import { useState } from 'react';
import { Icon } from './Icon';
import { api, errorMessage } from '../api/client';
import { cx } from '../lib/format';
import { sfx } from '../lib/sound';
import { haptic, share, shareMessage } from '../lib/telegram';
import { toast } from '../store/toast';

/**
 * «Поделиться» after a win: the server prepares a message with the brainrot's card and a «Играть» button on the
 * player's referral link (POST /api/share/win: the latest win of the last 15 minutes), Telegram's chat picker sends it.
 */
export function ShareWinButton({ className }: { className?: string }) {
  const [busy, setBusy] = useState(false);

  async function go() {
    setBusy(true);
    try {
      const prepared = await api<{ preparedId: string | null; text: string; url: string }>('/api/share/win', { body: {} });
      let sent = prepared.preparedId ? await shareMessage(prepared.preparedId) : null;
      if (sent === null) {
        // Older Telegram (or a browser): the classic share sheet with the text and the link.
        share(prepared.text, prepared.url);
        sent = true;
      }
      if (sent) {
        haptic('success');
        toast('Отправлено! Друг по твоей ссылке получит бесплатный кейс', 'success');
      }
    } catch (e) {
      sfx.error();
      toast(errorMessage(e), 'error');
    } finally {
      setBusy(false);
    }
  }

  return (
    <button type="button" className={cx('btn btn--ghost share-win', className)} onClick={() => void go()} disabled={busy} aria-busy={busy}>
      <Icon name="send" size={18} /> {busy ? 'Готовим…' : 'Поделиться'}
    </button>
  );
}
