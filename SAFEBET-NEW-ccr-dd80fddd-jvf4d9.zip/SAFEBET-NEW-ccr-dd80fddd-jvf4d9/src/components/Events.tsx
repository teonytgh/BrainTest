import { useEffect, useRef, useState } from 'react';
import { useCatalog } from '../api/queries';
import { EVENT_IDS, EVENT_INFO, SNAP_AT_SECONDS, SNAP_REPLAY_MS, SNAP_VIDEO_SECONDS, eventOn, type EventId } from '../../shared/events';
import { cx } from '../lib/format';
import { timeLeft } from '../lib/halloween';
import { routeHref, type RouteName } from '../lib/router';
import { sfx } from '../lib/sound';
import { tacosMusic, useTacosMusic } from '../lib/tacosMusic';
import { bgMusic } from '../lib/bgMusic';
import { haptic } from '../lib/telegram';
import { useNow } from '../lib/useNow';
import { Icon } from './Icon';

/**
 * The events admins switch on in «Ивенты» (or all at once with «Щелчок»). The FUSE and upgrader events are the look
 * only, so their lines never promise better odds; x2 / x4 / x8 luck in cases is real and says so.
 */
const LINES: Record<EventId, string> = {
  cases: 'Шанс окупа в кейсах и батлах удвоен',
  luck4: 'Шанс окупа в кейсах и батлах ×4',
  luck8: 'Шанс окупа в кейсах и батлах ×8',
  fuse: 'FUSE в праздничном режиме',
  upgrade: 'Апгрейдер в праздничном режиме',
  tacos: 'Музыка и дождь из тако по всему сайту',
};

/** Events running right now, with their ends. */
export function useEvents(now: number) {
  const catalog = useCatalog();
  const events = catalog.events;
  return EVENT_IDS.flatMap((id) => (events && eventOn(events[id], now) ? [{ id, endsAt: events[id]! }] : []));
}

/** The banner on a game's page while its event runs. */
export function EventBanner({ id }: { id: EventId }) {
  const now = useNow(1000);
  const ev = useEvents(now).find((e) => e.id === id);
  if (!ev) return null;
  const info = EVENT_INFO[id];
  return (
    <div className={cx('ev-banner', `ev-banner--${id}`)}>
      <img src={info.icon} alt="" />
      <span>
        <b className="ev-banner__title">{info.name}</b>
        <small>{LINES[id]}</small>
      </span>
      <span className="ev-banner__time">
        <Icon name="clock" size={12} /> {timeLeft(ev.endsAt - now)}
      </span>
      <i className="ev-banner__sparks" aria-hidden="true">
        <i />
        <i />
        <i />
        <i />
      </i>
    </div>
  );
}

/** Short names under the icons of the events row. */
const SHORT: Record<EventId, string> = { cases: 'Удача', luck4: 'Удача x4', luck8: 'Удача x8', fuse: 'FUSE', upgrade: 'Апгрейд', tacos: 'Тако' };

/** 4:59 under an hour, 2:05:00 above. */
function clock(ms: number) {
  const total = Math.max(0, Math.ceil(ms / 1000));
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const sec = String(total % 60).padStart(2, '0');
  return h ? `${h}:${String(m).padStart(2, '0')}:${sec}` : `${m}:${sec}`;
}

/**
 * Running events on every page, like the luck boosts at the bottom of Steal a Brainrot: one square per event, its
 * icon and the time left. On phones the row sits on the bottom bar, split around the upgrader disc; on a PC in the
 * header's empty middle (at the bottom it covered the page — the upgrader's button among others); a tap leads to
 * the event's game, the tacos square switches its music on and off. While it shows, pages and sticky action bars
 * make room for it (--hud-h).
 */
export function EventsHud({ phone }: { phone: boolean }) {
  const now = useNow(1000);
  const running = useEvents(now);
  const music = useTacosMusic();
  // «Небо Meowl» (iteration 35) gets its square too while it runs.
  const { sky, squid } = useCatalog();
  const skyOn = !!sky && sky.endsAt > now;
  const shown = running.length > 0 || skyOn || !!squid;

  useEffect(() => {
    const root = document.documentElement;
    // Phones: the row sits on the bottom bar, so pages make room for it; PC: in the header, nothing to make room for.
    if (shown) root.dataset.hud = phone ? 'phone' : 'pc';
    else delete root.dataset.hud;
    return () => {
      delete root.dataset.hud;
    };
  }, [shown, phone]);

  if (!shown) return null;
  const chip = (e: { id: EventId; endsAt: number }) => {
    const info = EVENT_INFO[e.id];
    const left = clock(e.endsAt - now);
    const body = (
      <>
        <img src={info.icon} alt="" />
        <b>{left}</b>
        <small>{SHORT[e.id]}</small>
      </>
    );
    if (e.id === 'tacos') {
      return (
        <button
          key={e.id}
          type="button"
          className={cx('ev-hud__chip', 'ev-hud__chip--tacos', music.muted && 'is-muted', music.playing && 'is-playing')}
          onClick={() => tacosMusic.toggleMute()}
          aria-pressed={!music.muted}
          aria-label={`${info.name}, ещё ${left}. ${music.muted ? 'Включить музыку' : 'Выключить музыку'}`}
        >
          {body}
          <span className="ev-hud__sound" aria-hidden="true">
            <Icon name={music.muted ? 'volumeOff' : 'volume'} size={11} />
          </span>
        </button>
      );
    }
    return (
      <a key={e.id} className={cx('ev-hud__chip', `ev-hud__chip--${e.id}`)} href={routeHref(info.route as RouteName)} aria-label={`${info.name}, ещё ${left}`}>
        {body}
      </a>
    );
  };
  const chips = running.map(chip);
  if (skyOn) {
    const left = clock(sky.endsAt - now);
    chips.unshift(
      <a key="sky" className="ev-hud__chip ev-hud__chip--sky" href={routeHref('sky')} aria-label={`Небо Meowl, ещё ${left}`}>
        <img src="/sky/meowl-face.webp" alt="" />
        <b>{left}</b>
        <small>Небо</small>
      </a>,
    );
  }
  if (squid) {
    // «Игра Кальмара»: the lobby's countdown, then «LIVE» while it is played.
    const lobby = squid.lobbyUntil > now;
    chips.unshift(
      <a
        key="squid"
        className="ev-hud__chip ev-hud__chip--squid"
        href={routeHref('squid')}
        aria-label={lobby ? `Игра Кальмара, вход ещё ${clock(squid.lobbyUntil - now)}` : 'Игра Кальмара идёт'}
      >
        <img src="/squid/watcher-red.webp" alt="" />
        <b>{lobby ? clock(squid.lobbyUntil - now) : 'LIVE'}</b>
        <small>Кальмар</small>
      </a>,
    );
  }
  const half = phone ? Math.ceil(chips.length / 2) : chips.length;
  return (
    // A group, not a live region: the timers tick every second and would chatter in a screen reader.
    <div className={cx('ev-hud', phone && 'ev-hud--phone')} role="group" aria-label="Идут ивенты">
      <div className="ev-hud__side">{chips.slice(0, half)}</div>
      {phone && <div className="ev-hud__side ev-hud__side--right">{chips.slice(half)}</div>}
    </div>
  );
}

const SEEN_KEY = 'brainrotcrash:snap-seen';
/**
 * Sammyni's footsteps in the cutscene, in video seconds: one every 7.5 frames from frame 24 to 144 at 24 fps (the
 * STRIDE in scripts/blender/snap_cutscene.py); the walk ends on frame 150.
 */
const STEP_SECONDS = Array.from({ length: 17 }, (_, k) => (24 + 7.5 * k - 1) / 24);
const WALK_END_SECONDS = 149 / 24;

function seenSnap(): number {
  try {
    return Number(localStorage.getItem(SEEN_KEY)) || 0;
  } catch {
    return 0;
  }
}

function markSeen(at: number) {
  try {
    localStorage.setItem(SEEN_KEY, String(at));
  } catch {
    // Private mode: it may play again on the next open — no harm.
  }
}

/**
 * «Щелчок»: when an admin snaps, every open app (and every one opened in the next minutes) plays the 10-second cutscene
 * once, then shows which events are on and for how long.
 */
export function SnapOverlay() {
  const catalog = useCatalog();
  const snap = catalog.snap ?? null;
  const [playing, setPlaying] = useState<number | null>(null);
  const [stage, setStage] = useState<'loading' | 'video' | 'card'>('loading');
  const video = useRef<HTMLVideoElement>(null);
  const snapped = useRef(false);
  const score = useRef<{ stop(): void } | null>(null);
  const now = useNow(1000);
  const watching = playing !== null && stage !== 'card';

  // The tacos track waits for the card: the cutscene has its own sound.
  useEffect(() => {
    tacosMusic.hold(watching);
  }, [watching]);
  // The background music keeps quiet for the whole cutscene and its card.
  useEffect(() => {
    bgMusic.hold(playing !== null);
  }, [playing]);
  useEffect(
    () => () => {
      tacosMusic.hold(false);
      bgMusic.hold(false);
      score.current?.stop();
    },
    [],
  );

  useEffect(() => {
    if (!snap || playing === snap.at) return;
    const t = Date.now();
    if (snap.endsAt <= t || t - snap.at > SNAP_REPLAY_MS || seenSnap() >= snap.at) return;
    markSeen(snap.at);
    snapped.current = false;
    score.current?.stop();
    score.current = null;
    setStage('loading');
    setPlaying(snap.at);
  }, [snap, playing]);

  // The video may be slow or blocked: the card comes anyway.
  useEffect(() => {
    if (playing === null || stage === 'card') return;
    const t = setTimeout(() => setStage((s) => (s === 'loading' ? 'card' : s)), 6000);
    const end = setTimeout(() => setStage('card'), (SNAP_VIDEO_SECONDS + 7) * 1000);
    return () => {
      clearTimeout(t);
      clearTimeout(end);
    };
  }, [playing, stage]);

  if (playing === null || !snap || snap.at !== playing) return null;

  function onTime() {
    const v = video.current;
    if (!v || snapped.current || v.currentTime < SNAP_AT_SECONDS - 0.05) return;
    snapped.current = true;
    sfx.snap();
    sfx.boom();
    haptic('success');
  }

  function close() {
    setPlaying(null);
    // A tap: where the browser held the tacos track back, it may start now.
    tacosMusic.hold(false);
    tacosMusic.kick();
  }

  function toCard() {
    if (stage === 'card') return;
    score.current?.stop();
    score.current = null;
    setStage('card');
    sfx.bigWin();
  }

  const left = Math.max(0, snap.endsAt - now);
  return (
    <div className={cx('snap', `snap--${stage}`)} role="dialog" aria-modal="true" aria-label="Щелчок — ивенты включены">
      {stage !== 'card' && (
        <>
          <video
            ref={video}
            className="snap__video"
            autoPlay
            muted
            playsInline
            preload="auto"
            poster="/events/snap-poster.webp"
            onPlaying={() => {
              setStage('video');
              // The dark aura walk, then the build-up hum until the fingers snap (once, even after a stall).
              if (score.current) return;
              const at = video.current?.currentTime ?? 0;
              score.current = sfx.snapScore(
                STEP_SECONDS.filter((t) => t >= at).map((t) => t - at),
                Math.max(0, WALK_END_SECONDS - at),
                Math.max(0.5, SNAP_AT_SECONDS - at),
              );
            }}
            onTimeUpdate={onTime}
            onEnded={toCard}
            onError={toCard}
          >
            <source src="/events/snap.webm" type="video/webm" />
            <source src="/events/snap.mp4" type="video/mp4" />
          </video>
          {stage === 'loading' && (
            <span className="snap__loading" aria-hidden="true">
              <Icon name="bolt" size={40} />
            </span>
          )}
          <button type="button" className="snap__skip" onClick={toCard}>
            Пропустить <Icon name="chevronRight" size={14} />
          </button>
        </>
      )}
      {stage === 'card' && (
        <div className="snap-card">
          <span className="snap-card__burst" aria-hidden="true" />
          <p className="snap-card__kicker">⚡ Щелчок!</p>
          <h2 className="snap-card__title">Ивенты включены</h2>
          <p className="snap-card__time">
            ещё <b>{timeLeft(left)}</b>
          </p>
          <ul className="snap-card__list">
            {snap.events.map((id, i) => (
              <li key={id} style={{ animationDelay: `${0.15 + i * 0.08}s` }}>
                <img src={EVENT_INFO[id].icon} alt="" />
                <span>
                  <b>{EVENT_INFO[id].name}</b>
                  <small>{LINES[id]}</small>
                </span>
              </li>
            ))}
          </ul>
          <div className="snap-card__actions">
            <button type="button" className="btn btn--primary btn--lg btn--block" onClick={close}>
              Играть
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
