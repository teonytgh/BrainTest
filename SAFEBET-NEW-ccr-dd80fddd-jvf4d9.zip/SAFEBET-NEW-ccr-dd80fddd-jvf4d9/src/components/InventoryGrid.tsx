import { useState, type ReactNode } from 'react';
import { BrainrotCard } from './BrainrotCard';
import { EmptyState } from './EmptyState';
import { useCatalog, type Me } from '../api/queries';
import { cx } from '../lib/format';

export type InventoryItem = Me['inventory'][number];

type Sort = 'expensive' | 'cheap' | 'new';
const SORTS: { value: Sort; label: string }[] = [
  { value: 'expensive', label: 'Дороже' },
  { value: 'cheap', label: 'Дешевле' },
  { value: 'new', label: 'Новые' },
];
const SORT_KEY = 'brainrotcrash:inventorySort';

function savedSort(): Sort {
  try {
    const v = localStorage.getItem(SORT_KEY);
    return v === 'cheap' || v === 'new' ? v : 'expensive';
  } catch {
    return 'expensive';
  }
}

interface Props {
  items: InventoryItem[];
  selectedUid?: number | null;
  /** Several picks in order: each card shows its number. */
  selected?: readonly number[];
  disabled?: boolean;
  onPick: (item: InventoryItem) => void;
  meta?: (item: InventoryItem) => ReactNode;
  /** Sort chips above the grid. */
  sortable?: boolean;
}

/** Brainrots on a withdrawal are shown last, greyed out with «НА ВЫВОДЕ», and can't be picked. */
export function InventoryGrid({ items, selectedUid, selected, disabled, onPick, meta, sortable }: Props) {
  const catalog = useCatalog();
  const [sort, setSort] = useState<Sort>(savedSort);
  const known = items.filter((i) => catalog.byId.has(i.brainrotId));
  if (known.length === 0) {
    return (
      <EmptyState
        icon="box"
        title="Инвентарь пуст"
        text="Открой кейс — брейнроты из него сразу появятся здесь."
        action={
          <a className="btn btn--primary" href="#/">
            К кейсам
          </a>
        }
      />
    );
  }
  const price = (i: InventoryItem) => catalog.byId.get(i.brainrotId)!.price;
  const order = (a: InventoryItem, b: InventoryItem) => (sort === 'new' ? b.id - a.id : sort === 'cheap' ? price(a) - price(b) : price(b) - price(a));
  const sorted = [...known].sort((a, b) => Number(!!a.withdrawalId) - Number(!!b.withdrawalId) || order(a, b));
  return (
    <>
      {sortable && (
        <div className="inv-sort" role="radiogroup" aria-label="Сортировка">
          {SORTS.map((s) => (
            <button
              key={s.value}
              type="button"
              role="radio"
              aria-checked={sort === s.value}
              className={cx('chip chip--sm', sort === s.value && 'is-active')}
              onClick={() => {
                setSort(s.value);
                try {
                  localStorage.setItem(SORT_KEY, s.value);
                } catch {
                  // The order just isn't remembered.
                }
              }}
            >
              {s.label}
            </button>
          ))}
        </div>
      )}
      <div className="grid">
        {sorted.map((item) => {
          const at = selected?.indexOf(item.id) ?? -1;
          const onWithdrawal = !!item.withdrawalId;
          return (
            <BrainrotCard
              key={item.id}
              brainrot={catalog.byId.get(item.brainrotId)!}
              selected={selectedUid === item.id || at >= 0}
              disabled={disabled || onWithdrawal}
              muted={onWithdrawal}
              meta={onWithdrawal ? 'На выводе' : meta?.(item)}
              badge={at >= 0 ? at + 1 : undefined}
              demo={item.demo}
              onClick={() => onPick(item)}
            />
          );
        })}
      </div>
    </>
  );
}
