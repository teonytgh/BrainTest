import { createHmac, timingSafeEqual } from 'node:crypto';
import { env } from '../env';

/**
 * Multiplayer rooms (iteration 35: «Небо Meowl»). A room lives in a Durable Object on Cloudflare (`GameRoom` in
 * worker/index.ts) or in the local dev server's memory; the API reaches it through this bridge — to tell everyone a
 * coin was taken or an egg dropped, and to ask who is online where. Without a bridge (tests) sends are no-ops and
 * calls return null.
 */
export interface RoomBridge {
  send(room: string, msg: unknown): Promise<void>;
  call(room: string, op: string, arg?: unknown): Promise<unknown>;
}

let bridge: RoomBridge | null = null;

export function useRooms(b: RoomBridge | null) {
  bridge = b;
}

export async function roomSend(room: string, msg: unknown): Promise<void> {
  if (!bridge) return;
  await bridge.send(room, msg).catch((e) => console.error('room send failed', room, e));
}

export async function roomCall<T>(room: string, op: string, arg?: unknown): Promise<T | null> {
  if (!bridge) return null;
  try {
    return (await bridge.call(room, op, arg)) as T;
  } catch (e) {
    console.error('room call failed', room, op, e);
    return null;
  }
}

// ---------- Tickets ----------

const TICKET_TTL_MS = 60_000;

function key() {
  return createHmac('sha256', env('BOT_TOKEN') ?? '').update('brainrotcrash-room').digest();
}

export interface RoomPass {
  userId: number;
  /** The name other players see (`publicName`: never the @username). */
  name: string;
  room: string;
  /** An admin's immortality for trailers (iteration 37): no damage, no knock-out in the room's games. */
  god?: boolean;
}

/** A short-lived signed pass into one room, carrying the player's public name (the room has no database). */
export function roomTicket(pass: RoomPass, now = Date.now()): string {
  const body = Buffer.from(JSON.stringify({ u: pass.userId, n: pass.name, r: pass.room, e: now + TICKET_TTL_MS, ...(pass.god ? { g: 1 } : {}) })).toString('base64url');
  return `${body}.${createHmac('sha256', key()).update(body).digest('base64url')}`;
}

export function verifyRoomTicket(ticket: string, now = Date.now()): RoomPass | null {
  const m = /^([A-Za-z0-9_-]{8,600})\.([A-Za-z0-9_-]{43})$/.exec(ticket);
  if (!m) return null;
  const sig = createHmac('sha256', key()).update(m[1]!).digest('base64url');
  if (!timingSafeEqual(Buffer.from(sig), Buffer.from(m[2]!))) return null;
  try {
    const p = JSON.parse(Buffer.from(m[1]!, 'base64url').toString('utf8')) as { u?: unknown; n?: unknown; r?: unknown; e?: unknown; g?: unknown };
    if (typeof p.u !== 'number' || typeof p.n !== 'string' || typeof p.r !== 'string' || typeof p.e !== 'number' || p.e < now) return null;
    return { userId: p.u, name: p.n.slice(0, 40), room: p.r, god: p.g === 1 };
  } catch {
    return null;
  }
}

export const skyRoom = (runId: number) => `sky:${runId}`;
