import { round2 } from '../shared/money';
import { assertActive, type Viewer } from './auth';
import { ms, num, one, q, tx } from './db';
import { depositPrices } from './depositList';
import { resolveDepositPromo, spendDepositPromo } from './depositPromo';
import { addCoins, addWager } from './economy';
import { afterResponse, touch } from './live';
import { markActiveReferral, notifyActiveFriend, notifyDepositShare, notifyMilestones, payDepositShare, payMilestones, type MilestonePaid } from './referrals';
import { OWNER_IDS, isOwnerId, siteUrl } from './env';
import { HttpError, bad } from './errors';
import { getSettings, setSetting } from './settings';
import { botApi, escapeHtml, notify } from './telegram';
import { displayName, getUser, type UserRow } from './users';
import { int, robloxNick, type Body } from './validate';
import { DEPOSIT_SECTION_OF, MAX_DEPOSIT_ITEMS } from '../shared/deposit';

/** A player sends at most this many brainrots in one trade (shared with the picker). */
export { MAX_DEPOSIT_ITEMS };
/** Time the player gets to send the trade once an admin picked a receiving account. */
export const TRADE_WINDOW_MS = 5 * 60 * 1000;

type Status = 'searching' | 'trading' | 'credited' | 'rejected' | 'expired' | 'cancelled';

interface DepositRow {
  id: string;
  user_id: string;
  items: { brainrotId: string; name: string; count: number; price: number }[];
  value: string;
  bonus: string;
  bonus_percent: number;
  promo_window: string | null;
  roblox_nick: string;
  status: Status;
  bot_nick: string | null;
  trade_deadline: string | null;
  credited: string | null;
  handled_by: string | null;
  admin_messages: { chatId: number; messageId: number }[];
  created_at: string;
  updated_at: string;
}

const fmt = (n: number) => n.toLocaleString('ru-RU', { maximumFractionDigits: 2 });
const total = (d: DepositRow) => round2(num(d.value) + num(d.bonus));
const playUrl = () => `${siteUrl()}/`;
const playButton = () => ({ inline_keyboard: [[{ text: '🎮 Открыть BrainrotCrash', web_app: { url: playUrl() } }]] });

function view(d: DepositRow) {
  return {
    id: num(d.id),
    status: d.status,
    items: d.items,
    value: num(d.value),
    bonus: num(d.bonus),
    bonusPercent: d.bonus_percent,
    total: total(d),
    robloxNick: d.roblox_nick,
    botNick: d.status === 'trading' ? d.bot_nick : null,
    deadline: ms(d.trade_deadline),
    credited: d.credited === null ? null : num(d.credited),
    createdAt: ms(d.created_at)!,
  };
}

export type ItemDepositView = ReturnType<typeof view>;

// ---------- Player API ----------

export async function createItemDeposit(v: Viewer, body: Body) {
  assertActive(v);
  if (!Array.isArray(body.items) || !body.items.length) throw bad('invalid', 'Выбери брейнротов для пополнения');
  const counts = new Map<string, number>();
  for (const raw of body.items as Body[]) {
    const id = typeof raw?.brainrotId === 'string' ? raw.brainrotId : '';
    counts.set(id, (counts.get(id) ?? 0) + int(raw?.count ?? 1, 'количество', 1, MAX_DEPOSIT_ITEMS));
  }
  const pieces = [...counts.values()].reduce((a, b) => a + b, 0);
  if (pieces > MAX_DEPOSIT_ITEMS) throw bad('too_many', `Максимум ${MAX_DEPOSIT_ITEMS} брейнротов за одно пополнение`);
  const nick = robloxNick(body.robloxNick);
  // Prices come from the admin's deposit list, not from the client.
  const listed = await depositPrices([...counts.keys()]);
  if (listed.size !== counts.size) throw bad('unavailable', 'Некоторые брейнроты сейчас нельзя внести');
  // A tab the admins closed takes no new requests (open ones carry on).
  const { depositOpen } = await getSettings();
  const closed = [...listed.values()].find((b) => !depositOpen[b.section]);
  if (closed) throw bad('deposit_closed', `Пополнение ${DEPOSIT_SECTION_OF[closed.section]} сейчас закрыто — загляни позже`);
  const items = [...listed].map(([id, b]) => ({ brainrotId: id, name: b.name, count: counts.get(id)!, price: b.price })).sort((a, b) => b.price - a.price);
  const value = round2(items.reduce((s, i) => s + i.price * i.count, 0));
  const promo = await resolveDepositPromo(v.id, body.promo, 'brainrots');
  const bonus = promo ? round2((value * promo.percent) / 100) : 0;
  // Every request pings all admins in the bot: cap cancel-and-recreate loops.
  const recent = await one<{ n: string }>(`SELECT count(*) AS n FROM item_deposits WHERE user_id = $1 AND created_at > now() - interval '10 minutes'`, [v.id]);
  if (num(recent?.n) >= 5) throw new HttpError(429, 'too_many', 'Слишком много заявок подряд — подожди несколько минут');

  let row: DepositRow | undefined;
  try {
    row = await one<DepositRow>(
      `INSERT INTO item_deposits (user_id, items, value, bonus, bonus_percent, promo_window, roblox_nick)
       VALUES ($1, $2::jsonb, $3, $4, $5, $6, $7) RETURNING *`,
      [v.id, JSON.stringify(items), value, bonus, promo?.percent ?? 0, promo?.window ?? null, nick],
    );
  } catch (e) {
    if ((e as { code?: string }).code === '23505') throw new HttpError(409, 'already_open', 'У тебя уже есть активная заявка — дождись её или отмени');
    throw e;
  }
  const user = (await getUser(v.id))!;
  // The request is saved: the player gets the answer now, the bot messages follow.
  await afterResponse(async () => {
    await notify(v.id, `📥 Заявка #${row!.id} на пополнение брейнротами создана.\nПодбираем для тебя бота — когда он будет готов, пришлём сообщение.`);
    await announce(row!, user);
  });
  return view(row!);
}

/** The player's latest deposit; an overdue trade is expired on the way. */
export async function currentItemDeposit(v: Viewer) {
  await expireOverdue({ userId: v.id });
  const row = await one<DepositRow>('SELECT * FROM item_deposits WHERE user_id = $1 ORDER BY id DESC LIMIT 1', [v.id]);
  return row ? view(row) : null;
}

export async function cancelItemDeposit(v: Viewer, idParam: string) {
  const id = int(idParam, 'заявка');
  const row = await one<DepositRow>(
    `UPDATE item_deposits SET status = 'cancelled', updated_at = now() WHERE id = $1 AND user_id = $2 AND status = 'searching' RETURNING *`,
    [id, v.id],
  );
  if (!row) throw bad('not_cancellable', 'Эту заявку уже нельзя отменить');
  await afterResponse(() => refreshAdminMessages(row));
  return view(row);
}

// ---------- Admin side (bot) ----------

export async function adminIds(): Promise<number[]> {
  const rows = await q<{ user_id: string }>('SELECT user_id FROM admins');
  return [...new Set([...OWNER_IDS, ...rows.map((r) => num(r.user_id))])];
}

/** Bot buttons of deposits and withdrawals: a banned or frozen admin's taps stop working too. */
export async function isAdmin(id: number) {
  if (isOwnerId(id)) return true;
  return !!(await one(
    `SELECT 1 FROM admins a WHERE a.user_id = $1 AND NOT EXISTS (
       SELECT 1 FROM punishments p WHERE p.user_id = a.user_id AND p.revoked_at IS NULL AND (p.until IS NULL OR p.until > now()))`,
    [id],
  ));
}

const mskTime = new Intl.DateTimeFormat('ru-RU', { timeZone: 'Europe/Moscow', hour: '2-digit', minute: '2-digit', second: '2-digit' });

function statusLine(d: DepositRow, handler: string | null): string {
  switch (d.status) {
    case 'searching':
      return '⏳ ждёт бота — выбери ник для трейда';
    case 'trading':
      return `🤝 трейд на <code>${escapeHtml(d.bot_nick ?? '')}</code> до ${mskTime.format(ms(d.trade_deadline)!)} МСК`;
    case 'credited':
      return `✅ зачислено ${fmt(num(d.credited))} B${handler ? ` (${escapeHtml(handler)})` : ''}`;
    case 'rejected':
      return `❌ отклонено${handler ? ` (${escapeHtml(handler)})` : ''}`;
    case 'expired':
      return '⌛ время на трейд вышло — можно назначить бота снова, зачислить или отклонить';
    case 'cancelled':
      return '🚫 отменена игроком';
  }
}

async function adminText(d: DepositRow, user: UserRow | undefined): Promise<string> {
  const who = user ? displayName(user) : `ID ${d.user_id}`;
  const handler = d.handled_by ? await getUser(num(d.handled_by)).then((u) => (u ? displayName(u) : null)) : null;
  const lines = d.items.map((i) => `• ${escapeHtml(i.name)}${i.count > 1 ? ` ×${i.count}` : ''} — ${fmt(i.price * i.count)} B`);
  const bonus = num(d.bonus) ? ` + бонус ${d.bonus_percent}% = <b>${fmt(total(d))} B</b>` : '';
  return [
    `📥 <b>Пополнение брейнротами #${d.id}</b>`,
    `Игрок: <a href="tg://user?id=${d.user_id}">${escapeHtml(who)}</a> · ID ${d.user_id}`,
    `Roblox игрока: <code>${escapeHtml(d.roblox_nick)}</code>`,
    ...lines,
    `Сумма: <b>${fmt(num(d.value))} B</b>${bonus}`,
    `Статус: ${statusLine(d, handler)}`,
  ].join('\n');
}

async function adminKeyboard(d: DepositRow, user: UserRow | undefined) {
  const rows: { text: string; callback_data?: string; url?: string }[][] = [];
  if (d.status === 'searching' || d.status === 'trading' || d.status === 'expired') {
    const { tradeBots } = await getSettings();
    for (let i = 0; i < tradeBots.length; i += 2) {
      rows.push(tradeBots.slice(i, i + 2).map((nick) => ({ text: `🤖 ${nick}${d.bot_nick === nick && d.status === 'trading' ? ' ✓' : ''}`, callback_data: `d:${d.id}:b:${nick}` })));
    }
    rows.push([{ text: '➕ Новый ник бота', callback_data: `d:${d.id}:n` }]);
    rows.push([
      { text: '✅ Зачислить', callback_data: `d:${d.id}:c` },
      { text: '❌ Отклонить', callback_data: `d:${d.id}:r` },
    ]);
  }
  rows.push([user?.username ? { text: '💬 Связаться', url: `https://t.me/${user.username}` } : { text: '💬 Связаться', callback_data: `d:${d.id}:u` }]);
  return { inline_keyboard: rows };
}

/** Labels of the admins' reply keyboard in the bot. */
export const QUEUE_BUTTON = '📥 Очередь пополнений';
export const PANEL_BUTTON = '🛠 Админ-панель';
/** Persistent buttons under the admins' message field («📤 Очередь выводов» is handled in server/withdrawals.ts). */
export const adminReplyKeyboard = () => ({
  keyboard: [[{ text: QUEUE_BUTTON }, { text: '📤 Очередь выводов' }], [{ text: PANEL_BUTTON }]],
  resize_keyboard: true,
  is_persistent: true,
});

const QUEUE_LIMIT = 10;

/**
 * «📥 Очередь пополнений»: re-sends every open request to this admin with its buttons. The new message
 * replaces this admin's older copy in the refresh list, so later actions update it in place.
 */
export async function sendQueue(chatId: number): Promise<string> {
  const rows = await q<DepositRow>(`SELECT * FROM item_deposits WHERE status IN ('searching', 'trading') ORDER BY id LIMIT ${QUEUE_LIMIT + 1}`);
  if (!rows.length) return '✅ Очередь пуста — новых заявок нет.';
  for (const d of rows.slice(0, QUEUE_LIMIT)) {
    const user = await getUser(num(d.user_id));
    const m = await botApi<{ message_id: number }>('sendMessage', {
      chat_id: chatId,
      text: await adminText(d, user),
      parse_mode: 'HTML',
      reply_markup: await adminKeyboard(d, user),
      disable_web_page_preview: true,
    });
    if (!m) continue;
    const messages = [...d.admin_messages.filter((x) => x.chatId !== chatId), { chatId, messageId: m.message_id }];
    await q('UPDATE item_deposits SET admin_messages = $2::jsonb WHERE id = $1', [d.id, JSON.stringify(messages)]);
  }
  const shown = Math.min(rows.length, QUEUE_LIMIT);
  return `📥 В очереди ${rows.length > QUEUE_LIMIT ? `больше ${QUEUE_LIMIT}` : shown} — заявки выше, кнопки под каждой.`;
}

/** Sends the request to every admin and remembers the messages so later changes update them in place. */
async function announce(d: DepositRow, user: UserRow) {
  const [text, keyboard] = [await adminText(d, user), await adminKeyboard(d, user)];
  const sent = await Promise.all(
    (await adminIds()).map(async (chatId) => {
      const m = await botApi<{ message_id: number }>('sendMessage', { chat_id: chatId, text, parse_mode: 'HTML', reply_markup: keyboard, disable_web_page_preview: true });
      return m ? { chatId, messageId: m.message_id } : null;
    }),
  );
  const messages = sent.filter((m): m is { chatId: number; messageId: number } => !!m);
  await q('UPDATE item_deposits SET admin_messages = $2::jsonb WHERE id = $1', [d.id, JSON.stringify(messages)]);
}

async function refreshAdminMessages(d: DepositRow) {
  const user = await getUser(num(d.user_id));
  const [text, keyboard] = [await adminText(d, user), await adminKeyboard(d, user)];
  await Promise.all(
    d.admin_messages.map((m) =>
      botApi('editMessageText', { chat_id: m.chatId, message_id: m.messageId, text, parse_mode: 'HTML', reply_markup: keyboard, disable_web_page_preview: true }),
    ),
  );
}

type Outcome = { ok: true; row: DepositRow } | { ok: false; reason: string };

async function assignBot(id: number, adminId: number, nick: string): Promise<Outcome> {
  const row = await one<DepositRow>(
    `UPDATE item_deposits SET status = 'trading', bot_nick = $2, trade_deadline = now() + interval '${TRADE_WINDOW_MS / 1000} seconds',
       handled_by = $3, updated_at = now()
     WHERE id = $1 AND status IN ('searching', 'trading', 'expired') RETURNING *`,
    [id, nick, adminId],
  );
  if (!row) return { ok: false, reason: 'Заявка уже закрыта' };
  touch(num(row.user_id), 'itemDeposit');
  await afterResponse(() =>
    botApi('sendMessage', {
      chat_id: num(row.user_id),
      parse_mode: 'HTML',
      text: `🔔 <b>Твоя очередь!</b> Заявка #${row.id}: открой BrainrotCrash — там ник, на который нужно отправить трейд.\nНа отправку трейда 5 минут.`,
      reply_markup: playButton(),
    }),
  );
  return { ok: true, row };
}

async function creditDeposit(id: number, adminId: number): Promise<Outcome> {
  let referrer: number | null = null;
  let share: Awaited<ReturnType<typeof payDepositShare>> = null;
  let milestones: MilestonePaid[] = [];
  const row = await tx(async (c) => {
    const { rows } = await c.query<DepositRow>(
      `UPDATE item_deposits SET status = 'credited', credited = value + bonus, handled_by = $2, updated_at = now()
       WHERE id = $1 AND status IN ('searching', 'trading', 'expired') RETURNING *`,
      [id, adminId],
    );
    let d = rows[0];
    if (!d) return null;
    // The promo bonus only if this window's bonus wasn't already paid on another deposit.
    if (num(d.bonus) > 0) {
      const bonusOk = d.bonus_percent > 0 && d.promo_window !== null && (await spendDepositPromo(c, num(d.user_id), num(d.promo_window), d.bonus_percent));
      if (!bonusOk) d = (await c.query<DepositRow>('UPDATE item_deposits SET bonus = 0, bonus_percent = 0, credited = value WHERE id = $1 RETURNING *', [d.id])).rows[0]!;
    }
    await addCoins(c, num(d.user_id), total(d));
    // «Отыгрыш»: deposited brainrots are played through before anything goes out (no swap of one brainrot for
    // another at catalog price without playing).
    await addWager(c, num(d.user_id), total(d), 'deposit');
    referrer = await markActiveReferral(c, num(d.user_id), total(d));
    // The referrer's share: of the brainrots' value (the promo bonus on top doesn't count).
    share = await payDepositShare(c, num(d.user_id), num(d.value));
    milestones = await payMilestones(c, num(d.user_id));
    await c.query('INSERT INTO admin_log (admin_id, action, target_user, details) VALUES ($1, $2, $3, $4::jsonb)', [
      adminId,
      'item_deposit_credit',
      d.user_id,
      JSON.stringify({ id: num(d.id), amount: total(d) }),
    ]);
    return d;
  });
  if (!row) return { ok: false, reason: 'Заявка уже закрыта' };
  touch(num(row.user_id), 'itemDeposit', 'me');
  const becameActive = referrer as number | null;
  const paid = share as Awaited<ReturnType<typeof payDepositShare>>;
  await afterResponse(async () => {
    if (paid) await notifyDepositShare(paid, becameActive !== null);
    else if (becameActive !== null) await notifyActiveFriend(becameActive);
    await notifyMilestones(milestones);
    await botApi('sendMessage', {
      chat_id: num(row.user_id),
      parse_mode: 'HTML',
      text: `✅ Пополнение брейнротами #${row.id} зачислено: <b>+${fmt(total(row))} B</b>`,
      reply_markup: playButton(),
    });
  });
  return { ok: true, row };
}

async function rejectDeposit(id: number, adminId: number): Promise<Outcome> {
  const row = await one<DepositRow>(
    `UPDATE item_deposits SET status = 'rejected', handled_by = $2, updated_at = now()
     WHERE id = $1 AND status IN ('searching', 'trading', 'expired') RETURNING *`,
    [id, adminId],
  );
  if (!row) return { ok: false, reason: 'Заявка уже закрыта' };
  touch(num(row.user_id), 'itemDeposit');
  await afterResponse(() => notify(num(row.user_id), `❌ Заявка #${row.id} на пополнение брейнротами отклонена.\nЕсли это ошибка — напиши /paysupport.`));
  return { ok: true, row };
}

/** Trades nobody credited within the window: expire, tell the player and refresh admin messages. */
export async function expireOverdue(scope: { userId?: number } = {}) {
  const rows = await q<DepositRow>(
    `UPDATE item_deposits SET status = 'expired', updated_at = now()
     WHERE status = 'trading' AND trade_deadline < now() ${scope.userId ? 'AND user_id = $1' : ''} RETURNING *`,
    scope.userId ? [scope.userId] : [],
  );
  for (const row of rows) {
    touch(num(row.user_id), 'itemDeposit');
    // An admin may have credited or rejected it a moment after the expiry: then the player hears only that.
    const now = await one<DepositRow>('SELECT * FROM item_deposits WHERE id = $1', [row.id]);
    if (!now || now.status !== 'expired') continue;
    await notify(num(row.user_id), `⌛ Время на трейд по заявке #${row.id} вышло. Создай заявку заново в BrainrotCrash.`);
    await refreshAdminMessages(now);
  }
  return rows.length;
}

const NICK_PROMPT = /Ник Roblox-аккаунта для заявки #(\d+)/;

interface CallbackQuery {
  id: string;
  from: { id: number };
  data?: string;
}

type BotReply = Record<string, unknown> | null;

/** Buttons under a deposit request in the admins' chats. */
export async function handleDepositCallback(cq: CallbackQuery): Promise<BotReply> {
  const answer = (text: string, alert = false) => ({ method: 'answerCallbackQuery', callback_query_id: cq.id, text, show_alert: alert });
  const m = /^d:(\d{1,18}):([bncru])(?::([A-Za-z0-9_]{3,20}))?$/.exec(cq.data ?? '');
  if (!m) return answer('Кнопка устарела');
  if (!(await isAdmin(cq.from.id))) return answer('Только для админов', true);
  const id = Number(m[1]);
  const action = m[2];
  let outcome: Outcome;
  let done: string;
  if (action === 'u') {
    const d = await one<DepositRow>('SELECT * FROM item_deposits WHERE id = $1', [id]);
    return answer(d ? `У игрока нет username. Telegram ID: ${d.user_id}` : 'Заявка не найдена', true);
  }
  if (action === 'n') {
    const d = await one<DepositRow>('SELECT status FROM item_deposits WHERE id = $1', [id]);
    if (!d || !['searching', 'trading', 'expired'].includes(d.status)) return answer('Заявка уже закрыта');
    await botApi('sendMessage', {
      chat_id: cq.from.id,
      text: `Ник Roblox-аккаунта для заявки #${id} — ответь на это сообщение. Ник сохранится и будет в кнопках у следующих заявок.`,
      reply_markup: { force_reply: true, input_field_placeholder: 'RobloxNick' },
    });
    return answer('Отправь ник ответом на сообщение');
  }
  if (action === 'b') {
    outcome = await assignBot(id, cq.from.id, m[3]!);
    done = `Отправили игроку ник ${m[3]}`;
  } else if (action === 'c') {
    outcome = await creditDeposit(id, cq.from.id);
    done = 'Зачислено';
  } else {
    outcome = await rejectDeposit(id, cq.from.id);
    done = 'Отклонено';
  }
  if (!outcome.ok) return answer(outcome.reason, true);
  const row = outcome.row;
  // The admin's button stops spinning now; the copies in every admin chat update right after.
  await afterResponse(() => refreshAdminMessages(row));
  return answer(done);
}

/** An admin answered the «new bot nick» prompt: save the nick and hand it to the player. */
export async function handleDepositReply(msg: { from: { id: number }; text: string; reply_to_message?: { text?: string } }): Promise<BotReply> {
  const m = NICK_PROMPT.exec(msg.reply_to_message?.text ?? '');
  if (!m) return null;
  const say = (text: string) => ({ method: 'sendMessage', chat_id: msg.from.id, text, parse_mode: 'HTML' });
  if (!(await isAdmin(msg.from.id))) return null;
  let nick: string;
  try {
    nick = robloxNick(msg.text.trim());
  } catch {
    return say('Ник Roblox: латиница, цифры и _ (3–20 символов). Нажми «➕ Новый ник бота» ещё раз.');
  }
  await tx(async (c) => {
    const { tradeBots } = await getSettings(c);
    // The first nick is the default withdrawal bot: a new one joins at the end and never pushes it out.
    if (!tradeBots.includes(nick)) await setSetting(c, 'trade_bots', [...tradeBots.slice(0, 9), nick]);
  });
  const outcome = await assignBot(Number(m[1]), msg.from.id, nick);
  if (!outcome.ok) return say(`Ник <code>${escapeHtml(nick)}</code> сохранён, но заявка #${m[1]} уже закрыта.`);
  await refreshAdminMessages(outcome.row);
  return say(`Ник <code>${escapeHtml(nick)}</code> сохранён и отправлен игроку по заявке #${m[1]}.`);
}

// ---------- Admin side (mini app) ----------

export async function adminItemDeposits(status: string | null) {
  await expireOverdue();
  const open = !status || status === 'open';
  const rows = await q<DepositRow & { username: string | null; first_name: string; last_name: string | null }>(
    `SELECT d.*, u.username, u.first_name, u.last_name FROM item_deposits d JOIN users u ON u.id = d.user_id
     WHERE ${open ? `d.status IN ('searching', 'trading', 'expired')` : `d.status IN ('credited', 'rejected', 'cancelled')`}
     ORDER BY d.id DESC LIMIT 100`,
  );
  return rows.map((r) => ({ ...view(r), user: displayName({ id: r.user_id, username: r.username, first_name: r.first_name, last_name: r.last_name }), userId: num(r.user_id), botNick: r.bot_nick }));
}

export async function adminItemDepositAction(admin: Viewer, idParam: string, body: Body) {
  const id = int(idParam, 'заявка');
  const action = body.action;
  let outcome: Outcome;
  if (action === 'credit') outcome = await creditDeposit(id, admin.id);
  else if (action === 'reject') outcome = await rejectDeposit(id, admin.id);
  else if (action === 'bot') outcome = await assignBot(id, admin.id, robloxNick(body.nick, 'ник бота'));
  else throw bad('invalid', 'Неизвестное действие');
  if (!outcome.ok) throw bad('closed', outcome.reason);
  await refreshAdminMessages(outcome.row);
  return view(outcome.row);
}
