import { one, type Queryable } from './db';
import { DEFAULT_STAR_RATE, STAR_RATE_MAX, STAR_RATE_MIN } from '../shared/stars';
import { DEFAULT_TACOS, type TacosEvent } from '../shared/tacos';
import { DEFAULT_WITHDRAW_RULES, MAX_WAGER_MULTIPLIER, type WithdrawRules } from '../shared/withdraw';
import { DEFAULT_DEPOSIT_OPEN, DEPOSIT_SECTIONS, type DepositOpen } from '../shared/deposit';
import { EVENT_IDS, eventOn, type EventId, type EventsState, type Snap } from '../shared/events';
import { tacosActive } from '../shared/tacos';
import { SKY_DEFAULT_MAX, SKY_DEFAULT_POOL, type SkyRun } from '../shared/sky';
import type { SquidGameView } from '../shared/squid';
import { SHOUT_COLORS, type Shout, type ShoutColor } from '../shared/shout';
import { OKUP_CUTS } from '../shared/cases';
import { CRYPTO_RATE_MAX, CRYPTO_RATE_MIN, DEFAULT_CRYPTO_RATE } from '../shared/crypto';

export interface Maintenance {
  enabled: boolean;
  message: string;
}

export interface Settings {
  maintenance: Maintenance;
  /** Coins credited per Telegram Star. */
  starRate: number;
  /** Coins credited per rouble of a crypto deposit (iteration 38). */
  cryptoRate: number;
  /** x2 luck event end (ms) while it runs, else null. */
  luckUntil: number | null;
  /** x4 and x8 luck (iteration 35): their end while they run, else null. */
  luck4Until: number | null;
  luck8Until: number | null;
  /** The FUSE and upgrader events (the look only): their end while they run, else null. */
  fuseEventUntil: number | null;
  upgradeEventUntil: number | null;
  /** The last «Щелчок» while its events run, else null. */
  snap: Snap | null;
  /** Roblox accounts admins send brainrot-deposit trades to, saved from the bot. */
  tradeBots: string[];
  /** Free case conditions: subscription to this channel (null = none) and a share before every opening. */
  freeGate: FreeGate;
  withdrawRules: WithdrawRules;
  /** Хэллоуин-ивент «Ночной забег». */
  /** «Raining Tacos» party event. */
  tacos: TacosEvent;
  /** Brainrot / gears deposits taking new requests. */
  depositOpen: DepositOpen;
  /** A site-wide message from an owner, shown as a banner in the app (null = none). */
  announcement: Announcement | null;
  /** «Небо Meowl» (iteration 35): the running flight (null when none) and the admin's launch settings. */
  sky: SkySettings;
  /** «Игра Кальмара» (iteration 35): the game in progress (lobby or stages), until it is settled. */
  squid: SquidGameView | null;
  /** «Анонс в игре» (iteration 37): the latest admin shout (apps show it only while it is fresh). */
  shout: Shout | null;
  /** Admins who turned immortality on for trailers (iteration 37): their room passes carry it. */
  immortal: number[];
  /** «Окуп в кейсах» (iteration 38, owners): the окуп chance of paid cases × factor until `until` (null = until switched off). */
  okupCut: OkupCut;
}

export interface OkupCut {
  /** 1 = as usual; 0.5 = drops dearer than the case half as often. */
  factor: number;
  until: number | null;
}

export interface SkySettings {
  run: SkyRun | null;
  /** The launch form: minutes, the coin cap per player, deposits only, auto-repeat every N hours (0 = off). */
  minutes: number;
  max: number;
  /** The coins of a whole run for everybody (iteration 37). */
  pool: number;
  needDeposit: boolean;
  repeatHours: number;
  /** Tell every player in the bot when a flight starts (auto-repeated ones too). */
  notify: boolean;
  /** When the last run started (ms): the tick's auto-repeat counts from it. */
  lastStartAt: number | null;
}

/** A global in-app message with the author's Telegram name and photo. */
export interface Announcement {
  text: string;
  authorName: string;
  authorPhoto: string | null;
  /** When it was posted (ms) — doubles as the id the client remembers for «dismissed». */
  at: number;
}


export interface FreeGate {
  channel: string | null;
  share: boolean;
}

export const DEFAULT_FREE_GATE: FreeGate = { channel: '@BrainrotCrash', share: true };

export type SettingKey =
  | 'top_drop_since'
  | 'maintenance'
  | 'stars'
  | 'luck'
  | 'trade_bots'
  | 'free_case_gate'
  | 'ref_settled_until'
  | 'withdraw_rules'
  | 'tacos'
  | 'deposit_open'
  | 'announcement'
  | 'fuse_event'
  | 'upgrade_event'
  | 'luck4'
  | 'luck8'
  | 'snap'
  | 'sky'
  | 'squid'
  | 'shout'
  | 'immortal'
  | 'okup_cut'
  | 'crypto';

/** Every setting as one row of columns — also folded into the profile query (`buildMe`), saving a round trip. */
export const SETTINGS_COLUMNS = `(SELECT value FROM settings WHERE key = 'maintenance') AS maintenance,
            (SELECT value FROM settings WHERE key = 'stars') AS stars,
            (SELECT value FROM settings WHERE key = 'luck') AS luck,
            (SELECT value FROM settings WHERE key = 'trade_bots') AS bots,
            (SELECT value FROM settings WHERE key = 'free_case_gate') AS gate,
            (SELECT value FROM settings WHERE key = 'withdraw_rules') AS withdraw,
            (SELECT value FROM settings WHERE key = 'tacos') AS tacos,
            (SELECT value FROM settings WHERE key = 'announcement') AS announcement,
            (SELECT value FROM settings WHERE key = 'deposit_open') AS deposit_open,
            (SELECT value FROM settings WHERE key = 'fuse_event') AS fuse_event,
            (SELECT value FROM settings WHERE key = 'upgrade_event') AS upgrade_event,
            (SELECT value FROM settings WHERE key = 'luck4') AS luck4,
            (SELECT value FROM settings WHERE key = 'luck8') AS luck8,
            (SELECT value FROM settings WHERE key = 'snap') AS snap,
            (SELECT value FROM settings WHERE key = 'sky') AS sky,
            (SELECT value FROM settings WHERE key = 'squid') AS squid,
            (SELECT value FROM settings WHERE key = 'shout') AS shout,
            (SELECT value FROM settings WHERE key = 'immortal') AS immortal,
            (SELECT value FROM settings WHERE key = 'okup_cut') AS okup_cut,
            (SELECT value FROM settings WHERE key = 'crypto') AS crypto`;

export type SettingsRow = {
  maintenance: Maintenance | null;
  stars: { rate?: unknown } | null;
  luck: { until?: unknown } | null;
  bots: unknown;
  gate: { channel?: unknown; share?: unknown } | null;
  withdraw: Partial<Record<keyof WithdrawRules, unknown>> | null;
  tacos: { enabled?: unknown; endsAt?: unknown } | null;
  announcement: { text?: unknown; authorName?: unknown; authorPhoto?: unknown; at?: unknown } | null;
  deposit_open: Partial<Record<string, unknown>> | null;
  fuse_event: { until?: unknown } | null;
  upgrade_event: { until?: unknown } | null;
  luck4: { until?: unknown } | null;
  luck8: { until?: unknown } | null;
  snap: { at?: unknown; endsAt?: unknown; events?: unknown } | null;
  sky?: Partial<Record<string, unknown>> | null;
  squid?: Partial<Record<string, unknown>> | null;
  shout?: Partial<Record<string, unknown>> | null;
  immortal?: unknown;
  okup_cut?: { factor?: unknown; until?: unknown } | null;
  crypto?: { rate?: unknown } | null;
};

export async function getSettings(db?: Queryable): Promise<Settings> {
  const sql = `SELECT ${SETTINGS_COLUMNS}`;
  const row = db ? (await db.query<SettingsRow>(sql)).rows[0] : await one<SettingsRow>(sql);
  return settingsFromRow(row);
}

export function settingsFromRow(row: SettingsRow | undefined | null): Settings {
  const rate = Number(row?.stars?.rate);
  const cryptoRate = Number(row?.crypto?.rate);
  const until = Number(row?.luck?.until);
  return {
    maintenance: { enabled: !!row?.maintenance?.enabled, message: row?.maintenance?.message ?? '' },
    starRate: Number.isFinite(rate) && rate >= STAR_RATE_MIN && rate <= STAR_RATE_MAX ? rate : DEFAULT_STAR_RATE,
    cryptoRate: Number.isFinite(cryptoRate) && cryptoRate >= CRYPTO_RATE_MIN && cryptoRate <= CRYPTO_RATE_MAX ? cryptoRate : DEFAULT_CRYPTO_RATE,
    luckUntil: Number.isFinite(until) && until > Date.now() ? until : null,
    luck4Until: untilOf(row?.luck4),
    luck8Until: untilOf(row?.luck8),
    fuseEventUntil: untilOf(row?.fuse_event),
    upgradeEventUntil: untilOf(row?.upgrade_event),
    snap: snapOf(row?.snap ?? null),
    tradeBots: Array.isArray(row?.bots) ? (row.bots as unknown[]).filter((b): b is string => typeof b === 'string') : [],
    freeGate: row?.gate
      ? { channel: typeof row.gate.channel === 'string' && row.gate.channel ? row.gate.channel : null, share: row.gate.share !== false }
      : DEFAULT_FREE_GATE,
    withdrawRules: withdrawRulesOf(row?.withdraw ?? null),
    tacos: tacosOf(row?.tacos ?? null),
    announcement: announcementOf(row?.announcement ?? null),
    depositOpen: Object.fromEntries(
      DEPOSIT_SECTIONS.map((s) => [s, row?.deposit_open && typeof row.deposit_open[s] === 'boolean' ? (row.deposit_open[s] as boolean) : DEFAULT_DEPOSIT_OPEN[s]]),
    ) as DepositOpen,
    sky: skyOf(row?.sky ?? null),
    squid: squidOf(row?.squid ?? null),
    shout: shoutOf(row?.shout ?? null),
    immortal: Array.isArray(row?.immortal) ? (row.immortal as unknown[]).map(Number).filter((n) => Number.isSafeInteger(n) && n > 0) : [],
    okupCut: okupCutOf(row?.okup_cut ?? null),
  };
}

/** A cut that has run out is no cut. */
function okupCutOf(v: { factor?: unknown; until?: unknown } | null): OkupCut {
  const factor = Number(v?.factor);
  const until = Number(v?.until);
  if (!(OKUP_CUTS as readonly number[]).includes(factor) || factor >= 1) return { factor: 1, until: null };
  if (Number.isFinite(until) && until > 0) return until > Date.now() ? { factor, until } : { factor: 1, until: null };
  return { factor, until: null };
}

function shoutOf(v: Partial<Record<string, unknown>> | null): Shout | null {
  const text = typeof v?.text === 'string' ? v.text.trim() : '';
  const at = Number(v?.at);
  if (!text || !Number.isFinite(at)) return null;
  return {
    text,
    color: SHOUT_COLORS.includes(v?.color as ShoutColor) ? (v!.color as ShoutColor) : 'accent',
    authorName: typeof v?.authorName === 'string' && v.authorName ? v.authorName : 'BrainrotCrash',
    authorPhoto: typeof v?.authorPhoto === 'string' && v.authorPhoto ? v.authorPhoto : null,
    at,
  };
}

function squidOf(v: Partial<Record<string, unknown>> | null): SquidGameView | null {
  const gameId = Number(v?.gameId);
  const lobbyUntil = Number(v?.lobbyUntil);
  if (!Number.isFinite(gameId) || gameId <= 0 || !Number.isFinite(lobbyUntil)) return null;
  return { gameId, lobbyUntil, needDeposit: v?.needDeposit !== false, prizes: Array.isArray(v?.prizes) ? (v.prizes as SquidGameView['prizes']) : [] };
}

function skyOf(v: Partial<Record<string, unknown>> | null): SkySettings {
  const num = (o: Partial<Record<string, unknown>> | null | undefined, k: string, fallback: number) => {
    const x = Number(o?.[k]);
    return Number.isFinite(x) ? x : fallback;
  };
  const r = v?.run && typeof v.run === 'object' ? (v.run as Partial<Record<string, unknown>>) : null;
  const run: SkyRun | null =
    r && num(r, 'runId', 0) > 0 && num(r, 'endsAt', 0) > Date.now()
      ? {
          runId: num(r, 'runId', 0),
          seed: num(r, 'seed', 0),
          startedAt: num(r, 'startedAt', 0),
          endsAt: num(r, 'endsAt', 0),
          max: num(r, 'max', SKY_DEFAULT_MAX),
          needDeposit: r.needDeposit !== false,
          // Runs started before iteration 37 have no pool.
          pool: r.pool === undefined || r.pool === null ? null : num(r, 'pool', SKY_DEFAULT_POOL),
        }
      : null;
  return {
    run,
    minutes: num(v, 'minutes', 30),
    max: num(v, 'max', SKY_DEFAULT_MAX),
    pool: num(v, 'pool', SKY_DEFAULT_POOL),
    needDeposit: v?.needDeposit !== false,
    repeatHours: num(v, 'repeatHours', 0),
    notify: v?.notify !== false,
    lastStartAt: num(v, 'lastStartAt', 0) || null,
  };
}

const untilOf = (v: { until?: unknown } | null | undefined) => {
  const until = Number(v?.until);
  return Number.isFinite(until) && until > Date.now() ? until : null;
};

function snapOf(v: { at?: unknown; endsAt?: unknown; events?: unknown } | null): Snap | null {
  const at = Number(v?.at);
  const endsAt = Number(v?.endsAt);
  if (!Number.isFinite(at) || !Number.isFinite(endsAt) || endsAt <= Date.now()) return null;
  const events = Array.isArray(v?.events) ? (v.events as unknown[]).filter((e): e is EventId => (EVENT_IDS as readonly unknown[]).includes(e)) : [];
  return { at, endsAt, events };
}

/** Every event's end while it runs (what the app shows). */
export function eventsOf(s: Settings, now = Date.now()): EventsState {
  return {
    cases: eventOn(s.luckUntil, now) ? s.luckUntil : null,
    luck4: eventOn(s.luck4Until, now) ? s.luck4Until : null,
    luck8: eventOn(s.luck8Until, now) ? s.luck8Until : null,
    fuse: eventOn(s.fuseEventUntil, now) ? s.fuseEventUntil : null,
    upgrade: eventOn(s.upgradeEventUntil, now) ? s.upgradeEventUntil : null,
    tacos: tacosActive(s.tacos, now) ? s.tacos.endsAt : null,
  };
}

function tacosOf(v: { enabled?: unknown; endsAt?: unknown } | null): TacosEvent {
  const endsAt = Number(v?.endsAt);
  return { enabled: v ? v.enabled === true : DEFAULT_TACOS.enabled, endsAt: Number.isFinite(endsAt) && endsAt > 0 ? endsAt : DEFAULT_TACOS.endsAt };
}

function announcementOf(v: { text?: unknown; authorName?: unknown; authorPhoto?: unknown; at?: unknown } | null): Announcement | null {
  const text = typeof v?.text === 'string' ? v.text.trim() : '';
  const at = Number(v?.at);
  if (!text || !Number.isFinite(at)) return null;
  return {
    text,
    authorName: typeof v?.authorName === 'string' && v.authorName ? v.authorName : 'BrainrotCrash',
    authorPhoto: typeof v?.authorPhoto === 'string' && v.authorPhoto ? v.authorPhoto : null,
    at,
  };
}

function withdrawRulesOf(v: Partial<Record<keyof WithdrawRules, unknown>> | null): WithdrawRules {
  const pick = (k: keyof WithdrawRules) => {
    const n = Number(v?.[k]);
    return Number.isFinite(n) && n >= 0 ? n : DEFAULT_WITHDRAW_RULES[k];
  };
  return {
    minValue: pick('minValue'),
    minItems: Math.round(pick('minItems')),
    minItemPrice: pick('minItemPrice'),
    wagerDeposit: Math.min(pick('wagerDeposit'), MAX_WAGER_MULTIPLIER),
    wagerBonus: Math.min(pick('wagerBonus'), MAX_WAGER_MULTIPLIER),
  };
}

/** The luck multiplier for case drops right now: the strongest running luck event (x8, x4, x2), else 1. */
export const luckMultiplier = (s: Pick<Settings, 'luckUntil' | 'luck4Until' | 'luck8Until'>) =>
  s.luck8Until ? 8 : s.luck4Until ? 4 : s.luckUntil ? 2 : 1;

/** The running luck the app shows (strongest first), or null. */
export function luckState(s: Pick<Settings, 'luckUntil' | 'luck4Until' | 'luck8Until'>): { x: number; until: number } | null {
  if (s.luck8Until) return { x: 8, until: s.luck8Until };
  if (s.luck4Until) return { x: 4, until: s.luck4Until };
  if (s.luckUntil) return { x: 2, until: s.luckUntil };
  return null;
}

export async function setSetting(db: Queryable, key: SettingKey, value: unknown) {
  await db.query(
    `INSERT INTO settings (key, value) VALUES ($1, $2::jsonb)
     ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value`,
    [key, JSON.stringify(value)],
  );
}
