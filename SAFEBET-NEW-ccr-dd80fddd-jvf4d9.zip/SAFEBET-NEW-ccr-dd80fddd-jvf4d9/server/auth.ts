import { TERMS_VERSION } from '../shared/legal';
import { db, ms, one } from './db';
import { env, isOwnerId } from './env';
import { HttpError } from './errors';
import { verifyInitData, type TelegramUser } from './telegram';
import { upsertTelegramUser } from './users';

export interface PunishmentView {
  id: number;
  until: number | null;
  reason: string | null;
}

export interface Viewer {
  id: number;
  isOwner: boolean;
  isAdmin: boolean;
  frozen: PunishmentView | null;
  maintenance: { enabled: boolean; message: string };
  /** Confirmed 18+ and accepted the current user agreement and privacy policy (shared/legal.ts). */
  termsOk: boolean;
}

interface GateRow {
  id: string;
  is_admin: boolean;
  terms_version: number | null;
  ban: { id: number; until: string | null; reason: string | null } | null;
  freeze: { id: number; until: string | null; reason: string | null } | null;
  maintenance: { enabled?: boolean; message?: string } | null;
}

const ACTIVE = `revoked_at IS NULL AND (until IS NULL OR until > now())`;

async function loadGate(id: number) {
  return one<GateRow>(
    `SELECT u.id, u.terms_version,
       EXISTS (SELECT 1 FROM admins a WHERE a.user_id = u.id) AS is_admin,
       (SELECT json_build_object('id', p.id, 'until', p.until, 'reason', p.reason) FROM punishments p
         WHERE p.user_id = u.id AND p.kind = 'ban' AND ${ACTIVE} ORDER BY p.until DESC NULLS FIRST LIMIT 1) AS ban,
       (SELECT json_build_object('id', p.id, 'until', p.until, 'reason', p.reason) FROM punishments p
         WHERE p.user_id = u.id AND p.kind = 'freeze' AND ${ACTIVE} ORDER BY p.until DESC NULLS FIRST LIMIT 1) AS freeze,
       (SELECT value FROM settings WHERE key = 'maintenance') AS maintenance
     FROM users u WHERE u.id = $1`,
    [id],
  );
}

const view = (p: GateRow['ban']): PunishmentView | null => (p ? { id: Number(p.id), until: ms(p.until), reason: p.reason } : null);

/** Every request carries Telegram's signed initData; nothing about the player is trusted from the client otherwise. */
export async function authenticate(req: Request, opts: { refreshProfile: boolean }): Promise<Viewer> {
  const header = req.headers.get('authorization') ?? '';
  const initData = header.startsWith('tma ') ? header.slice(4) : '';
  if (!initData) throw new HttpError(401, 'unauthorized', 'Открой приложение через Telegram');
  const token = env('BOT_TOKEN');
  if (!token) throw new HttpError(500, 'not_configured', 'Сервер не настроен');
  const tg = verifyInitData(initData, token);
  if (!tg) throw new HttpError(401, 'unauthorized', 'Сессия Telegram устарела — перезапусти приложение');
  return viewerOf(tg, opts.refreshProfile);
}

/**
 * The player behind a verified Telegram identity, through the same gates for the mini app (initData) and the bot
 * (an update's `from`, vouched for by Telegram via the webhook secret): ban, maintenance and freeze.
 */
export async function viewerOf(tg: TelegramUser, refreshProfile = false): Promise<Viewer> {
  if (refreshProfile) await upsertTelegramUser(db, tg);
  let gate = await loadGate(tg.id);
  if (!gate) {
    await upsertTelegramUser(db, tg);
    gate = await loadGate(tg.id);
  }
  if (!gate) throw new HttpError(500, 'user_missing', 'Не удалось создать профиль');

  const isOwner = isOwnerId(tg.id);
  const isAdmin = isOwner || gate.is_admin;
  const ban = view(gate.ban);
  if (ban && !isOwner) {
    throw new HttpError(403, 'banned', 'Аккаунт заблокирован', { until: ban.until, reason: ban.reason });
  }
  const maintenance = { enabled: !!gate.maintenance?.enabled, message: gate.maintenance?.message ?? '' };
  if (maintenance.enabled && !isAdmin) {
    throw new HttpError(503, 'maintenance', 'Технические работы', { message: maintenance.message });
  }
  return { id: tg.id, isOwner, isAdmin, frozen: isOwner ? null : view(gate.freeze), maintenance, termsOk: (gate.terms_version ?? 0) >= TERMS_VERSION };
}

export function assertActive(v: Viewer) {
  // 18+: no playing, depositing or withdrawing before the player has confirmed their age and accepted the documents.
  if (!v.termsOk) throw new HttpError(403, 'terms_required', 'Подтверди, что тебе есть 18, и прими соглашение — открой приложение');
  if (v.frozen) {
    throw new HttpError(403, 'frozen', 'Аккаунт заморожен — можно только смотреть', { until: v.frozen.until, reason: v.frozen.reason });
  }
}
