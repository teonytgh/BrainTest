-- Iteration 28: «Мины» on brainrot stakes; the events and «Щелчок» live in settings (fuse_event, upgrade_event, snap).

-- Every player's next mines key: its sha256 is shown before the stake, the key itself when the round ends. The mines
-- are the first m places of a Fisher–Yates shuffle of tiles 0…24 drawn from sha256('mines:' || key || ':' || i).
CREATE TABLE mines_seeds (
  user_id BIGINT PRIMARY KEY REFERENCES users (id),
  seed TEXT NOT NULL,
  hash TEXT NOT NULL,
  nonce INT NOT NULL DEFAULT 0
);

-- One round per stake; the stake brainrots are out of the inventory while it is active. The field (mines_at) never
-- leaves the server before the round ends.
CREATE TABLE mines_runs (
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT NOT NULL REFERENCES users (id),
  mines INT NOT NULL CHECK (mines BETWEEN 1 AND 24),
  stake_value NUMERIC(16, 2) NOT NULL CHECK (stake_value > 0),
  stake JSONB NOT NULL,
  seed TEXT NOT NULL,
  hash TEXT NOT NULL,
  mines_at INT[] NOT NULL,
  picks INT[] NOT NULL DEFAULT '{}',
  bust INT,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'cashed', 'busted', 'refunded')),
  payout JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  finished_at TIMESTAMPTZ
);
CREATE UNIQUE INDEX mines_runs_one_active ON mines_runs (user_id) WHERE status = 'active';
CREATE INDEX mines_runs_stale ON mines_runs (updated_at) WHERE status = 'active';
CREATE INDEX drops_mines_top ON drops (payout_value DESC) WHERE game = 'mines';

DO $$
DECLARE t TEXT;
BEGIN
  FOREACH t IN ARRAY ARRAY['mines_seeds', 'mines_runs'] LOOP
    EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', t);
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'anon') THEN
      EXECUTE format('REVOKE ALL ON %I FROM anon, authenticated', t);
    END IF;
  END LOOP;
END $$;
