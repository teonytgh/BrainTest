import { createStore, useStore } from './createStore';

/**
 * Режим стримера (iteration 33): hides the streamer's own private things on screen — balance and history, the
 * deposit / withdrawal buttons (which also stop taking taps, so a blurred button isn't hit blind on air), their own
 * stakes and the account data. Kept on this device (localStorage) and applied as attributes on <html>, which
 * src/styles/streamer.css turns into a blur. It never hides the games themselves from viewers.
 */
export type StreamerPart = 'balance' | 'money' | 'stakes' | 'account';
export type BlurLevel = 'low' | 'mid' | 'high';

export interface StreamerState {
  on: boolean;
  parts: Record<StreamerPart, boolean>;
  blur: BlurLevel;
  /** A hover un-blurs (on a PC the cursor is the streamer's, and it isn't in the picture). */
  reveal: boolean;
}

export const STREAMER_PARTS: { id: StreamerPart; title: string; text: string }[] = [
  { id: 'balance', title: 'Баланс и история', text: 'Баланс, реферальный баланс, сумма инвентаря, статистика и история игр.' },
  { id: 'money', title: 'Пополнение и вывод', text: 'Кнопки пополнения и вывода. Пока режим включён, они ещё и не нажимаются — размытую кнопку легко задеть в эфире.' },
  { id: 'stakes', title: 'Свои ставки', text: 'Сумма твоей ставки в апгрейдере, минах, дороге и FUSE.' },
  { id: 'account', title: 'Аккаунт', text: 'Твой ID профиля и @username — чтобы зрители не нашли и не писали тебе.' },
];

const KEY = 'brainrotcrash:streamer';
const DEFAULT: StreamerState = { on: false, parts: { balance: true, money: true, stakes: true, account: true }, blur: 'mid', reveal: true };

function read(): StreamerState {
  try {
    const raw = JSON.parse(localStorage.getItem(KEY) ?? 'null') as Partial<StreamerState> | null;
    if (!raw) return DEFAULT;
    return {
      on: raw.on === true,
      parts: { ...DEFAULT.parts, ...(raw.parts ?? {}) },
      blur: raw.blur === 'low' || raw.blur === 'high' ? raw.blur : 'mid',
      reveal: raw.reveal !== false,
    };
  } catch {
    return DEFAULT;
  }
}

const store = createStore<StreamerState>(read());

function apply(s: StreamerState) {
  const root = document.documentElement;
  const parts = (Object.keys(s.parts) as StreamerPart[]).filter((p) => s.parts[p]);
  if (s.on && parts.length) root.dataset.streamer = parts.join(' ');
  else delete root.dataset.streamer;
  root.dataset.smBlur = s.blur;
  if (s.on && s.reveal) root.dataset.smReveal = '';
  else delete root.dataset.smReveal;
}

if (typeof document !== 'undefined') apply(store.get());

export function setStreamer(update: (s: StreamerState) => StreamerState) {
  store.set(update);
  const next = store.get();
  apply(next);
  try {
    localStorage.setItem(KEY, JSON.stringify(next));
  } catch {
    // Works for this session only.
  }
}

export const useStreamer = () => useStore(store);
