import { useState } from 'react';
import { useCatalog } from '../../api/queries';
import { cx, formatCoins } from '../../lib/format';
import { Card, formatWhen, useAdminQuery, type Data } from './ui';
import type * as AuditApi from '../../../server/audit';

type Audit = Data<typeof AuditApi.playerAudit>;

const GAME: Record<string, string> = {
  case: 'Кейсы',
  battle: 'Батлы',
  upgrade: 'Апгрейдер',
  dice: 'Дайсы',
  crash: 'Краш',
  mines: 'Мины',
  road: 'Дорога',
  fuse: 'FUSE',
  halloween: 'Забег',
  trick: 'Сладость или гадость',
  pumpkins: 'Тыквы',
};

const SOURCE: Record<string, string> = {
  admin: 'выдал админ',
  upgrade: 'апгрейдер',
  dice: 'дайсы',
  crash: 'краш',
  mines: 'мины',
  road: 'дорога',
  fuse: 'FUSE',
  shop: 'магазин',
  promo: 'промокод',
  giveaway: 'розыгрыш',
  squid: 'Игра Кальмара',
  exchange: 'обмен при выводе',
  deposit: 'пополнение брейнротами',
  mines_refund: 'возврат мин',
  road_refund: 'возврат дороги',
};

/**
 * «Откуда инвентарь» (iteration 38, owners): one tap on the player card shows where their coins and brainrots came
 * from — what the games paid back for what was staked, free openings by case, other bonuses, admin gifts, the inventory
 * by source and the friends they brought (accounts with no deposit and no play stand out).
 */
export function AuditBlock({ userId }: { userId: number }) {
  const [open, setOpen] = useState(false);
  const audit = useAdminQuery<Audit>(['audit', userId], `/users/${userId}/audit`, open);
  if (!open) {
    return (
      <button type="button" className="btn btn--ghost btn--sm btn--block" onClick={() => setOpen(true)}>
        Откуда инвентарь — проверить игрока
      </button>
    );
  }
  if (!audit.data) return <p className="acard__text">{audit.isError ? 'Не удалось загрузить проверку' : 'Считаем…'}</p>;
  return <AuditView a={audit.data} />;
}

function AuditView({ a }: { a: Audit }) {
  const catalog = useCatalog();
  const caseName = (id: string | null) => (id ? (catalog.caseById.get(id)?.name ?? id) : '');
  const sourceName = (s: string) =>
    s.startsWith('case:') ? `кейс «${caseName(s.slice(5))}»` : s.startsWith('battle:') ? 'батл' : s.startsWith('rank:') ? 'подарок ранга' : s.startsWith('pass:') ? 'батл пасс' : (SOURCE[s] ?? s);
  const m = a.money;
  const holds = m.balance - m.demoBalance + m.refBalance + m.inventoryValue;
  const net = holds + m.withdrawn - m.deposited;
  const gamesNet = a.games.reduce((s, g) => s + g.won - g.staked, 0);
  const freeTotal = a.free.reduce((s, f) => s + f.won, 0);
  const o = a.other;
  return (
    <Card title={`Откуда инвентарь · ${a.user.name}`} className="aaudit">
      <dl className="adl">
        <div>
          <dt>Пополнил (звёзды + брейнроты)</dt>
          <dd>{formatCoins(m.deposited)} B</dd>
        </div>
        <div>
          <dt>Вывел</dt>
          <dd>{formatCoins(m.withdrawn)} B</dd>
        </div>
        <div>
          <dt>На руках сейчас</dt>
          <dd>
            {formatCoins(holds)} B
            <small className="aaudit__sub">
              монеты {formatCoins(m.balance - m.demoBalance)} · инвентарь {formatCoins(m.inventoryValue)} · реф. {formatCoins(m.refBalance)}
            </small>
          </dd>
        </div>
        <div className={cx(net > 0 ? 'is-bad' : 'is-good')}>
          <dt>Сверх пополнений</dt>
          <dd>{(net > 0 ? '+' : '') + formatCoins(net)} B</dd>
        </div>
      </dl>
      {m.demoBalance + m.demoInventoryValue > 0 && (
        <p className="acard__text">
          Ещё демо (не выводится): {formatCoins(m.demoBalance)} B монет и брейнротов на {formatCoins(m.demoInventoryValue)} B.
        </p>
      )}

      <h4 className="aaudit__h">Игры на свои ставки · итог {(gamesNet > 0 ? '+' : '') + formatCoins(gamesNet)} B</h4>
      {a.games.length ? (
        <ul className="aaudit__rows">
          {a.games.map((g) => (
            <li key={g.game}>
              <span>
                {GAME[g.game] ?? g.game} <small>×{g.count}</small>
              </span>
              <span>
                {formatCoins(g.staked)} → {formatCoins(g.won)} B <b className={g.won > g.staked ? 'is-bad' : 'is-good'}>{g.staked ? `${Math.round((g.won / g.staked) * 100)}%` : '—'}</b>
              </span>
            </li>
          ))}
        </ul>
      ) : (
        <p className="acard__text">Своих ставок не было.</p>
      )}

      <h4 className="aaudit__h">Бесплатно (без ставки) · {formatCoins(freeTotal)} B</h4>
      {a.free.length ? (
        <ul className="aaudit__rows">
          {a.free.map((f) => (
            <li key={`${f.game}:${f.caseId}`}>
              <span>
                {f.caseId ? `Кейс «${caseName(f.caseId)}»` : (GAME[f.game] ?? f.game)} <small>×{f.count}</small>
              </span>
              <span>
                {formatCoins(f.won)} B <small>лучший {formatCoins(f.best)}</small>
              </span>
            </li>
          ))}
        </ul>
      ) : (
        <p className="acard__text">Ничего.</p>
      )}
      <ul className="aaudit__rows">
        <li>
          <span>Реферальные выплаты</span>
          <span>{formatCoins(o.refPaid)} B</span>
        </li>
        <li>
          <span>Кэшбэк · утешительные</span>
          <span>
            {formatCoins(o.cashback)} · {formatCoins(o.consolation)} B
          </span>
        </li>
        <li>
          <span>Небо Meowl · батл пасс · ранги</span>
          <span>
            {formatCoins(o.sky)} · {formatCoins(o.pass)} · {formatCoins(o.rankGifts)} B
          </span>
        </li>
        <li>
          <span>Призы розыгрышей · Кальмара</span>
          <span>
            {o.giveaways} · {o.squid}
          </span>
        </li>
      </ul>

      <h4 className="aaudit__h">Выдачи админов</h4>
      {a.gifts.length ? (
        <ul className="aaudit__rows">
          {a.gifts.map((g, i) => (
            <li key={i}>
              <span>
                {g.admin} <small>{formatWhen(g.at)}</small>
              </span>
              <span>{giftText(g.action, g.details, (id) => catalog.byId.get(id)?.name ?? id, caseName)}</span>
            </li>
          ))}
        </ul>
      ) : (
        <p className="acard__text">Админы ему ничего не выдавали.</p>
      )}

      <h4 className="aaudit__h">Инвентарь по источникам</h4>
      <ul className="aaudit__rows">
        {a.inventory.map((r) => (
          <li key={`${r.source}:${r.demo}`}>
            <span>
              {sourceName(r.source)} {r.demo && <small>демо</small>} <small>×{r.count}</small>
            </span>
            <span>{formatCoins(r.value)} B</span>
          </li>
        ))}
      </ul>

      <h4 className="aaudit__h">Самые дорогие дропы</h4>
      <ul className="aaudit__rows">
        {a.top.map((t, i) => (
          <li key={i}>
            <span>
              {t.brainrotId ? (catalog.byId.get(t.brainrotId)?.name ?? t.brainrotId) : 'монеты'} <small>{formatWhen(t.at)}</small>
            </span>
            <span>
              {formatCoins(t.value)} B{' '}
              <small>
                {t.caseId ? `кейс «${caseName(t.caseId)}»` : (GAME[t.game] ?? t.game)} · ставка {formatCoins(t.stake)}
              </small>
            </span>
          </li>
        ))}
      </ul>

      <h4 className="aaudit__h">
        Друзья по его ссылке · {a.friends.count}
        {a.friends.count > 0 && ` · пополняли ${a.friends.deposited} · пустых ${a.friends.empty}`}
      </h4>
      {a.friends.count > 0 && (
        <>
          {a.friends.empty >= 3 && a.friends.empty * 2 >= a.friends.count && (
            <p className="acard__text aaudit__warn">
              Больше половины друзей ни разу не пополняли и не играли — похоже на твинков ради реферального кейса. Их реферальные кейсы дали {formatCoins(a.friends.refCaseValue)} B.
            </p>
          )}
          <ul className="aaudit__rows">
            {a.friends.list.map((f) => (
              <li key={f.id} className={cx(f.deposited === 0 && f.staked === 0 && 'is-empty')}>
                <span>
                  {f.name} <small>{formatWhen(f.at)}</small>
                </span>
                <span>
                  {f.deposited ? `пополнил ${formatCoins(f.deposited)}` : 'без пополнений'} · ставок {formatCoins(f.staked)}
                </span>
              </li>
            ))}
          </ul>
        </>
      )}
    </Card>
  );
}

function giftText(action: string, d: Record<string, unknown>, brainrot: (id: string) => string, kase: (id: string) => string): string {
  const demo = d.demo ? ' (демо)' : '';
  if (action === 'give_coins') return `${formatCoins(Number(d.amount) || 0)} B${demo}${d.noWager ? ' без отыгрыша' : ''}`;
  if (action === 'give_brainrot') return `${brainrot(String(d.brainrotId))}${Number(d.count) > 1 ? ` ×${d.count}` : ''}${demo}`;
  if (action === 'give_case') return `кейс «${kase(String(d.id))}»${Number(d.count) > 1 ? ` ×${d.count}` : ''}${demo}`;
  if (action === 'wager_clear') return 'снял отыгрыш';
  return action;
}
