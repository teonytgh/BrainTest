/**
 * The 18+ consent: on first open the player confirms being 18 or older and accepts the user agreement and the privacy
 * policy (texts in src/lib/legalDocs.ts, shown at #/terms and #/privacy). The server stores the accepted version
 * (`users.terms_version`) and refuses to play, deposit or withdraw without it (`terms_required`, in assertActive).
 * Changing the documents in a way players must agree to again = bumping TERMS_VERSION.
 */
/** 2 (iteration 36): the wagering before a withdrawal («отыгрыш») was added to the agreement. */
export const TERMS_VERSION = 2;
export const MIN_AGE = 18;
