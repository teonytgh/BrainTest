import type { Viewer } from './auth';
import { ensureSchema } from './autoMigrate';
import { healCases } from './caseHealth';
import { ms, num, q, tx, type Queryable } from './db';
import { bad, notFound } from './errors';
import { bool, int, str, type Body } from './validate';

/**
 * «Конфиги кейсов» (iteration 33): an admin saves everything about the cases under a name — every case (price, price
 * in tickets, kind, status, theme, order, mystery), the compositions with their hand-set chances, the home themes, the
 * coin prizes and the brainrot prices — and can load any of them back later («шансы поменял, не зашло — вернул»).
 *
 * Loading first saves what it is about to replace as an automatic copy, so a load can be undone too. Cases missing
 * from the config are hidden, not deleted (keys, battles and the history point at them). Brainrot prices come back
 * only when asked: they also move the upgrader, withdrawals and every inventory's value. Brainrots deleted since the
 * save are skipped (and counted). Everything runs as a few set-based statements straight from the stored JSON. Then the
 * healer runs, as after any admin save: a case that no longer fits today's prices is completed at once instead of
 * refusing to open until the next tick (it only adds, and skips hand-set chances).
 */

const MAX_CONFIGS = 60;
const MAX_AUTO = 10;

/** The whole current state as one JSON value (SQL), for INSERT … SELECT. */
const SNAPSHOT_SQL = `json_build_object(
  'cases', (SELECT coalesce(json_agg(row_to_json(c) ORDER BY c.sort, c.id), '[]'::json)
    FROM (SELECT id, name, price, image, kind, status, sort, mystery, bonus, section_id, ticket_price FROM cases) c),
  'items', (SELECT coalesce(json_agg(row_to_json(i) ORDER BY i.case_id, i.brainrot_id), '[]'::json)
    FROM (SELECT case_id, brainrot_id, weight, fixed_chance FROM case_items) i),
  'sections', (SELECT coalesce(json_agg(row_to_json(s) ORDER BY s.sort, s.id), '[]'::json)
    FROM (SELECT id, title, sort FROM case_sections) s),
  'coins', (SELECT coalesce(json_agg(row_to_json(b) ORDER BY b.price), '[]'::json)
    FROM (SELECT id, name, price, image, status FROM brainrots WHERE kind = 'coins' AND status <> 'deleted') b),
  'prices', (SELECT coalesce(json_agg(json_build_object('id', id, 'price', price)), '[]'::json)
    FROM brainrots WHERE kind = 'brainrot' AND status <> 'deleted')
)::jsonb`;

async function snapshot(c: Queryable, name: string, auto: boolean, adminId: number): Promise<number> {
  const { rows } = await c.query<{ id: string }>(`INSERT INTO case_configs (name, data, auto, created_by) SELECT $1, ${SNAPSHOT_SQL}, $2, $3 RETURNING id`, [
    name,
    auto,
    adminId,
  ]);
  // Only the newest automatic copies are kept.
  await c.query(`DELETE FROM case_configs WHERE auto AND id NOT IN (SELECT id FROM case_configs WHERE auto ORDER BY id DESC LIMIT ${MAX_AUTO})`);
  return num(rows[0]!.id);
}

export async function listCaseConfigs() {
  await ensureSchema();
  const rows = await q<{ id: string; name: string; auto: boolean; created_at: string; author: string | null; cases: string; items: string; sections: string }>(
    `SELECT cc.id, cc.name, cc.auto, cc.created_at, u.first_name AS author,
       jsonb_array_length(cc.data->'cases') AS cases, jsonb_array_length(cc.data->'items') AS items, jsonb_array_length(cc.data->'sections') AS sections
     FROM case_configs cc LEFT JOIN users u ON u.id = cc.created_by
     ORDER BY cc.auto, cc.id DESC`,
  );
  return rows.map((r) => ({
    id: num(r.id),
    name: r.name,
    auto: r.auto,
    at: ms(r.created_at),
    author: r.author,
    cases: num(r.cases),
    items: num(r.items),
    sections: num(r.sections),
  }));
}

export async function saveCaseConfig(admin: Viewer, body: Body) {
  await ensureSchema();
  const name = str(body.name, 'название', 1, 60);
  const id = await tx(async (c) => {
    const { rows } = await c.query<{ n: string }>('SELECT count(*) AS n FROM case_configs WHERE NOT auto');
    if (num(rows[0]?.n) >= MAX_CONFIGS) throw bad('too_many', `Конфигов уже ${MAX_CONFIGS} — удали ненужные`);
    const saved = await snapshot(c, name, false, admin.id);
    await log(c, admin, 'case_config_save', { id: saved, name });
    return saved;
  });
  return { id, configs: await listCaseConfigs() };
}

export async function deleteCaseConfig(admin: Viewer, idParam: string) {
  await ensureSchema();
  const id = int(idParam, 'конфиг');
  await tx(async (c) => {
    const { rows } = await c.query<{ name: string }>('DELETE FROM case_configs WHERE id = $1 RETURNING name', [id]);
    if (!rows[0]) throw notFound('Конфиг не найден');
    await log(c, admin, 'case_config_delete', { id, name: rows[0].name });
  });
  return { configs: await listCaseConfigs() };
}

export async function loadCaseConfig(admin: Viewer, idParam: string, body: Body) {
  await ensureSchema();
  const id = int(idParam, 'конфиг');
  const withPrices = bool(body.prices);
  const result = await tx(async (c) => {
    // The healer's lock: a load and a heal never rewrite the compositions at the same time.
    await c.query('SELECT pg_advisory_xact_lock(4207011)');
    const cfg = (await c.query<{ name: string }>('SELECT name FROM case_configs WHERE id = $1', [id])).rows[0];
    if (!cfg) throw notFound('Конфиг не найден');
    const backup = await snapshot(c, `Автокопия перед «${cfg.name}»`.slice(0, 60), true, admin.id);

    await c.query(
      `INSERT INTO case_sections (id, title, sort)
       SELECT s.id, s.title, s.sort FROM case_configs cc, jsonb_to_recordset(cc.data->'sections') AS s(id bigint, title text, sort int)
       WHERE cc.id = $1
       ON CONFLICT (id) DO UPDATE SET title = EXCLUDED.title, sort = EXCLUDED.sort`,
      [id],
    );
    await c.query(`SELECT setval('case_sections_id_seq', greatest(1, (SELECT max(id) FROM case_sections)))`);
    await c.query(
      `INSERT INTO brainrots (id, name, price, image, status, withdrawable, kind)
       SELECT b.id, b.name, b.price, b.image, b.status, FALSE, 'coins'
       FROM case_configs cc, jsonb_to_recordset(cc.data->'coins') AS b(id text, name text, price numeric, image text, status text)
       WHERE cc.id = $1
       ON CONFLICT (id) DO UPDATE SET name = EXCLUDED.name, price = EXCLUDED.price, image = EXCLUDED.image, status = EXCLUDED.status, updated_at = now()
       WHERE brainrots.kind = 'coins'`,
      [id],
    );
    let prices = 0;
    if (withPrices) {
      const r = await c.query(
        `UPDATE brainrots b SET price = p.price, updated_at = now()
         FROM case_configs cc, jsonb_to_recordset(cc.data->'prices') AS p(id text, price numeric)
         WHERE cc.id = $1 AND b.id = p.id AND b.kind = 'brainrot' AND b.status <> 'deleted' AND b.price <> p.price`,
        [id],
      );
      prices = r.rowCount ?? 0;
    }
    const cases = await c.query(
      `INSERT INTO cases (id, name, price, image, kind, status, sort, mystery, bonus, section_id, ticket_price)
       SELECT x.id, x.name, x.price, x.image, x.kind, x.status, x.sort, x.mystery, x.bonus,
         (SELECT s.id FROM case_sections s WHERE s.id = x.section_id), x.ticket_price
       FROM case_configs cc, jsonb_to_recordset(cc.data->'cases')
         AS x(id text, name text, price numeric, image text, kind text, status text, sort int, mystery boolean, bonus text, section_id bigint, ticket_price int)
       WHERE cc.id = $1
       ON CONFLICT (id) DO UPDATE SET name = EXCLUDED.name, price = EXCLUDED.price, image = EXCLUDED.image, kind = EXCLUDED.kind,
         status = EXCLUDED.status, sort = EXCLUDED.sort, mystery = EXCLUDED.mystery, bonus = EXCLUDED.bonus,
         section_id = EXCLUDED.section_id, ticket_price = EXCLUDED.ticket_price`,
      [id],
    );
    // Cases made after the save: hidden, not deleted.
    const hidden = await c.query(
      `UPDATE cases SET status = 'hidden'
       WHERE status <> 'hidden' AND id NOT IN (SELECT x.id FROM case_configs cc, jsonb_to_recordset(cc.data->'cases') AS x(id text) WHERE cc.id = $1)`,
      [id],
    );
    await c.query(
      `DELETE FROM case_items WHERE case_id IN (SELECT x.id FROM case_configs cc, jsonb_to_recordset(cc.data->'cases') AS x(id text) WHERE cc.id = $1)`,
      [id],
    );
    const items = await c.query(
      `INSERT INTO case_items (case_id, brainrot_id, weight, fixed_chance)
       SELECT i.case_id, i.brainrot_id, greatest(1, coalesce(i.weight, 1)), i.fixed_chance
       FROM case_configs cc, jsonb_to_recordset(cc.data->'items') AS i(case_id text, brainrot_id text, weight int, fixed_chance numeric)
       WHERE cc.id = $1 AND EXISTS (SELECT 1 FROM brainrots b WHERE b.id = i.brainrot_id AND b.status <> 'deleted')
       ON CONFLICT DO NOTHING`,
      [id],
    );
    const total = await c.query<{ n: string }>(`SELECT jsonb_array_length(data->'items') AS n FROM case_configs WHERE id = $1`, [id]);
    const out = {
      name: cfg.name,
      backup,
      cases: cases.rowCount ?? 0,
      hidden: hidden.rowCount ?? 0,
      items: items.rowCount ?? 0,
      skipped: num(total.rows[0]?.n) - (items.rowCount ?? 0),
      prices,
    };
    await log(c, admin, 'case_config_load', { id, ...out });
    return out;
  });
  const healed = await healCases({ adminId: admin.id });
  return { ...result, healed, configs: await listCaseConfigs() };
}

async function log(c: Queryable, admin: Viewer, action: string, details: Record<string, unknown>) {
  await c.query('INSERT INTO admin_log (admin_id, action, target_user, details) VALUES ($1, $2, NULL, $3::jsonb)', [admin.id, action, JSON.stringify(details)]);
}
