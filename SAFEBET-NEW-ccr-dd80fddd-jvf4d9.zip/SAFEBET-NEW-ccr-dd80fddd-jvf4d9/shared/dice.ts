import { secureRandom, type Rng } from './random';

export const DICE_COLORS = [
  { id: 'red', label: 'Красный' },
  { id: 'orange', label: 'Оранжевый' },
  { id: 'yellow', label: 'Жёлтый' },
  { id: 'green', label: 'Зелёный' },
  { id: 'blue', label: 'Синий' },
  { id: 'purple', label: 'Фиолетовый' },
] as const;

export type DiceColorId = (typeof DICE_COLORS)[number]['id'];

export const DICE_COUNT = 4;

export function rollDice(rng: Rng = secureRandom): DiceColorId[] {
  return Array.from({ length: DICE_COUNT }, () => DICE_COLORS[Math.floor(rng() * DICE_COLORS.length)]!.id);
}

export function countMatches(roll: readonly DiceColorId[], color: DiceColorId): number {
  return roll.filter((c) => c === color).length;
}

/** 1 match → x2, all 4 → x3, anything else loses. */
export function diceMultiplier(matches: number): number {
  if (matches === 1) return 2;
  if (matches === DICE_COUNT) return 3;
  return 0;
}

export const DICE_RULES = Array.from({ length: DICE_COUNT + 1 }, (_, matches) => ({
  matches,
  multiplier: diceMultiplier(matches),
}));
