import { cx } from '../lib/format';

/**
 * «ДЕМО» on a brainrot, a balance or a game result (iteration 35): an admin's demo gift or what it won. It plays like
 * any other but is never withdrawn, exchanged, put in a battle or spent on a promo code — and viewers can see that.
 */
export function DemoTag({ corner, className }: { corner?: boolean; className?: string }) {
  return (
    <span className={cx('demo-tag', corner && 'demo-tag--corner', className)} title="Выдано для демо: играть можно, вывести нельзя">
      ДЕМО
    </span>
  );
}
