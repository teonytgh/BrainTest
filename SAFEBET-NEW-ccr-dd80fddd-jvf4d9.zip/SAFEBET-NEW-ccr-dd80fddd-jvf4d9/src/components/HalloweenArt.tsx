import { cx } from '../lib/format';

/* Halloween event art: pumpkins, ghosts, bats and the night scene. Plain SVG + CSS (src/styles/halloween.css). */

/** Gradients shared by every pumpkin and ghost on the page (one copy for all of them). */
export function PumpkinDefs() {
  return (
    <svg className="pk-defs" width="0" height="0" aria-hidden="true" focusable="false">
      <defs>
        <radialGradient id="pk-body" cx="38%" cy="32%" r="75%">
          <stop offset="0" style={{ stopColor: 'var(--pk-orange)' }} />
          <stop offset="0.65" style={{ stopColor: 'var(--pk-orange-deep)' }} />
          <stop offset="1" style={{ stopColor: 'var(--pk-orange-dark)' }} />
        </radialGradient>
        <radialGradient id="pk-rib" cx="50%" cy="35%" r="80%">
          <stop offset="0" style={{ stopColor: 'var(--pk-orange-deep)' }} />
          <stop offset="1" style={{ stopColor: 'var(--pk-orange-dark)' }} />
        </radialGradient>
        <linearGradient id="pk-stem" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" style={{ stopColor: 'var(--pk-leaf)' }} />
          <stop offset="1" style={{ stopColor: 'var(--pk-stem)' }} />
        </linearGradient>
        <radialGradient id="pk-fire" cx="50%" cy="55%" r="60%">
          <stop offset="0" style={{ stopColor: '#fff8d6' }} />
          <stop offset="0.45" style={{ stopColor: 'var(--pk-glow)' }} />
          <stop offset="1" style={{ stopColor: 'var(--pk-orange)' }} />
        </radialGradient>
        <linearGradient id="pk-ghost" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" style={{ stopColor: 'var(--pk-ghost)' }} />
          <stop offset="1" style={{ stopColor: 'var(--pk-ghost-shade)' }} />
        </linearGradient>
        <clipPath id="pk-half-l">
          <path d="M0 0H52L46 40 54 58 44 76 50 100H0z" />
        </clipPath>
        <clipPath id="pk-half-r">
          <path d="M52 0H100V100H50L44 76 54 58 46 40z" />
        </clipPath>
      </defs>
    </svg>
  );
}

function PumpkinBody() {
  return (
    <>
      <ellipse cx="29" cy="62" rx="21" ry="27" fill="url(#pk-rib)" />
      <ellipse cx="71" cy="62" rx="21" ry="27" fill="url(#pk-rib)" />
      <ellipse cx="40" cy="62" rx="20" ry="29" fill="url(#pk-body)" />
      <ellipse cx="60" cy="62" rx="20" ry="29" fill="url(#pk-body)" />
      <ellipse cx="50" cy="62" rx="14" ry="30" fill="url(#pk-body)" />
      <ellipse className="pk-art__shine" cx="38" cy="46" rx="7" ry="4.5" />
    </>
  );
}

/** A ribbed pumpkin; `lit` carves the face and lights the candle inside. It splits in two when a ghost bursts out. */
export function PumpkinArt({ lit }: { lit: boolean }) {
  return (
    <svg className="pk-art" viewBox="0 0 100 100" aria-hidden="true">
      <ellipse className="pk-art__shadow" cx="50" cy="92" rx="32" ry="5" />
      <g className="pk-art__half pk-art__half--l" clipPath="url(#pk-half-l)">
        <PumpkinBody />
      </g>
      <g className="pk-art__half pk-art__half--r" clipPath="url(#pk-half-r)">
        <PumpkinBody />
      </g>
      {lit && (
        <g className="pk-art__face">
          <path d="M30 55l9-11 7 12z" />
          <path d="M70 55l-9-11-7 12z" />
          <path d="M46.5 62l3.5-6 3.5 6z" />
          <path d="M27 68c9 11 37 11 46 0l-5 9-5-4-5 6-4-5-4 5-5-6-4 5-5-6-4 4z" />
        </g>
      )}
      <g className="pk-art__lid">
        <path d="M46 35c-1-8 2-14 8-17l4 3.5c-4 3-5.5 7-4.5 13.5z" fill="url(#pk-stem)" />
        <path d="M56 24c5-7 14-7 18-2-5-1-10 0-14 5z" fill="var(--pk-leaf)" />
        <path className="pk-art__vine" d="M47 30c-6-2-9 1-8 5 1 3 5 2 4-1" />
      </g>
    </svg>
  );
}

export function GhostArt({ className }: { className?: string }) {
  return (
    <svg className={cx('pk-ghost', className)} viewBox="0 0 100 100" aria-hidden="true">
      <path d="M20 58c-8 1-13-3-15-9 6 3 11 3 15 0zM80 58c8 1 13-3 15-9-6 3-11 3-15 0z" fill="url(#pk-ghost)" />
      <path d="M22 94V46a28 28 0 0 1 56 0v48l-9-7-9 7-10-7-10 7-9-7z" fill="url(#pk-ghost)" />
      <ellipse cx="39" cy="46" rx="5.5" ry="7.5" fill="var(--pk-ink)" />
      <ellipse cx="61" cy="46" rx="5.5" ry="7.5" fill="var(--pk-ink)" />
      <ellipse cx="50" cy="66" rx="6.5" ry="9" fill="var(--pk-ink)" />
    </svg>
  );
}

export function Bat() {
  return (
    <span className="pk-bat">
      <svg viewBox="0 0 60 30" aria-hidden="true">
        <path className="pk-bat__wing pk-bat__wing--l" d="M28 15C23 5 12 3 2 9c6 0 8 4 7 8 4-3 8-2 10 2 2-4 6-4 9-1z" />
        <path className="pk-bat__wing pk-bat__wing--r" d="M32 15c5-10 16-12 26-6-6 0-8 4-7 8-4-3-8-2-10 2-2-4-6-4-9-1z" />
        <path d="M30 9l-3-4 1 5-2 2 1 7 3 3 3-3 1-7-2-2 1-5z" />
      </svg>
    </span>
  );
}

/** Hills, graves and a crooked tree along the bottom of the scene. */
export function Hills() {
  return (
    <svg className="pk-hills" viewBox="0 0 400 90" preserveAspectRatio="none" aria-hidden="true">
      <path className="pk-hills__far" d="M0 52c40-14 80-18 120-8s70 4 110-8 90-10 170 8V90H0z" />
      <path
        className="pk-hills__near"
        d="M0 70c50-12 95-10 140-2 30 5 60 4 90-3 50-11 110-8 170 4V90H0zM52 66v-9a6 6 0 0 1 12 0v8zM84 64v-12a7 7 0 0 1 14 0v11zM300 66v-10a6 6 0 0 1 12 0v10zM331 67v-7h-4v-4h4v-4h4v4h4v4h-4v8z"
      />
      <path className="pk-hills__tree" d="M356 70c2-14 1-26-3-36l-9-6 10 3-2-11 5 10 6-9-3 12c3 10 4 22 3 37z" />
    </svg>
  );
}

/** Stars, the moon, bats, hills and the back fog layer of the night scene (the parent is `.pk-scene`). */
export function NightSky() {
  return (
    <>
      <span className="pk-stars" aria-hidden="true" />
      <span className="pk-moon" aria-hidden="true" />
      <span className="pk-bats" aria-hidden="true">
        <Bat />
        <Bat />
        <Bat />
      </span>
      <Hills />
      <span className="pk-fog pk-fog--back" aria-hidden="true" />
    </>
  );
}

/** Is the Halloween skin on (`<html data-palette="halloween">`)? */
export const halloweenSkin = () => typeof document !== 'undefined' && document.documentElement.dataset.palette === 'halloween';

/** The Halloween season over the Crash look (iteration 37, `<html data-season="halloween">` until 3 November). */
export const halloweenSeason = () => typeof document !== 'undefined' && document.documentElement.dataset.season === 'halloween';

/**
 * The whole-app night behind the pages while the Halloween skin is on: moon, stars, bats, drifting spirits,
 * a graveyard on the horizon and fog. Fixed, behind everything, never catches a tap.
 */
export function SpookyLayer() {
  if (!halloweenSkin()) return null;
  return (
    <div className="spooky" aria-hidden="true">
      <PumpkinDefs />
      <span className="spooky__stars" />
      <span className="spooky__moon" />
      <span className="pk-bats spooky__bats">
        <Bat />
        <Bat />
        <Bat />
      </span>
      <GhostArt className="spooky__wisp spooky__wisp--1" />
      <GhostArt className="spooky__wisp spooky__wisp--2" />
      <svg className="spooky__graves" viewBox="0 0 400 100" preserveAspectRatio="xMidYMax slice">
        <path d="M0 78c40-10 80-12 120-6 30 4 60 3 90-2 50-8 120-6 190 6V100H0z" />
        <path d="M262 74V40h6v-8l5-10 5 10v8h6v34zM292 74V48h5l4-8 4 8h5v26zM240 74V52l6-8 6 8v22z" />
        <path d="M34 80v-12a7 7 0 0 1 14 0v12zM70 79v-9h-4v-4h4v-4h4v4h4v4h-4v9zM118 77v-10a6 6 0 0 1 12 0v10zM344 80v-11a6 6 0 0 1 12 0v11zM372 80v-8h-3v-3h3v-3h3v3h3v3h-3v8z" />
        <path d="M186 74c2-12 1-22-3-30l-8-5 9 2-2-10 5 9 5-8-3 11c3 9 4 19 3 31z" />
      </svg>
      <span className="spooky__fog" />
    </div>
  );
}
