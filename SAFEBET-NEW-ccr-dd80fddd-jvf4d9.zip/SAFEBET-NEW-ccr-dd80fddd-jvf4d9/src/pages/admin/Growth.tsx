import { useState, type FormEvent } from 'react';
import { Icon } from '../../components/Icon';
import { copyText } from '../../lib/copy';
import { cx, formatCoins } from '../../lib/format';
import type * as GrowthApi from '../../../server/growth';
import { Card, Empty, Field, Segmented, adminApi, formatWhen, useAdminAction, useAdminQuery, type Data } from './ui';

// ---------- «Экономика» (owners) ----------

type Economy = Data<typeof GrowthApi.economyReport>;
type Period = 'week' | 'month' | 'all';

const PERIODS: { value: Period; label: string }[] = [
  { value: 'week', label: '7 дней' },
  { value: 'month', label: '30 дней' },
  { value: 'all', label: 'Всё время' },
];

const BONUS_LABEL: Record<keyof Economy['all']['bonuses'], string> = {
  referral: 'Рефералам (% с пополнений)',
  milestones: 'Крупные приглашения',
  cashback: 'Кэшбэк',
  quests: 'Задания (монеты, до тикетов)',
  ticketCases: 'Тикет-кейсы (что выпало)',
  rankGifts: 'Подарки рангов',
  promo: 'Промокоды (монеты)',
  consolations: 'Утешительные спины',
  giveaways: 'Розыгрыши (по каталогу)',
  admin: 'Выдано админами',
  pass: 'Батл пасс (брейнроты, монеты, кейсы)',
};

const B = (n: number) => `${formatCoins(n)} B`;

/**
 * What came in, what went out, what the bonuses cost and what the games kept. The verdict line is the all-time
 * position: deposits − done withdrawals − everything players hold right now.
 */
export function Economy() {
  const report = useAdminQuery<Economy>(['economy'], '/economy');
  const [period, setPeriod] = useState<Period>('week');
  const d = report.data;
  if (!d) return <Card title="Экономика">{report.isError ? <Empty>Не удалось загрузить</Empty> : <Empty>Считаем…</Empty>}</Card>;
  const p = d[period];
  const bonusShare = p.house > 0 ? Math.round((p.bonusTotal / p.house) * 100) : null;
  const ok = d.result >= 0;
  return (
    <>
      <Card title="Итог проекта" className={cx('eco-verdict', ok ? 'is-ok' : 'is-bad')}>
        <p className="eco-verdict__value">
          {ok ? '+' : '−'}
          {B(Math.abs(d.result))}
        </p>
        <p className="acard__text">
          {ok ? 'В плюсе: ' : 'В минусе: '}пополнения (и BPlus по курсу звёзд) за всё время − выводы − то, что сейчас у игроков на руках (монеты, реферальные
          балансы и брейнроты по ценам каталога). Пока число выше нуля, ни один бонус не стоил больше, чем принёс.
        </p>
        <dl className="adl">
          <div>
            <dt>Пополнено всего</dt>
            <dd>{B(d.all.deposits)}</dd>
          </div>
          {d.all.passStars > 0 && (
            <div>
              <dt>BPlus продано</dt>
              <dd>
                {formatCoins(d.all.passStars)} ⭐ ≈ {B(d.all.passCoins)}
              </dd>
            </div>
          )}
          <div>
            <dt>Выведено всего</dt>
            <dd>{B(d.all.withdrawals)}</dd>
          </div>
          <div>
            <dt>У игроков сейчас</dt>
            <dd>{B(d.holdingsTotal)}</dd>
          </div>
          <div>
            <dt>Из них монеты / реф. / брейнроты</dt>
            <dd>
              {formatCoins(d.holdings.coins)} / {formatCoins(d.holdings.ref)} / {formatCoins(d.holdings.items)}
            </dd>
          </div>
          <div>
            <dt>Игроков</dt>
            <dd>{formatCoins(d.players)}</dd>
          </div>
        </dl>
      </Card>

      <Card title="За период" actions={<Segmented value={period} onChange={setPeriod} options={PERIODS} label="Период" />}>
        <div className="atiles atiles--eco">
          <div className="atile">
            <span className="atile__value">{formatCoins(p.stars)}</span>
            <span className="atile__label">Звёзд</span>
          </div>
          <div className="atile">
            <span className="atile__value">{formatCoins(p.cryptoRub)}</span>
            <span className="atile__label">Криптой, ₽</span>
          </div>
          <div className="atile">
            <span className="atile__value">{formatCoins(p.deposits)}</span>
            <span className="atile__label">Пополнено, B</span>
          </div>
          <div className="atile">
            <span className="atile__value">{formatCoins(p.withdrawals)}</span>
            <span className="atile__label">Выведено, B</span>
          </div>
          <div className="atile">
            <span className="atile__value">{formatCoins(p.played)}</span>
            <span className="atile__label">Сыграно, B</span>
          </div>
          <div className={cx('atile', p.house < 0 && 'is-alert')}>
            <span className="atile__value">{formatCoins(p.house)}</span>
            <span className="atile__label">Оставили игры, B</span>
          </div>
          <div className={cx('atile', p.bonusTotal > p.house && p.bonusTotal > 0 && 'is-alert')}>
            <span className="atile__value">{formatCoins(p.bonusTotal)}</span>
            <span className="atile__label">Бонусы, B{bonusShare !== null && ` · ${bonusShare}% от игр`}</span>
          </div>
          <div className="atile">
            <span className="atile__value">{formatCoins(p.tickets)}</span>
            <span className="atile__label">Тикетов выдано</span>
          </div>
        </div>
        <ul className="alist alist--compact eco-bonuses">
          {(Object.keys(BONUS_LABEL) as (keyof typeof BONUS_LABEL)[]).map((k) => (
            <li key={k} className="alist__row">
              <span>{BONUS_LABEL[k]}</span>
              <span className="alist__meta">{B(p.bonuses[k])}</span>
            </li>
          ))}
        </ul>
        <p className="afield__hint">
          «Оставили игры» — ставки минус выплаты во всех играх. Бонусы должны оставаться заметно ниже этого числа: кэшбэк ≤ 8 %
          проигрыша, задания ≈ 3 % нужного оборота, подарки рангов — 1 % порога при обороте ×3.
        </p>
      </Card>
    </>
  );
}

// ---------- «Источники» (owners) ----------

type Source = Data<typeof GrowthApi.listSources>[number];

/** Tagged /start links for bloggers and ads: who came, who paid, what they brought and took out. */
export function Sources() {
  const list = useAdminQuery<Source[]>(['sources'], '/sources');
  const [tag, setTag] = useState('');
  const [title, setTitle] = useState('');
  const create = useAdminAction((body: { tag: string; title: string }) => adminApi<Source[]>('/sources', 'POST', body), { success: 'Ссылка создана' });

  function submit(e: FormEvent) {
    e.preventDefault();
    create.mutate({ tag, title }, { onSuccess: () => (setTag(''), setTitle('')) });
  }

  return (
    <>
      <Card title="Новая ссылка">
        <form className="aform" onSubmit={submit}>
          <Field label="Название" hint="Для себя: «TikTok @blogger», «Реклама в канале X»">
            <span className="ainput">
              <input value={title} onChange={(e) => setTitle(e.target.value.slice(0, 80))} placeholder="TikTok @blogger" />
            </span>
          </Field>
          <Field label="Метка" hint="Латиница, цифры и «_», 3–32 символа — попадёт в ссылку">
            <span className="ainput">
              <input
                value={tag}
                onChange={(e) => setTag(e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, '').slice(0, 32))}
                placeholder="tiktok_blogger"
                autoCapitalize="off"
                spellCheck={false}
              />
            </span>
          </Field>
          <button type="submit" className="btn btn--primary btn--sm" disabled={tag.length < 3 || !title.trim() || create.isPending}>
            Создать ссылку
          </button>
        </form>
      </Card>

      <Card title="Источники">
        {!list.data ? (
          <Empty>Загружаем…</Empty>
        ) : !list.data.length ? (
          <Empty>Ссылок пока нет. Создай первую и отдай блогеру — здесь будет видно, сколько игроков и денег она привела.</Empty>
        ) : (
          <ul className="src-list">
            {list.data.map((s) => {
              const net = s.deposits - s.withdrawals;
              return (
                <li key={s.tag} className="src">
                  <div className="src__head">
                    <span className="src__title">{s.title}</span>
                    <span className="alist__meta">{formatWhen(s.createdAt)}</span>
                  </div>
                  <button type="button" className="src__link" onClick={() => copyText(s.link, 'Ссылка скопирована')}>
                    <span>{s.link.replace('https://', '')}</span>
                    <Icon name="copy" size={16} />
                  </button>
                  <dl className="src__stats">
                    <div>
                      <dt>Переходы</dt>
                      <dd>{formatCoins(s.clicks)}</dd>
                    </div>
                    <div>
                      <dt>Новые игроки</dt>
                      <dd>{formatCoins(s.players)}</dd>
                    </div>
                    <div>
                      <dt>Платили</dt>
                      <dd>{formatCoins(s.payers)}</dd>
                    </div>
                    <div>
                      <dt>Пополнили</dt>
                      <dd>{B(s.deposits)}</dd>
                    </div>
                    <div>
                      <dt>Вывели</dt>
                      <dd>{B(s.withdrawals)}</dd>
                    </div>
                    <div>
                      <dt>Чистыми</dt>
                      <dd className={net < 0 ? 'is-red' : 'is-green'}>{B(net)}</dd>
                    </div>
                  </dl>
                </li>
              );
            })}
          </ul>
        )}
        <p className="afield__hint">
          Игрок засчитывается источнику, только если он впервые открыл бота по этой ссылке. Переход считается один раз на игрока.
        </p>
      </Card>
    </>
  );
}
