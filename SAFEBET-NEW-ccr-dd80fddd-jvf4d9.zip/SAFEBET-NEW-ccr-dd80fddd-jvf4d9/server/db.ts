import { AsyncLocalStorage } from 'node:async_hooks';

export interface QueryResult<T> {
  rows: T[];
  rowCount: number | null;
}

export interface Queryable {
  query<T = Record<string, unknown>>(text: string, params?: unknown[]): Promise<QueryResult<T>>;
}

interface PoolClientLike extends Queryable {
  release(): void;
}

export interface PoolLike extends Queryable {
  connect(): Promise<PoolClientLike>;
}

let pool: PoolLike | null = null;
// Cloudflare Workers can't share a socket between requests: each request (and each cron run) brings its own
// short-lived pool through runWithPool.
const scoped = new AsyncLocalStorage<PoolLike>();

export function usePool(p: PoolLike | null) {
  pool = p;
}

export function runWithPool<T>(p: PoolLike, fn: () => Promise<T>): Promise<T> {
  return scoped.run(p, fn);
}

async function getPool(): Promise<PoolLike> {
  const own = scoped.getStore();
  if (own) return own;
  if (!pool) {
    const { getDatabase } = await import('@netlify/database');
    pool = getDatabase().pool as unknown as PoolLike;
  }
  return pool;
}

export const db: Queryable = {
  query: async (text, params) => (await getPool()).query(text, params),
};

export async function q<T = Record<string, unknown>>(text: string, params: unknown[] = []): Promise<T[]> {
  return (await (await getPool()).query<T>(text, params)).rows;
}

export async function one<T = Record<string, unknown>>(text: string, params: unknown[] = []): Promise<T | undefined> {
  return (await q<T>(text, params))[0];
}

export async function tx<T>(fn: (c: Queryable) => Promise<T>): Promise<T> {
  const client = await (await getPool()).connect();
  try {
    await client.query('BEGIN');
    const result = await fn(client);
    await client.query('COMMIT');
    return result;
  } catch (e) {
    await client.query('ROLLBACK').catch(() => {});
    throw e;
  } finally {
    client.release();
  }
}

export const num = (v: unknown): number => (v === null || v === undefined ? 0 : Number(v));
export const ms = (v: unknown): number | null => (v ? new Date(v as string).getTime() : null);
