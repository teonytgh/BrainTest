import {
  bridgeSpans,
  BRIDGE_TURN_MS,
  COOKIE_COVER,
  COOKIE_IDLE_MS,
  COOKIE_MAX_SPEED,
  COOKIE_SHAPES,
  COOKIE_TOLERANCE,
  LIGHT_FIELD,
  LIGHT_GRACE_MS,
  LIGHT_GREEN_MS,
  LIGHT_IDLE_GAIN,
  LIGHT_IDLE_MS,
  LIGHT_RED_MS,
  LIGHT_SPEED,
  LIGHT_TOLERANCE,
  NIGHT_COOLDOWN_MS,
  NIGHT_DAMAGE,
  NIGHT_HP,
  NIGHT_RADIUS,
  NIGHT_REACH,
  NIGHT_SPEED,
  SQUID_BREAK_MS,
  SQUID_GONE_MS,
  SQUID_ROOM_LIMIT,
  SQUID_STAGE,
  SQUID_STAGE_CAP_MS,
  SQUID_STAGES,
  cookieOutline,
  outlineDistance,
  outlineSamples,
  type BridgeSide,
  type CookieShape,
  type SquidPhase,
  type SquidStage,
} from '../../shared/squid';
import type { JoinOpts, RoomLogic, RoomSocket } from './types';

/**
 * «Игра Кальмара» (iteration 35, rules in shared/squid.ts): one game's room — the referee. Phases run on its clock
 * (tick every 100 ms): lobby → (break → stage) × 4 → done. Since iteration 36 only the lobby, the breaks and the night
 * have a clock: the other stages end when everyone still in is through (or out); players who left or stand still are
 * taken out so nobody waits for them, and a hidden 10-minute net closes an abandoned room. Players send only their input; the room decides who moved
 * on red, who hit whom and for how much, whether a candy cracked, which glass holds. When the game is over the API
 * asks for the results (`call('results')`) and pays the places.
 *
 * To players: `w` (everything, on join), `ph` (phase changes), `li` (the light), `s` (positions), `out`, `ok` (passed
 * a stage), `hit`, `ck` (your candy's shape), `cv` (your candy's progress), `br` (the bridge's turn), `st` (a step),
 * `cross`, `done`. From players: `mv` (light: progress), `p` + `hit` (night), `tr` (candy trace points), `ch` (bridge
 * side).
 */

interface Player {
  id: number;
  name: string;
  sock: RoomSocket | null;
  /** When the socket went away during the game (0 = connected). */
  goneAt: number;
  /** An admin's immortality for trailers (iteration 37): red light, HP, the candy and the glass never take them out. */
  god: boolean;
  alive: boolean;
  /** Joined after the lobby: watches only. */
  spectator: boolean;
  lane: number;
  prog: number;
  progAt: number;
  /** Green light (ms) stood through without running. */
  idle: number;
  finished: boolean;
  x: number;
  y: number;
  posAt: number;
  hp: number;
  hitAt: number;
  shape: CookieShape;
  cover: Set<number>;
  last: [number, number, number] | null;
  traceStart: number;
  /** The last time the traced part of the outline grew. */
  coverAt: number;
  done: boolean;
  dirty: boolean;
}

const pick = (rng: () => number, [a, b]: readonly [number, number]) => a + rng() * (b - a);
/** Not the game's doing: these take even an immortal admin out (else a stage would wait for them). */
const NOT_GAMEPLAY = new Set(['idle', 'gone', 'time']);

export class SquidRoom implements RoomLogic {
  readonly tickMs = 100;
  private players = new Map<number, Player>();
  phase: SquidPhase = 'lobby';
  phaseEnds = Number.POSITIVE_INFINITY;
  private phaseStart = 0;
  /** The phase's clock is shown (lobby, break, night); otherwise `phaseEnds` is only the hidden safety net. */
  private timed = true;
  private lastTick = 0;
  private next: SquidStage | null = null;
  private stageIndex = -1;
  private green = true;
  private lightUntil = 0;
  private redSince = 0;
  private snapAt = 0;
  private glass: BridgeSide[] = [];
  private known: (BridgeSide | null)[] = [];
  private order: number[] = [];
  private turn = 0;
  private turnEnds = 0;
  readonly places: number[] = [];
  readonly out = new Map<number, SquidStage | 'lobby'>();

  constructor(
    private now: () => number = Date.now,
    private rng: () => number = Math.random,
  ) {}

  /** Connected sockets: the host ticks while there are any (the game's clock is absolute, so it catches up). */
  get size() {
    let n = 0;
    for (const p of this.players.values()) if (p.sock) n++;
    return n;
  }

  private alive() {
    return [...this.players.values()].filter((p) => p.alive);
  }

  // ---------- Joining ----------

  join(id: number, name: string, sock: RoomSocket, opts: JoinOpts = {}): boolean {
    const old = this.players.get(id);
    if (old) {
      if (old.sock && old.sock !== sock) {
        try {
          old.sock.close(4000, 'replaced');
        } catch {
          // Gone.
        }
      }
      old.sock = sock;
      old.goneAt = 0;
      old.god = opts.god === true;
    } else {
      if (this.players.size >= SQUID_ROOM_LIMIT) {
        sock.send(JSON.stringify({ t: 'full' }));
        sock.close(4001, 'full');
        return false;
      }
      const playing = this.phase === 'lobby';
      this.players.set(id, {
        id,
        name,
        sock,
        goneAt: 0,
        god: opts.god === true,
        alive: playing,
        spectator: !playing,
        lane: this.players.size,
        prog: 0,
        progAt: this.now(),
        idle: 0,
        finished: false,
        x: 0,
        y: 0,
        posAt: this.now(),
        hp: NIGHT_HP,
        hitAt: 0,
        shape: 'circle',
        cover: new Set(),
        last: null,
        traceStart: 0,
        coverAt: 0,
        done: false,
        dirty: false,
      });
      if (playing) this.broadcast({ t: 'j', id, n: name }, id);
    }
    sock.send(JSON.stringify(this.welcome(id)));
    return true;
  }

  leave(id: number, sock: RoomSocket) {
    const p = this.players.get(id);
    if (!p || p.sock !== sock) return;
    p.sock = null;
    p.goneAt = this.now();
    // In the lobby leaving means not playing; later a player stays in the game: the bridge steps for them, and in a
    // stage without a clock they are out after SQUID_GONE_MS unless they come back.
    if (this.phase === 'lobby') {
      this.players.delete(id);
      this.broadcast({ t: 'l', id });
    }
  }

  private welcome(id: number) {
    const me = this.players.get(id)!;
    return {
      t: 'w',
      you: id,
      phase: this.phase,
      ends: this.shownEnds(),
      start: this.phaseStart,
      next: this.next,
      players: [...this.players.values()].filter((p) => !p.spectator).map((p) => [p.id, p.name, p.alive ? 1 : 0, p.lane]),
      light: { green: this.green, until: this.lightUntil },
      prog: [...this.players.values()].filter((p) => !p.spectator).map((p) => [p.id, Math.round(p.prog)]),
      night: [...this.players.values()].filter((p) => p.alive).map((p) => [p.id, Math.round(p.x), Math.round(p.y), p.hp]),
      cookie: this.phase === 'cookie' && me.alive ? { shape: me.shape, cover: me.cover.size, done: me.done } : null,
      bridge: this.phase === 'bridge' ? this.bridgeState() : null,
      places: this.places,
      spectator: me.spectator,
    };
  }

  // ---------- Phases ----------

  /** The API sets the lobby's end when the game starts. */
  init(lobbyUntil: number) {
    if (this.phase === 'lobby') this.phaseEnds = lobbyUntil;
  }

  /** The clock players see: null for a stage that ends when everyone is through. */
  private shownEnds(): number | null {
    return this.timed && Number.isFinite(this.phaseEnds) ? this.phaseEnds : null;
  }

  /** `ms` null: no clock — the stage ends when everyone is through (the hidden net aside). */
  private setPhase(phase: SquidPhase, ms: number | null) {
    this.phase = phase;
    this.phaseStart = this.now();
    this.timed = ms !== null;
    this.phaseEnds = this.phaseStart + (ms ?? SQUID_STAGE_CAP_MS);
    this.broadcast({ t: 'ph', phase, ends: this.shownEnds(), start: this.phaseStart, next: this.next });
  }

  private toBreak() {
    if (!this.alive().length || this.stageIndex >= SQUID_STAGES.length - 1) return this.finish();
    this.next = SQUID_STAGES[this.stageIndex + 1]!;
    this.setPhase('break', SQUID_BREAK_MS);
  }

  private finish() {
    this.next = null;
    this.phase = 'done';
    this.phaseEnds = Number.POSITIVE_INFINITY;
    this.broadcast({ t: 'done', places: this.places });
  }

  private eliminate(p: Player, stage: SquidStage | 'lobby', why: string) {
    if (!p.alive) return;
    // Immortal for trailers: the game never takes them out — leaving or standing idle still does (or the stage waits).
    if (p.god && !NOT_GAMEPLAY.has(why)) return;
    p.alive = false;
    this.out.set(p.id, stage);
    this.broadcast({ t: 'out', id: p.id, why });
  }

  tick() {
    const now = this.now();
    const dt = this.lastTick ? Math.min(now - this.lastTick, 1000) : 0;
    this.lastTick = now;
    if (this.phase === 'done') return;
    if (this.phase === 'light' || this.phase === 'cookie') this.dropStragglers(now, dt);
    if (this.phase === 'light') this.lightTick(now);
    if (this.phase === 'bridge' && now >= this.turnEnds) this.step(this.rng() < 0.5 ? 'l' : 'r', true);
    if ((this.phase === 'light' || this.phase === 'night') && now - this.snapAt >= 200) this.snapshot(now);
    if (now < this.phaseEnds) return;
    switch (this.phase) {
      case 'lobby':
        this.stageIndex = -1;
        return this.toBreak();
      case 'break':
        return this.startStage(this.next!);
      case 'light':
        // Only the hidden net gets here with someone still running (an abandoned room).
        for (const p of this.alive()) if (!p.finished) this.eliminate(p, 'light', 'time');
        return this.toBreak();
      case 'night':
        return this.toBreak();
      case 'cookie':
        for (const p of this.alive()) if (!p.done) this.eliminate(p, 'cookie', 'time');
        return this.toBreak();
      case 'bridge':
        for (const p of this.alive()) if (!this.places.includes(p.id)) this.eliminate(p, 'bridge', 'time');
        return this.finish();
    }
  }

  /**
   * A stage without a clock waits for everyone still in: who left for good, stands still on green or stopped tracing
   * is taken out, so it never hangs on them.
   */
  private dropStragglers(now: number, dt: number) {
    const light = this.phase === 'light';
    for (const p of this.alive()) {
      if (light ? p.finished : p.done) continue;
      if (!p.sock && p.goneAt && now - p.goneAt >= SQUID_GONE_MS) {
        this.eliminate(p, this.phase as SquidStage, 'gone');
        continue;
      }
      if (light && this.green) p.idle += dt;
      if (light ? p.idle >= LIGHT_IDLE_MS : now - p.coverAt >= COOKIE_IDLE_MS) this.eliminate(p, this.phase as SquidStage, 'idle');
    }
    if (this.alive().every((q) => (light ? q.finished : q.done))) this.phaseEnds = Math.min(this.phaseEnds, now);
  }

  private startStage(stage: SquidStage) {
    this.stageIndex = SQUID_STAGES.indexOf(stage);
    const alive = this.alive();
    const now = this.now();
    if (stage === 'light') {
      alive.forEach((p, i) => {
        p.prog = 0;
        p.progAt = now;
        p.idle = 0;
        p.finished = false;
        p.lane = i;
      });
      this.green = true;
      this.lightUntil = now + pick(this.rng, LIGHT_GREEN_MS);
    } else if (stage === 'night') {
      alive.forEach((p, i) => {
        const a = (i / Math.max(1, alive.length)) * Math.PI * 2;
        p.x = Math.round(Math.cos(a) * NIGHT_RADIUS * 0.7);
        p.y = Math.round(Math.sin(a) * NIGHT_RADIUS * 0.7);
        p.posAt = now;
        p.hp = NIGHT_HP;
        p.hitAt = 0;
        // Everyone's starting place goes out with the next snapshot (also those who never move).
        p.dirty = true;
      });
    } else if (stage === 'cookie') {
      for (const p of alive) {
        p.shape = COOKIE_SHAPES[Math.floor(this.rng() * COOKIE_SHAPES.length)]!;
        p.cover = new Set();
        p.last = null;
        p.done = false;
        p.traceStart = now;
        p.coverAt = now;
      }
    } else {
      const spans = bridgeSpans(alive.length);
      this.glass = Array.from({ length: spans }, () => (this.rng() < 0.5 ? 'l' : 'r'));
      this.known = Array.from({ length: spans }, () => null);
      this.order = alive.map((p) => p.id);
      for (let i = this.order.length - 1; i > 0; i--) {
        const j = Math.floor(this.rng() * (i + 1));
        [this.order[i], this.order[j]] = [this.order[j]!, this.order[i]!];
      }
      this.turn = 0;
    }
    this.setPhase(stage, SQUID_STAGE[stage].ms);
    if (stage === 'light') this.broadcast({ t: 'li', green: this.green, until: this.lightUntil });
    if (stage === 'cookie') for (const p of alive) this.sendTo(p, { t: 'ck', shape: p.shape });
    if (stage === 'bridge') this.nextWalker();
  }

  // ---------- Stage 1: red light, green light ----------

  private lightTick(now: number) {
    if (now < this.lightUntil) return;
    this.green = !this.green;
    this.lightUntil = now + pick(this.rng, this.green ? LIGHT_GREEN_MS : LIGHT_RED_MS);
    if (!this.green) this.redSince = now;
    this.broadcast({ t: 'li', green: this.green, until: this.lightUntil });
  }

  private onMove(p: Player, raw: number) {
    if (p.finished) return;
    const now = this.now();
    const maxGain = (LIGHT_SPEED * 1.3 * (now - p.progAt)) / 1000 + 12;
    const want = Math.max(p.prog, Math.min(raw, p.prog + maxGain));
    const moved = want - p.prog > LIGHT_TOLERANCE;
    if (moved && !this.green && now - this.redSince > LIGHT_GRACE_MS && !p.god) {
      this.eliminate(p, 'light', 'moved');
      return;
    }
    if (Math.floor(want / LIGHT_IDLE_GAIN) > Math.floor(p.prog / LIGHT_IDLE_GAIN)) p.idle = 0;
    p.prog = want;
    p.progAt = now;
    p.dirty = true;
    if (p.prog >= LIGHT_FIELD) {
      p.prog = LIGHT_FIELD;
      p.finished = true;
      this.broadcast({ t: 'ok', id: p.id, stage: 'light' });
      if (this.alive().every((q) => q.finished)) this.phaseEnds = now;
    }
  }

  // ---------- Stage 2: the night fight ----------

  private onPos(p: Player, x: number, y: number) {
    const now = this.now();
    const maxD = (NIGHT_SPEED * 1.4 * (now - p.posAt)) / 1000 + 24;
    let dx = x - p.x;
    let dy = y - p.y;
    const d = Math.hypot(dx, dy);
    if (d > maxD) {
      dx = (dx / d) * maxD;
      dy = (dy / d) * maxD;
    }
    let nx = p.x + dx;
    let ny = p.y + dy;
    const r = Math.hypot(nx, ny);
    if (r > NIGHT_RADIUS) {
      nx = (nx / r) * NIGHT_RADIUS;
      ny = (ny / r) * NIGHT_RADIUS;
    }
    p.x = Math.round(nx);
    p.y = Math.round(ny);
    p.posAt = now;
    p.dirty = true;
  }

  private onHit(p: Player) {
    const now = this.now();
    if (now - p.hitAt < NIGHT_COOLDOWN_MS) return;
    p.hitAt = now;
    let target: Player | null = null;
    let best = NIGHT_REACH + 16;
    for (const q of this.alive()) {
      if (q === p) continue;
      const d = Math.hypot(q.x - p.x, q.y - p.y);
      if (d <= best) {
        best = d;
        target = q;
      }
    }
    this.broadcast({ t: 'sw', id: p.id });
    if (!target) return;
    const dmg = target.god ? 0 : Math.round(pick(this.rng, [NIGHT_DAMAGE[0], NIGHT_DAMAGE[1] + 0.999]) - 0.5);
    target.hp = Math.max(0, target.hp - dmg);
    this.broadcast({ t: 'hit', from: p.id, to: target.id, dmg, hp: target.hp });
    if (target.hp <= 0) {
      this.eliminate(target, 'night', 'hp');
      if (this.alive().length <= 1) this.phaseEnds = now;
    }
  }

  // ---------- Stage 3: the candy ----------

  private onTrace(p: Player, pts: unknown) {
    if (p.done || !Array.isArray(pts) || pts.length > 80) return;
    const now = this.now();
    const outline = cookieOutline(p.shape);
    const samples = outlineSamples(outline);
    const before = p.cover.size;
    for (const raw of pts) {
      if (!Array.isArray(raw) || raw.length !== 3) return;
      const [x, y, t] = raw.map(Number) as [number, number, number];
      if (![x, y, t].every(Number.isFinite)) return;
      // The app's clock may not run ahead of the room's (a slow trace can't be faked by stamping times).
      if (t > now - p.traceStart + 1500) return;
      if (outlineDistance(outline, x, y) > COOKIE_TOLERANCE) {
        // Off the line: cracked — an immortal admin's stray point is simply not counted.
        if (p.god) continue;
        return this.crack(p, 'off');
      }
      const prev = p.last;
      if (prev && t - prev[2] > 16 && t - prev[2] < 250) {
        const speed = Math.hypot(x - prev[0], y - prev[1]) / ((t - prev[2]) / 1000);
        if (speed > COOKIE_MAX_SPEED && !p.god) return this.crack(p, 'fast');
      }
      if (prev && t < prev[2]) return;
      p.last = [x, y, t];
      samples.forEach(([sx, sy], i) => {
        if (Math.hypot(sx - x, sy - y) <= COOKIE_TOLERANCE * 1.4) p.cover.add(i);
      });
    }
    if (p.cover.size > before) p.coverAt = now;
    const cover = p.cover.size / samples.length;
    this.sendTo(p, { t: 'cv', cover: Math.round(cover * 100) / 100 });
    if (cover >= COOKIE_COVER) {
      p.done = true;
      this.broadcast({ t: 'ok', id: p.id, stage: 'cookie' });
      if (this.alive().every((q) => q.done)) this.phaseEnds = now;
    }
  }

  private crack(p: Player, why: 'off' | 'fast') {
    this.eliminate(p, 'cookie', why);
    if (this.alive().every((q) => q.done)) this.phaseEnds = this.now();
  }

  // ---------- Stage 4: the glass bridge ----------

  private bridgeState() {
    const walker = this.order[this.turn] ?? null;
    return { order: this.order, turn: this.turn, walker, at: this.known.indexOf(null), known: this.known, ends: this.turnEnds, places: this.places };
  }

  private nextWalker() {
    const now = this.now();
    while (this.turn < this.order.length) {
      const id = this.order[this.turn]!;
      const p = this.players.get(id);
      if (!p?.alive) {
        this.turn++;
        continue;
      }
      if (this.known.indexOf(null) === -1) {
        this.cross(p);
        this.turn++;
        continue;
      }
      this.turnEnds = now + BRIDGE_TURN_MS;
      this.broadcast({ t: 'br', ...this.bridgeState() });
      return;
    }
    // Everybody had their turn.
    this.phaseEnds = now;
  }

  private cross(p: Player) {
    this.places.push(p.id);
    this.broadcast({ t: 'cross', id: p.id, place: this.places.length });
  }

  private step(side: BridgeSide, auto = false) {
    const id = this.order[this.turn];
    const p = id === undefined ? null : this.players.get(id);
    const at = this.known.indexOf(null);
    if (!p || at === -1) return this.nextWalker();
    const ok = this.glass[at] === side;
    // A step tells everyone which glass holds there: the one stepped on, or the other one.
    this.known[at] = this.glass[at]!;
    this.broadcast({ t: 'st', id: p.id, span: at, side, ok, auto });
    // An immortal admin's pane breaks like anyone's, but they hop onto the tempered one and walk on.
    if (!ok && !p.god) {
      this.eliminate(p, 'bridge', 'fell');
      this.turn++;
      return this.nextWalker();
    }
    if (this.known.indexOf(null) === -1) {
      this.cross(p);
      this.turn++;
      return this.nextWalker();
    }
    this.turnEnds = this.now() + BRIDGE_TURN_MS;
    this.broadcast({ t: 'br', ...this.bridgeState() });
  }

  // ---------- Messages ----------

  message(id: number, sock: RoomSocket, raw: string) {
    const p = this.players.get(id);
    if (!p || p.sock !== sock || raw.length > 4000) return;
    if (raw === 'ping') return sock.send('pong');
    if (!p.alive) return;
    let m: Record<string, unknown>;
    try {
      m = JSON.parse(raw);
    } catch {
      return;
    }
    if (this.phase === 'light' && m.t === 'mv' && Number.isFinite(Number(m.p))) this.onMove(p, Number(m.p));
    else if (this.phase === 'night' && m.t === 'p' && Number.isFinite(Number(m.x)) && Number.isFinite(Number(m.y))) this.onPos(p, Number(m.x), Number(m.y));
    else if (this.phase === 'night' && m.t === 'hit') this.onHit(p);
    else if (this.phase === 'cookie' && m.t === 'tr') this.onTrace(p, m.pts);
    else if (this.phase === 'bridge' && m.t === 'ch' && (m.side === 'l' || m.side === 'r') && this.order[this.turn] === id) this.step(m.side);
  }

  private snapshot(now: number) {
    this.snapAt = now;
    const moved = this.alive().filter((p) => p.dirty);
    if (!moved.length) return;
    for (const p of moved) p.dirty = false;
    if (this.phase === 'light') this.broadcast({ t: 's', p: moved.map((p) => [p.id, Math.round(p.prog)]) });
    else this.broadcast({ t: 's', p: moved.map((p) => [p.id, p.x, p.y, p.hp]) });
  }

  private sendTo(p: Player, msg: unknown) {
    try {
      p.sock?.send(JSON.stringify(msg));
    } catch {
      // Closing.
    }
  }

  broadcast(msg: unknown, except?: number) {
    const data = JSON.stringify(msg);
    for (const p of this.players.values()) {
      if (p.id === except || !p.sock) continue;
      try {
        p.sock.send(data);
      } catch {
        // Closing.
      }
    }
  }

  call(op: string, arg: unknown): unknown {
    if (op === 'init') {
      this.init(Number((arg as { lobbyUntil?: unknown })?.lobbyUntil) || this.now() + 120_000);
      return true;
    }
    if (op === 'results') {
      return {
        done: this.phase === 'done',
        places: this.places,
        out: [...this.out.entries()],
        players: [...this.players.values()].filter((p) => !p.spectator).map((p) => p.id),
      };
    }
    if (op === 'stats')
      return { phase: this.phase, ends: this.shownEnds(), players: [...this.players.values()].filter((p) => !p.spectator).length, alive: this.alive().length };
    if (op === 'close') {
      this.broadcast({ t: 'end' });
      for (const p of this.players.values()) {
        try {
          p.sock?.close(1000, 'over');
        } catch {
          // Gone.
        }
      }
      this.players.clear();
      this.phase = 'done';
      return true;
    }
    return null;
  }
}
