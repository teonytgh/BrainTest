import { useQuery } from '@tanstack/react-query';
import { useRef, useState } from 'react';
import { CaseArt } from '../components/CaseArt';
import { CaseWalkers, useOnscreen } from '../components/CaseWalkers';
import { Coin } from '../components/Coin';
import { Icon } from '../components/Icon';
import { Ticket } from '../components/Ticket';
import { api } from '../api/client';
import { useCatalog, useMe } from '../api/queries';
import { GIVEAWAY_KIND_NAMES, type GiveawayCard } from '../../shared/giveaways';
import { FREE_CASE_COOLDOWN_MS } from '../../shared/types';
import { cx, formatCoins, formatCountdown } from '../lib/format';
import { routeHref } from '../lib/router';
import { timeLeft } from '../lib/halloween';
import { Countdown, useNow, useReached } from '../lib/useNow';
import { luckIcon } from '../lib/luck';
import { PriceChart, PriceTrend } from '../components/PriceChart';
import { toast } from '../store/toast';
import { openPlayer, openSheet } from '../store/ui';
import { LiveDrops, PlayerDot } from '../components/LiveDrops';
import { AutumnMeowl } from '../components/AutumnMeowl';
import { autumnSeason } from '../lib/season';
import { tierOf } from '../lib/tier';


export function Home() {
  const me = useMe();
  const catalog = useCatalog();
  // Coarse: which cards show. The countdowns tick on their own (Countdown), the free case flips once (useReached).
  const now = useNow(15_000);
  const [search, setSearch] = useState('');
  /** The theme chip: 'all' shows every theme as its own block. */
  const [theme, setTheme] = useState('all');
  const promo = me.promo;
  // The case cards' walkers move only while their card is on screen.
  const casesRef = useRef<HTMLDivElement>(null);
  const drop = catalog.topDrop ? { ...catalog.topDrop, brainrot: catalog.byId.get(catalog.topDrop.brainrotId) } : null;
  const freeCase = catalog.cases.find((c) => c.kind === 'free');
  const freeAt = me.user.freeCaseAt ? me.user.freeCaseAt + FREE_CASE_COOLDOWN_MS : 0;
  const freeReady = useReached(freeAt);
  const query = search.trim().toLowerCase();
  // Ticket cases sit in their own theme («Бесплатные») next to the paid ones.
  const paid = catalog.cases.filter((c) => (c.kind === 'paid' || c.kind === 'tickets') && (!query || c.name.toLowerCase().includes(query)));
  // One block per theme (admin «Темы»); cases without one go to the first theme.
  const sections = catalog.sections.length ? catalog.sections : [{ id: -1, title: 'Кейсы', sort: 0 }];
  const groups = sections
    .map((s, i) => ({
      key: String(s.id),
      title: s.title,
      cases: paid.filter((c) => c.sectionId === s.id || (i === 0 && !sections.some((x) => x.id === c.sectionId))),
    }))
    .filter((g) => g.cases.length);
  const shown = theme === 'all' || query ? groups : groups.filter((g) => g.key === theme);

  async function copyCode() {
    try {
      await navigator.clipboard.writeText(promo.code);
      toast(`Промокод ${promo.code} скопирован`, 'success');
    } catch {
      toast(`Промокод: ${promo.code}`);
    }
  }

  const giveaways = useQuery({ queryKey: ['giveaways'], queryFn: () => api<{ active: GiveawayCard[]; finished: GiveawayCard[] }>('/api/giveaways'), staleTime: 60_000 });
  // The running giveaway closest to its results.
  const giveaway = giveaways.data?.active.find((g) => g.status === 'active' && g.endsAt > now) ?? null;
  const giveawayPrize = giveaway?.prizes[0] ? catalog.byId.get(giveaway.prizes[0].brainrotId) : null;

  const luck = me.luck;
  const luckOn = !useReached(luck?.until ?? 0);
  const squidLobby = !useReached(catalog.squid?.lobbyUntil ?? 0);

  useOnscreen(casesRef, [shown.map((g) => g.key).join(), search]);
  return (
    <div className="home">
      {luck && luckOn && (
        <div className={cx('luck-banner', `luck-banner--x${luck.x}`)} role="status">
          <img src={luckIcon(luck.x)} alt="" />
          <span>
            <span className="luck-banner__title">x{luck.x} УДАЧА</span>
            <span className="luck-banner__text">Шанс окупа в кейсах и батлах {luck.x === 2 ? 'удвоен' : `×${luck.x}`}</span>
          </span>
          <span className="luck-banner__time">
            <Countdown to={luck.until} format={formatCountdown} />
          </span>
        </div>
      )}
      {catalog.squid && (
        <a className="sky-card squid-card" href={routeHref('squid')}>
          <img className="sky-card__meowl squid-card__watcher" src="/squid/watcher-red.webp" alt="" />
          <span className="sky-card__body">
            <span className="sky-card__live">LIVE · ивент</span>
            <span className="sky-card__title">Игра Кальмара</span>
            <span className="sky-card__text">{squidLobby ? '4 испытания, призы за первые места — успей войти' : 'Игра идёт — можно посмотреть'}</span>
          </span>
          <span className="sky-card__go">
            {squidLobby && (
              <span className="sky-card__time">
                <Countdown to={catalog.squid.lobbyUntil} format={formatCountdown} />
              </span>
            )}
            {squidLobby ? 'Войти' : 'Смотреть'} <Icon name="arrowRight" size={16} />
          </span>
        </a>
      )}
      {catalog.sky && catalog.sky.endsAt > now && (
        <a className="sky-card" href={routeHref('sky')}>
          <img className="sky-card__meowl" src="/sky/meowl-face.webp" alt="" />
          <span className="sky-card__body">
            <span className="sky-card__live">LIVE · ивент</span>
            <span className="sky-card__title">Небо Meowl</span>
            <span className="sky-card__text">
              Лети и собирай монеты — до {formatCoins(catalog.sky.max)} B, яйцо 10 B
            </span>
          </span>
          <span className="sky-card__go">
            <span className="sky-card__time">
              <Countdown to={catalog.sky.endsAt} format={formatCountdown} />
            </span>
            Взлететь <Icon name="arrowRight" size={16} />
          </span>
        </a>
      )}
      <div className="home__top">
        {freeCase && (
          <a className={cx('free-hero', freeReady && 'is-ready')} href={routeHref('case', freeCase.id)}>
            <CaseArt kase={freeCase} className="free-hero__art" />
            <span className="free-hero__body">
              <span className="free-hero__label">
                <Icon name="gift" size={14} /> Бесплатный кейс
              </span>
              <span className="free-hero__title">{freeReady ? 'Готов — забирай!' : 'Следующий через'}</span>
              {!freeReady && (
                <span className="free-hero__time">
                  <Countdown to={freeAt} format={formatCountdown} />
                </span>
              )}
              <span className="free-hero__cta">
                {freeReady ? 'Открыть' : 'Что внутри'} <Icon name="arrowRight" size={16} />
              </span>
            </span>
          </a>
        )}

        <section className="promo-strip" aria-labelledby="promo-title">
          <span className="promo-strip__bonus">+{promo.percent}%</span>
          <span className="promo-strip__body">
            <span id="promo-title" className="promo-strip__title">
              к пополнению по коду
            </span>
            <span className="promo-strip__row">
              <button type="button" className="promo-strip__code" onClick={copyCode} aria-label={`Скопировать промокод ${promo.code}`}>
                {promo.code}
                <Icon name="copy" size={14} />
              </button>
              <time className="promo-strip__time" dateTime={new Date(promo.endsAt).toISOString()} aria-label="До смены кода">
                <Icon name="clock" size={13} /> <Countdown to={promo.endsAt} format={formatCountdown} />
              </time>
              {promo.bonus?.status === 'active' && <span className="pill pill--green">Активирован</span>}
              {promo.bonus?.status === 'used' && <span className="pill">Использован</span>}
            </span>
          </span>
          <button type="button" className="btn btn--primary btn--sm promo-strip__go" onClick={() => openSheet('deposit')}>
            <Icon name="plus" size={16} /> Пополнить
          </button>
        </section>

        {giveaway && (
          <a className="gw-strip" href={routeHref('giveaways', String(giveaway.id))}>
            <span className="gw-strip__prize">{giveawayPrize ? <img src={giveawayPrize.image} alt="" /> : <Icon name="trophy" size={24} />}</span>
            <span className="gw-strip__body">
              <small>{GIVEAWAY_KIND_NAMES[giveaway.kind]}</small>
              <b>{giveaway.title}</b>
              <span className="gw-strip__time">
                <Icon name="clock" size={12} /> до итогов <Countdown to={giveaway.endsAt} format={timeLeft} />
              </span>
            </span>
            <Icon name="chevronRight" size={18} />
          </a>
        )}


        <section className="live-panel" aria-label="Дропы игроков в реальном времени">
          <span className="live-panel__badge" aria-hidden="true">
            <i /> LIVE
          </span>
          {drop?.brainrot ? (
            <button
              key={`${drop.brainrotId}-${drop.at}`}
              type="button"
              className={cx('topdrop', `tier-${tierOf(drop.brainrot.price)}`)}
              onClick={() => openPlayer(drop.playerId)}
              aria-label={`Топ дроп дня: ${drop.brainrot.name} у ${drop.player}. Открыть профиль`}
            >
              <span className="topdrop__art">
                <span className="topdrop__halo" aria-hidden="true" />
                <img src={drop.brainrot.image} alt="" />
              </span>
              <span className="topdrop__body">
                <span className="topdrop__label">
                  <Icon name="trophy" size={14} /> <span className="topdrop__label-text">Топ дроп дня</span>
                </span>
                <span className="topdrop__name">{drop.brainrot.name}</span>
                <span className="topdrop__meta">
                  <span className="topdrop__price">
                    <Coin size={16} /> {formatCoins(drop.brainrot.price)}
                  </span>
                  <span className="topdrop__who">
                    <PlayerDot player={{ publicId: drop.playerId, name: drop.player, photo: drop.photo ?? null }} className="topdrop__dot" />
                    <span>{drop.player}</span>
                  </span>
                </span>
              </span>
              <Icon name="chevronRight" size={20} className="topdrop__chev" />
            </button>
          ) : (
            <a className="topdrop topdrop--empty" href={routeHref('upgrader')}>
              <span className="topdrop__art topdrop__art--empty">
                <Icon name="trophy" size={28} />
              </span>
              <span className="topdrop__body">
                <span className="topdrop__label">
                  <Icon name="trophy" size={14} /> <span className="topdrop__label-text">Топ дроп дня</span>
                </span>
                <span className="topdrop__name">Пока пусто — выбей первый</span>
              </span>
              <span className="topdrop__go" aria-hidden="true">
                <Icon name="arrowRight" size={20} />
              </span>
            </a>
          )}
          <LiveDrops />
        </section>
      </div>

      {autumnSeason() && <AutumnMeowl />}

      <div className="case-tools">
        <div className="chips" role="tablist" aria-label="Темы кейсов">
          {[{ key: 'all', title: 'Все' }, ...groups].map((g) => (
            <button key={g.key} type="button" role="tab" aria-selected={theme === g.key} className={cx('chip', theme === g.key && 'is-active')} onClick={() => setTheme(g.key)}>
              {g.title}
            </button>
          ))}
        </div>
        <label className="search home__search">
          <Icon name="sparkle" size={18} />
          <input type="search" placeholder="Поиск кейса" value={search} onChange={(e) => setSearch(e.target.value)} aria-label="Поиск кейса" />
        </label>
      </div>
      {groups.length === 0 && <p className="hint">Ничего не нашли</p>}
      <div ref={casesRef} className="home__grids">
        {shown.map((g) => (
          <section key={g.key} className="home__cases" aria-labelledby={`cases-${g.key}`}>
          <h2 id={`cases-${g.key}`} className="section-title">
            {g.title}
          </h2>
          <div className="cases">
            {g.cases.map((c, i) => (
              <a
                key={c.id}
                className={cx('case-card', c.kind === 'tickets' && 'case-card--tickets', c.badge && `case-card--${c.badge}`, c.priceCycle && 'case-card--floating')}
                href={routeHref('case', c.id)}
                style={{ animationDelay: `${Math.min(i, 8) * 40}ms` }}
                data-tour={i === 0 && g === shown[0] ? 'case-grid' : undefined}
              >
                {c.badge && <span className="case-card__badge">{c.badge === 'new' ? 'Новый' : 'Редизайн'}</span>}
                {(me.caseKeys[c.id] ?? 0) > 0 && <span className="case-card__gift">🎁 ×{me.caseKeys[c.id]}</span>}
                <span className="case-card__count">{c.items.length} предм.</span>
                <span className="case-card__stage">
                  <CaseArt kase={c} className="case-card__art" lazy />
                  <CaseWalkers kase={c} />
                  {c.priceHistory && c.priceHistory.length > 1 && <PriceChart prices={c.priceHistory} className="case-card__chart" />}
                </span>
                <span className="case-card__name">{c.name}</span>
                {c.kind === 'tickets' ? (
                  <span className="case-card__price case-card__price--tickets">
                    <Ticket size={17} /> {formatCoins(c.ticketPrice ?? 0)}
                  </span>
                ) : (
                  <span className="case-card__price">
                    <Coin size={16} /> {formatCoins(c.price)}
                    {c.priceHistory && <PriceTrend prices={c.priceHistory} />}
                  </span>
                )}
              </a>
            ))}
          </div>
          </section>
        ))}
      </div>
    </div>
  );
}
