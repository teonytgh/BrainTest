import { describe, expect, it } from 'vitest';
import { afterResponse, broadcast, liveTicket, markViewer, touch, verifyLiveTicket, withLiveScope } from './live';

describe('live updates', () => {
  it('collects the players a request changed, without the one who made it', async () => {
    const s = await withLiveScope(async () => {
      markViewer(1);
      touch(1, 'me');
      touch(2, 'me');
      touch(2, 'itemDeposit');
      touch(3);
      return 'done';
    });
    expect(s.result).toBe('done');
    expect(await s.settle()).toEqual([
      { userId: 2, topics: ['me', 'itemDeposit'] },
      { userId: 3, topics: ['me'] },
    ]);
  });

  it('waits for background work (and what it touches) before listing pushes', async () => {
    let ran = false;
    const s = await withLiveScope(async () => {
      await afterResponse(async () => {
        await new Promise((r) => setTimeout(r, 20));
        ran = true;
        touch(7, 'bonuses');
      });
      return ran;
    });
    expect(s.result).toBe(false); // the response did not wait
    expect(await s.settle()).toEqual([{ userId: 7, topics: ['bonuses'] }]);
    expect(ran).toBe(true);
  });

  it('outside a live scope background work just runs inline and touches are ignored', async () => {
    let ran = false;
    touch(5, 'me');
    await afterResponse(async () => {
      ran = true;
    });
    expect(ran).toBe(true);
  });

  it('catalog edits go to every open app, the editor included', async () => {
    const s = await withLiveScope(async () => {
      markViewer(1);
      broadcast('catalog');
      touch(2, 'me');
    });
    expect(await s.settle()).toEqual([
      { userId: null, topics: ['catalog'] },
      { userId: 2, topics: ['me'] },
    ]);
  });

  it('socket tickets are signed, bound to the player and short-lived', () => {
    const now = Date.now();
    const t = liveTicket(42, now);
    expect(verifyLiveTicket(t, now)).toBe(42);
    expect(verifyLiveTicket(t, now + 61_000)).toBeNull();
    expect(verifyLiveTicket(t.replace(/^42\./, '43.'), now)).toBeNull();
    expect(verifyLiveTicket('garbage', now)).toBeNull();
  });
});
