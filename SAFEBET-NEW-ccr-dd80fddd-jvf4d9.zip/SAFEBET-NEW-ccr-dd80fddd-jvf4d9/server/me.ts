import { rankOf } from '../shared/ranks';
import { ms, num, one, q } from './db';
import { tacosActive } from '../shared/tacos';
import { currentPromo } from '../shared/promo';
import type { Viewer } from './auth';
import type { UserRow } from './users';
import { resolveStaleCrash } from './crash';
import { SETTINGS_COLUMNS, luckState, settingsFromRow, type SettingsRow } from './settings';

export interface TitleView {
  id: number;
  name: string;
  description: string;
  icon: string;
  color: string;
  grantedAt: number;
  holders: number;
  /** Share of all players who hold it, % (the card says «Есть у N% игроков»). */
  percent: number;
}

/** A title's share of players, % with one decimal under 10 %. */
const PERCENT_SQL = (holders: string) => `round(100.0 * ${holders} / greatest(1, (SELECT count(*) FROM users)), 1)`;

export async function userTitles(userId: number): Promise<TitleView[]> {
  const rows = await q<{ id: string; name: string; description: string; icon: string; color: string; created_at: string; holders: string; percent: string }>(
    `SELECT t.id, t.name, t.description, t.icon, t.color, ut.created_at,
       (SELECT count(*) FROM user_titles x WHERE x.title_id = t.id) AS holders,
       ${PERCENT_SQL('(SELECT count(*) FROM user_titles x WHERE x.title_id = t.id)')} AS percent
     FROM user_titles ut JOIN titles t ON t.id = ut.title_id
     WHERE ut.user_id = $1 ORDER BY ut.created_at`,
    [userId],
  );
  return rows.map((r) => ({
    id: num(r.id),
    name: r.name,
    description: r.description,
    icon: r.icon,
    color: r.color,
    grantedAt: ms(r.created_at)!,
    holders: num(r.holders),
    percent: num(r.percent),
  }));
}

interface MeRow {
  user: UserRow;
  /** Everything ever deposited (Stars + brainrot deposits, credited coins): the brainrot rank. */
  deposited: string | number;
  inventory: { id: number; brainrot_id: string; withdrawal_id: number | null; demo?: boolean }[];
  titles: { id: number; name: string; description: string; icon: string; color: string; created_at: string; holders: number; percent: number }[];
  bonus: { status: string; percent: number } | null;
  crash: { id: number; brainrot_id: string; stake_value: number; auto_cashout: number | null; started_at: string } | null;
  best: string | null;
  keys: { case_id: string; count: number; demo?: number }[];
  consolations: number[];
  settings: SettingsRow;
  rev: number;
}

/**
 * Everything about the player in ONE round trip: on Workers every query is a trip to the database, and the profile
 * comes back with every game action.
 */
const ME_SQL = `
  SELECT row_to_json(u) AS user,
    (SELECT coalesce(sum(p.credited), 0) FROM star_payments p WHERE p.user_id = u.id)
      + (SELECT coalesce(sum(d.credited), 0) FROM item_deposits d WHERE d.user_id = u.id AND d.status = 'credited') AS deposited,
    (SELECT coalesce(json_agg(json_build_object('id', i.id, 'brainrot_id', i.brainrot_id, 'withdrawal_id', i.withdrawal_id, 'demo', i.demo) ORDER BY i.id DESC), '[]'::json)
       FROM inventory i WHERE i.user_id = u.id) AS inventory,
    (SELECT coalesce(json_agg(json_build_object('id', t.id, 'name', t.name, 'description', t.description, 'icon', t.icon, 'color', t.color,
        'created_at', ut.created_at, 'holders', (SELECT count(*) FROM user_titles x WHERE x.title_id = t.id),
        'percent', ${PERCENT_SQL('(SELECT count(*) FROM user_titles x WHERE x.title_id = t.id)')}) ORDER BY ut.created_at), '[]'::json)
       FROM user_titles ut JOIN titles t ON t.id = ut.title_id WHERE ut.user_id = u.id) AS titles,
    (SELECT json_build_object('status', a.status, 'percent', a.percent) FROM auto_promo_uses a WHERE a.user_id = u.id AND a.window_index = $2) AS bonus,
    (SELECT json_build_object('id', c.id, 'brainrot_id', c.brainrot_id, 'stake_value', c.stake_value, 'auto_cashout', c.auto_cashout, 'started_at', c.started_at)
       FROM crash_rounds c WHERE c.user_id = u.id AND c.status = 'flying' LIMIT 1) AS crash,
    (SELECT d.brainrot_id FROM drops d JOIN brainrots b ON b.id = d.brainrot_id
       WHERE d.user_id = u.id AND d.result = 'win' ORDER BY b.price DESC, d.created_at DESC LIMIT 1) AS best,
    (SELECT coalesce(json_agg(json_build_object('case_id', k.case_id, 'count', k.count, 'demo', k.demo_count)), '[]'::json) FROM case_keys k WHERE k.user_id = u.id AND k.count > 0) AS keys,
    (SELECT coalesce(json_agg(x.id ORDER BY x.id), '[]'::json)
       FROM (SELECT id FROM consolations WHERE user_id = u.id AND opened_at IS NULL ORDER BY id LIMIT 10) x) AS consolations,
    (SELECT row_to_json(s) FROM (SELECT ${SETTINGS_COLUMNS}) s) AS settings,
    (extract(epoch FROM clock_timestamp()) * 1000)::float8 AS rev
  FROM users u WHERE u.id = $1`;

export async function buildMe(v: Viewer) {
  const promo = currentPromo();
  const load = () => one<MeRow>(ME_SQL, [v.id, promo.windowIndex]);
  // The settings ride in the same statement: a second query in parallel would open a second connection to the
  // database (a handshake costs more than the query).
  let row = await load();
  // A crash round still «flying» may have crashed long ago (the player left): settle it, then read again.
  if (row?.crash) {
    await resolveStaleCrash(v.id);
    row = await load();
  }
  const user = row?.user;
  const settings = settingsFromRow(row?.settings);
  const inventory = row?.inventory ?? [];
  const titles: TitleView[] = (row?.titles ?? []).map((t) => ({
    id: num(t.id),
    name: t.name,
    description: t.description,
    icon: t.icon,
    color: t.color,
    grantedAt: ms(t.created_at)!,
    holders: num(t.holders),
    percent: num(t.percent),
  }));
  const bonus = row?.bonus ?? null;
  const crash = row?.crash ?? null;
  const best = row?.best ? { brainrot_id: row.best } : null;
  const keys = row?.keys ?? [];
  const consolations = (row?.consolations ?? []).map((id) => ({ id }));
  if (!user) throw new Error('user vanished');
  return {
    user: {
      id: num(user.id),
      publicId: user.public_id,
      username: user.username,
      name: [user.first_name, user.last_name].filter(Boolean).join(' ') || user.username || 'Игрок',
      photoUrl: user.photo_url,
      balance: num(user.balance),
      /** The demo part of the balance (iteration 35): spent first, what it buys is «ДЕМО». */
      demoBalance: num(user.demo_balance ?? 0),
      /** «Отыгрыш» (iteration 36): what is left to play before a withdrawal, and the whole of the current round. */
      wager: { left: num(user.wager_left ?? 0), total: num(user.wager_total ?? 0) },
      isAdmin: v.isAdmin,
      isOwner: v.isOwner,
      media: user.media_platform,
      frozen: v.frozen,
      /** 18+ confirmed and the current documents accepted; the app shows the consent screen until then. */
      termsOk: v.termsOk,
      /** Accepted an older version: the consent screen says what changed. */
      termsUpdated: !v.termsOk && Number(user.terms_version ?? 0) > 0,
      /** The brainrot rank (shared/ranks.ts) from everything deposited. */
      rank: rankOf(num(row?.deposited)).level,
      /** Everything deposited (the rank's progress). */
      deposited: num(row?.deposited),
      /** Quest tickets (spent on the ticket cases). */
      tickets: num(user.tickets ?? 0),
      /** The Meowl tour was done or skipped (true until its migration ran, so nobody sees a half-ready tour). */
      onboarded: user.onboarded_at === undefined ? true : user.onboarded_at !== null,
      freeCaseAt: ms(user.free_case_at),
      nickCaseAt: ms(user.nick_case_at),
      refBalance: num(user.ref_balance),
      bestDrop: best?.brainrot_id ?? null,
      stats: {
        casesOpened: user.cases_opened,
        upgrades: user.upgrades,
        diceRolls: user.dice_rolls,
        crashRounds: user.crash_rounds,
        withdrawn: num(user.withdrawn_value),
      },
      titles,
    },
    /** `withdrawalId`: the item is locked on that withdrawal («НА ВЫВОДЕ»); `demo`: «ДЕМО», never withdrawn. */
    inventory: inventory.map((i) => ({
      id: num(i.id),
      brainrotId: i.brainrot_id,
      withdrawalId: i.withdrawal_id === null ? null : num(i.withdrawal_id),
      demo: i.demo === true,
    })),
    /** Unopened consolation spins (from big upgrade losses). */
    consolations: consolations.map((c) => num(c.id)),
    promo: {
      code: promo.code,
      percent: promo.percent,
      endsAt: promo.endsAt,
      bonus: bonus ? { status: bonus.status as 'active' | 'used', percent: bonus.percent } : null,
    },
    crash: crash
      ? {
          roundId: num(crash.id),
          brainrotId: crash.brainrot_id,
          stakeValue: num(crash.stake_value),
          auto: crash.auto_cashout === null ? null : Number(crash.auto_cashout),
          startedAt: ms(crash.started_at)!,
        }
      : null,
    // Test top-ups mint coins: shown to admins only (the server refuses them for everyone else).
    starRate: settings.starRate,
    withdrawRules: settings.withdrawRules,
    luckUntil: settings.luckUntil,
    /** The strongest running luck event (x2 / x4 / x8) and its end, or null. */
    luck: luckState(settings),
    /** The «Raining Tacos» party while it runs (its end), else null. */
    tacos: tacosActive(settings.tacos) ? { endsAt: settings.tacos.endsAt } : null,
    caseKeys: Object.fromEntries(keys.map((k) => [k.case_id, k.count])) as Record<string, number>,
    /** How many of those gift openings are demo (used first). */
    demoKeys: Object.fromEntries(keys.filter((k) => (k.demo ?? 0) > 0).map((k) => [k.case_id, k.demo ?? 0])) as Record<string, number>,
    maintenance: v.isAdmin ? settings.maintenance : { enabled: false, message: '' },
    serverNow: Date.now(),
    /**
     * When the database read this state (ms, sub-ms precision): the app never replaces a profile with an older one —
     * a poll or live refetch read before the last action used to land after it and bring spent items back.
     */
    rev: Number(row?.rev ?? Date.now()),
  };
}

export type Me = Awaited<ReturnType<typeof buildMe>>;
