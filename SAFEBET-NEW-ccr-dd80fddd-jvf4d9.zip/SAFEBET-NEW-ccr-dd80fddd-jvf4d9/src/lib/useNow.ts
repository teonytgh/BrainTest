import { createElement, useEffect, useState } from 'react';

export function useNow(intervalMs: number): number {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), intervalMs);
    return () => clearInterval(id);
  }, [intervalMs]);
  return now;
}

/**
 * Whether the moment `at` has come: re-renders once, when it comes — not every second (iteration 40: the home page
 * used to re-render its whole case grid every second for a few countdowns).
 */
export function useReached(at: number | null | undefined): boolean {
  const [, bump] = useState(0);
  const reached = at == null || at <= Date.now();
  useEffect(() => {
    if (at == null) return;
    const left = at - Date.now();
    if (left <= 0) return;
    // setTimeout tops out at ~24.8 days.
    const id = setTimeout(() => bump((n) => n + 1), Math.min(left + 30, 2 ** 31 - 1));
    return () => clearTimeout(id);
  }, [at]);
  return reached;
}

/** A ticking countdown that re-renders only its own text. */
export function Countdown({ to, format }: { to: number; format: (ms: number) => string }) {
  const now = useNow(1000);
  return createElement('span', { className: 'countdown' }, format(Math.max(0, to - now)));
}
