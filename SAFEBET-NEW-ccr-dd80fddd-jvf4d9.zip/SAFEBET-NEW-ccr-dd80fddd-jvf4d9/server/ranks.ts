import { RANKS, RANK_GIFT_TURNOVER, nextRank, rankOf } from '../shared/ranks';
import { payoutFor } from '../shared/payout';
import { HOUSE_GAMES } from '../shared/bonuses';
import { assertActive, type Viewer } from './auth';
import { ensureSchema } from './autoMigrate';
import { activeBrainrots } from './catalog';
import { num, one, tx, type Queryable } from './db';
import { addWager, payOut } from './economy';
import { bad } from './errors';
import { int } from './validate';

const HOUSE = HOUSE_GAMES.map((g) => `'${g}'`).join(', ');

/** Everything a player has deposited (credited coins) and played in the house's games — what ranks are made of. */
export const PLAYER_TOTALS = `
  (SELECT coalesce(sum(p.credited), 0) FROM star_payments p WHERE p.user_id = $1)
    + (SELECT coalesce(sum(d.credited), 0) FROM item_deposits d WHERE d.user_id = $1 AND d.status = 'credited') AS deposited,
  (SELECT coalesce(sum(dr.stake_value), 0) FROM drops dr WHERE dr.user_id = $1 AND dr.game IN (${HOUSE}) AND dr.stake_value > 0 AND NOT dr.demo) AS played`;

export async function totalsOf(c: Queryable, userId: number) {
  const { rows } = await c.query<{ deposited: string; played: string }>(`SELECT ${PLAYER_TOTALS}`, [userId]);
  return { deposited: num(rows[0]?.deposited), played: num(rows[0]?.played) };
}

/** The player's brainrot rank: progress to the next one and every rank's gift (locked / ready / taken). */
export async function rankState(v: Viewer) {
  await ensureSchema();
  const row = await one<{ deposited: string; played: string; gifts: number[] | null }>(
    `SELECT ${PLAYER_TOTALS}, (SELECT array_agg(rank) FROM rank_gifts WHERE user_id = $1) AS gifts`,
    [v.id],
  );
  const deposited = num(row?.deposited);
  const played = num(row?.played);
  const rank = rankOf(deposited);
  const next = nextRank(rank);
  const taken = new Set(row?.gifts ?? []);
  return {
    rank: rank.level,
    deposited,
    played,
    next: next ? { level: next.level, from: next.from } : null,
    gifts: RANKS.filter((r) => r.gift > 0).map((r) => ({
      level: r.level,
      gift: r.gift,
      needPlayed: r.from * RANK_GIFT_TURNOVER,
      taken: taken.has(r.level),
      reached: rank.level >= r.level,
      ready: rank.level >= r.level && played >= r.from * RANK_GIFT_TURNOVER && !taken.has(r.level),
    })),
  };
}

/**
 * A rank's one-time gift: a brainrot worth 1 % of its threshold (+ change), once the rank is reached and the player
 * has played RANK_GIFT_TURNOVER × the threshold in cases and battles. The primary key makes a second one impossible.
 */
export async function claimRankGift(v: Viewer, levelParam: unknown) {
  assertActive(v);
  await ensureSchema();
  const level = int(levelParam, 'ранг', 1, RANKS.length - 1);
  const r = RANKS[level]!;
  return tx(async (c) => {
    await c.query('SELECT 1 FROM users WHERE id = $1 FOR UPDATE', [v.id]);
    const totals = await totalsOf(c, v.id);
    if (rankOf(totals.deposited).level < level) throw bad('rank_locked', `Подарок откроется на ранге «${r.name}»`);
    if (totals.played < r.from * RANK_GIFT_TURNOVER) {
      throw bad('need_play', `Подарок откроется, когда сыграешь в кейсах и батлах на ${(r.from * RANK_GIFT_TURNOVER).toLocaleString('ru-RU')} B`);
    }
    const payout = payoutFor(r.gift, await activeBrainrots(c));
    const ins = await c.query(
      'INSERT INTO rank_gifts (user_id, rank, brainrot_id, coins, value) VALUES ($1, $2, $3, $4, $5) ON CONFLICT DO NOTHING RETURNING 1',
      [v.id, level, payout.brainrot?.id ?? null, payout.coins, payout.value],
    );
    if (!ins.rows.length) throw bad('claimed', 'Подарок этого ранга уже получен');
    const itemId = await payOut(c, v.id, payout, `rank:${level}`);
    await addWager(c, v.id, payout.value, 'bonus');
    return { level, brainrotId: payout.brainrot?.id ?? null, coins: payout.coins, value: payout.value, itemId };
  });
}

/** Cashback percent for a player now (their rank's). */
export async function cashbackPercent(c: Queryable, userId: number) {
  return rankOf((await totalsOf(c, userId)).deposited).cashback;
}
