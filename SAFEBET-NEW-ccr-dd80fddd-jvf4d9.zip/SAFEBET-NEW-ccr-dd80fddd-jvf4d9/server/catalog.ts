import { db, num, one, q, type Queryable } from './db';
import { solveCaseChances } from '../shared/cases';
import { bad } from './errors';
import type { Brainrot, BrainrotStatus, CaseDef, CaseItem, CaseSection } from '../shared/types';
import { getSettings, luckMultiplier } from './settings';
import { notStaff } from './staff';

interface BrainrotRow {
  id: string;
  name: string;
  price: string;
  image: string;
  status: BrainrotStatus;
  withdrawable: boolean;
  kind?: 'brainrot' | 'coins';
}

export const toBrainrot = (r: BrainrotRow): Brainrot => ({
  id: r.id,
  name: r.name,
  price: num(r.price),
  image: r.image,
  status: r.status,
  withdrawable: r.withdrawable !== false,
  kind: r.kind === 'coins' ? 'coins' : 'brainrot',
});

export async function allBrainrots(db?: Queryable): Promise<Brainrot[]> {
  const sql = 'SELECT id, name, price, image, status, withdrawable, kind FROM brainrots ORDER BY price, name';
  const rows = db ? (await db.query<BrainrotRow>(sql)).rows : await q<BrainrotRow>(sql);
  return rows.map(toBrainrot);
}

/** Brainrots that payouts, the shop, upgrades and fuses may hand out (coin prizes only ever drop from cases). */
export async function activeBrainrots(db: Queryable): Promise<Brainrot[]> {
  const { rows } = await db.query<BrainrotRow>(`SELECT id, name, price, image, status, withdrawable, kind FROM brainrots WHERE status = 'active' AND kind = 'brainrot'`);
  return rows.map(toBrainrot);
}

interface CaseRow {
  id: string;
  name: string;
  price: string;
  image: string;
  kind: 'paid' | 'free' | 'bonus' | 'tickets';
  bonus: 'referral' | 'nick' | null;
  /** Only once iteration 32's migration ran (SELECT *). */
  ticket_price?: number | null;
  status: 'active' | 'hidden';
  sort: number;
  mystery: boolean;
  section_id: string | null;
  /** Iteration 35 (SELECT *, once its migration ran). */
  badge?: 'new' | 'redesign' | null;
  badge_until?: string | null;
  price_cycle?: string[] | null;
}

interface ItemRow {
  brainrotId: string;
  price: number;
  fixed: number | null;
}

/**
 * Chances come from current prices (solveChances), so a price edit in the catalog re-balances every case;
 * chances the admin set by hand stay exactly as set and the rest share what is left.
 */
function withChances(items: ItemRow[], casePrice: number, luck: number, cut: number) {
  const solution = solveCaseChances(
    items.map((i) => i.price),
    items.map((i) => i.fixed),
    casePrice,
    luck,
    cut,
  );
  return { solution, items: items.map((i, k): CaseItem => ({ brainrotId: i.brainrotId, weight: solution.probs[k]!, fixed: i.fixed })) };
}

const fixedOf = (v: string | null) => (v === null ? null : Number(v));

/**
 * Players never get the real chances. The reel filler weight depends only on the price rank (cheapest = most
 * often on the reel), which tells nothing the prices don't already show. Items a case can't actually drop
 * right now (chance squeezed to zero) are left out of the prize list.
 */
function reelWeights(items: { brainrotId: string; price: number }[], table: CaseItem[]): CaseItem[] {
  const real = new Map(table.map((t) => [t.brainrotId, t.weight]));
  const live = items.filter((i) => (real.get(i.brainrotId) ?? 0) > 1e-7).sort((a, b) => a.price - b.price);
  const total = (live.length * (live.length + 1)) / 2 || 1;
  return live.map((i, rank) => ({ brainrotId: i.brainrotId, weight: Math.round(((live.length - rank) / total) * 10_000) / 10_000 }));
}

/** `forAdmin` adds hidden cases and the real chances; players get reel weights only. */
export async function allCases(forAdmin: boolean): Promise<CaseDef[]> {
  const [cases, items, settings, history] = await Promise.all([
    q<CaseRow>(`SELECT * FROM cases ${forAdmin ? '' : `WHERE status = 'active'`} ORDER BY sort, price`),
    q<{ case_id: string; brainrot_id: string; price: string; fixed_chance: string | null }>(
      `SELECT ci.case_id, ci.brainrot_id, b.price, ci.fixed_chance FROM case_items ci
       JOIN brainrots b ON b.id = ci.brainrot_id
       WHERE b.status IN ('active', 'hidden') ORDER BY b.price`,
    ),
    getSettings(),
    // The last prices of floating-price cases (the «Биткоин» chart), oldest first.
    q<{ case_id: string; price: string }>(
      `SELECT case_id, price FROM (
         SELECT case_id, price, id, row_number() OVER (PARTITION BY case_id ORDER BY id DESC) AS n FROM case_price_history
       ) h WHERE n <= ${PRICE_HISTORY} ORDER BY case_id, id`,
    ).catch(() => []),
  ]);
  const luck = luckMultiplier(settings);
  const cut = settings.okupCut.factor;
  return cases.map((c) => {
    const price = num(c.price);
    const own = items.filter((i) => i.case_id === c.id).map((i) => ({ brainrotId: i.brainrot_id, price: num(i.price), fixed: fixedOf(i.fixed_chance) }));
    const table = withChances(own, price, luck, cut).items;
    return {
      id: c.id,
      name: c.name,
      price,
      image: c.image,
      kind: c.kind,
      bonus: c.bonus,
      ticketPrice: c.ticket_price ?? null,
      status: c.status,
      sort: c.sort,
      mystery: c.mystery,
      sectionId: c.section_id === null ? null : num(c.section_id),
      badge: badgeOf(c),
      badgeUntil: forAdmin && c.badge_until ? new Date(c.badge_until).getTime() : null,
      priceCycle: c.price_cycle?.length ? c.price_cycle.map(num) : null,
      priceHistory: c.price_cycle?.length ? history.filter((h) => h.case_id === c.id).map((h) => num(h.price)) : null,
      items: forAdmin ? table : reelWeights(own, table).map(({ brainrotId, weight }) => ({ brainrotId, weight })),
    };
  });
}

/** Points on the floating-price chart. */
const PRICE_HISTORY = 12;

/** «НОВЫЙ» / «РЕДИЗАЙН» while it lasts. */
const badgeOf = (c: CaseRow): CaseDef['badge'] => (c.badge && c.badge_until && new Date(c.badge_until).getTime() > Date.now() ? c.badge : null);

export async function caseSections(): Promise<CaseSection[]> {
  const rows = await q<{ id: string; title: string; sort: number }>('SELECT id, title, sort FROM case_sections ORDER BY sort, id');
  return rows.map((r) => ({ id: num(r.id), title: r.title, sort: r.sort }));
}

/** Everything needed to roll one case inside a transaction. */
export async function caseDropTable(c: Queryable, caseId: string) {
  const { rows } = await c.query<CaseRow>(`SELECT * FROM cases WHERE id = $1 AND status = 'active'`, [caseId]);
  const kase = rows[0];
  if (!kase) return null;
  const items = (
    await c.query<{ brainrot_id: string; price: string; fixed_chance: string | null }>(
      `SELECT ci.brainrot_id, b.price, ci.fixed_chance FROM case_items ci JOIN brainrots b ON b.id = ci.brainrot_id
       WHERE ci.case_id = $1 AND b.status IN ('active', 'hidden') ORDER BY b.price`,
      [caseId],
    )
  ).rows.map((i) => ({ brainrotId: i.brainrot_id, price: num(i.price), fixed: fixedOf(i.fixed_chance) }));
  const price = num(kase.price);
  const settings = await getSettings(c);
  const priceOf = new Map(items.map((i) => [i.brainrotId, i.price]));
  const { solution, items: table } = withChances(items, price, luckMultiplier(settings), settings.okupCut.factor);
  // A case whose every item costs more than the case would pay out at a loss; the healer fixes it within a minute.
  // Hand-set chances are the admin's decision: such a case opens as configured.
  const losing = price > 0 && !solution.manual && solution.rtp > 1;
  // «Невозможно» (and chances squeezed to zero) never roll; a case left with nothing droppable is empty.
  const droppable = table.filter((i) => i.weight > 0);
  // A floating price («Биткоин») may move while a battle waits: such a case stays out of battles.
  const floating = !!kase.price_cycle?.length;
  return { id: kase.id, name: kase.name, kind: kase.kind, bonus: kase.bonus, price, ticketPrice: kase.ticket_price ?? null, mystery: kase.mystery, items: droppable, priceOf, losing, floating };
}

/** The best drop of the last day. The player is shown by the name they set in Telegram, never by @username. */
export async function topDrop24h() {
  const rows = await q<{ brainrot_id: string; first_name: string; last_name: string | null; public_id: string; photo_url: string | null; created_at: string }>(
    `SELECT d.brainrot_id, u.first_name, u.last_name, u.public_id, u.photo_url, d.created_at FROM drops d
     JOIN brainrots b ON b.id = d.brainrot_id JOIN users u ON u.id = d.user_id
     WHERE d.result = 'win' AND NOT d.demo AND d.created_at > now() - interval '24 hours'
       -- «Очистить топ дроп дня» (iteration 41): only drops after the admin's reset count; the drops stay in the history.
       AND d.created_at > coalesce((SELECT to_timestamp((value #>> '{}')::double precision / 1000) FROM settings WHERE key = 'top_drop_since'), '-infinity')
       AND ${notStaff('d.user_id')}
     ORDER BY b.price DESC, d.created_at DESC LIMIT 1`,
  );
  const r = rows[0];
  return r
    ? { brainrotId: r.brainrot_id, player: publicName(r), playerId: r.public_id, photo: r.photo_url, at: new Date(r.created_at).getTime() }
    : null;
}

/** What other players see: first + last name from Telegram (the @username stays private). */
export const publicName = (u: { first_name: string; last_name: string | null }) => [u.first_name, u.last_name].filter(Boolean).join(' ').trim() || 'Игрок';

export const rebalancing = () => bad('case_rebalancing', 'Кейс обновляется под новые цены — загляни через минуту');

/**
 * The catalog is the same for every player and the heaviest read (every case's chances are solved from prices). Each
 * Worker isolate keeps one copy and rebuilds it when an admin edit or a heal bumps `catalog_version`, or after a minute
 * (the top drop moves on; the LIVE feed updates it on the client in between). At launch an admin edit made every open
 * app refetch the catalog at once and the rebuilds ran the database out of connections.
 */
let cached: { version: string; at: number; value: unknown } | null = null;
const CATALOG_TTL_MS = 60_000;

export async function cachedCatalog<T>(build: () => Promise<T>): Promise<T> {
  const row = await one<{ v: string | null }>(`SELECT value::text AS v FROM settings WHERE key = 'catalog_version'`);
  const version = row?.v ?? '0';
  if (cached && cached.version === version && Date.now() - cached.at < CATALOG_TTL_MS) return cached.value as T;
  const value = await build();
  cached = { version, at: Date.now(), value };
  return value;
}

/** Every isolate rebuilds its copy on the next request. */
export async function bumpCatalogVersion(c: Queryable = db) {
  cached = null;
  await c.query(
    `INSERT INTO settings (key, value) VALUES ('catalog_version', to_jsonb($1::text))
     ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value`,
    [String(Date.now())],
  );
}

