import { useEffect, useMemo, useRef, useState, type CSSProperties, type RefObject } from 'react';
import { CaseArt } from './CaseArt';
import { Coin } from './Coin';
import { Burst, Confetti, CountUp, Twinkles } from './Fx';
import { Icon } from './Icon';
import type { Brainrot, CaseDef } from '../../shared/types';
import { round2 } from '../../shared/money';
import { errorMessage } from '../api/client';
import { act, setMe, type Me } from '../api/queries';
import { cx, formatCoins, plural } from '../lib/format';
import { buildReel } from '../lib/reel';
import { sfx } from '../lib/sound';
import { haptic } from '../lib/telegram';
import { TIER_LABEL, tierOf } from '../lib/tier';
import { useReelSpin } from '../lib/useReelSpin';
import { toast } from '../store/toast';
import { ShareWinButton } from './ShareWin';
import { DemoTag } from './DemoTag';

export type OpenMode = 'slow' | 'fast' | 'skip';

/** One drop of an opening. `itemId` is null for a coin prize: it is already on the balance, there is nothing to sell. */
export interface CaseWin {
  won: Brainrot;
  itemId: number | null;
}

const REEL_LENGTH = 64;
const WIN_INDEX = 54;
/** Card width (104) plus the gap (8). */
const STEP = 112;
/** Several reels at once: shorter strips of smaller cards (72 + 8), so up to five fit on a phone. */
const COMPACT = { length: 48, winIndex: 40, step: 80 };
const TIMING: Record<Exclude<OpenMode, 'skip'>, { intro: number; spin: number; reveal: number }> = {
  slow: { intro: 1700, spin: 7000, reveal: 1100 },
  fast: { intro: 650, spin: 2400, reveal: 650 },
};

interface Props {
  kase: CaseDef;
  pool: { brainrot: Brainrot; weight: number }[];
  /** One drop per opened case, in the order the server rolled them. */
  wins: CaseWin[];
  /** Paid with demo coins or a demo key: the drops are «ДЕМО» (never withdrawn, sold for demo coins). */
  demo?: boolean;
  me: Me;
  mode: OpenMode;
  /** What the second button does: spin the same case again, top up first, or just finish (free case). */
  again: 'spin' | 'deposit' | 'none';
  /** 0 when the next spin is a gift opening. */
  againPrice: number;
  /** How many cases «Крутить ещё» opens. */
  againCount: number;
  /** What the player lacks for the next spin, said on «Пополнить». */
  againShort: number;
  againBusy: boolean;
  onAgain: () => void;
  onDeposit: () => void;
  onClose: () => void;
}

type Phase = 'intro' | 'spin' | 'reveal' | 'result';

const isBig = (b: Brainrot, kase: CaseDef) => {
  const tier = tierOf(b.price);
  return tier === 'secret' || tier === 'legendary' || b.price >= kase.price * 3;
};

/**
 * The opening show: the chest charges up and bursts open in a flash; the reel flies, slows down with the light
 * shifting to the colour of the card under the marker, overshoots a little and settles; the drop explodes in its
 * rarity colour (confetti for the big ones) and the win card counts its price up. Several cases at once spin one
 * compact reel each, landing one after another, and end on one card with every drop.
 */
export function CaseOpening({ kase, pool, wins, demo, me, mode, again, againPrice, againCount, againShort, againBusy, onAgain, onDeposit, onClose }: Props) {
  const [phase, setPhase] = useState<Phase>(mode === 'skip' ? 'result' : 'intro');
  const [instant, setInstant] = useState(false);
  const [selling, setSelling] = useState(false);
  const [sold, setSold] = useState<ReadonlySet<number>>(() => new Set());
  const stage = useRef<HTMLDivElement>(null);
  const landedReels = useRef(new Set<number>());
  const timing = mode === 'skip' ? TIMING.fast : TIMING[mode];
  const multi = wins.length > 1;
  const best = wins.reduce((a, b) => (b.won.price > a.won.price ? b : a));
  const tier = tierOf(best.won.price);
  const big = wins.some((w) => isBig(w.won, kase));
  const total = round2(wins.reduce((s, w) => s + w.won.price, 0));
  const unsold = wins.filter((w) => w.itemId != null && !sold.has(w.itemId));
  const unsoldValue = round2(unsold.reduce((s, w) => s + w.won.price, 0));
  const coinValue = round2(wins.reduce((s, w) => s + (w.itemId == null ? w.won.price : 0), 0));

  useEffect(() => {
    if (phase === 'intro') {
      sfx.charge((timing.intro * 0.82) / 1000);
      const pop = setTimeout(() => {
        sfx.burstOpen();
        haptic('tap');
      }, timing.intro * 0.8);
      const next = setTimeout(() => setPhase('spin'), timing.intro);
      return () => {
        clearTimeout(pop);
        clearTimeout(next);
      };
    }
    if (phase === 'reveal') {
      sfx.reveal(tier);
      haptic(big ? 'success' : 'tap');
      const sparkle = big ? setTimeout(() => sfx.sparkle(), 380) : undefined;
      const t = setTimeout(() => setPhase('result'), timing.reveal);
      return () => {
        clearTimeout(t);
        if (sparkle) clearTimeout(sparkle);
      };
    }
    if (phase === 'result') {
      setMe(me);
      if (big) sfx.bigWin();
      else sfx.win();
      haptic('success');
    }
  }, [phase, timing.intro, timing.reveal, me, tier, big]);

  function skip() {
    if (phase === 'intro') {
      setInstant(true);
      setPhase('spin');
    } else if (phase === 'spin') setInstant(true);
  }

  // The reveal waits for the last reel (a skip lands the rest at once; a reel may report twice then).
  function reelLanded(i: number) {
    if (landedReels.current.has(i)) return;
    landedReels.current.add(i);
    if (landedReels.current.size >= wins.length) setPhase('reveal');
    else haptic('tap');
  }

  async function sell(items: CaseWin[], closeAfter: boolean) {
    const ids = items.flatMap((w) => (w.itemId == null || sold.has(w.itemId) ? [] : [w.itemId]));
    if (!ids.length) return onClose();
    setSelling(true);
    try {
      const r = await act<{ coins: number }>('/api/inventory/sell', { itemIds: ids });
      setMe(r.me);
      sfx.coin();
      toast(`+${formatCoins(r.result.coins)} B за ${ids.length === 1 ? items.find((w) => w.itemId === ids[0])!.won.name : `${ids.length} ${plural(ids.length, 'предмет', 'предмета', 'предметов')}`}`, 'success');
      if (closeAfter) return onClose();
      setSold((s) => new Set([...s, ...ids]));
    } catch (e) {
      toast(errorMessage(e), 'error');
    }
    setSelling(false);
  }

  const timingVars = { '--intro-ms': `${timing.intro}ms`, '--reveal-ms': `${timing.reveal}ms` } as CSSProperties;
  const single = wins[0]!;

  return (
    <div
      className={cx('opening', `opening--${phase}`, `tier-${tier}`, big && 'is-big', multi && 'is-multi')}
      style={timingVars}
      role="dialog"
      aria-modal="true"
      aria-label={multi ? `Открытие ${wins.length} ${plural(wins.length, 'кейса', 'кейсов', 'кейсов')} ${kase.name}` : `Открытие кейса ${kase.name}`}
    >
      {phase === 'intro' && (
        <div className="opening__intro" onClick={skip}>
          <span className="oi-rays" aria-hidden="true" />
          <span className="oi-pedestal" aria-hidden="true" />
          <span className="oi-glow" aria-hidden="true" />
          <span className="oi-case">
            <CaseArt kase={kase} />
          </span>
          {multi && (
            <span className="oi-count" aria-hidden="true">
              ×{wins.length}
            </span>
          )}
          <span className="oi-ring" aria-hidden="true" />
          <span className="oi-flash" aria-hidden="true" />
          <span className="oi-burst">
            <Burst count={30} spread={1.4} />
          </span>
          <p className="oi-name">{kase.name}</p>
        </div>
      )}

      {(phase === 'spin' || phase === 'reveal') && (
        <div className={cx('opening__stage', phase === 'reveal' && 'is-revealed', multi && 'is-multi')} ref={stage}>
          <p className="opening__title">{phase === 'reveal' ? TIER_LABEL[tier] : multi ? `${kase.name} ×${wins.length}` : kase.name}</p>
          {multi ? (
            <div className="opening__reels">
              {wins.map((w, i) => (
                <CaseReel
                  key={i}
                  pool={pool}
                  won={w.won}
                  mystery={kase.mystery}
                  compact
                  // Earlier reels land a little sooner, so the drops come in one after another; the last one clicks.
                  durationMs={timing.spin * (1 - (wins.length - 1 - i) * 0.06)}
                  running={phase === 'spin'}
                  instant={instant}
                  ticks={i === wins.length - 1}
                  burst={phase === 'reveal' && w === best ? (isBig(w.won, kase) ? 'big' : 'small') : null}
                  onLanded={() => reelLanded(i)}
                />
              ))}
            </div>
          ) : (
            <CaseReel
              pool={pool}
              won={single.won}
              mystery={kase.mystery}
              stage={stage}
              durationMs={timing.spin}
              running={phase === 'spin'}
              instant={instant}
              burst={phase === 'reveal' ? (big ? 'big' : 'small') : null}
              onLanded={() => reelLanded(0)}
            />
          )}
          {phase === 'spin' && (
            <button type="button" className="btn btn--ghost btn--sm opening__skip" onClick={skip}>
              Пропустить
            </button>
          )}
          {phase === 'reveal' && <span className="opening__flash" aria-hidden="true" />}
        </div>
      )}

      {phase === 'result' && (
        <>
          {big && <Confetti />}
          <div className={cx('win-card', `tier-${tier}`, multi && 'win-card--multi')}>
            <span className="win-card__rays" aria-hidden="true" />
            <Twinkles count={big ? 14 : 7} />
            <button
              type="button"
              className="icon-btn icon-btn--ghost win-card__close"
              aria-label={unsold.length ? 'Закрыть — предметы останутся в инвентаре' : 'Закрыть — монеты уже на балансе'}
              onClick={onClose}
              disabled={againBusy}
            >
              <Icon name="close" />
            </button>
            <p className="win-card__title">Вы выиграли!</p>
            <span className="win-card__tier">{multi ? `${wins.length} ${plural(wins.length, 'кейс', 'кейса', 'кейсов')} · лучший: ${TIER_LABEL[tier]}` : TIER_LABEL[tier]}</span>
            {demo && <DemoTag className="win-card__demo" />}
            {multi ? (
              <ul className="win-grid" aria-label="Дропы">
                {wins.map((w, i) => {
                  const isSold = w.itemId != null && sold.has(w.itemId);
                  return (
                    <li key={i} className={cx('win-grid__item', `tier-${tierOf(w.won.price)}`, w === best && 'is-best', isSold && 'is-sold')} style={{ '--i': i } as CSSProperties}>
                      <img className="win-grid__art" src={w.won.image} alt="" />
                      <span className="win-grid__name">{w.won.name}</span>
                      <span className="win-grid__price">
                        <Coin size={12} /> {formatCoins(w.won.price)}
                      </span>
                      {w.itemId == null ? (
                        <span className="win-grid__note">на балансе</span>
                      ) : isSold ? (
                        <span className="win-grid__note">продано</span>
                      ) : (
                        <button type="button" className="win-grid__sell" onClick={() => void sell([w], false)} disabled={selling || againBusy} aria-label={`Продать ${w.won.name}`}>
                          Продать
                        </button>
                      )}
                    </li>
                  );
                })}
              </ul>
            ) : (
              <>
                <span className="win-card__stage">
                  <img className="win-card__art" src={single.won.image} alt="" />
                </span>
                <p className="win-card__name">{single.won.name}</p>
              </>
            )}
            <p className="win-card__price">
              {multi && <span className="win-card__total">Итого</span>}
              <Coin size={18} /> <CountUp to={total} format={formatCoins} />
            </p>
            <div className="win-card__actions">
              {unsold.length ? (
                <button type="button" className={cx('btn btn--primary', multi && 'win-card__two')} onClick={() => void sell(unsold, true)} disabled={selling || againBusy} autoFocus>
                  {multi ? (
                    <>
                      {unsold.length > 1 ? 'Продать всё' : 'Продать'}
                      <span className="win-card__sub">
                        {formatCoins(unsoldValue)} <Coin size={13} />
                      </span>
                    </>
                  ) : (
                    <>
                      Продать <Coin size={16} /> {formatCoins(unsoldValue)}
                    </>
                  )}
                </button>
              ) : (
                <button type="button" className={cx('btn btn--primary', multi && !sold.size && 'win-card__two')} onClick={onClose} disabled={againBusy} autoFocus>
                  {sold.size ? (
                    'Готово'
                  ) : multi ? (
                    <>
                      Забрать
                      <span className="win-card__sub">
                        {formatCoins(total)} <Coin size={13} />
                      </span>
                    </>
                  ) : (
                    <>
                      Забрать <Coin size={16} /> {formatCoins(total)}
                    </>
                  )}
                </button>
              )}
              {again === 'spin' && (
                <button type="button" className="btn btn--ghost win-card__again" onClick={onAgain} disabled={selling || againBusy} aria-busy={againBusy}>
                  {againBusy ? 'Открываем…' : againCount > 1 ? `Крутить ещё ×${againCount}` : 'Крутить ещё'}
                  {!againBusy && (
                    <span className="win-card__again-price">
                      {againPrice > 0 ? (
                        <>
                          {formatCoins(againPrice)} <Coin size={13} />
                        </>
                      ) : (
                        'подарок'
                      )}
                    </span>
                  )}
                </button>
              )}
              {again === 'deposit' && (
                <button type="button" className="btn btn--ghost win-card__again" onClick={onDeposit} disabled={selling}>
                  Пополнить
                  {againShort > 0 && (
                    <span className="win-card__again-price">
                      не хватает {formatCoins(againShort)} <Coin size={13} />
                    </span>
                  )}
                </button>
              )}
              {again === 'none' && (
                <button type="button" className="btn btn--ghost" onClick={onClose} disabled={selling}>
                  Готово
                </button>
              )}
            </div>
            {/* A demo win isn't advertised (the server refuses to share it too). */}
            {!demo && <ShareWinButton className="win-card__share" />}
            <p className="win-card__hint">
              {coinValue > 0 && `+${formatCoins(coinValue)} B уже на балансе`}
              {coinValue > 0 && unsold.length > 0 && ' · '}
              {unsold.length > 0 && (unsold.length > 1 ? 'Предметы уже в инвентаре' : 'Предмет уже в инвентаре')}
              {!coinValue && !unsold.length && 'Монеты за проданное уже на балансе'}
            </p>
          </div>
        </>
      )}
    </div>
  );
}

interface ReelProps {
  pool: { brainrot: Brainrot; weight: number }[];
  won: Brainrot;
  mystery?: boolean;
  /** The smaller reel of a several-cases opening. */
  compact?: boolean;
  /** Gets the tier light of the card under the marker; by default the reel itself. */
  stage?: RefObject<HTMLElement | null>;
  durationMs: number;
  running: boolean;
  instant: boolean;
  ticks?: boolean;
  burst: 'big' | 'small' | null;
  onLanded: () => void;
}

/** One case reel: lands `won` under the marker and lights it up (a mystery card flips over then). */
function CaseReel({ pool, won, mystery, compact, stage, durationMs, running, instant, ticks, burst, onLanded }: ReelProps) {
  const root = useRef<HTMLDivElement>(null);
  const viewport = useRef<HTMLDivElement>(null);
  const track = useRef<HTMLDivElement>(null);
  const marker = useRef<HTMLSpanElement>(null);
  const [done, setDone] = useState(false);
  const { length, winIndex, step } = compact ? COMPACT : { length: REEL_LENGTH, winIndex: WIN_INDEX, step: STEP };
  const items = useMemo(() => buildReel(pool, length, winIndex, won), [pool, length, winIndex, won]);

  useReelSpin({
    viewport,
    track,
    stage: stage ?? root,
    marker,
    winIndex,
    step,
    durationMs,
    running,
    instant,
    ticks,
    onLanded: () => {
      setDone(true);
      onLanded();
    },
  });

  return (
    <div className={cx('reel reel--case', compact && 'reel--compact', compact && done && 'is-done')} ref={root}>
      <span className="reel__glow" aria-hidden="true" />
      <span className="reel__marker" ref={marker} aria-hidden="true" />
      {/* A fixed window with faded edges; the track moves inside it. */}
      <div className="reel__window" ref={viewport}>
        <div className="reel__track" ref={track}>
          {items.map((b, i) => {
            const reveal = done && i === winIndex;
            // Mystery cases show only glowing «?» until the winning card flips over on landing.
            if (mystery && !reveal) {
              return (
                <div key={i} className="reel__card reel__card--mystery" aria-hidden="true">
                  <span className="reel__q">?</span>
                </div>
              );
            }
            return (
              <div key={i} data-tier={tierOf(b.price)} className={cx('reel__card', `tier-${tierOf(b.price)}`, reveal && 'is-won', reveal && mystery && 'is-flipped')}>
                <img src={b.image} alt="" />
                <span>{b.name}</span>
              </div>
            );
          })}
        </div>
      </div>
      {burst && (
        <span className="reel__burst">
          <span className="reel__beams" aria-hidden="true" />
          <Burst count={burst === 'big' ? 36 : 22} spread={burst === 'big' ? 1.5 : 1} />
        </span>
      )}
    </div>
  );
}
