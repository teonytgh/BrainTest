import { queryOptions } from '@tanstack/react-query';
import { api } from '../api/client';
import { queryClient, type CatalogResponse } from '../api/queries';
import type { LiveDrop } from '../../server/liveDrops';
import { liveSocketOpen } from './socketState';

export type { LiveDrop };

/** How many drops the strip keeps. */
export const LIVE_KEEP = 20;

export { setLiveSocketOpen } from './socketState';

export const liveDropsQuery = queryOptions({
  queryKey: ['liveDrops'],
  queryFn: () => api<LiveDrop[]>('/api/drops/live'),
  staleTime: 5_000,
  // Pushes do the work while the socket is up; without one (local dev, a dropped connection) the list is polled —
  // gently: hundreds of apps polling every few seconds is what a crowd can't afford.
  refetchInterval: () => (liveSocketOpen() ? 120_000 : 15_000),
});

/** Newest first, no repeats, at most LIVE_KEEP. */
export function mergeDrops(fresh: LiveDrop[], old: LiveDrop[] = []): LiveDrop[] {
  const seen = new Set<number>();
  return [...fresh, ...old]
    .sort((a, b) => b.id - a.id)
    .filter((d) => (seen.has(d.id) ? false : (seen.add(d.id), true)))
    .slice(0, LIVE_KEEP);
}

/** Drops pushed over the socket: into the strip, and into «Топ дроп дня» when one beats it. */
export function receiveDrops(drops: LiveDrop[]) {
  if (!drops.length) return;
  queryClient.setQueryData<LiveDrop[]>(liveDropsQuery.queryKey, (old) => mergeDrops(drops, old ?? []));
  queryClient.setQueryData<CatalogResponse>(['catalog'], (cat) => {
    if (!cat) return cat;
    const price = (id: string) => cat.brainrots.find((b) => b.id === id)?.price ?? 0;
    const best = [...drops].sort((a, b) => price(b.brainrotId) - price(a.brainrotId))[0]!;
    if (cat.topDrop && price(cat.topDrop.brainrotId) >= price(best.brainrotId)) return cat;
    return { ...cat, topDrop: { brainrotId: best.brainrotId, player: best.player.name, playerId: best.player.publicId, photo: best.player.photo, at: best.at } };
  });
}
