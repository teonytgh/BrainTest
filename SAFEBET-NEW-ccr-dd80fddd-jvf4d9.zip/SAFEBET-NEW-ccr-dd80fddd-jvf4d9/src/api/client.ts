import { getInitData } from '../lib/telegram';
import { createStore, useStore } from '../store/createStore';

export class ApiError extends Error {
  constructor(
    public status: number,
    public code: string,
    message: string,
    public data: Record<string, unknown>,
  ) {
    super(message);
  }
}

export type Gate =
  | { kind: 'ok' }
  | { kind: 'banned'; until: number | null; reason: string | null }
  | { kind: 'maintenance'; message: string };

const gate = createStore<Gate>({ kind: 'ok' });
export const useGate = () => useStore(gate);

/** Answers index.html started before the JS arrived (the profile and the catalog), each used once. */
function bootResponse(path: string): Promise<Response> | null {
  const boot = (window as unknown as { __boot?: Record<string, Promise<Response> | undefined> }).__boot;
  const res = boot?.[path];
  if (!res) return null;
  delete boot[path];
  return res;
}

/** Anti-spam (the server's rule, checked here first): at most 8 actions a second leave this app. */
const ACTIONS_PER_SECOND = 8;
const recentActions: number[] = [];

function spamGuard() {
  const now = performance.now();
  while (recentActions.length && now - recentActions[0]! >= 1000) recentActions.shift();
  if (recentActions.length >= ACTIONS_PER_SECOND) throw new ApiError(429, 'too_fast', 'Не спамь — подожди секунду', {});
  recentActions.push(now);
}

/** Every call is signed with Telegram's initData; ban/maintenance answers switch the whole app to a gate screen. */
export async function api<T>(path: string, init: { method?: string; body?: unknown } = {}): Promise<T> {
  const initData = getInitData();
  if (!initData) throw new ApiError(401, 'no_telegram', 'Открой приложение через Telegram', {});
  const method = init.method ?? (init.body === undefined ? 'GET' : 'POST');
  if (method !== 'GET') spamGuard();
  let res: Response;
  try {
    res =
      (method === 'GET' ? await bootResponse(path)?.catch(() => null) : null) ??
      (await fetch(path, {
        method,
        headers: { authorization: `tma ${initData}`, 'content-type': 'application/json' },
        body: init.body === undefined ? undefined : JSON.stringify(init.body),
      }));
  } catch {
    throw new ApiError(0, 'network', 'Нет соединения — проверь интернет', {});
  }
  let data: Record<string, unknown> = {};
  try {
    data = (await res.json()) as Record<string, unknown>;
  } catch {
    // Non-JSON body (e.g. a proxy error page).
  }
  if (!res.ok) {
    const code = String(data.error ?? 'error');
    if (code === 'banned') gate.set(() => ({ kind: 'banned', until: (data.until as number) ?? null, reason: (data.reason as string) ?? null }));
    if (code === 'maintenance') gate.set(() => ({ kind: 'maintenance', message: String(data.message ?? '') }));
    throw new ApiError(res.status, code, String(data.message ?? 'Что-то пошло не так'), data);
  }
  gate.set((g) => (g.kind === 'ok' ? g : { kind: 'ok' }));
  return data as T;
}

export function errorMessage(e: unknown): string {
  return e instanceof ApiError ? e.message : 'Что-то пошло не так, попробуй ещё раз';
}
