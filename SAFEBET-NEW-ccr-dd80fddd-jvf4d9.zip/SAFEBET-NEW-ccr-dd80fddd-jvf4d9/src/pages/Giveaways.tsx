import { useQuery } from '@tanstack/react-query';
import { useState } from 'react';
import { Avatar } from '../components/Avatar';
import { BrainrotThumb } from '../components/BrainrotCard';
import { Coin } from '../components/Coin';
import { EmptyState } from '../components/EmptyState';
import { Icon } from '../components/Icon';
import { ApiError, api, errorMessage } from '../api/client';
import { queryClient, useCatalog, type CatalogView } from '../api/queries';
import type { Brainrot } from '../../shared/types';
import { round2 } from '../../shared/money';
import { GIVEAWAY_KIND_NAMES, type GiveawayCard, type GiveawayDetail, type GiveawayKind, type GiveawayPlayer, type GiveawayPrize } from '../../shared/giveaways';
import { cx, formatCoins, plural } from '../lib/format';
import { timeLeft } from '../lib/halloween';
import { routeHref } from '../lib/router';
import { sfx } from '../lib/sound';
import { haptic, openTelegramLink } from '../lib/telegram';
import { useNow } from '../lib/useNow';
import { openPlayer } from '../store/ui';
import { toast } from '../store/toast';

const LIST_KEY = ['giveaways'] as const;
const MEDALS = ['🥇', '🥈', '🥉'];
const dateFmt = new Intl.DateTimeFormat('ru-RU', { day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit', timeZone: 'Europe/Moscow' });

const prizeValue = (prizes: GiveawayPrize[], catalog: CatalogView) => round2(prizes.reduce((s, p) => s + (catalog.byId.get(p.brainrotId)?.price ?? 0), 0));

function scoreLabel(kind: GiveawayKind, score: number) {
  return kind === 'referral_race' ? `${score} ${plural(score, 'друг', 'друга', 'друзей')}` : `${formatCoins(score)} B`;
}

export function Giveaways({ id }: { id: string | null }) {
  return id ? <GiveawayPage id={id} /> : <GiveawayList />;
}

/** «До итогов 2 д 04:12:55» / «Старт через …» / «Итоги подведены». */
function Timer({ g, now, big }: { g: GiveawayCard; now: number; big?: boolean }) {
  const label = g.status === 'upcoming' ? 'Старт через' : g.status === 'active' ? 'До итогов' : null;
  const target = g.status === 'upcoming' ? g.startsAt : g.endsAt;
  return (
    <span className={cx('gw-timer', big && 'gw-timer--big', g.status !== 'active' && g.status !== 'upcoming' && 'is-over')}>
      <Icon name="clock" size={big ? 16 : 13} />
      {label ? (
        <>
          {label} <b>{timeLeft(Math.max(0, target - now))}</b>
        </>
      ) : (
        'Итоги подведены'
      )}
    </span>
  );
}

function KindChip({ kind }: { kind: GiveawayKind }) {
  return (
    <span className={cx('gw-kind', `gw-kind--${kind}`)}>
      {kind === 'deposit_race' ? <Coin size={12} /> : <Icon name={kind === 'referral_race' ? 'users' : 'gift'} size={12} />}
      {GIVEAWAY_KIND_NAMES[kind]}
    </span>
  );
}

/** The banner the admin uploaded, or the first prize on the brand gradient. */
function Banner({ g, catalog }: { g: GiveawayCard; catalog: CatalogView }) {
  const first = g.prizes[0] ? catalog.byId.get(g.prizes[0].brainrotId) : null;
  return (
    <span className={cx('gw-banner', !g.banner && 'gw-banner--auto')}>
      {g.banner ? <img src={g.banner} alt="" decoding="async" /> : first && <img className="gw-banner__prize" src={first.image} alt="" decoding="async" />}
    </span>
  );
}

function GiveawayList() {
  const catalog = useCatalog();
  const now = useNow(1000);
  const list = useQuery({ queryKey: LIST_KEY, queryFn: () => api<{ active: GiveawayCard[]; finished: GiveawayCard[] }>('/api/giveaways'), staleTime: 30_000 });
  const active = list.data?.active ?? [];
  const finished = list.data?.finished ?? [];

  return (
    <section className="gw" aria-labelledby="gw-title">
      <h1 id="gw-title" className="page-title">
        Розыгрыши
      </h1>
      <p className="gw-lead">Гонки пополнений, гонки приглашений и розыгрыши брейнротов. Призы падают прямо в инвентарь.</p>

      {list.isPending && <div className="gw-skeleton" aria-hidden="true" />}
      {list.isSuccess && active.length === 0 && (
        <EmptyState icon="trophy" title="Сейчас розыгрышей нет" text="Новые розыгрыши появляются здесь и в канале @BrainrotCrash — заглядывай." />
      )}

      <div className="gw-grid">
        {active.map((g) => (
          <a key={g.id} className="gw-card" href={routeHref('giveaways', String(g.id))}>
            <Banner g={g} catalog={catalog} />
            <span className="gw-card__body">
              <span className="gw-card__top">
                <KindChip kind={g.kind} />
                {g.status === 'upcoming' && <span className="gw-soon">Скоро</span>}
              </span>
              <b className="gw-card__title">{g.title}</b>
              <Timer g={g} now={now} />
              <span className="gw-card__prizes">
                {g.prizes.slice(0, 5).map((p) => {
                  const b = catalog.byId.get(p.brainrotId);
                  return b ? (
                    <span key={p.place} className="gw-card__prize">
                      <BrainrotThumb brainrot={b} size={34} />
                      <i>{p.place}</i>
                    </span>
                  ) : null;
                })}
                {g.prizes.length > 5 && <span className="gw-card__more">+{g.prizes.length - 5}</span>}
                <span className="gw-card__pool">
                  <Coin size={13} /> {formatCoins(prizeValue(g.prizes, catalog))}
                </span>
              </span>
              {g.entries !== null && (
                <small className="gw-card__entries">
                  <Icon name="users" size={12} /> {g.entries} {plural(g.entries, 'участник', 'участника', 'участников')}
                </small>
              )}
            </span>
          </a>
        ))}
      </div>

      {finished.length > 0 && (
        <section className="panel gw-finished" aria-labelledby="gw-finished-title">
          <h2 id="gw-finished-title" className="panel__title">
            Завершённые
          </h2>
          <ul className="gw-finished__list">
            {finished.map((g) => {
              const b = g.winner ? catalog.byId.get(g.winner.brainrotId) : null;
              return (
                <li key={g.id}>
                  <a className="gw-finished__row" href={routeHref('giveaways', String(g.id))}>
                    <span className="gw-finished__what">
                      <b>{g.title}</b>
                      <small>{g.winner ? `🥇 ${g.winner.name}` : 'Без победителей'}</small>
                    </span>
                    {b && <BrainrotThumb brainrot={b} size={34} />}
                    <Icon name="chevronRight" size={16} />
                  </a>
                </li>
              );
            })}
          </ul>
        </section>
      )}
    </section>
  );
}

function PlayerRow({ p, kind, prize, mine }: { p: GiveawayPlayer; kind: GiveawayKind; prize: Brainrot | null; mine?: boolean }) {
  return (
    <li>
      <button type="button" className={cx('gw-row', p.place <= 3 && 'is-podium', p.place === 1 && 'is-first', mine && 'is-me')} onClick={() => p.playerId && openPlayer(p.playerId)} disabled={!p.playerId}>
        <span className="gw-row__place">{MEDALS[p.place - 1] ?? p.place}</span>
        <Avatar user={{ photoUrl: p.photo, name: p.name }} size={34} />
        <span className="gw-row__who">
          <b>{p.name}</b>
          {kind !== 'draw' && <small>{scoreLabel(kind, p.score)}</small>}
        </span>
        {prize && (
          <span className="gw-row__prize" title={prize.name}>
            <BrainrotThumb brainrot={prize} size={p.place === 1 ? 44 : 32} />
          </span>
        )}
      </button>
    </li>
  );
}

function GiveawayPage({ id }: { id: string }) {
  const catalog = useCatalog();
  const now = useNow(1000);
  const key = ['giveaways', id];
  const q = useQuery({
    queryKey: key,
    queryFn: () => api<GiveawayDetail>(`/api/giveaways/${encodeURIComponent(id)}`),
    staleTime: 15_000,
    refetchInterval: (s) => (s.state.data?.status === 'active' ? 30_000 : false),
  });
  const [joining, setJoining] = useState(false);
  const g = q.data;

  if (q.isError) {
    return (
      <section className="gw">
        <a className="gw-back" href={routeHref('giveaways')}>
          <Icon name="chevronLeft" size={16} /> Все розыгрыши
        </a>
        <EmptyState icon="trophy" title="Розыгрыш не найден" text={q.error instanceof ApiError ? q.error.message : 'Попробуй ещё раз позже'} />
      </section>
    );
  }
  if (!g) {
    return (
      <section className="gw">
        <div className="gw-skeleton gw-skeleton--hero" aria-hidden="true" />
      </section>
    );
  }

  const prizeOf = (place: number) => {
    const p = g.prizes.find((x) => x.place === place);
    return p ? catalog.byId.get(p.brainrotId) ?? null : null;
  };
  const running = g.status === 'active';
  const race = g.kind !== 'draw';
  const meIn = g.me.place !== null && g.me.place > g.top.length;

  async function join() {
    if (joining || !g) return;
    setJoining(true);
    try {
      await api(`/api/giveaways/${g.id}/join`, { body: {} });
      sfx.win();
      haptic('success');
      toast('Ты участвуешь! Итоги — в конце розыгрыша', 'success');
      await queryClient.invalidateQueries({ queryKey: key });
    } catch (e) {
      sfx.error();
      toast(errorMessage(e), 'error');
      if (e instanceof ApiError && e.code === 'need_channel' && typeof e.data?.url === 'string') openTelegramLink(e.data.url);
    } finally {
      setJoining(false);
    }
  }

  const reqs: { text: string; done: boolean | null }[] = [];
  // «Пополни брейнрота X ×N» counts in every format (iteration 35).
  // Iteration 39: Stars or crypto worth as much count too.
  const brainrotReq = (n: NonNullable<typeof g.needBrainrot>) => ({
    text: `Пополнить ${catalog.byId.get(n.brainrotId)?.name ?? 'брейнрота'}${n.count > 1 ? ` ×${n.count}` : ''} (внесено ${Math.min(n.have, n.count)} из ${n.count}) или звёздами / криптой на ${formatCoins(n.paidNeed)} B (у тебя ${formatCoins(Math.min(n.paid, n.paidNeed))} B) за время розыгрыша`,
    done: n.have >= n.count || (n.paidNeed > 0 && n.paid >= n.paidNeed),
  });
  if (g.kind === 'deposit_race') {
    reqs.push({ text: 'Очки — чистые пополнения за время гонки: звёзды, крипта и брейнроты минус выводы', done: null });
    if (g.needBrainrot) reqs.push(brainrotReq(g.needBrainrot));
    if (g.minDeposit > 0) reqs.push({ text: `В таблицу — от ${formatCoins(g.minDeposit)} B`, done: g.me.place !== null });
  } else if (g.kind === 'referral_race') {
    reqs.push({ text: 'Очки — друзья, пришедшие по твоей ссылке за время гонки', done: null });
    reqs.push({ text: `Друг засчитывается, когда пополнит от ${formatCoins(g.minDeposit)} B за время гонки`, done: null });
    if (g.needBrainrot) reqs.push(brainrotReq(g.needBrainrot));
  } else {
    if (g.minDeposit > 0) reqs.push({ text: `Пополнить от ${formatCoins(g.minDeposit)} B за время розыгрыша (у тебя ${formatCoins(Math.max(0, g.me.score))} B)`, done: g.me.score >= g.minDeposit });
    if (g.channel) reqs.push({ text: `Быть подписанным на ${g.channel.username} до итогов`, done: null });
    if (g.needBrainrot) reqs.push(brainrotReq(g.needBrainrot));
    reqs.push({ text: 'Нажать «Участвовать»', done: g.me.joined });
  }

  return (
    <section className="gw gw-page" aria-labelledby="gw-page-title">
      <a className="gw-back" href={routeHref('giveaways')}>
        <Icon name="chevronLeft" size={16} /> Все розыгрыши
      </a>

      <div className="gw-hero">
        <Banner g={g} catalog={catalog} />
        <div className="gw-hero__over">
          <KindChip kind={g.kind} />
          <h1 id="gw-page-title" className="gw-hero__title">
            {g.title}
          </h1>
          <Timer g={g} now={now} big />
        </div>
      </div>
      <p className="gw-dates">
        {dateFmt.format(g.startsAt)} — {dateFmt.format(g.endsAt)} МСК
      </p>

      <section className="panel gw-prizes" aria-labelledby="gw-prizes-title">
        <h2 id="gw-prizes-title" className="panel__title">
          Призы · {g.prizes.length} {plural(g.prizes.length, 'место', 'места', 'мест')}
          <span className="gw-prizes__pool">
            <Coin size={13} /> {formatCoins(prizeValue(g.prizes, catalog))}
          </span>
        </h2>
        <ol className="gw-prizes__list">
          {g.prizes.map((p) => {
            const b = catalog.byId.get(p.brainrotId);
            return (
              <li key={p.place} className={cx('gw-prize', p.place === 1 && 'is-first')}>
                <span className="gw-prize__place">{MEDALS[p.place - 1] ?? `${p.place}`}</span>
                {b && <BrainrotThumb brainrot={b} size={p.place === 1 ? 56 : 40} />}
                <span className="gw-prize__name">
                  <b>{b?.name ?? p.brainrotId}</b>
                  {b && (
                    <small>
                      <Coin size={11} /> {formatCoins(b.price)}
                    </small>
                  )}
                </span>
              </li>
            );
          })}
        </ol>
      </section>

      {(g.description || g.conditions || reqs.length > 0) && (
        <section className="panel gw-how" aria-labelledby="gw-how-title">
          <h2 id="gw-how-title" className="panel__title">
            Как участвовать
          </h2>
          {g.description && <p className="gw-text">{g.description}</p>}
          <ul className="gw-reqs">
            {reqs.map((r) => (
              <li key={r.text} className={cx(r.done === true && 'is-done')}>
                <Icon name={r.done ? 'check' : 'chevronRight'} size={14} />
                {r.text}
              </li>
            ))}
          </ul>
          {g.conditions && <p className="gw-text gw-text--small">{g.conditions}</p>}
          {g.kind === 'draw' && running && (
            <div className="gw-join">
              {g.channel && (
                <button type="button" className="btn btn--ghost" onClick={() => openTelegramLink(g.channel!.url)}>
                  <Icon name="bot" size={18} /> {g.channel.username}
                </button>
              )}
              <button type="button" className={cx('btn btn--primary btn--lg', g.me.joined && 'is-joined')} disabled={joining || g.me.joined} onClick={join}>
                {g.me.joined ? (
                  <>
                    <Icon name="check" size={18} /> Ты участвуешь
                  </>
                ) : joining ? (
                  'Секунду…'
                ) : (
                  'Участвовать'
                )}
              </button>
            </div>
          )}
          {g.status === 'upcoming' && <p className="hint hint--left">Розыгрыш ещё не начался — очки начнут считаться со старта.</p>}
          {g.kind === 'referral_race' && running && (
            <a className="btn btn--primary btn--block" href={routeHref('referrals')}>
              <Icon name="users" size={18} /> Пригласить друзей
            </a>
          )}
        </section>
      )}

      {g.status === 'finished' ? (
        <section className="panel gw-board" aria-labelledby="gw-win-title">
          <h2 id="gw-win-title" className="panel__title">
            Победители
          </h2>
          {g.winners.length === 0 ? (
            <p className="hint hint--left">В этот раз никто не выполнил условия.</p>
          ) : (
            <ol className="gw-board__list">
              {g.winners.map((w) => (
                <PlayerRow key={w.place} p={w} kind={g.kind} prize={catalog.byId.get(w.brainrotId) ?? null} />
              ))}
            </ol>
          )}
          {g.me.place !== null && <p className="gw-me">🎉 Ты занял {g.me.place} место — приз уже в инвентаре.</p>}
        </section>
      ) : race ? (
        <section className="panel gw-board" aria-labelledby="gw-board-title">
          <h2 id="gw-board-title" className="panel__title">
            Лидеры · топ {Math.max(g.top.length, 1)}
            <small>
              {g.field} {plural(g.field, 'участник', 'участника', 'участников')}
            </small>
          </h2>
          {g.top.length === 0 ? (
            <p className="hint hint--left">{g.status === 'upcoming' ? 'Таблица откроется со стартом.' : 'Пока никого — займи первое место!'}</p>
          ) : (
            <ol className="gw-board__list">
              {g.top.map((p) => (
                <PlayerRow key={p.place} p={p} kind={g.kind} prize={prizeOf(p.place)} mine={g.me.place === p.place} />
              ))}
            </ol>
          )}
          {meIn ? (
            <p className="gw-me">
              Ты на <b>{g.me.place} месте</b> · {scoreLabel(g.kind, g.me.score)}
              {g.me.place! <= g.prizes.length ? ' — в призах!' : ''}
            </p>
          ) : (
            g.me.place === null && running && <p className="gw-me gw-me--out">{g.kind === 'deposit_race' ? 'Тебя пока нет в таблице — пополни баланс, чтобы попасть.' : 'Тебя пока нет в таблице — пригласи друга.'}</p>
          )}
        </section>
      ) : (
        <section className="panel gw-board" aria-labelledby="gw-draw-title">
          <h2 id="gw-draw-title" className="panel__title">
            Участники
          </h2>
          <p className="gw-me">
            {g.entries ?? 0} {plural(g.entries ?? 0, 'участник', 'участника', 'участников')} · победителей выберет случай в конце
          </p>
        </section>
      )}
    </section>
  );
}
