import { useId } from 'react';

/**
 * The quest ticket (iteration 32): an orange admission ticket with notched sides, a perforation and the brand's «B».
 * Inline SVG in the --ticket tokens, sized like `Coin` so card image rules never stretch it.
 */
export function Ticket({ size = 18, className }: { size?: number; className?: string }) {
  const id = useId();
  return (
    <svg
      className={className ? `ticket ${className}` : 'ticket'}
      width={size}
      height={size}
      viewBox="0 0 24 24"
      style={{ width: size, height: size, minWidth: size, flex: 'none' }}
      aria-hidden="true"
      focusable="false"
    >
      <defs>
        <linearGradient id={`${id}g`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="var(--ticket-top)" />
          <stop offset="1" stopColor="var(--ticket)" />
        </linearGradient>
      </defs>
      <g transform="rotate(-12 12 12)">
        <path
          d="M3.5 6.5h17a1 1 0 0 1 1 1v2.6a2 2 0 0 0 0 3.8v2.6a1 1 0 0 1-1 1h-17a1 1 0 0 1-1-1v-2.6a2 2 0 0 0 0-3.8V7.5a1 1 0 0 1 1-1z"
          fill={`url(#${id}g)`}
          stroke="var(--ticket-deep)"
          strokeWidth="1.1"
        />
        <path d="M16.2 8v8" stroke="var(--ticket-deep)" strokeWidth="1" strokeDasharray="1.3 1.2" />
        <path
          d="M7.2 8.6h3.3a1.7 1.7 0 0 1 .6 3.3 1.8 1.8 0 0 1-.4 3.5H7.2zm1.5 1.3v1.6h1.6a.8.8 0 0 0 0-1.6zm0 2.8v1.4h1.8a.7.7 0 0 0 0-1.4z"
          fill="var(--ticket-ink)"
          fillRule="evenodd"
        />
      </g>
    </svg>
  );
}
