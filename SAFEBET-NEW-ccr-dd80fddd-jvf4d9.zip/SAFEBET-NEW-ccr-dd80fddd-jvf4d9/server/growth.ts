import { TERMS_VERSION } from '../shared/legal';
import { round2 } from '../shared/money';
import { REF_LEVELS } from '../shared/bonuses';
import { HttpError, bad, forbidden, notFound } from './errors';
import { type Viewer } from './auth';
import { ensureSchema } from './autoMigrate';
import { getSettings } from './settings';
import { db, ms, num, one, q } from './db';
import { promo, siteUrl } from './env';
import { ensureRefCode, refLink } from './referrals';
import { BotRefusal, botCall, escapeHtml } from './telegram';
import { int, str, type Body } from './validate';
import { notStaff } from './staff';

// ---------- 18+ ----------

/** The player confirms 18+ and accepts the current user agreement and privacy policy. */
export async function acceptTerms(v: Viewer, body: Body) {
  await ensureSchema();
  if (body.adult !== true) throw bad('invalid', 'Подтверди, что тебе есть 18 лет');
  if (Number(body.version) !== TERMS_VERSION) throw bad('terms_changed', 'Документы обновились — перечитай и прими ещё раз');
  await q('UPDATE users SET terms_version = $2, terms_accepted_at = now() WHERE id = $1', [v.id, TERMS_VERSION]);
  // The rest of this request (the profile it returns) runs with the consent in place.
  v.termsOk = true;
  return { version: TERMS_VERSION };
}

// ---------- The Meowl tour ----------

/** The first-visit tour was finished or skipped: it never starts by itself again (Настройки can replay it). */
export async function finishOnboarding(v: Viewer) {
  await ensureSchema();
  await q('UPDATE users SET onboarded_at = coalesce(onboarded_at, now()) WHERE id = $1', [v.id]);
  return { ok: true };
}

// ---------- «Поделиться выигрышем» ----------

const SHARE_LIMIT = 5; // per 10 minutes
const SHARE_GAMES = ['case', 'battle', 'upgrade', 'mines', 'road', 'fuse'];

/**
 * A prepared Telegram message about the player's latest win (within 15 minutes): the brainrot's card, its price and a
 * «Играть» button on the player's referral link — the friend gets a referral case, the player a friend.
 */
export async function shareWin(v: Viewer) {
  await ensureSchema();
  const recent = await one<{ n: string }>(`SELECT count(*) AS n FROM win_shares WHERE user_id = $1 AND created_at > now() - interval '10 minutes'`, [v.id]);
  if (num(recent?.n) >= SHARE_LIMIT) throw new HttpError(429, 'too_many', 'Слишком часто — подожди пару минут');
  const win = await one<{ id: string; name: string; price: string; brainrot_id: string; image: string }>(
    `SELECT d.id, b.name, b.price, b.id AS brainrot_id, b.image FROM drops d JOIN brainrots b ON b.id = d.brainrot_id
     WHERE d.user_id = $1 AND d.result = 'win' AND NOT d.demo AND d.game = ANY($2) AND d.created_at > now() - interval '15 minutes'
     ORDER BY d.id DESC LIMIT 1`,
    [v.id, SHARE_GAMES],
  );
  if (!win) throw bad('no_win', 'Сначала выиграй что-нибудь — делиться пока нечем');
  const row = (await q<{ id: string }>('INSERT INTO win_shares (user_id, drop_id) VALUES ($1, $2) RETURNING id', [v.id, win.id]))[0]!;
  const link = refLink(await ensureRefCode(db, v.id));
  const price = num(win.price).toLocaleString('ru-RU');
  const caption = `🎉 Выбил <b>${escapeHtml(win.name)}</b> за <b>${price} B</b> в BrainrotCrash!\nЗалетай по моей ссылке — тебе бесплатный кейс 🎁`;
  // Telegram wants a JPEG: the catalog's brainrots have cards in public/share/brainrots (scripts/gen_share_cards.py);
  // one an admin uploaded later gets the general share banner.
  const photo = win.image.startsWith('/brainrots/')
    ? `${siteUrl()}/share/brainrots/${encodeURIComponent(win.image.slice('/brainrots/'.length).replace(/\.webp$/, ''))}.jpg`
    : `${siteUrl()}${promo('share.jpg')}`;
  const prepared = await botCall<{ id: string }>('savePreparedInlineMessage', {
    user_id: v.id,
    result: {
      type: 'photo',
      id: `win-${row.id}`,
      photo_url: photo,
      thumbnail_url: photo,
      photo_width: 800,
      photo_height: 800,
      caption,
      parse_mode: 'HTML',
      reply_markup: { inline_keyboard: [[{ text: '🎮 Играть в BrainrotCrash', url: link }]] },
    },
    allow_user_chats: true,
    allow_group_chats: true,
    allow_channel_chats: true,
  });
  const preparedId = prepared && !(prepared instanceof BotRefusal) ? prepared.id : null;
  return { preparedId, text: caption.replace(/<[^>]+>/g, ''), url: link };
}

// ---------- Owners: partners, traffic sources, the economy ----------

function ownerOnly(v: Viewer) {
  if (!v.isOwner) throw forbidden('Это раздел владельца');
}

const TOP_PERCENT = REF_LEVELS[REF_LEVELS.length - 1]!.percent;

/**
 * A partner (a creator who brings players): the owner gives them their own referral percent — from the first friend
 * on, never above the top level's (the deposit share is what can cost the house, see CLAUDE.md). null takes it back.
 */
export async function setPartner(v: Viewer, idParam: string, body: Body) {
  ownerOnly(v);
  await ensureSchema();
  const id = int(idParam, 'игрок');
  const percent = body.percent === null || body.percent === undefined ? null : Number(body.percent);
  if (percent !== null && (!Number.isFinite(percent) || percent < REF_LEVELS[0]!.percent || percent > TOP_PERCENT)) {
    throw bad('invalid', `Процент партнёра — от ${REF_LEVELS[0]!.percent} до ${TOP_PERCENT}`);
  }
  const rows = await q('UPDATE users SET ref_percent = $2 WHERE id = $1 RETURNING id', [id, percent === null ? null : round2(percent)]);
  if (!rows.length) throw notFound('Игрок не найден');
  return { percent };
}

const TAG_RE = /^[a-z0-9_]{3,32}$/;

/** Who came with which link: clicks, new players, payers, deposits, withdrawals, turnover in the house's games. */
export async function listSources(v: Viewer) {
  ownerOnly(v);
  await ensureSchema();
  const rows = await q<{
    tag: string;
    title: string;
    created_at: string;
    clicks: string;
    players: string;
    payers: string;
    deposits: string;
    withdrawals: string;
    played: string;
  }>(
    `SELECT s.tag, s.title, s.created_at,
       (SELECT count(*) FROM source_clicks c WHERE c.tag = s.tag) AS clicks,
       (SELECT count(*) FROM users u WHERE u.source = s.tag) AS players,
       (SELECT count(*) FROM users u WHERE u.source = s.tag AND (EXISTS (SELECT 1 FROM star_payments p WHERE p.user_id = u.id)
          OR EXISTS (SELECT 1 FROM item_deposits d WHERE d.user_id = u.id AND d.status = 'credited'))) AS payers,
       (SELECT coalesce(sum(p.credited), 0) FROM star_payments p JOIN users u ON u.id = p.user_id WHERE u.source = s.tag)
         + (SELECT coalesce(sum(d.credited), 0) FROM item_deposits d JOIN users u ON u.id = d.user_id WHERE u.source = s.tag AND d.status = 'credited') AS deposits,
       (SELECT coalesce(sum(w.value), 0) FROM withdrawals w JOIN users u ON u.id = w.user_id WHERE u.source = s.tag AND w.status = 'done') AS withdrawals,
       (SELECT coalesce(sum(dr.stake_value), 0) FROM drops dr JOIN users u ON u.id = dr.user_id WHERE u.source = s.tag AND dr.stake_value > 0 AND NOT dr.demo) AS played
     FROM traffic_sources s ORDER BY s.created_at DESC`,
  );
  return rows.map((r) => ({
    tag: r.tag,
    title: r.title,
    link: `https://t.me/braincrashbot?start=s-${r.tag}`,
    createdAt: ms(r.created_at),
    clicks: num(r.clicks),
    players: num(r.players),
    payers: num(r.payers),
    deposits: num(r.deposits),
    withdrawals: num(r.withdrawals),
    played: num(r.played),
  }));
}

export async function createSource(v: Viewer, body: Body) {
  ownerOnly(v);
  await ensureSchema();
  const tag = str(body.tag, 'метка', 3, 32).toLowerCase();
  if (!TAG_RE.test(tag)) throw bad('invalid', 'Метка — латиница, цифры и «_», 3–32 символа');
  const title = str(body.title, 'название', 1, 80);
  const rows = await q('INSERT INTO traffic_sources (tag, title, created_by) VALUES ($1, $2, $3) ON CONFLICT DO NOTHING RETURNING tag', [tag, title, v.id]);
  if (!rows.length) throw bad('taken', 'Такая метка уже есть');
  return listSources(v);
}

/**
 * /start s-<tag>: the click is noted once per player; a player who has just appeared (this /start created them) is
 * marked as that source's for good.
 */
export async function noteSource(userId: number, tag: string) {
  if (!TAG_RE.test(tag)) return;
  await ensureSchema();
  await q(
    `WITH src AS (SELECT tag FROM traffic_sources WHERE tag = $1),
     click AS (INSERT INTO source_clicks (tag, user_id) SELECT tag, $2 FROM src ON CONFLICT DO NOTHING)
     UPDATE users SET source = (SELECT tag FROM src)
     WHERE id = $2 AND source IS NULL AND created_at > now() - interval '10 minutes' AND EXISTS (SELECT 1 FROM src)`,
    [tag, userId],
  );
}

interface EconomyRow {
  stars: string;
  crypto_rub: string;
  pass_stars: string;
  pass_rewards: string;
  star_coins: string;
  item_deposits: string;
  withdrawals: string;
  referral: string;
  milestones: string;
  cashback: string;
  quests: string;
  ticket_cases: string;
  tickets: string;
  rank_gifts: string;
  promo: string;
  consolations: string;
  giveaways: string;
  admin: string;
  played: string;
  house: string;
}

const ECONOMY_SQL = (since: string) => `
  SELECT
    (SELECT coalesce(sum(stars), 0) FROM star_payments WHERE created_at >= ${since}) AS stars,
    (SELECT coalesce(sum(credited), 0) FROM star_payments WHERE created_at >= ${since}) AS star_coins,
    (SELECT coalesce(sum(rub), 0) FROM crypto_orders WHERE status = 'paid' AND paid_at >= ${since}) AS crypto_rub,
    (SELECT coalesce(sum(stars), 0) FROM pass_orders WHERE status = 'paid' AND paid_at >= ${since}) AS pass_stars,
    (SELECT coalesce(sum(value), 0) FROM pass_claims WHERE reward->>'kind' IN ('brainrot', 'coins', 'case') AND created_at >= ${since} AND ${notStaff('user_id')}) AS pass_rewards,
    (SELECT coalesce(sum(credited), 0) FROM item_deposits WHERE status = 'credited' AND updated_at >= ${since}) AS item_deposits,
    (SELECT coalesce(sum(value), 0) FROM withdrawals WHERE status = 'done' AND processed_at >= ${since}) AS withdrawals,
    (SELECT coalesce(sum(amount), 0) FROM ref_payouts WHERE kind <> 'milestone' AND created_at >= ${since}) AS referral,
    (SELECT coalesce(sum(amount), 0) FROM ref_milestones WHERE created_at >= ${since}) AS milestones,
    (SELECT coalesce(sum(amount), 0) FROM cashback_claims WHERE created_at >= ${since}) AS cashback,
    (SELECT coalesce(sum(reward), 0) FROM quest_claims WHERE currency = 'coins' AND created_at >= ${since}) AS quests,
    (SELECT coalesce(sum(reward), 0) FROM quest_claims WHERE currency = 'tickets' AND created_at >= ${since}) AS tickets,
    (SELECT coalesce(sum(payout_value), 0) FROM drops WHERE game = 'case' AND meta->>'tickets' IS NOT NULL AND created_at >= ${since}) AS ticket_cases,
    (SELECT coalesce(sum(value), 0) FROM rank_gifts WHERE created_at >= ${since}) AS rank_gifts,
    (SELECT coalesce(sum(p.reward_amount), 0) FROM promo_activations a JOIN promo_codes p ON p.id = a.promo_id
       WHERE p.reward_type = 'coins' AND a.created_at >= ${since}) AS promo,
    (SELECT coalesce(sum(coins), 0) FROM consolations WHERE opened_at >= ${since}) AS consolations,
    (SELECT coalesce(sum(b.price), 0) FROM giveaway_winners w JOIN giveaways g ON g.id = w.giveaway_id JOIN brainrots b ON b.id = w.brainrot_id
       WHERE g.settled_at >= ${since}) AS giveaways,
    (SELECT coalesce(sum(CASE WHEN l.action = 'give_coins' THEN (l.details->>'amount')::numeric
         ELSE b.price * coalesce((l.details->>'count')::int, 1) END), 0)
       FROM admin_log l LEFT JOIN brainrots b ON b.id = l.details->>'brainrotId'
       WHERE l.action IN ('give_coins', 'give_brainrot') AND l.details->>'demo' IS NULL AND l.created_at >= ${since} AND ${notStaff('l.target_user')}) AS admin,
    (SELECT coalesce(sum(stake_value), 0) FROM drops WHERE stake_value > 0 AND payout_value IS NOT NULL AND NOT demo AND created_at >= ${since} AND ${notStaff('user_id')}) AS played,
    (SELECT coalesce(sum(stake_value - payout_value), 0) FROM drops WHERE stake_value > 0 AND payout_value IS NOT NULL AND NOT demo AND created_at >= ${since} AND ${notStaff('user_id')}) AS house`;

function economyOf(r: EconomyRow, starRate: number) {
  const deposits = round2(num(r.star_coins) + num(r.item_deposits));
  const bonuses = {
    referral: num(r.referral),
    milestones: num(r.milestones),
    cashback: num(r.cashback),
    quests: num(r.quests),
    /** What the ticket cases really dropped (coins and brainrots at catalog prices): the tickets' true cost. */
    ticketCases: num(r.ticket_cases),
    rankGifts: num(r.rank_gifts),
    promo: num(r.promo),
    consolations: num(r.consolations),
    giveaways: num(r.giveaways),
    /** Coins and brainrots (at catalog prices) admins gave by hand. */
    admin: num(r.admin),
    /** Battle pass brainrots (iteration 37; its tickets cost what ticketCases shows). */
    pass: num(r.pass_rewards),
  };
  return {
    stars: num(r.stars),
    /** Roubles paid in crypto (iteration 38); their coins are in `deposits` (star_payments rows with 0 stars). */
    cryptoRub: num(r.crypto_rub),
    /** BPlus sold (iteration 37): Stars that bought no coins — income at today's rate. */
    passStars: num(r.pass_stars),
    passCoins: round2(num(r.pass_stars) * starRate),
    deposits,
    withdrawals: num(r.withdrawals),
    bonuses,
    bonusTotal: round2(Object.values(bonuses).reduce((s, x) => s + x, 0)),
    /** Quest tickets handed out (not coins: they cost what ticketCases shows once spent). */
    tickets: num(r.tickets),
    played: num(r.played),
    house: num(r.house),
  };
}

/**
 * «Экономика» for the owners: what came in, what went out, what the bonuses cost and what the games kept — for 7 and
 * 30 days and all time — plus what players hold right now. The house's real position is all-time deposits − done
 * withdrawals − what players hold (coins, referral balances and brainrots at catalog prices): if that stays above
 * zero, nothing has cost more than it brought.
 */
export async function economyReport(v: Viewer) {
  ownerOnly(v);
  await ensureSchema();
  const { starRate } = await getSettings();
  const [week, month, all, held] = await Promise.all([
    one<EconomyRow>(ECONOMY_SQL(`now() - interval '7 days'`)),
    one<EconomyRow>(ECONOMY_SQL(`now() - interval '30 days'`)),
    one<EconomyRow>(ECONOMY_SQL(`'-infinity'::timestamptz`)),
    one<{ coins: string; ref: string; items: string; players: string }>(
      // Staff aren't players: what admins and owners hold (test coins included) is not the project's debt.
      `SELECT (SELECT coalesce(sum(balance - demo_balance), 0) FROM users u WHERE ${notStaff('u.id')}) AS coins,
         (SELECT coalesce(sum(ref_balance), 0) FROM users u WHERE ${notStaff('u.id')}) AS ref,
         (SELECT coalesce(sum(b.price), 0) FROM inventory i JOIN brainrots b ON b.id = i.brainrot_id WHERE NOT i.demo AND ${notStaff('i.user_id')}) AS items,
         (SELECT count(*) FROM users u WHERE ${notStaff('u.id')}) AS players`,
    ),
  ]);
  const total = economyOf(all!, starRate);
  const holdings = { coins: num(held?.coins), ref: num(held?.ref), items: num(held?.items) };
  const holdingsTotal = round2(holdings.coins + holdings.ref + holdings.items);
  return {
    week: economyOf(week!, starRate),
    month: economyOf(month!, starRate),
    all: total,
    holdings,
    holdingsTotal,
    players: num(held?.players),
    result: round2(total.deposits + total.passCoins - total.withdrawals - holdingsTotal),
  };
}
