-- Iteration 35 (part 1). Applied by the Worker (server/autoMigrate.ts), so every statement is safe to run twice.

-- A case opening the app may not have heard back about: the result is kept (same transaction) under the app's
-- request id, so the app can still show the spin, and a repeated request never opens a second time.
CREATE TABLE IF NOT EXISTS case_open_results (
  user_id BIGINT NOT NULL REFERENCES users (id),
  request_id TEXT NOT NULL CHECK (char_length(request_id) BETWEEN 8 AND 64),
  result JSONB NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, request_id)
);
CREATE INDEX IF NOT EXISTS case_open_results_time ON case_open_results (created_at);

-- A Stars invoice made with a partner's code: +15 % while the payer is still bound to that partner.
ALTER TABLE star_orders ADD COLUMN IF NOT EXISTS partner_id BIGINT;

-- «НОВЫЙ» / «РЕДИЗАЙН» ribbon on a case card until badge_until.
ALTER TABLE cases ADD COLUMN IF NOT EXISTS badge TEXT CHECK (badge IN ('new', 'redesign'));
ALTER TABLE cases ADD COLUMN IF NOT EXISTS badge_until TIMESTAMPTZ;

-- A floating price («Биткоин»): the tick moves `price` to another value of the cycle at price_next_at.
ALTER TABLE cases ADD COLUMN IF NOT EXISTS price_cycle NUMERIC(16, 2)[];
ALTER TABLE cases ADD COLUMN IF NOT EXISTS price_next_at TIMESTAMPTZ;
CREATE TABLE IF NOT EXISTS case_price_history (
  id BIGSERIAL PRIMARY KEY,
  case_id TEXT NOT NULL REFERENCES cases (id) ON DELETE CASCADE,
  price NUMERIC(16, 2) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS case_price_history_case ON case_price_history (case_id, id DESC);

-- A giveaway that asks for a brainrot deposit of a given brainrot in its period.
ALTER TABLE giveaways ADD COLUMN IF NOT EXISTS need_brainrot TEXT REFERENCES brainrots (id) ON DELETE SET NULL;
ALTER TABLE giveaways ADD COLUMN IF NOT EXISTS need_brainrot_count INT NOT NULL DEFAULT 1 CHECK (need_brainrot_count BETWEEN 1 AND 50);

-- «Биткоин»: 10 000 / 5 000 / 799 / 99 B, the price changes every 5–10 minutes. The healer composes it for every
-- price of the cycle on the next tick.
INSERT INTO cases (id, name, price, image, kind, status, sort, section_id, price_cycle, price_next_at, badge, badge_until)
SELECT 'bitcoin', 'Биткоин', 799, '/cases/bitcoin.webp', 'paid', 'active', -1, (SELECT min(id) FROM case_sections),
       ARRAY[10000, 5000, 799, 99]::NUMERIC(16, 2)[], now() + interval '7 minutes', 'new', now() + interval '3 days'
WHERE NOT EXISTS (SELECT 1 FROM cases WHERE id = 'bitcoin');
INSERT INTO case_price_history (case_id, price)
SELECT 'bitcoin', 799 WHERE NOT EXISTS (SELECT 1 FROM case_price_history WHERE case_id = 'bitcoin');

DO $$
DECLARE t TEXT;
BEGIN
  FOREACH t IN ARRAY ARRAY['case_open_results', 'case_price_history'] LOOP
    EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', t);
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'anon') THEN
      EXECUTE format('REVOKE ALL ON %I FROM anon, authenticated', t);
    END IF;
  END LOOP;
END $$;
