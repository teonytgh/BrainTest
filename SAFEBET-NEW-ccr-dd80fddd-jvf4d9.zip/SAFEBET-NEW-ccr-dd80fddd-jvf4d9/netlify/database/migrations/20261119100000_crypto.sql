-- Iteration 38: crypto deposits through Crypto Pay (@CryptoBot). Applied by the Worker (server/autoMigrate.ts) — safe to
-- run twice.

-- A paid crypto invoice is also written to star_payments (stars = 0, charge_id 'crypto:<invoice id>', no Stars order),
-- so every «deposited» sum — ranks, races, quests, referral milestones, the economy — counts it like a Stars deposit.
ALTER TABLE star_payments ALTER COLUMN order_id DROP NOT NULL;

CREATE TABLE IF NOT EXISTS crypto_orders (
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT NOT NULL REFERENCES users (id),
  rub NUMERIC(16, 2) NOT NULL CHECK (rub > 0),
  coins NUMERIC(16, 2) NOT NULL CHECK (coins > 0),
  rate NUMERIC(10, 4) NOT NULL,
  invoice_id BIGINT UNIQUE,
  pay_url TEXT,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'paid', 'expired')),
  paid_asset TEXT,
  paid_amount NUMERIC(30, 10),
  checked_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  paid_at TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS crypto_orders_user ON crypto_orders (user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS crypto_orders_pending ON crypto_orders (created_at) WHERE status = 'pending';
