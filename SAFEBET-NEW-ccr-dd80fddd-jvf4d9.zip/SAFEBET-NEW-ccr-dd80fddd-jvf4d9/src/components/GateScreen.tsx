import type { ReactNode } from 'react';
import { Icon, type IconName } from './Icon';
import { BrandMark, Logo } from './Logo';
import { cx } from '../lib/format';
import { BOT_LINK } from '../lib/telegram';

const until = new Intl.DateTimeFormat('ru-RU', { dateStyle: 'long', timeStyle: 'short' });

function Screen({ icon, tone, title, children }: { icon: IconName | 'logo'; tone?: 'red' | 'blue'; title: string; children?: ReactNode }) {
  return (
    <main className={cx('gate', tone && `gate--${tone}`)}>
      <div className="gate__logo">
        <Logo />
      </div>
      <span className="gate__icon">{icon === 'logo' ? <BrandMark height={40} /> : <Icon name={icon} size={38} />}</span>
      <h1 className="gate__title">{title}</h1>
      {children}
    </main>
  );
}

export function SplashScreen() {
  return (
    <main className="gate gate--splash" aria-busy="true">
      <span className="gate__pulse">
        <BrandMark height={72} />
      </span>
      <p className="gate__text">Загружаем BrainrotCrash…</p>
    </main>
  );
}

export function TelegramOnlyScreen() {
  return (
    <Screen icon="logo" title="Открой в Telegram">
      <p className="gate__text">BrainrotCrash работает как мини-приложение Telegram — так мы узнаём твой аккаунт и бережём баланс.</p>
      <a className="btn btn--primary btn--lg" href={BOT_LINK}>
        Открыть бота
      </a>
    </Screen>
  );
}

export function BannedScreen({ until: untilMs, reason }: { until: number | null; reason: string | null }) {
  return (
    <Screen icon="shield" tone="red" title="Аккаунт заблокирован">
      <p className="gate__text">{untilMs ? `Блокировка действует до ${until.format(untilMs)}.` : 'Блокировка бессрочная.'}</p>
      {reason && <p className="gate__reason">Причина: {reason}</p>}
      <p className="gate__hint">Если это ошибка — напиши в поддержку через бота.</p>
    </Screen>
  );
}

export function MaintenanceScreen({ message }: { message: string }) {
  return (
    <Screen icon="settings" tone="blue" title="Мы на обновлении">
      <p className="gate__text">{message || 'Проводим технические работы. Скоро вернёмся — с новыми фишками!'}</p>
      <button type="button" className="btn btn--ghost" onClick={() => window.location.reload()}>
        Проверить снова
      </button>
    </Screen>
  );
}

export function ErrorScreen({ message, onRetry }: { message: string; onRetry: () => void }) {
  return (
    <Screen icon="reset" title="Не удалось загрузиться">
      <p className="gate__text">{message}</p>
      <button type="button" className="btn btn--primary" onClick={onRetry}>
        Попробовать снова
      </button>
    </Screen>
  );
}
