import { pickWeighted } from '../../shared/cases';
import type { Brainrot } from '../../shared/types';

/**
 * Reel cards for a spin. The catalog already sends flattened reel weights (players never see the real
 * chances), so this only keeps the reel lively: no brainrot twice in a row. The drop itself always comes
 * from the server and sits at `winIndex`.
 */
export function buildReel(pool: readonly { brainrot: Brainrot; weight: number }[], length: number, winIndex: number, won: Brainrot): Brainrot[] {
  const out: Brainrot[] = [];
  const distinct = new Set(pool.map((p) => p.brainrot.id)).size;
  for (let i = 0; i < length; i++) {
    if (i === winIndex) {
      out.push(won);
      continue;
    }
    let pick = pool.length ? pickWeighted(pool, Math.random).brainrot : won;
    for (let tries = 0; distinct > 2 && tries < 6 && (pick.id === out[i - 1]?.id || (i + 1 === winIndex && pick.id === won.id)); tries++) {
      pick = pickWeighted(pool, Math.random).brainrot;
    }
    out.push(pick);
  }
  return out;
}
