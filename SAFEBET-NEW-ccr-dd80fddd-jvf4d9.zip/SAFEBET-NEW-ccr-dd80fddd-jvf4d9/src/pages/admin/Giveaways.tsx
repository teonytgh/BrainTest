import { useState } from 'react';
import type * as GiveawaysApi from '../../../server/giveaways';
import { BrainrotThumb } from '../../components/BrainrotCard';
import { Coin } from '../../components/Coin';
import { Switch } from '../../components/Toggle';
import { useCatalog } from '../../api/queries';
import { round2 } from '../../../shared/money';
import { GIVEAWAY_KIND_NAMES, MAX_GIVEAWAY_PLACES, MIN_REFERRAL_RACE_DEPOSIT, type GiveawayKind } from '../../../shared/giveaways';
import { cx, formatCoins } from '../../lib/format';
import { routeHref } from '../../lib/router';
import { BrainrotPicker, Card, ConfirmButton, Empty, Field, ImageInput, Segmented, adminApi, formatWhen, fromMskInput, toMskInput, useAdminAction, useAdminQuery, type Data } from './ui';

type Row = Data<typeof GiveawaysApi.adminGiveaways>[number];

const DAY = 86_400_000;
const STATUS: Record<Row['status'], string> = { upcoming: 'Скоро', active: 'Идёт', finished: 'Завершён', cancelled: 'Отменён' };
const KIND_HELP: Record<GiveawayKind, string> = {
  deposit_race:
    'Места — по чистым пополнениям за период (звёзды, крипта и брейнроты минус выводы): пополнить и вывести обратно не получится. Порог — с какой суммы игрок попадает в таблицу. Держи приз в пределах ~10 % от пополнений лидера: дороже — выгодно пополнить ради приза и вывести после итогов.',
  referral_race: `Места — по числу друзей, пришедших по ссылке игрока за период и пополнивших от порога (не меньше ${MIN_REFERRAL_RACE_DEPOSIT} B — пустые аккаунты не считаются). Ставь порог от 100 B: чем он выше, тем дороже накрутка твинками.`,
  draw: 'Игроки жмут «Участвовать», победителей выбирает случай среди тех, кто выполнил требования: пополнение за период от порога и подписка на канал.',
};
const STAFF_NOTE = 'Админы и владельцы не участвуют ни в одном формате, забаненные и замороженные — тоже.';

interface Draft {
  id: number | null;
  kind: GiveawayKind;
  title: string;
  description: string;
  conditions: string;
  banner: string | null;
  starts: string;
  ends: string;
  minDeposit: string;
  needChannel: boolean;
  /** «Пополни брейнрота X ×N» in the period (empty = none). */
  needBrainrot: string;
  needBrainrotCount: string;
  prizes: (string | null)[];
}

const blank = (): Draft => ({
  id: null,
  kind: 'deposit_race',
  title: '',
  description: '',
  conditions: '',
  banner: null,
  starts: toMskInput(Date.now()),
  ends: toMskInput(Date.now() + 7 * DAY),
  minDeposit: '',
  needChannel: true,
  needBrainrot: '',
  needBrainrotCount: '1',
  prizes: [null, null, null],
});

const fromRow = (g: Row): Draft => ({
  id: g.id,
  kind: g.kind,
  title: g.title,
  description: g.description,
  conditions: g.conditions,
  banner: g.banner,
  starts: toMskInput(g.startsAt),
  ends: toMskInput(g.endsAt),
  minDeposit: g.minDeposit ? String(g.minDeposit) : '',
  needChannel: g.needChannel,
  needBrainrot: g.needBrainrot ?? '',
  needBrainrotCount: String(g.needBrainrotCount ?? 1),
  prizes: g.prizes.map((p) => p.brainrotId),
});

/** Admin «Розыгрыши»: make a deposit race, an invite race or a draw; prizes per place go straight to the winners. */
export function AdminGiveaways() {
  const list = useAdminQuery<Row[]>(['giveaways'], '/giveaways');
  const depositList = useAdminQuery<{ brainrotId: string; name: string }[]>(['deposit-items'], '/deposit-items');
  const catalog = useCatalog();
  const [d, setD] = useState<Draft>(blank);
  const set = <K extends keyof Draft>(k: K, v: Draft[K]) => setD((x) => ({ ...x, [k]: v }));

  const save = useAdminAction(
    (body: Record<string, unknown>) => (d.id ? adminApi(`/giveaways/${d.id}`, 'PATCH', body) : adminApi<{ id: number }>('/giveaways', 'POST', body)),
    { success: d.id ? 'Розыгрыш обновлён' : 'Розыгрыш создан — он уже на странице «Розыгрыши»' },
  );
  const settle = useAdminAction((id: number) => adminApi<{ winners: number }>(`/giveaways/${id}/settle`, 'POST'), {
    success: (r) => `Итоги подведены: ${r.winners} ${r.winners === 1 ? 'победитель' : 'победителей'}`,
  });
  const cancel = useAdminAction((id: number) => adminApi(`/giveaways/${id}/cancel`, 'POST'), { success: 'Розыгрыш отменён' });

  const startsAt = fromMskInput(d.starts);
  const endsAt = fromMskInput(d.ends);
  const min = Number(d.minDeposit.replace(',', '.')) || 0;
  const pool = round2(d.prizes.reduce((s, id) => s + (id ? catalog.byId.get(id)?.price ?? 0 : 0), 0));
  const problem =
    d.title.trim().length < 2
      ? 'Напиши название'
      : !Number.isFinite(startsAt) || !Number.isFinite(endsAt)
        ? 'Укажи даты'
        : endsAt <= Math.max(startsAt, Date.now())
          ? 'Окончание — позже начала и в будущем'
          : d.prizes.some((p) => !p)
            ? 'Выбери приз на каждое место'
            : d.kind === 'referral_race' && min < MIN_REFERRAL_RACE_DEPOSIT
              ? `Порог для гонки приглашений — от ${MIN_REFERRAL_RACE_DEPOSIT} B`
              : null;

  function places(n: number) {
    setD((x) => ({ ...x, prizes: Array.from({ length: n }, (_, i) => x.prizes[i] ?? null) }));
  }

  function submit() {
    if (problem) return;
    const body = {
      ...(d.id ? {} : { kind: d.kind }),
      title: d.title.trim(),
      description: d.description.trim(),
      conditions: d.conditions.trim(),
      banner: d.banner,
      startsAt,
      endsAt,
      minDeposit: min,
      needChannel: d.kind === 'draw' && d.needChannel,
      needBrainrot: d.needBrainrot || null,
      needBrainrotCount: Math.max(1, Math.min(50, Number(d.needBrainrotCount) || 1)),
      prizes: d.prizes,
    };
    save.mutate(body, { onSuccess: () => setD(blank()) });
  }

  const rows = list.data ?? [];
  return (
    <>
      <Card title={d.id ? `Изменить розыгрыш #${d.id}` : 'Новый розыгрыш'} actions={d.id ? <button type="button" className="btn btn--ghost btn--sm" onClick={() => setD(blank())}>Новый</button> : undefined}>
        {!d.id && (
          <Segmented
            label="Формат"
            value={d.kind}
            onChange={(k) => set('kind', k)}
            options={[
              { value: 'deposit_race', label: 'Гонка пополнений' },
              { value: 'referral_race', label: 'Гонка приглашений' },
              { value: 'draw', label: 'Розыгрыш' },
            ]}
          />
        )}
        <p className="acard__text">
          <b>{GIVEAWAY_KIND_NAMES[d.kind]}.</b> {KIND_HELP[d.kind]} {STAFF_NOTE}
        </p>
        <ImageInput value={d.banner} onChange={(v) => set('banner', v)} label="Баннер (широкий, 2:1 — необязательно)" photo />
        <Field label="Название">
          <span className="ainput">
            <input value={d.title} maxLength={60} placeholder="Гонка недели" onChange={(e) => set('title', e.target.value)} aria-label="Название" />
          </span>
        </Field>
        <Field label="Описание" hint="Что разыгрываем и зачем участвовать">
          <textarea className="atextarea" rows={3} maxLength={1500} value={d.description} placeholder="Топ-5 по пополнениям за неделю заберут брейнротов!" onChange={(e) => set('description', e.target.value)} />
        </Field>
        <Field label="Условия" hint="Мелкий шрифт: правила, сроки, кто не участвует">
          <textarea className="atextarea" rows={3} maxLength={800} value={d.conditions} onChange={(e) => set('conditions', e.target.value)} />
        </Field>
        <div className="agw-dates">
          <Field label="Начало (МСК)">
            <span className="ainput">
              <input type="datetime-local" value={d.starts} onChange={(e) => set('starts', e.target.value)} />
            </span>
          </Field>
          <Field label="Итоги (МСК)">
            <span className="ainput">
              <input type="datetime-local" value={d.ends} onChange={(e) => set('ends', e.target.value)} />
            </span>
          </Field>
        </div>
        <div className="agw-quick" role="group" aria-label="Длительность">
          {[1, 3, 7, 14].map((n) => (
            <button key={n} type="button" className="chip chip--sm" onClick={() => set('ends', toMskInput((Number.isFinite(startsAt) ? Math.max(startsAt, Date.now()) : Date.now()) + n * DAY))}>
              {n === 1 ? 'сутки' : `${n} дней`}
            </button>
          ))}
        </div>
        <Field
          label={d.kind === 'draw' ? 'Пополнить за время розыгрыша от, B' : d.kind === 'referral_race' ? 'Друг засчитывается от пополнения, B' : 'В таблицу — от пополнений, B'}
          hint={d.kind === 'referral_race' ? `Не меньше ${MIN_REFERRAL_RACE_DEPOSIT} B` : 'Пусто — без порога'}
        >
          <span className="ainput ainput--short">
            <input inputMode="decimal" value={d.minDeposit} placeholder={d.kind === 'referral_race' ? '100' : '0'} onChange={(e) => set('minDeposit', e.target.value)} aria-label="Порог пополнений" />
          </span>
        </Field>
        <Field label="Пополнить брейнрота" hint="Участвуют те, кто за время розыгрыша внёс этого брейнрота (из списка пополнений) или пополнил звёздами / криптой на его цену × штук. Пусто — без условия.">
          <span className="agw-need">
            <span className="ainput">
              <select className="aselect" value={d.needBrainrot} onChange={(e) => set('needBrainrot', e.target.value)} aria-label="Брейнрот для пополнения">
                <option value="">— без условия —</option>
                {(depositList.data ?? []).map((b) => (
                  <option key={b.brainrotId} value={b.brainrotId}>
                    {b.name}
                  </option>
                ))}
              </select>
            </span>
            {d.needBrainrot && (
              <span className="ainput ainput--short">
                <input inputMode="numeric" value={d.needBrainrotCount} onChange={(e) => set('needBrainrotCount', e.target.value.replace(/\D/g, '').slice(0, 2))} aria-label="Сколько штук" />
                <small>шт.</small>
              </span>
            )}
          </span>
        </Field>
        {d.kind === 'draw' && (
          <div className="arow">
            <div>
              <p className="arow__title">Подписка на канал</p>
              <p className="acard__text">Участвовать и выиграть — только подписчикам канала бесплатного кейса (бот должен быть админом канала).</p>
            </div>
            <Switch on={d.needChannel} onChange={(v) => set('needChannel', v)} label="Подписка на канал" />
          </div>
        )}
        <Field label="Призовых мест">
          <span className="agw-places">
            {Array.from({ length: MAX_GIVEAWAY_PLACES }, (_, i) => i + 1).map((n) => (
              <button key={n} type="button" className={cx('chip chip--sm', d.prizes.length === n && 'is-active')} onClick={() => places(n)} aria-pressed={d.prizes.length === n}>
                {n}
              </button>
            ))}
          </span>
        </Field>
        <div className="agw-prizes">
          {d.prizes.map((id, i) => (
            <BrainrotPicker
              key={i}
              label={`${i + 1} место`}
              value={id}
              includeHidden={false}
              onChange={(v) => setD((x) => ({ ...x, prizes: x.prizes.map((p, k) => (k === i ? v : p)) }))}
            />
          ))}
        </div>
        <p className="agw-pool">
          Призовой фонд{' '}
          <span className="agw-pool__sum">
            <Coin size={13} /> <b>{formatCoins(pool)}</b>
          </span>{' '}
          — столько стоит розыгрыш: ровно эти призы и уйдут победителям.
        </p>
        <button type="button" className="btn btn--primary btn--block" disabled={!!problem || save.isPending} onClick={submit}>
          {problem ?? (d.id ? 'Сохранить изменения' : 'Запустить розыгрыш')}
        </button>
      </Card>

      <Card title="Розыгрыши">
        {list.isSuccess && rows.length === 0 && <Empty>Розыгрышей ещё не было — создай первый выше.</Empty>}
        <ul className="agw-list">
          {rows.map((g) => {
            const first = g.prizes[0] ? catalog.byId.get(g.prizes[0].brainrotId) : null;
            const open = g.status === 'active' || g.status === 'upcoming';
            return (
              <li key={g.id} className={cx('agw-item', !open && 'is-closed')}>
                <span className="agw-item__img">{g.banner ? <img src={g.banner} alt="" /> : first ? <BrainrotThumb brainrot={first} size={44} /> : null}</span>
                <span className="agw-item__what">
                  <b>{g.title}</b>
                  <small>
                    {GIVEAWAY_KIND_NAMES[g.kind]} · {STATUS[g.status]} · {formatWhen(g.startsAt)} — {formatWhen(g.endsAt)}
                  </small>
                  <small>
                    {g.prizes.length} мест · фонд {formatCoins(round2(g.prizes.reduce((s, p) => s + (catalog.byId.get(p.brainrotId)?.price ?? 0), 0)))} B
                    {g.kind === 'draw' ? ` · участников ${g.entries ?? 0}` : ''}
                    {g.status === 'finished' ? ` · победителей ${g.winners}` : ''}
                  </small>
                </span>
                <span className="agw-item__actions">
                  <a className="btn btn--ghost btn--sm" href={routeHref('giveaways', String(g.id))}>
                    Открыть
                  </a>
                  {open && (
                    <>
                      <button type="button" className="btn btn--ghost btn--sm" onClick={() => (setD(fromRow(g)), window.scrollTo({ top: 0, behavior: 'smooth' }))}>
                        Изменить
                      </button>
                      <ConfirmButton className="btn btn--primary btn--sm" confirmText="Подвести?" disabled={settle.isPending} onConfirm={() => settle.mutate(g.id)}>
                        Итоги сейчас
                      </ConfirmButton>
                      <ConfirmButton disabled={cancel.isPending} confirmText="Отменить?" onConfirm={() => cancel.mutate(g.id)}>
                        Отменить
                      </ConfirmButton>
                    </>
                  )}
                </span>
              </li>
            );
          })}
        </ul>
      </Card>
    </>
  );
}
