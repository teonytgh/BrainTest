import { createHmac } from 'node:crypto';
import { describe, expect, it } from 'vitest';
import { verifyInitData } from './telegram';

const TOKEN = '123456:TEST-TOKEN';

function sign(fields: Record<string, string>, token = TOKEN) {
  const check = Object.keys(fields)
    .sort()
    .map((k) => `${k}=${fields[k]}`)
    .join('\n');
  const secret = createHmac('sha256', 'WebAppData').update(token).digest();
  const hash = createHmac('sha256', secret).update(check).digest('hex');
  return new URLSearchParams({ ...fields, hash }).toString();
}

const now = 1_800_000_000;
const user = JSON.stringify({ id: 42, first_name: 'Teo', username: 'teonyt' });

describe('verifyInitData', () => {
  it('accepts a correctly signed payload', () => {
    const data = sign({ auth_date: String(now - 60), query_id: 'AAA', user });
    expect(verifyInitData(data, TOKEN, now)?.username).toBe('teonyt');
  });

  it('rejects a tampered user', () => {
    const data = sign({ auth_date: String(now), user }).replace('teonyt', 'admin');
    expect(verifyInitData(data, TOKEN, now)).toBeNull();
  });

  it('rejects a payload signed with another bot token', () => {
    expect(verifyInitData(sign({ auth_date: String(now), user }, '1:OTHER'), TOKEN, now)).toBeNull();
  });

  it('rejects stale payloads', () => {
    expect(verifyInitData(sign({ auth_date: String(now - 3 * 86400), user }), TOKEN, now)).toBeNull();
  });
});
