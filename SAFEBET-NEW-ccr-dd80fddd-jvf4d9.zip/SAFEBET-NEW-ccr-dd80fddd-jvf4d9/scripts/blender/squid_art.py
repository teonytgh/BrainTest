"""Art for «Игра Кальмара» (iteration 35). Our own look — not the show's doll: the watcher is a giant voxel Meowl.

    blender -b -y --factory-startup --python scripts/blender/squid_art.py -- OUT_DIR [--preview] [--only=watcher,…]

    watcher-back.png  — the giant Meowl statue seen from behind (green light: it looks away)
    watcher-red.png   — the same statue turned to the players, eyes glowing red (red light)
    cookie.png        — the honeycomb candy disc from above (the app stamps the shape on it)
    sword.png         — a voxel sword for the night fight's swing
    arena.png         — the night arena from above: a stone ring with torches under a red moon's light
    field.png         — «Тише едешь»: the sand playground from above between low walls (portrait)
    glass.png         — a tempered pane of the bridge in its steel frame
    glass-broken.png  — the same frame after the pane gave way: shards in the corners

`cwebp -q 86 -alpha_q 90` → public/squid/*.webp.
"""
import math
import os
import sys

import bmesh
import bpy
from mathutils import Vector

ARGS = sys.argv[sys.argv.index('--') + 1:] if '--' in sys.argv else []
POSITIONAL = [a for a in ARGS if not a.startswith('--')]
OUT = os.path.abspath(POSITIONAL[0] if POSITIONAL else 'squid_art')
PREVIEW = '--preview' in ARGS
ONLY = next((a.split('=', 1)[1].split(',') for a in ARGS if a.startswith('--only=')), None)
os.makedirs(OUT, exist_ok=True)
scene = bpy.context.scene
V = 0.1


def lin(c):
    def ch(v):
        v /= 255
        return v / 12.92 if v <= 0.04045 else ((v + 0.055) / 1.055) ** 2.4
    return (ch(c[0]), ch(c[1]), ch(c[2]), 1.0)


def hexrgb(h):
    h = h.lstrip('#')
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def clear():
    for o in list(bpy.data.objects):
        bpy.data.objects.remove(o, do_unlink=True)
    for m in list(bpy.data.meshes):
        bpy.data.meshes.remove(m)
    for m in list(bpy.data.materials):
        bpy.data.materials.remove(m)
    MATS.clear()


MATS = {}


def material(color, emit=0.0):
    key = (color, emit)
    if key not in MATS:
        m = bpy.data.materials.new(f'{color}-{emit}')
        m.use_nodes = True
        b = m.node_tree.nodes['Principled BSDF']
        b.inputs['Base Color'].default_value = lin(hexrgb(color))
        b.inputs['Roughness'].default_value = 0.7
        if emit:
            b.inputs['Emission Color'].default_value = lin(hexrgb(color))
            b.inputs['Emission Strength'].default_value = emit
        MATS[key] = m
    return MATS[key]


def h3(x, y, z, salt=0):
    n = (x * 374761393 + y * 668265263 + z * 2147483647 + salt * 1442695041) & 0xFFFFFFFF
    n = (n ^ (n >> 13)) * 1274126177 & 0xFFFFFFFF
    return ((n ^ (n >> 16)) & 0xFFFF) / 65536


DIRS = [((1, 0, 0), ((1, 0, 0), (1, 1, 0), (1, 1, 1), (1, 0, 1))), ((-1, 0, 0), ((0, 0, 0), (0, 0, 1), (0, 1, 1), (0, 1, 0))),
        ((0, 1, 0), ((0, 1, 0), (0, 1, 1), (1, 1, 1), (1, 1, 0))), ((0, -1, 0), ((0, 0, 0), (1, 0, 0), (1, 0, 1), (0, 0, 1))),
        ((0, 0, 1), ((0, 0, 1), (1, 0, 1), (1, 1, 1), (0, 1, 1))), ((0, 0, -1), ((0, 0, 0), (0, 1, 0), (1, 1, 0), (1, 0, 0)))]


def build(name, voxels, emit=None, scale=V):
    """voxels: {(x, y, z): '#rrggbb'}; `emit`: {colour: strength} for glowing ones."""
    by = {}
    for p, c in voxels.items():
        by.setdefault(c, []).append(p)
    for color, cells in by.items():
        bm = bmesh.new()
        for (x, y, z) in cells:
            for (dx, dy, dz), quad in DIRS:
                if (x + dx, y + dy, z + dz) in voxels:
                    continue
                bm.faces.new([bm.verts.new(((x + qx) * scale, (y + qy) * scale, (z + qz) * scale)) for qx, qy, qz in quad])
        me = bpy.data.meshes.new(f'{name}-{color}')
        bm.to_mesh(me)
        bm.free()
        o = bpy.data.objects.new(f'{name}-{color}', me)
        o.data.materials.append(material(color, (emit or {}).get(color, 0.0)))
        scene.collection.objects.link(o)


def ellipsoid(cx, cy, cz, rx, ry, rz):
    for x in range(math.floor(cx - rx), math.ceil(cx + rx) + 1):
        for y in range(math.floor(cy - ry), math.ceil(cy + ry) + 1):
            for z in range(math.floor(cz - rz), math.ceil(cz + rz) + 1):
                if ((x + 0.5 - cx) / rx) ** 2 + ((y + 0.5 - cy) / ry) ** 2 + ((z + 0.5 - cz) / rz) ** 2 <= 1:
                    yield x, y, z


def setup(size, w=None, world=(0.6, 0.65, 0.75), strength=0.6, sun=(-0.45, -0.6, 1.0), energy=3.0):
    scene.render.engine = 'CYCLES'
    scene.cycles.device = 'CPU'
    scene.cycles.samples = 24 if PREVIEW else 96
    scene.cycles.use_denoising = True
    scene.render.film_transparent = True
    scene.render.resolution_x = w or size
    scene.render.resolution_y = size
    scene.render.image_settings.file_format = 'PNG'
    scene.render.image_settings.color_mode = 'RGBA'
    scene.view_settings.view_transform = 'Standard'
    s = bpy.data.lights.new('sun', 'SUN')
    s.energy = energy
    s.angle = math.radians(22)
    o = bpy.data.objects.new('sun', s)
    scene.collection.objects.link(o)
    o.rotation_euler = Vector(sun).to_track_quat('Z', 'Y').to_euler()
    wd = bpy.data.worlds.new('w')
    wd.use_nodes = True
    wd.node_tree.nodes['Background'].inputs['Color'].default_value = (*world, 1)
    wd.node_tree.nodes['Background'].inputs['Strength'].default_value = strength
    scene.world = wd


def camera(loc, look, ortho):
    d = bpy.data.cameras.new('cam')
    d.type = 'ORTHO'
    d.ortho_scale = ortho
    cam = bpy.data.objects.new('cam', d)
    scene.collection.objects.link(cam)
    cam.location = loc
    cam.rotation_euler = (Vector(look) - Vector(loc)).to_track_quat('-Z', 'Y').to_euler()
    scene.camera = cam
    return cam


def shoot(name):
    scene.render.filepath = os.path.join(OUT, f'{name}.png')
    bpy.ops.render.render(write_still=True)
    print('rendered', name, flush=True)


# ---------- The watcher: a giant standing Meowl ----------

FUR = '#c98a4b'
FUR_DARK = '#8f5a2c'
FUR_LIGHT = '#dca46a'
WHITE = '#f6efe4'
PLINTH = '#8e8a84'


def watcher_voxels(red):
    """A standing Meowl, front = −y (towards the camera at the front). Face, belly and paws only on the front side."""
    vox = {}
    # A stone plinth.
    for x, y, z in ellipsoid(0, 0, 1.5, 11, 9, 2.5):
        if z >= 0:
            vox[(x, y, z)] = PLINTH if h3(x, y, z) > 0.25 else '#7c7872'
    # Body.
    for x, y, z in ellipsoid(0, 0, 13, 8.5, 6.5, 10):
        if z < 4:
            continue
        front = y <= -3
        c = WHITE if front and abs(x) <= 4 and z < 18 else (FUR_DARK if (z % 5 == 0 and not front) else (FUR if h3(x, y, z) > 0.2 else FUR_LIGHT))
        vox[(x, y, z)] = c
    # Head.
    for x, y, z in ellipsoid(0, -0.5, 28, 9.5, 8, 7.5):
        front = y <= -5
        c = FUR if h3(x, y, z, 1) > 0.18 else FUR_LIGHT
        if not front and z >= 31 and abs(x + 0.5) in (1.5, 3.5):
            c = FUR_DARK
        if front and z <= 27 and abs(x) <= 4:
            c = WHITE
        vox[(x, y, z)] = c
    # Ears.
    for sx in (-1, 1):
        for k, (x0, x1) in enumerate([(3, 8), (4, 7), (4, 7), (5, 6), (5, 6)]):
            for x in range(x0, x1 + 1):
                for y in range(-3, 2):
                    xx = x if sx > 0 else -x - 1
                    inner = y == -3 and x0 < x < x1 and k < 3
                    vox[(xx, y, 34 + k)] = '#e9a0ad' if inner else FUR
    # Face on the front (y = −8 … −7): eyes (red and glowing on «red»), nose, mouth.
    eye = '#ff2a2a' if red else '#46b06e'
    for sx in (-1, 1):
        ex = 3 if sx > 0 else -4
        for x in (ex, ex + sx):
            for z in (29, 30):
                vox[(x, -8, z)] = eye
        if not red:
            vox[(ex, -8, 30)] = '#1d2b22'
    for x in (-1, 0):
        vox[(x, -8, 27)] = '#e7889a'
    # Arms down the sides, white paws in front.
    for sx in (-1, 1):
        for z in range(8, 19):
            for x in (8, 9):
                vox[(x * sx if sx > 0 else -x - 1, -2, z)] = FUR
        for x in (6, 7):
            vox[((x if sx > 0 else -x - 1), -5, 7)] = WHITE
    # A tail curling up the back.
    for i in range(16):
        t = i / 15
        for x, y, z in ellipsoid(2.5 * math.sin(t * 3), 6.5 + 1.5 * math.sin(t * 2), 6 + i * 1.2, 1.6, 1.6, 1.0):
            vox[(x, y, z)] = WHITE if i >= 14 else (FUR_DARK if i % 4 == 1 else FUR)
    return vox


def watcher():
    for red in (False, True):
        clear()
        setup(256 if PREVIEW else 512, sun=(-0.3, -0.8, 1.0))
        vox = watcher_voxels(red)
        build('watcher', vox, emit={'#ff2a2a': 9.0})
        if red:
            camera((0, -20, 2.0), (0, 0, 2.0), 4.6)
            shoot('watcher-red')
        else:
            camera((0, 20, 2.0), (0, 0, 2.0), 4.6)
            shoot('watcher-back')


# ---------- The honeycomb candy ----------

def cookie():
    clear()
    setup(256 if PREVIEW else 512, sun=(-0.4, -0.5, 1.0), energy=3.4)
    bpy.ops.mesh.primitive_cylinder_add(vertices=96, radius=1.0, depth=0.12, location=(0, 0, 0))
    disc = bpy.context.active_object
    bpy.ops.object.shade_smooth()
    bev = disc.modifiers.new('bevel', 'BEVEL')
    bev.width = 0.05
    bev.segments = 4
    m = bpy.data.materials.new('candy')
    m.use_nodes = True
    nt = m.node_tree
    b = nt.nodes['Principled BSDF']
    b.inputs['Roughness'].default_value = 0.35
    vor = nt.nodes.new('ShaderNodeTexVoronoi')
    vor.inputs['Scale'].default_value = 26
    ramp = nt.nodes.new('ShaderNodeValToRGB')
    ramp.color_ramp.elements[0].position = 0.0
    ramp.color_ramp.elements[0].color = lin((240, 176, 64))
    ramp.color_ramp.elements[1].position = 0.9
    ramp.color_ramp.elements[1].color = lin((196, 118, 34))
    nt.links.new(vor.outputs['Distance'], ramp.inputs['Fac'])
    nt.links.new(ramp.outputs['Color'], b.inputs['Base Color'])
    bump = nt.nodes.new('ShaderNodeBump')
    bump.inputs['Strength'].default_value = 0.6
    nt.links.new(vor.outputs['Distance'], bump.inputs['Height'])
    nt.links.new(bump.outputs['Normal'], b.inputs['Normal'])
    disc.data.materials.append(m)
    camera((0, 0, 10), (0, 0, 0), 2.15)
    shoot('cookie')


# ---------- The sword ----------

def sword():
    clear()
    setup(128 if PREVIEW else 192, sun=(-0.4, -0.5, 1.0))
    vox = {}
    for y in range(0, 22):
        w = 1 if y < 20 else 0
        for x in range(-w, w + 1):
            vox[(x, y, 0)] = '#dfe6ee' if x == 0 else '#b9c3cf'
    for x in range(-4, 5):
        vox[(x, -1, 0)] = '#e2b042'
    for y in range(-6, -1):
        vox[(0, y, 0)] = '#6b3f22'
    vox[(0, -7, 0)] = '#e2b042'
    build('sword', vox, scale=0.1)
    camera((0, 0.75, 10), (0, 0.75, 0), 3.2)
    shoot('sword')


# ---------- The night arena ----------

def arena():
    clear()
    setup(512 if PREVIEW else 1024, world=(0.12, 0.04, 0.07), strength=0.35, sun=(0.3, 0.4, 1.0), energy=0.9)
    vox = {}
    R = 60
    for x in range(-R - 4, R + 4):
        for y in range(-R - 4, R + 4):
            d = math.hypot(x + 0.5, y + 0.5)
            if d > R + 3:
                continue
            if d > R:
                vox[(x, y, 1)] = '#5b4a45'
                vox[(x, y, 0)] = '#4a3c38'
                continue
            ring = int(d) // 6
            tile = (x // 3 + y // 3) % 2
            base = ['#57504e', '#4b4442', '#625a57'][ring % 3]
            vox[(x, y, 0)] = base if tile else ('#433d3b' if h3(x, y, 0, 3) > 0.5 else base)
            # Cracks and moss between the stones.
            if h3(x, y, 0, 9) < 0.03:
                vox[(x, y, 0)] = '#3b4a33'
    build('floor', vox, scale=0.05)
    # Torches round the ring: posts with glowing flames.
    for i in range(10):
        a = i / 10 * math.pi * 2
        cx, cy = math.cos(a) * (R + 1.5) * 0.05, math.sin(a) * (R + 1.5) * 0.05
        post = {}
        for z in range(2, 7):
            post[(0, 0, z)] = '#4a3428'
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                post[(dx, dy, 7)] = '#ff7a2a'
        post[(0, 0, 8)] = '#ffd27a'
        post[(0, 0, 9)] = '#ffe9a8'
        build(f'torch{i}', post, emit={'#ff7a2a': 30.0, '#ffd27a': 40.0, '#ffe9a8': 45.0}, scale=0.12)
        for o in bpy.data.objects:
            if o.name.startswith(f'torch{i}-'):
                o.location = (cx - 0.06, cy - 0.06, 0)
        lamp = bpy.data.lights.new(f'fire{i}', 'POINT')
        lamp.energy = 140
        lamp.color = (1.0, 0.55, 0.25)
        lamp.shadow_soft_size = 0.3
        lo = bpy.data.objects.new(f'fire{i}', lamp)
        lo.location = (cx, cy, 1.0)
        scene.collection.objects.link(lo)
    # The red moon's light from above.
    moon = bpy.data.lights.new('moon', 'AREA')
    moon.energy = 320
    moon.color = (1.0, 0.25, 0.25)
    moon.size = 6
    mo = bpy.data.objects.new('moon', moon)
    mo.location = (2.0, 3.0, 8.0)
    mo.rotation_euler = (Vector((0, 0, 0)) - Vector(mo.location)).to_track_quat('-Z', 'Y').to_euler()
    scene.collection.objects.link(mo)
    camera((0, 0, 20), (0, 0, 0), 6.4)
    shoot('arena')


# ---------- «Тише едешь»: the playground from above ----------

def field():
    """Sand from wall to wall, low teal walls on both sides, a raked start strip and footprints — the app adds the
    runners, the finish line and the statue."""
    clear()
    W = 48
    H = 2 * (W + 4)  # the frame is 1:2 and shows the walls
    setup(1024 if PREVIEW else 1280, w=(512 if PREVIEW else 640), world=(0.75, 0.72, 0.65), strength=0.5,
          sun=(-0.8, -0.35, 0.9), energy=3.6)
    vox = {}
    sands = ['#d8b47c', '#d4b078', '#dab880', '#d1ad75']
    for x in range(W):
        for y in range(H):
            n = h3(x, y, 0, 21)
            vox[(x, y, 0)] = sands[int(n * 4) % 4]
            # Small dunes: the odd raised grain.
            if h3(x, y, 1, 22) < 0.012:
                vox[(x, y, 1)] = '#e3c591'
            # A raked strip at the start: furrows across the field.
            if y < 8 and y % 2 == 0:
                vox[(x, y, 0)] = '#c59f63'
    # Footprints going up the field, a few trails.
    for trail in range(4):
        tx = 8 + trail * 11
        for step in range(10, H - 14, 5):
            fx = tx + (1 if (step // 5) % 2 else -1) + int(h3(trail, step, 0, 23) * 2)
            if 0 <= fx < W:
                vox[(fx, step, 0)] = '#b48f57'
                if fx + 1 < W:
                    vox[(fx + 1, step, 0)] = '#bb975f'
    # Walls along the sides: teal concrete with a pink cap.
    for y in range(H):
        for x in (-2, -1, W, W + 1):
            for z in range(0, 5):
                vox[(x, y, z)] = '#3f8f86' if z < 4 else '#e0577f'
    build('field', vox, scale=0.1)
    camera((W * 0.05, H * 0.05, 30), (W * 0.05, H * 0.05, 0), H * 0.1)  # ortho = the frame's height
    shoot('field')


# ---------- The glass bridge: a tempered pane and a broken one ----------

def glass_material(name):
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    b = m.node_tree.nodes['Principled BSDF']
    b.inputs['Base Color'].default_value = (0.75, 0.9, 1.0, 1)
    b.inputs['Transmission Weight'].default_value = 1.0
    b.inputs['Roughness'].default_value = 0.04
    b.inputs['IOR'].default_value = 1.45
    return m


def box(name, size, loc, mat):
    bpy.ops.mesh.primitive_cube_add(size=1, location=loc)
    o = bpy.context.active_object
    o.name = name
    o.scale = size
    bpy.ops.object.transform_apply(scale=True)
    bev = o.modifiers.new('bevel', 'BEVEL')
    bev.width = 0.02
    bev.segments = 3
    o.data.materials.append(mat)
    return o


def pane_light():
    # A long soft light at an angle: its reflection is the streak that makes glass read as glass from above.
    for i, (x, e) in enumerate(((-1.2, 260), (1.6, 120))):
        a = bpy.data.lights.new(f'streak{i}', 'AREA')
        a.energy = e
        a.shape = 'RECTANGLE'
        a.size = 0.3
        a.size_y = 4
        o = bpy.data.objects.new(f'streak{i}', a)
        o.location = (x, 0.3, 3.0)
        o.rotation_euler = (Vector((0, 0, 0)) - Vector(o.location)).to_track_quat('-Z', 'Y').to_euler()
        scene.collection.objects.link(o)


def glass_pane(broken):
    clear()
    setup(256 if PREVIEW else 400, w=(1024 if PREVIEW else 1600), world=(0.35, 0.45, 0.6), strength=0.4,
          sun=(-0.5, -0.8, 1.0), energy=2.0)
    scene.render.resolution_x = 512 if PREVIEW else 800
    scene.render.resolution_y = 128 if PREVIEW else 200
    scene.cycles.film_transparent_glass = True
    steel = material('#7d8794')
    steel.node_tree.nodes['Principled BSDF'].inputs['Metallic'].default_value = 0.9
    steel.node_tree.nodes['Principled BSDF'].inputs['Roughness'].default_value = 0.35
    W, H, T = 3.8, 0.9, 0.08
    # The frame: four bars.
    box('top', (W + 0.2, 0.1, 0.14), (0, H / 2 + 0.05, 0), steel)
    box('bottom', (W + 0.2, 0.1, 0.14), (0, -H / 2 - 0.05, 0), steel)
    box('left', (0.1, H, 0.14), (-W / 2 - 0.05, 0, 0), steel)
    box('right', (0.1, H, 0.14), (W / 2 + 0.05, 0, 0), steel)
    for bx in (-W / 2, W / 2):
        for by in (-H / 2, H / 2):
            bpy.ops.mesh.primitive_cylinder_add(radius=0.035, depth=0.04, location=(bx * 0.97, by * 0.86, 0.08))
            bpy.context.active_object.data.materials.append(material('#b8c0cc'))
    g = glass_material('glass')
    if not broken:
        box('pane', (W, H, T), (0, 0, 0), g)
    else:
        # Shards left in the frame's corners and edges, tilted down where the pane gave way.
        import random
        rnd = random.Random(7)
        for i in range(14):
            side = rnd.choice(((-1, 0), (1, 0), (0, -1), (0, 1)))
            if side[0]:
                cx = side[0] * (W / 2 - 0.12)
                cy = rnd.uniform(-H / 2 + 0.1, H / 2 - 0.1)
            else:
                cx = rnd.uniform(-W / 2 + 0.1, W / 2 - 0.1)
                cy = side[1] * (H / 2 - 0.1)
            r = rnd.uniform(0.08, 0.2)
            bm = bmesh.new()
            pts = []
            for k in range(3):
                a = rnd.uniform(0, math.pi * 2)
                pts.append((cx + math.cos(a) * r, cy + math.sin(a) * r * 0.7))
            top = [bm.verts.new((x, y, T / 2)) for x, y in pts]
            bot = [bm.verts.new((x, y, -T / 2)) for x, y in pts]
            bm.faces.new(top)
            bm.faces.new(bot[::-1])
            for k in range(3):
                bm.faces.new((top[k], top[(k + 1) % 3], bot[(k + 1) % 3], bot[k]))
            me = bpy.data.meshes.new(f'shard{i}')
            bm.to_mesh(me)
            bm.free()
            o = bpy.data.objects.new(f'shard{i}', me)
            o.data.materials.append(g)
            o.rotation_euler = (rnd.uniform(-0.4, 0.4), rnd.uniform(-0.4, 0.4), 0)
            scene.collection.objects.link(o)
    pane_light()
    camera((0, 0, 10), (0, 0, 0), W + 0.3)
    shoot('glass-broken' if broken else 'glass')


JOBS = {'watcher': watcher, 'cookie': cookie, 'sword': sword, 'arena': arena, 'field': field,
        'glass': lambda: glass_pane(False), 'glass-broken': lambda: glass_pane(True)}
for name, job in JOBS.items():
    if ONLY and name not in ONLY:
        continue
    job()
print('done', flush=True)
