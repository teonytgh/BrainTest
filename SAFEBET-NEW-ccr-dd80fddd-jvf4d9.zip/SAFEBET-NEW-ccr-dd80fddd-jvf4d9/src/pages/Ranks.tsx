import { useQuery } from '@tanstack/react-query';
import { useState } from 'react';
import { Coin } from '../components/Coin';
import { Icon } from '../components/Icon';
import { RankBadge } from '../components/RankBadge';
import { api, errorMessage } from '../api/client';
import { act, setMe, useCatalog } from '../api/queries';
import { RANKS, RANK_GIFT_TURNOVER } from '../../shared/ranks';
import { cx, formatCoins } from '../lib/format';
import { routeHref } from '../lib/router';
import { sfx } from '../lib/sound';
import { haptic } from '../lib/telegram';
import { toast } from '../store/toast';

interface RankState {
  rank: number;
  deposited: number;
  played: number;
  next: { level: number; from: number } | null;
  gifts: { level: number; gift: number; needPlayed: number; taken: boolean; reached: boolean; ready: boolean }[];
}

/** «Брейнрот-ранги»: the VIP club — the rank from everything deposited, its cashback and a one-time gift per rank. */
export function Ranks() {
  const catalog = useCatalog();
  const state = useQuery({ queryKey: ['ranks'], queryFn: () => api<RankState>('/api/ranks'), staleTime: 15_000 });
  const [busy, setBusy] = useState<number | null>(null);
  const s = state.data;
  const rank = RANKS[s?.rank ?? 0]!;
  const next = s?.next ? RANKS[s.next.level]! : null;
  const toNext = next && s ? Math.max(0, next.from - s.deposited) : 0;
  const share = next && s ? Math.min(1, (s.deposited - rank.from) / (next.from - rank.from)) : 1;

  async function claim(level: number) {
    if (busy !== null) return;
    setBusy(level);
    try {
      const r = await act<{ brainrotId: string | null; coins: number; value: number }>(`/api/ranks/${level}/claim`);
      setMe(r.me);
      void state.refetch();
      const b = r.result.brainrotId ? catalog.byId.get(r.result.brainrotId) : null;
      sfx.bigWin();
      haptic('success');
      toast(`Подарок ранга «${RANKS[level]!.name}»: ${b ? b.name : `${formatCoins(r.result.coins)} B`}`, 'success');
    } catch (e) {
      sfx.error();
      toast(errorMessage(e), 'error');
    } finally {
      setBusy(null);
    }
  }

  return (
    <section className="ranks" aria-labelledby="ranks-title">
      <h1 id="ranks-title" className="page-title">
        Брейнрот-ранги
      </h1>
      <div className={cx('rank-hero', `rank-hero--${rank.tier}`)}>
        <RankBadge rank={rank} size={92} />
        <div className="rank-hero__body">
          <small>Твой ранг</small>
          <b className="rank-hero__name">{rank.name}</b>
          <span className="rank-hero__perk">
            Кэшбэк <b>{rank.cashback}%</b> по пятницам
          </span>
        </div>
      </div>
      {s && (
        <div className="rank-progress">
          <div className="rank-progress__row">
            <span>
              Пополнено <b>{formatCoins(s.deposited)}</b> <Coin size={12} />
            </span>
            {next ? (
              <span>
                до «{next.name}» ещё <b>{formatCoins(toNext)}</b> B
              </span>
            ) : (
              <span>высший ранг</span>
            )}
          </div>
          <span className="rank-progress__bar" aria-hidden="true">
            <i style={{ transform: `scaleX(${share})` }} />
          </span>
        </div>
      )}

      <h2 className="section-title">Все ранги</h2>
      <ol className="rank-list">
        {RANKS.map((r) => {
          const gift = s?.gifts.find((g) => g.level === r.level);
          const reached = (s?.rank ?? 0) >= r.level;
          return (
            <li key={r.level} className={cx('rank-row', `rank-row--${r.tier}`, reached && 'is-reached', r.level === rank.level && 'is-current')}>
              <RankBadge rank={r} size={44} />
              <div className="rank-row__body">
                <b>{r.name}</b>
                <small>{r.from ? `от ${formatCoins(r.from)} B пополнений` : 'с первого дня'}</small>
                <span className="rank-row__perks">
                  <span>кэшбэк {r.cashback}%</span>
                  {r.gift > 0 && (
                    <span>
                      подарок {formatCoins(r.gift)} <Coin size={10} />
                    </span>
                  )}
                </span>
              </div>
              <div className="rank-row__side">
                {gift?.taken ? (
                  <span className="quest__got">
                    <Icon name="check" size={14} /> Получен
                  </span>
                ) : gift?.ready ? (
                  <button type="button" className="btn btn--primary btn--sm" disabled={busy !== null} onClick={() => void claim(r.level)}>
                    {busy === r.level ? '…' : 'Подарок'}
                  </button>
                ) : gift && reached && s ? (
                  <span className="rank-row__need">сыграй ещё {formatCoins(Math.max(0, gift.needPlayed - s.played))} B</span>
                ) : reached ? (
                  <Icon name="check" size={18} />
                ) : (
                  <Icon name="lock" size={16} />
                )}
              </div>
            </li>
          );
        })}
      </ol>
      <p className="hint hint--left">
        Ранг растёт от суммы всех пополнений (звёзды и брейнроты) и никогда не падает. Кэшбэк — это доля недельного проигрыша в кейсах и
        батлах, его забирают по пятницам в <a href={routeHref('bonuses')}>«Бонусах»</a>. Подарок ранга — брейнрот, он открывается, когда
        сыграешь в кейсах и батлах на сумму в {RANK_GIFT_TURNOVER} раза больше порога ранга. Крупные ранги админы видят в очереди выводов.
      </p>
    </section>
  );
}
