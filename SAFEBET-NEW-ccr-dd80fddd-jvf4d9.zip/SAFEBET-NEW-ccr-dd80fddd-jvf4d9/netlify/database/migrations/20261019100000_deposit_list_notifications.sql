-- Iteration 5: admin-managed deposit list, bot notifications and the free case gate.

-- Brainrots accepted as a deposit. price NULL = follow the catalog price; a number overrides it.
CREATE TABLE deposit_items (
  brainrot_id TEXT PRIMARY KEY REFERENCES brainrots (id) ON DELETE CASCADE,
  price NUMERIC(16, 2) CHECK (price IS NULL OR price > 0),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
INSERT INTO deposit_items (brainrot_id) SELECT id FROM brainrots WHERE status = 'active';

ALTER TABLE users
  ADD COLUMN bot_blocked_at TIMESTAMPTZ,
  ADD COLUMN free_notified_at TIMESTAMPTZ,
  ADD COLUMN comeback_sent_at TIMESTAMPTZ,
  ADD COLUMN free_share_at TIMESTAMPTZ;

-- One message to every player, sent in batches by the scheduled tick (last_user_id = where it stopped).
CREATE TABLE broadcasts (
  id BIGSERIAL PRIMARY KEY,
  kind TEXT NOT NULL,
  text TEXT NOT NULL,
  photo TEXT,
  button JSONB,
  created_by BIGINT NOT NULL,
  last_user_id BIGINT NOT NULL DEFAULT 0,
  sent INT NOT NULL DEFAULT 0,
  failed INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  -- A tick that takes the broadcast holds it until then, so two ticks never send the same batch.
  lease_until TIMESTAMPTZ,
  finished_at TIMESTAMPTZ
);
CREATE INDEX broadcasts_open ON broadcasts (id) WHERE finished_at IS NULL;

-- «Поделиться с другом» before each free case: prepared Telegram messages and their confirmations.
CREATE TABLE free_shares (
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT NOT NULL REFERENCES users (id) ON DELETE CASCADE,
  prepared_id TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  confirmed_at TIMESTAMPTZ
);
CREATE INDEX free_shares_user ON free_shares (user_id, created_at DESC);

INSERT INTO settings (key, value) VALUES ('free_case_gate', '{"channel":"@safebet_tgk","share":true}')
ON CONFLICT (key) DO NOTHING;
