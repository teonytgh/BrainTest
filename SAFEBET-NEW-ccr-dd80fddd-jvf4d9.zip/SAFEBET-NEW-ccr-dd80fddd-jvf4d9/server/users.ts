import { randomInt } from 'node:crypto';
import { db, one, type Queryable } from './db';
import { bad, notFound } from './errors';
import type { TelegramUser } from './telegram';

const ID_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

function newPublicId(): string {
  return Array.from({ length: 10 }, () => ID_ALPHABET[randomInt(ID_ALPHABET.length)]).join('');
}

export interface UserRow {
  id: string;
  public_id: string;
  username: string | null;
  first_name: string;
  last_name: string | null;
  photo_url: string | null;
  balance: string;
  media_platform: string | null;
  free_case_at: string | null;
  cases_opened: number;
  upgrades: number;
  dice_rolls: number;
  crash_rounds: number;
  withdrawn_value: string;
  created_at: string;
  last_seen_at: string;
  nick_case_at: string | null;
  ref_balance: string;
  /** Iteration 35 (absent until its migration ran): the demo part of `balance`. */
  demo_balance?: string;
  /** «Отыгрыш» (iteration 36): left to play before a withdrawal, and the current round (undefined before its migration). */
  wager_left?: string;
  wager_total?: string;
  terms_version: number | null;
  ref_percent: string | null;
  /** Iteration 32 (absent until its migration ran): quest tickets and the Meowl tour (done or skipped). */
  tickets?: number;
  onboarded_at?: string | null;
}

async function insertUser(db: Queryable, id: number, fields: { username?: string | null; first?: string; last?: string | null; photo?: string | null }, update: boolean) {
  for (let attempt = 0; attempt < 5; attempt++) {
    try {
      const username = fields.username ?? null;
      await db.query(
        `INSERT INTO users (id, public_id, username, username_lc, first_name, last_name, photo_url)
         VALUES ($1, $2, $3, $4, $5, $6, $7)
         ON CONFLICT (id) DO ${
           update
             ? `UPDATE SET username = EXCLUDED.username, username_lc = EXCLUDED.username_lc,
                first_name = EXCLUDED.first_name, last_name = EXCLUDED.last_name,
                photo_url = COALESCE(EXCLUDED.photo_url, users.photo_url), last_seen_at = now()`
             : 'NOTHING'
         }`,
        [id, newPublicId(), username, username?.toLowerCase() ?? null, fields.first ?? '', fields.last ?? null, fields.photo ?? null],
      );
      return;
    } catch (e) {
      if ((e as { code?: string; constraint?: string }).code === '23505' && String((e as Error).message).includes('public_id')) continue;
      throw e;
    }
  }
  throw new Error('Could not allocate a public id');
}

export function upsertTelegramUser(db: Queryable, tg: TelegramUser) {
  return insertUser(db, tg.id, { username: tg.username, first: tg.first_name, last: tg.last_name, photo: tg.photo_url }, true);
}

export async function getUser(id: number): Promise<UserRow | undefined> {
  return one<UserRow>('SELECT * FROM users WHERE id = $1', [id]);
}

/** "@name", "name" or a numeric Telegram ID. An unknown ID gets a stub row so a ban can be issued before the first visit. */
export async function resolveUser(ref: unknown, opts: { createById?: boolean } = {}): Promise<UserRow> {
  if (typeof ref !== 'string' && typeof ref !== 'number') throw bad('invalid', 'Укажи @username или ID');
  const raw = String(ref).trim().replace(/^@/, '');
  if (/^\d{3,15}$/.test(raw)) {
    const id = Number(raw);
    if (!Number.isSafeInteger(id)) throw bad('invalid', 'Неверный ID');
    let user = await getUser(id);
    if (!user && opts.createById) {
      await insertUser(db, id, {}, false);
      user = await getUser(id);
    }
    if (!user) throw notFound('Пользователь с таким ID ещё не заходил в приложение');
    return user;
  }
  if (!/^[a-z0-9_]{3,32}$/i.test(raw)) throw bad('invalid', 'Укажи @username или числовой ID');
  const user = await one<UserRow>('SELECT * FROM users WHERE username_lc = $1 ORDER BY last_seen_at DESC LIMIT 1', [raw.toLowerCase()]);
  if (!user) throw notFound(`@${raw} ещё не заходил в приложение`);
  return user;
}

export function displayName(u: Pick<UserRow, 'username' | 'first_name' | 'last_name' | 'id'>): string {
  if (u.username) return `@${u.username}`;
  const name = [u.first_name, u.last_name].filter(Boolean).join(' ');
  return name || `ID ${u.id}`;
}
