-- «Raining Tacos» event: each player catches falling coin-tacos. The pace (cooldown) and the daily cap are
-- enforced per player, so these columns hold the last catch time, how many were caught today and which MSK day
-- that count belongs to (it resets at Moscow midnight).
ALTER TABLE users
  ADD COLUMN IF NOT EXISTS taco_catch_at TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS taco_catches INTEGER NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS taco_day DATE;
