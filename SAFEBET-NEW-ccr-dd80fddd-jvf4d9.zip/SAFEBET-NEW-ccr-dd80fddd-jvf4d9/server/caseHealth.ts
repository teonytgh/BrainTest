import { db, num, tx, type Queryable } from './db';
import { caseMiss, composeCase, solveCaseChances, solveChances, suggestCasePrice, type PricedItem } from '../shared/cases';

/** admin_log rows written by the server itself (not by a person). */
export const SYSTEM_ADMIN_ID = 0;
/** Re-compose a case only when it is this far off its target average… */
const HEAL_AT = 0.04;
/** …and only if the new table is clearly better, so a case that cannot be fixed is not reshuffled every minute. */
const MIN_GAIN = 0.01;
/** The case editor's limit. */
const MAX_CASE_ITEMS = 60;

interface CaseRow {
  id: string;
  name: string;
  price: string;
  price_cycle: string[] | null;
}

async function load(c: Queryable) {
  // One query at a time: inside a transaction they share a single connection.
  // Ticket cases are priced in tickets, not coins: their composition is the admin's alone.
  const cases = await c.query<CaseRow>(`SELECT * FROM cases WHERE kind <> 'tickets' ORDER BY sort, price`);
  // Every row, disabled brainrots too: they are not counted (they don't drop) but they stay in the case.
  const items = await c.query<{ case_id: string; brainrot_id: string; price: string; fixed_chance: string | null; kind: string; status: string }>(
    `SELECT ci.case_id, ci.brainrot_id, b.price, ci.fixed_chance, b.kind, b.status FROM case_items ci JOIN brainrots b ON b.id = ci.brainrot_id
     ORDER BY b.price`,
  );
  const catalog = await c.query<{ id: string; price: string }>(`SELECT id, price FROM brainrots WHERE status = 'active' AND kind = 'brainrot'`);
  const pool: PricedItem[] = catalog.rows.map((b) => ({ id: b.id, price: num(b.price) }));
  return {
    pool,
    priceOf: new Map(pool.map((b) => [b.id, b.price])),
    cases: cases.rows.map((r) => {
      const all = items.rows.filter((i) => i.case_id === r.id);
      const own = all.filter((i) => i.status === 'active' || i.status === 'hidden');
      const fixed = own.map((i) => (i.fixed_chance === null ? null : Number(i.fixed_chance)));
      // Coin prizes are put into a case by hand, so such a case is the admin's call too (even while one is switched off).
      const manual = all.some((i) => i.fixed_chance !== null || i.kind === 'coins');
      const cycle = r.price_cycle?.length ? r.price_cycle.map(num) : null;
      return { id: r.id, name: r.name, price: num(r.price), cycle, ids: own.map((i) => i.brainrot_id), prices: own.map((i) => num(i.price)), fixed, manual };
    }),
  };
}

export interface HealResult {
  id: string;
  name: string;
  before: number;
  after: number;
  items: number;
}

/**
 * Keeps every case sane after catalog price edits: a case whose average drop is off target (e.g. all of its
 * items now cost more than the case) gets the missing items from the current catalog. Nothing is taken out —
 * the items in a case were picked by an admin. `force` rebuilds the given case from scratch (admin
 * «Пересобрать состав»).
 */
export async function healCases(opts: { caseId?: string; force?: boolean; adminId?: number } = {}): Promise<HealResult[]> {
  return tx(async (c) => {
    // One healer at a time (tick and an admin save may overlap); the other simply skips.
    const { rows: lock } = await c.query<{ ok: boolean }>('SELECT pg_try_advisory_xact_lock(4207011) AS ok');
    if (!lock[0]?.ok) return [];
    // Admin case saves lock their row too, so a save and a heal never rewrite case_items at the same time.
    await c.query(`SELECT id FROM cases ${opts.caseId ? 'WHERE id = $1' : ''} ORDER BY id FOR UPDATE`, opts.caseId ? [opts.caseId] : []);
    const { pool, priceOf, cases } = await load(c);
    const healed: HealResult[] = [];
    for (const k of cases) {
      if (opts.caseId && k.id !== opts.caseId) continue;
      // Chances set by hand or coin prizes: the admin runs this case, the healer leaves it alone (a forced rebuild resets them).
      if (k.manual && !opts.force) continue;
      // A floating price («Биткоин»): the case must fit every price it moves between, so whatever each one lacks
      // is added (the healer only adds; a forced rebuild starts from the union of fresh compositions).
      if (k.cycle) {
        const own = new Map(k.ids.map((id, i) => [id, k.prices[i]!]));
        let ids = opts.force ? [] : [...k.ids];
        for (const p of k.cycle) {
          const prices = ids.map((id) => own.get(id) ?? priceOf.get(id)!);
          if (!opts.force && ids.length >= 2 && caseMiss(prices, p) <= HEAL_AT) continue;
          ids = [...new Set([...ids, ...composeCase(pool, p, ids).ids])];
        }
        if (ids.length > MAX_CASE_ITEMS || ids.length < 2 || (!opts.force && ids.length === k.ids.length)) continue;
        if (opts.force) await c.query('DELETE FROM case_items WHERE case_id = $1', [k.id]);
        await c.query(
          'INSERT INTO case_items (case_id, brainrot_id, weight) SELECT $1, id, 1 FROM unnest($2::text[]) AS id ON CONFLICT (case_id, brainrot_id) DO NOTHING',
          [k.id, ids],
        );
        const nextPrices = ids.map((id) => own.get(id) ?? priceOf.get(id)!);
        const result = {
          id: k.id,
          name: k.name,
          before: Math.round(solveChances(k.prices, k.price).rtp * 1000) / 10,
          after: Math.round(solveChances(nextPrices, k.price).rtp * 1000) / 10,
          items: ids.length,
        };
        healed.push(result);
        await c.query('INSERT INTO admin_log (admin_id, action, target_user, details) VALUES ($1, $2, NULL, $3::jsonb)', [
          opts.adminId ?? SYSTEM_ADMIN_ID,
          opts.force ? 'case_recompose' : 'case_heal',
          JSON.stringify(result),
        ]);
        continue;
      }
      const missBefore = caseMiss(k.prices, k.price);
      if (!opts.force && missBefore <= HEAL_AT) continue;
      const composed = composeCase(pool, k.price, opts.force ? [] : k.ids);
      // What is in the case stays (the admin picked it): the healer only adds what the price needs. A forced
      // rebuild («Пересобрать состав») starts from scratch.
      const union = [...new Set([...k.ids, ...composed.ids])];
      // Never past the editor's limit: what doesn't fit isn't added (the admin can rebuild the case).
      if (!opts.force && union.length > MAX_CASE_ITEMS) continue;
      const next = { ids: opts.force ? composed.ids : union };
      const own = new Map(k.ids.map((id, i) => [id, k.prices[i]!]));
      const nextPrices = next.ids.map((id) => own.get(id) ?? priceOf.get(id)!);
      const missAfter = caseMiss(nextPrices, k.price);
      if (next.ids.length < 2) continue;
      if (!opts.force && missAfter > missBefore - MIN_GAIN) continue;
      if (!opts.force && next.ids.length === k.ids.length) continue; // nothing to add
      // A heal only inserts the new rows; a forced rebuild replaces the whole list.
      if (opts.force) await c.query('DELETE FROM case_items WHERE case_id = $1', [k.id]);
      await c.query(
        'INSERT INTO case_items (case_id, brainrot_id, weight) SELECT $1, id, 1 FROM unnest($2::text[]) AS id ON CONFLICT (case_id, brainrot_id) DO NOTHING',
        [k.id, next.ids],
      );
      const result = {
        id: k.id,
        name: k.name,
        before: Math.round(solveChances(k.prices, k.price).rtp * 1000) / 10,
        after: Math.round(solveChances(nextPrices, k.price).rtp * 1000) / 10,
        items: next.ids.length,
      };
      healed.push(result);
      await c.query('INSERT INTO admin_log (admin_id, action, target_user, details) VALUES ($1, $2, NULL, $3::jsonb)', [
        opts.adminId ?? SYSTEM_ADMIN_ID,
        opts.force ? 'case_recompose' : 'case_heal',
        JSON.stringify(result),
      ]);
    }
    return healed;
  });
}

/** Health of every case for the admin editor: average drop, profit chance and a working price if needed. */
export async function caseReport() {
  const { pool, cases } = await load(db);
  return Object.fromEntries(
    cases.map((k) => {
      const s = solveCaseChances(k.prices, k.fixed, k.price);
      return [k.id, { ok: s.ok, manual: s.manual, rtp: s.rtp, profit: s.profit, suggestedPrice: s.ok || s.manual ? null : suggestCasePrice(pool, k.price) }];
    }),
  );
}
