import { InventoryGrid, type InventoryItem } from './InventoryGrid';
import { Sheet } from './Sheet';
import { useMe } from '../api/queries';

interface Props {
  open: boolean;
  onClose: () => void;
  onPick: (item: InventoryItem) => void;
  selectedUid?: number | null;
}

export function InventoryPicker({ open, onClose, onPick, selectedUid }: Props) {
  const me = useMe();
  return (
    <Sheet open={open} onClose={onClose} title="Выбери брейнрота">
      <InventoryGrid
        items={me.inventory}
        selectedUid={selectedUid}
        onPick={(item) => {
          onPick(item);
          onClose();
        }}
      />
    </Sheet>
  );
}
