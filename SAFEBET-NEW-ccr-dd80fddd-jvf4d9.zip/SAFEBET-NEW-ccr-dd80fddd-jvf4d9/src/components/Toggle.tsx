import { Icon } from './Icon';
import { cx } from '../lib/format';

/** Lightning button that switches a game into its fast animation mode. */
export function FastToggle({ on, onChange, disabled }: { on: boolean; onChange: (on: boolean) => void; disabled?: boolean }) {
  return (
    <button
      type="button"
      className={cx('fast-toggle', on && 'is-on')}
      aria-pressed={on}
      aria-label={on ? 'Быстрый режим включён' : 'Быстрый режим выключен'}
      disabled={disabled}
      onClick={() => onChange(!on)}
    >
      <Icon name="bolt" size={22} />
    </button>
  );
}

export function Switch({ on, onChange, label, disabled }: { on: boolean; onChange: (on: boolean) => void; label: string; disabled?: boolean }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={on}
      aria-label={label}
      className={cx('switch', on && 'is-on')}
      disabled={disabled}
      onClick={() => onChange(!on)}
    >
      <span className="switch__thumb" />
    </button>
  );
}
