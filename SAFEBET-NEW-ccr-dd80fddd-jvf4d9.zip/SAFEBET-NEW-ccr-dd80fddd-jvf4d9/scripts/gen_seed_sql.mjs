// Writes the catalog seed migration from shared/seed/catalog.json.
import { readFileSync, writeFileSync } from 'node:fs';

const { brainrots, cases } = JSON.parse(readFileSync(new URL('../shared/seed/catalog.json', import.meta.url), 'utf8'));
const q = (s) => `'${String(s).replaceAll("'", "''")}'`;

const lines = ['INSERT INTO brainrots (id, name, price, image) VALUES'];
lines.push(brainrots.map((b) => `  (${q(b.id)}, ${q(b.name)}, ${b.price}, ${q(b.image)})`).join(',\n') + ';', '');
lines.push('INSERT INTO cases (id, name, price, image, kind, sort) VALUES');
lines.push(cases.map((c) => `  (${q(c.id)}, ${q(c.name)}, ${c.price}, ${q(c.image)}, ${q(c.free ? 'free' : 'paid')}, ${c.sort})`).join(',\n') + ';', '');
lines.push('INSERT INTO case_items (case_id, brainrot_id, weight) VALUES');
lines.push(
  cases.flatMap((c) => c.items.map((i) => `  (${q(c.id)}, ${q(i.brainrotId)}, ${i.weight})`)).join(',\n') + ';',
  '',
);

writeFileSync(new URL('../netlify/database/migrations/20261017150100_seed_catalog.sql', import.meta.url), lines.join('\n'));
console.log(`seeded ${brainrots.length} brainrots, ${cases.length} cases`);
