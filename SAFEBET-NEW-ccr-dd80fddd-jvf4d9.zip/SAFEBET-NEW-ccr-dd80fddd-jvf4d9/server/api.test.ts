import { createHash, createHmac } from 'node:crypto';
import { copyFileSync, mkdtempSync, readFileSync, readdirSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { NetlifyDB } from '@netlify/database-dev';
import pg from 'pg';
import { afterAll, afterEach, beforeAll, describe, expect, it, vi } from 'vitest';
import { usePool, type PoolLike } from './db';
import { handle } from './router';
import { useImageStore, type StoredImage } from './storage';
import { BotRefusal, useBotApi, useNotifier } from './telegram';
import { runNotifications } from './notifications';
import { runTick } from './tick';
import { healCases } from './caseHealth';
import { useCryptoApi } from './crypto';
import { ensureSchema } from './autoMigrate';
import { verifyLiveTicket, withLiveScope } from './live';
import { dropsByIds } from './liveDrops';
import { cashbackDayStart, isCashbackDay, weekIndex, weekStart } from '../shared/bonuses';
import { MAX_UPGRADE_CHANCE, UPGRADE_RTP } from '../shared/upgrader';
import { currentPromo } from '../shared/promo';
import { SUPPORT_URL } from './botWelcome';
import { skyTick } from './sky';
import { SkyRoom } from './rooms/sky';
import { SquidRoom } from './rooms/squid';
import { roomTicket, useRooms, verifyRoomTicket } from './rooms/bridge';
import { SKY_CHUNK, chunkCoins, type SkyCoin } from '../shared/sky';
import { fuseMessage, fuseTable, pickFuse } from '../shared/fuse';
import { ROAD_LEVELS, ROAD_RTP, laneCrashes, laneMultiplier, nextLaneProblem, roadLanes, roadMessage, type RoadLevel } from '../shared/road';
import { REF_MILESTONE_TURNOVER, REF_MILESTONES } from '../shared/bonuses';
import { TERMS_VERSION } from '../shared/legal';
import { PASS_FREE, PASS_LEVELS, PASS_PLUS_STARS, passLevelOf } from '../shared/pass';
import { RANKS, RANK_GIFT_TURNOVER } from '../shared/ranks';
import { DEPOSIT_QUEST, FRIEND_QUEST_REWARD, type Quest } from '../shared/quests';
import { MINES_RTP, MINES_TILES, clearChance, minesFromDigests, minesMessage, minesMultiplier, nextPickProblem } from '../shared/mines';

// Anti-spam is off for the suite (it fires requests back to back on purpose); its own test switches it on.
process.env.RATE_LIMIT = 'off';

// The tests bring their own two owners, whoever owns the real site (OWNER_IDS in env.ts).
vi.mock('./env', async (importOriginal) => {
  const actual = await importOriginal<typeof import('./env')>();
  const OWNER_IDS: readonly number[] = [7263901569, 5283820522];
  return { ...actual, OWNER_IDS, isOwnerId: (id: number) => OWNER_IDS.includes(id) };
});

const TOKEN = '777000:TEST-TOKEN';
const OWNER = 7263901569;
const OWNER2 = 5283820522;
const ALICE = 1001;
const BOB = 1002;
const CAROL = 1003;
const DAVE = 1004;
const EVE = 1005;
const FRANK = 1006;
const WEBHOOK_SECRET = createHmac('sha256', TOKEN).update('brainrotcrash-webhook').digest('hex');

let db: NetlifyDB;
let pool: pg.Pool;
const sent: { chatId: number; html: string }[] = [];
/** Every Bot API call the server made (sendMessage, editMessageText, createInvoiceLink…). */
const botCalls: { method: string; params: Record<string, unknown> }[] = [];
/** Chats that answer like a user who blocked the bot. */
const blockedChats = new Set<number>();
/** Players who are not (or no longer) subscribed to the free case channel. */
const unsubscribed = new Set<number>();
/** What getChat answers as a player's current Telegram name. */
const chatNames = new Map<number, string>();
let messageId = 0;
const images = new Map<string, StoredImage>();

function initData(id: number, username: string) {
  const fields: Record<string, string> = {
    auth_date: String(Math.floor(Date.now() / 1000)),
    query_id: 'Q',
    user: JSON.stringify({ id, first_name: username, username }),
  };
  const check = Object.keys(fields).sort().map((k) => `${k}=${fields[k]}`).join('\n');
  const secret = createHmac('sha256', 'WebAppData').update(TOKEN).digest();
  fields.hash = createHmac('sha256', secret).update(check).digest('hex');
  return new URLSearchParams(fields).toString();
}

const NAMES: Record<number, string> = { [OWNER]: 'owner', [OWNER2]: 'owner2', [ALICE]: 'alice', [BOB]: 'bob', [CAROL]: 'carol', [DAVE]: 'dave' };

async function call(as: number | null, method: string, path: string, body?: unknown) {
  const headers: Record<string, string> = { 'content-type': 'application/json' };
  if (as !== null) headers.authorization = `tma ${initData(as, NAMES[as] ?? `u${as}`)}`;
  const res = await handle(new Request(`http://local${path}`, { method, headers, body: body === undefined ? undefined : JSON.stringify(body) }));
  const text = await res.text();
  return { status: res.status, data: text ? JSON.parse(text) : null };
}

async function hook(update: unknown, secret: string | null = WEBHOOK_SECRET) {
  const headers: Record<string, string> = { 'content-type': 'application/json' };
  if (secret !== null) headers['x-telegram-bot-api-secret-token'] = secret;
  const res = await handle(new Request('http://local/api/telegram/webhook', { method: 'POST', headers, body: JSON.stringify(update) }));
  const text = await res.text();
  return { status: res.status, data: res.headers.get('content-type')?.includes('json') ? JSON.parse(text) : text };
}

const ok = async (as: number, method: string, path: string, body?: unknown) => {
  const r = await call(as, method, path, body);
  if (r.status !== 200) throw new Error(`${method} ${path} -> ${r.status} ${JSON.stringify(r.data)}`);
  return r.data;
};

/** Pins crypto.getRandomValues so the next server rolls are deterministic. */
function fixRandom(...values: number[]) {
  let i = 0;
  vi.spyOn(globalThis.crypto, 'getRandomValues').mockImplementation(<T extends ArrayBufferView | null>(arr: T): T => {
    const a = arr as unknown as Uint32Array;
    for (let k = 0; k < a.length; k++) a[k] = Math.floor((values[Math.min(i++, values.length - 1)] ?? 0) * 4294967296);
    return arr;
  });
}

async function buy(as: number, brainrotId: string) {
  const r = await ok(as, 'POST', '/api/shop/buy', { brainrotId });
  return r.result.itemId as number;
}

beforeAll(async () => {
  process.env.BOT_TOKEN = TOKEN;
  db = new NetlifyDB();
  const cs = await db.start();
  // Schema and seed only: the *_admin_snapshot.sql files carry production's catalog and cases, which the owner
  // reshapes at will (whole cases deleted) — the tests need the stable seed lineup.
  const dir = mkdtempSync(path.join(tmpdir(), 'brc-migrations-'));
  for (const f of readdirSync('./netlify/database/migrations')) if (!f.endsWith('_admin_snapshot.sql')) copyFileSync(path.join('./netlify/database/migrations', f), path.join(dir, f));
  await db.applyMigrations(dir);
  pool = new pg.Pool({ connectionString: cs, max: 1 });
  // 18+: the test players have accepted the consent (the iteration 31 tests check the gate with a player who hasn't).
  await pool.query(`ALTER TABLE users ALTER COLUMN terms_version SET DEFAULT ${TERMS_VERSION}`);
  usePool(pool as unknown as PoolLike);
  // The Worker's own migrations run once here (as on the first request), then: iteration 38 switched «Окуп ×0.5» on
  // for production; the tests check the usual model unless they turn it on.
  await ensureSchema();
  await pool.query(`DELETE FROM settings WHERE key = 'okup_cut'`);
  useNotifier(async (chatId, html) => {
    sent.push({ chatId, html });
    return true;
  });
  useImageStore({ put: async (k, img) => void images.set(k, img), get: async (k) => images.get(k) ?? null });
  useBotApi(async (method, params) => {
    botCalls.push({ method, params });
    if (blockedChats.has(Number(params.chat_id))) return new BotRefusal(403, 'Forbidden: bot was blocked by the user');
    if (method === 'createInvoiceLink') return `https://t.me/$invoice${botCalls.length}`;
    if (method === 'getChatMember') return { status: unsubscribed.has(Number(params.user_id)) ? 'left' : 'member' };
    if (method === 'savePreparedInlineMessage') return { id: `prep-${botCalls.length}`, expiration_date: 0 };
    if (method === 'getChat') return { id: params.chat_id, first_name: chatNames.get(Number(params.chat_id)) ?? 'Player' };
    if (method === 'sendMessage') return { message_id: ++messageId };
    return true;
  });
  // As the minute tick does in production: cases re-composed for the prices the migrations set.
  await healCases();
}, 60_000);

afterAll(async () => {
  useBotApi(null);
  usePool(null);
  await pool?.end();
  await db?.stop();
});

afterEach(() => vi.restoreAllMocks());

describe('auth', () => {
  it('rejects missing and forged initData', async () => {
    expect((await call(null, 'GET', '/api/me')).status).toBe(401);
    const res = await handle(new Request('http://local/api/me', { headers: { authorization: `tma ${initData(ALICE, 'alice').replace('alice', 'admin')}` } }));
    expect(res.status).toBe(401);
  });

  it('creates players on first visit; owners are admins', async () => {
    const me = await ok(ALICE, 'GET', '/api/me');
    expect(me.user).toMatchObject({ id: ALICE, username: 'alice', balance: 0, isAdmin: false });
    expect(me.user.publicId).toMatch(/^[A-Z2-9]{10}$/);
    const owner = await ok(OWNER, 'GET', '/api/me');
    expect(owner.user).toMatchObject({ isAdmin: true, isOwner: true });
    await ok(BOB, 'GET', '/api/me');
    await ok(CAROL, 'GET', '/api/me');
    await ok(OWNER2, 'GET', '/api/me');
  });

  it('keeps players out of admin routes', async () => {
    expect((await call(ALICE, 'GET', '/api/admin/stats')).status).toBe(403);
  });

  it('hands out live-socket tickets only where the socket exists (the Worker)', async () => {
    expect((await ok(ALICE, 'GET', '/api/live/ticket')).ticket).toBeNull();
    process.env.LIVE_UPDATES = '1';
    try {
      const { ticket } = await ok(ALICE, 'GET', '/api/live/ticket');
      expect(verifyLiveTicket(ticket)).toBe(ALICE);
    } finally {
      delete process.env.LIVE_UPDATES;
    }
  });
});

describe('economy and games', () => {
  it('there is no test deposit any more: coins come from Stars, brainrot deposits or an admin', async () => {
    expect((await call(ALICE, 'POST', '/api/deposit', { amount: 1000 })).status).toBe(404);
    expect((await call(OWNER, 'POST', '/api/deposit', { amount: 1000 })).status).toBe(404);
    expect((await ok(OWNER, 'GET', '/api/me')).demoDeposits).toBeUndefined();
    // The same coins the old test deposits used to mint, so the tests below keep their numbers.
    const bonus = Math.floor((1000 * currentPromo().percent) / 100);
    await pool.query('UPDATE users SET balance = balance + $2 WHERE id = $1', [OWNER, 2000 + bonus]);
    await ok(OWNER, 'POST', '/api/admin/give', { user: String(ALICE), type: 'coins', amount: 2000 + bonus });
  });

  it('upgrade at stake/target (45 / 87.4) wins Jolly Jolly Sahur for Garama on a low roll', async () => {
    const item = await buy(ALICE, 'garama-and-madundung');
    fixRandom(0.1);
    const r = await ok(ALICE, 'POST', '/api/upgrade', { itemId: item, targetId: 'jolly-jolly-sahur' });
    expect(r.result).toMatchObject({ win: true, targetId: 'jolly-jolly-sahur' });
    expect(r.result.chance).toBeCloseTo((45 / 87.4) * UPGRADE_RTP, 4);
    expect(r.me.inventory.map((i: { brainrotId: string }) => i.brainrotId)).toEqual(['jolly-jolly-sahur']);
    expect(r.me.user.stats.upgrades).toBe(1);
  });

  it('upgrade loses the stake on a high roll and refuses cheaper targets', async () => {
    const item = await buy(ALICE, 'garama-and-madundung');
    expect((await call(ALICE, 'POST', '/api/upgrade', { itemId: item, targetId: 'cash-or-card' })).data.error).toBe('bad_target');
    fixRandom(0.9);
    const r = await ok(ALICE, 'POST', '/api/upgrade', { itemId: item, targetId: 'capitano-moby' });
    expect(r.result.win).toBe(false);
    expect(r.me.inventory).toHaveLength(1);
    expect((await call(ALICE, 'POST', '/api/upgrade', { itemId: item, targetId: 'capitano-moby' })).data.error).toBe('no_item');
  });

  it('dice pays x2 for exactly one match', async () => {
    const item = await buy(ALICE, 'garama-and-madundung');
    // Brainrots only: coins are no stake in dice either (rejected before the item is taken).
    expect((await call(ALICE, 'POST', '/api/dice', { itemId: item, color: 'red', coins: 10 })).data.error).toBe('items_only');
    // colors index = floor(r * 6): 0.0 → red, 0.5 → green
    fixRandom(0.0, 0.5, 0.5, 0.5);
    const r = await ok(ALICE, 'POST', '/api/dice', { itemId: item, color: 'red' });
    expect(r.result).toMatchObject({ faces: ['red', 'green', 'green', 'green'], matches: 1, multiplier: 2 });
    // 90 B: the dearest brainrot that fits (87.4) plus the rest in coins.
    expect(r.result.payout).toMatchObject({ brainrotId: 'jolly-jolly-sahur', coins: 2.6 });
  });

  it('opens a paid case and enforces the free-case cooldown', async () => {
    const before = (await ok(ALICE, 'GET', '/api/me')).user.balance;
    const r = await ok(ALICE, 'POST', '/api/case/open', { caseId: 'noobini' });
    expect(r.me.user.balance).toBe(before - 55);
    const catalog = await ok(ALICE, 'GET', '/api/catalog');
    const noobini = catalog.cases.find((c: { id: string }) => c.id === 'noobini');
    expect(noobini.items.map((i: { brainrotId: string }) => i.brainrotId)).toContain(r.result.brainrotId);
    // The free case wants the project's channel and a share with a friend first.
    unsubscribed.add(ALICE);
    expect((await call(ALICE, 'POST', '/api/case/open', { caseId: 'free' })).data).toMatchObject({ error: 'need_channel', channel: '@BrainrotCrash' });
    expect((await ok(ALICE, 'GET', '/api/free-case/gate')).channel).toMatchObject({ status: 'missing', url: 'https://t.me/BrainrotCrash' });
    unsubscribed.delete(ALICE);
    expect((await call(ALICE, 'POST', '/api/case/open', { caseId: 'free' })).data.error).toBe('need_share');
    const share = await ok(ALICE, 'POST', '/api/free-case/share');
    expect(share.preparedId).toMatch(/^prep-/);
    const prepared = lastCall('savePreparedInlineMessage', undefined)!;
    expect(prepared.params).toMatchObject({ user_id: ALICE, allow_group_chats: true });
    // The friend lands on the sharer's own referral link.
    const aliceCode = (await ok(ALICE, 'GET', '/api/referrals')).code;
    expect(JSON.stringify(prepared.params.result)).toContain(`start=r-${aliceCode}`);
    // The app prepares it before the tap: asking again hands out the same message until it is confirmed.
    const prepares = botCalls.filter((c) => c.method === 'savePreparedInlineMessage').length;
    expect(await ok(ALICE, 'POST', '/api/free-case/share')).toEqual(share);
    expect(botCalls.filter((c) => c.method === 'savePreparedInlineMessage').length).toBe(prepares);
    expect((await call(BOB, 'POST', '/api/free-case/share/confirm', { shareId: share.shareId })).data.error).toBe('share_expired');
    expect((await ok(ALICE, 'POST', '/api/free-case/share/confirm', { shareId: share.shareId })).ready).toBe(true);
    // A confirmation counts once, and the next share is a new message.
    expect((await call(ALICE, 'POST', '/api/free-case/share/confirm', { shareId: share.shareId })).data.error).toBe('share_expired');
    expect((await ok(ALICE, 'POST', '/api/free-case/share')).shareId).not.toBe(share.shareId);
    await ok(ALICE, 'POST', '/api/case/open', { caseId: 'free' });
    const again = await call(ALICE, 'POST', '/api/case/open', { caseId: 'free' });
    expect(again.data.error).toBe('cooldown');
    expect(again.data.nextAt).toBeGreaterThan(Date.now());
    // Next time it asks for a new share.
    await pool.query(`UPDATE users SET free_case_at = now() - interval '13 hours', free_share_at = now() - interval '13 hours 1 minute' WHERE id = $1`, [ALICE]);
    expect((await call(ALICE, 'POST', '/api/case/open', { caseId: 'free' })).data.error).toBe('need_share');
  });

  it('sells one item and then everything', async () => {
    const me = await ok(ALICE, 'GET', '/api/me');
    const first = me.inventory[0];
    const r = await ok(ALICE, 'POST', '/api/inventory/sell', { itemIds: [first.id] });
    expect(r.result.sold).toBe(1);
    const all = await ok(ALICE, 'POST', '/api/inventory/sell', { all: true });
    expect(all.me.inventory).toHaveLength(0);
    expect((await call(ALICE, 'POST', '/api/inventory/sell', { all: true })).data.error).toBe('no_item');
  });

  it('crash auto cash-out at x2 pays the dearest brainrot that fits', async () => {
    const item = await buy(ALICE, 'garama-and-madundung');
    fixRandom(0.9); // crash point 0.96 / 0.1 → 9.59 after 32-bit rounding
    const start = await ok(ALICE, 'POST', '/api/crash/start', { itemId: item, auto: 2 });
    vi.restoreAllMocks();
    await pool.query(`UPDATE crash_rounds SET started_at = now() - interval '7 seconds' WHERE id = $1`, [start.result.roundId]);
    const r = await ok(ALICE, 'POST', '/api/crash/wait', { roundId: start.result.roundId });
    expect(r.result).toMatchObject({ status: 'cashed', cashedAt: 2, crashPoint: 9.59 });
    expect(r.result.payout.brainrotId).toBe('jolly-jolly-sahur');
  });

  it('crash ends a round that blows up before the auto cash-out', async () => {
    const item = await buy(ALICE, 'garama-and-madundung');
    fixRandom(0.0); // 0.96 → floored to 1.00, instant crash
    const start = await ok(ALICE, 'POST', '/api/crash/start', { itemId: item, auto: 2 });
    vi.restoreAllMocks();
    const r = await ok(ALICE, 'POST', '/api/crash/wait', { roundId: start.result.roundId });
    expect(r.result).toMatchObject({ status: 'crashed', crashPoint: 1 });
    expect(r.me.crash).toBeNull();
  });

  it('manual cash-out uses the server clock', async () => {
    const item = await buy(ALICE, 'capitano-moby');
    fixRandom(0.9);
    const start = await ok(ALICE, 'POST', '/api/crash/start', { itemId: item, auto: null });
    vi.restoreAllMocks();
    expect((await call(ALICE, 'POST', '/api/crash/start', { itemId: item, auto: null })).data.error).toBe('active_round');
    await pool.query(`UPDATE crash_rounds SET started_at = now() - interval '3 seconds' WHERE id = $1`, [start.result.roundId]);
    const r = await ok(ALICE, 'POST', '/api/crash/cashout', { roundId: start.result.roundId });
    expect(r.result.status).toBe('cashed');
    // x2 takes 8 s, so 3 s in is about x1.3.
    expect(r.result.cashedAt).toBeGreaterThan(1.28);
    expect(r.result.cashedAt).toBeLessThan(1.36);
  });

  it('Haunted Fuse: 3–4 brainrots in, one random brainrot out, picked by the pre-committed key', async () => {
    const s = await ok(ALICE, 'GET', '/api/fuse');
    expect(s.nextHash).toMatch(/^[0-9a-f]{64}$/);
    expect((await ok(ALICE, 'GET', '/api/fuse')).nextHash).toBe(s.nextHash);
    const a = await buy(ALICE, 'garama-and-madundung');
    const b = await buy(ALICE, 'garama-and-madundung');
    const c3 = await buy(ALICE, 'garama-and-madundung');
    expect((await call(ALICE, 'POST', '/api/fuse', { itemIds: [a] })).data.error).toBe('invalid');
    expect((await call(ALICE, 'POST', '/api/fuse', { itemIds: [a, b] })).data.error).toBe('invalid');
    expect((await call(ALICE, 'POST', '/api/fuse', { itemIds: [1, 2, 3, 4, 5] })).data.error).toBe('invalid');
    expect((await call(ALICE, 'POST', '/api/fuse', { itemIds: [a, b, c3], coins: 10 })).data.error).toBe('items_only');

    const r = await ok(ALICE, 'POST', '/api/fuse', { itemIds: [a, b, c3] });
    const d = r.result;
    expect(d.stakeValue).toBe(135);
    expect(d.hash).toBe(s.nextHash);
    expect(createHash('sha256').update(d.seed).digest('hex')).toBe(d.hash);
    const catalog = (await pool.query(`SELECT id, price::float AS price FROM brainrots WHERE status = 'active'`)).rows;
    const table = fuseTable(135, catalog)!;
    const expected = pickFuse(table, createHash('sha256').update(fuseMessage(d.seed)).digest('hex'));
    expect(d.brainrotId).toBe(expected.id);
    expect(d.value).toBe(expected.price);
    expect(d.value).toBeLessThanOrEqual(270);
    expect(r.me.inventory.some((i: { id: number }) => i.id === a || i.id === b || i.id === c3)).toBe(false);
    expect(r.me.inventory.some((i: { id: number; brainrotId: string }) => i.id === d.itemId && i.brainrotId === d.brainrotId)).toBe(true);
    const s2 = await ok(ALICE, 'GET', '/api/fuse');
    expect(s2.nextHash).toBe(d.nextHash);
    expect(s2.mine[0]).toMatchObject({ brainrotId: d.brainrotId, stakeValue: 135, value: d.value, from: ['garama-and-madundung', 'garama-and-madundung', 'garama-and-madundung'] });
    const drop = (await pool.query(`SELECT result, payout_value FROM drops WHERE user_id = $1 AND game = 'fuse' ORDER BY id DESC LIMIT 1`, [ALICE])).rows[0];
    expect(Number(drop.payout_value)).toBe(d.value);

    // Nothing in the catalog is worth a set of the three dearest brainrots: refused, and nothing is taken.
    const dearest = (await pool.query(`SELECT id FROM brainrots WHERE status = 'active' ORDER BY price DESC LIMIT 1`)).rows[0].id;
    await ok(OWNER, 'POST', '/api/admin/give', { user: String(ALICE), type: 'brainrot', brainrotId: dearest, amount: 3 });
    const three = (await ok(ALICE, 'GET', '/api/me')).inventory.filter((i: { brainrotId: string }) => i.brainrotId === dearest).slice(0, 3).map((i: { id: number }) => i.id);
    expect((await call(ALICE, 'POST', '/api/fuse', { itemIds: three })).data.error).toBe('stake_too_big');
    expect((await ok(ALICE, 'GET', '/api/me')).inventory.filter((i: { brainrotId: string }) => i.brainrotId === dearest)).toHaveLength(3);
    await pool.query('DELETE FROM inventory WHERE user_id = $1 AND brainrot_id = $2', [ALICE, dearest]);
  });

  it('upgrade takes up to 5 brainrots as one stake, brainrots only, at most a 75 % chance', async () => {
    const a = await buy(ALICE, 'garama-and-madundung');
    const b = await buy(ALICE, 'garama-and-madundung');
    const before = (await ok(ALICE, 'GET', '/api/me')).user.balance;
    expect((await call(ALICE, 'POST', '/api/upgrade', { itemIds: [a, b], coins: 10, targetId: 'capitano-moby' })).data.error).toBe('items_only');
    expect((await call(ALICE, 'POST', '/api/upgrade', { itemIds: [], targetId: 'capitano-moby' })).data.error).toBe('invalid');
    expect((await call(ALICE, 'POST', '/api/upgrade', { itemIds: [1, 2, 3, 4, 5, 6], targetId: 'capitano-moby' })).data.error).toBe('invalid');
    // A chance above the cap is no upgrade: a target just a bit dearer than 90 is refused, nothing is taken.
    const easy = (await pool.query(`SELECT id FROM brainrots WHERE status = 'active' AND kind = 'brainrot' AND price > 90 AND price < $1 ORDER BY price LIMIT 1`, [(90 * UPGRADE_RTP) / MAX_UPGRADE_CHANCE])).rows[0];
    if (easy) expect((await call(ALICE, 'POST', '/api/upgrade', { itemIds: [a, b], targetId: easy.id })).data.error).toBe('too_easy');
    expect((await ok(ALICE, 'GET', '/api/me')).inventory.filter((i: { id: number }) => i.id === a || i.id === b)).toHaveLength(2);
    // 45 + 45 = 90 against 120.75: 74.5 % × 0.8 = 59.6 %.
    fixRandom(0.1);
    const r = await ok(ALICE, 'POST', '/api/upgrade', { itemIds: [a, b], targetId: 'capitano-moby' });
    expect(r.result).toMatchObject({ win: true, stakeValue: 90 });
    expect(r.result.chance).toBeCloseTo((90 / 120.75) * UPGRADE_RTP, 6);
    expect(r.me.user.balance).toBeCloseTo(before, 2);
    expect(r.me.inventory.some((i: { id: number }) => i.id === a || i.id === b)).toBe(false);
  });
});

describe('admin', () => {
  it('gives coins by @username and brainrots by ID', async () => {
    sent.length = 0;
    const r = await ok(OWNER, 'POST', '/api/admin/give', { user: '@bob', type: 'coins', amount: 500 });
    expect(r.notified).toBe(true);
    await ok(OWNER, 'POST', '/api/admin/give', { user: String(BOB), type: 'brainrot', brainrotId: 'meowl', amount: 2 });
    const me = await ok(BOB, 'GET', '/api/me');
    expect(me.user.balance).toBe(500);
    expect(me.inventory.filter((i: { brainrotId: string }) => i.brainrotId === 'meowl')).toHaveLength(2);
    expect(sent.map((s) => s.chatId)).toEqual([BOB, BOB]);
  });

  it('bans with a bot message and lifts the ban', async () => {
    sent.length = 0;
    const r = await ok(OWNER, 'POST', '/api/admin/punish', { user: '@carol', kind: 'ban', amount: 3, unit: 'day', reason: 'спам' });
    expect(sent[0]?.html).toContain('заблокирован');
    const banned = await call(CAROL, 'GET', '/api/me');
    expect(banned.status).toBe(403);
    expect(banned.data).toMatchObject({ error: 'banned', reason: 'спам' });
    expect(banned.data.until).toBeGreaterThan(Date.now() + 2.9 * 86400_000);
    const list = await ok(OWNER, 'GET', '/api/admin/punishments');
    expect(list[0]).toMatchObject({ kind: 'ban', active: true });
    await ok(OWNER, 'POST', `/api/admin/punishments/${r.id}/revoke`);
    expect((await call(CAROL, 'GET', '/api/me')).status).toBe(200);
  });

  it('freezes players into spectators', async () => {
    const r = await ok(OWNER, 'POST', '/api/admin/punish', { user: String(BOB), kind: 'freeze', amount: 1, unit: 'month' });
    const me = await ok(BOB, 'GET', '/api/me');
    expect(me.user.frozen).toMatchObject({ id: r.id });
    expect((await call(BOB, 'POST', '/api/case/open', { caseId: 'noobini' })).data.error).toBe('frozen');
    expect((await call(BOB, 'POST', '/api/inventory/sell', { all: true })).data.error).toBe('frozen');
    await ok(OWNER, 'POST', `/api/admin/punishments/${r.id}/revoke`);
    await ok(BOB, 'POST', '/api/case/open', { caseId: 'noobini' });
  });

  it('nobody can punish an owner, and only owners can punish admins', async () => {
    expect((await call(OWNER, 'POST', '/api/admin/punish', { user: String(OWNER2), kind: 'ban', unit: 'forever' })).status).toBe(403);
    await ok(OWNER, 'POST', '/api/admin/admins', { user: '@carol' });
    expect((await call(CAROL, 'POST', '/api/admin/punish', { user: String(OWNER), kind: 'ban', unit: 'forever' })).status).toBe(403);
    expect((await call(CAROL, 'POST', '/api/admin/admins', { user: '@bob' })).status).toBe(403);
    await ok(CAROL, 'GET', '/api/admin/stats');
    await ok(OWNER, 'DELETE', `/api/admin/admins/${CAROL}`);
    expect((await call(CAROL, 'GET', '/api/admin/stats')).status).toBe(403);
    expect((await call(OWNER, 'DELETE', `/api/admin/admins/${OWNER2}`)).status).toBe(403);
  });

  it('maintenance closes the app for players only', async () => {
    await ok(OWNER, 'POST', '/api/admin/settings', { maintenance: { enabled: true, message: 'Обновляем кейсы' } });
    const r = await call(ALICE, 'GET', '/api/me');
    expect(r.status).toBe(503);
    expect(r.data.message).toBe('Обновляем кейсы');
    expect((await ok(OWNER, 'GET', '/api/me')).maintenance.enabled).toBe(true);
    await ok(OWNER, 'POST', '/api/admin/settings', { maintenance: { enabled: false, message: '' } });
    expect((await call(ALICE, 'GET', '/api/me')).status).toBe(200);
  });

  it('promo codes: any language, spaces, limited activations', async () => {
    const created = await ok(OWNER, 'POST', '/api/admin/promos', { code: 'Летний Бонус', maxUses: 1, rewardType: 'coins', amount: 300 });
    expect((await call(OWNER, 'POST', '/api/admin/promos', { code: 'летний  бонус', maxUses: 1, rewardType: 'coins', amount: 1 })).status).toBe(409);
    const before = (await ok(BOB, 'GET', '/api/me')).user.balance;
    const r = await ok(BOB, 'POST', '/api/promo', { code: '  летний   бонус ' });
    expect(r.me.user.balance).toBe(before + 300);
    expect((await call(ALICE, 'POST', '/api/promo', { code: 'Летний Бонус' })).data.error).toBe('promo_exhausted');
    const list = await ok(OWNER, 'GET', '/api/admin/promos');
    expect(list.codes[0]).toMatchObject({ code: 'Летний Бонус', uses: 1, maxUses: 1 });
    await ok(OWNER, 'POST', '/api/admin/promos', { code: 'Brain Drop', maxUses: 5, rewardType: 'brainrot', brainrotId: 'meowl', amount: 1 });
    const br = await ok(ALICE, 'POST', '/api/promo', { code: 'brain drop' });
    expect(br.result).toMatchObject({ type: 'brainrot', brainrotId: 'meowl' });
    await ok(OWNER, 'DELETE', `/api/admin/promos/${created.id}`);
    expect((await ok(OWNER, 'GET', '/api/admin/promos')).codes).toHaveLength(1);
  });

  it('catalog edits apply everywhere; new brainrots use uploaded images', async () => {
    await ok(OWNER, 'PATCH', '/api/admin/brainrots/capitano-moby', { price: 120, name: 'Capitano Moby X' });
    const cat = await ok(ALICE, 'GET', '/api/catalog');
    expect(cat.brainrots.find((b: { id: string }) => b.id === 'capitano-moby')).toMatchObject({ price: 120, name: 'Capitano Moby X' });
    const png = Buffer.from('89504e470d0a1a0a0000000d4948445200000001000000010806000000', 'hex').toString('base64');
    expect((await call(OWNER, 'POST', '/api/admin/upload', { dataUrl: 'data:image/svg+xml;base64,PHN2Zz4=' })).status).toBe(400);
    const { url } = await ok(OWNER, 'POST', '/api/admin/upload', { dataUrl: `data:image/png;base64,${png}` });
    expect(url).toMatch(/^\/api\/img\/[a-f0-9]{24}$/);
    const img = await handle(new Request(`http://local${url}`));
    expect(img.headers.get('content-type')).toBe('image/png');
    const created = await ok(OWNER, 'POST', '/api/admin/brainrots', { name: 'Brainrot Crash Hero', price: 777, image: url });
    await ok(OWNER, 'PATCH', `/api/admin/brainrots/${created.id}`, { status: 'hidden' });
    expect((await call(ALICE, 'POST', '/api/shop/buy', { brainrotId: created.id })).data.error).toBe('unavailable');
    await ok(OWNER, 'DELETE', `/api/admin/brainrots/${created.id}`);
    expect((await ok(OWNER, 'GET', '/api/admin/brainrots')).some((b: { id: string }) => b.id === created.id)).toBe(false);
  });

  it('titles can be created, granted and revoked', async () => {
    const t = await ok(OWNER, 'POST', '/api/admin/titles', { name: 'Герой', description: 'За тесты', icon: '/brainrots/meowl.webp', color: '#ffcc00' });
    await ok(OWNER, 'POST', `/api/admin/titles/${t.id}/grant`, { user: '@alice' });
    expect((await call(OWNER, 'POST', `/api/admin/titles/${t.id}/grant`, { user: '@alice' })).data.error).toBe('exists');
    const me = await ok(ALICE, 'GET', '/api/me');
    expect(me.user.titles[0]).toMatchObject({ name: 'Герой', holders: 1, color: '#ffcc00' });
    await ok(OWNER, 'POST', `/api/admin/titles/${t.id}/revoke`, { userId: ALICE });
    expect((await ok(ALICE, 'GET', '/api/me')).user.titles).toHaveLength(0);
  });

  it('media partners get a platform badge', async () => {
    await ok(OWNER, 'POST', '/api/admin/media', { user: '@alice', platform: 'youtube' });
    expect((await ok(ALICE, 'GET', '/api/me')).user.media).toBe('youtube');
    await ok(OWNER, 'DELETE', `/api/admin/media/${ALICE}`);
    expect((await ok(ALICE, 'GET', '/api/me')).user.media).toBeNull();
  });

  it('case editor replaces items and the log records admin actions', async () => {
    await ok(OWNER, 'PATCH', '/api/admin/cases/noobini', { price: 25, items: [{ brainrotId: 'love-love-bear' }, { brainrotId: 'meowl' }] });
    const cat = await ok(ALICE, 'GET', '/api/catalog');
    const c = cat.cases.find((x: { id: string }) => x.id === 'noobini');
    expect(c.price).toBe(25);
    // Two items far above a 25 B case would pay out at a loss: the server completes the case from the catalog.
    const admin = (await ok(OWNER, 'GET', '/api/admin/cases')).find((x: { id: string }) => x.id === 'noobini');
    expect(admin.items.length).toBeGreaterThan(2);
    const logs = await ok(OWNER, 'GET', '/api/admin/logs');
    expect(logs.find((l: { action: string }) => l.action === 'case_update')).toMatchObject({ admin: '@owner' });
    // Players only: the owner and the admin aren't counted.
    const stats = await ok(OWNER, 'GET', '/api/admin/stats');
    expect(stats.users).toBe(3);
  });
});

describe('telegram stars', () => {
  // The admin snapshot carries production's rate; these tests are written for 1.35 coins per star.
  beforeAll(() => pool.query(`UPDATE settings SET value = '{"rate": 1.35}'::jsonb WHERE key = 'stars'`));
  const invoices = { at: (i: number) => botCalls.filter((c) => c.method === 'createInvoiceLink').map((c) => c.params).at(i) };
  const checkout = (from: number, payload: string, amount: number, id = 'pcq') =>
    hook({ update_id: 1, pre_checkout_query: { id, from: { id: from, first_name: 'x' }, currency: 'XTR', total_amount: amount, invoice_payload: payload } });
  const paid = (from: number, payload: string, amount: number, charge: string) =>
    hook({
      update_id: 2,
      message: {
        message_id: 1,
        from: { id: from, first_name: 'x' },
        chat: { id: from, type: 'private' },
        successful_payment: { currency: 'XTR', total_amount: amount, invoice_payload: payload, telegram_payment_charge_id: charge, provider_payment_charge_id: '' },
      },
    });
  const say = (from: number, text: string) => hook({ update_id: 3, message: { message_id: 2, from: { id: from, first_name: 'dave' }, chat: { id: from, type: 'private' }, text } });

  it('rejects webhook calls without the secret', async () => {
    expect((await hook({ update_id: 9 }, null)).status).toBe(403);
    expect((await hook({ update_id: 9 }, 'nope')).status).toBe(403);
    expect((await hook({ update_id: 9 })).data).toEqual({});
  });

  it('invoice → checkout → payment credits coins and the promo bonus exactly once', async () => {
    const promo = currentPromo();
    const { balance: before, wager: wagerBefore } = (await ok(DAVE, 'GET', '/api/me')).user;
    expect((await call(DAVE, 'POST', '/api/stars/invoice', { stars: 5 })).status).toBe(400);
    expect((await call(DAVE, 'POST', '/api/stars/invoice', { stars: 100, promo: 'NOT-A-CODE' })).data.error).toBe('promo_invalid');

    const inv = await ok(DAVE, 'POST', '/api/stars/invoice', { stars: 100, promo: ` ${promo.code.toLowerCase()} ` });
    const bonus = Math.floor((135 * promo.percent) / 100);
    expect(inv).toMatchObject({ stars: 100, coins: 135, bonus, percent: promo.percent, link: expect.stringContaining('t.me') });
    const sentInvoice = invoices.at(-1)!;
    expect(sentInvoice).toMatchObject({ currency: 'XTR', provider_token: '', payload: `stars:${inv.orderId}`, prices: [{ amount: 100 }] });
    expect(String(sentInvoice.title).length).toBeLessThanOrEqual(32);
    const payload = `stars:${inv.orderId}`;

    expect((await call(BOB, 'GET', `/api/stars/orders/${inv.orderId}`)).status).toBe(404);
    expect((await checkout(BOB, payload, 100)).data).toMatchObject({ method: 'answerPreCheckoutQuery', ok: false });
    expect((await checkout(DAVE, payload, 99)).data).toMatchObject({ ok: false });
    expect((await checkout(DAVE, 'stars:999999', 100)).data).toMatchObject({ ok: false });
    expect((await checkout(DAVE, payload, 100)).data).toEqual({ method: 'answerPreCheckoutQuery', pre_checkout_query_id: 'pcq', ok: true });
    expect((await ok(DAVE, 'GET', `/api/stars/orders/${inv.orderId}`)).status).toBe('pending');

    const r = await paid(DAVE, payload, 100, 'charge-1');
    expect(r.data).toMatchObject({ method: 'sendMessage', chat_id: DAVE, reply_markup: { inline_keyboard: [[{ web_app: { url: 'http://local/' } }]] } });
    expect(r.data.text).toContain(`${135 + bonus} B`);
    const me = await ok(DAVE, 'GET', '/api/me');
    expect(me.user.balance).toBe(before + 135 + bonus);
    expect(me.promo.bonus).toMatchObject({ status: 'used' });
    // «Отыгрыш» (iteration 36; ×2 since iteration 38): the deposit with its bonus is played through before a withdrawal.
    expect(me.user.wager.left).toBeCloseTo(wagerBefore.left + (135 + bonus) * 2, 2);

    expect((await paid(DAVE, payload, 100, 'charge-1')).data).toEqual({});
    expect((await ok(DAVE, 'GET', '/api/me')).user.balance).toBe(before + 135 + bonus);
    expect((await checkout(DAVE, payload, 100, 'pcq2')).data).toMatchObject({ ok: false, error_message: expect.stringContaining('оплачен') });
    expect(await ok(DAVE, 'GET', `/api/stars/orders/${inv.orderId}`)).toMatchObject({ status: 'paid', coins: 135, bonus });
    expect((await call(DAVE, 'POST', '/api/stars/invoice', { stars: 100, promo: promo.code })).data.error).toBe('promo_used');
  });

  it('admins set the rate and see payments', async () => {
    expect((await call(OWNER, 'POST', '/api/admin/settings', { starRate: 1.234 })).status).toBe(400);
    expect((await call(ALICE, 'GET', '/api/admin/payments')).status).toBe(403);
    await ok(OWNER, 'POST', '/api/admin/settings', { starRate: 2 });
    expect((await ok(DAVE, 'GET', '/api/me')).starRate).toBe(2);
    expect(await ok(DAVE, 'POST', '/api/stars/invoice', { stars: 50 })).toMatchObject({ coins: 100, bonus: 0 });
    await ok(OWNER, 'POST', '/api/admin/settings', { starRate: 1.35 });
    const list = await ok(OWNER, 'GET', '/api/admin/payments');
    expect(list.totals).toMatchObject({ stars: 100, count: 1 });
    expect(list.payments[0]).toMatchObject({ userId: DAVE, stars: 100, user: '@dave' });
    expect((await ok(OWNER, 'GET', '/api/admin/stats')).stars).toBe(100);
  });

  it('bot answers /start, /terms and forwards /paysupport to owners once per 10 minutes', async () => {
    const hello = (await say(DAVE, '/start')).data;
    expect(hello).toMatchObject({ method: 'sendPhoto', chat_id: DAVE, parse_mode: 'HTML' });
    expect(hello.photo).toMatch(/\/promo\/welcome\.jpg\?v=\d+$/); // versioned: Telegram caches photos by URL
    expect(hello.caption).toContain('Добро пожаловать в BrainrotCrash');
    expect(hello.caption.length).toBeLessThanOrEqual(1024);
    expect(hello.reply_markup.inline_keyboard).toEqual([
      [{ text: '📢 Новости', url: 'https://t.me/BrainrotCrash' }, ...(SUPPORT_URL ? [{ text: '💬 Поддержка', url: SUPPORT_URL }] : [])],
      [{ text: '🎮 Играть', web_app: { url: expect.stringMatching(/^https?:\/\/[^/]+\/$/) } }],
      [{ text: '🎟 Ввести код', callback_data: 'code' }],
    ]);
    expect((await say(DAVE, '/terms@braincrashbot')).data.text).toContain('Условия');
    expect((await say(DAVE, '/paysupport')).data.text).toContain('Опиши проблему');
    sent.length = 0;
    expect((await say(DAVE, '/paysupport монеты не пришли')).data.text).toContain('Передали');
    expect(sent.filter((m) => m.html.includes('монеты не пришли')).map((m) => m.chatId).sort()).toEqual([OWNER2, OWNER].sort());
    expect((await say(DAVE, '/paysupport ещё раз')).data.text).toContain('уже получили');
    expect((await say(DAVE, 'привет')).data).toEqual({});
  });

  it('«🎟 Ввести код» asks for a code by force-reply and activates it like the app does', async () => {
    await ok(OWNER, 'POST', '/api/admin/promos', { code: 'BOT GIFT', maxUses: 5, rewardType: 'coins', amount: 15 });
    const prompt = (await hook({ update_id: 4, callback_query: { id: 'cq-code', from: { id: DAVE, first_name: 'dave' }, data: 'code' } })).data;
    expect(prompt).toMatchObject({ method: 'sendMessage', chat_id: DAVE, reply_markup: { force_reply: true } });
    const before = (await ok(DAVE, 'GET', '/api/me')).user.balance;
    const answer = (msg: string) =>
      hook({ update_id: 5, message: { message_id: 3, from: { id: DAVE, first_name: 'dave' }, chat: { id: DAVE, type: 'private' }, text: msg, reply_to_message: { text: prompt.text } } });
    expect((await answer('bot gift')).data.text).toContain('+15 B');
    expect((await ok(DAVE, 'GET', '/api/me')).user.balance).toBeCloseTo(before + 15, 2);
    expect((await answer('BOT GIFT')).data.text).toContain('уже активировал');
    expect((await answer('НЕТ ТАКОГО')).data.text).toContain('Такого промокода нет');
    // «/code» without a code asks for it; with one activates straight away.
    expect((await say(DAVE, '/code')).data.reply_markup).toMatchObject({ force_reply: true });
    expect((await say(DAVE, '/code bot gift')).data.text).toContain('уже активировал');
  });
});

describe('several cases at once', () => {
  const MULTI = 1888;
  it('one press opens 3 or 5 paid cases: one payment of price × N, every drop rolled and recorded on its own', async () => {
    await ok(MULTI, 'GET', '/api/me');
    const png = Buffer.from('89504e470d0a1a0a0000000d4948445200000001000000010806000000', 'hex').toString('base64');
    const { url } = await ok(OWNER, 'POST', '/api/admin/upload', { dataUrl: `data:image/png;base64,${png}` });
    const kase = await ok(OWNER, 'POST', '/api/admin/cases', {
      name: 'Мульти кейс',
      price: 100,
      image: url,
      items: [{ brainrotId: 'garama-and-madundung', chance: 0.5 }, { brainrotId: 'bupin-bani', chance: 0.5 }],
    });
    await ok(OWNER, 'POST', '/api/admin/give', { user: String(MULTI), type: 'coins', amount: 350 });
    const r = await ok(MULTI, 'POST', '/api/case/open', { caseId: kase.id, count: 3 });
    expect(r.result.drops).toHaveLength(3);
    expect(r.result.drops.every((d: { brainrotId: string; itemId: number }) => ['garama-and-madundung', 'bupin-bani'].includes(d.brainrotId) && d.itemId > 0)).toBe(true);
    expect(r.result.brainrotId).toBe(r.result.drops[0].brainrotId);
    expect(r.me.user.balance).toBeCloseTo(50, 2);
    expect(r.me.inventory).toHaveLength(3);
    const rows = (await pool.query(`SELECT stake_value FROM drops WHERE user_id = $1 AND game = 'case'`, [MULTI])).rows;
    expect(rows.map((x) => Number(x.stake_value))).toEqual([100, 100, 100]);
    expect((await pool.query('SELECT cases_opened FROM users WHERE id = $1', [MULTI])).rows[0].cases_opened).toBe(3);
    // Not enough for three more: refused, nothing taken.
    expect((await call(MULTI, 'POST', '/api/case/open', { caseId: kase.id, count: 3 })).data.error).toBe('no_money');
    expect((await ok(MULTI, 'GET', '/api/me')).user.balance).toBeCloseTo(50, 2);
    // Only 1, 3 and 5; gifts, free and bonus cases one at a time.
    for (const count of [2, 4, 6, 0]) expect((await call(MULTI, 'POST', '/api/case/open', { caseId: kase.id, count })).data.error).toBe('invalid');
    expect((await call(MULTI, 'POST', '/api/case/open', { caseId: kase.id, count: 3, useKey: true })).data.error).toBe('invalid');
    expect((await call(MULTI, 'POST', '/api/case/open', { caseId: 'free', count: 3 })).data.error).toBe('invalid');
    await ok(OWNER, 'DELETE', `/api/admin/cases/${kase.id}`);
  });
});

describe('LIVE drops', () => {
  const LIVER = 1777;
  it('the newest winning drops of everyone, with the player shown like the top drop; each one is pushed once', async () => {
    await ok(LIVER, 'GET', '/api/me');
    // A case of its own, so earlier price edits of the seed cases don't matter here.
    const png = Buffer.from('89504e470d0a1a0a0000000d4948445200000001000000010806000000', 'hex').toString('base64');
    const { url } = await ok(OWNER, 'POST', '/api/admin/upload', { dataUrl: `data:image/png;base64,${png}` });
    const kase = await ok(OWNER, 'POST', '/api/admin/cases', {
      name: 'Live кейс',
      price: 100,
      image: url,
      items: [{ brainrotId: 'garama-and-madundung', chance: 1 }, { brainrotId: 'meowl', chance: 0 }],
    });
    await ok(OWNER, 'POST', '/api/admin/give', { user: String(LIVER), type: 'case', caseId: kase.id, amount: 1 });
    const scoped = await withLiveScope(() => ok(LIVER, 'POST', '/api/case/open', { caseId: kase.id, useKey: true }));
    const ids = scoped.takeDrops();
    expect(ids).toHaveLength(1);
    expect(scoped.takeDrops()).toHaveLength(0);
    const live = await ok(ALICE, 'GET', '/api/drops/live');
    expect(live[0]).toMatchObject({ id: ids[0], brainrotId: scoped.result.result.brainrotId, game: 'case' });
    expect(Object.keys(live[0].player).sort()).toEqual(['name', 'photo', 'publicId']);
    const eve = (await pool.query('SELECT public_id, first_name, last_name FROM users WHERE id = $1', [LIVER])).rows[0];
    expect(live[0].player).toMatchObject({ publicId: eve.public_id, name: [eve.first_name, eve.last_name].filter(Boolean).join(' ') });
    expect(live.length).toBeLessThanOrEqual(20);
    expect(live.map((d: { id: number }) => d.id)).toEqual([...live.map((d: { id: number }) => d.id)].sort((a, b) => b - a));
    // What the Worker pushes after the response is read back from the database.
    expect((await dropsByIds(ids)).map((d) => d.id)).toEqual(ids);
    expect(await dropsByIds([987654321])).toEqual([]);
    // A lost upgrade is not a drop.
    await ok(OWNER, 'POST', '/api/admin/give', { user: String(LIVER), type: 'coins', amount: 100 });
    const lose = await withLiveScope(async () => {
      const item = await buy(LIVER, 'garama-and-madundung');
      fixRandom(0.999999);
      const r = await ok(LIVER, 'POST', '/api/upgrade', { itemIds: [item], targetId: 'meowl' });
      vi.restoreAllMocks();
      return r;
    });
    expect(lose.result.result.win).toBe(false);
    expect(lose.takeDrops()).toHaveLength(0);
    await ok(OWNER, 'DELETE', `/api/admin/cases/${kase.id}`);
  });
});

describe('public profiles', () => {
  it('top drop links to the player, whose profile hides the balance', async () => {
    const cat = await ok(BOB, 'GET', '/api/catalog');
    expect(cat.topDrop.playerId).toMatch(/^[A-Z2-9]{10}$/);
    const p = await ok(BOB, 'GET', `/api/players/${cat.topDrop.playerId}`);
    expect(p).toMatchObject({ publicId: cat.topDrop.playerId, stats: expect.any(Object), inventory: expect.any(Array) });
    expect(p).not.toHaveProperty('balance');
    expect(p).not.toHaveProperty('id');
    // Other players see the Telegram name only, never the @username.
    expect(p).not.toHaveProperty('username');
    expect(cat.topDrop.player).not.toMatch(/^@/);
    expect((await call(BOB, 'GET', '/api/players/NOPE')).status).toBe(404);
    expect((await call(BOB, 'GET', '/api/players/ZZZZZZZZZZ')).status).toBe(404);
  });

  it('iteration 41: an admin clears «Топ дроп дня»; the drops stay in the history', async () => {
    expect((await ok(BOB, 'GET', '/api/catalog')).topDrop).not.toBeNull();
    expect((await call(BOB, 'POST', '/api/admin/top-drop/reset')).status).toBe(403);
    await ok(OWNER, 'POST', '/api/admin/top-drop/reset');
    expect((await ok(BOB, 'GET', '/api/catalog')).topDrop).toBeNull();
    expect(Number((await pool.query(`SELECT count(*) AS n FROM drops WHERE result = 'win'`)).rows[0].n)).toBeGreaterThan(0);
    await pool.query(`DELETE FROM settings WHERE key = 'top_drop_since'`);
  });
});

describe('kopecks', () => {
  it('keeps two decimals through buy, sell and admin prices', async () => {
    await ok(OWNER, 'POST', '/api/admin/give', { user: '@dave', type: 'coins', amount: '500,5' });
    const before = (await ok(DAVE, 'GET', '/api/me')).user.balance;
    const item = await buy(DAVE, 'guest-666');
    expect((await ok(DAVE, 'GET', '/api/me')).user.balance).toBeCloseTo(before - 188.1, 2);
    const sold = await ok(DAVE, 'POST', '/api/inventory/sell', { itemIds: [item] });
    expect(sold.result.coins).toBe(188.1);
    expect(sold.me.user.balance).toBe(before);
    expect((await call(OWNER, 'PATCH', '/api/admin/brainrots/guest-666', { price: '1,234' })).status).toBe(400);
    await ok(OWNER, 'PATCH', '/api/admin/brainrots/guest-666', { price: '199,99' });
    const cat = await ok(DAVE, 'GET', '/api/catalog');
    expect(cat.brainrots.find((b: { id: string }) => b.id === 'guest-666').price).toBe(199.99);
  });
});

const tap = (from: number, data: string) => hook({ update_id: 10, callback_query: { id: `cb${Date.now()}`, from: { id: from, first_name: 'x' }, data } });
const lastCall = (method: string, chatId?: number) => [...botCalls].reverse().find((c) => c.method === method && (chatId === undefined || c.params.chat_id === chatId));

describe('cases follow prices', () => {
  type Kase = { id: string; price: number; mystery: boolean; items: { brainrotId: string; weight: number }[]; health: { ok: boolean; rtp: number; profit: number } };
  const adminCase = async (id: string) => ((await ok(OWNER, 'GET', '/api/admin/cases')) as Kase[]).find((c) => c.id === id)!;
  const pricesOf = async () => new Map<string, number>((await ok(EVE, 'GET', '/api/catalog')).brainrots.map((b: { id: string; price: number }) => [b.id, b.price]));

  it('chances come from prices (88% average, 2% окуп) and players never see them', async () => {
    const prices = await pricesOf();
    const moon = await adminCase('moon');
    expect(moon.items.reduce((s, i) => s + i.weight, 0)).toBeCloseTo(1, 9);
    expect(moon.items.reduce((s, i) => s + prices.get(i.brainrotId)! * i.weight, 0)).toBeCloseTo(moon.price * moon.health.rtp, 6);
    expect(moon.health.ok).toBe(true);
    expect(moon.items.reduce((s, i) => s + (prices.get(i.brainrotId)! > moon.price ? i.weight : 0), 0)).toBeCloseTo(0.02, 6);
    // Players only get flattened reel weights.
    const shown = (await ok(EVE, 'GET', '/api/catalog')).cases.find((c: Kase) => c.id === 'moon') as Kase;
    const real = new Map(moon.items.map((i) => [i.brainrotId, i.weight]));
    expect(shown.items.some((i) => Math.abs(i.weight - real.get(i.brainrotId)!) > 0.01)).toBe(true);
    expect(shown.mystery).toBe(false);
    expect((await adminCase('mystery')).mystery).toBe(true);
    // A pricier item gets rarer.
    const top = [...moon.items].sort((a, b) => prices.get(b.brainrotId)! - prices.get(a.brainrotId)!)[0]!;
    await ok(OWNER, 'PATCH', `/api/admin/brainrots/${top.brainrotId}`, { price: prices.get(top.brainrotId)! * 3 });
    expect((await adminCase('moon')).items.find((i) => i.brainrotId === top.brainrotId)!.weight).toBeLessThan(top.weight);
  });

  it('a case re-priced into a loss gets a new composition at once', async () => {
    // Real brainrots only: coin prizes (10 B, 15 B…) never go into an automatic composition.
    const catalog = (await ok(EVE, 'GET', '/api/catalog')).brainrots as { id: string; price: number; kind: string }[];
    const prices = new Map(catalog.filter((x) => x.kind !== 'coins').map((x) => [x.id, x.price] as const));
    const cheap = [...prices].sort((a, b) => a[1] - b[1])[0]!;
    // Make nearly every item of «lucky» cost more than the case.
    const lucky = await adminCase('lucky');
    const priciest = [...prices].sort((a, b) => b[1] - a[1]).slice(0, 2).map(([brainrotId]) => ({ brainrotId }));
    const r = await ok(OWNER, 'PATCH', '/api/admin/cases/lucky', { price: Math.round(cheap[1] * 3), items: priciest });
    expect(r.healed.map((h: { id: string }) => h.id)).toContain('lucky');
    const healed = await adminCase('lucky');
    expect(healed.health.ok).toBe(true);
    expect(healed.items.map((i) => i.brainrotId)).not.toEqual(lucky.items.map((i) => i.brainrotId));
    expect((await ok(OWNER, 'GET', '/api/admin/logs')).some((l: { action: string }) => l.action === 'case_heal')).toBe(true);
    // Below the cheapest brainrot nothing can fix it: the case refuses to open instead of paying out at a loss.
    await ok(OWNER, 'PATCH', '/api/admin/cases/lucky', { price: Math.max(1, Math.floor(cheap[1] / 2)) });
    expect((await call(EVE, 'POST', '/api/case/open', { caseId: 'lucky' })).data.error).toBe('case_rebalancing');
    await ok(OWNER, 'PATCH', '/api/admin/cases/lucky', { price: lucky.price, items: lucky.items.map(({ brainrotId }) => ({ brainrotId })) });
  });

  it('x2 luck doubles the chance of profitable drops but not the average', async () => {
    const before = (await adminCase('lavaka')).health;
    await ok(OWNER, 'POST', '/api/admin/settings', { luck: { minutes: 30 } });
    expect((await ok(EVE, 'GET', '/api/me')).luckUntil).toBeGreaterThan(Date.now() + 29 * 60_000);
    const prices = await pricesOf();
    const lavaka = await adminCase('lavaka');
    const profit = lavaka.items.reduce((s, i) => s + (prices.get(i.brainrotId)! > lavaka.price ? i.weight : 0), 0);
    expect(profit).toBeCloseTo(before.profit * 2, 6);
    expect(lavaka.items.reduce((s, i) => s + prices.get(i.brainrotId)! * i.weight, 0) / lavaka.price).toBeCloseTo(before.rtp, 4);
    await ok(OWNER, 'POST', '/api/admin/settings', { luck: { minutes: 0 } });
    expect((await ok(EVE, 'GET', '/api/me')).luckUntil).toBeNull();
  });

  it('admins set drop chances by hand (exact %, down to 0.0001 %, «Невозможно»); the healer leaves them', async () => {
    const prices = await pricesOf();
    const toxic = await adminCase('toxic');
    const ids = [...toxic.items].sort((x, y) => prices.get(x.brainrotId)! - prices.get(y.brainrotId)!).map((i) => i.brainrotId);
    const [cheapest, second, third, ...rest] = ids as [string, string, string, ...string[]];
    const priciest = rest[rest.length - 1]!;
    await ok(OWNER, 'PATCH', '/api/admin/cases/toxic', {
      items: [
        { brainrotId: cheapest, chance: 0 },
        { brainrotId: second, chance: 0.5 },
        { brainrotId: third, chance: 0.000001 },
        ...rest.map((brainrotId) => ({ brainrotId })),
      ],
    });
    const manual = await adminCase('toxic');
    const w = new Map(manual.items.map((i) => [i.brainrotId, i.weight]));
    expect(w.get(cheapest)).toBe(0);
    expect(w.get(second)).toBeCloseTo(0.5, 9);
    expect(w.get(third)).toBeCloseTo(0.000001, 12);
    expect(manual.items.reduce((s, i) => s + i.weight, 0)).toBeCloseTo(1, 9);
    expect((manual.health as { manual?: boolean }).manual).toBe(true);
    // Players get neither the chances nor the items that cannot drop.
    const shown = (await ok(EVE, 'GET', '/api/catalog')).cases.find((c: Kase) => c.id === 'toxic') as Kase;
    expect(shown.items.map((i) => i.brainrotId)).not.toContain(cheapest);
    expect(shown.items.every((i) => Object.keys(i).sort().join() === 'brainrotId,weight')).toBe(true);
    expect((await healCases()).map((h) => h.id)).not.toContain('toxic');
    // Wrong input is refused.
    const bad = (items: unknown) => call(OWNER, 'PATCH', '/api/admin/cases/toxic', { items }).then((r) => r.data.error);
    expect(await bad([{ brainrotId: second, chance: 0.7 }, { brainrotId: third, chance: 0.4 }])).toBe('invalid');
    expect(await bad([{ brainrotId: second, chance: 0.0000001 }, { brainrotId: third }])).toBe('invalid');
    expect(await bad([{ brainrotId: second, chance: 0 }, { brainrotId: third, chance: 0 }])).toBe('invalid');
    // Hand-set chances are the admin's call: a case paying out more than its price still opens, exactly as set.
    await ok(OWNER, 'PATCH', '/api/admin/cases/toxic', { items: [{ brainrotId: cheapest, chance: 0 }, { brainrotId: priciest, chance: 1 }] });
    await ok(OWNER, 'POST', '/api/admin/give', { user: String(EVE), type: 'case', caseId: 'toxic', amount: 1 });
    const open = await ok(EVE, 'POST', '/api/case/open', { caseId: 'toxic', useKey: true });
    expect(open.result.brainrotId).toBe(priciest);
    // Back to automatic chances.
    await ok(OWNER, 'PATCH', '/api/admin/cases/toxic', { items: toxic.items.map(({ brainrotId }) => ({ brainrotId })) });
    expect(((await adminCase('toxic')).health as { manual?: boolean }).manual).toBe(false);
  });

  it('a new case keeps every brainrot the admin picked; the server only adds what the price needs', async () => {
    const png = Buffer.from('89504e470d0a1a0a0000000d4948445200000001000000010806000000', 'hex').toString('base64');
    const { url } = await ok(OWNER, 'POST', '/api/admin/upload', { dataUrl: `data:image/png;base64,${png}` });
    const picked = ['garama-and-madundung', 'bupin-bani', 'meowl'];
    const made = await ok(OWNER, 'POST', '/api/admin/cases', { name: 'Тестовый кейс', price: 100, image: url, items: picked.map((brainrotId) => ({ brainrotId })) });
    const kase = await adminCase(made.id);
    expect(kase.items.map((i) => i.brainrotId)).toEqual(expect.arrayContaining(picked));
    expect(kase.items.length).toBeGreaterThan(picked.length);
    expect(kase.health.ok).toBe(true);
    // The minute tick leaves it as it is now.
    expect((await healCases()).map((h) => h.id)).not.toContain(made.id);
    // «Пересобрать состав» still starts from scratch.
    await ok(OWNER, 'POST', `/api/admin/cases/${made.id}/recompose`);
    expect((await adminCase(made.id)).items.map((i) => i.brainrotId)).not.toContain('meowl');
    await ok(OWNER, 'DELETE', `/api/admin/cases/${made.id}`);
  });

  it('coin prizes drop from cases straight to the balance and nowhere else', async () => {
    const { id } = await ok(OWNER, 'POST', '/api/admin/brainrots', { kind: 'coins', price: 25 });
    const prize = (await ok(EVE, 'GET', '/api/catalog')).brainrots.find((b: { id: string }) => b.id === id);
    expect(prize).toMatchObject({ kind: 'coins', name: '25 B', price: 25, image: '/brainrots/coin-prize.webp', withdrawable: false });
    // Not a shop item, an upgrade target or a deposit; the admin can't hand it out as a brainrot either.
    expect((await call(EVE, 'POST', '/api/shop/buy', { brainrotId: id })).data.error).toBe('unavailable');
    expect((await call(OWNER, 'POST', '/api/admin/give', { user: String(EVE), type: 'brainrot', brainrotId: id, amount: 1 })).status).toBe(404);
    expect((await call(OWNER, 'PATCH', `/api/admin/brainrots/${id}`, { withdrawable: true })).status).toBe(200);
    expect((await ok(EVE, 'GET', '/api/catalog')).brainrots.find((b: { id: string }) => b.id === id).withdrawable).toBe(false);
    // In a case it rolls like any drop, with a chance set by hand here.
    const prices = await pricesOf();
    const toxic = await adminCase('toxic');
    const cheapest = [...toxic.items].sort((x, y) => prices.get(x.brainrotId)! - prices.get(y.brainrotId)!)[0]!.brainrotId;
    await ok(OWNER, 'PATCH', '/api/admin/cases/toxic', { items: [{ brainrotId: cheapest, chance: 0 }, { brainrotId: id, chance: 1 }] });
    await ok(OWNER, 'POST', '/api/admin/give', { user: String(EVE), type: 'case', caseId: 'toxic', amount: 1 });
    const before = await ok(EVE, 'GET', '/api/me');
    const open = await ok(EVE, 'POST', '/api/case/open', { caseId: 'toxic', useKey: true });
    expect(open.result).toEqual({ brainrotId: id, itemId: null, coins: 25, drops: [{ brainrotId: id, itemId: null, coins: 25 }] });
    expect(open.me.user.balance).toBeCloseTo(before.user.balance + 25, 2);
    expect(open.me.inventory).toHaveLength(before.inventory.length);
    // Players see the coin prize in the case like any drop.
    expect((await ok(EVE, 'GET', '/api/catalog')).cases.find((c: Kase) => c.id === 'toxic').items.map((i: { brainrotId: string }) => i.brainrotId)).toEqual([id]);
    // A case with coin prizes is the admin's call: the healer never rewrites it.
    expect((await healCases()).map((h) => h.id)).not.toContain('toxic');
    await ok(OWNER, 'PATCH', '/api/admin/cases/toxic', { items: toxic.items.map(({ brainrotId }) => ({ brainrotId })) });
    await ok(OWNER, 'DELETE', `/api/admin/brainrots/${id}`);
  });

  it('home page themes: create, rename, reorder, move cases, delete', async () => {
    type Section = { id: number; title: string; cases?: number };
    // The owner's own themes come with the catalog snapshot; the test only adds and removes its own.
    const start = await ok(EVE, 'GET', '/api/catalog');
    const titles = start.sections.map((s: Section) => s.title) as string[];
    expect(titles[0]).toBe('Кейсы');
    const known = new Set(start.sections.map((s: Section) => s.id));
    expect(start.cases.filter((c: { kind: string }) => c.kind === 'paid').every((c: { sectionId: number }) => known.has(c.sectionId))).toBe(true);
    const { id } = await ok(OWNER, 'POST', '/api/admin/sections', { title: 'Хэллоуин' });
    await ok(OWNER, 'PATCH', '/api/admin/cases/hell', { sectionId: id });
    await ok(OWNER, 'PATCH', `/api/admin/sections/${id}`, { move: -1 });
    await ok(OWNER, 'PATCH', `/api/admin/sections/${id}`, { title: 'Хэллоуин 🎃' });
    const next = await ok(EVE, 'GET', '/api/catalog');
    expect(next.sections.map((s: Section) => s.title)).toEqual([...titles.slice(0, -1), 'Хэллоуин 🎃', titles[titles.length - 1]]);
    expect(next.cases.find((c: { id: string }) => c.id === 'hell').sectionId).toBe(id);
    expect(((await ok(OWNER, 'GET', '/api/admin/sections')) as Section[]).find((s) => s.id === id)!.cases).toBe(1);
    expect((await call(EVE, 'POST', '/api/admin/sections', { title: 'x' })).status).toBe(403);
    expect((await call(OWNER, 'POST', '/api/admin/sections', { title: '' })).data.error).toBe('invalid');
    await ok(OWNER, 'DELETE', `/api/admin/sections/${id}`);
    const after = await ok(EVE, 'GET', '/api/catalog');
    expect(after.sections.map((s: Section) => s.title)).toEqual(titles);
    expect(after.cases.find((c: { id: string }) => c.id === 'hell').sectionId).toBe(after.sections[0].id);
    expect((await ok(OWNER, 'GET', '/api/admin/logs')).some((l: { action: string }) => l.action === 'section_create')).toBe(true);
  });

  it('admins give free case openings', async () => {
    const r = await ok(OWNER, 'POST', '/api/admin/give', { user: String(EVE), type: 'case', caseId: 'og', amount: 2 });
    expect(r.given).toContain('OG');
    expect((await ok(EVE, 'GET', '/api/me')).caseKeys).toEqual({ og: 2 });
    const before = (await ok(EVE, 'GET', '/api/me')).user.balance;
    const open = await ok(EVE, 'POST', '/api/case/open', { caseId: 'og', useKey: true });
    expect(open.me.user.balance).toBe(before);
    expect(open.me.caseKeys).toEqual({ og: 1 });
    await ok(EVE, 'POST', '/api/case/open', { caseId: 'og', useKey: true });
    expect((await call(EVE, 'POST', '/api/case/open', { caseId: 'og', useKey: true })).data.error).toBe('no_key');
  });
});

describe('brainrot deposits', () => {
  let depositId = 0;

  it('validates the basket and opens one request at a time', async () => {
    expect((await call(FRANK, 'POST', '/api/item-deposits', { items: [], robloxNick: 'Frank_1' })).status).toBe(400);
    // Up to 5 brainrots in one deposit (one trade).
    expect((await call(FRANK, 'POST', '/api/item-deposits', { items: [{ brainrotId: 'meowl', count: 6 }], robloxNick: 'Frank_1' })).status).toBe(400);
    expect((await call(FRANK, 'POST', '/api/item-deposits', { items: [{ brainrotId: 'meowl', count: 3 }, { brainrotId: 'garama-and-madundung', count: 3 }], robloxNick: 'Frank_1' })).data.error).toBe('too_many');
    expect((await call(FRANK, 'POST', '/api/item-deposits', { items: [{ brainrotId: 'meowl' }], robloxNick: 'bad nick!' })).status).toBe(400);
    botCalls.length = 0;
    const d = await ok(FRANK, 'POST', '/api/item-deposits', {
      items: [{ brainrotId: 'garama-and-madundung', count: 2 }, { brainrotId: 'guest-666' }],
      robloxNick: 'Frank_1',
    });
    depositId = d.id;
    expect(d).toMatchObject({ status: 'searching', value: 45 * 2 + 199.99, total: 45 * 2 + 199.99, robloxNick: 'Frank_1' });
    const toAdmins = botCalls.filter((c) => c.method === 'sendMessage' && String(c.params.text).includes(`#${d.id}`));
    expect(toAdmins.map((c) => c.params.chat_id).sort()).toEqual([OWNER, OWNER2].sort());
    const keyboard = JSON.stringify(toAdmins[0]!.params.reply_markup);
    expect(keyboard).toContain(`d:${d.id}:c`);
    expect(keyboard).toContain(`d:${d.id}:n`);
    expect((await call(FRANK, 'POST', '/api/item-deposits', { items: [{ brainrotId: 'meowl' }], robloxNick: 'Frank_1' })).data.error).toBe('already_open');
  });

  it('only admins can press the buttons', async () => {
    expect((await tap(FRANK, `d:${depositId}:c`)).data).toMatchObject({ method: 'answerCallbackQuery', show_alert: true });
    expect((await ok(FRANK, 'GET', '/api/item-deposits/current')).status).toBe('searching');
  });

  it('a new bot nick sent as a reply is saved and shown to the player with a 5 minute timer', async () => {
    expect((await tap(OWNER, `d:${depositId}:n`)).data.method).toBe('answerCallbackQuery');
    const prompt = lastCall('sendMessage', OWNER)!;
    expect(prompt.params.reply_markup).toMatchObject({ force_reply: true });
    const r = await hook({
      update_id: 11,
      message: { message_id: 5, from: { id: OWNER, first_name: 'o' }, chat: { id: OWNER, type: 'private' }, text: 'GG_TradeBot', reply_to_message: { text: prompt.params.text } },
    });
    expect(r.data.text).toContain('GG_TradeBot');
    const cur = await ok(FRANK, 'GET', '/api/item-deposits/current');
    expect(cur).toMatchObject({ status: 'trading', botNick: 'GG_TradeBot' });
    expect(cur.deadline - Date.now()).toBeGreaterThan(4.5 * 60_000);
    expect(String(lastCall('sendMessage', FRANK)!.params.text)).toContain('Твоя очередь');
    expect((await ok(OWNER, 'GET', '/api/admin/settings')).tradeBots).toContain('GG_TradeBot');
    expect(botCalls.some((c) => c.method === 'editMessageText' && String(c.params.text).includes('GG_TradeBot'))).toBe(true);
  });

  it('an overdue trade expires, then an admin can still credit it', async () => {
    await pool.query(`UPDATE item_deposits SET trade_deadline = now() - interval '1 second' WHERE id = $1`, [depositId]);
    expect((await ok(FRANK, 'GET', '/api/item-deposits/current')).status).toBe('expired');
    expect(sent.some((m) => m.chatId === FRANK && m.html.includes('вышло'))).toBe(true);
    const before = (await ok(FRANK, 'GET', '/api/me')).user.balance;
    expect((await tap(OWNER2, `d:${depositId}:c`)).data).toMatchObject({ text: 'Зачислено' });
    const after = await ok(FRANK, 'GET', '/api/me');
    expect(after.user.balance).toBeCloseTo(before + 45 * 2 + 199.99, 2);
    expect((await ok(FRANK, 'GET', '/api/item-deposits/current')).status).toBe('credited');
    expect((await tap(OWNER, `d:${depositId}:r`)).data).toMatchObject({ show_alert: true });
  });

  it('saved bots appear as buttons; reject and cancel close requests', async () => {
    const d = await ok(FRANK, 'POST', '/api/item-deposits', { items: [{ brainrotId: 'meowl' }], robloxNick: 'Frank_1' });
    const msg = botCalls.find((c) => c.method === 'sendMessage' && String(c.params.text).includes(`#${d.id}`) && c.params.chat_id === OWNER)!;
    expect(JSON.stringify(msg.params.reply_markup)).toContain(`d:${d.id}:b:GG_TradeBot`);
    await tap(OWNER, `d:${d.id}:r`);
    expect((await ok(FRANK, 'GET', '/api/item-deposits/current')).status).toBe('rejected');
    const d2 = await ok(FRANK, 'POST', '/api/item-deposits', { items: [{ brainrotId: 'meowl' }], robloxNick: 'Frank_1' });
    await ok(FRANK, 'POST', `/api/item-deposits/${d2.id}/cancel`);
    expect((await ok(FRANK, 'GET', '/api/item-deposits/current')).status).toBe('cancelled');
    const list = await ok(OWNER, 'GET', '/api/admin/item-deposits?status=closed');
    expect(list.map((x: { id: number }) => x.id)).toEqual(expect.arrayContaining([d.id, d2.id, depositId]));
  });
});

describe('withdrawals', () => {
  const GRACE = 1007;
  let w1 = 0;
  const nickOf = { robloxNick: 'Grace_Rbx' };
  const inv = async () => (await ok(GRACE, 'GET', '/api/me')).inventory as { id: number; brainrotId: string; withdrawalId: number | null }[];
  const row = async (id: number) => (await pool.query('SELECT * FROM withdrawals WHERE id = $1', [id])).rows[0];

  beforeAll(async () => {
    await ok(GRACE, 'GET', '/api/me');
    // «Без отыгрыша» (iteration 36, owners only): these tests are about the withdrawal rules themselves.
    await ok(OWNER, 'POST', '/api/admin/give', { user: String(GRACE), type: 'coins', amount: 5000, noWager: true });
  });

  it('needs 100 B or 2 brainrots; junk and brainrots the admin closed never go out', async () => {
    const one = await buy(GRACE, 'garama-and-madundung');
    const err = (await call(GRACE, 'POST', '/api/withdrawals', { itemIds: [one], ...nickOf })).data;
    expect(err.error).toBe('withdraw_min');
    expect(err.message).toContain('2 × Garama and Madundung');
    expect((await call(GRACE, 'POST', '/api/withdrawals', { itemIds: [one], robloxNick: 'bad nick!' })).status).toBe(400);
    // Junk below the admin's threshold.
    await ok(OWNER, 'POST', '/api/admin/settings', { withdrawRules: { minValue: 100, minItems: 2, minItemPrice: 50 } });
    const two = await buy(GRACE, 'garama-and-madundung');
    expect((await call(GRACE, 'POST', '/api/withdrawals', { itemIds: [one, two], ...nickOf })).data.error).toBe('not_withdrawable');
    await ok(OWNER, 'POST', '/api/admin/settings', { withdrawRules: { minValue: 100, minItems: 2, minItemPrice: 45 } });
    // Only brainrots in stock go out; the admin switches one off (it stays in the catalog).
    const moby = await buy(GRACE, 'capitano-moby');
    expect((await call(GRACE, 'POST', '/api/withdrawals', { itemIds: [moby], ...nickOf })).data.error).toBe('not_withdrawable');
    await ok(OWNER, 'PATCH', '/api/admin/brainrots/dragon-cannelloni', { withdrawable: false });
    const dragon = await buy(GRACE, 'dragon-cannelloni');
    expect((await call(GRACE, 'POST', '/api/withdrawals', { itemIds: [dragon], ...nickOf })).data.error).toBe('not_withdrawable');
    expect((await ok(GRACE, 'GET', '/api/catalog')).brainrots.find((b: { id: string }) => b.id === 'dragon-cannelloni')).toMatchObject({ withdrawable: false, status: 'active' });
    await ok(OWNER, 'PATCH', '/api/admin/brainrots/dragon-cannelloni', { withdrawable: true });
    await ok(GRACE, 'POST', '/api/inventory/sell', { itemIds: [moby, dragon] });
  });

  it('locks the brainrots «НА ВЫВОДЕ»: no selling, staking or second request; cancel brings them back', async () => {
    const items = (await inv()).filter((i) => i.brainrotId === 'garama-and-madundung').map((i) => i.id);
    botCalls.length = 0;
    const r = await ok(GRACE, 'POST', '/api/withdrawals', { itemIds: items, ...nickOf });
    w1 = r.result.id;
    expect(r.result).toMatchObject({ status: 'pending', value: 90, canCancel: true, items: [{ brainrotId: 'garama-and-madundung', count: 2 }] });
    expect(r.me.inventory.filter((i: { withdrawalId: number | null }) => i.withdrawalId === w1)).toHaveLength(2);
    // Admins get the request with its buttons in the bot.
    const announce = botCalls.find((c) => c.method === 'sendMessage' && c.params.chat_id === OWNER && String(c.params.text).includes(`Вывод #${w1}`));
    expect(JSON.stringify(announce?.params.reply_markup)).toContain(`w:${w1}:m:0`);
    // Locked everywhere.
    expect((await call(GRACE, 'POST', '/api/inventory/sell', { itemIds: [items[0]] })).data.error).toBe('no_item');
    await buy(GRACE, 'bupin-bani');
    const sold = await ok(GRACE, 'POST', '/api/inventory/sell', { all: true });
    expect(sold.result.sold).toBe(1);
    expect(sold.me.inventory.filter((i: { withdrawalId: number | null }) => i.withdrawalId === w1)).toHaveLength(2);
    expect((await call(GRACE, 'POST', '/api/upgrade', { itemIds: [items[0]], targetId: 'meowl' })).data.error).toBe('on_withdrawal');
    expect((await call(GRACE, 'POST', '/api/dice', { itemId: items[1], color: 'red' })).data.error).toBe('on_withdrawal');
    expect((await call(GRACE, 'POST', '/api/withdrawals', { itemIds: items, ...nickOf })).data.error).toBe('on_withdrawal');
    // The database itself refuses to delete a locked item.
    await expect(pool.query('DELETE FROM inventory WHERE id = $1', [items[0]])).rejects.toThrow(/on withdrawal/);
    const cancelled = await ok(GRACE, 'POST', `/api/withdrawals/${w1}/cancel`);
    expect(cancelled.result.status).toBe('cancelled');
    expect(cancelled.me.inventory.filter((i: { id: number; withdrawalId: number | null }) => items.includes(i.id) && i.withdrawalId === null)).toHaveLength(2);
  });

  it('admin sets a date and a bot in the bot; reminder 5 min before; 5-minute trade window; timeout; «Выведено»', async () => {
    const items = (await inv()).filter((i) => i.brainrotId === 'garama-and-madundung').map((i) => i.id);
    const r = await ok(GRACE, 'POST', '/api/withdrawals', { itemIds: items, ...nickOf });
    const id = r.result.id as number;
    expect((await call(GRACE, 'POST', '/api/withdrawals', { itemIds: [items[0]], ...nickOf })).status).toBe(400);
    // The time buttons are right under the request; one tap schedules it with the default (last used) bot.
    const announced = [...botCalls].reverse().find((c) => c.method === 'sendMessage' && c.params.chat_id === OWNER && String(c.params.text).includes(`Вывод #${id}`));
    expect(JSON.stringify(announced?.params.reply_markup)).toContain(`w:${id}:m:15`);
    const defaultBot = (await ok(OWNER, 'GET', '/api/admin/settings')).tradeBots[0];
    await tap(OWNER, `w:${id}:m:15`);
    expect(await row(id)).toMatchObject({ status: 'scheduled', bot_nick: defaultBot });
    // Another bot: it becomes the default for the next requests.
    await tap(OWNER, `w:${id}:b:GG_TradeBot`);
    const scheduled = await row(id);
    expect(scheduled).toMatchObject({ status: 'scheduled', bot_nick: 'GG_TradeBot' });
    expect((await ok(OWNER, 'GET', '/api/admin/settings')).tradeBots[0]).toBe('GG_TradeBot');
    expect(new Date(scheduled.scheduled_at).getTime() - Date.now()).toBeGreaterThan(14 * 60_000);
    expect(String(lastCall('sendMessage', GRACE)!.params.text)).toContain('назначен');
    // A date typed in reply to the prompt (Moscow time).
    await tap(OWNER, `w:${id}:c`);
    const prompt = lastCall('sendMessage', OWNER)!;
    expect(prompt.params.reply_markup).toMatchObject({ force_reply: true });
    const reply = await hook({ update_id: 21, message: { message_id: 9, from: { id: OWNER, first_name: 'o' }, chat: { id: OWNER, type: 'private' }, text: 'завтра', reply_to_message: { text: prompt.params.text } } });
    expect(reply.data.text).toContain('Не понял дату');
    // 4 minutes ahead: the heads-up goes out at once, to the player and the admins.
    await pool.query(`UPDATE withdrawals SET scheduled_at = now() + interval '4 minutes' WHERE id = $1`, [id]);
    botCalls.length = 0;
    await runTick();
    expect(botCalls.some((c) => c.params.chat_id === GRACE && String(c.params.text).includes('Через 5 минут'))).toBe(true);
    expect(botCalls.some((c) => c.params.chat_id === OWNER && String(c.params.text).includes('Через 5 минут'))).toBe(true);
    await runTick();
    expect(botCalls.filter((c) => c.params.chat_id === GRACE && String(c.params.text).includes('Через 5 минут'))).toHaveLength(1);
    // The time comes: from that second (even before the tick opens the window) the player can't cancel.
    await pool.query(`UPDATE withdrawals SET scheduled_at = now() - interval '1 second' WHERE id = $1`, [id]);
    expect((await call(GRACE, 'POST', `/api/withdrawals/${id}/cancel`)).data.error).toBe('not_cancellable');
    const cur = await ok(GRACE, 'GET', '/api/withdrawals/current');
    expect(cur).toMatchObject({ id, status: 'trading', botNick: 'GG_TradeBot', canCancel: false });
    expect(cur.deadline - Date.now()).toBeGreaterThan(4.5 * 60_000);
    expect((await call(GRACE, 'POST', `/api/withdrawals/${id}/cancel`)).data.error).toBe('not_cancellable');
    // Nobody pressed anything for 5 minutes.
    await pool.query(`UPDATE withdrawals SET trade_deadline = now() - interval '1 second' WHERE id = $1`, [id]);
    sent.length = 0;
    await runTick();
    expect((await ok(GRACE, 'GET', '/api/withdrawals/current')).status).toBe('expired');
    expect(sent.some((m) => m.chatId === GRACE && m.html.includes('вышло'))).toBe(true);
    // A new date after a window: the trade may have happened, so still no cancel for the player.
    await tap(OWNER, `w:${id}:m:60`);
    expect((await ok(GRACE, 'GET', '/api/withdrawals/current')).status).toBe('scheduled');
    expect((await ok(GRACE, 'GET', '/api/withdrawals/current')).canCancel).toBe(false);
    expect((await call(GRACE, 'POST', `/api/withdrawals/${id}/cancel`)).data.error).toBe('not_cancellable');
    // The admin still closes it: «Выведено» takes the brainrots for good.
    const withdrawnBefore = (await ok(GRACE, 'GET', '/api/me')).user.stats.withdrawn;
    expect((await tap(OWNER, `w:${id}:d`)).data).toMatchObject({ text: 'Выведено' });
    expect((await tap(OWNER2, `w:${id}:d`)).data).toMatchObject({ show_alert: true });
    const after = await ok(GRACE, 'GET', '/api/me');
    expect(after.inventory.some((i: { id: number }) => items.includes(i.id))).toBe(false);
    expect(after.user.stats.withdrawn).toBe(withdrawnBefore + 90);
    expect(String(lastCall('sendMessage', GRACE)!.params.text)).toContain('выполнен');
    const history = await ok(GRACE, 'GET', '/api/withdrawals');
    expect(history.map((h: { status: string }) => h.status).slice(0, 2)).toEqual(['done', 'cancelled']);
    expect((await ok(OWNER, 'GET', '/api/admin/withdrawals?status=history')).some((h: { id: number }) => h.id === id)).toBe(true);
  }, 20_000);

  it('rejecting (bot or mini app) returns the brainrots; only admins press the buttons', async () => {
    const a = await buy(GRACE, 'dragon-cannelloni');
    const r = await ok(GRACE, 'POST', '/api/withdrawals', { itemIds: [a], ...nickOf });
    expect((await tap(GRACE, `w:${r.result.id}:d`)).data).toMatchObject({ show_alert: true, text: 'Только для админов' });
    const list = await ok(OWNER, 'GET', '/api/admin/withdrawals?status=open');
    expect(list.find((w: { id: number }) => w.id === r.result.id)).toMatchObject({ robloxNick: 'Grace_Rbx', user: { id: GRACE } });
    await ok(OWNER, 'POST', `/api/admin/withdrawals/${r.result.id}`, { action: 'schedule', at: Date.now() + 3_600_000, botNick: 'GG_TradeBot' });
    expect((await row(r.result.id)).status).toBe('scheduled');
    // «⚡ Сейчас»: the trade window opens at once and the player is told it's their turn.
    botCalls.length = 0;
    await tap(OWNER, `w:${r.result.id}:m:0`);
    expect((await row(r.result.id)).status).toBe('trading');
    expect(botCalls.some((c) => c.params.chat_id === GRACE && String(c.params.text).includes('Твоя очередь'))).toBe(true);
    await ok(OWNER, 'POST', `/api/admin/withdrawals/${r.result.id}`, { action: 'reject', note: 'нет бота' });
    expect((await inv()).find((i) => i.id === a)).toMatchObject({ withdrawalId: null });
    expect(sent.some((m) => m.chatId === GRACE && m.html.includes('нет бота'))).toBe(true);
    expect((await call(OWNER, 'POST', `/api/admin/withdrawals/${r.result.id}`, { action: 'done' })).data.error).toBe('closed');
    await ok(GRACE, 'POST', '/api/inventory/sell', { itemIds: [a] });
  });

  it('brainrots not in stock are exchanged into ones that are, with the change paid to the balance', async () => {
    // Prices pinned here: the admin snapshot carries whatever production has.
    await pool.query(`UPDATE brainrots SET price = 55 WHERE id = 'bupin-bani'`);
    await pool.query(`UPDATE brainrots SET price = 45 WHERE id = 'garama-and-madundung'`);
    const a = await buy(GRACE, 'bupin-bani');
    const b = await buy(GRACE, 'bupin-bani');
    expect((await call(GRACE, 'POST', '/api/withdrawals', { itemIds: [a, b], ...nickOf })).data.error).toBe('not_withdrawable');
    const swap = (take: unknown, itemIds = [a, b]) => call(GRACE, 'POST', '/api/withdrawals/exchange', { itemIds, take }).then((x) => x.data.error);
    expect(await swap([{ brainrotId: 'garama-and-madundung', count: 3 }])).toBe('exchange_too_much');
    expect(await swap([{ brainrotId: 'capitano-moby', count: 1 }])).toBe('not_in_stock');
    expect((await inv()).filter((i) => i.id === a || i.id === b)).toHaveLength(2);
    const before = (await ok(GRACE, 'GET', '/api/me')).user.balance;
    // 2 × 55 = 110 → 2 Garama (90) + 20 B change.
    const r = await ok(GRACE, 'POST', '/api/withdrawals/exchange', { itemIds: [a, b], take: [{ brainrotId: 'garama-and-madundung', count: 2 }] });
    expect(r.result).toMatchObject({ value: 110, total: 90, change: 20 });
    expect(r.me.user.balance).toBeCloseTo(before + 20, 2);
    const now = r.me.inventory as { id: number; brainrotId: string }[];
    expect(now.some((i) => i.id === a || i.id === b)).toBe(false);
    expect(now.filter((i) => r.result.itemIds.includes(i.id)).map((i) => i.brainrotId)).toEqual(['garama-and-madundung', 'garama-and-madundung']);
    expect((await pool.query('SELECT value, change FROM item_exchanges WHERE user_id = $1', [GRACE])).rows).toEqual([{ value: '110.00', change: '20.00' }]);
    // Now it goes out; brainrots on a withdrawal can't be exchanged.
    const w = await ok(GRACE, 'POST', '/api/withdrawals', { itemIds: r.result.itemIds, ...nickOf });
    expect(w.result.status).toBe('pending');
    expect(await swap([{ brainrotId: 'garama-and-madundung', count: 1 }], [r.result.itemIds[0]])).toBe('on_withdrawal');
    await ok(GRACE, 'POST', `/api/withdrawals/${w.result.id}/cancel`);
  });
});

describe('deposit promo bonus', () => {
  it('two deposits made with the same 2-hour code get the bonus once', async () => {
    const HANK = 1008;
    const code = currentPromo().code;
    await ok(HANK, 'GET', '/api/me');
    const a = await ok(HANK, 'POST', '/api/item-deposits', { items: [{ brainrotId: 'garama-and-madundung', count: 2 }], robloxNick: 'Hank_1', promo: code });
    expect(a.bonus).toBeGreaterThan(0);
    // The first one ran out of time; a second one is made with the same code before anything is credited.
    await pool.query(`UPDATE item_deposits SET status = 'expired' WHERE id = $1`, [a.id]);
    const b = await ok(HANK, 'POST', '/api/item-deposits', { items: [{ brainrotId: 'garama-and-madundung', count: 2 }], robloxNick: 'Hank_1', promo: code });
    expect(b.bonus).toBeGreaterThan(0);
    const before = (await ok(HANK, 'GET', '/api/me')).user.balance;
    await ok(OWNER, 'POST', `/api/admin/item-deposits/${a.id}`, { action: 'credit' });
    await ok(OWNER, 'POST', `/api/admin/item-deposits/${b.id}`, { action: 'credit' });
    expect((await ok(HANK, 'GET', '/api/me')).user.balance).toBeCloseTo(before + a.value + a.bonus + b.value, 2);
  });
});

describe('deposit list', () => {
  it('admins add, re-price and remove brainrots that can be deposited', async () => {
    const list = await ok(FRANK, 'GET', '/api/item-deposits/catalog');
    expect(list.find((b: { id: string }) => b.id === 'meowl')).toMatchObject({ name: 'Meowl' });
    await ok(OWNER, 'PATCH', '/api/admin/deposit-items/meowl', { price: 12345.5 });
    expect((await ok(FRANK, 'GET', '/api/item-deposits/catalog')).find((b: { id: string }) => b.id === 'meowl').price).toBe(12345.5);
    const d = await ok(FRANK, 'POST', '/api/item-deposits', { items: [{ brainrotId: 'meowl' }], robloxNick: 'Frank_1' });
    expect(d.value).toBe(12345.5);
    await ok(FRANK, 'POST', `/api/item-deposits/${d.id}/cancel`);
    // Empty price → back to the catalog price.
    await ok(OWNER, 'PATCH', '/api/admin/deposit-items/meowl', { price: null });
    const admin = await ok(OWNER, 'GET', '/api/admin/deposit-items');
    const meowl = admin.find((r: { brainrotId: string }) => r.brainrotId === 'meowl');
    expect(meowl).toMatchObject({ price: null });
    expect(meowl.effective).toBe(meowl.catalogPrice);
    await ok(OWNER, 'DELETE', '/api/admin/deposit-items/meowl');
    expect((await ok(FRANK, 'GET', '/api/item-deposits/catalog')).some((b: { id: string }) => b.id === 'meowl')).toBe(false);
    expect((await call(FRANK, 'POST', '/api/item-deposits', { items: [{ brainrotId: 'meowl' }], robloxNick: 'Frank_1' })).data.error).toBe('unavailable');
    expect((await call(FRANK, 'POST', '/api/admin/deposit-items', { brainrotId: 'meowl' })).status).toBe(403);
    await ok(OWNER, 'POST', '/api/admin/deposit-items', { brainrotId: 'meowl' });
    expect((await call(OWNER, 'POST', '/api/admin/deposit-items', { brainrotId: 'meowl' })).data.error).toBe('exists');
    // «Гирсы»: a second tab of the picker; admins move entries between the tabs.
    expect((await ok(FRANK, 'GET', '/api/item-deposits/catalog')).find((b: { id: string }) => b.id === 'meowl').section).toBe('brainrots');
    await ok(OWNER, 'PATCH', '/api/admin/deposit-items/meowl', { section: 'gears' });
    expect((await ok(FRANK, 'GET', '/api/item-deposits/catalog')).find((b: { id: string }) => b.id === 'meowl').section).toBe('gears');
    expect((await ok(OWNER, 'GET', '/api/admin/deposit-items')).find((r: { brainrotId: string }) => r.brainrotId === 'meowl')).toMatchObject({ section: 'gears', price: null });
    expect((await call(OWNER, 'PATCH', '/api/admin/deposit-items/meowl', { section: 'hats' })).data.error).toBe('invalid');
    // A new entry can go straight into «Гирсы».
    await ok(OWNER, 'DELETE', '/api/admin/deposit-items/skibidi-toilet').catch(() => undefined);
    await ok(OWNER, 'POST', '/api/admin/deposit-items', { brainrotId: 'skibidi-toilet', section: 'gears' });
    expect((await ok(FRANK, 'GET', '/api/item-deposits/catalog')).find((b: { id: string }) => b.id === 'skibidi-toilet').section).toBe('gears');
    await ok(OWNER, 'PATCH', '/api/admin/deposit-items/meowl', { section: 'brainrots' });
    const logs = await ok(OWNER, 'GET', '/api/admin/logs');
    expect(logs.map((l: { action: string }) => l.action)).toEqual(expect.arrayContaining(['deposit_item_add', 'deposit_item_price', 'deposit_item_remove', 'deposit_item_section']));
  });

  it('admins get a «📥 Очередь пополнений» button that re-sends open requests', async () => {
    const d = await ok(FRANK, 'POST', '/api/item-deposits', { items: [{ brainrotId: 'meowl' }], robloxNick: 'Frank_1' });
    const start = await hook({ update_id: 30, message: { message_id: 30, from: { id: OWNER, first_name: 'o' }, chat: { id: OWNER, type: 'private' }, text: '/start' } });
    expect(start.data.method).toBe('sendPhoto');
    expect(JSON.stringify(lastCall('sendMessage', OWNER)!.params.reply_markup)).toContain('Очередь пополнений');
    botCalls.length = 0;
    const r = await hook({ update_id: 31, message: { message_id: 31, from: { id: OWNER, first_name: 'o' }, chat: { id: OWNER, type: 'private' }, text: '📥 Очередь пополнений' } });
    expect(r.data.text).toContain('В очереди');
    expect(botCalls.some((c) => c.method === 'sendMessage' && c.params.chat_id === OWNER && String(c.params.text).includes(`#${d.id}`))).toBe(true);
    // Players pressing the same text get nothing.
    expect((await hook({ update_id: 32, message: { message_id: 32, from: { id: FRANK, first_name: 'f' }, chat: { id: FRANK, type: 'private' }, text: '📥 Очередь пополнений' } })).data).toEqual({});
    await ok(FRANK, 'POST', `/api/item-deposits/${d.id}/cancel`);
  });
});

describe('bot notifications', () => {
  const DAY = new Date('2026-10-18T09:00:00Z'); // 12:00 in Moscow
  const NIGHT = new Date('2026-10-18T23:30:00Z'); // 02:30 in Moscow
  const photosTo = (chatId: number) => botCalls.filter((c) => c.method === 'sendPhoto' && c.params.chat_id === chatId);

  it('switching x2 luck on messages every player once, in batches from the tick', async () => {
    await runTick(); // drain anything earlier tests queued
    blockedChats.add(DAVE);
    botCalls.length = 0;
    await ok(OWNER, 'POST', '/api/admin/settings', { luck: { minutes: 90 } });
    // Extending a running event does not message everyone again.
    await ok(OWNER, 'POST', '/api/admin/settings', { luck: { minutes: 120 } });
    await runNotifications(NIGHT); // broadcasts ignore quiet hours
    const luck = botCalls.filter((c) => c.method === 'sendPhoto' && String(c.params.photo).includes('/promo/luck.jpg'));
    expect(luck.map((c) => c.params.chat_id)).toEqual(expect.arrayContaining([ALICE, BOB, EVE, FRANK, OWNER]));
    expect(new Set(luck.map((c) => c.params.chat_id)).size).toBe(luck.length);
    expect(String(luck[0]!.params.caption)).toContain('x2 УДАЧА');
    expect(String(luck[0]!.params.caption)).toContain('1 ч 30 мин');
    expect((await ok(OWNER, 'GET', '/api/admin/broadcasts')).list[0]).toMatchObject({ kind: 'luck', done: true, sent: luck.length - 1 });
    // Finished: the next tick sends nothing more.
    const before = botCalls.length;
    await runNotifications(NIGHT);
    expect(botCalls.length).toBe(before);
    // DAVE blocked the bot: marked and skipped from now on.
    expect((await pool.query('SELECT bot_blocked_at FROM users WHERE id = $1', [DAVE])).rows[0].bot_blocked_at).not.toBeNull();
    await ok(OWNER, 'POST', '/api/admin/settings', { luck: { minutes: 0 } });
  });

  it('a luck broadcast stops once the event is switched off', async () => {
    await ok(OWNER, 'POST', '/api/admin/settings', { luck: { minutes: 30 } });
    await ok(OWNER, 'POST', '/api/admin/settings', { luck: { minutes: 0 } });
    botCalls.length = 0;
    await runNotifications(NIGHT);
    expect(botCalls.filter((c) => String(c.params.photo).includes('/promo/luck.jpg'))).toHaveLength(0);
    expect((await ok(OWNER, 'GET', '/api/admin/broadcasts')).list[0]).toMatchObject({ kind: 'luck', done: true, sent: 0 });
  });

  it('owners send an announcement (photo, text, button) to every player in batches; a test goes to themselves only', async () => {
    await runTick();
    const png = Buffer.from('89504e470d0a1a0a0000000d4948445200000001000000010806000000', 'hex').toString('base64');
    const photo = (await ok(OWNER, 'POST', '/api/admin/upload', { dataUrl: `data:image/png;base64,${png}` })).url as string;
    const body = { text: '**Новый ивент!** Заходи <скорее> & __крути__', photo, button: { text: 'Открыть FUSE', open: 'fuse' } };
    expect((await call(ALICE, 'POST', '/api/admin/announce', body)).status).toBe(403);
    botCalls.length = 0;
    expect((await ok(OWNER, 'POST', '/api/admin/announce', { ...body, test: true })).test).toBe('sent');
    expect(botCalls.map((c) => c.params.chat_id)).toEqual([OWNER]);
    expect(botCalls[0]!.params.caption).toBe('<b>Новый ивент!</b> Заходи &lt;скорее&gt; &amp; <i>крути</i>');
    expect(JSON.stringify(botCalls[0]!.params.reply_markup)).toContain('?open=fuse');
    botCalls.length = 0;
    const queued = await ok(OWNER, 'POST', '/api/admin/announce', body);
    expect(queued.list[0]).toMatchObject({ kind: 'announce', done: false, sent: 0, text: 'Новый ивент! Заходи <скорее> & крути' });
    // A second one waits for the first instead of replacing it.
    await ok(OWNER, 'POST', '/api/admin/announce', { text: 'Второе объявление' });
    await runNotifications(NIGHT);
    const photos = botCalls.filter((c) => c.method === 'sendPhoto' && String(c.params.photo).endsWith(photo));
    expect(photos.map((c) => c.params.chat_id)).toEqual(expect.arrayContaining([ALICE, BOB, EVE, OWNER]));
    expect(photos.map((c) => c.params.chat_id)).not.toContain(DAVE); // blocked the bot
    const list = (await ok(OWNER, 'GET', '/api/admin/broadcasts')).list;
    expect(list[1]).toMatchObject({ kind: 'announce', done: true, sent: photos.length });
    expect(list[0]).toMatchObject({ kind: 'announce' });
    // Too long for a caption; an unknown button target.
    expect((await call(OWNER, 'POST', '/api/admin/announce', { text: 'я'.repeat(1100), photo })).data.error).toBe('too_long');
    expect((await call(OWNER, 'POST', '/api/admin/announce', { text: 'hi', button: { text: 'x', open: 'admin' } })).data.error).toBe('invalid');
    // Stopping one that is still going.
    const third = await ok(OWNER, 'POST', '/api/admin/announce', { text: 'Третье' });
    const stopped = await ok(OWNER, 'POST', `/api/admin/broadcasts/${third.list[0].id}/stop`);
    expect(stopped.list[0]).toMatchObject({ done: true });
    await runTick();
  });

  it('free case ready: one reminder per reset, none at night, none while blocked', async () => {
    await pool.query(`UPDATE users SET last_seen_at = now() - interval '1 hour', free_notified_at = now(), comeback_sent_at = NULL`);
    await pool.query(`UPDATE users SET free_case_at = now() - interval '13 hours', free_notified_at = now() - interval '14 hours' WHERE id IN ($1, $2)`, [CAROL, DAVE]);
    botCalls.length = 0;
    expect((await runNotifications(NIGHT)).free).toBe(0);
    const r = await runNotifications(DAY);
    expect(r.free).toBe(1); // DAVE blocked the bot
    const msg = photosTo(CAROL)[0]!;
    expect(String(msg.params.photo)).toMatch(/\/promo\/free-case\.jpg\?v=\d+$/);
    expect(String(msg.params.caption)).toContain('бесплатный кейс готов');
    expect(JSON.stringify(msg.params.reply_markup)).toContain('?open=case/free');
    await runNotifications(DAY);
    expect(photosTo(CAROL)).toHaveLength(1);
  });

  it('three days away → one teasing message, until the player comes back', async () => {
    await pool.query(`UPDATE users SET last_seen_at = now() - interval '4 days' WHERE id = $1`, [BOB]);
    botCalls.length = 0;
    expect((await runNotifications(DAY)).comeback).toBe(1);
    expect(String(photosTo(BOB)[0]!.params.caption)).toMatch(/пропал|ждём|обиделись/);
    await runNotifications(DAY);
    expect(photosTo(BOB)).toHaveLength(1);
  });

  it('blocking and unblocking the bot is tracked from my_chat_member', async () => {
    const update = (status: string) => ({ update_id: 40, my_chat_member: { chat: { id: CAROL, type: 'private' }, from: { id: CAROL, first_name: 'c' }, new_chat_member: { status } } });
    await hook(update('kicked'));
    expect((await pool.query('SELECT bot_blocked_at FROM users WHERE id = $1', [CAROL])).rows[0].bot_blocked_at).not.toBeNull();
    await hook(update('member'));
    expect((await pool.query('SELECT bot_blocked_at FROM users WHERE id = $1', [CAROL])).rows[0].bot_blocked_at).toBeNull();
    blockedChats.delete(DAVE);
    await hook({ update_id: 41, message: { message_id: 41, from: { id: DAVE, first_name: 'd' }, chat: { id: DAVE, type: 'private' }, text: '/start' } });
    expect((await pool.query('SELECT bot_blocked_at FROM users WHERE id = $1', [DAVE])).rows[0].bot_blocked_at).toBeNull();
  });
});

describe('battles', () => {
  it('creator pays, joiner pays, the pricier drop takes both', async () => {
    await ok(OWNER, 'POST', '/api/admin/give', { user: String(EVE), type: 'coins', amount: 1000 });
    await ok(OWNER, 'POST', '/api/admin/give', { user: String(FRANK), type: 'coins', amount: 1000 });
    expect((await call(EVE, 'POST', '/api/battles', { caseId: 'free' })).data.error).toBe('free_case');
    const eve0 = (await ok(EVE, 'GET', '/api/me')).user.balance;
    const created = await ok(EVE, 'POST', '/api/battles', { caseId: 'lavaka' });
    expect(created.me.user.balance).toBeCloseTo(eve0 - 149, 2);
    expect(created.result).toMatchObject({ status: 'waiting', you: 'creator', opponent: null });
    const list = await ok(FRANK, 'GET', '/api/battles');
    expect(list.waiting.map((b: { id: number }) => b.id)).toContain(created.result.id);
    expect((await call(EVE, 'POST', `/api/battles/${created.result.id}/join`)).data.error).toBe('own_battle');

    fixRandom(0.0, 0.999999);
    const joined = await ok(FRANK, 'POST', `/api/battles/${created.result.id}/join`);
    vi.restoreAllMocks();
    const b = joined.result;
    expect(b).toMatchObject({ status: 'finished', you: 'opponent', winner: 'opponent' });
    expect(b.rounds).toHaveLength(1);
    const won = joined.me.inventory.map((i: { brainrotId: string }) => i.brainrotId);
    expect(won).toEqual(expect.arrayContaining([b.rounds[0].creator, b.rounds[0].opponent]));
    expect((await call(FRANK, 'POST', `/api/battles/${b.id}/join`)).data.error).toBe('taken');
    expect(String(lastCall('sendMessage', EVE)!.params.text)).toContain('зашёл в твой батл');
  });

  it('a case re-priced since the battle was made refunds the creator instead of rolling', async () => {
    const eve0 = (await ok(EVE, 'GET', '/api/me')).user.balance;
    const created = await ok(EVE, 'POST', '/api/battles', { caseId: 'lavaka' });
    await ok(OWNER, 'PATCH', '/api/admin/cases/lavaka', { price: 199 });
    const frank0 = (await ok(FRANK, 'GET', '/api/me')).user.balance;
    expect((await call(FRANK, 'POST', `/api/battles/${created.result.id}/join`)).data.error).toBe('case_changed');
    expect((await ok(EVE, 'GET', '/api/me')).user.balance).toBeCloseTo(eve0, 2);
    expect((await ok(FRANK, 'GET', '/api/me')).user.balance).toBeCloseTo(frank0, 2);
    expect((await ok(EVE, 'GET', `/api/battles/${created.result.id}`)).status).toBe('cancelled');
    await ok(OWNER, 'PATCH', '/api/admin/cases/lavaka', { price: 149 });
  });

  it('a tie is a draw: no reroll, each keeps their own drop (a battle pays what the case does)', async () => {
    const created = await ok(EVE, 'POST', '/api/battles', { caseId: 'lavaka' });
    const eveItems = (await ok(EVE, 'GET', '/api/me')).inventory.length;
    const frankItems = (await ok(FRANK, 'GET', '/api/me')).inventory.length;
    fixRandom(0.0, 0.0, 0.0, 0.999999);
    const joined = await ok(FRANK, 'POST', `/api/battles/${created.result.id}/join`);
    vi.restoreAllMocks();
    expect(joined.result.rounds).toHaveLength(1);
    expect(joined.result.winner).toBeNull();
    expect(joined.result.rounds[0].creator).toBe(joined.result.rounds[0].opponent);
    expect(joined.me.inventory).toHaveLength(frankItems + 1);
    expect((await ok(EVE, 'GET', '/api/me')).inventory).toHaveLength(eveItems + 1);
  });

  it('cancel refunds; nobody joining in 5 minutes opens the case for the creator', async () => {
    const before = (await ok(EVE, 'GET', '/api/me')).user.balance;
    const a = await ok(EVE, 'POST', '/api/battles', { caseId: 'lavaka' });
    await ok(EVE, 'POST', `/api/battles/${a.result.id}/cancel`);
    expect((await ok(EVE, 'GET', '/api/me')).user.balance).toBeCloseTo(before, 2);
    const s = await ok(EVE, 'POST', '/api/battles', { caseId: 'lavaka' });
    const items = s.me.inventory.length;
    await pool.query(`UPDATE battles SET created_at = now() - interval '6 minutes' WHERE id = $1`, [s.result.id]);
    const { runTick } = await import('./tick');
    expect((await runTick()).soloBattles).toBe(1);
    const solo = await ok(EVE, 'GET', `/api/battles/${s.result.id}`);
    expect(solo).toMatchObject({ status: 'solo', winner: 'creator' });
    expect((await ok(EVE, 'GET', '/api/me')).inventory).toHaveLength(items + 1);
  });
});

describe('referrals and bonuses', () => {
  const NEW1 = 2001;
  const NEW2 = 2002;
  const NEW3 = 2003;
  const NEW4 = 2004;
  const start = (id: number, text: string) => hook({ update_id: 50 + id, message: { message_id: id, from: { id, first_name: `n${id}` }, chat: { id, type: 'private' }, text } });
  const refBalance = async (id: number) => Number((await pool.query('SELECT ref_balance FROM users WHERE id = $1', [id])).rows[0].ref_balance);
  const addDrop = (user: number, game: string, stake: number, payout: number, at = Date.now()) =>
    pool.query(`INSERT INTO drops (user_id, game, result, stake_value, payout_value, created_at) VALUES ($1, $2, 'win', $3, $4, $5)`, [user, game, stake, payout, new Date(at)]);
  let firstCode = '';

  it('a friend joining by link becomes a referral; both get a referral case right away', async () => {
    const mine = await ok(FRANK, 'GET', '/api/referrals');
    firstCode = mine.code;
    expect(mine.link).toBe(`https://t.me/braincrashbot?start=r-${mine.code}`);
    expect(mine).toMatchObject({ invited: 0, active: 0, percent: 5, level: 1 });
    botCalls.length = 0;
    const r = await start(NEW1, `/start r-${mine.code}`);
    expect(r.data.caption).toContain('реферальный кейс');
    expect(JSON.stringify(r.data.reply_markup)).toContain('?open=bonuses');
    expect(botCalls.some((c) => c.method === 'sendMessage' && c.params.chat_id === FRANK && String(c.params.text).includes('пришёл'))).toBe(true);
    // The same link again: counted once, nothing new.
    await start(NEW1, `/start r-${mine.code}`);
    const after = await ok(FRANK, 'GET', '/api/referrals');
    expect(after).toMatchObject({ invited: 1, active: 0, clicks: 1 });
    expect((await ok(NEW1, 'GET', '/api/me')).caseKeys.referral).toBe(1);
    expect((await ok(FRANK, 'GET', '/api/me')).caseKeys.referral).toBe(1);
    // The referral case opens only with such a key.
    expect((await call(NEW2, 'POST', '/api/case/open', { caseId: 'referral' })).data.error).toBe('need_invite');
    const open = await ok(NEW1, 'POST', '/api/case/open', { caseId: 'referral', useKey: true });
    expect(open.me.caseKeys.referral).toBeUndefined();
  });

  it('a partner code works once, never for yourself or your own referral; codes can be personalised once a day', async () => {
    const mine = await ok(FRANK, 'GET', '/api/referrals');
    expect((await call(FRANK, 'POST', '/api/promo', { code: mine.code })).data.error).toBe('own_code');
    expect((await ok(NEW2, 'POST', '/api/promo', { code: mine.code.toLowerCase() })).result).toMatchObject({ type: 'referral' });
    expect((await call(NEW2, 'POST', '/api/promo', { code: mine.code })).data.error).toBe('already_referred');
    // No loops: Frank can't become the referral of the friend he brought.
    const friendCode = (await ok(NEW1, 'GET', '/api/referrals')).code;
    expect((await call(FRANK, 'POST', '/api/promo', { code: friendCode })).data.error).toBe('ref_cycle');
    expect((await ok(FRANK, 'POST', '/api/referrals/code', { code: 'FrankBest' })).link).toContain('start=r-FrankBest');
    expect((await call(EVE, 'POST', '/api/referrals/code', { code: 'frankbest' })).data.error).toBe('taken');
    expect((await call(FRANK, 'POST', '/api/referrals/code', { code: 'FrankBest2' })).data.error).toBe('cooldown');
    // The old code stays Frank's: nobody can take it, and links shared before still bring friends to him.
    expect((await call(EVE, 'POST', '/api/referrals/code', { code: firstCode })).data.error).toBe('taken');
    await start(NEW4, `/start r-${firstCode}`);
    expect((await ok(FRANK, 'GET', '/api/referrals')).invited).toBe(3);
    const friends = await ok(FRANK, 'GET', '/api/referrals/friends');
    expect(friends).toHaveLength(3);
    expect(Object.keys(friends[0]).sort()).toEqual(['bets', 'brought', 'deposits', 'name', 'net', 'nextMilestone', 'photo', 'played', 'since']); // no IDs or balances
  });

  it('one referral per account: another link later, a bot restart, two links at once or your own link give nobody anything', async () => {
    const NEW5 = 2005;
    const NEW6 = 2006;
    const frank = (await ok(FRANK, 'GET', '/api/referrals')).code;
    const eve = (await ok(EVE, 'GET', '/api/referrals')).code;
    const keys = async (id: number) => (await ok(id, 'GET', '/api/me')).caseKeys.referral ?? 0;
    const stats = async (id: number) => {
      const r = await ok(id, 'GET', '/api/referrals');
      return { invited: r.invited, clicks: r.clicks, keys: await keys(id) };
    };
    // Bound to Frank by his link.
    await start(NEW5, `/start r-${frank}`);
    const mine = await keys(NEW5);
    const eveBefore = await stats(EVE);
    // Eve's link afterwards counts for nobody: no case for either side, no invite, not even a click.
    await start(NEW5, `/start r-${eve}`);
    expect(await keys(NEW5)).toBe(mine);
    expect(await stats(EVE)).toEqual(eveBefore);
    expect((await call(NEW5, 'POST', '/api/promo', { code: eve })).data.error).toBe('already_referred');
    expect(await stats(EVE)).toEqual(eveBefore);
    // Restarting the bot with Frank's link again: nothing new.
    const frankBefore = await stats(FRANK);
    await start(NEW5, `/start r-${frank}`);
    expect(await stats(FRANK)).toEqual(frankBefore);
    expect(await keys(NEW5)).toBe(mine);
    // Two different links one right after the other: bound to exactly one, one case on each side. (Truly parallel
    // requests are serialised by the row locks in bindReferral; the in-memory test database can't run two sessions.)
    const fk = await keys(FRANK);
    const ek = await keys(EVE);
    await start(NEW6, `/start r-${frank}`);
    await start(NEW6, `/start r-${eve}`);
    const ref = String((await pool.query('SELECT referred_by FROM users WHERE id = $1', [NEW6])).rows[0].referred_by);
    expect([String(FRANK), String(EVE)]).toContain(ref);
    expect(await keys(NEW6)).toBe(1);
    // At most one more on the referrers' side: the referral case comes once per account (iteration 38).
    expect((await keys(FRANK)) - fk + ((await keys(EVE)) - ek)).toBeLessThanOrEqual(1);
    // Your own link: nothing.
    const own = await stats(FRANK);
    await start(FRANK, `/start r-${frank}`);
    expect(await stats(FRANK)).toEqual(own);
  }, 20_000);

  it('referrers earn their level % of every friend deposit at once (stars or brainrots, the promo bonus aside), never from bets', async () => {
    const before = await refBalance(FRANK);
    // Bets earn the referrer nothing any more, however much the friend loses.
    await addDrop(NEW1, 'case', 1000, 0);
    await addDrop(NEW1, 'battle', 500, 0);
    expect(await refBalance(FRANK)).toBeCloseTo(before, 2);
    // A brainrot deposit: 5 % (level 1) of the brainrots' value, straight onto the referral balance.
    const d = await ok(NEW1, 'POST', '/api/item-deposits', { items: [{ brainrotId: 'garama-and-madundung' }], robloxNick: 'New_One' });
    botCalls.length = 0;
    await ok(OWNER, 'POST', `/api/admin/item-deposits/${d.id}`, { action: 'credit' });
    const value = Number((await pool.query('SELECT value FROM item_deposits WHERE id = $1', [d.id])).rows[0].value);
    const share1 = Math.floor(value * 5) / 100;
    expect(await refBalance(FRANK)).toBeCloseTo(before + share1, 2);
    const told = botCalls.find((c) => c.method === 'sendMessage' && c.params.chat_id === FRANK);
    expect(String(told?.params.text)).toContain('первое пополнение');
    expect(String(told?.params.text)).toContain('(5%)');
    // A stars deposit: 5 % of the coins bought.
    const inv = await ok(NEW1, 'POST', '/api/stars/invoice', { stars: 100 });
    await hook({
      update_id: 77,
      message: {
        message_id: 77,
        from: { id: NEW1, first_name: 'n' },
        chat: { id: NEW1, type: 'private' },
        successful_payment: { currency: 'XTR', total_amount: 100, invoice_payload: `stars:${inv.orderId}`, telegram_payment_charge_id: 'ref-share-1', provider_payment_charge_id: '' },
      },
    });
    const share2 = Math.floor(inv.coins * 5) / 100;
    expect(await refBalance(FRANK)).toBeCloseTo(before + share1 + share2, 2);
    const rows = await pool.query(`SELECT referral_id, amount FROM ref_payouts WHERE referrer_id = $1 AND kind = 'deposit_bonus' ORDER BY id`, [FRANK]);
    expect(rows.rows.map((r) => [Number(r.referral_id), Number(r.amount)])).toEqual([
      [NEW1, share1],
      [NEW1, share2],
    ]);
    const summary = await ok(FRANK, 'GET', '/api/referrals');
    expect(summary.earned).toBeCloseTo(share1 + share2, 2);
    expect(summary).not.toHaveProperty('pending');
    // Moved to the main balance in one tap.
    const bal = (await ok(FRANK, 'GET', '/api/me')).user.balance;
    const moved = await ok(FRANK, 'POST', '/api/referrals/transfer');
    expect(moved.me.user.balance).toBeCloseTo(bal + before + share1 + share2, 2);
    expect((await call(FRANK, 'POST', '/api/referrals/transfer')).data.error).toBe('empty');
  });

  it('the first real deposit of a friend makes them active for the level; every deposit pays the share', async () => {
    const d = await ok(NEW2, 'POST', '/api/item-deposits', { items: [{ brainrotId: 'garama-and-madundung' }], robloxNick: 'New_Two' });
    const before = await refBalance(FRANK);
    botCalls.length = 0;
    await ok(OWNER, 'POST', `/api/admin/item-deposits/${d.id}`, { action: 'credit' });
    expect(await refBalance(FRANK)).toBeGreaterThan(before);
    expect(botCalls.some((c) => c.method === 'sendMessage' && c.params.chat_id === FRANK && String(c.params.text).includes('активный'))).toBe(true);
    expect((await ok(FRANK, 'GET', '/api/referrals')).active).toBe(2);
    botCalls.length = 0;
    const d2 = await ok(NEW2, 'POST', '/api/item-deposits', { items: [{ brainrotId: 'garama-and-madundung' }], robloxNick: 'New_Two' });
    await ok(OWNER, 'POST', `/api/admin/item-deposits/${d2.id}`, { action: 'credit' });
    const told = botCalls.filter((c) => c.params.chat_id === FRANK).map((c) => String(c.params.text));
    expect(told.some((t) => t.includes('активный'))).toBe(false); // «active» once
    expect(told.some((t) => t.includes('Друг пополнил баланс'))).toBe(true);
    expect((await pool.query(`SELECT count(*)::int AS n FROM ref_payouts WHERE referrer_id = $1 AND referral_id = $2 AND kind = 'deposit_bonus'`, [FRANK, NEW2])).rows[0].n).toBe(2);
  });

  it('players create their own promo codes (after a real deposit, paid up front, refunded on delete); activators become referrals', { timeout: 30_000 }, async () => {
    await ok(OWNER, 'POST', '/api/admin/give', { user: String(EVE), type: 'coins', amount: 1000 });
    expect((await call(EVE, 'POST', '/api/referrals/promos', { type: 'coins', amount: 10, uses: 3 })).data.error).toBe('need_deposit');
    const dep = await ok(EVE, 'POST', '/api/item-deposits', { items: [{ brainrotId: 'garama-and-madundung' }], robloxNick: 'Eve_Main' });
    await ok(OWNER, 'POST', `/api/admin/item-deposits/${dep.id}`, { action: 'credit' });
    const bal = (await ok(EVE, 'GET', '/api/me')).user.balance;
    expect((await call(EVE, 'POST', '/api/referrals/promos', { type: 'coins', amount: 10.5, uses: 3 })).data.error).toBe('invalid');
    const coins = await ok(EVE, 'POST', '/api/referrals/promos', { type: 'coins', amount: 10, uses: 3, code: 'EVE_GIFT' });
    expect(coins.me.user.balance).toBeCloseTo(bal - 30, 2);
    expect((await call(EVE, 'POST', '/api/promo', { code: 'EVE_GIFT' })).data.error).toBe('own_promo');
    expect((await call(EVE, 'POST', '/api/referrals/promos', { type: 'coins', amount: 10, uses: 1, code: 'FrankBest' })).data.error).toBe('taken');
    expect((await call(EVE, 'POST', '/api/referrals/promos', { type: 'coins', amount: 10, uses: 1, code: firstCode })).data.error).toBe('taken');
    const got = await ok(NEW3, 'POST', '/api/promo', { code: 'eve_gift' });
    expect(got.result).toMatchObject({ type: 'coins', amount: 10 });
    expect((await ok(EVE, 'GET', '/api/referrals')).invited).toBe(1);
    const kase = await ok(EVE, 'POST', '/api/referrals/promos', { type: 'case', caseId: 'lavaka', uses: 1 });
    expect(kase.result.cost).toBe(149);
    expect((await ok(NEW3, 'POST', '/api/promo', { code: kase.result.code })).result).toMatchObject({ type: 'case', caseId: 'lavaka' });
    expect((await ok(NEW3, 'GET', '/api/me')).caseKeys.lavaka).toBe(1);
    const list = await ok(EVE, 'GET', '/api/referrals/promos');
    const coinPromo = list.find((p: { code: string }) => p.code === 'EVE_GIFT');
    expect(coinPromo).toMatchObject({ uses: 1, maxUses: 3 });
    const del = await ok(EVE, 'DELETE', `/api/referrals/promos/${coinPromo.id}`);
    expect(del.result.refund).toBe(20);
    expect((await call(FRANK, 'DELETE', `/api/referrals/promos/${kase.result.id}`)).status).toBe(404);
  });

  it('the nick case wants «@BrainrotCrash» at the end of the current Telegram name, every 12 hours', async () => {
    chatNames.set(NEW3, 'Ivan');
    expect((await call(NEW3, 'POST', '/api/case/open', { caseId: 'nick' })).data).toMatchObject({ error: 'need_nick', tag: '@BrainrotCrash' });
    chatNames.set(NEW3, 'Ivan BrainrotCrash');
    expect((await call(NEW3, 'POST', '/api/case/open', { caseId: 'nick' })).data.error).toBe('need_nick');
    chatNames.set(NEW3, 'Ivan @brainrotcrash'); // any case
    await ok(NEW3, 'POST', '/api/case/open', { caseId: 'nick' });
    expect((await call(NEW3, 'POST', '/api/case/open', { caseId: 'nick' })).data.error).toBe('cooldown');
    chatNames.set(NEW3, 'Ivan');
    expect((await call(NEW3, 'POST', '/api/case/open', { caseId: 'nick' })).data.error).toBe('cooldown');
    const b = await ok(NEW3, 'GET', '/api/bonuses');
    expect(b.nick.readyAt).toBeGreaterThan(Date.now() + 11 * 3600_000);
  });

  it('weekly cashback: 3% of the net loss on cases and battles, collected on Fridays only', async () => {
    const CASHY = 1090;
    await ok(CASHY, 'GET', '/api/me');
    const friday = cashbackDayStart(Date.now()) + 12 * 3600_000;
    const week = weekIndex(friday);
    const at = (w: number) => weekStart(w) + 3600_000;
    await addDrop(CASHY, 'case', 300, 100, at(week - 1));
    await addDrop(CASHY, 'battle', 100, 0, at(week - 1));
    await addDrop(CASHY, 'upgrade', 1000, 0, at(week - 1)); // no house edge: no cashback
    await addDrop(CASHY, 'crash', 1000, 0, at(week - 1));
    await addDrop(CASHY, 'case', 200, 0, at(week - 3)); // an older week nobody collected
    await addDrop(CASHY, 'case', 5000, 0, at(week - 6)); // too old
    await addDrop(CASHY, 'case', 100, 0, at(week)); // this week: still growing
    const clock = vi.spyOn(Date, 'now');
    try {
      clock.mockReturnValue(friday - 86_400_000);
      const thursday = await ok(CASHY, 'GET', '/api/bonuses');
      expect(thursday.cashback).toMatchObject({ percent: 3, available: 15, accruing: 3, today: false });
      expect(isCashbackDay(friday - 86_400_000)).toBe(false);
      expect((await call(CASHY, 'POST', '/api/bonuses/cashback')).data.error).toBe('not_friday');

      clock.mockReturnValue(friday);
      expect((await ok(CASHY, 'GET', '/api/bonuses')).cashback).toMatchObject({ available: 15, today: true });
      const before = (await ok(CASHY, 'GET', '/api/me')).user.balance;
      const r = await ok(CASHY, 'POST', '/api/bonuses/cashback');
      expect(r.result.amount).toBe(15);
      expect(r.me.user.balance).toBeCloseTo(before + 15, 2);
      expect((await call(CASHY, 'POST', '/api/bonuses/cashback')).data.error).toBe('empty');
      expect((await ok(CASHY, 'GET', '/api/bonuses')).cashback).toMatchObject({ available: 0, accruing: 3 });
    } finally {
      clock.mockRestore();
    }
  });

  it('losing an upgrade with a stake of 300+ gives a consolation spin worth 1–30 coins, once a day', { timeout: 30_000 }, async () => {
    await ok(OWNER, 'POST', '/api/admin/give', { user: String(NEW3), type: 'coins', amount: 2000 });
    const item = await buy(NEW3, 'cloverat-clapat');
    fixRandom(0.999999);
    const up = await ok(NEW3, 'POST', '/api/upgrade', { itemId: item, targetId: 'meowl' });
    vi.restoreAllMocks();
    expect(up.result.win).toBe(false);
    expect(up.result.consolationId).toBeGreaterThan(0);
    expect((await ok(NEW3, 'GET', '/api/bonuses')).consolations).toHaveLength(1);
    const before = (await ok(NEW3, 'GET', '/api/me')).user.balance;
    const spin = await ok(NEW3, 'POST', `/api/consolations/${up.result.consolationId}/open`);
    expect(spin.result.coins).toBeGreaterThanOrEqual(1);
    expect(spin.result.coins).toBeLessThanOrEqual(30);
    expect(spin.me.user.balance).toBeCloseTo(before + spin.result.coins, 2);
    expect((await call(NEW3, 'POST', `/api/consolations/${up.result.consolationId}/open`)).status).toBe(404);
    // The next big loss the same day: no second spin.
    const again = await buy(NEW3, 'cloverat-clapat');
    fixRandom(0.999999);
    const second = await ok(NEW3, 'POST', '/api/upgrade', { itemId: again, targetId: 'meowl' });
    vi.restoreAllMocks();
    expect(second.result.consolationId).toBeNull();
    // Small stakes don't qualify either.
    await pool.query('DELETE FROM consolations WHERE user_id = $1', [NEW3]);
    const cheap = await buy(NEW3, 'garama-and-madundung');
    fixRandom(0.999999);
    const small = await ok(NEW3, 'POST', '/api/upgrade', { itemId: cheap, targetId: 'meowl' });
    vi.restoreAllMocks();
    expect(small.result.consolationId).toBeNull();
  });
});

// Runs last: the full wipe clears every player.
describe('danger zone', () => {
  const PASSWORD = 'test-danger-password';
  beforeAll(() => {
    process.env.WIPE_PASSWORD = PASSWORD;
  });
  afterAll(() => {
    delete process.env.WIPE_PASSWORD;
  });

  it('owners only, with the password; five wrong ones lock it for 15 minutes', async () => {
    expect((await call(ALICE, 'POST', '/api/admin/danger/reset', { user: String(BOB), password: PASSWORD })).status).toBe(403);
    expect((await call(OWNER, 'POST', '/api/admin/danger/reset', { user: String(BOB) })).data.error).toBe('wrong_password');
    for (let i = 0; i < 4; i++) expect((await call(OWNER2, 'POST', '/api/admin/danger/reset', { user: String(BOB), password: 'nope' })).data.error).toBe('wrong_password');
    // The fifth wrong try is counted; after it even the right password waits.
    expect((await call(OWNER2, 'POST', '/api/admin/danger/reset', { user: String(BOB), password: 'nope' })).data.error).toBe('wrong_password');
    expect((await call(OWNER2, 'POST', '/api/admin/danger/reset', { user: String(BOB), password: PASSWORD })).data.error).toBe('danger_locked');
    expect((await call(OWNER, 'POST', '/api/admin/danger/reset', { user: String(OWNER2), password: PASSWORD })).status).toBe(403);
    expect((await ok(OWNER, 'GET', '/api/admin/danger')).enabled).toBe(true);
  });

  it('resets one player: coins, items, history and keys go, the account stays', { timeout: 30_000 }, async () => {
    for (const id of [CAROL, BOB, ALICE]) await ok(id, 'GET', '/api/me');
    await ok(OWNER, 'POST', '/api/admin/give', { user: String(CAROL), type: 'coins', amount: 500 });
    await buy(CAROL, 'garama-and-madundung');
    await ok(CAROL, 'POST', '/api/case/open', { caseId: 'noobini' }).catch(() => undefined);
    await ok(OWNER, 'POST', '/api/admin/give', { user: String(CAROL), type: 'case', caseId: 'noobini', amount: 2 });
    const bobBefore = await ok(BOB, 'GET', '/api/me');
    const r = await ok(OWNER, 'POST', '/api/admin/danger/reset', { user: '@carol', password: PASSWORD });
    expect(r.user.id).toBe(CAROL);
    expect(r.items).toBeGreaterThan(0);
    const me = await ok(CAROL, 'GET', '/api/me');
    expect(me.user.balance).toBe(0);
    expect(me.inventory).toHaveLength(0);
    expect(me.caseKeys.noobini ?? 0).toBe(0);
    expect((await pool.query('SELECT count(*)::int AS n FROM drops WHERE user_id = $1', [CAROL])).rows[0].n).toBe(0);
    // Nobody else is touched.
    expect((await ok(BOB, 'GET', '/api/me')).user.balance).toBeCloseTo(bobBefore.user.balance, 2);
    expect((await ok(OWNER, 'GET', '/api/admin/logs')).some((l: { action: string }) => l.action === 'danger_reset')).toBe(true);
  });

  it('wipes every player with the password and the phrase; payment ledgers stay', { timeout: 30_000 }, async () => {
    const payments = (await pool.query('SELECT count(*)::int AS n FROM star_payments')).rows[0].n;
    // Tickets and claimed quests are game state too (tickets open ticket cases); admins stay admins.
    await pool.query('UPDATE users SET tickets = 77 WHERE id = $1', [ALICE]);
    await pool.query(`INSERT INTO quest_claims (user_id, quest, period, reward, currency) VALUES ($1, 'wipe-test', 'p', 5, 'tickets') ON CONFLICT DO NOTHING`, [ALICE]);
    const admins = (await pool.query('SELECT count(*)::int AS n FROM admins')).rows[0].n;
    expect((await call(OWNER, 'POST', '/api/admin/danger/wipe', { password: PASSWORD, confirm: 'да' })).data.error).toBe('invalid');
    const r = await ok(OWNER, 'POST', '/api/admin/danger/wipe', { password: PASSWORD, confirm: 'СТЕРЕТЬ ВСЁ' });
    expect(r.players).toBeGreaterThanOrEqual(5);
    const left = await pool.query(
      `SELECT (SELECT count(*) FROM inventory)::int AS inv, (SELECT count(*) FROM drops)::int AS drops, (SELECT count(*) FROM battles)::int AS battles,
              (SELECT count(*) FROM case_keys)::int AS keys, (SELECT count(*) FROM users WHERE balance <> 0 OR ref_balance <> 0)::int AS rich,
              (SELECT count(*) FROM withdrawals WHERE status <> 'done')::int AS open, (SELECT count(*) FROM star_payments)::int AS payments`,
    );
    expect(left.rows[0]).toEqual({ inv: 0, drops: 0, battles: 0, keys: 0, rich: 0, open: 0, payments });
    const extra = await pool.query(
      `SELECT (SELECT count(*) FROM users WHERE tickets <> 0)::int AS tickets, (SELECT count(*) FROM quest_claims)::int AS quests, (SELECT count(*) FROM admins)::int AS admins`,
    );
    expect(extra.rows[0]).toEqual({ tickets: 0, quests: 0, admins });
    // Players still log in and play from zero.
    const me = await ok(ALICE, 'GET', '/api/me');
    expect(me.user.balance).toBe(0);
    expect(me.inventory).toHaveLength(0);
    expect((await ok(OWNER, 'GET', '/api/admin/danger')).lastWipe.details.players).toBe(r.players);
  });
});

describe('pre-launch audit fixes', () => {
  const ADM = 2601;
  const PLAYER = 2602;

  it('a frozen admin loses the panel; nobody lifts their own punishment', async () => {
    await ok(ADM, 'GET', '/api/me');
    await ok(PLAYER, 'GET', '/api/me');
    await ok(OWNER, 'POST', '/api/admin/admins', { user: String(ADM) });
    await ok(ADM, 'GET', '/api/admin/stats');
    const p = await ok(OWNER, 'POST', '/api/admin/punish', { user: String(ADM), kind: 'freeze', amount: 1, unit: 'day' });
    expect((await call(ADM, 'GET', '/api/admin/stats')).status).toBe(403);
    expect((await call(ADM, 'POST', `/api/admin/punishments/${p.id}/revoke`)).status).toBe(403);
    await ok(OWNER, 'POST', `/api/admin/punishments/${p.id}/revoke`);
    await ok(ADM, 'GET', '/api/admin/stats');
  });

  it('take: owners are untouchable and the reply says what was really taken', async () => {
    expect((await call(ADM, 'POST', '/api/admin/take', { userId: OWNER, coins: 10 })).status).toBe(403);
    await ok(OWNER, 'POST', '/api/admin/give', { user: String(PLAYER), type: 'coins', amount: 20 });
    const r = await ok(ADM, 'POST', '/api/admin/take', { userId: PLAYER, coins: 500 });
    expect(r.coins).toBe(20);
    expect((await ok(PLAYER, 'GET', '/api/me')).user.balance).toBe(0);
  });

  it("an admin promo code never shadows a player's partner code", async () => {
    await ok(PLAYER, 'GET', '/api/referrals');
    const { ref_code: code } = (await pool.query('SELECT ref_code FROM users WHERE id = $1', [PLAYER])).rows[0];
    expect(code).toBeTruthy();
    expect((await call(OWNER, 'POST', '/api/admin/promos', { code, maxUses: 1, rewardType: 'coins', amount: 1 })).status).toBe(409);
  });

  it('a switched-off brainrot stays in its case through an admin save and comes back when switched on', async () => {
    const png = Buffer.from('89504e470d0a1a0a0000000d4948445200000001000000010806000000', 'hex').toString('base64');
    const { url } = await ok(OWNER, 'POST', '/api/admin/upload', { dataUrl: `data:image/png;base64,${png}` });
    const items = [
      { brainrotId: 'garama-and-madundung', chance: 0.5 },
      { brainrotId: 'bupin-bani', chance: 0.3 },
      { brainrotId: 'meowl', chance: 0.2 },
    ];
    const kase = await ok(OWNER, 'POST', '/api/admin/cases', { name: 'Аудит кейс', price: 100, image: url, items });
    await ok(OWNER, 'PATCH', '/api/admin/brainrots/meowl', { status: 'disabled' });
    // The editor only sees what is on, and saves just that.
    await ok(OWNER, 'PATCH', `/api/admin/cases/${kase.id}`, { name: 'Аудит кейс 2', items: items.slice(0, 2) });
    await ok(OWNER, 'PATCH', '/api/admin/brainrots/meowl', { status: 'active' });
    const rows = (await pool.query('SELECT brainrot_id, fixed_chance FROM case_items WHERE case_id = $1 ORDER BY brainrot_id', [kase.id])).rows;
    expect(rows.map((r) => r.brainrot_id)).toEqual(['bupin-bani', 'garama-and-madundung', 'meowl']);
    expect(Number(rows.find((r) => r.brainrot_id === 'meowl').fixed_chance)).toBeCloseTo(0.2, 6);
    await ok(OWNER, 'DELETE', `/api/admin/cases/${kase.id}`);
  });

  it('admins close and open «Брейнроты» and «Гирсы» separately; a closed tab takes no new requests', async () => {
    const P = 2603;
    await ok(P, 'GET', '/api/me');
    expect((await ok(P, 'GET', '/api/catalog')).depositOpen).toEqual({ brainrots: true, gears: true });
    expect((await call(P, 'POST', '/api/admin/settings', { depositOpen: { brainrots: false } })).status).toBe(403);
    await ok(OWNER, 'POST', '/api/admin/settings', { depositOpen: { gears: false } });
    expect((await ok(P, 'GET', '/api/catalog')).depositOpen).toEqual({ brainrots: true, gears: false });
    const offers = await ok(P, 'GET', '/api/item-deposits/catalog');
    const gear = offers.find((b: { section: string }) => b.section === 'gears');
    const brainrot = offers.find((b: { section: string }) => b.section === 'brainrots');
    expect((await call(P, 'POST', '/api/item-deposits', { items: [{ brainrotId: gear.id }], robloxNick: 'Intake_1' })).data).toMatchObject({
      error: 'deposit_closed',
      message: expect.stringContaining('гирсами'),
    });
    // «Брейнроты» stay open.
    const d = await ok(P, 'POST', '/api/item-deposits', { items: [{ brainrotId: brainrot.id }], robloxNick: 'Intake_1' });
    await ok(P, 'POST', `/api/item-deposits/${d.id}/cancel`, {});
    await ok(OWNER, 'POST', '/api/admin/settings', { depositOpen: { gears: true } });
    expect((await ok(P, 'GET', '/api/catalog')).depositOpen).toEqual({ brainrots: true, gears: true });
  });

  it('Raining Tacos: off until an owner starts it; catching pays 5 B and then waits out the cooldown', async () => {
    const P = 2604;
    await ok(P, 'GET', '/api/me');
    // Off by default — no catching.
    expect((await ok(P, 'GET', '/api/tacos')).endsAt).toBe(null);
    expect((await call(P, 'POST', '/api/tacos/catch')).data.error).toBe('tacos_off');
    // Players can't start it; an owner can.
    expect((await call(P, 'POST', '/api/admin/settings', { tacos: { enabled: true, endsAt: Date.now() + 3600_000 } })).status).toBe(403);
    await ok(OWNER, 'POST', '/api/admin/settings', { tacos: { enabled: true, endsAt: Date.now() + 3600_000 } });
    const st = await ok(P, 'GET', '/api/tacos');
    expect(st.endsAt).toBeGreaterThan(Date.now());
    expect(st.capPerDay).toBeGreaterThan(0);
    // A winning catch (rng < 5%) pays exactly the coin amount.
    fixRandom(0);
    const before = (await ok(P, 'GET', '/api/me')).user.balance;
    const hit = await ok(P, 'POST', '/api/tacos/catch');
    expect(hit.result.coins).toBe(st.coinAmount);
    expect(hit.result.caughtToday).toBe(1);
    expect(hit.me.user.balance).toBeCloseTo(before + st.coinAmount, 2);
    // The next catch has to wait out the cooldown.
    expect((await call(P, 'POST', '/api/tacos/catch')).data.error).toBe('cooldown');
    await ok(OWNER, 'POST', '/api/admin/settings', { tacos: { enabled: false, endsAt: Date.now() + 3600_000 } });
  });

  it('owners post a site-wide announcement that rides with the catalog', async () => {
    const P = 2605;
    await ok(P, 'GET', '/api/me');
    expect((await ok(P, 'GET', '/api/catalog')).announcement ?? null).toBe(null);
    // Players (even admins who aren't owners) can't post it.
    expect((await call(P, 'POST', '/api/admin/settings', { announcement: { text: 'привет' } })).status).toBe(403);
    await ok(OWNER, 'POST', '/api/admin/settings', { announcement: { text: 'Розыгрыш сегодня вечером!' } });
    const a = (await ok(P, 'GET', '/api/catalog')).announcement;
    expect(a).toMatchObject({ text: 'Розыгрыш сегодня вечером!' });
    expect(typeof a.authorName).toBe('string');
    expect(a.at).toBeGreaterThan(0);
    // Empty text clears it.
    await ok(OWNER, 'POST', '/api/admin/settings', { announcement: { text: '' } });
    expect((await ok(P, 'GET', '/api/catalog')).announcement ?? null).toBe(null);
  });
});

describe('iteration 27: road, giveaways, big invites', () => {
  const sha = (x: string) => createHash('sha256').update(x).digest('hex');
  /** A key whose first `safe` lanes are clear (and whose next lane crashes or not, when asked). */
  const roadSeedFor = (level: RoadLevel, safe: number, crashNext?: boolean) => {
    for (let i = 0; ; i++) {
      const seed = `road-test-${level}-${safe}-${crashNext}-${i}`;
      const crashes = Array.from({ length: safe + 1 }, (_, k) => laneCrashes(level, sha(roadMessage(seed, k + 1))));
      if (crashes.slice(0, safe).every((c) => !c) && (crashNext === undefined || crashes[safe] === crashNext)) return seed;
    }
  };
  const plantRoadSeed = (user: number, seed: string) =>
    pool.query('INSERT INTO road_seeds (user_id, seed, hash) VALUES ($1, $2, $3) ON CONFLICT (user_id) DO UPDATE SET seed = EXCLUDED.seed, hash = EXCLUDED.hash', [user, seed, sha(seed)]);
  const ROADY = 3001;

  it('road rules: lanes as long as Chicken Road\'s, never above x50, the house keeps 6 % wherever you leave', () => {
    expect(ROAD_LEVELS.map((l) => roadLanes(l.id).length)).toEqual([24, 22, 17, 11]);
    for (const l of ROAD_LEVELS) {
      const lanes = roadLanes(l.id);
      expect(Math.max(...lanes)).toBeLessThanOrEqual(50);
      lanes.forEach((m, i) => expect((1 - l.risk) ** (i + 1) * m).toBeLessThanOrEqual(ROAD_RTP + 1e-9));
    }
    expect(laneMultiplier('medium', 2)).toBe(1.21);
    expect(nextLaneProblem('hardcore', 11, 1)).toBe('end');
    expect(nextLaneProblem('hardcore', 10, 1000)).toBe('limit');
    expect(nextLaneProblem('easy', 0, 45)).toBe(null);
  });

  it('Дорога: lanes follow the pre-committed key; a crash burns the stake, «Забрать» pays the lane multiplier', async () => {
    await ok(ROADY, 'GET', '/api/me');
    await pool.query('UPDATE users SET balance = balance + 1000 WHERE id = $1', [ROADY]);
    const s = await ok(ROADY, 'GET', '/api/road');
    expect(s.nextHash).toMatch(/^[0-9a-f]{64}$/);
    expect(s.run).toBeNull();
    expect((await call(ROADY, 'POST', '/api/road/start', { level: 'easy', coins: 10 })).data.error).toBe('items_only');
    expect((await call(ROADY, 'POST', '/api/road/start', { level: 'easy', itemIds: [] })).data.error).toBe('invalid');
    expect((await call(ROADY, 'POST', '/api/road/start', { level: 'insane', itemIds: [1] })).data.error).toBe('invalid');
    expect((await call(ROADY, 'POST', '/api/road/step')).data.error).toBe('no_run');

    // Two clear lanes, a crash on the third: the player leaves after two.
    const seed1 = roadSeedFor('medium', 2, true);
    await plantRoadSeed(ROADY, seed1);
    const a = await buy(ROADY, 'garama-and-madundung');
    const started = await ok(ROADY, 'POST', '/api/road/start', { level: 'medium', itemIds: [a] });
    expect(started.result.run).toMatchObject({ level: 'medium', step: 0, status: 'active', stakeValue: 45, seed: null, hash: sha(seed1) });
    expect(started.result.nextHash).not.toBe(sha(seed1));
    expect(started.me.inventory.some((i: { id: number }) => i.id === a)).toBe(false);
    expect((await call(ROADY, 'POST', '/api/road/start', { level: 'easy', itemIds: [await buy(ROADY, 'garama-and-madundung')] })).data.error).toBe('run_active');
    expect((await call(ROADY, 'POST', '/api/road/cashout')).data.error).toBe('no_step');
    const st1 = await ok(ROADY, 'POST', '/api/road/step');
    expect(st1.result).toMatchObject({ crashed: false, run: { step: 1, status: 'active', multiplier: laneMultiplier('medium', 1), seed: null } });
    await ok(ROADY, 'POST', '/api/road/step');
    const before = (await ok(ROADY, 'GET', '/api/me')).user.balance;
    const out = await ok(ROADY, 'POST', '/api/road/cashout');
    expect(out.result.run).toMatchObject({ status: 'cashed', step: 2, multiplier: 1.21, seed: seed1 });
    expect(out.result.run.payout.value).toBeCloseTo(45 * 1.21, 2);
    expect(out.me.user.balance).toBeCloseTo(before + out.result.run.payout.coins, 2);
    if (out.result.run.payout.itemId) expect(out.me.inventory.some((i: { id: number }) => i.id === out.result.run.payout.itemId)).toBe(true);
    expect((await call(ROADY, 'POST', '/api/road/cashout')).data.error).toBe('no_run');

    // A crash on the first lane: the stake is gone and the key is shown.
    const seed2 = roadSeedFor('hardcore', 0, true);
    await plantRoadSeed(ROADY, seed2);
    await ok(ROADY, 'POST', '/api/road/start', { level: 'hardcore', itemIds: [await buy(ROADY, 'garama-and-madundung')] });
    const crash = await ok(ROADY, 'POST', '/api/road/step');
    expect(crash.result).toMatchObject({ crashed: true, run: { status: 'crashed', step: 0, seed: seed2 } });
    const s2 = await ok(ROADY, 'GET', '/api/road');
    expect(s2.run).toBeNull();
    expect(s2.mine.slice(0, 2)).toMatchObject([
      { level: 'hardcore', won: false, value: 0 },
      { level: 'medium', step: 2, won: true, multiplier: 1.21 },
    ]);
    expect(s2.top[0]).toMatchObject({ name: `u${ROADY}`, level: 'medium', step: 2, multiplier: 1.21 });

    // The last lane takes the win by itself.
    const seed3 = roadSeedFor('hardcore', 11);
    await plantRoadSeed(ROADY, seed3);
    await ok(ROADY, 'POST', '/api/road/start', { level: 'hardcore', itemIds: [await buy(ROADY, 'garama-and-madundung')] });
    let last;
    for (let k = 0; k < 11; k++) last = await ok(ROADY, 'POST', '/api/road/step');
    expect(last.result.run).toMatchObject({ status: 'cashed', step: 11, multiplier: laneMultiplier('hardcore', 11) });
    expect(last.result.run.payout.value).toBeCloseTo(45 * laneMultiplier('hardcore', 11), 2);
  }, 30_000);

  it('the tick closes a road run left alone for 30 minutes: the win after a step, the stake back before one', async () => {
    await plantRoadSeed(ROADY, roadSeedFor('easy', 1));
    await ok(ROADY, 'POST', '/api/road/start', { level: 'easy', itemIds: [await buy(ROADY, 'garama-and-madundung')] });
    await ok(ROADY, 'POST', '/api/road/step');
    const idle = () => pool.query(`UPDATE road_runs SET updated_at = now() - interval '31 minutes' WHERE user_id = $1 AND status = 'active'`, [ROADY]);
    await idle();
    sent.length = 0;
    await runTick();
    const r1 = (await pool.query(`SELECT status, payout FROM road_runs WHERE user_id = $1 ORDER BY id DESC LIMIT 1`, [ROADY])).rows[0];
    expect(r1.status).toBe('cashed');
    expect(Number(r1.payout.value)).toBeCloseTo(45 * laneMultiplier('easy', 1), 2);
    expect(sent.some((m) => m.chatId === ROADY && m.html.includes('полосе 1'))).toBe(true);

    await ok(ROADY, 'POST', '/api/road/start', { level: 'easy', itemIds: [await buy(ROADY, 'garama-and-madundung')] });
    await idle();
    await runTick();
    expect((await pool.query(`SELECT status FROM road_runs WHERE user_id = $1 ORDER BY id DESC LIMIT 1`, [ROADY])).rows[0].status).toBe('refunded');
    expect((await pool.query(`SELECT count(*)::int AS n FROM inventory WHERE user_id = $1 AND source = 'road_refund' AND brainrot_id = 'garama-and-madundung'`, [ROADY])).rows[0].n).toBe(1);
    expect((await ok(ROADY, 'GET', '/api/road')).run).toBeNull();
  }, 20_000);

  const G = [3101, 3102, 3103, 3104, 3105, 3106, 3107];
  const [G1, G2, G3, G4, G5, F1, F2] = G as [number, number, number, number, number, number, number];
  const deposit = (user: number, amount: number, at = new Date()) =>
    pool.query(`INSERT INTO item_deposits (user_id, items, value, roblox_nick, status, credited, created_at, updated_at) VALUES ($1, '[]', $2, 'Test_Nick', 'credited', $2, $3, $3)`, [user, amount, at]);
  const withdrawn = (user: number, amount: number, at = new Date()) =>
    pool.query(`INSERT INTO withdrawals (user_id, value, roblox_nick, status, processed_at) VALUES ($1, $2, 'Test_Nick', 'done', $3)`, [user, amount, at]);
  /** The giveaways' start: set when the first giveaway test begins, so earlier tests' deposits stay out. */
  let t0 = 0;
  const giveaway = (over: Record<string, unknown>) => ({
    kind: 'deposit_race',
    title: 'Гонка недели',
    description: 'Кто больше пополнит — тот и забирает',
    conditions: 'Считаются пополнения минус выводы',
    startsAt: t0,
    endsAt: Date.now() + 86_400_000,
    prizes: ['capitano-moby', 'garama-and-madundung'],
    ...over,
  });

  it('giveaways: admins make a deposit race; net deposits score, the top gets the prizes in the inventory', { timeout: 30_000 }, async () => {
    t0 = Date.now();
    for (const id of G) await ok(id, 'GET', '/api/me');
    expect((await call(G1, 'POST', '/api/admin/giveaways', giveaway({}))).status).toBe(403);
    expect((await call(OWNER, 'POST', '/api/admin/giveaways', giveaway({ endsAt: Date.now() - 1000 }))).data.error).toBe('invalid');
    expect((await call(OWNER, 'POST', '/api/admin/giveaways', giveaway({ prizes: [] }))).data.error).toBe('invalid');
    expect((await call(OWNER, 'POST', '/api/admin/giveaways', giveaway({ prizes: ['nope'] }))).data.error).toBe('invalid');
    expect((await call(OWNER, 'POST', '/api/admin/giveaways', giveaway({ banner: 'https://evil.example/x.png' }))).data.error).toBe('invalid');
    // Invite races need a deposit threshold: empty accounts must never count.
    expect((await call(OWNER, 'POST', '/api/admin/giveaways', giveaway({ kind: 'referral_race', minDeposit: 0 }))).data.error).toBe('invalid');
    const { id } = await ok(OWNER, 'POST', '/api/admin/giveaways', giveaway({}));

    await deposit(G4, 900, new Date(t0 - 3600_000)); // before the start: doesn't count
    await deposit(G1, 500);
    await deposit(G2, 800);
    await withdrawn(G2, 400); // deposited and took half back: 400 net
    await deposit(G3, 300);
    // Staff never place: an admin credits deposits himself.
    await ok(OWNER2, 'GET', '/api/me');
    await deposit(OWNER2, 5000);
    const list = await ok(G3, 'GET', '/api/giveaways');
    expect(list.active.find((g: { id: number }) => g.id === id)).toMatchObject({ kind: 'deposit_race', status: 'active', entries: null, prizes: [{ place: 1 }, { place: 2 }] });
    const d = await ok(G3, 'GET', `/api/giveaways/${id}`);
    expect(d.top.map((p: { name: string; score: number }) => [p.name, p.score])).toEqual([
      [`u${G1}`, 500],
      [`u${G2}`, 400],
      [`u${G3}`, 300],
    ]);
    expect(d.me).toMatchObject({ place: 3, score: 300, eligible: true });
    expect(d.field).toBe(3);
    expect((await ok(G4, 'GET', `/api/giveaways/${id}`)).me.place).toBe(null);
    expect((await call(G1, 'POST', `/api/giveaways/${id}/join`)).data.error).toBe('invalid');

    botCalls.length = 0;
    const r = await ok(OWNER, 'POST', `/api/admin/giveaways/${id}/settle`);
    expect(r).toMatchObject({ id, winners: 2 });
    expect((await call(OWNER, 'POST', `/api/admin/giveaways/${id}/settle`)).data.error).toBe('finished');
    const prize = async (user: number) => (await pool.query(`SELECT brainrot_id FROM inventory WHERE user_id = $1 AND source = 'giveaway'`, [user])).rows.map((x) => x.brainrot_id);
    expect(await prize(G1)).toEqual(['capitano-moby']);
    expect(await prize(G2)).toEqual(['garama-and-madundung']);
    expect(await prize(G3)).toEqual([]);
    expect(botCalls.some((c) => c.method === 'sendMessage' && c.params.chat_id === G1 && String(c.params.text).includes('1 место'))).toBe(true);
    const done = await ok(G2, 'GET', `/api/giveaways/${id}`);
    expect(done.status).toBe('finished');
    expect(done.winners.map((w: { place: number; name: string; brainrotId: string }) => [w.place, w.name, w.brainrotId])).toEqual([
      [1, `u${G1}`, 'capitano-moby'],
      [2, `u${G2}`, 'garama-and-madundung'],
    ]);
    expect(done.me).toMatchObject({ place: 2, score: 400 });
    expect((await ok(G2, 'GET', '/api/giveaways')).finished[0]).toMatchObject({ id, winner: { name: `u${G1}`, brainrotId: 'capitano-moby' } });
  });

  it('a draw: players join after meeting the requirements; the tick draws winners among those who still do', { timeout: 30_000 }, async () => {
    const { id } = await ok(OWNER, 'POST', '/api/admin/giveaways', giveaway({ kind: 'draw', title: 'Розыгрыш', minDeposit: 100, needChannel: true, prizes: ['bupin-bani'] }));
    const join = (u: number) => call(u, 'POST', `/api/giveaways/${id}/join`);
    expect((await join(G4)).data).toMatchObject({ error: 'need_deposit', need: 100 });
    unsubscribed.add(G3);
    expect((await join(G3)).data).toMatchObject({ error: 'need_channel', channel: '@BrainrotCrash' });
    unsubscribed.delete(G3);
    expect((await join(OWNER)).data.error).toBe('staff');
    expect((await join(G1)).status).toBe(200);
    expect((await join(G1)).status).toBe(200);
    expect((await join(G3)).status).toBe(200);
    const d = await ok(G1, 'GET', `/api/giveaways/${id}`);
    expect(d).toMatchObject({ kind: 'draw', entries: 2, field: 2, top: [], channel: { username: '@BrainrotCrash' } });
    expect(d.me).toMatchObject({ joined: true, eligible: true });
    // G3 leaves the channel before the end: the draw skips them.
    unsubscribed.add(G3);
    await pool.query(`UPDATE giveaways SET ends_at = now() - interval '1 second' WHERE id = $1`, [id]);
    await runTick();
    unsubscribed.delete(G3);
    const done = await ok(G1, 'GET', `/api/giveaways/${id}`);
    expect(done.status).toBe('finished');
    expect(done.winners).toMatchObject([{ place: 1, name: `u${G1}`, brainrotId: 'bupin-bani' }]);
    expect((await join(G1)).data.error).toBe('finished');
  });

  it('an invite race counts friends bound in the period who deposited enough; admins edit and cancel', { timeout: 30_000 }, async () => {
    const { id } = await ok(OWNER, 'POST', '/api/admin/giveaways', giveaway({ kind: 'referral_race', title: 'Гонка приглашений', minDeposit: 50 }));
    await pool.query(`UPDATE users SET referred_by = $1, referred_at = now() WHERE id = ANY($2)`, [G5, [F1, F2]]);
    await deposit(F1, 100);
    await deposit(F2, 20); // below the threshold
    const d = await ok(G5, 'GET', `/api/giveaways/${id}`);
    expect(d.top).toMatchObject([{ name: `u${G5}`, score: 1 }]);
    expect(d.me).toMatchObject({ place: 1, score: 1 });
    await ok(OWNER, 'PATCH', `/api/admin/giveaways/${id}`, { minDeposit: 10, title: 'Гонка друзей', prizes: ['jolly-jolly-sahur'] });
    const e = await ok(G5, 'GET', `/api/giveaways/${id}`);
    expect(e).toMatchObject({ title: 'Гонка друзей', minDeposit: 10, prizes: [{ place: 1, brainrotId: 'jolly-jolly-sahur' }] });
    expect(e.top[0].score).toBe(2);
    expect((await call(OWNER, 'PATCH', `/api/admin/giveaways/${id}`, { minDeposit: 5 })).data.error).toBe('invalid');
    expect((await ok(OWNER, 'GET', '/api/admin/giveaways')).find((g: { id: number }) => g.id === id)).toMatchObject({ kind: 'referral_race', minDeposit: 10 });
    await ok(OWNER, 'POST', `/api/admin/giveaways/${id}/cancel`);
    expect((await call(G5, 'GET', `/api/giveaways/${id}`)).status).toBe(404);
    expect((await ok(G5, 'GET', '/api/giveaways')).active.some((g: { id: number }) => g.id === id)).toBe(false);
    expect((await call(OWNER, 'POST', `/api/admin/giveaways/${id}/settle`)).data.error).toBe('finished');
  });

  it('big invites: a friend\'s net deposits passing 1 000 / 5 000 B pay 10 % once per threshold, after 3× played in cases and battles', { timeout: 30_000 }, async () => {
    const M1 = 3201;
    const M2 = 3202;
    const refBalance = async (id: number) => Number((await pool.query('SELECT ref_balance FROM users WHERE id = $1', [id])).rows[0].ref_balance);
    const { code } = await ok(M1, 'GET', '/api/referrals');
    await hook({ update_id: 3202, message: { message_id: 3202, from: { id: M2, first_name: 'm2' }, chat: { id: M2, type: 'private' }, text: `/start r-${code}` } });
    let n = 0;
    const pay = async (stars: number) => {
      const inv = await ok(M2, 'POST', '/api/stars/invoice', { stars });
      n++;
      await hook({
        update_id: 3300 + n,
        message: {
          message_id: 3300 + n,
          from: { id: M2, first_name: 'm2' },
          chat: { id: M2, type: 'private' },
          successful_payment: { currency: 'XTR', total_amount: stars, invoice_payload: `stars:${inv.orderId}`, telegram_payment_charge_id: `big-${n}`, provider_payment_charge_id: '' },
        },
      });
      return inv.coins as number;
    };
    const milestones = async () => (await pool.query('SELECT step, amount FROM ref_milestones WHERE referral_id = $1 ORDER BY step', [M2])).rows.map((r) => [r.step, Number(r.amount)]);
    // What the friend «played»: case and battle stakes count, other games don't.
    const play = (game: string, value: number) =>
      pool.query(`INSERT INTO drops (user_id, game, result, stake_value) VALUES ($1, $2, 'lose', $3)`, [M2, game, value]);
    const before = await refBalance(M1);
    botCalls.length = 0;
    const c1 = await pay(1000);
    expect(c1).toBeGreaterThanOrEqual(1000);
    // Deposited 1 000, played nothing yet: only the deposit share.
    expect(await milestones()).toEqual([]);
    expect(await refBalance(M1)).toBeCloseTo(before + Math.floor(c1 * 5) / 100, 2);
    await play('upgrade', 5000);
    await play('case', REF_MILESTONES[0].from * REF_MILESTONE_TURNOVER - 1);
    await runTick();
    expect(await milestones()).toEqual([]);
    await play('battle', 1);
    await runTick();
    expect(await milestones()).toEqual([[1, 100]]);
    expect(await refBalance(M1)).toBeCloseTo(before + Math.floor(c1 * 5) / 100 + 100, 2);
    expect(botCalls.some((c) => c.params.chat_id === M1 && String(c.params.text).includes('Крупное приглашение'))).toBe(true);
    await runTick();
    expect(await milestones()).toEqual([[1, 100]]); // once
    // Withdrawals take the net back down: gross over 5 000 isn't enough.
    await play('case', 20_000);
    const big = 3000;
    await withdrawn(M2, c1 + Math.round(big * 1.35) - 4990);
    await pay(big);
    expect(await milestones()).toEqual([[1, 100]]);
    // Played enough already: the deposit that passes 5 000 pays at once.
    await pay(100);
    expect(await milestones()).toEqual([
      [1, 100],
      [2, 500],
    ]);
    const s = await ok(M1, 'GET', '/api/referrals');
    expect(s.milestones).toBe(600);
    const friends = await ok(M1, 'GET', '/api/referrals/friends');
    expect(friends[0]).toMatchObject({ nextMilestone: { step: 3, from: 20_000, reward: 2_000, turnover: 60_000 } });
    expect(friends[0].played).toBe(REF_MILESTONES[0].from * REF_MILESTONE_TURNOVER + 20_000);
    expect(friends[0].net).toBeGreaterThanOrEqual(5000);
  });
});

describe('iteration 28: mines, events, snap', () => {
  const sha = (x: string) => createHash('sha256').update(x).digest('hex');
  const field = (seed: string, mines: number) => minesFromDigests(mines, Array.from({ length: mines }, (_, i) => sha(minesMessage(seed, i))));
  const plant = (user: number, seed: string) =>
    pool.query('INSERT INTO mines_seeds (user_id, seed, hash) VALUES ($1, $2, $3) ON CONFLICT (user_id) DO UPDATE SET seed = EXCLUDED.seed, hash = EXCLUDED.hash', [user, seed, sha(seed)]);
  const MINER = 3301;

  it('mines rules: the house keeps 6 % wherever you stop; x100 and 25 000 B are the ceiling', () => {
    expect(minesMultiplier(1, 1)).toBe(0.97);
    expect(minesMultiplier(24, 1)).toBe(23.5);
    expect(minesMultiplier(3, 0)).toBe(0);
    for (let m = 1; m <= 24; m++) {
      for (let k = 1; k <= MINES_TILES - m; k++) expect(clearChance(m, k) * minesMultiplier(m, k)).toBeLessThanOrEqual(MINES_RTP + 1e-9);
    }
    expect(nextPickProblem(24, 1, 1)).toBe('end');
    expect(nextPickProblem(10, 0, 1)).toBe(null);
    // 10 mines: the 8th tile would pay more than x100.
    expect(minesMultiplier(10, 7)).toBeLessThan(100);
    expect(minesMultiplier(10, 8)).toBeGreaterThan(100);
    expect(nextPickProblem(10, 7, 1)).toBe('limit');
    expect(nextPickProblem(1, 0, 30_000)).toBe('limit');
    const f = field('some-key', 5);
    expect(f).toHaveLength(5);
    expect(new Set(f).size).toBe(5);
    expect(f.every((t) => t >= 0 && t < 25)).toBe(true);
    expect(field('some-key', 5)).toEqual(f);
  });

  it('Мины: the field follows the pre-committed key; a mine burns the stake, «Забрать» pays the multiplier', async () => {
    await ok(MINER, 'GET', '/api/me');
    await pool.query('UPDATE users SET balance = balance + 1000 WHERE id = $1', [MINER]);
    const s = await ok(MINER, 'GET', '/api/mines');
    expect(s.nextHash).toMatch(/^[0-9a-f]{64}$/);
    expect(s.run).toBeNull();
    expect((await call(MINER, 'POST', '/api/mines/start', { mines: 3, coins: 10 })).data.error).toBe('items_only');
    expect((await call(MINER, 'POST', '/api/mines/start', { mines: 0, itemIds: [1] })).data.error).toBe('invalid');
    // The owner's floor: at least 3 mines.
    expect((await call(MINER, 'POST', '/api/mines/start', { mines: 2, itemIds: [1] })).data.error).toBe('invalid');
    expect((await call(MINER, 'POST', '/api/mines/start', { mines: 25, itemIds: [1] })).data.error).toBe('invalid');
    expect((await call(MINER, 'POST', '/api/mines/pick', { tile: 0 })).data.error).toBe('no_run');

    const seed1 = 'mines-test-one';
    const mines1 = field(seed1, 3);
    const safe = Array.from({ length: 25 }, (_, i) => i).filter((t) => !mines1.includes(t));
    await plant(MINER, seed1);
    const a = await buy(MINER, 'garama-and-madundung');
    const started = await ok(MINER, 'POST', '/api/mines/start', { mines: 3, itemIds: [a] });
    expect(started.result.run).toMatchObject({ mines: 3, picks: [], status: 'active', stakeValue: 45, seed: null, minesAt: null, hash: sha(seed1) });
    expect(started.result.nextHash).not.toBe(sha(seed1));
    expect((await call(MINER, 'POST', '/api/mines/start', { mines: 3, itemIds: [await buy(MINER, 'garama-and-madundung')] })).data.error).toBe('run_active');
    expect((await call(MINER, 'POST', '/api/mines/cashout')).data.error).toBe('no_step');
    expect((await call(MINER, 'POST', '/api/mines/pick', { tile: 25 })).data.error).toBe('invalid');
    const p1 = await ok(MINER, 'POST', '/api/mines/pick', { tile: safe[0] });
    expect(p1.result).toMatchObject({ busted: false, run: { picks: [safe[0]], multiplier: minesMultiplier(3, 1), minesAt: null } });
    expect((await call(MINER, 'POST', '/api/mines/pick', { tile: safe[0] })).data.error).toBe('taken');
    await ok(MINER, 'POST', '/api/mines/pick', { tile: safe[1] });
    const before = (await ok(MINER, 'GET', '/api/me')).user.balance;
    const out = await ok(MINER, 'POST', '/api/mines/cashout');
    expect(out.result.run).toMatchObject({ status: 'cashed', picks: [safe[0], safe[1]], multiplier: minesMultiplier(3, 2), seed: seed1, minesAt: mines1 });
    expect(out.result.run.payout.value).toBeCloseTo(45 * minesMultiplier(3, 2), 2);
    expect(out.me.user.balance).toBeCloseTo(before + out.result.run.payout.coins, 2);

    // A mine: the stake is gone and the whole field is shown.
    const seed2 = 'mines-test-two';
    const mines2 = field(seed2, 5);
    await plant(MINER, seed2);
    await ok(MINER, 'POST', '/api/mines/start', { mines: 5, itemIds: [await buy(MINER, 'garama-and-madundung')] });
    const boom = await ok(MINER, 'POST', '/api/mines/pick', { tile: mines2[0] });
    expect(boom.result).toMatchObject({ busted: true, run: { status: 'busted', bust: mines2[0], seed: seed2, minesAt: mines2 } });

    // 24 mines: the one clear tile cashes out by itself at x23.5.
    const seed3 = 'mines-test-three';
    const mines3 = field(seed3, 24);
    await plant(MINER, seed3);
    await ok(MINER, 'POST', '/api/mines/start', { mines: 24, itemIds: [await buy(MINER, 'garama-and-madundung')] });
    const lucky = await ok(MINER, 'POST', '/api/mines/pick', { tile: Array.from({ length: 25 }, (_, i) => i).find((t) => !mines3.includes(t)) });
    expect(lucky.result.run).toMatchObject({ status: 'cashed', multiplier: 23.5 });
    expect(lucky.result.run.payout.value).toBeCloseTo(45 * 23.5, 2);
    const s2 = await ok(MINER, 'GET', '/api/mines');
    expect(s2.mine.slice(0, 3)).toMatchObject([
      { mines: 24, picks: 1, won: true, multiplier: 23.5 },
      { mines: 5, picks: 0, won: false },
      { mines: 3, picks: 2, won: true },
    ]);
    expect(s2.top[0]).toMatchObject({ name: `u${MINER}`, mines: 24, multiplier: 23.5 });
  }, 30_000);

  it('the tick closes a mines round left alone for 30 minutes', async () => {
    const seed = 'mines-test-idle';
    const mines = field(seed, 3);
    await plant(MINER, seed);
    await ok(MINER, 'POST', '/api/mines/start', { mines: 3, itemIds: [await buy(MINER, 'garama-and-madundung')] });
    await ok(MINER, 'POST', '/api/mines/pick', { tile: Array.from({ length: 25 }, (_, i) => i).find((t) => !mines.includes(t)) });
    await pool.query(`UPDATE mines_runs SET updated_at = now() - interval '31 minutes' WHERE user_id = $1 AND status = 'active'`, [MINER]);
    await runTick();
    const r = (await pool.query(`SELECT status, payout FROM mines_runs WHERE user_id = $1 ORDER BY id DESC LIMIT 1`, [MINER])).rows[0];
    expect(r.status).toBe('cashed');
    expect(Number(r.payout.value)).toBeCloseTo(45 * minesMultiplier(3, 1), 2);
  }, 20_000);

  it('events: admins switch FUSE and upgrader events on one by one; «Щелчок» switches every event on until one moment', { timeout: 30_000 }, async () => {
    const P = 3401;
    await ok(P, 'GET', '/api/me');
    expect((await call(P, 'POST', '/api/admin/settings', { snap: { minutes: 5 } })).status).toBe(403);
    expect((await call(OWNER, 'POST', '/api/admin/settings', { snap: { minutes: 0 } })).data.error).toBe('invalid');
    expect((await call(OWNER, 'POST', '/api/admin/settings', { snap: { minutes: 181 } })).data.error).toBe('invalid');
    expect((await call(OWNER, 'POST', '/api/admin/settings', { snap: { minutes: 5, events: ['nope'] } })).data.error).toBe('invalid');

    await ok(OWNER, 'POST', '/api/admin/settings', { fuseEvent: { minutes: 60 } });
    let c = await ok(P, 'GET', '/api/catalog');
    expect(c.events.fuse).toBeGreaterThan(Date.now() + 59 * 60_000);
    expect(c.events.upgrade).toBe(null);
    expect(c.snap).toBe(null);

    const t = Date.now();
    await ok(OWNER, 'POST', '/api/admin/settings', { snap: { minutes: 5 } });
    c = await ok(P, 'GET', '/api/catalog');
    expect(c.snap.events.sort()).toEqual(['cases', 'fuse', 'tacos', 'upgrade']);
    expect(c.snap.at).toBeGreaterThanOrEqual(t);
    expect(c.snap.endsAt).toBe(c.snap.at + 5 * 60_000);
    expect(c.events.cases).toBe(c.snap.endsAt);
    expect(c.events.upgrade).toBe(c.snap.endsAt);
    expect(c.events.tacos).toBe(c.snap.endsAt);
    // A longer event keeps its end.
    expect(c.events.fuse).toBeGreaterThan(Date.now() + 59 * 60_000);
    const me = await ok(P, 'GET', '/api/me');
    expect(me.luckUntil).toBe(c.snap.endsAt);
    expect(me.tacos).toMatchObject({ endsAt: c.snap.endsAt });

    // Only the chosen ones.
    await ok(OWNER, 'POST', '/api/admin/settings', { luck: { minutes: 0 }, fuseEvent: { minutes: 0 }, upgradeEvent: { minutes: 0 }, tacos: { enabled: false, endsAt: Date.now() } });
    await ok(OWNER, 'POST', '/api/admin/settings', { snap: { minutes: 3, events: ['upgrade'] } });
    c = await ok(P, 'GET', '/api/catalog');
    expect(c.events).toMatchObject({ cases: null, fuse: null, tacos: null });
    expect(c.events.upgrade).toBe(c.snap.endsAt);
    expect(c.snap.events).toEqual(['upgrade']);
    await ok(OWNER, 'POST', '/api/admin/settings', { upgradeEvent: { minutes: 0 } });
    expect((await ok(P, 'GET', '/api/catalog')).events.upgrade).toBe(null);
  });
});

describe('iteration 31: 18+, ranks, quests, partners, sources, economy, clean-up', () => {
  let n = 0;
  /** Stars paid through the real invoice → webhook path. */
  const payStars = async (user: number, stars: number) => {
    const inv = await ok(user, 'POST', '/api/stars/invoice', { stars });
    n++;
    await hook({
      update_id: 9100 + n,
      message: {
        message_id: 9100 + n,
        from: { id: user, first_name: `u${user}` },
        chat: { id: user, type: 'private' },
        successful_payment: { currency: 'XTR', total_amount: stars, invoice_payload: `stars:${inv.orderId}`, telegram_payment_charge_id: `it31-${n}`, provider_payment_charge_id: '' },
      },
    });
    return inv.coins as number;
  };
  const played = (user: number, game: string, value: number) =>
    pool.query(`INSERT INTO drops (user_id, game, result, stake_value, payout_value) VALUES ($1, $2, 'lose', $3, 0)`, [user, game, value]);

  it('the removed games answer 404; the BrainFlip refund returns open flips once', async () => {
    const U = 3601;
    await ok(U, 'GET', '/api/me');
    for (const path of ['/api/flips', '/api/halloween', '/api/trick']) expect((await call(U, 'GET', path)).status).toBe(404);
    const g = 'garama-and-madundung';
    await pool.query(
      `INSERT INTO flips (creator_id, side, creator_items, creator_value, seed, hash) VALUES ($1, 'b', $2::jsonb, 90, 's', 'h')`,
      [U, JSON.stringify([g, g])],
    );
    const sql = readFileSync('./netlify/database/migrations/20261107100000_brainflip_refund.sql', 'utf8');
    await pool.query(sql);
    await pool.query(sql);
    expect(Number((await pool.query('SELECT count(*) AS n FROM inventory WHERE user_id = $1 AND brainrot_id = $2', [U, g])).rows[0].n)).toBe(2);
    expect((await pool.query('SELECT status FROM flips WHERE creator_id = $1', [U])).rows[0].status).toBe('cancelled');
  });

  it('18+: without the consent nothing can be played or deposited; accepting it opens everything', async () => {
    const U = 3602;
    await ok(U, 'GET', '/api/me');
    await pool.query('UPDATE users SET terms_version = NULL, balance = 500 WHERE id = $1', [U]);
    const me = await ok(U, 'GET', '/api/me');
    expect(me.user.termsOk).toBe(false);
    expect((await call(U, 'POST', '/api/shop/buy', { brainrotId: 'garama-and-madundung' })).data.error).toBe('terms_required');
    expect((await call(U, 'POST', '/api/stars/invoice', { stars: 100 })).data.error).toBe('terms_required');
    expect((await call(U, 'POST', '/api/legal/accept', { adult: false, version: TERMS_VERSION })).data.error).toBe('invalid');
    expect((await call(U, 'POST', '/api/legal/accept', { adult: true, version: TERMS_VERSION - 1 })).data.error).toBe('terms_changed');
    const accepted = await ok(U, 'POST', '/api/legal/accept', { adult: true, version: TERMS_VERSION });
    expect(accepted.me.user.termsOk).toBe(true);
    expect((await pool.query('SELECT terms_version, terms_accepted_at FROM users WHERE id = $1', [U])).rows[0]).toMatchObject({ terms_version: TERMS_VERSION });
    await ok(U, 'POST', '/api/shop/buy', { brainrotId: 'garama-and-madundung' });
  });

  it('ranks: deposits raise the rank and the cashback; a rank gift needs 2× its threshold played, once', { timeout: 30_000 }, async () => {
    const U = 3603;
    await ok(U, 'GET', '/api/me');
    expect((await ok(U, 'GET', '/api/me')).user.rank).toBe(0);
    expect((await ok(U, 'GET', '/api/bonuses')).cashback.percent).toBe(3);
    const coins = await payStars(U, 1000);
    expect(coins).toBeGreaterThanOrEqual(RANKS[1]!.from);
    expect((await ok(U, 'GET', '/api/me')).user.rank).toBe(1);
    expect((await ok(U, 'GET', '/api/bonuses')).cashback.percent).toBe(RANKS[1]!.cashback);
    let r = await ok(U, 'GET', '/api/ranks');
    expect(r.gifts[0]).toMatchObject({ level: 1, reached: true, ready: false, taken: false, needPlayed: RANKS[1]!.from * RANK_GIFT_TURNOVER });
    expect((await call(U, 'POST', '/api/ranks/1/claim')).data.error).toBe('need_play');
    // The upgrader doesn't count; cases and battles do.
    await played(U, 'upgrade', 10_000);
    expect((await call(U, 'POST', '/api/ranks/1/claim')).data.error).toBe('need_play');
    await played(U, 'case', RANKS[1]!.from * RANK_GIFT_TURNOVER - 100);
    await played(U, 'battle', 100);
    r = await ok(U, 'GET', '/api/ranks');
    expect(r.gifts[0].ready).toBe(true);
    const gift = await ok(U, 'POST', '/api/ranks/1/claim');
    expect(gift.result.value).toBeLessThanOrEqual(RANKS[1]!.gift);
    expect(gift.result.value).toBeGreaterThan(0);
    expect((await call(U, 'POST', '/api/ranks/1/claim')).data.error).toBe('claimed');
    expect((await call(U, 'POST', '/api/ranks/2/claim')).data.error).toBe('rank_locked');
    expect((await ok(U, 'GET', '/api/ranks')).gifts[0].taken).toBe(true);
  });

  it('quests: the day\'s and week\'s set, progress from the game history, tickets once per period', { timeout: 30_000 }, async () => {
    const U = 3604;
    const F = 3605;
    await ok(U, 'GET', '/api/me');
    await ok(F, 'GET', '/api/me');
    // Pin today's and this week's quests (the server reads the stored set first).
    const now = Date.now();
    const day = `d${Math.floor((now + 3 * 3_600_000) / 86_400_000)}`;
    const week = `w${weekIndex(now)}`;
    const daily: Quest[] = [
      { id: 'd0', kind: 'daily', type: 'case_open', game: 'case', caseId: 'noobini', caseName: 'Нубини', target: 1, reward: 6, name: 'Открой «Нубини»', text: '', image: '' },
      { id: 'd1', kind: 'daily', type: 'plays', game: 'upgrade', minStake: 20, target: 1, reward: 6, name: 'Апгрейд', text: '', image: '' },
      { id: 'd2', kind: 'daily', type: 'turnover', game: 'mines', target: 100, reward: 15, name: 'Мины', text: '', image: '' },
    ];
    const weekly: Quest[] = [
      { id: 'w0', kind: 'weekly', type: 'case_open', game: 'case', caseId: 'toxic', caseName: 'Токсик', target: 3, reward: 62, name: 'Токсик', text: '', image: '' },
      { id: 'w1', kind: 'weekly', type: 'deposit', target: DEPOSIT_QUEST.target, reward: DEPOSIT_QUEST.reward, name: 'Деп', text: '', image: '' },
      { id: 'w2', kind: 'weekly', type: 'friend', target: 1, reward: FRIEND_QUEST_REWARD, name: 'Друг', text: '', image: '' },
      { id: 'w3', kind: 'weekly', type: 'days', target: 5, reward: 40, name: 'Дни', text: '', image: '' },
    ];
    for (const [key, set] of [[day, daily], [week, weekly]] as const) {
      await pool.query('INSERT INTO quest_sets (period, quests) VALUES ($1, $2::jsonb) ON CONFLICT (period) DO UPDATE SET quests = EXCLUDED.quests', [key, JSON.stringify(set)]);
    }
    const caseDrop = (user: number, caseId: string, stake: number) =>
      pool.query(`INSERT INTO drops (user_id, game, result, stake_value, payout_value, meta) VALUES ($1, 'case', 'win', $2, 0, $3)`, [user, stake, JSON.stringify({ caseId })]);
    const balance = async () => Number((await pool.query('SELECT balance FROM users WHERE id = $1', [U])).rows[0].balance);
    const before = await balance();
    let s = await ok(U, 'GET', '/api/quests');
    expect(s.tickets).toBe(0);
    expect(s.quests.map((q: Quest) => q.id)).toEqual(['d0', 'd1', 'd2', 'w0', 'w1', 'w2', 'w3']);
    expect((await call(U, 'POST', '/api/quests/d0/claim')).data.error).toBe('not_done');
    expect((await call(U, 'POST', '/api/quests/nope/claim')).status).toBe(404);
    expect((await call(U, 'POST', '/api/quests/d7/claim')).status).toBe(404);
    // Opening another case or a gift opening (no stake) doesn't count.
    await caseDrop(U, 'toxic', 69);
    await caseDrop(U, 'noobini', 0);
    s = await ok(U, 'GET', '/api/quests');
    expect(s.quests.find((q: Quest) => q.id === 'd0').progress).toBe(0);
    expect(s.quests.find((q: Quest) => q.id === 'w0').progress).toBe(1);
    await caseDrop(U, 'noobini', 19);
    const got = await ok(U, 'POST', '/api/quests/d0/claim');
    expect(got.result.reward).toBe(6);
    expect(got.result.tickets).toBe(6);
    expect(got.me.user.tickets).toBe(6);
    // Tickets, not coins.
    expect(await balance()).toBeCloseTo(before, 2);
    expect((await call(U, 'POST', '/api/quests/d0/claim')).data.error).toBe('claimed');
    expect(got.result.quests.find((q: Quest) => q.id === 'w3').progress).toBe(1);
    // «N games from S B»: a smaller stake doesn't count.
    await played(U, 'upgrade', 15);
    expect((await ok(U, 'GET', '/api/quests')).quests.find((q: Quest) => q.id === 'd1').progress).toBe(0);
    await played(U, 'upgrade', 25);
    expect((await ok(U, 'POST', '/api/quests/d1/claim')).result.tickets).toBe(12);
    // Turnover in the mines.
    await played(U, 'mines', 100);
    expect((await ok(U, 'POST', '/api/quests/d2/claim')).result.tickets).toBe(27);
    // Net deposits of the week.
    expect((await ok(U, 'GET', '/api/quests')).quests.find((q: Quest) => q.id === 'w1').progress).toBe(0);
    const coins = await payStars(U, 1000);
    expect(coins).toBeGreaterThanOrEqual(DEPOSIT_QUEST.target);
    expect((await ok(U, 'POST', '/api/quests/w1/claim')).result.tickets).toBe(27 + DEPOSIT_QUEST.reward);
    // A friend who played 300 B in cases and battles this week.
    await pool.query('UPDATE users SET referred_by = $2, referred_at = now() WHERE id = $1', [F, U]);
    await played(F, 'battle', 299);
    expect((await ok(U, 'GET', '/api/quests')).quests.find((q: Quest) => q.id === 'w2').progress).toBe(0);
    await played(F, 'case', 1);
    expect((await ok(U, 'GET', '/api/quests')).quests.find((q: Quest) => q.id === 'w2').progress).toBe(1);
    await ok(U, 'POST', '/api/quests/w2/claim');
    expect((await call(U, 'POST', '/api/quests/w2/claim')).data.error).toBe('claimed');
    expect((await ok(U, 'GET', '/api/quests')).tickets).toBe(27 + DEPOSIT_QUEST.reward + FRIEND_QUEST_REWARD);
  });

  it('partners get their own percent from an owner (5–15); sources mark new players and count them', { timeout: 30_000 }, async () => {
    const P = 3606;
    const FR = 3607;
    const AD = 3608;
    for (const u of [P, FR, AD]) await ok(u, 'GET', '/api/me');
    await pool.query('INSERT INTO admins (user_id, added_by) VALUES ($1, $2) ON CONFLICT DO NOTHING', [AD, OWNER]);
    expect((await call(AD, 'POST', `/api/admin/users/${P}/partner`, { percent: 15 })).status).toBe(403);
    expect((await call(OWNER, 'POST', `/api/admin/users/${P}/partner`, { percent: 20 })).data.error).toBe('invalid');
    await ok(OWNER, 'POST', `/api/admin/users/${P}/partner`, { percent: 15 });
    expect((await ok(P, 'GET', '/api/referrals')).percent).toBe(15);
    await pool.query('UPDATE users SET referred_by = $2, referred_at = now() WHERE id = $1', [FR, P]);
    const before = Number((await pool.query('SELECT ref_balance FROM users WHERE id = $1', [P])).rows[0].ref_balance);
    const credited = await payStars(FR, 200);
    const after = Number((await pool.query('SELECT ref_balance FROM users WHERE id = $1', [P])).rows[0].ref_balance);
    // 15 % of what was paid for (the promo bonus aside) — at least 15 % of 200 stars' worth.
    expect(after - before).toBeGreaterThan(0);
    expect(after - before).toBeLessThanOrEqual(credited * 0.15 + 0.01);

    expect((await call(AD, 'GET', '/api/admin/sources')).status).toBe(403);
    expect((await call(OWNER, 'POST', '/api/admin/sources', { tag: 'Bad Tag', title: 'x' })).data.error).toBe('invalid');
    await ok(OWNER, 'POST', '/api/admin/sources', { tag: 'tiktok_test', title: 'TikTok тест' });
    expect((await call(OWNER, 'POST', '/api/admin/sources', { tag: 'tiktok_test', title: 'again' })).data.error).toBe('taken');
    const NEW = 3609;
    await hook({ update_id: 9201, message: { message_id: 9201, from: { id: NEW, first_name: 'new' }, chat: { id: NEW, type: 'private' }, text: '/start s-tiktok_test' } });
    // An old player following the link counts as a click, not as the source's player.
    await pool.query(`UPDATE users SET created_at = now() - interval '1 day' WHERE id = $1`, [FR]);
    await hook({ update_id: 9202, message: { message_id: 9202, from: { id: FR, first_name: 'fr' }, chat: { id: FR, type: 'private' }, text: '/start s-tiktok_test' } });
    expect((await pool.query('SELECT source FROM users WHERE id = $1', [NEW])).rows[0].source).toBe('tiktok_test');
    expect((await pool.query('SELECT source FROM users WHERE id = $1', [FR])).rows[0].source).toBeNull();
    const list = await ok(OWNER, 'GET', '/api/admin/sources');
    expect(list.find((x: { tag: string }) => x.tag === 'tiktok_test')).toMatchObject({ clicks: 2, players: 1, link: 'https://t.me/braincrashbot?start=s-tiktok_test' });
  });

  it('economy: owners only; deposits, withdrawals, bonuses and what players hold', async () => {
    const AD = 3608;
    expect((await call(AD, 'GET', '/api/admin/economy')).status).toBe(403);
    const before = await ok(OWNER, 'GET', '/api/admin/economy');
    // What admins hand out by hand to players is a cost too: coins at face value, brainrots at catalog prices.
    const FR = 3607;
    await ok(OWNER, 'POST', '/api/admin/give', { user: String(FR), type: 'coins', amount: 50 });
    await ok(OWNER, 'POST', '/api/admin/give', { user: String(FR), type: 'brainrot', brainrotId: 'garama-and-madundung', amount: 2 });
    // …to staff (tests) it isn't.
    await ok(OWNER, 'POST', '/api/admin/give', { user: String(AD), type: 'coins', amount: 70 });
    const price = Number((await pool.query(`SELECT price FROM brainrots WHERE id = 'garama-and-madundung'`)).rows[0].price);
    const e = await ok(OWNER, 'GET', '/api/admin/economy');
    expect(e.all.bonuses.admin).toBeCloseTo(before.all.bonuses.admin + 50 + 2 * price, 2);
    for (const k of ['week', 'month', 'all']) expect(e[k]).toMatchObject({ deposits: expect.any(Number), withdrawals: expect.any(Number), bonusTotal: expect.any(Number) });
    // Quests pay tickets now: counted apart from coins.
    expect(e.all.tickets).toBeGreaterThanOrEqual(6);
    expect(e.all.bonuses.rankGifts).toBeGreaterThan(0);
    expect(e.result).toBeCloseTo(e.all.deposits - e.all.withdrawals - e.holdingsTotal, 2);
  });

  it('share a win: only a fresh win, a prepared message with the referral link', async () => {
    const U = 3610;
    await ok(U, 'GET', '/api/me');
    expect((await call(U, 'POST', '/api/share/win')).data.error).toBe('no_win');
    await pool.query(`INSERT INTO drops (user_id, game, result, stake_value, brainrot_id, payout_value) VALUES ($1, 'case', 'win', 10, 'garama-and-madundung', 45)`, [U]);
    botCalls.length = 0;
    const r = await ok(U, 'POST', '/api/share/win');
    expect(r.preparedId).toMatch(/^prep-/);
    const sent = botCalls.find((c) => c.method === 'savePreparedInlineMessage')!;
    expect(String((sent.params.result as { photo_url: string }).photo_url)).toMatch(/\/share\/brainrots\/garama-and-madundung\.jpg$/);
    expect(JSON.stringify(sent.params.result)).toContain('start=r-');
  });
});

describe('iteration 32: tickets, ticket cases, the Meowl tour', () => {
  it('ticket cases: in «Бесплатные», opened for tickets only, one at a time; zero-chance items are hidden from players', { timeout: 30_000 }, async () => {
    const U = 3701;
    await ok(U, 'GET', '/api/me');
    const cat = await ok(U, 'GET', '/api/catalog');
    const eclipse = cat.cases.find((c: { id: string }) => c.id === 'eclipse');
    const candy = cat.cases.find((c: { id: string }) => c.id === 'candy');
    expect(eclipse).toMatchObject({ kind: 'tickets', ticketPrice: 119, price: 0 });
    expect(candy).toMatchObject({ kind: 'tickets', ticketPrice: 240, price: 0 });
    const section = cat.sections.find((x: { id: number }) => x.id === eclipse.sectionId);
    expect(section.title).toBe('Бесплатные');
    // The real table (admins): chances set by hand, summing to 1, plus three «Невозможно» items players never see.
    const admin = await ok(OWNER, 'GET', '/api/admin/cases');
    for (const id of ['eclipse', 'candy']) {
      const table = admin.find((c: { id: string }) => c.id === id).items as { brainrotId: string; weight: number; fixed: number | null }[];
      expect(table.every((i) => i.fixed !== null)).toBe(true);
      expect(table.filter((i) => i.fixed === 0)).toHaveLength(3);
      expect(table.reduce((sum, i) => sum + i.weight, 0)).toBeCloseTo(1, 6);
      const shown = cat.cases.find((c: { id: string }) => c.id === id).items as { brainrotId: string }[];
      expect(shown).toHaveLength(table.length - 3);
      for (const z of table.filter((i) => i.fixed === 0)) expect(shown.some((i) => i.brainrotId === z.brainrotId)).toBe(false);
    }
    expect(admin.find((c: { id: string }) => c.id === 'eclipse').items.find((i: { brainrotId: string }) => i.brainrotId === 'coins-10').fixed).toBeCloseTo(0.68, 6);
    // No tickets — no case; coins don't help.
    const r = await call(U, 'POST', '/api/case/open', { caseId: 'eclipse' });
    expect(r.data.error).toBe('no_tickets');
    expect(r.data.message).toMatch(/119/);
    expect((await call(U, 'POST', '/api/case/open', { caseId: 'eclipse', count: 3 })).data.error).toBe('invalid');
    await pool.query('UPDATE users SET tickets = 130 WHERE id = $1', [U]);
    const balance = Number((await pool.query('SELECT balance FROM users WHERE id = $1', [U])).rows[0].balance);
    const opened = await ok(U, 'POST', '/api/case/open', { caseId: 'eclipse' });
    expect(opened.me.user.tickets).toBe(11);
    const drop = (await pool.query(`SELECT stake_value, meta, brainrot_id FROM drops WHERE user_id = $1 ORDER BY id DESC LIMIT 1`, [U])).rows[0];
    expect(Number(drop.stake_value)).toBe(0);
    expect(drop.meta.tickets).toBe(119);
    const won = cat.brainrots.find((b: { id: string }) => b.id === drop.brainrot_id);
    // Coins drop straight onto the balance, brainrots into the inventory; never one of the «Невозможно» ones.
    expect(won.price).toBeLessThanOrEqual(80);
    const after = Number((await pool.query('SELECT balance FROM users WHERE id = $1', [U])).rows[0].balance);
    expect(after).toBeCloseTo(balance + (won.kind === 'coins' ? won.price : 0), 2);
    expect((await call(U, 'POST', '/api/case/open', { caseId: 'eclipse' })).data.error).toBe('no_tickets');
    expect((await call(U, 'POST', '/api/case/open', { caseId: 'candy' })).data.message).toMatch(/229/);
    // Not in battles.
    expect((await call(U, 'POST', '/api/battles', { caseId: 'candy' })).status).toBe(400);
  });

  it('the Meowl tour: a new player starts it once; done or skipped, it never starts by itself again', async () => {
    const U = 3702;
    expect((await ok(U, 'GET', '/api/me')).user.onboarded).toBe(false);
    const done = await ok(U, 'POST', '/api/onboarding');
    expect(done.me.user.onboarded).toBe(true);
    expect((await ok(U, 'GET', '/api/me')).user.onboarded).toBe(true);
    await ok(U, 'POST', '/api/onboarding');
  });

  it('ranks are easier: 500 B deposited is «Редкий», its gift opens after 2× the threshold played', () => {
    expect(RANKS.map((r) => r.from)).toEqual([0, 500, 2_500, 10_000, 25_000, 75_000, 250_000]);
    expect(RANK_GIFT_TURNOVER).toBe(2);
    // Never in the red: a gift stays a small share of what the required turnover leaves the house (12 %).
    for (const r of RANKS.slice(1)) expect(r.gift).toBeLessThan(r.from * RANK_GIFT_TURNOVER * 0.12 * 0.15);
  });
});

describe('iteration 33: anti-spam, case configs, staff are not players, search, titles', () => {
  it('anti-spam: more than 8 actions a second → «Не спамь», reads are never limited', async () => {
    const U = 3801;
    await ok(U, 'GET', '/api/me');
    process.env.RATE_LIMIT = 'on';
    // One frozen second: the requests themselves take longer than that in the test database.
    const now = vi.spyOn(Date, 'now').mockReturnValue(Date.now());
    try {
      for (let i = 0; i < 8; i++) expect((await call(U, 'POST', '/api/onboarding')).status).toBe(200);
      const r = await call(U, 'POST', '/api/onboarding');
      expect(r.status).toBe(429);
      expect(r.data.error).toBe('too_fast');
      expect(r.data.message).toMatch(/Не спамь/);
      // Reads go through.
      for (let i = 0; i < 12; i++) expect((await call(U, 'GET', '/api/me')).status).toBe(200);
      // Another player isn't affected.
      expect((await call(3802, 'POST', '/api/onboarding')).status).toBe(200);
    } finally {
      now.mockRestore();
      process.env.RATE_LIMIT = 'off';
    }
  });

  it('case configs: save everything, change things, load it back (with an automatic copy first), delete', { timeout: 30_000 }, async () => {
    expect((await call(3803, 'GET', '/api/admin/case-configs')).status).toBe(403);
    const saved = await ok(OWNER, 'POST', '/api/admin/case-configs', { name: 'Базовый' });
    const base = saved.configs.find((c: { id: number }) => c.id === saved.id);
    expect(base).toMatchObject({ name: 'Базовый', auto: false });
    expect(base.cases).toBeGreaterThan(5);
    expect(base.items).toBeGreaterThan(10);
    const before = (await pool.query(`SELECT price FROM cases WHERE id = 'toxic'`)).rows[0].price;
    const item = (await pool.query(`SELECT brainrot_id FROM case_items WHERE case_id = 'toxic' ORDER BY brainrot_id LIMIT 1`)).rows[0].brainrot_id;
    const brainrot = (await pool.query(`SELECT id, price FROM brainrots WHERE kind = 'brainrot' AND status = 'active' ORDER BY id LIMIT 1`)).rows[0];
    // Change the price, a chance, the catalog, and add a case.
    await pool.query(`UPDATE cases SET price = 999 WHERE id = 'toxic'`);
    await pool.query(`UPDATE case_items SET fixed_chance = 0.5 WHERE case_id = 'toxic' AND brainrot_id = $1`, [item]);
    await pool.query(`UPDATE brainrots SET price = price + 7 WHERE id = $1`, [brainrot.id]);
    await pool.query(`INSERT INTO cases (id, name, price, image, kind, status, sort) VALUES ('tmp-case', 'Временный', 10, '/cases/free.svg', 'paid', 'active', 999)`);
    // Load without the brainrot prices.
    const loaded = await ok(OWNER, 'POST', `/api/admin/case-configs/${saved.id}/load`, {});
    expect(loaded.result ?? loaded).toBeTruthy();
    const r = loaded.result ?? loaded;
    expect(r.hidden).toBe(1);
    expect(r.skipped).toBe(0);
    expect(r.prices).toBe(0);
    expect(Number((await pool.query(`SELECT price FROM cases WHERE id = 'toxic'`)).rows[0].price)).toBe(Number(before));
    expect((await pool.query(`SELECT fixed_chance FROM case_items WHERE case_id = 'toxic' AND brainrot_id = $1`, [item])).rows[0].fixed_chance).toBeNull();
    expect((await pool.query(`SELECT status FROM cases WHERE id = 'tmp-case'`)).rows[0].status).toBe('hidden');
    expect(Number((await pool.query('SELECT price FROM brainrots WHERE id = $1', [brainrot.id])).rows[0].price)).toBe(Number(brainrot.price) + 7);
    // The automatic copy holds what was replaced: loading it brings the changes back.
    const backup = r.configs.find((c: { id: number }) => c.id === r.backup);
    expect(backup.auto).toBe(true);
    expect(backup.name).toMatch(/Автокопия перед «Базовый»/);
    await ok(OWNER, 'POST', `/api/admin/case-configs/${r.backup}/load`, {});
    expect(Number((await pool.query(`SELECT price FROM cases WHERE id = 'toxic'`)).rows[0].price)).toBe(999);
    // Load again, now with the brainrot prices.
    const withPrices = await ok(OWNER, 'POST', `/api/admin/case-configs/${saved.id}/load`, { prices: true });
    expect((withPrices.result ?? withPrices).prices).toBeGreaterThanOrEqual(1);
    expect(Number((await pool.query('SELECT price FROM brainrots WHERE id = $1', [brainrot.id])).rows[0].price)).toBe(Number(brainrot.price));
    expect((await ok(OWNER, 'GET', '/api/admin/logs')).some((l: { action: string }) => l.action === 'case_config_load')).toBe(true);
    const del = await ok(OWNER, 'DELETE', `/api/admin/case-configs/${saved.id}`);
    expect((del.result ?? del).configs.some((c: { id: number }) => c.id === saved.id)).toBe(false);
    expect((await call(OWNER, 'POST', `/api/admin/case-configs/${saved.id}/load`, {})).status).toBe(404);
    await pool.query(`DELETE FROM cases WHERE id = 'tmp-case'`);
  });

  it('staff are not players: their drops stay out of LIVE and the top drop, they are not found, not counted', { timeout: 30_000 }, async () => {
    const U = 3804;
    await ok(U, 'GET', '/api/me');
    await ok(OWNER, 'POST', '/api/admin/give', { user: String(U), type: 'coins', amount: 500 });
    await ok(OWNER, 'POST', '/api/admin/give', { user: String(OWNER), type: 'coins', amount: 500 });
    const ownerId = (await ok(OWNER, 'GET', '/api/me')).user.publicId;
    const userId = (await ok(U, 'GET', '/api/me')).user.publicId;
    // An earlier test left noobini at 25 B, below everything in the catalog now: give it a price it can be built for.
    await pool.query(`UPDATE cases SET price = 150 WHERE id = 'noobini'`);
    await healCases({ caseId: 'noobini' });
    await ok(OWNER, 'POST', '/api/case/open', { caseId: 'noobini' });
    await ok(U, 'POST', '/api/case/open', { caseId: 'noobini' });
    const live = (await ok(U, 'GET', '/api/drops/live')) as { player: { publicId: string } }[];
    expect(live.some((d) => d.player.publicId === userId)).toBe(true);
    expect(live.some((d) => d.player.publicId === ownerId)).toBe(false);
    // An admin's huge drop never becomes the top drop.
    const top = (await pool.query(`SELECT id FROM brainrots WHERE kind = 'brainrot' ORDER BY price DESC LIMIT 1`)).rows[0].id;
    await pool.query(`INSERT INTO drops (user_id, game, result, stake_value, brainrot_id, payout_value) VALUES ($1, 'case', 'win', 10, $2, 0)`, [OWNER, top]);
    const cat = await ok(U, 'GET', '/api/catalog');
    expect(cat.topDrop?.playerId).not.toBe(ownerId);
    // Not in the player counts.
    const users = Number((await pool.query('SELECT count(*) AS n FROM users')).rows[0].n);
    const staff = Number((await pool.query(`SELECT count(*) AS n FROM users u WHERE u.id IN (SELECT user_id FROM admins) OR u.id = ANY($1::bigint[])`, [[OWNER, OWNER2]])).rows[0].n);
    expect((await ok(OWNER, 'GET', '/api/admin/stats')).users).toBe(users - staff);
  });

  it('player search: by name, profile ID or exact @username; never shows the username; no staff', async () => {
    const U = 3805;
    await ok(U, 'GET', '/api/me');
    const id = (await ok(U, 'GET', '/api/me')).user.publicId;
    const byName = await ok(3806, 'GET', '/api/players/search?q=u380');
    expect(byName.some((p: { publicId: string }) => p.publicId === id)).toBe(true);
    expect(byName[0]).not.toHaveProperty('username');
    expect((await ok(3806, 'GET', `/api/players/search?q=${id.toLowerCase()}`))[0].publicId).toBe(id);
    expect((await ok(3806, 'GET', '/api/players/search?q=%40u3805'))[0].publicId).toBe(id);
    expect(await ok(3806, 'GET', '/api/players/search?q=owner')).toEqual([]);
    expect(await ok(3806, 'GET', '/api/players/search?q=a')).toEqual([]);
    // «%» is a letter here, not a wildcard.
    expect(await ok(3806, 'GET', '/api/players/search?q=%25%25')).toEqual([]);
  });

  it('titles: the card says which share of players holds the title', async () => {
    const U = 3807;
    await ok(U, 'GET', '/api/me');
    const t = await ok(OWNER, 'POST', '/api/admin/titles', { name: 'Редкий гость', description: 'Тест', icon: '/brainrots/meowl.webp', color: '#22ccff' });
    await ok(OWNER, 'POST', `/api/admin/titles/${t.id}/grant`, { user: String(U) });
    const title = (await ok(U, 'GET', '/api/me')).user.titles.find((x: { id: number }) => x.id === t.id);
    const users = Number((await pool.query('SELECT count(*) AS n FROM users')).rows[0].n);
    expect(title.holders).toBe(1);
    expect(title.percent).toBeCloseTo(Math.round((1000 / users)) / 10, 1);
  });
});


describe('iteration 35: fresh profile, safe openings, partner codes, x4/x8 luck, badges, floating prices, giveaway brainrots', () => {
  let n = 0;
  const payStars = async (user: number, stars: number, promo?: string) => {
    const inv = await ok(user, 'POST', '/api/stars/invoice', { stars, promo });
    n++;
    await hook({
      update_id: 9500 + n,
      message: {
        message_id: 9500 + n,
        from: { id: user, first_name: `u${user}` },
        chat: { id: user, type: 'private' },
        successful_payment: { currency: 'XTR', total_amount: stars, invoice_payload: `stars:${inv.orderId}`, telegram_payment_charge_id: `it35-${n}`, provider_payment_charge_id: '' },
      },
    });
    return inv as { coins: number; bonus: number; percent: number; partner: string | null };
  };

  it('every profile carries the time the database read it, so the app keeps the newest', async () => {
    const U = 3901;
    const a = (await ok(U, 'GET', '/api/me')).rev as number;
    const b = (await ok(U, 'GET', '/api/me')).rev as number;
    expect(a).toBeGreaterThan(1_700_000_000_000);
    expect(b).toBeGreaterThan(a);
  });

  it('an opening with a request id happens once; the app can look it up; a moved price is refused', async () => {
    const U = 3902;
    await ok(U, 'GET', '/api/me');
    await ok(OWNER, 'POST', '/api/admin/give', { user: String(U), type: 'coins', amount: 1000 });
    const kase = (await ok(U, 'GET', '/api/catalog')).cases.find((c: { kind: string; price: number }) => c.kind === 'paid' && c.price > 0 && c.price < 300);
    const before = (await ok(U, 'GET', '/api/me')).user.balance;
    expect((await call(U, 'POST', '/api/case/open', { caseId: kase.id, expectedPrice: kase.price + 1 })).data.error).toBe('price_changed');
    expect((await ok(U, 'GET', '/api/me')).user.balance).toBe(before);
    const requestId = 'req-it35-0001';
    const first = await ok(U, 'POST', '/api/case/open', { caseId: kase.id, requestId, expectedPrice: kase.price });
    const again = await ok(U, 'POST', '/api/case/open', { caseId: kase.id, requestId, expectedPrice: kase.price });
    expect(again.result).toEqual(first.result);
    expect(again.me.user.balance).toBeCloseTo(before - kase.price, 2);
    const looked = await ok(U, 'GET', `/api/case/opened/${requestId}`);
    expect(looked.result).toEqual(first.result);
    expect((await call(U, 'GET', '/api/case/opened/req-never-made')).status).toBe(404);
    // Someone else's id finds nothing.
    expect((await call(3903, 'GET', `/api/case/opened/${requestId}`)).status).toBe(404);
  });

  it('a partner code at a Stars deposit: +15 %, binds a player without a partner, the partner gets the usual share', { timeout: 30_000 }, async () => {
    const P = 3910;
    const F = 3911;
    const OTHER = 3912;
    const BOUND = 3913;
    for (const u of [P, F, OTHER, BOUND]) await ok(u, 'GET', '/api/me');
    const code = (await ok(P, 'GET', '/api/referrals')).code as string;
    const otherCode = (await ok(OTHER, 'GET', '/api/referrals')).code as string;
    expect(await ok(F, 'GET', `/api/deposit-promo?via=stars&code=${code.toLowerCase()}`)).toMatchObject({ kind: 'partner', percent: 15 });
    expect((await call(F, 'GET', `/api/deposit-promo?via=brainrots&code=${code}`)).data.error).toBe('promo_invalid');
    expect((await call(P, 'GET', `/api/deposit-promo?via=stars&code=${code}`)).data.error).toBe('promo_self');
    expect((await call(F, 'GET', '/api/deposit-promo?via=stars&code=NOSUCHCODE1')).data.error).toBe('promo_invalid');
    // A brainrot deposit refuses it (the bonus would pay for depositing and withdrawing again).
    expect((await call(F, 'POST', '/api/item-deposits', { items: [{ brainrotId: 'garama-and-madundung', count: 1 }], robloxNick: 'Friend_Nick', promo: code })).data.error).toBe('promo_invalid');
    const refBefore = Number((await pool.query('SELECT ref_balance FROM users WHERE id = $1', [P])).rows[0].ref_balance);
    const balBefore = (await ok(F, 'GET', '/api/me')).user.balance as number;
    const inv = await payStars(F, 100, code);
    expect(inv.percent).toBe(15);
    // Whole coins, rounded down (as the auto promo's bonus).
    expect(inv.bonus).toBe(Math.floor((inv.coins * 15) / 100));
    expect(Number((await pool.query('SELECT referred_by FROM users WHERE id = $1', [F])).rows[0].referred_by)).toBe(P);
    expect((await ok(F, 'GET', '/api/me')).user.balance).toBeCloseTo(balBefore + inv.coins + inv.bonus, 2);
    // The partner's share is of what was paid for, not of the bonus.
    const refAfter = Number((await pool.query('SELECT ref_balance FROM users WHERE id = $1', [P])).rows[0].ref_balance);
    expect(refAfter - refBefore).toBeGreaterThan(0);
    expect(refAfter - refBefore).toBeLessThanOrEqual(inv.coins * 0.15 + 0.01);
    // Bound to someone else: only that partner's code gives the bonus.
    await pool.query('UPDATE users SET referred_by = $2, referred_at = now() WHERE id = $1', [BOUND, OTHER]);
    const other = await call(BOUND, 'POST', '/api/stars/invoice', { stars: 100, promo: code });
    expect(other.data.error).toBe('promo_other_partner');
    expect(other.data.message).toContain(otherCode);
    expect((await payStars(BOUND, 100, otherCode)).percent).toBe(15);
  });

  it('x4 and x8 luck are switched like x2; the strongest running one counts', async () => {
    const U = 3920;
    // From a clean slate (an earlier «Щелчок» test may have left luck on).
    for (const x of [2, 4, 8]) await ok(OWNER, 'POST', '/api/admin/settings', { luck: { minutes: 0, x } });
    await ok(OWNER, 'POST', '/api/admin/settings', { luck: { minutes: 10, x: 4, notify: false } });
    expect((await ok(U, 'GET', '/api/me')).luck).toMatchObject({ x: 4 });
    await ok(OWNER, 'POST', '/api/admin/settings', { luck: { minutes: 10, x: 8, notify: false } });
    expect((await ok(U, 'GET', '/api/me')).luck).toMatchObject({ x: 8 });
    const events = (await ok(U, 'GET', '/api/catalog')).events;
    expect(events.luck4).toBeGreaterThan(Date.now());
    expect(events.luck8).toBeGreaterThan(Date.now());
    await ok(OWNER, 'POST', '/api/admin/settings', { luck: { minutes: 0, x: 8 } });
    await ok(OWNER, 'POST', '/api/admin/settings', { luck: { minutes: 0, x: 4 } });
    expect((await ok(U, 'GET', '/api/me')).luck).toBeNull();
    expect((await call(OWNER, 'POST', '/api/admin/settings', { luck: { minutes: 10, x: 3 } })).data.error).toBe('invalid');
  });

  it('a new case wears «НОВЫЙ», a new picture makes «РЕДИЗАЙН», the admin can pick or clear it', async () => {
    const items = (await ok(OWNER, 'GET', '/api/admin/brainrots')).filter((b: { kind?: string; status: string }) => b.status === 'active' && b.kind !== 'coins').slice(0, 3);
    const made = await ok(OWNER, 'POST', '/api/admin/cases', {
      name: 'Лента тест',
      price: 50,
      image: '/cases/noobini.webp',
      items: items.map((b: { id: string }) => ({ brainrotId: b.id })),
    });
    const badgeOf = async () => (await ok(ALICE, 'GET', '/api/catalog')).cases.find((c: { id: string }) => c.id === made.id)?.badge;
    expect(await badgeOf()).toBe('new');
    await ok(OWNER, 'PATCH', `/api/admin/cases/${made.id}`, { image: '/cases/toxic.webp' });
    expect(await badgeOf()).toBe('new'); // still fresh
    await ok(OWNER, 'PATCH', `/api/admin/cases/${made.id}`, { badge: 'none' });
    expect(await badgeOf()).toBeNull();
    await ok(OWNER, 'PATCH', `/api/admin/cases/${made.id}`, { image: '/cases/noobini.webp' });
    expect(await badgeOf()).toBe('redesign');
    await ok(OWNER, 'DELETE', `/api/admin/cases/${made.id}`);
  });

  it('a floating price moves within its cycle, keeps a history, is composed for every price and stays out of battles', { timeout: 30_000 }, async () => {
    const { rotateFloatingPrices } = await import('./floatingPrice');
    const cycle = [99, 799, 5000];
    await ok(OWNER, 'PATCH', '/api/admin/cases/noobini', { priceCycle: cycle });
    const at = async () => (await ok(ALICE, 'GET', '/api/catalog')).cases.find((c: { id: string }) => c.id === 'noobini');
    const start = await at();
    expect(start.priceCycle).toEqual(cycle);
    expect(cycle).toContain(start.price);
    await pool.query(`UPDATE cases SET price_next_at = now() - interval '1 second' WHERE id = 'noobini'`);
    const moved = await rotateFloatingPrices();
    expect(moved.find((m) => m.id === 'noobini')?.price).not.toBe(start.price);
    const after = await at();
    expect(cycle).toContain(after.price);
    expect(after.priceHistory.at(-1)).toBe(after.price);
    // Not due again yet.
    expect((await rotateFloatingPrices()).some((m) => m.id === 'noobini')).toBe(false);
    // Composed for all of its prices: something under 99 and something worth more than 5000.
    await healCases({ caseId: 'noobini' });
    const prices = (await pool.query(`SELECT b.price FROM case_items ci JOIN brainrots b ON b.id = ci.brainrot_id WHERE ci.case_id = 'noobini'`)).rows.map((r) => Number(r.price));
    expect(Math.min(...prices)).toBeLessThan(99);
    expect(Math.max(...prices)).toBeGreaterThan(5000);
    await ok(OWNER, 'POST', '/api/admin/give', { user: String(ALICE), type: 'coins', amount: 6000 });
    expect((await call(ALICE, 'POST', '/api/battles', { caseId: 'noobini' })).data.error).toBe('floating_price');
    await ok(OWNER, 'PATCH', '/api/admin/cases/noobini', { priceCycle: null, price: 150 });
    expect((await at()).priceCycle).toBeNull();
  });

  it('a draw can ask for a brainrot deposit of a given brainrot in its period', async () => {
    const U = 3930;
    await ok(U, 'GET', '/api/me');
    const prize = (await ok(OWNER, 'GET', '/api/admin/brainrots')).find((b: { kind?: string; status: string }) => b.status === 'active' && b.kind !== 'coins').id;
    const asked = (await pool.query('SELECT brainrot_id FROM deposit_items LIMIT 1')).rows[0].brainrot_id as string;
    expect((await call(OWNER, 'POST', '/api/admin/giveaways', {
      kind: 'draw', title: 'Неверный', endsAt: Date.now() + 3600_000, prizes: [prize], needBrainrot: 'no-such-brainrot',
    })).data.error).toBe('invalid');
    const g = await ok(OWNER, 'POST', '/api/admin/giveaways', {
      kind: 'draw', title: 'Внеси брейнрота', endsAt: Date.now() + 3600_000, prizes: [prize], needBrainrot: asked, needBrainrotCount: 2,
    });
    const gid = g.id ?? g.result?.id;
    expect((await call(U, 'POST', `/api/giveaways/${gid}/join`)).data).toMatchObject({ error: 'need_brainrot', have: 0, want: 2 });
    await pool.query(
      `INSERT INTO item_deposits (user_id, items, value, roblox_nick, status, credited, created_at, updated_at)
       VALUES ($1, $2::jsonb, 10, 'Test_Nick', 'credited', 10, now(), now())`,
      [U, JSON.stringify([{ brainrotId: asked, name: 'x', count: 2, price: 5 }])],
    );
    expect((await ok(U, 'GET', `/api/giveaways/${gid}`)).needBrainrot).toMatchObject({ brainrotId: asked, count: 2, have: 2, paid: 0 });
    await ok(U, 'POST', `/api/giveaways/${gid}/join`);
    // Iteration 39: a Stars / crypto deposit worth the brainrots meets the condition too.
    const V = 3931;
    await ok(V, 'GET', '/api/me');
    const price = Number((await pool.query('SELECT coalesce(di.price, b.price) AS p FROM brainrots b LEFT JOIN deposit_items di ON di.brainrot_id = b.id WHERE b.id = $1', [asked])).rows[0].p);
    const need = (await call(V, 'POST', `/api/giveaways/${gid}/join`)).data;
    expect(need).toMatchObject({ error: 'need_brainrot', have: 0, paid: 0, paidNeed: price * 2 });
    await pool.query(`INSERT INTO star_payments (charge_id, order_id, user_id, stars, credited) VALUES ('crypto:gw-1', NULL, $1, 0, $2)`, [V, price * 2 - 1]);
    expect((await call(V, 'POST', `/api/giveaways/${gid}/join`)).data.error).toBe('need_brainrot');
    await pool.query(`INSERT INTO star_payments (charge_id, order_id, user_id, stars, credited) VALUES ('crypto:gw-2', NULL, $1, 0, 1)`, [V]);
    expect((await ok(V, 'GET', `/api/giveaways/${gid}`)).needBrainrot).toMatchObject({ have: 0, paid: price * 2, paidNeed: price * 2 });
    await ok(V, 'POST', `/api/giveaways/${gid}/join`);
    await ok(OWNER, 'POST', `/api/admin/giveaways/${gid}/cancel`);
  });

  it('iteration 39: a deposit race counts Stars and crypto, with a brainrot asked too', async () => {
    const W = 3932;
    await ok(W, 'GET', '/api/me');
    const prize = (await ok(OWNER, 'GET', '/api/admin/brainrots')).find((b: { kind?: string; status: string }) => b.status === 'active' && b.kind !== 'coins').id;
    const asked = (await pool.query('SELECT brainrot_id FROM deposit_items LIMIT 1')).rows[0].brainrot_id as string;
    const g = await ok(OWNER, 'POST', '/api/admin/giveaways', {
      kind: 'deposit_race', title: 'Гонка', endsAt: Date.now() + 3600_000, prizes: [prize], needBrainrot: asked, needBrainrotCount: 1,
    });
    const gid = g.id ?? g.result?.id;
    await pool.query(`INSERT INTO star_payments (charge_id, order_id, user_id, stars, credited) VALUES ('crypto:race-1', NULL, $1, 0, 1000000)`, [W]);
    const d = await ok(W, 'GET', `/api/giveaways/${gid}`);
    expect(d.me.place).not.toBeNull();
    expect(d.me.score).toBe(1000000);
    await ok(OWNER, 'POST', `/api/admin/giveaways/${gid}/cancel`);
  });
});

describe('iteration 35: demo grants («Для демо»)', () => {
  let n = 0;
  const payStars = async (user: number, stars: number) => {
    const inv = await ok(user, 'POST', '/api/stars/invoice', { stars });
    n++;
    await hook({
      update_id: 9600 + n,
      message: {
        message_id: 9600 + n,
        from: { id: user, first_name: `u${user}` },
        chat: { id: user, type: 'private' },
        successful_payment: { currency: 'XTR', total_amount: stars, invoice_payload: `stars:${inv.orderId}`, telegram_payment_charge_id: `demo-${n}`, provider_payment_charge_id: '' },
      },
    });
    return inv as { coins: number };
  };
  const cheapCase = async (U: number) =>
    (await ok(U, 'GET', '/api/catalog')).cases.find((c: { kind: string; price: number; bonus: string | null }) => c.kind === 'paid' && !c.bonus && c.price > 0 && c.price < 300) as {
      id: string;
      price: number;
    };

  it('demo coins are spent first, make the drops demo and stay out of LIVE', async () => {
    const U = 3950;
    await ok(U, 'GET', '/api/me');
    await ok(OWNER, 'POST', '/api/admin/give', { user: String(U), type: 'coins', amount: 1000, demo: true });
    const me = await ok(U, 'GET', '/api/me');
    expect(me.user.balance).toBe(1000);
    expect(me.user.demoBalance).toBe(1000);
    const kase = await cheapCase(U);
    const r = await ok(U, 'POST', '/api/case/open', { caseId: kase.id, requestId: 'demo-open-0001', expectedPrice: kase.price });
    expect(r.result.demo).toBe(true);
    expect(r.me.user.demoBalance).toBeCloseTo(1000 - kase.price, 2);
    expect((await pool.query('SELECT demo FROM drops WHERE user_id = $1 ORDER BY id DESC LIMIT 1', [U])).rows[0].demo).toBe(true);
    if (r.result.itemId) expect(r.me.inventory.find((i: { id: number }) => i.id === r.result.itemId).demo).toBe(true);
    expect((await ok(U, 'GET', '/api/history'))[0].demo).toBe(true);
    const live = await ok(U, 'GET', '/api/drops/live');
    expect(JSON.stringify(live)).not.toContain(me.user.publicId);
  });

  it('a demo brainrot never leaves: no withdrawal, no exchange, no mixed stakes; its wins and sales are demo', async () => {
    const U = 3951;
    await ok(U, 'GET', '/api/me');
    await ok(OWNER, 'POST', '/api/admin/give', { user: String(U), type: 'brainrot', brainrotId: 'garama-and-madundung', amount: 3, demo: true });
    await ok(OWNER, 'POST', '/api/admin/give', { user: String(U), type: 'brainrot', brainrotId: 'garama-and-madundung', amount: 1, demo: false });
    const inv = (await ok(U, 'GET', '/api/me')).inventory as { id: number; demo: boolean }[];
    const demo = inv.filter((i) => i.demo).map((i) => i.id);
    const real = inv.filter((i) => !i.demo).map((i) => i.id);
    expect(demo).toHaveLength(3);
    expect(real).toHaveLength(1);
    const w = await call(U, 'POST', '/api/withdrawals', { itemIds: demo.slice(0, 2), robloxNick: 'Demo_Nick' });
    expect(w.data.error).toBe('not_withdrawable');
    expect(w.data.message).toContain('демо');
    expect((await call(U, 'POST', '/api/withdrawals/exchange', { itemIds: [demo[0]], take: [{ brainrotId: 'garama-and-madundung', count: 1 }] })).data.error).toBe('demo_item');
    // Still all there: the refusals rolled back.
    expect((await ok(U, 'GET', '/api/me')).inventory).toHaveLength(4);
    expect((await call(U, 'POST', '/api/upgrade', { itemIds: [demo[0], real[0]], targetId: 'capitano-moby' })).data.error).toBe('mixed_demo');
    fixRandom(0.1);
    const up = await ok(U, 'POST', '/api/upgrade', { itemIds: [demo[0]], targetId: 'jolly-jolly-sahur' });
    vi.restoreAllMocks();
    expect(up.result.win).toBe(true);
    expect(up.me.inventory.find((i: { id: number }) => i.id === up.result.itemId).demo).toBe(true);
    const before = (await ok(U, 'GET', '/api/me')).user;
    const sold = await ok(U, 'POST', '/api/inventory/sell', { itemIds: [demo[1]] });
    expect(sold.me.user.demoBalance).toBeCloseTo(before.demoBalance + sold.result.coins, 2);
    expect(sold.me.user.balance).toBeCloseTo(before.balance + sold.result.coins, 2);
  });

  it('battles and own promo codes take only the player’s own coins', async () => {
    const U = 3952;
    await ok(U, 'GET', '/api/me');
    await ok(OWNER, 'POST', '/api/admin/give', { user: String(U), type: 'coins', amount: 5000, demo: true });
    const kase = await cheapCase(U);
    const b = await call(U, 'POST', '/api/battles', { caseId: kase.id });
    expect(b.data.error).toBe('demo_coins');
    const paid = await payStars(U, 100);
    const me = (await ok(U, 'GET', '/api/me')).user;
    expect(me.balance).toBeCloseTo(5000 + paid.coins, 2);
    expect(me.demoBalance).toBe(5000);
    // More than the own coins (the demo ones would cover it): refused.
    const tooMuch = await call(U, 'POST', '/api/referrals/promos', { type: 'coins', amount: Math.floor(paid.coins) + 1, uses: 1 });
    expect(tooMuch.data.error).toBe('demo_coins');
    await ok(U, 'POST', '/api/referrals/promos', { type: 'coins', amount: 1, uses: 1 });
    const after = (await ok(U, 'GET', '/api/me')).user;
    expect(after.demoBalance).toBe(5000);
    expect(after.balance).toBeCloseTo(me.balance - 1, 2);
  });

  it('demo keys open first and give demo drops; demo and own coins never mix; «Забрать» takes demo coins first', async () => {
    const U = 3953;
    await ok(U, 'GET', '/api/me');
    const kase = await cheapCase(U);
    await ok(OWNER, 'POST', '/api/admin/give', { user: String(U), type: 'case', caseId: kase.id, amount: 1, demo: true });
    await ok(OWNER, 'POST', '/api/admin/give', { user: String(U), type: 'case', caseId: kase.id, amount: 1, demo: false });
    expect((await ok(U, 'GET', '/api/me')).demoKeys[kase.id]).toBe(1);
    expect((await ok(U, 'POST', '/api/case/open', { caseId: kase.id, useKey: true })).result.demo).toBe(true);
    expect((await ok(U, 'POST', '/api/case/open', { caseId: kase.id, useKey: true })).result.demo).toBeFalsy();
    // Demo and own coins never mix: demo pays only when it covers the whole price, else own coins do; a price that
    // only both together cover is refused. (A demo key's coin prize would be demo coins: start from none.)
    await pool.query('UPDATE users SET demo_balance = 0 WHERE id = $1', [U]);
    await ok(OWNER, 'POST', '/api/admin/give', { user: String(U), type: 'coins', amount: 1000, demo: false });
    const some = Math.floor(kase.price * 0.6);
    await ok(OWNER, 'POST', '/api/admin/give', { user: String(U), type: 'coins', amount: some, demo: true });
    expect((await ok(U, 'POST', '/api/case/open', { caseId: kase.id, expectedPrice: kase.price })).result.demo).toBeFalsy();
    expect((await ok(U, 'GET', '/api/me')).user.demoBalance).toBe(some);
    await ok(OWNER, 'POST', '/api/admin/give', { user: String(U), type: 'coins', amount: kase.price, demo: true });
    expect((await ok(U, 'POST', '/api/case/open', { caseId: kase.id, expectedPrice: kase.price })).result.demo).toBe(true);
    // 0.6 of the price in each: together enough, apart not.
    await pool.query('UPDATE users SET balance = $2, demo_balance = $3 WHERE id = $1', [U, 2 * some, some]);
    expect((await call(U, 'POST', '/api/case/open', { caseId: kase.id, expectedPrice: kase.price })).data.error).toBe('mixed_coins');
    expect((await ok(U, 'GET', '/api/me')).user.balance).toBe(2 * some);
    await ok(OWNER, 'POST', '/api/admin/give', { user: String(U), type: 'coins', amount: 300, demo: true });
    const before = (await ok(U, 'GET', '/api/me')).user;
    await ok(OWNER, 'POST', '/api/admin/take', { userId: U, coins: 100 });
    const after = (await ok(U, 'GET', '/api/me')).user;
    expect(after.balance).toBeCloseTo(before.balance - 100, 2);
    expect(after.demoBalance).toBeCloseTo(before.demoBalance - 100, 2);
  });
});

describe('iteration 35: «Небо Meowl»', () => {
  let n = 0;
  const payStars = async (user: number, stars: number) => {
    const inv = await ok(user, 'POST', '/api/stars/invoice', { stars });
    n++;
    await hook({
      update_id: 9700 + n,
      message: {
        message_id: 9700 + n,
        from: { id: user, first_name: `u${user}` },
        chat: { id: user, type: 'private' },
        successful_payment: { currency: 'XTR', total_amount: stars, invoice_payload: `stars:${inv.orderId}`, telegram_payment_charge_id: `sky-${n}`, provider_payment_charge_id: '' },
      },
    });
  };
  /** The run's coins around a point, nearest first. */
  const coinsNear = (seed: number, x: number, y: number) => {
    const out: (SkyCoin & { d: number })[] = [];
    const cx = Math.floor(x / SKY_CHUNK);
    const cy = Math.floor(y / SKY_CHUNK);
    for (let i = -4; i <= 4; i++) for (let j = -4; j <= 4; j++) for (const c of chunkCoins(seed, cx + i, cy + j)) out.push({ ...c, d: Math.hypot(c.x - x, c.y - y) });
    return out.sort((a, b) => a.d - b.d);
  };
  /** As if the player had been flying for a while since their last pick (so the next coin is within reach). */
  const flyFor = (run: number, user: number, seconds: number) =>
    pool.query(`UPDATE sky_players SET at = now() - make_interval(secs => $3) WHERE run_id = $1 AND user_id = $2`, [run, user, seconds]);

  it('a flight: depositors only, coins within reach, shared, capped; eggs come on top; the admin stops it', { timeout: 30_000 }, async () => {
    const A = 3960;
    const B = 3961;
    const NODEP = 3962;
    for (const u of [A, B, NODEP]) await ok(u, 'GET', '/api/me');
    await payStars(A, 10);
    await payStars(B, 10);
    const started = await ok(OWNER, 'POST', '/api/admin/sky/start', { minutes: 10, max: 2, needDeposit: true, repeatHours: 0, notify: false });
    const runId = started.run.runId as number;
    const cat = await ok(A, 'GET', '/api/catalog');
    expect(cat.sky).toMatchObject({ runId, max: 2, needDeposit: true });
    const seed = cat.sky.seed as number;
    expect((await call(NODEP, 'POST', '/api/sky/join')).data.error).toBe('sky_closed');
    const a = await ok(A, 'POST', '/api/sky/join');
    expect(typeof a.ticket).toBe('string');
    expect(a.me).toMatchObject({ coins: 0, eggs: 0 });
    // Joining again keeps the spawn.
    expect((await ok(A, 'POST', '/api/sky/join')).me).toMatchObject({ x: a.me.x, y: a.me.y });
    const near = coinsNear(seed, a.me.x, a.me.y);
    const first = near[0]!;
    await flyFor(runId, A, 30);
    const balance = (await ok(A, 'GET', '/api/me')).user.balance as number;
    const got = await ok(A, 'POST', '/api/sky/pick', { key: first.key });
    expect(got).toMatchObject({ kind: 'coin', value: 0.5, coins: 0.5 });
    expect(got.balance).toBeCloseTo(balance + 0.5, 2);
    // Shared: the second player finds it taken.
    await ok(B, 'POST', '/api/sky/join');
    await flyFor(runId, B, 600);
    expect((await call(B, 'POST', '/api/sky/pick', { key: first.key })).data.error).toBe('taken');
    // Right after a pick, a coin far away is out of reach.
    const far = coinsNear(seed, first.x, first.y).find((c) => c.d > 1200)!;
    expect((await call(A, 'POST', '/api/sky/pick', { key: far.key })).data.error).toBe('too_far');
    expect((await call(A, 'POST', '/api/sky/pick', { key: 'c:999999:1:99' })).data.error).toBe('no_coin');
    // Up to the cap (2 B = 4 coins), then no more coins.
    const rest = coinsNear(seed, first.x, first.y).filter((c) => c.key !== first.key);
    for (const c of rest.slice(0, 3)) {
      await flyFor(runId, A, 60);
      await ok(A, 'POST', '/api/sky/pick', { key: c.key });
    }
    await flyFor(runId, A, 60);
    expect((await call(A, 'POST', '/api/sky/pick', { key: rest[3]!.key })).data.error).toBe('sky_cap');
    // An egg next to everyone flying (no room here: the players seen in the last 5 minutes stand in — B's last pick
    // was 10 minutes ago) — over the cap.
    const eggs = await ok(OWNER, 'POST', '/api/admin/sky/eggs', { mode: 'all' });
    expect(eggs.eggs.map((e: { near: number }) => e.near)).toEqual([A]);
    const mine = eggs.eggs.find((e: { near: number }) => e.near === A);
    await flyFor(runId, A, 60);
    expect(await ok(A, 'POST', '/api/sky/pick', { key: mine.key })).toMatchObject({ kind: 'egg', value: 10, eggs: 10 });
    expect((await ok(B, 'GET', '/api/sky')).eggs.map((e: { key: string }) => e.key)).not.toContain(mine.key);
    expect((await ok(B, 'GET', '/api/sky')).taken).toContain(first.key);
    const admin = await ok(OWNER, 'GET', '/api/admin/sky');
    expect(admin.stats).toMatchObject({ players: 2, coins: 2, eggs: 10 });
    await ok(OWNER, 'POST', '/api/admin/sky/stop');
    expect((await ok(A, 'GET', '/api/catalog')).sky).toBeNull();
    expect((await call(A, 'POST', '/api/sky/pick', { key: rest[4]!.key })).data.error).toBe('sky_over');
  });

  it("iteration 37: the run's pool is shared — once it is spent, coins pay nobody (eggs still do)", { timeout: 30_000 }, async () => {
    const A = 3964;
    const B = 3965;
    for (const u of [A, B]) await ok(u, 'GET', '/api/me');
    const started = await ok(OWNER, 'POST', '/api/admin/sky/start', { minutes: 10, max: 5, pool: 1, needDeposit: false, repeatHours: 0, notify: false });
    const runId = started.run.runId as number;
    expect(started.run).toMatchObject({ pool: 1, max: 5 });
    const seed = started.run.seed as number;
    const a = await ok(A, 'POST', '/api/sky/join');
    expect(a.poolLeft).toBe(1);
    await ok(B, 'POST', '/api/sky/join');
    const near = coinsNear(seed, a.me.x, a.me.y);
    await flyFor(runId, A, 600);
    expect(await ok(A, 'POST', '/api/sky/pick', { key: near[0]!.key })).toMatchObject({ coins: 0.5, poolLeft: 0.5 });
    await flyFor(runId, B, 6000);
    expect(await ok(B, 'POST', '/api/sky/pick', { key: near[1]!.key })).toMatchObject({ coins: 0.5, poolLeft: 0 });
    await flyFor(runId, A, 600);
    expect((await call(A, 'POST', '/api/sky/pick', { key: near[2]!.key })).data.error).toBe('sky_pool');
    expect((await ok(A, 'GET', '/api/sky')).poolLeft).toBe(0);
    expect((await ok(OWNER, 'GET', '/api/admin/sky')).stats).toMatchObject({ pool: 1, paid: 1 });
    await ok(OWNER, 'POST', '/api/admin/sky/stop');
  });

  it('auto-repeat starts the next flight from the tick once its interval has passed', async () => {
    await ok(OWNER, 'POST', '/api/admin/sky/config', { minutes: 5, max: 20, needDeposit: false, repeatHours: 2, notify: false });
    expect(await skyTick()).toBeNull();
    await pool.query(`UPDATE settings SET value = jsonb_set(value, '{lastStartAt}', to_jsonb($1::bigint)) WHERE key = 'sky'`, [Date.now() - 3 * 3_600_000]);
    const runId = await skyTick();
    expect(runId).toBeGreaterThan(0);
    expect((await ok(3963, 'GET', '/api/catalog')).sky).toMatchObject({ runId, needDeposit: false, max: 20 });
    // Running: no second start.
    expect(await skyTick()).toBeNull();
    await ok(OWNER, 'POST', '/api/admin/sky/config', { repeatHours: 0 });
    await ok(OWNER, 'POST', '/api/admin/sky/stop');
  });

  it('the room shows who flies where: joins, snapshots of who moved, leaves, egg targets', () => {
    let t = 1000;
    const room = new SkyRoom(() => t);
    const inbox = new Map<number, unknown[]>();
    const sock = (id: number) => ({ send: (d: string) => inbox.set(id, [...(inbox.get(id) ?? []), d === 'pong' ? d : JSON.parse(d)]), close: () => {} });
    const s1 = sock(1);
    const s2 = sock(2);
    room.join(1, 'Аня', s1);
    room.join(2, 'Боря', s2);
    expect(inbox.get(1)).toContainEqual({ t: 'j', id: 2, n: 'Боря', x: 0, y: 0 });
    room.message(1, s1, JSON.stringify({ t: 'p', x: 100.4, y: -50, h: 1.5 }));
    // Too soon after the last one: dropped.
    t += 50;
    room.message(1, s1, JSON.stringify({ t: 'p', x: 9999, y: 9999, h: 0 }));
    expect(room.flush()).toBe(true);
    expect(inbox.get(2)).toContainEqual({ t: 's', p: [[1, 100, -50, 1.5]] });
    expect(room.flush()).toBe(false);
    expect(room.targets('all')).toEqual([
      { userId: 1, x: 100, y: -50 },
      { userId: 2, x: 0, y: 0 },
    ]);
    expect(room.targets('random', 1)).toHaveLength(1);
    room.leave(2, s2);
    expect(inbox.get(1)).toContainEqual({ t: 'l', id: 2 });
    expect(room.size).toBe(1);
  });
});

describe('iteration 35: «Игра Кальмара»', () => {
  let n = 0;
  const payStars = async (user: number, stars: number) => {
    const inv = await ok(user, 'POST', '/api/stars/invoice', { stars });
    n++;
    await hook({
      update_id: 9800 + n,
      message: {
        message_id: 9800 + n,
        from: { id: user, first_name: `u${user}` },
        chat: { id: user, type: 'private' },
        successful_payment: { currency: 'XTR', total_amount: stars, invoice_payload: `stars:${inv.orderId}`, telegram_payment_charge_id: `squid-${n}`, provider_payment_charge_id: '' },
      },
    });
  };

  it('a game: invite in the catalog, depositors play, the room decides, places get the prizes once (staff skipped)', async () => {
    const rooms = new Map<string, SquidRoom>();
    const room = (name: string) => rooms.get(name) ?? (rooms.set(name, new SquidRoom()), rooms.get(name)!);
    useRooms({ send: async (name, msg) => room(name).broadcast(msg), call: async (name, op, arg) => room(name).call(op, arg) });
    try {
      const A = 3970;
      const B = 3971;
      const NODEP = 3972;
      for (const u of [A, B, NODEP]) await ok(u, 'GET', '/api/me');
      await payStars(A, 10);
      await payStars(B, 10);
      expect((await call(OWNER, 'POST', '/api/admin/squid/start', { prizes: [] })).data.error).toBe('invalid');
      const started = await ok(OWNER, 'POST', '/api/admin/squid/start', {
        prizes: [
          { type: 'brainrot', brainrotId: 'garama-and-madundung' },
          { type: 'coins', amount: 50 },
        ],
        needDeposit: true,
        notify: false,
      });
      expect((await call(OWNER, 'POST', '/api/admin/squid/start', { prizes: [{ type: 'coins', amount: 1 }] })).data.error).toBe('running');
      const cat = await ok(A, 'GET', '/api/catalog');
      expect(cat.squid).toMatchObject({ gameId: started.gameId, needDeposit: true });
      expect((await ok(A, 'GET', '/api/squid')).ticket).toBeTruthy();
      const nodep = await ok(NODEP, 'GET', '/api/squid');
      expect(nodep.block).toContain('пополнением');
      expect(nodep.ticket).toBeNull();
      // Not over yet: nothing is settled.
      expect(await ok(A, 'POST', '/api/squid/settle')).toEqual({ settled: false });
      // The room ends with the owner crossing first, then A, then B.
      const r = room(`squid:${started.gameId}`) as unknown as { phase: string; places: number[] };
      r.phase = 'done';
      r.places.push(OWNER, A, B);
      const before = (await ok(B, 'GET', '/api/me')).user.balance as number;
      const settled = await ok(B, 'POST', '/api/squid/settle');
      expect(settled.settled).toBe(true);
      // The first prize goes to A (the owner is staff), the second to B.
      expect((await ok(A, 'GET', '/api/me')).inventory.some((i: { brainrotId: string }) => i.brainrotId === 'garama-and-madundung')).toBe(true);
      expect((await ok(B, 'GET', '/api/me')).user.balance).toBeCloseTo(before + 50, 2);
      expect(await ok(A, 'GET', '/api/squid/mine')).toMatchObject({ place: 2, prize: { type: 'brainrot' } });
      // Once only.
      expect(await ok(A, 'POST', '/api/squid/settle')).toEqual({ settled: false });
      expect((await ok(A, 'GET', '/api/catalog')).squid).toBeNull();
      // A new game can be cancelled.
      const second = await ok(OWNER, 'POST', '/api/admin/squid/start', { prizes: [{ type: 'coins', amount: 5 }], notify: false });
      await ok(OWNER, 'POST', '/api/admin/squid/cancel');
      expect((await pool.query('SELECT status FROM squid_games WHERE id = $1', [second.gameId])).rows[0].status).toBe('cancelled');
      expect((await ok(A, 'GET', '/api/catalog')).squid).toBeNull();
    } finally {
      useRooms(null);
    }
  });
});

describe('iteration 36: wagering («отыгрыш») before a withdrawal', () => {
  const W = 3601;
  const ADM = 3602;
  const nick = { robloxNick: 'Wager_Rbx' };
  const wager = async (id = W) => (await ok(id, 'GET', '/api/me')).user.wager as { left: number; total: number };
  const rules = (wagerDeposit: number, wagerBonus: number) =>
    ok(OWNER, 'POST', '/api/admin/settings', { withdrawRules: { minValue: 100, minItems: 2, minItemPrice: 45, wagerDeposit, wagerBonus } });

  beforeAll(async () => {
    await ok(W, 'GET', '/api/me');
    await ok(ADM, 'GET', '/api/me');
    await ok(OWNER, 'POST', '/api/admin/admins', { user: String(ADM) });
  });

  it('a gift is played through ×2; a purchase is no stake; every paid case plays it down; then the withdrawal opens', async () => {
    await ok(OWNER, 'POST', '/api/admin/give', { user: String(W), type: 'coins', amount: 400 });
    expect(await wager()).toEqual({ left: 800, total: 800 });
    const a = await buy(W, 'garama-and-madundung');
    const b = await buy(W, 'garama-and-madundung');
    expect((await wager()).left).toBe(800);
    const refused = await call(W, 'POST', '/api/withdrawals', { itemIds: [a, b], ...nick });
    expect(refused.data).toMatchObject({ error: 'wager', left: 800, total: 800 });
    expect(refused.data.message).toContain('800');
    // Coins to play with that need no wagering of their own (an owner's «без отыгрыша»).
    await ok(OWNER, 'POST', '/api/admin/give', { user: String(W), type: 'coins', amount: 1000, noWager: true });
    expect((await wager()).left).toBe(800);
    const price = Number((await pool.query(`SELECT price FROM cases WHERE id = 'noobini'`)).rows[0].price);
    await ok(W, 'POST', '/api/case/open', { caseId: 'noobini' });
    expect(await wager()).toEqual({ left: 800 - price, total: 800 });
    for (let i = 0; i < 20 && (await wager()).left > 0; i++) await ok(W, 'POST', '/api/case/open', { caseId: 'noobini', count: 5 });
    expect((await wager()).left).toBe(0);
    const w = await ok(W, 'POST', '/api/withdrawals', { itemIds: [a, b], ...nick });
    expect(w.result.status).toBe('pending');
    await ok(W, 'POST', `/api/withdrawals/${w.result.id}/cancel`);
  }, 60_000);

  it("the admin's multipliers; a gift key's drop is free value; demo touches nothing", async () => {
    await rules(1, 2);
    try {
      await ok(OWNER, 'POST', '/api/admin/give', { user: String(W), type: 'coins', amount: 50 });
      expect(await wager()).toEqual({ left: 100, total: 100 });
      // A demo gift and a demo game leave it as it is.
      await ok(OWNER, 'POST', '/api/admin/give', { user: String(W), type: 'coins', amount: 300, demo: true });
      expect((await wager()).left).toBe(100);
      // A gift opening (stake 0): what it dropped is added × the bonus multiplier.
      await ok(OWNER, 'POST', '/api/admin/give', { user: String(W), type: 'case', caseId: 'noobini', amount: 1 });
      const opened = await ok(W, 'POST', '/api/case/open', { caseId: 'noobini', useKey: true });
      const drop = (await pool.query('SELECT payout_value, stake_value FROM drops WHERE user_id = $1 ORDER BY id DESC LIMIT 1', [W])).rows[0];
      expect(Number(drop.stake_value)).toBe(0);
      expect(opened.result.brainrotId).toBeTruthy();
      expect((await wager()).left).toBeCloseTo(100 + Number(drop.payout_value) * 2, 2);
      // 0 switches it off.
      await rules(0, 0);
      const before = await wager();
      await ok(OWNER, 'POST', '/api/admin/give', { user: String(W), type: 'coins', amount: 70 });
      expect(await wager()).toEqual(before);
    } finally {
      await rules(2, 2);
    }
    expect((await ok(OWNER, 'GET', '/api/admin/settings')).withdrawRules).toMatchObject({ wagerDeposit: 2, wagerBonus: 2 });
  });

  it('only an owner gives without wagering or clears it (logged); the admin card shows it', async () => {
    expect((await call(ADM, 'POST', '/api/admin/give', { user: String(W), type: 'coins', amount: 10, noWager: true })).status).toBe(403);
    expect((await call(ADM, 'POST', `/api/admin/users/${W}/wager/clear`)).status).toBe(403);
    const left = (await wager()).left;
    expect(left).toBeGreaterThan(0);
    expect((await ok(ADM, 'GET', `/api/admin/users/${W}`)).user.wager.left).toBe(left);
    expect(await ok(OWNER, 'POST', `/api/admin/users/${W}/wager/clear`)).toEqual({ cleared: left });
    expect(await wager()).toEqual({ left: 0, total: 0 });
    const logged = await pool.query(`SELECT details FROM admin_log WHERE action = 'wager_clear' AND target_user = $1`, [W]);
    expect(logged.rows[0].details).toEqual({ left });
  });
});

describe('iteration 37: «Анонс в игре», immortality for trailers', () => {
  it('an admin shouts to every open app (photo, name, colour), one at a time, logged; players cannot', async () => {
    expect((await call(ALICE, 'POST', '/api/admin/shout', { text: 'hi' })).status).toBe(403);
    expect((await call(OWNER, 'POST', '/api/admin/shout', { text: '', color: 'red' })).status).toBe(400);
    expect((await call(OWNER, 'POST', '/api/admin/shout', { text: 'x', color: 'pink' })).status).toBe(400);
    const r = await ok(OWNER, 'POST', '/api/admin/shout', { text: '  Через 5 минут —   Кальмар!  ', color: 'green' });
    expect(r.shout).toMatchObject({ text: 'Через 5 минут — Кальмар!', color: 'green', authorName: 'owner' });
    const catalog = await ok(ALICE, 'GET', '/api/catalog');
    expect(catalog.shout).toMatchObject({ text: 'Через 5 минут — Кальмар!', color: 'green' });
    expect((await call(OWNER, 'POST', '/api/admin/shout', { text: 'ещё' })).data.error).toBe('too_soon');
    const logged = await pool.query(`SELECT details FROM admin_log WHERE action = 'shout' ORDER BY id DESC LIMIT 1`);
    expect(logged.rows[0].details).toEqual({ text: 'Через 5 минут — Кальмар!', color: 'green' });
  });

  it("immortality is each admin's own switch and rides in the room pass", async () => {
    expect((await call(ALICE, 'POST', '/api/admin/immortal', { on: true })).status).toBe(403);
    await ok(OWNER, 'POST', '/api/admin/immortal', { on: true });
    expect((await ok(OWNER, 'GET', '/api/admin/settings')).immortal).toEqual([OWNER]);
    const pass = verifyRoomTicket(roomTicket({ userId: OWNER, name: 'owner', room: 'squid:1', god: true }));
    expect(pass).toMatchObject({ userId: OWNER, god: true });
    expect(verifyRoomTicket(roomTicket({ userId: ALICE, name: 'alice', room: 'squid:1' }))).toMatchObject({ god: false });
    await ok(OWNER, 'POST', '/api/admin/immortal', { on: false });
    expect((await ok(OWNER, 'GET', '/api/admin/settings')).immortal).toEqual([]);
  });
});

describe('iteration 37: «Батл пасс»', () => {
  const P = 3701;
  const plusHook = (n: number, user: number, orderId: number, amount: number, charge: string) =>
    hook({
      update_id: 37000 + n,
      message: {
        message_id: 37000 + n,
        from: { id: user, first_name: `u${user}` },
        chat: { id: user, type: 'private' },
        successful_payment: { currency: 'XTR', total_amount: amount, invoice_payload: `pass:${orderId}`, telegram_payment_charge_id: charge, provider_payment_charge_id: '' },
      },
    });

  it('levels come from real stakes; FREE rewards are claimed once; BPlus needs 299 ⭐ and then opens every level reached', { timeout: 60_000 }, async () => {
    await ok(P, 'GET', '/api/me');
    let s = await ok(P, 'GET', '/api/pass');
    expect(s).toMatchObject({ xp: 0, level: 0, plus: false, plusStars: PASS_PLUS_STARS });
    expect(s.free).toHaveLength(PASS_LEVELS);
    expect(s.plusValue).toBeGreaterThan(s.plusPrice * 1.4);
    expect(s.plusValue).toBeLessThanOrEqual(s.plusPrice * 1.5);
    expect((await call(P, 'POST', '/api/pass/claim')).data.error).toBe('nothing');
    // Coins to play with (an owner's gift without wagering) and three paid cases: XP = what was staked.
    await ok(OWNER, 'POST', '/api/admin/give', { user: String(P), type: 'coins', amount: 5000, noWager: true });
    const price = Number((await pool.query(`SELECT price FROM cases WHERE id = 'noobini'`)).rows[0].price);
    for (let i = 0; i < 4; i++) await ok(P, 'POST', '/api/case/open', { caseId: 'noobini', count: 5 });
    s = await ok(P, 'GET', '/api/pass');
    expect(s.xp).toBe(Math.floor(price * 20));
    expect(s.level).toBe(passLevelOf(s.xp).level);
    expect(s.level).toBeGreaterThanOrEqual(1);
    // Level 3 isn't reached yet (unless the cases were dear).
    if (s.level < 3) expect((await call(P, 'POST', '/api/pass/claim', { level: 3, track: 'free' })).data.error).toBe('pass_locked');
    expect((await call(P, 'POST', '/api/pass/claim', { level: 1, track: 'plus' })).data.error).toBe('pass_no_plus');
    // Iteration 39: FREE is sparse — nothing on level 1, the first tickets on level 3.
    expect(PASS_FREE[0]).toBeNull();
    expect((await call(P, 'POST', '/api/pass/claim', { level: 1, track: 'free' })).data.error).toBe('no_reward');
    expect((await call(P, 'POST', '/api/pass/claim')).data.error).toBe(s.level >= 3 ? undefined : 'nothing');
    // BPlus: an invoice, the checkout, the payment — then the plus rewards of every level reached.
    const inv = await ok(P, 'POST', '/api/pass/buy');
    expect(inv).toMatchObject({ stars: PASS_PLUS_STARS, link: expect.stringContaining('t.me') });
    const checkout = (from: number, amount: number) =>
      hook({ update_id: 37100, pre_checkout_query: { id: 'pp', from: { id: from, first_name: 'x' }, currency: 'XTR', total_amount: amount, invoice_payload: `pass:${inv.orderId}` } });
    expect((await checkout(BOB, PASS_PLUS_STARS)).data).toMatchObject({ ok: false });
    expect((await checkout(P, 5)).data).toMatchObject({ ok: false });
    expect((await checkout(P, PASS_PLUS_STARS)).data).toMatchObject({ ok: true });
    const paid = await plusHook(1, P, inv.orderId, PASS_PLUS_STARS, 'pass-charge-1');
    expect(paid.data.text).toContain('BPlus');
    expect((await plusHook(2, P, inv.orderId, PASS_PLUS_STARS, 'pass-charge-1')).data).toEqual({});
    expect(await ok(P, 'GET', `/api/pass/orders/${inv.orderId}`)).toMatchObject({ status: 'paid' });
    expect((await call(P, 'POST', '/api/pass/buy')).data.error).toBe('already_plus');
    s = await ok(P, 'GET', '/api/pass');
    expect(s.plus).toBe(true);
    // Claim everything reached: the plus reward of level 1 is coins, bonus value to wager.
    const wagerBefore = (await ok(P, 'GET', '/api/me')).user.wager.left as number;
    const balanceBefore = (await ok(P, 'GET', '/api/me')).user.balance as number;
    const all = await ok(P, 'POST', '/api/pass/claim');
    expect(all.result.rewards.length).toBeGreaterThanOrEqual(1);
    expect(all.result.rewards[0]).toMatchObject({ brainrotId: null, caseId: null, coins: s.plusTrack[0].amount });
    expect(all.result.total).toBeGreaterThan(0);
    expect((await ok(P, 'GET', '/api/me')).user.balance).toBeGreaterThanOrEqual(balanceBefore + s.plusTrack[0].amount);
    expect((await ok(P, 'GET', '/api/me')).user.wager.left).toBeGreaterThan(wagerBefore);
    s = await ok(P, 'GET', '/api/pass');
    expect(s.claimed).toContain('plus:1');
    expect((await call(P, 'POST', '/api/pass/claim')).data.error).toBe('nothing');
  });

  it('iteration 39: BPlus gives coins, tickets and paid case openings — no brainrots — worth 1.5× its price; FREE is lean', async () => {
    const s0 = await ok(P, 'GET', '/api/pass');
    const kinds = new Set((s0.plusTrack as { kind: string }[]).map((r) => r.kind));
    expect([...kinds].sort()).toEqual(['case', 'coins', 'tickets']);
    expect(s0.plusValue).toBeGreaterThan(s0.plusPrice * 1.45);
    expect(s0.plusValue).toBeLessThanOrEqual(s0.plusPrice * 1.5);
    // FREE: about half of what it was (≈ 85 B), a reward on fewer than every level.
    const freeValue = (PASS_FREE as ({ kind: string; amount?: number; value?: number } | null)[]).reduce(
      (sum, r) => sum + (!r ? 0 : r.kind === 'tickets' ? r.amount! * s0.ticketValue : r.value!),
      0,
    );
    expect(freeValue).toBeLessThan(45);
    expect(PASS_FREE.filter(Boolean).length).toBeLessThan(PASS_LEVELS / 2);
    // A new BPlus holder at level 5 (stakes played this season): its BPlus reward is a free opening of the dearest paid
    // case that fits, the rest in coins.
    const Q = 3702;
    await ok(Q, 'GET', '/api/me');
    await pool.query(`INSERT INTO pass_plus (user_id, season) VALUES ($1, $2)`, [Q, s0.season.id]);
    await pool.query(`INSERT INTO drops (user_id, game, result, stake_value, payout_value) VALUES ($1, 'case', 'lose', 1000, 0)`, [Q]);
    const keysBefore = (await ok(Q, 'GET', '/api/me')).caseKeys as Record<string, number>;
    const r5 = await ok(Q, 'POST', '/api/pass/claim', { level: 5, track: 'plus' });
    const got = r5.result.rewards[0];
    const value = s0.plusTrack[4].value as number;
    const fit = await pool.query(
      `SELECT id, price FROM cases WHERE kind = 'paid' AND status = 'active' AND bonus IS NULL AND price > 0 AND price <= $1
       AND (price_cycle IS NULL OR cardinality(price_cycle) = 0) ORDER BY price DESC LIMIT 1`,
      [value],
    );
    expect(got.caseId).toBe(fit.rows[0]?.id ?? null);
    expect(got.coins).toBeCloseTo(value - Number(fit.rows[0]?.price ?? 0), 2);
    if (got.caseId) expect((await ok(Q, 'GET', '/api/me')).caseKeys[got.caseId]).toBe((keysBefore[got.caseId] ?? 0) + 1);
    expect((await call(Q, 'POST', '/api/pass/claim', { level: 5, track: 'plus' })).data.error).toBe('claimed');
    // The opening works like any gift key: free, and its drop is bonus value to wager.
    if (got.caseId) {
      const opened = await ok(Q, 'POST', '/api/case/open', { caseId: got.caseId, useKey: true });
      expect(opened.result.brainrotId).toBeTruthy();
      expect((await ok(Q, 'GET', '/api/me')).caseKeys[got.caseId] ?? 0).toBe(keysBefore[got.caseId] ?? 0);
    }
  });
});

describe('iteration 38: the referral case once per account, «Окуп ×0.5»', () => {
  const start = (id: number, text: string) => hook({ update_id: 38000 + id, message: { message_id: id, from: { id, first_name: `n${id}` }, chat: { id, type: 'private' }, text } });
  const keys = async (id: number) => (await ok(id, 'GET', '/api/me')).caseKeys.referral ?? 0;

  it('a million friends still give one referral case; a player who came by a link gets none for their own friends', async () => {
    const [R, F1, F2, F3, G1] = [3801, 3802, 3803, 3804, 3805];
    await start(R, '/start');
    const code = (await ok(R, 'GET', '/api/referrals')).code;
    // The first friend: a case for both.
    await start(F1, `/start r-${code}`);
    expect(await keys(R)).toBe(1);
    expect(await keys(F1)).toBe(1);
    // More friends: each friend gets theirs, the referrer nothing more.
    await start(F2, `/start r-${code}`);
    await ok(F3, 'GET', '/api/me');
    expect((await ok(F3, 'POST', '/api/promo', { code })).result).toMatchObject({ type: 'referral' });
    expect(await keys(F2)).toBe(1);
    expect(await keys(F3)).toBe(1);
    expect(await keys(R)).toBe(1);
    expect((await ok(R, 'GET', '/api/referrals')).invited).toBe(3);
    // F1 came by R's link and had the case then: F1's own friend gets one, F1 doesn't get a second.
    const f1code = (await ok(F1, 'GET', '/api/referrals')).code;
    await start(G1, `/start r-${f1code}`);
    expect(await keys(G1)).toBe(1);
    expect(await keys(F1)).toBe(1);
    expect((await ok(F1, 'GET', '/api/bonuses')).referralHad).toBe(true);
    // Opening it: gone for good, «уже получен», and the case itself refuses without a key.
    await ok(R, 'POST', '/api/case/open', { caseId: 'referral', useKey: true });
    expect(await keys(R)).toBe(0);
    expect((await ok(R, 'GET', '/api/bonuses')).referralHad).toBe(true);
    expect((await call(R, 'POST', '/api/case/open', { caseId: 'referral' })).data.error).toBe('need_invite');
  }, 20_000);

  it('the migration trims unopened extra referral cases and remembers what was taken', async () => {
    const [A, B, C] = [3811, 3812, 3813];
    for (const id of [A, B, C]) await ok(id, 'GET', '/api/me');
    const set = (id: number, n: number) =>
      pool.query(`INSERT INTO case_keys (user_id, case_id, count) VALUES ($1, 'referral', $2) ON CONFLICT (user_id, case_id) DO UPDATE SET count = $2`, [id, n]);
    await set(A, 5); // never opened one: keeps 1
    await set(B, 3); // opened one already: keeps none
    await set(C, 1); // just the one: untouched
    await pool.query(`INSERT INTO drops (user_id, game, result, stake_value, meta) VALUES ($1, 'case', 'win', 0, '{"caseId": "referral", "gift": true}')`, [B]);
    const sql = readFileSync('./netlify/database/migrations/20261117100000_ref_once.sql', 'utf8');
    await pool.query(sql);
    await pool.query(sql); // twice: nothing more happens
    expect(await keys(A)).toBe(1);
    expect(await keys(B)).toBe(0);
    expect(await keys(C)).toBe(1);
    const trimmed = await pool.query('SELECT user_id, had, kept, opened FROM ref_case_trim WHERE user_id = ANY($1) ORDER BY user_id', [[A, B, C]]);
    expect(trimmed.rows.map((r) => [Number(r.user_id), r.had, r.kept, r.opened])).toEqual([
      [A, 5, 1, 0],
      [B, 3, 0, 1],
    ]);
    // The migration also switched the cut on (×0.5): back to the usual model for the tests below.
    expect((await ok(OWNER, 'GET', '/api/admin/settings')).okupCut).toEqual({ factor: 0.5, until: null });
    await pool.query(`DELETE FROM settings WHERE key = 'okup_cut'`);
  });

  it('«Окуп ×0.5»: owners only; drops dearer than a paid case come half as often, the case pays less; back to usual', async () => {
    const ADM = 3821;
    await ok(ADM, 'GET', '/api/me');
    await pool.query('INSERT INTO admins (user_id, added_by) VALUES ($1, $2) ON CONFLICT DO NOTHING', [ADM, OWNER]);
    expect((await call(ALICE, 'POST', '/api/admin/okup-cut', { factor: 0.5 })).status).toBe(403);
    expect((await call(ADM, 'POST', '/api/admin/okup-cut', { factor: 0.5 })).status).toBe(403);
    expect((await call(OWNER, 'POST', '/api/admin/okup-cut', { factor: 0.4 })).status).toBe(400);
    const share = async () => {
      const cases = await ok(OWNER, 'GET', '/api/admin/cases');
      const paid = cases.filter((k: { price: number; kind: string; items: unknown[] }) => k.price > 0 && k.kind === 'paid' && k.items.length > 2);
      const cat = await ok(OWNER, 'GET', '/api/catalog');
      const price = new Map(cat.brainrots.map((b: { id: string; price: number }) => [b.id, b.price]));
      return paid.map((k: { id: string; price: number; items: { brainrotId: string; weight: number }[] }) => {
        const dear = k.items.filter((i) => (price.get(i.brainrotId) as number) > k.price).reduce((s, i) => s + i.weight, 0);
        const ev = k.items.reduce((s, i) => s + (price.get(i.brainrotId) as number) * i.weight, 0);
        return { id: k.id, dear, ev };
      });
    };
    const before = await share();
    const withDear = before.filter((k: { dear: number }) => k.dear > 0);
    expect(withDear.length).toBeGreaterThan(0);
    const r = await ok(OWNER, 'POST', '/api/admin/okup-cut', { factor: 0.5, hours: 2 });
    expect(r.okupCut.factor).toBe(0.5);
    expect(r.okupCut.until).toBeGreaterThan(Date.now() + 3_600_000);
    const after = new Map((await share()).map((k: { id: string }) => [k.id, k]));
    for (const k of withDear) {
      const a = after.get(k.id) as { dear: number; ev: number };
      expect(a.dear).toBeCloseTo(k.dear / 2, 9);
      expect(a.ev).toBeLessThan(k.ev);
    }
    expect((await pool.query(`SELECT details FROM admin_log WHERE action = 'okup_cut' ORDER BY id DESC LIMIT 1`)).rows[0].details).toMatchObject({ factor: 0.5 });
    // A cut that has run out is no cut.
    await pool.query(`UPDATE settings SET value = '{"factor": 0.5, "until": 1}'::jsonb WHERE key = 'okup_cut'`);
    expect((await ok(OWNER, 'GET', '/api/admin/settings')).okupCut).toEqual({ factor: 1, until: null });
    await ok(OWNER, 'POST', '/api/admin/okup-cut', { factor: 1 });
    const back = new Map((await share()).map((k: { id: string }) => [k.id, k]));
    for (const k of withDear) expect((back.get(k.id) as { dear: number }).dear).toBeCloseTo(k.dear, 9);
  });
});

describe('iteration 38: «Откуда инвентарь»', () => {
  it('owners see where a player’s coins and brainrots came from: games, free cases, gifts, inventory, friends', async () => {
    const [P, F1, F2] = [3831, 3832, 3833];
    await ok(P, 'GET', '/api/me');
    for (const f of [F1, F2]) {
      await ok(f, 'GET', '/api/me');
      await pool.query('UPDATE users SET referred_by = $2, referred_at = now() WHERE id = $1', [f, P]);
    }
    await ok(OWNER, 'POST', '/api/admin/give', { user: String(P), type: 'coins', amount: 70 });
    await ok(OWNER, 'POST', '/api/admin/give', { user: String(P), type: 'brainrot', brainrotId: 'meowl', amount: 1 });
    await pool.query(`INSERT INTO drops (user_id, game, result, stake_value, payout_value) VALUES ($1, 'upgrade', 'win', 100, 300), ($1, 'case', 'lose', 50, 0)`, [P]);
    await pool.query(`INSERT INTO drops (user_id, game, result, stake_value, payout_value, meta) VALUES ($1, 'case', 'win', 0, 40, '{"caseId": "referral", "gift": true}')`, [P]);
    expect((await call(ALICE, 'GET', `/api/admin/users/${P}/audit`)).status).toBe(403);
    const a = await ok(OWNER, 'GET', `/api/admin/users/${P}/audit`);
    expect(a.money).toMatchObject({ deposited: 0, withdrawn: 0 });
    expect(a.money.balance).toBeGreaterThanOrEqual(70);
    expect(a.games).toEqual(
      expect.arrayContaining([
        expect.objectContaining({ game: 'upgrade', count: 1, staked: 100, won: 300 }),
        expect.objectContaining({ game: 'case', count: 1, staked: 50, won: 0 }),
      ]),
    );
    expect(a.free).toEqual([expect.objectContaining({ game: 'case', caseId: 'referral', count: 1, won: 40 })]);
    expect(a.gifts.map((g: { action: string }) => g.action).sort()).toEqual(['give_brainrot', 'give_coins']);
    expect(a.inventory).toEqual([expect.objectContaining({ source: 'admin', count: 1, demo: false })]);
    expect(a.friends).toMatchObject({ count: 2, deposited: 0, empty: 2 });
    expect(a.friends.list[0]).toMatchObject({ deposited: 0, staked: 0 });
  });
});

describe('iteration 38: «Обнулить всех, кто подобрал яйцо»', () => {
  const PASSWORD = 'egg-danger-password';
  beforeAll(() => {
    process.env.WIPE_PASSWORD = PASSWORD;
  });
  afterAll(() => {
    delete process.env.WIPE_PASSWORD;
  });

  it('lists every player with an egg from «Небо Meowl» (staff aside) and resets them all at once, with the password', async () => {
    const [E1, E2, C1] = [3841, 3842, 3843];
    for (const id of [E1, E2, C1]) await ok(id, 'GET', '/api/me');
    await pool.query('UPDATE users SET balance = 500 WHERE id = ANY($1::bigint[])', [[E1, E2, C1]]);
    await pool.query(`INSERT INTO inventory (user_id, brainrot_id, source) VALUES ($1, 'meowl', 'admin'), ($2, 'meowl', 'admin'), ($3, 'meowl', 'admin')`, [E1, E2, C1]);
    const run = (await pool.query(`INSERT INTO sky_runs (seed, ends_at, max_per_player) VALUES (7, now() + interval '1 hour', 10) RETURNING id`)).rows[0].id;
    await pool.query(
      `INSERT INTO sky_players (run_id, user_id, x, y, coins, eggs) VALUES ($1, $2, 0, 0, 2, 10), ($1, $3, 0, 0, 0, 20), ($1, $4, 0, 0, 5, 0), ($1, $5, 0, 0, 0, 10)`,
      [run, E1, E2, C1, OWNER],
    );
    const info = await ok(OWNER, 'GET', '/api/admin/danger');
    // Earlier «Небо Meowl» tests may have left egg holders of their own: only these four are this test's.
    const listed = info.eggPlayers.map((p: { id: number }) => p.id);
    expect(listed).toEqual(expect.arrayContaining([E1, E2]));
    expect(listed).not.toContain(C1);
    expect(listed).not.toContain(OWNER);
    expect(info.eggPlayers.find((p: { id: number }) => p.id === E2).eggs).toBe(20);
    expect((await call(ALICE, 'POST', '/api/admin/danger/reset-eggs', { password: PASSWORD })).status).toBe(403);
    expect((await call(OWNER, 'POST', '/api/admin/danger/reset-eggs', { password: 'nope' })).data.error).toBe('wrong_password');
    const r = await ok(OWNER, 'POST', '/api/admin/danger/reset-eggs', { password: PASSWORD });
    expect(r.players).toBe(listed.length);
    expect(r.items).toBeGreaterThanOrEqual(2);
    for (const id of [E1, E2]) {
      const me = await ok(id, 'GET', '/api/me');
      expect(me.user.balance).toBe(0);
      expect(me.inventory).toHaveLength(0);
    }
    // The coin-only flyer and the owner keep everything.
    expect((await ok(C1, 'GET', '/api/me')).user.balance).toBe(500);
    expect((await ok(C1, 'GET', '/api/me')).inventory).toHaveLength(1);
    expect((await ok(OWNER, 'GET', '/api/admin/danger')).eggPlayers).toEqual([]);
    expect((await call(OWNER, 'POST', '/api/admin/danger/reset-eggs', { password: PASSWORD })).data.error).toBe('nobody');
    const logged = await pool.query(`SELECT details FROM admin_log WHERE action = 'danger_reset_eggs' ORDER BY id DESC LIMIT 1`);
    expect(logged.rows[0].details).toMatchObject({ players: listed.length, ids: expect.arrayContaining([E1, E2]) });
  });
});

describe('iteration 38: crypto deposits (@CryptoBot)', () => {
  const C = 3851;
  const CRYPTO_TOKEN = '12345:AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA';
  const invoices = new Map<number, Record<string, string | number | undefined>>();
  let nextInvoice = 900;
  const sign = (body: string) => createHmac('sha256', createHash('sha256').update(CRYPTO_TOKEN).digest()).update(body).digest('hex');
  const hookCrypto = (update: unknown, signature?: string) => {
    const body = JSON.stringify(update);
    return handle(new Request('http://local/api/crypto/webhook', { method: 'POST', headers: { 'crypto-pay-api-signature': signature ?? sign(body) }, body }));
  };
  beforeAll(async () => {
    process.env.CRYPTO_PAY_TOKEN = CRYPTO_TOKEN;
    useCryptoApi(async (method, params) => {
      if (method === 'createInvoice') {
        const inv = { invoice_id: ++nextInvoice, status: 'active', currency_type: params.currency_type, fiat: params.fiat, amount: params.amount, payload: params.payload, mini_app_invoice_url: `https://t.me/CryptoBot/app?startapp=invoice-${nextInvoice}` };
        invoices.set(inv.invoice_id, inv);
        return inv;
      }
      if (method === 'getInvoices') return { items: (params.invoice_ids ?? '').split(',').map((id) => invoices.get(Number(id))).filter(Boolean) };
      throw new Error(`unexpected ${method}`);
    });
    await ok(C, 'GET', '/api/me');
  });
  afterAll(() => {
    delete process.env.CRYPTO_PAY_TOKEN;
    useCryptoApi(null);
  });

  it('roubles become coins at 1.4 B per ₽; the signed webhook credits once — a deposit like Stars', async () => {
    const info = await ok(C, 'GET', '/api/crypto');
    expect(info).toMatchObject({ enabled: true, rate: 1.4, min: 10 });
    expect(info.packs[0]).toEqual({ rub: 10, coins: 14 });
    expect((await call(C, 'POST', '/api/crypto/invoice', { rub: 9 })).status).toBe(400);
    const inv = await ok(C, 'POST', '/api/crypto/invoice', { rub: 100 });
    expect(inv).toMatchObject({ rub: 100, coins: 140, url: expect.stringContaining('t.me/CryptoBot') });
    const created = [...invoices.values()].at(-1)!;
    expect(created).toMatchObject({ currency_type: 'fiat', fiat: 'RUB', amount: '100', payload: `bc:${inv.orderId}` });
    const before = await ok(C, 'GET', '/api/me');
    const paid = { ...created, status: 'paid', paid_asset: 'USDT', paid_amount: '1.21' };
    // Forged: refused, nothing credited.
    expect((await hookCrypto({ update_type: 'invoice_paid', payload: paid }, 'deadbeef')).status).toBe(401);
    expect((await ok(C, 'GET', '/api/me')).user.balance).toBe(before.user.balance);
    expect((await hookCrypto({ update_type: 'invoice_paid', payload: paid })).status).toBe(200);
    // Delivered twice: credited once.
    expect((await hookCrypto({ update_type: 'invoice_paid', payload: paid })).status).toBe(200);
    const after = await ok(C, 'GET', '/api/me');
    expect(after.user.balance).toBeCloseTo(before.user.balance + 140, 2);
    expect(after.user.wager.left).toBeCloseTo(before.user.wager.left + 140 * 2, 2);
    expect(await ok(C, 'GET', `/api/crypto/orders/${inv.orderId}`)).toMatchObject({ status: 'paid', rub: 100, coins: 140 });
    // Counted as a deposit everywhere (star_payments with 0 stars), and the owner is told nothing is wrong.
    const row = (await pool.query(`SELECT stars, credited, order_id FROM star_payments WHERE charge_id = $1`, [`crypto:${created.invoice_id}`])).rows[0];
    expect(row).toMatchObject({ stars: 0, order_id: null });
    expect(Number(row.credited)).toBe(140);
    expect(sent.some((m) => m.chatId === C && m.html.includes('140 B'))).toBe(true);
  });

  it('without the webhook the order is checked with CryptoBot when the app polls it (and by the tick)', async () => {
    const inv = await ok(C, 'POST', '/api/crypto/invoice', { rub: 250 });
    const before = (await ok(C, 'GET', '/api/me')).user.balance as number;
    expect(await ok(C, 'GET', `/api/crypto/orders/${inv.orderId}`)).toMatchObject({ status: 'pending' });
    const created = [...invoices.values()].at(-1)!;
    invoices.set(Number(created.invoice_id), { ...created, status: 'paid', paid_asset: 'TON', paid_amount: '0.5' });
    // The poll right after asked a moment ago: the tick picks it up.
    await runTick();
    expect(await ok(C, 'GET', `/api/crypto/orders/${inv.orderId}`)).toMatchObject({ status: 'paid', coins: 350 });
    expect((await ok(C, 'GET', '/api/me')).user.balance).toBeCloseTo(before + 350, 2);
    // Another player can't read the order.
    expect((await call(ALICE, 'GET', `/api/crypto/orders/${inv.orderId}`)).status).toBe(404);
    // The owners' list.
    const admin = await ok(OWNER, 'GET', '/api/admin/crypto');
    expect(admin.totals).toMatchObject({ count: 2, rub: 350 });
    expect(admin.webhook).toContain('/api/crypto/webhook');
  });
});
