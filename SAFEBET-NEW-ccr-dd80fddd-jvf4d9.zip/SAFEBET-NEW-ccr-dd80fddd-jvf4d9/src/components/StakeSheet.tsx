import { InventoryGrid, type InventoryItem } from './InventoryGrid';
import { Sheet } from './Sheet';
import { useMe } from '../api/queries';

/** Picks several brainrots for a stake (in order) from the player's inventory. */
export function StakeSheet({ open, onClose, picked, max, onToggle }: { open: boolean; onClose: () => void; picked: number[]; max: number; onToggle: (item: InventoryItem) => void }) {
  const me = useMe();
  return (
    <Sheet open={open} onClose={onClose} title={`Ставка — до ${max} брейнротов`}>
      <InventoryGrid items={me.inventory} selected={picked} onPick={onToggle} sortable />
      <button type="button" className="btn btn--primary btn--block stake-sheet__done" onClick={onClose}>
        Готово{picked.length ? ` · ${picked.length}/${max}` : ''}
      </button>
    </Sheet>
  );
}
