import { useQuery } from '@tanstack/react-query';
import { useEffect, useRef, useState, type FormEvent } from 'react';
import { BrainrotDeposit } from './BrainrotDeposit';
import { Coin } from './Coin';
import { Icon } from './Icon';
import { Sheet } from './Sheet';
import { Tabs } from './Tabs';
import { api, errorMessage } from '../api/client';
import { queryClient, useMe } from '../api/queries';
import type { DepositSection } from '../../shared/deposit';
import { STARS_MAX, STARS_MIN, depositBonus, starsToCoins } from '../../shared/stars';
import { rubToCoins } from '../../shared/crypto';
import { cx, formatCoins } from '../lib/format';
import { sfx } from '../lib/sound';
import { haptic, openInvoice, openTelegramLink } from '../lib/telegram';
import { useDebounced } from '../lib/useDebounced';
import { toast } from '../store/toast';
import { closeSheet, useUi } from '../store/ui';
import { DepositWagerNote } from './Wager';

type Tab = 'stars' | 'crypto' | DepositSection;

interface Invoice {
  orderId: number;
  link: string;
  stars: number;
  coins: number;
  bonus: number;
  percent: number;
}

interface OrderStatus {
  orderId: number;
  status: 'pending' | 'paid';
  stars: number;
  coins: number;
  bonus: number;
  percent: number;
}

type Phase =
  | { kind: 'form' }
  | { kind: 'confirming'; orderId: number; external: boolean }
  | { kind: 'done'; order: OrderStatus }
  | { kind: 'late' }
  | { kind: 'crypto'; orderId: number; url: string }
  | { kind: 'cryptoDone'; order: CryptoOrder };

export function DepositSheet() {
  const { sheet } = useUi();
  const open = sheet === 'deposit';
  const [tab, setTab] = useState<Tab>('stars');
  const [phase, setPhase] = useState<Phase>({ kind: 'form' });

  useEffect(() => {
    if (!open) {
      setPhase({ kind: 'form' });
      return;
    }
    // An open brainrot request (or a result the player hasn't seen) takes over the sheet.
    void queryClient
      .fetchQuery({ queryKey: ['itemDeposit'], queryFn: () => api<{ status: string } | null>('/api/item-deposits/current'), staleTime: 0 })
      .then((d) => {
        if (d && ['searching', 'trading'].includes(d.status)) setTab((t) => (t === 'stars' ? 'brainrots' : t));
      })
      .catch(() => {});
  }, [open]);

  return (
    <Sheet open={open} onClose={closeSheet} title="Пополнение баланса">
      {phase.kind === 'confirming' && <Confirming orderId={phase.orderId} external={phase.external} onPaid={(order) => setPhase({ kind: 'done', order })} onLate={() => setPhase({ kind: 'late' })} />}
      {phase.kind === 'done' && <Success order={phase.order} />}
      {phase.kind === 'crypto' && <CryptoWaiting orderId={phase.orderId} url={phase.url} onPaid={(order) => setPhase({ kind: 'cryptoDone', order })} onBack={() => setPhase({ kind: 'form' })} />}
      {phase.kind === 'cryptoDone' && <CryptoSuccess order={phase.order} />}
      {phase.kind === 'late' && (
        <div className="deposit-state">
          <span className="deposit-state__icon deposit-state__icon--wait">
            <Icon name="clock" size={34} />
          </span>
          <p className="deposit-state__title">Оплата обрабатывается</p>
          <p className="deposit-state__text">Монеты придут автоматически — бот пришлёт сообщение, как только Telegram подтвердит платёж.</p>
          <button type="button" className="btn btn--primary btn--lg btn--block" onClick={closeSheet}>
            Понятно
          </button>
        </div>
      )}
      {phase.kind === 'form' && (
        <>
          <Tabs
            label="Способ пополнения"
            value={tab}
            onChange={setTab}
            options={[
              { value: 'stars', label: 'Звёзды' },
              { value: 'crypto', label: 'Крипта' },
              { value: 'brainrots', label: 'Брейнроты' },
              { value: 'gears', label: 'Гирсы' },
            ]}
          />
          {tab === 'stars' ? (
            <StarsForm onInvoice={(orderId, external) => setPhase({ kind: 'confirming', orderId, external })} />
          ) : tab === 'crypto' ? (
            <CryptoForm onInvoice={(orderId, url) => setPhase({ kind: 'crypto', orderId, url })} />
          ) : (
            <BrainrotDeposit key={tab} section={tab} onClose={closeSheet} />
          )}
        </>
      )}
    </Sheet>
  );
}

const STAR_PRESETS = [50, 100, 250, 500, 1000];

interface PromoCheck {
  kind: 'auto' | 'partner';
  code: string;
  percent: number;
  partnerName: string | null;
}

function StarsForm({ onInvoice }: { onInvoice: (orderId: number, external: boolean) => void }) {
  const me = useMe();
  const [stars, setStars] = useState('');
  const [promo, setPromo] = useState(() => (me.promo.bonus?.status === 'active' ? me.promo.code : ''));
  const [error, setError] = useState<{ field: 'stars' | 'promo' | 'form'; text: string } | null>(null);
  const [busy, setBusy] = useState(false);

  const n = Number(stars);
  const valid = stars !== '' && Number.isInteger(n) && n >= STARS_MIN && n <= STARS_MAX;
  const coins = valid ? starsToCoins(n, me.starRate) : 0;
  const typed = promo.trim().replace(/\s+/g, ' ').toLowerCase();
  const matches = typed !== '' && typed === me.promo.code.toLowerCase();
  const promoUsed = matches && me.promo.bonus?.status === 'used';
  // Anything else may be a partner's code: the server says (+15 % on Stars, see PARTNER_DEPOSIT_PERCENT).
  const asked = useDebounced(typed, 400);
  const partner = useQuery({
    queryKey: ['deposit-promo', asked],
    queryFn: () => api<PromoCheck>(`/api/deposit-promo?via=stars&code=${encodeURIComponent(asked)}`),
    enabled: asked.length >= 2 && !matches,
    staleTime: 60_000,
    retry: false,
  });
  const partnerOk = !matches && asked === typed && partner.data?.kind === 'partner' ? partner.data : null;
  const partnerError = !matches && asked === typed && partner.isError ? errorMessage(partner.error) : null;
  const percent = matches && !promoUsed ? me.promo.percent : (partnerOk?.percent ?? 0);
  const bonus = depositBonus(coins, percent);

  async function submit(e: FormEvent) {
    e.preventDefault();
    if (!valid) {
      setError({ field: 'stars', text: `От ${formatCoins(STARS_MIN)} до ${formatCoins(STARS_MAX)} звёзд` });
      return;
    }
    setBusy(true);
    setError(null);
    try {
      const inv = await api<Invoice>('/api/stars/invoice', { body: { stars: n, promo: typed ? promo : undefined } });
      haptic('tap');
      const status = await openInvoice(inv.link);
      if (status === 'paid') {
        onInvoice(inv.orderId, false);
      } else if (status === 'pending') {
        onInvoice(inv.orderId, true);
      } else if (status === 'failed') {
        sfx.error();
        setError({ field: 'form', text: 'Оплата не прошла — попробуй ещё раз' });
      } else {
        toast('Оплата отменена');
      }
    } catch (err) {
      sfx.error();
      const text = errorMessage(err);
      setError({ field: /промокод/i.test(text) ? 'promo' : 'form', text });
    } finally {
      setBusy(false);
    }
  }

  return (
    <form className="form" onSubmit={submit} noValidate>
      <div className="stars-hero">
        <span className="stars-hero__badge" aria-hidden="true">
          <Icon name="star" size={26} />
        </span>
        <span>
          <span className="stars-hero__title">Telegram Stars</span>
          <span className="stars-hero__text">Монеты зачисляются сразу после оплаты</span>
        </span>
      </div>

      <div className="presets" role="group" aria-label="Быстрый выбор">
        {STAR_PRESETS.map((p) => (
          <button
            key={p}
            type="button"
            className={cx('chip', String(p) === stars && 'is-active')}
            onClick={() => {
              setStars(String(p));
              setError(null);
            }}
          >
            <Icon name="star" size={13} className="chip__star" /> {formatCoins(p)}
          </button>
        ))}
      </div>

      <label className="field">
        <span className="field__label">Количество звёзд</span>
        <span className="stars-calc">
          <span className={cx('field__control', error?.field === 'stars' && 'has-error')}>
            <Icon name="star" size={20} className="field__star" />
            <input
              inputMode="numeric"
              autoComplete="off"
              placeholder="Например: 100"
              value={stars}
              aria-invalid={error?.field === 'stars'}
              aria-describedby="stars-hint"
              onChange={(e) => {
                setStars(e.target.value.replace(/\D/g, '').slice(0, 5));
                setError(null);
              }}
            />
          </span>
          <span className={cx('stars-calc__result', !valid && 'is-empty')} aria-live="polite">
            = {valid ? formatCoins(coins) : '0'} <Coin size={20} />
          </span>
        </span>
        {error?.field === 'stars' ? (
          <span className="field__error">{error.text}</span>
        ) : (
          <span id="stars-hint" className="field__hint">
            1 ⭐ = {String(me.starRate).replace('.', ',')} B · от {STARS_MIN} до {formatCoins(STARS_MAX)} звёзд
          </span>
        )}
      </label>

      <label className="field">
        <span className="field__label">
          Промокод или код партнёра <span className="field__optional">(необязательно)</span>
        </span>
        <span className={cx('field__control', error?.field === 'promo' && 'has-error')}>
          <Icon name="tag" size={18} />
          <input
            autoComplete="off"
            autoCapitalize="characters"
            spellCheck={false}
            placeholder="PROMO"
            value={promo}
            maxLength={64}
            onChange={(e) => {
              setPromo(e.target.value);
              setError(null);
            }}
          />
        </span>
        {error?.field === 'promo' ? (
          <span className="field__error">{error.text}</span>
        ) : partnerError ? (
          <span className="field__error">{partnerError}</span>
        ) : (
          !typed && <span className="field__hint">Код партнёра даёт +15% к пополнению звёздами</span>
        )}
      </label>

      {percent > 0 && (
        <div className="promo-note promo-note--on" role="status">
          <Icon name="check" size={18} />
          <span>
            {partnerOk ? `Код партнёра принят${partnerOk.partnerName ? ` (${partnerOk.partnerName})` : ''} — +${percent}%` : `+${percent}% бонус`} — зачислится{' '}
            <b>{valid ? formatCoins(coins + bonus) : '…'}</b> <Coin size={15} />
          </span>
        </div>
      )}
      {promoUsed && <p className="form__note">Бонус этого промокода ты уже получил — счёт будет без бонуса, очисти поле.</p>}

      {error?.field === 'form' && (
        <p className="field__error field__error--block" role="alert">
          {error.text}
        </p>
      )}

      <DepositWagerNote rules={me.withdrawRules} />
      <button type="submit" className="btn btn--primary btn--lg btn--block" disabled={busy || !!me.user.frozen}>
        <Icon name="star" size={18} /> {busy ? 'Создаём счёт…' : 'Создать счёт в звёздах'}
      </button>
      <p className="form__note form__note--center">
        {me.user.frozen ? 'Аккаунт заморожен — пополнение недоступно.' : valid ? `Telegram попросит подтвердить оплату ${formatCoins(n)} ⭐` : 'Введи количество звёзд выше.'}
      </p>
    </form>
  );
}

/** Telegram has taken the stars; the webhook credits the coins a moment later, so wait for the order to flip to paid. */
function Confirming({ orderId, external, onPaid, onLate }: { orderId: number; external: boolean; onPaid: (o: OrderStatus) => void; onLate: () => void }) {
  const order = useQuery({
    queryKey: ['starOrder', orderId],
    queryFn: () => api<OrderStatus>(`/api/stars/orders/${orderId}`),
    refetchInterval: (q) => (q.state.data?.status === 'paid' ? false : 1200),
    staleTime: 0,
  });

  // Callbacks change identity on every parent render; keep the timers and effects pinned to the latest ones.
  const handlers = useRef({ onPaid, onLate });
  handlers.current = { onPaid, onLate };

  useEffect(() => {
    if (order.data?.status !== 'paid') return;
    void queryClient.invalidateQueries({ queryKey: ['me'] });
    handlers.current.onPaid(order.data);
  }, [order.data]);

  useEffect(() => {
    // An external invoice may be paid minutes later; an in-app "paid" lands within seconds.
    const t = setTimeout(() => handlers.current.onLate(), external ? 180_000 : 45_000);
    return () => clearTimeout(t);
  }, [external]);

  return (
    <div className="deposit-state" role="status">
      <span className="deposit-state__icon deposit-state__icon--spin" aria-hidden="true">
        <Icon name="star" size={32} />
      </span>
      <p className="deposit-state__title">{external ? 'Ждём оплату' : 'Подтверждаем оплату…'}</p>
      <p className="deposit-state__text">{external ? 'Оплати счёт в чате с ботом — баланс обновится сам.' : 'Обычно это занимает пару секунд.'}</p>
    </div>
  );
}

function Success({ order }: { order: OrderStatus }) {
  useEffect(() => {
    sfx.bigWin();
    haptic('success');
  }, []);
  return (
    <div className="deposit-state deposit-state--done">
      <span className="deposit-state__icon deposit-state__icon--done" aria-hidden="true">
        <Icon name="check" size={38} />
      </span>
      <p className="deposit-state__title">Баланс успешно пополнен</p>
      <p className="deposit-state__amount">
        +{formatCoins(order.coins + order.bonus)} <Coin size={26} />
      </p>
      <p className="deposit-state__text">
        {formatCoins(order.stars)} ⭐{order.bonus ? ` · бонус +${order.percent}% (${formatCoins(order.bonus)} B)` : ''}
      </p>
      <button type="button" className="btn btn--primary btn--lg btn--block" onClick={closeSheet} autoFocus>
        Отлично
      </button>
    </div>
  );
}



// ---------- Crypto (iteration 38): roubles → coins, paid in USDT / TON / BTC… through @CryptoBot ----------

interface CryptoInfo {
  enabled: boolean;
  rate: number;
  min: number;
  max: number;
  assets: string[];
  packs: { rub: number; coins: number }[];
}

interface CryptoOrder {
  orderId: number;
  status: 'pending' | 'paid' | 'expired';
  rub: number;
  coins: number;
}

const rub = (n: number) => `${formatCoins(n)} ₽`;

/** Opens CryptoBot's invoice: a t.me link stays inside Telegram, anything else in the browser. */
function openPay(url: string) {
  if (url.startsWith('https://t.me/')) openTelegramLink(url);
  else window.open(url, '_blank', 'noopener');
}

function CryptoForm({ onInvoice }: { onInvoice: (orderId: number, url: string) => void }) {
  const me = useMe();
  const info = useQuery({ queryKey: ['crypto'], queryFn: () => api<CryptoInfo>('/api/crypto'), staleTime: 60_000 });
  const [amount, setAmount] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const d = info.data;
  if (!d) return <div className="page-loading" aria-busy="true" />;
  if (!d.enabled) {
    return (
      <div className="deposit-state">
        <span className="deposit-state__icon deposit-state__icon--wait">
          <Icon name="crypto" size={32} />
        </span>
        <p className="deposit-state__title">Крипта скоро</p>
        <p className="deposit-state__text">Оплату криптой ещё подключают — пока пополняй звёздами или брейнротами.</p>
      </div>
    );
  }
  const n = Number(amount);
  const valid = amount !== '' && Number.isInteger(n) && n >= d.min && n <= d.max;
  const coins = valid ? rubToCoins(n, d.rate) : 0;

  async function submit(e: FormEvent) {
    e.preventDefault();
    if (!valid) {
      setError(`От ${rub(d!.min)} до ${rub(d!.max)}`);
      return;
    }
    setBusy(true);
    setError(null);
    try {
      const inv = await api<{ orderId: number; url: string }>('/api/crypto/invoice', { body: { rub: n } });
      haptic('tap');
      openPay(inv.url);
      onInvoice(inv.orderId, inv.url);
    } catch (err) {
      sfx.error();
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <form className="form" onSubmit={submit} noValidate>
      <div className="crypto-hero">
        <span className="crypto-hero__badge" aria-hidden="true">
          <Icon name="crypto" size={26} />
        </span>
        <span>
          <span className="crypto-hero__title">Криптовалюта</span>
          <span className="crypto-hero__text">Оплата через @CryptoBot · монеты придут сами</span>
        </span>
      </div>
      <ul className="crypto-assets" aria-label="Чем можно оплатить">
        {d.assets.map((a) => (
          <li key={a} className={`crypto-asset crypto-asset--${a.toLowerCase()}`}>
            {a}
          </li>
        ))}
      </ul>

      <div className="crypto-packs" role="group" aria-label="Сумма пополнения">
        {d.packs.map((p) => (
          <button
            key={p.rub}
            type="button"
            className={cx('crypto-pack', String(p.rub) === amount && 'is-active')}
            aria-pressed={String(p.rub) === amount}
            onClick={() => {
              setAmount(String(p.rub));
              setError(null);
            }}
          >
            <span className="crypto-pack__coins">
              {formatCoins(p.coins)} <Coin size={16} />
            </span>
            <span className="crypto-pack__rub">{rub(p.rub)}</span>
          </button>
        ))}
      </div>

      <label className="field">
        <span className="field__label">Своя сумма, ₽</span>
        <span className="stars-calc">
          <span className={cx('field__control', error && 'has-error')}>
            <span className="crypto-rub" aria-hidden="true">
              ₽
            </span>
            <input
              inputMode="numeric"
              autoComplete="off"
              placeholder="Например: 300"
              value={amount}
              aria-invalid={!!error}
              onChange={(e) => {
                setAmount(e.target.value.replace(/\D/g, '').slice(0, 6));
                setError(null);
              }}
            />
          </span>
          <span className={cx('stars-calc__result', !valid && 'is-empty')} aria-live="polite">
            = {valid ? formatCoins(coins) : '0'} <Coin size={20} />
          </span>
        </span>
        {error ? (
          <span className="field__error">{error}</span>
        ) : (
          <span className="field__hint">
            1 ₽ = {String(d.rate).replace('.', ',')} B · от {rub(d.min)} до {rub(d.max)} · курс монеты — по CryptoBot
          </span>
        )}
      </label>

      <DepositWagerNote rules={me.withdrawRules} />
      <button type="submit" className="btn btn--primary btn--lg btn--block" disabled={busy || !!me.user.frozen}>
        <Icon name="crypto" size={18} /> {busy ? 'Создаём счёт…' : valid ? `Оплатить ${rub(n)} криптой` : 'Оплатить криптой'}
      </button>
      <p className="form__note form__note--center">
        {me.user.frozen ? 'Аккаунт заморожен — пополнение недоступно.' : 'Откроется @CryptoBot: выбери монету и оплати — баланс пополнится сам.'}
      </p>
    </form>
  );
}

/** The player pays in CryptoBot; the order flips to paid by the webhook or the server's own check. */
function CryptoWaiting({ orderId, url, onPaid, onBack }: { orderId: number; url: string; onPaid: (o: CryptoOrder) => void; onBack: () => void }) {
  const order = useQuery({
    queryKey: ['cryptoOrder', orderId],
    queryFn: () => api<CryptoOrder>(`/api/crypto/orders/${orderId}`),
    refetchInterval: (q) => (q.state.data && q.state.data.status !== 'pending' ? false : 2500),
    staleTime: 0,
  });
  const handlers = useRef({ onPaid });
  handlers.current = { onPaid };
  useEffect(() => {
    if (order.data?.status !== 'paid') return;
    void queryClient.invalidateQueries({ queryKey: ['me'] });
    handlers.current.onPaid(order.data);
  }, [order.data]);
  const expired = order.data?.status === 'expired';
  return (
    <div className="deposit-state" role="status">
      <span className={cx('deposit-state__icon', expired ? 'deposit-state__icon--wait' : 'deposit-state__icon--spin')} aria-hidden="true">
        <Icon name="crypto" size={32} />
      </span>
      <p className="deposit-state__title">{expired ? 'Счёт истёк' : 'Ждём оплату в CryptoBot'}</p>
      <p className="deposit-state__text">
        {expired
          ? 'Счёт действовал час. Создай новый — это быстро.'
          : order.data
            ? `${rub(order.data.rub)} → ${formatCoins(order.data.coins)} B. Оплати счёт в @CryptoBot — баланс обновится сам, а бот пришлёт сообщение.`
            : 'Оплати счёт в @CryptoBot — баланс обновится сам.'}
      </p>
      {!expired && (
        <button type="button" className="btn btn--primary btn--lg btn--block" onClick={() => openPay(url)}>
          <Icon name="crypto" size={18} /> Открыть счёт ещё раз
        </button>
      )}
      <button type="button" className="btn btn--ghost btn--block" onClick={expired ? onBack : closeSheet}>
        {expired ? 'Новый счёт' : 'Закрыть — оплачу позже'}
      </button>
    </div>
  );
}

function CryptoSuccess({ order }: { order: CryptoOrder }) {
  useEffect(() => {
    sfx.bigWin();
    haptic('success');
  }, []);
  return (
    <div className="deposit-state deposit-state--done">
      <span className="deposit-state__icon deposit-state__icon--done" aria-hidden="true">
        <Icon name="check" size={38} />
      </span>
      <p className="deposit-state__title">Баланс успешно пополнен</p>
      <p className="deposit-state__amount">
        +{formatCoins(order.coins)} <Coin size={26} />
      </p>
      <p className="deposit-state__text">{rub(order.rub)} криптой</p>
      <button type="button" className="btn btn--primary btn--lg btn--block" onClick={closeSheet} autoFocus>
        Отлично
      </button>
    </div>
  );
}
