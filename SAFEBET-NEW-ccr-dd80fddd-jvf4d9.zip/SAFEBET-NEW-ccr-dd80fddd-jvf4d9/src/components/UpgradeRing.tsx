import { forwardRef, useEffect, useImperativeHandle, useRef, useState, type CSSProperties } from 'react';
import { Burst, Crack } from './Fx';
import { cx, formatChance } from '../lib/format';
import { sfx } from '../lib/sound';
import { haptic } from '../lib/telegram';

/** Skins with their own Blender art for the ring: only the current one's pictures are loaded. */
const skin = () => (typeof document === 'undefined' ? '' : document.documentElement.dataset.palette ?? '');

export interface UpgradeRingHandle {
  /** Spins the needle forward to `angle` (0° = top, clockwise) over `ms`, several full turns first. */
  spin(angle: number, ms: number, turns: number): Promise<void>;
}

interface Props {
  chance: number | null;
  multiplier: number | null;
  result: 'win' | 'lose' | null;
}

const TICK_DEG = 7.5;
/**
 * Cubic ease-out, like a wheel that is braking: the needle still covers most of a turn in the last half of the spin,
 * so it crawls past the marks to the very end instead of stopping dead early.
 */
const easeOut = (t: number) => 1 - (1 - t) ** 3;

/** A number that glides to its new value instead of jumping (the chance in the middle of the ring). */
function useGlide(value: number | null, ms = 380) {
  const [shown, setShown] = useState(value);
  const from = useRef(value);
  useEffect(() => {
    if (value === null || from.current === null) {
      from.current = value;
      setShown(value);
      return;
    }
    const start = performance.now();
    const a = from.current;
    let frame = 0;
    const loop = (now: number) => {
      const k = Math.min(1, (now - start) / ms);
      const v = a + (value - a) * (1 - (1 - k) ** 3);
      from.current = v;
      setShown(v);
      if (k < 1) frame = requestAnimationFrame(loop);
    };
    frame = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(frame);
  }, [value, ms]);
  return shown;
}

/**
 * Plain HTML ring: a conic-gradient arc for the win chance and a needle turned frame by frame.
 * (The previous SVG version animated a CSS transform on an SVG group, which stutters in Android WebView.)
 */
export const UpgradeRing = forwardRef<UpgradeRingHandle, Props>(function UpgradeRing({ chance, multiplier, result }, ref) {
  const needle = useRef<HTMLDivElement>(null);
  const root = useRef<HTMLDivElement>(null);
  const shownChance = useGlide(chance);
  const angle = useRef(0);
  const frame = useRef(0);
  const spinning = useRef(false);
  const [art] = useState(skin);

  useEffect(() => () => cancelAnimationFrame(frame.current), []);

  useImperativeHandle(ref, () => ({
    spin(target, ms, turns) {
      cancelAnimationFrame(frame.current);
      const from = angle.current;
      const base = from - (from % 360);
      const to = base + turns * 360 + target;
      const started = performance.now();
      let lastTick = Math.floor(from / TICK_DEG);
      let lastA = from;
      let lastT = started;
      // Fastest at the start: 3 × the distance per duration with this easing.
      const top = (3 * (to - from)) / ms;
      spinning.current = true;
      root.current?.classList.add('is-spinning');
      return new Promise((resolve) => {
        const step = (now: number) => {
          const t = Math.min(1, (now - started) / ms);
          const a = from + (to - from) * easeOut(t);
          const speed = Math.min(1, (a - lastA) / Math.max(1, now - lastT) / top);
          lastA = a;
          lastT = now;
          angle.current = a;
          if (needle.current) needle.current.style.transform = `rotate(${a}deg)`;
          // The glowing trail behind the needle stretches with the speed.
          root.current?.style.setProperty('--needle', `${a % 360}deg`);
          root.current?.style.setProperty('--trail', `${8 + speed * 120}deg`);
          const tick = Math.floor(a / TICK_DEG);
          if (tick !== lastTick) {
            lastTick = tick;
            sfx.reelTick(speed);
            if (speed < 0.12) haptic('select');
          }
          if (t < 1) frame.current = requestAnimationFrame(step);
          else {
            spinning.current = false;
            root.current?.classList.remove('is-spinning');
            resolve();
          }
        };
        frame.current = requestAnimationFrame(step);
      });
    },
  }));

  const style = { '--chance': `${(chance ?? 0) * 360}deg` } as CSSProperties;

  return (
    <div className={cx('uring', chance === null && 'is-empty', result && `is-${result}`)} style={style} ref={root}>
      {/* Halloween: a Blender stone circle and wand. Crash: no picture under it — a compact gauge drawn in CSS. */}
      {art === 'halloween' && <img className="uring__plate" src="/upgrader/plate.webp" alt="" aria-hidden="true" />}
      <span className="uring__halo" aria-hidden="true" />
      <span className="uring__track" aria-hidden="true" />
      <span className="uring__bezel" aria-hidden="true" />
      <span className="uring__arc" aria-hidden="true" />
      <span className="uring__trail" aria-hidden="true" />
      <span className="uring__ticks" aria-hidden="true" />
      <span className="uring__marks" aria-hidden="true">
        {[0, 25, 50, 75].map((p) => {
          const a = (p / 100) * 2 * Math.PI;
          return (
            <span key={p} style={{ left: `${50 + 46.5 * Math.sin(a)}%`, top: `${50 - 46.5 * Math.cos(a)}%` }}>
              {p}
            </span>
          );
        })}
      </span>
      <div className="uring__needle" ref={needle} aria-hidden="true">
        <span />
        {art === 'halloween' && <img className="uring__wand" src="/upgrader/wand.webp" alt="" />}
        <i className="uring__tip" />
        <i className="uring__spark" />
      </div>
      {result && (
        <span key={result} className={cx('uring__fx', `uring__fx--${result}`)} aria-hidden="true">
          <span className="uring__flash" />
          {result === 'lose' && <Crack className="uring__crack" seed={Math.round((chance ?? 0.5) * 1000)} />}
          <Burst count={result === 'win' ? 34 : 18} spread={result === 'win' ? 1.3 : 0.9} className={result === 'lose' ? 'fx-burst--shards' : undefined} />
        </span>
      )}
      <div className="uring__core">
        {/* Crash: our BC mark in the middle (the owner's reference gauge), the chance under it. */}
        {art === 'crash' && <img className="uring__logo" src="/logo-bc-256.webp" alt="" aria-hidden="true" />}
        <span className="uring__chance" aria-live="polite">
          {shownChance === null ? (art === 'crash' ? '?%' : '—') : formatChance(shownChance)}
        </span>
        <span className="uring__label">
          {result === 'win' ? 'выигрыш!' : result === 'lose' ? 'не повезло' : shownChance === null && art === 'crash' ? 'ожидание ставки' : 'шанс'}
        </span>
        {multiplier !== null && <span className="uring__mult">x{multiplier.toFixed(multiplier < 10 ? 2 : 1)}</span>}
      </div>
    </div>
  );
});
