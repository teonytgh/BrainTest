import { Avatar } from './Avatar';
import { Coin } from './Coin';
import { Icon, type IconName } from './Icon';
import { MediaBadge } from './MediaBadge';
import { Sheet } from './Sheet';
import { useCatalog, useMe } from '../api/queries';
import { cx, formatCoins } from '../lib/format';
import { routeHref, useRoute, type RouteName } from '../lib/router';
import { closeMenu, openSheet, useUi } from '../store/ui';
import { openTelegramLink } from '../lib/telegram';
import { SUPPORT_URL } from '../../shared/links';

export const NAV: { route: RouteName; label: string; icon: IconName; soon?: boolean; fresh?: boolean }[] = [
  { route: 'home', label: 'Главная', icon: 'home' },
  { route: 'upgrader', label: 'Апгрейдер', icon: 'gauge' },
  { route: 'battle', label: 'Батлы', icon: 'shield' },
  { route: 'dice', label: 'Дайсы', icon: 'dice' },
  { route: 'crash', label: 'Краш', icon: 'rocket' },
  { route: 'mines', label: 'Мины', icon: 'bomb', fresh: true },
  { route: 'road', label: 'Дорога', icon: 'road', fresh: true },
  { route: 'fuse', label: 'FUSE', icon: 'fuse', fresh: true },
  { route: 'bonuses', label: 'Бонусы', icon: 'gift' },
  { route: 'quests', label: 'Задания', icon: 'quests', fresh: true },
  { route: 'pass', label: 'Батл пасс', icon: 'trophy', fresh: true },
  { route: 'giveaways', label: 'Розыгрыши', icon: 'trophy', fresh: true },
  { route: 'faq', label: 'FAQ', icon: 'help' },
  { route: 'referrals', label: 'Рефералы', icon: 'users' },
];

export function SideMenu() {
  const { menuOpen } = useUi();
  return (
    <Sheet open={menuOpen} onClose={closeMenu} title="Меню" variant="drawer">
      <MenuContent />
    </Sheet>
  );
}

/** PC layout: the same menu, always visible on the left. */
export function Sidebar() {
  return (
    <aside className="sidebar" aria-label="Меню">
      <MenuContent />
    </aside>
  );
}

function MenuContent() {
  const me = useMe();
  const { user } = me;
  const route = useRoute();
  const { sky, squid } = useCatalog();

  return (
    <>
      <div className="profile">
        <a className="profile__row" href={routeHref('profile')} onClick={closeMenu}>
          <Avatar user={user} size={56} />
          <span className="profile__who">
            <span className="profile__source">
              Telegram <Icon name="check" size={14} />
            </span>
            <span className="profile__name">{user.username ? `@${user.username}` : user.name}</span>
            {user.media && <MediaBadge platform={user.media} />}
          </span>
          <span className="profile__go">
            <span className="visually-hidden">Профиль и инвентарь</span>
            <Icon name="chevronRight" />
          </span>
        </a>
        <div className="profile__balance">
          <a className={cx('profile__coins', formatCoins(user.balance).length > 6 && 'is-long', formatCoins(user.balance).length > 9 && 'is-longer')} href={routeHref('profile')} onClick={closeMenu}>
            <Coin size={22} />
            {formatCoins(user.balance)}
          </a>
          <button type="button" className="btn btn--primary btn--sm" onClick={() => openSheet('deposit')} data-private="money">
            Пополнить
          </button>
        </div>
      </div>

      <nav aria-label="Разделы">
        <ul className="nav">
          {sky && sky.endsAt > Date.now() && (
            <li>
              <a href={routeHref('sky')} className="nav__link nav__link--sky" aria-current={route.name === 'sky' ? 'page' : undefined} onClick={closeMenu}>
                <img className="nav__icon nav__sky" src="/sky/meowl-face.webp" alt="" />
                <span>Небо Meowl</span>
                <span className="nav__soon nav__live">live</span>
              </a>
            </li>
          )}
          {squid && (
            <li>
              <a href={routeHref('squid')} className="nav__link nav__link--squid" aria-current={route.name === 'squid' ? 'page' : undefined} onClick={closeMenu}>
                <img className="nav__icon nav__sky" src="/squid/watcher-red.webp" alt="" />
                <span>Игра Кальмара</span>
                <span className="nav__soon nav__live">live</span>
              </a>
            </li>
          )}
          {NAV.map((item) => (
            <li key={item.route}>
              <a href={routeHref(item.route)} className="nav__link" aria-current={route.name === item.route ? 'page' : undefined} onClick={closeMenu}>
                <Icon name={item.icon} className="nav__icon" />
                <span>{item.label}</span>
                {item.soon && <span className="nav__soon">скоро</span>}
                {item.fresh && <span className="nav__soon nav__event">new</span>}
              </a>
            </li>
          ))}
          <li>
            <button
              type="button"
              className="nav__link"
              onClick={() => {
                closeMenu();
                openTelegramLink(SUPPORT_URL);
              }}
            >
              <Icon name="chat" className="nav__icon" />
              <span>Поддержка</span>
            </button>
          </li>
          {user.isAdmin && (
            <li>
              <a href={routeHref('admin')} className="nav__link nav__link--admin" aria-current={route.name === 'admin' ? 'page' : undefined} onClick={closeMenu}>
                <Icon name="shield" className="nav__icon" />
                <span>Админ-панель</span>
              </a>
            </li>
          )}
        </ul>
      </nav>
    </>
  );
}
