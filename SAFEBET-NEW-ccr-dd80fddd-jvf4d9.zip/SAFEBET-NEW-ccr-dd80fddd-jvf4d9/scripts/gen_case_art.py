"""Draws our own case art (SVG chests in the BrainrotCrash style), one colourway per case.

Usage: python3 scripts/gen_case_art.py   → public/cases/<id>.svg
The UI layers the most valuable brainrot of the case behind the lid (see src/components/CaseArt.tsx).
"""
import math
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, 'public', 'cases')

# id → (hue, chroma, metal, sparkles)
CASES = {
    'free': (150, 0.15, 'silver', 1),
    'noobini': (255, 0.13, 'silver', 1),
    'petrosyan': (32, 0.15, 'silver', 1),
    'random': (300, 0.14, 'silver', 1),
    'lucky': (142, 0.16, 'gold', 2),
    'toxic': (125, 0.17, 'silver', 2),
    'moon': (235, 0.07, 'silver', 2),
    'lavaka': (45, 0.17, 'gold', 2),
    'crazy': (345, 0.17, 'silver', 2),
    'pro': (262, 0.16, 'gold', 3),
    'mystery': (295, 0.16, 'gold', 3),
    'neon': (200, 0.13, 'silver', 3),
    'meteor': (58, 0.16, 'gold', 3),
    'phantom': (280, 0.11, 'silver', 3),
    'overdrive': (24, 0.18, 'gold', 4),
    'chaos': (330, 0.18, 'gold', 4),
    'elite': (86, 0.13, 'gold', 4),
    'dragon': (160, 0.13, 'gold', 4),
    'hell': (22, 0.19, 'dark', 5),
    'secret': (270, 0.05, 'gold', 5),
    'og': (72, 0.15, 'gold', 6),
    'referral': (40, 0.17, 'gold', 3),
    'nick': (292, 0.17, 'gold', 3),
    'consolation': (205, 0.11, 'silver', 2),
}

METALS = {
    'silver': ((0.93, 0.01, 250), (0.66, 0.02, 250)),
    'gold': ((0.92, 0.09, 92), (0.68, 0.12, 70)),
    'dark': ((0.52, 0.03, 30), (0.26, 0.02, 30)),
}


def hexc(L, C, h):
    a, b = C * math.cos(math.radians(h)), C * math.sin(math.radians(h))
    l_, m_, s_ = L + 0.3963377774 * a + 0.2158037573 * b, L - 0.1055613458 * a - 0.0638541728 * b, L - 0.0894841775 * a - 1.2914855480 * b
    l, m, s = l_ ** 3, m_ ** 3, s_ ** 3
    rgb = (4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s,
           -1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s,
           -0.0041960863 * l - 0.7034186147 * m + 1.7076147010 * s)

    def ch(x):
        x = max(0.0, min(1.0, x))
        return round(255 * (12.92 * x if x <= 0.0031308 else 1.055 * x ** (1 / 2.4) - 0.055))
    return '#%02x%02x%02x' % tuple(ch(x) for x in rgb)


SPARKS = [(78, 132, 1.0), (430, 120, 0.8), (446, 300, 0.6), (64, 330, 0.7), (380, 70, 0.55), (120, 70, 0.6)]


def spark(x, y, k, color):
    r, w = 22 * k, 6 * k
    return (f'<path d="M{x} {y - r}Q{x + w * 0.4} {y - w * 0.4} {x + r} {y}Q{x + w * 0.4} {y + w * 0.4} {x} {y + r}'
            f'Q{x - w * 0.4} {y + w * 0.4} {x - r} {y}Q{x - w * 0.4} {y - w * 0.4} {x} {y - r}Z" fill="{color}"/>')


def svg(hue, chroma, metal, sparkles):
    accent = hexc(0.74, chroma, hue)
    lid_top, lid_bottom = hexc(0.64, chroma * 0.92, hue), hexc(0.48, chroma, hue)
    body_top, body_bottom = hexc(0.42, chroma, hue), hexc(0.24, chroma * 0.7, hue)
    rim = hexc(0.34, chroma * 0.85, hue)
    edge = hexc(0.16, 0.035, hue)
    deep = hexc(0.17, 0.03, 258)
    spark_c = hexc(0.96, min(chroma, 0.08), hue)
    m_light, m_dark = (hexc(*c) for c in METALS[metal])
    rivets = ''.join(f'<circle cx="{x}" cy="{y}" r="5" fill="{m_dark}" stroke="{edge}" stroke-width="2"/>'
                     for x in (165, 347) for y in (176, 270, 392))
    return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
<defs>
<radialGradient id="g" cx="50%" cy="48%" r="50%"><stop offset="0" stop-color="{accent}" stop-opacity=".6"/><stop offset=".5" stop-color="{accent}" stop-opacity=".16"/><stop offset="1" stop-color="{accent}" stop-opacity="0"/></radialGradient>
<linearGradient id="lid" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="{lid_top}"/><stop offset="1" stop-color="{lid_bottom}"/></linearGradient>
<linearGradient id="body" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="{body_top}"/><stop offset="1" stop-color="{body_bottom}"/></linearGradient>
<linearGradient id="m" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="{m_dark}"/><stop offset=".45" stop-color="{m_light}"/><stop offset="1" stop-color="{m_dark}"/></linearGradient>
</defs>
<ellipse cx="256" cy="250" rx="250" ry="228" fill="url(#g)"/>
<ellipse cx="256" cy="440" rx="170" ry="22" fill="#000" opacity=".42"/>
<rect x="92" y="228" width="328" height="202" rx="28" fill="url(#body)" stroke="{edge}" stroke-width="5"/>
<rect x="114" y="252" width="284" height="156" rx="18" fill="none" stroke="{accent}" stroke-opacity=".38" stroke-width="3"/>
<path d="M108 232 126 160Q130 144 147 144H365Q382 144 386 160L404 232Z" fill="url(#lid)" stroke="{edge}" stroke-width="5" stroke-linejoin="round"/>
<path d="M134 162H378L382 178H130Z" fill="#fff" opacity=".2"/>
<rect x="82" y="212" width="348" height="32" rx="13" fill="{rim}" stroke="{edge}" stroke-width="5"/>
<rect x="88" y="216" width="336" height="8" rx="4" fill="#fff" opacity=".14"/>
<rect x="150" y="146" width="30" height="282" rx="7" fill="url(#m)" stroke="{edge}" stroke-width="3"/>
<rect x="332" y="146" width="30" height="282" rx="7" fill="url(#m)" stroke="{edge}" stroke-width="3"/>
{rivets}
<circle cx="256" cy="322" r="60" fill="{deep}" stroke="url(#m)" stroke-width="8"/>
<circle cx="256" cy="322" r="49" fill="none" stroke="{accent}" stroke-opacity=".5" stroke-width="2"/>
<g transform="translate(256 322) scale(2.55) translate(-16 -16)">
<path fill="#e5484d" d="M15.2 6c-2.4-.8-4.8.2-5.6 2.2-2.2.2-3.8 2.2-3.4 4.4-1.6 1-2.2 3.2-1.2 5-.6 2 .4 4.2 2.4 5 .4 2.2 2.6 3.8 4.8 3.4 1 .8 2 1 3 .8z"/>
<path fill="#3b82f6" d="M16.8 6c2.4-.8 4.8.2 5.6 2.2 2.2.2 3.8 2.2 3.4 4.4 1.6 1 2.2 3.2 1.2 5 .6 2-.4 4.2-2.4 5-.4 2.2-2.6 3.8-4.8 3.4-1 .8-2 1-3 .8z"/>
<path fill="none" stroke="#fff" stroke-opacity=".9" stroke-width="1.4" stroke-linecap="round" d="M9.6 8.2c1 1.4 2.4 1.8 3.4 1.4M6.2 12.6c1.8.6 3.4.2 4.4-.8M5 17.6c1.6-.4 3 0 4 1.2M7.4 22.6c1.4-.6 2.4-1.8 2.6-3.2M22.4 8.2c-1 1.4-2.4 1.8-3.4 1.4M25.8 12.6c-1.8.6-3.4.2-4.4-.8M27 17.6c-1.6-.4-3 0-4 1.2M24.6 22.6c-1.4-.6-2.4-1.8-2.6-3.2"/>
</g>
<rect x="232" y="196" width="48" height="56" rx="11" fill="url(#m)" stroke="{edge}" stroke-width="4"/>
<circle cx="256" cy="218" r="7" fill="{edge}"/><rect x="252.5" y="220" width="7" height="16" rx="3.5" fill="{edge}"/>
{''.join(spark(x, y, k, spark_c) for x, y, k in SPARKS[:sparkles])}
</svg>
'''


def main():
    os.makedirs(OUT, exist_ok=True)
    for cid, spec in CASES.items():
        with open(os.path.join(OUT, f'{cid}.svg'), 'w', encoding='utf-8') as fh:
            fh.write(svg(*spec))
    print(len(CASES), 'cases ->', OUT)


main()
