-- Mystery cases hide the reel until the drop lands.
ALTER TABLE cases ADD COLUMN mystery BOOLEAN NOT NULL DEFAULT false;
UPDATE cases SET mystery = true WHERE id = 'mystery';

-- Free openings granted by admins ("подарочные кейсы").
CREATE TABLE case_keys (
  user_id BIGINT NOT NULL REFERENCES users (id),
  case_id TEXT NOT NULL REFERENCES cases (id) ON DELETE CASCADE,
  count INT NOT NULL CHECK (count >= 0),
  PRIMARY KEY (user_id, case_id)
);

-- Deposits paid with brainrots through a Roblox trade, driven by admins from the bot.
CREATE TABLE item_deposits (
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT NOT NULL REFERENCES users (id),
  items JSONB NOT NULL,
  value NUMERIC(16, 2) NOT NULL,
  bonus NUMERIC(16, 2) NOT NULL DEFAULT 0,
  bonus_percent INT NOT NULL DEFAULT 0,
  promo_window BIGINT,
  roblox_nick TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'searching' CHECK (status IN ('searching', 'trading', 'credited', 'rejected', 'expired', 'cancelled')),
  bot_nick TEXT,
  trade_deadline TIMESTAMPTZ,
  credited NUMERIC(16, 2),
  handled_by BIGINT,
  admin_messages JSONB NOT NULL DEFAULT '[]',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX item_deposits_user ON item_deposits (user_id, id DESC);
CREATE UNIQUE INDEX item_deposits_one_open ON item_deposits (user_id) WHERE status IN ('searching', 'trading');

-- 1v1 case battles. case_id has no foreign key so deleting a case keeps the history.
CREATE TABLE battles (
  id BIGSERIAL PRIMARY KEY,
  case_id TEXT NOT NULL,
  case_name TEXT NOT NULL,
  price NUMERIC(16, 2) NOT NULL,
  creator_id BIGINT NOT NULL REFERENCES users (id),
  opponent_id BIGINT REFERENCES users (id),
  status TEXT NOT NULL DEFAULT 'waiting' CHECK (status IN ('waiting', 'finished', 'solo', 'cancelled')),
  rounds JSONB NOT NULL DEFAULT '[]',
  winner_id BIGINT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  started_at TIMESTAMPTZ,
  finished_at TIMESTAMPTZ
);
CREATE INDEX battles_waiting ON battles (created_at) WHERE status = 'waiting';

INSERT INTO settings (key, value) VALUES
  ('luck', '{"until": null}'),
  ('trade_bots', '[]')
ON CONFLICT (key) DO NOTHING;
