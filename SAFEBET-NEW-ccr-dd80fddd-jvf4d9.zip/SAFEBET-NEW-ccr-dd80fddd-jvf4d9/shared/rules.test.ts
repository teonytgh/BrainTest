import { describe, expect, it } from 'vitest';
import { SEED_BRAINROTS as BRAINROTS, seedBrainrot as getBrainrot } from './seed';
import { CASE_RTP, FREE_CASE_EV, MIN_RTP, PROFIT_SHARE, autoChances, composeCase, solveChances, suggestCasePrice } from './cases';
import { round2 } from './money';
import { payoutFor } from './payout';
import { UPGRADE_RTP, pointerAngle, rollUpgrade, targetForChance, targetForMultiplier, upgradeChance, upgradeTargets } from './upgrader';
import { countMatches, diceMultiplier, rollDice } from './dice';
import { generateCrashPoint, msToReach, multiplierAt, parseAutoCashout } from './crash';
import { PROMO_MAX_PERCENT, PROMO_MIN_PERCENT, PROMO_WINDOW_MS, currentPromo, promoForWindow } from './promo';
import { seededRandom } from './random';

const garama = getBrainrot('garama-and-madundung');
const moby = getBrainrot('capitano-moby');
const burguro = getBrainrot('burguro-and-fryuro');

describe('payout', () => {
  it('pays Burguro and Fryuro (90) for Garama (45) x2', () => {
    expect(payoutFor(garama.price * 2, BRAINROTS)).toEqual({ brainrot: burguro, coins: 0, value: 90 });
  });

  it('pays the closest cheaper brainrot plus coin change', () => {
    const p = payoutFor(110, BRAINROTS);
    expect(p.brainrot).toEqual(moby);
    expect(p.coins).toBe(5);
  });

  it('keeps kopecks: 188.17 pays Guest 666 (188.10) plus 0.07', () => {
    const p = payoutFor(188.179, BRAINROTS);
    expect(p).toMatchObject({ brainrot: { id: 'guest-666' }, coins: 0.07, value: 188.17 });
  });

  it('pays only coins below the cheapest brainrot', () => {
    expect(payoutFor(5, BRAINROTS)).toEqual({ brainrot: null, coins: 5, value: 5 });
  });

  it('never pays more than the value', () => {
    for (let v = 0; v < 60000; v += 137) {
      const p = payoutFor(v, BRAINROTS);
      expect(round2((p.brainrot?.price ?? 0) + p.coins)).toBe(v);
    }
  });
});

describe('upgrader', () => {
  it('chance is the price ratio times the 80 % payback (the shown chance is the rolled one)', () => {
    expect(upgradeChance(50, 100)).toBeCloseTo(0.5 * UPGRADE_RTP, 10);
    expect(UPGRADE_RTP).toBe(0.8);
  });

  it('targets are strictly more expensive', () => {
    expect(upgradeTargets(100, BRAINROTS).every((b) => b.price > 100)).toBe(true);
  });

  it('x2 from Garama finds Capitano Moby', () => {
    expect(targetForMultiplier(50, 2, BRAINROTS)?.id).toBe('capitano-moby');
  });

  it('asking for 50% finds the target whose real chance is closest to 50%', () => {
    const t = targetForChance(50, 0.5, BRAINROTS)!;
    const best = Math.min(...upgradeTargets(50, BRAINROTS).map((b) => Math.abs(Math.log(upgradeChance(50, b.price) / 0.5))));
    expect(Math.abs(Math.log(upgradeChance(50, t.price) / 0.5))).toBeCloseTo(best, 10);
  });

  it('no target above the most expensive brainrot', () => {
    expect(targetForMultiplier(BRAINROTS.at(-1)!.price, 2, BRAINROTS)).toBeNull();
  });

  it('roll wins below the chance', () => {
    expect(rollUpgrade(0.5, () => 0.49).win).toBe(true);
    expect(rollUpgrade(0.5, () => 0.5).win).toBe(false);
  });

  it('pointer lands inside the correct zone', () => {
    const rng = seededRandom(7);
    for (let i = 0; i < 2000; i++) {
      const chance = 0.02 + rng() * 0.95;
      const roll = rng();
      const angle = pointerAngle(roll, chance);
      if (roll < chance) expect(angle).toBeLessThan(chance * 360);
      else expect(angle).toBeGreaterThan(chance * 360);
      expect(angle).toBeGreaterThanOrEqual(0);
      expect(angle).toBeLessThanOrEqual(360);
    }
  });
});

describe('dice', () => {
  it('pays x2 for one match, x3 for four, nothing otherwise', () => {
    expect([0, 1, 2, 3, 4].map(diceMultiplier)).toEqual([0, 2, 0, 0, 3]);
  });

  it('counts matches', () => {
    expect(countMatches(['red', 'blue', 'red', 'green'], 'red')).toBe(2);
  });

  it('rolls four valid colors', () => {
    const roll = rollDice(seededRandom(1));
    expect(roll).toHaveLength(4);
  });
});

describe('crash', () => {
  it('reaches x2 in 8 seconds, then x5 and x10 on the same exponential pace', () => {
    expect(msToReach(2)).toBeCloseTo(8000, 0);
    expect(msToReach(3) - msToReach(2)).toBeLessThan(8000);
    expect(msToReach(10) / 1000).toBeCloseTo(26.6, 1);
    expect(multiplierAt(0)).toBe(1);
  });

  it('about half of rockets reach x2', () => {
    const rng = seededRandom(42);
    const n = 200000;
    let reached = 0;
    for (let i = 0; i < n; i++) if (generateCrashPoint(rng) >= 2) reached++;
    expect(reached / n).toBeGreaterThan(0.46);
    expect(reached / n).toBeLessThan(0.5);
  });

  it('crash point is at least 1', () => {
    expect(generateCrashPoint(() => 0)).toBe(1);
  });

  it('parses auto cashout', () => {
    expect(parseAutoCashout('2')).toBe(2);
    expect(parseAutoCashout('1,5')).toBe(1.5);
    expect(parseAutoCashout('1')).toBeNull();
    expect(parseAutoCashout('abc')).toBeNull();
    expect(parseAutoCashout('101')).toBeNull();
  });
});

describe('promo', () => {
  it('keeps the bonus between 5 and 15 percent', () => {
    for (let i = 0; i < 5000; i++) {
      const { percent } = promoForWindow(i);
      expect(percent).toBeGreaterThanOrEqual(PROMO_MIN_PERCENT);
      expect(percent).toBeLessThanOrEqual(PROMO_MAX_PERCENT);
    }
  });

  it('uses every percent value', () => {
    const seen = new Set(Array.from({ length: 5000 }, (_, i) => promoForWindow(i).percent));
    expect(seen.size).toBe(PROMO_MAX_PERCENT - PROMO_MIN_PERCENT + 1);
  });

  it('is stable within a window and changes after 2 hours', () => {
    const start = 1000 * PROMO_WINDOW_MS;
    expect(currentPromo(start)).toEqual(currentPromo(start + PROMO_WINDOW_MS - 1));
    expect(currentPromo(start + PROMO_WINDOW_MS).windowIndex).toBe(1001);
    expect(currentPromo(start).endsAt).toBe(start + PROMO_WINDOW_MS);
  });
});

describe('auto case chances', () => {
  const prices = [26, 38, 45, 60, 71, 80, 86, 90, 95, 98, 105, 151, 233.7, 500, 961.4, 6720];
  const casePrice = 99;
  const ev = (probs: number[]) => prices.reduce((s, p, i) => s + p * probs[i]!, 0);
  const profit = (probs: number[]) => probs.reduce((s, p, i) => s + (prices[i]! > casePrice ? p : 0), 0);

  it('averages 88% of the price with a 2% chance to profit', () => {
    const s = solveChances(prices, casePrice);
    expect(s.ok).toBe(true);
    expect(s.probs.reduce((a, b) => a + b, 0)).toBeCloseTo(1, 9);
    expect(ev(s.probs)).toBeCloseTo(casePrice * CASE_RTP, 2);
    expect(profit(s.probs)).toBeCloseTo(PROFIT_SHARE, 6);
    expect(PROFIT_SHARE).toBe(0.02);
  });

  it('the pricier the profit, the rarer; no item swallows the reel', () => {
    const probs = autoChances(prices, casePrice);
    const p = probs.slice(prices.findIndex((x) => x > casePrice));
    expect(p.every((x, i) => i === 0 || x <= p[i - 1]!)).toBe(true);
    expect(Math.max(...probs)).toBeLessThanOrEqual(0.6 + 1e-9);
  });

  it('x2 luck doubles the profit chance without raising the average drop', () => {
    const lucky = autoChances(prices, casePrice, 2);
    expect(profit(lucky)).toBeCloseTo(PROFIT_SHARE * 2, 6);
    expect(ev(lucky)).toBeCloseTo(casePrice * CASE_RTP, 2);
  });

  it('free case pays a fixed average', () => {
    const free = [8, 12, 18, 22, 25, 28, 35, 42, 54, 90, 180];
    const probs = autoChances(free, 0);
    expect(free.reduce((s, p, i) => s + p * probs[i]!, 0)).toBeCloseTo(FREE_CASE_EV, 2);
  });

  it('a case whose items all cost more than the case is flagged and never pays out below cost silently', () => {
    const s = solveChances([45, 71, 83.6, 90], 32);
    expect(s.ok).toBe(false);
    expect(s.rtp).toBeGreaterThan(1);
  });

  it('a case whose cheap items sit right under the price cannot keep its окуп chance → flagged', () => {
    const s = solveChances([80, 85, 90, 95, 400, 600], 100);
    expect(s.profit).toBeLessThan(PROFIT_SHARE * 0.75);
    expect(s.ok).toBe(false);
  });

  it('with nothing near the price the average drops instead of the profit chance rising', () => {
    const s = solveChances([10, 12, 15, 20, 400], 100);
    expect(s.ok).toBe(false);
    expect(s.profit).toBeCloseTo(PROFIT_SHARE, 6);
    expect(s.rtp).toBeLessThan(MIN_RTP);
  });
});

describe('case composition', () => {
  const catalog = [4, 8, 11, 12, 13, 15, 18, 22, 25, 28, 35, 37, 39, 42, 45, 54, 60, 71, 90, 135, 180, 380, 965].map((price, i) => ({ id: `b${i}`, price }));
  const priceOf = new Map(catalog.map((b) => [b.id, b.price]));

  it('rebuilds a case that was re-priced into a loss, keeping items that still fit', () => {
    const current = ['b14', 'b17', 'b18', 'b22']; // 45, 71, 90, 965 in a 32 B case: everything costs more than the case
    expect(solveChances(current.map((id) => priceOf.get(id)!), 32).ok).toBe(false);
    const next = composeCase(catalog, 32, current);
    const prices = next.ids.map((id) => priceOf.get(id)!);
    const s = solveChances(prices, 32);
    expect(next.ok).toBe(true);
    expect(s.rtp).toBeGreaterThanOrEqual(MIN_RTP);
    expect(s.rtp).toBeLessThanOrEqual(0.9);
    expect(prices.filter((p) => p <= 32).length).toBeGreaterThanOrEqual(4);
    expect(next.ids).toContain('b14'); // 45 B still fits as a rare profit item
  });

  it('suggests a working price when the catalog has a gap below the case price', () => {
    const gappy = [10, 12, 14, 16, 18, 20, 22, 24, 26, 400, 800].map((price, i) => ({ id: `g${i}`, price }));
    expect(composeCase(gappy, 60).ok).toBe(false);
    const suggested = suggestCasePrice(gappy, 60);
    expect(suggested).not.toBeNull();
    expect(composeCase(gappy, suggested!).ok).toBe(true);
  });
});
