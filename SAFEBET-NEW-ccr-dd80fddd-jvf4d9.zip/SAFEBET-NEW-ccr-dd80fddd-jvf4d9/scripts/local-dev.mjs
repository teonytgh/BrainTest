// Full stack on one port for local development: Vite + the /api functions on a throwaway in-memory Postgres.
// Usage: BOT_TOKEN=123:abc npm run dev:local   (open inside Telegram, or fake initData signed with BOT_TOKEN)
// SEED_ONLY=1 skips the *_admin_snapshot.sql files: the original seed lineup instead of production's catalog.
import { copyFileSync, mkdtempSync, readdirSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { NetlifyDB } from '@netlify/database-dev';
import pg from 'pg';
import { createServer } from 'vite';
import { WebSocketServer } from 'ws';

process.env.BOT_TOKEN ??= 'local:DEV-TOKEN';

const db = new NetlifyDB();
const connectionString = await db.start();
let migrations = 'netlify/database/migrations';
if (process.env.SEED_ONLY === '1') {
  const dir = mkdtempSync(path.join(tmpdir(), 'brc-seed-'));
  for (const f of readdirSync(migrations)) if (!f.endsWith('_admin_snapshot.sql')) copyFileSync(path.join(migrations, f), path.join(dir, f));
  migrations = dir;
}
await db.applyMigrations(migrations);

let api = null;
const rooms = new Map();
let roomOf = null;
let verifyRoom = null;
async function loadApi(server) {
  if (api) return api;
  const dbModule = await server.ssrLoadModule('/server/db.ts');
  dbModule.usePool(new pg.Pool({ connectionString, max: 1 }));
  const images = new Map();
  (await server.ssrLoadModule('/server/storage.ts')).useImageStore({
    put: async (key, image) => void images.set(key, image),
    get: async (key) => images.get(key) ?? null,
  });
  const telegram = await server.ssrLoadModule('/server/telegram.ts');
  telegram.useNotifier(async (chatId, html) => {
    console.log(`[bot → ${chatId}] ${html.replace(/<[^>]+>/g, '')}`);
    return true;
  });
  // No real bot locally: invoices are fake links carrying their payload; pay them by POSTing updates to
  // /api/telegram/webhook with the X-Telegram-Bot-Api-Secret-Token derived from BOT_TOKEN.
  // Everyone counts as subscribed to the free case channel; prepared shares get a fake id.
  let messageId = 0;
  telegram.useBotApi(async (method, params) => {
    console.log(`[bot api] ${method}`);
    if (method === 'createInvoiceLink') return `https://t.me/$local-invoice?payload=${encodeURIComponent(params.payload)}`;
    if (method === 'getChatMember') return { status: 'member' };
    if (method === 'savePreparedInlineMessage') return { id: `local-share-${++messageId}` };
    if (method === 'sendMessage' || method === 'sendPhoto') return { message_id: ++messageId };
    return true;
  });
  // Multiplayer rooms («Небо Meowl», «Игра Кальмара») in this process: the same room logic the Worker's GameRoom wraps.
  const { SkyRoom } = await server.ssrLoadModule('/server/rooms/sky.ts');
  const { SquidRoom } = await server.ssrLoadModule('/server/rooms/squid.ts');
  const bridge = await server.ssrLoadModule('/server/rooms/bridge.ts');
  const room = (name) => {
    let r = rooms.get(name);
    if (!r) {
      r = name.startsWith('squid:') ? new SquidRoom() : new SkyRoom();
      rooms.set(name, r);
      setInterval(() => r.tick(), r.tickMs).unref();
    }
    return r;
  };
  bridge.useRooms({ send: async (name, msg) => room(name).broadcast(msg), call: async (name, op, arg) => room(name).call(op, arg) });
  roomOf = room;
  verifyRoom = bridge.verifyRoomTicket;
  api = await server.ssrLoadModule('/server/router.ts');
  // Same job Netlify runs every minute (netlify/functions/tick.mts): heal cases, expire trades, notifications.
  const { runTick } = await server.ssrLoadModule('/server/tick.ts');
  const tick = () => runTick().then((r) => console.log('[tick]', JSON.stringify(r)), (e) => console.error('[tick]', e));
  void tick();
  setInterval(tick, 60_000).unref();
  return api;
}

const localApi = {
  name: 'local-api',
  configureServer(server) {
    // Local only (never in the Worker): walk a room through its phases for e2e checks —
    // /__dev/room?name=squid:1&op=skip ends the current phase now, &op=stage&stage=cookie starts a stage at once,
    // any other op only reads the room's stats.
    server.middlewares.use(async (req, res, next) => {
      if (!req.url?.startsWith('/__dev/room')) return next();
      await loadApi(server);
      const url = new URL(req.url, 'http://localhost');
      const r = roomOf(url.searchParams.get('name') ?? '');
      if (url.searchParams.get('op') === 'stage') r.startStage(url.searchParams.get('stage'));
      else if (url.searchParams.get('op') === 'skip') r.phaseEnds = Date.now();
      res.writeHead(200, { 'content-type': 'application/json' }).end(JSON.stringify(r.call('stats')));
    });
    server.middlewares.use(async (req, res, next) => {
      if (!req.url?.startsWith('/api/')) return next();
      try {
        const chunks = [];
        for await (const chunk of req) chunks.push(chunk);
        const body = chunks.length ? Buffer.concat(chunks) : undefined;
        const request = new Request(`http://localhost${req.url}`, {
          method: req.method,
          headers: Object.entries(req.headers).flatMap(([k, v]) => (v === undefined ? [] : [[k, Array.isArray(v) ? v.join(', ') : v]])),
          body: req.method === 'GET' || req.method === 'HEAD' ? undefined : body,
        });
        const response = await (await loadApi(server)).handle(request);
        res.writeHead(response.status, Object.fromEntries(response.headers));
        res.end(Buffer.from(await response.arrayBuffer()));
      } catch (e) {
        console.error(e);
        res.writeHead(500).end('local api error');
      }
    });
  },
};

const server = await createServer({ plugins: [localApi], server: { port: Number(process.env.PORT ?? 5173), strictPort: true, host: true } });
await server.listen();
server.printUrls();

// /api/room WebSockets (the Worker forwards them to a GameRoom Durable Object).
const wss = new WebSocketServer({ noServer: true });
server.httpServer.on('upgrade', async (req, socket, head) => {
  const url = new URL(req.url ?? '/', 'http://localhost');
  if (url.pathname !== '/api/room') return;
  await loadApi(server);
  const pass = verifyRoom(url.searchParams.get('t') ?? '');
  if (!pass) return socket.destroy();
  wss.handleUpgrade(req, socket, head, (ws) => {
    const r = roomOf(pass.room);
    const sock = { send: (d) => ws.send(d), close: (code, reason) => ws.close(code, reason) };
    if (!r.join(pass.userId, pass.name, sock, { god: pass.god })) return;
    ws.on('message', (data) => r.message(pass.userId, sock, String(data)));
    ws.on('close', () => r.leave(pass.userId, sock));
  });
});

const stop = async () => {
  await server.close();
  await db.stop();
  process.exit(0);
};
process.on('SIGINT', stop);
process.on('SIGTERM', stop);
