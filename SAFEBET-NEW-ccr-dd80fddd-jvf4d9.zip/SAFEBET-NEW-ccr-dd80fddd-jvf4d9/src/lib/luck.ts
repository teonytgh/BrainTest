import { EVENT_INFO } from '../../shared/events';

/** The clover of a luck level: x2 the classic green one, x4 the gold pile, x8 the rainbow pile (the owner's art). */
export const luckIcon = (x: number) => (x >= 8 ? EVENT_INFO.luck8.icon : x >= 4 ? EVENT_INFO.luck4.icon : '/luck-clover.webp');
