import { createStore, useStore } from './createStore';

/**
 * The Meowl tour's state (src/components/Tour.tsx, a lazy chunk: only new players and replays load it).
 * step -1 = the offer; 0… = the tour's steps. The step survives a reload (localStorage) until the tour is closed.
 */
interface TourState {
  active: boolean;
  step: number;
}

const SAVE_KEY = 'brainrotcrash:tour';

export const tour = createStore<TourState>({ active: false, step: -1 });
export const useTour = () => useStore(tour);

/** Closed in this session: don't start again before the server's answer arrives. */
let closed = false;
export const closedHere = () => closed;
export function markClosed() {
  closed = true;
}

export function save(step: number | null) {
  try {
    if (step === null) localStorage.removeItem(SAVE_KEY);
    else localStorage.setItem(SAVE_KEY, String(step));
  } catch {
    // The tour just won't resume after a reload.
  }
}

export function saved(steps: number): number | null {
  try {
    const v = localStorage.getItem(SAVE_KEY);
    const n = v === null ? NaN : Number(v);
    return Number.isInteger(n) && n >= -1 && n < steps ? n : null;
  } catch {
    return null;
  }
}

export function goTo(step: number) {
  save(step);
  tour.set(() => ({ active: true, step }));
}

/** Настройки → «Обучение с Meowl»: straight to the first step (the player chose it). */
export function startTour() {
  closed = false;
  goTo(0);
}
