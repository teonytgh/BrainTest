-- Iteration 35 (part 4): «Игра Кальмара». Applied by the Worker (server/autoMigrate.ts), so every statement is safe to
-- run twice. The game itself runs in a GameRoom Durable Object; these keep each game and its results.

CREATE TABLE IF NOT EXISTS squid_games (
  id BIGSERIAL PRIMARY KEY,
  status TEXT NOT NULL DEFAULT 'live' CHECK (status IN ('live', 'done', 'cancelled', 'abandoned')),
  lobby_until TIMESTAMPTZ NOT NULL,
  need_deposit BOOLEAN NOT NULL DEFAULT true,
  -- [{type: 'brainrot', brainrotId} | {type: 'coins', amount}] for places 1…N.
  prizes JSONB NOT NULL DEFAULT '[]',
  created_by BIGINT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  settled_at TIMESTAMPTZ,
  results JSONB
);

CREATE TABLE IF NOT EXISTS squid_players (
  game_id BIGINT NOT NULL REFERENCES squid_games (id) ON DELETE CASCADE,
  user_id BIGINT NOT NULL REFERENCES users (id),
  -- Crossing order on the bridge (1 = first); null = out (out_stage says where).
  place INT,
  out_stage TEXT,
  prize JSONB,
  PRIMARY KEY (game_id, user_id)
);
CREATE INDEX IF NOT EXISTS squid_players_user ON squid_players (user_id);

DO $$
DECLARE t TEXT;
BEGIN
  FOREACH t IN ARRAY ARRAY['squid_games', 'squid_players'] LOOP
    EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', t);
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'anon') THEN
      EXECUTE format('REVOKE ALL ON %I FROM anon, authenticated', t);
    END IF;
  END LOOP;
END $$;
