import { useQuery } from '@tanstack/react-query';
import { useEffect, useRef, useState, type CSSProperties } from 'react';
import { useCatalog } from '../api/queries';
import { LIVE_KEEP, liveDropsQuery, type LiveDrop } from '../lib/liveDrops';
import { cx } from '../lib/format';
import { tierOf } from '../lib/tier';
import { openPlayer } from '../store/ui';

/** New drops slide in no faster than this, so the strip reads as a steady stream. */
const STEP_MS = 1000;
/** A burst (a battle, a busy minute) is shown as its newest few rather than a minute of catching up. */
const MAX_QUEUE = 6;

/**
 * «LIVE» drops of all players under the top drop: newest on the left, each new one slides in and pushes the rest
 * right. A tile shows the drop in its rarity colour and the player's photo (or initials); a tap opens the player.
 */
export function LiveDrops() {
  const catalog = useCatalog();
  const { data } = useQuery(liveDropsQuery);
  const [shown, setShown] = useState<LiveDrop[]>([]);
  const [fresh, setFresh] = useState<number | null>(null);
  const shownRef = useRef<LiveDrop[]>([]);
  const queue = useRef<LiveDrop[]>([]);

  // The first list appears at once; later ones only add what is newer, oldest first, to the queue.
  useEffect(() => {
    if (!data?.length) return;
    if (!shownRef.current.length) {
      shownRef.current = data;
      setShown(data);
      return;
    }
    const top = Math.max(shownRef.current[0]?.id ?? 0, queue.current[queue.current.length - 1]?.id ?? 0);
    const newer = data.filter((d) => d.id > top).sort((a, b) => a.id - b.id);
    queue.current = [...queue.current, ...newer].slice(-MAX_QUEUE);
  }, [data]);

  useEffect(() => {
    const t = setInterval(() => {
      if (document.hidden) return;
      const next = queue.current.shift();
      if (!next) return;
      shownRef.current = [next, ...shownRef.current].slice(0, LIVE_KEEP);
      setShown(shownRef.current);
      setFresh(next.id);
    }, STEP_MS);
    return () => clearInterval(t);
  }, []);

  const tiles = shown.flatMap((d) => {
    const b = catalog.byId.get(d.brainrotId);
    return b ? [{ d, b }] : [];
  });

  if (!tiles.length) return <p className="live-strip__empty">Здесь появятся дропы игроков — открой кейс первым</p>;

  return (
    <div className="live-strip" role="list" aria-label="Последние дропы игроков" aria-live="polite">
      {tiles.map(({ d, b }) => (
        <button
          key={d.id}
          type="button"
          role="listitem"
          className={cx('ld', `tier-${tierOf(b.price)}`, d.id === fresh && 'is-new')}
          onClick={() => openPlayer(d.player.publicId)}
          aria-label={`${b.name} — ${d.player.name}. Открыть профиль`}
        >
          <PlayerDot player={d.player} />
          <img className="ld__art" src={b.image} alt="" loading="lazy" decoding="async" draggable={false} />
        </button>
      ))}
    </div>
  );
}

/** The player's Telegram photo, or their initials on a colour of their own. */
export function PlayerDot({ player, className = 'ld__who' }: { player: LiveDrop['player']; className?: string }) {
  const [broken, setBroken] = useState(false);
  const initials =
    player.name
      .split(/\s+/)
      .filter(Boolean)
      .slice(0, 2)
      .map((w) => [...w][0]!.toUpperCase())
      .join('') || '?';
  let h = 0;
  for (const ch of player.publicId) h = (h * 31 + ch.charCodeAt(0)) % 360;
  return (
    <span className={className} style={{ '--who-hue': h } as CSSProperties} aria-hidden="true">
      {player.photo && !broken ? <img src={player.photo} alt="" loading="lazy" referrerPolicy="no-referrer" onError={() => setBroken(true)} /> : initials}
    </span>
  );
}
