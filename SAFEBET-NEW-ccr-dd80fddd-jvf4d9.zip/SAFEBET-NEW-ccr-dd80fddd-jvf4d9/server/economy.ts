import { num, type Queryable } from './db';
import { bad } from './errors';
import { noteDrop, touch } from './live';
import type { Payout } from '../shared/payout';
import { round2 } from '../shared/money';

/**
 * Pays with coins (iteration 35: `users.demo_balance` is the part of the balance an admin gave «для демо»). Demo and
 * own coins never mix, like demo and own brainrots in a stake: demo coins pay when they cover the whole price (and what
 * it buys is demo), otherwise own coins do. A mix — demo paying part of a dear case — would let a top-up launder the
 * whole gift into real drops.
 */
export async function spendCoins(c: Queryable, userId: number, amount: number): Promise<{ demo: boolean }> {
  touch(userId, 'me');
  const { rows } = await c.query<{ demo: boolean }>(
    `WITH o AS (SELECT balance, demo_balance FROM users WHERE id = $1 FOR UPDATE)
     UPDATE users u SET balance = u.balance - $2,
       demo_balance = CASE WHEN o.demo_balance >= $2 THEN u.demo_balance - $2 ELSE u.demo_balance END
     FROM o WHERE u.id = $1 AND (o.demo_balance >= $2 OR o.balance - o.demo_balance >= $2)
     RETURNING o.demo_balance >= $2 AS demo`,
    [userId, amount],
  );
  if (rows[0]) return { demo: rows[0].demo === true };
  const { rows: have } = await c.query<{ balance: string; demo_balance: string }>('SELECT balance, demo_balance FROM users WHERE id = $1', [userId]);
  const demo = num(have[0]?.demo_balance);
  if (num(have[0]?.balance) >= amount) {
    const own = round2(num(have[0]?.balance) - demo);
    throw bad(
      'mixed_coins',
      `Демо-монеты и свои не складываются: демо ${demo.toLocaleString('ru-RU')} B, своих ${own.toLocaleString('ru-RU')} B — нужно ${amount.toLocaleString('ru-RU')} B одних или других`,
      { demo, own },
    );
  }
  throw bad('no_money', 'Недостаточно монет');
}

/** Pays with the player's own coins only (battles, own promo codes): demo coins never go there. */
export async function spendRealCoins(c: Queryable, userId: number, amount: number) {
  touch(userId, 'me');
  const { rows } = await c.query<{ balance: string; demo: string }>(
    `WITH o AS (SELECT balance, demo_balance FROM users WHERE id = $1 FOR UPDATE)
     UPDATE users u SET balance = u.balance - $2 FROM o
     WHERE u.id = $1 AND o.balance - o.demo_balance >= $2 RETURNING u.balance, u.demo_balance AS demo`,
    [userId, amount],
  );
  if (rows[0]) return;
  const { rows: have } = await c.query<{ balance: string; demo_balance: string }>('SELECT balance, demo_balance FROM users WHERE id = $1', [userId]);
  const real = round2(num(have[0]?.balance) - num(have[0]?.demo_balance));
  if (num(have[0]?.balance) >= amount) {
    throw bad('demo_coins', `Демо-монеты здесь не тратятся — своих монет ${real.toLocaleString('ru-RU')} B из ${amount.toLocaleString('ru-RU')} B`, { real });
  }
  throw bad('no_money', 'Недостаточно монет');
}

/** `demo`: the coins come from a demo grant or a demo game. */
export async function addCoins(c: Queryable, userId: number, amount: number, demo = false) {
  if (amount <= 0) return;
  await c.query(
    `UPDATE users SET balance = balance + $2, demo_balance = demo_balance + CASE WHEN $3::boolean THEN $2 ELSE 0 END WHERE id = $1`,
    [userId, amount, demo],
  );
  touch(userId, 'me');
}

/**
 * «Отыгрыш» (iteration 36): a deposit (`deposit`) or anything free (`bonus`) must be played through × the admin's
 * multiplier before a withdrawal. Never for demo (it can't leave anyway). Stakes play it down by themselves: a trigger on
 * `drops` (migration 20261114100000_wager.sql), which also adds the free drops of bonus, gift and ticket cases.
 */
export async function addWager(c: Queryable, userId: number, amount: number, kind: 'deposit' | 'bonus') {
  if (!(amount > 0)) return;
  await c.query('SELECT wager_add($1, $2, $3)', [userId, round2(amount), kind]);
  touch(userId, 'me');
}

/** `addWager` for brainrots given for free (prizes), at their catalog price. */
export async function addItemWager(c: Queryable, userId: number, brainrotId: string, count = 1) {
  await c.query(`SELECT wager_add($1, (SELECT price FROM brainrots WHERE id = $2) * $3, 'bonus')`, [userId, brainrotId, count]);
  touch(userId, 'me');
}

/**
 * A stake is all demo or all the player's own: mixing would either free demo brainrots or mark real ones, so it is
 * refused. Returns whether the stake is demo.
 */
export function stakeDemo(stakes: readonly { demo: boolean }[]): boolean {
  const demo = stakes.filter((s) => s.demo).length;
  if (demo && demo < stakes.length) throw bad('mixed_demo', 'Демо-брейнроты ставятся только вместе с демо-брейнротами');
  return demo > 0;
}

/**
 * Removes an item the user owns; DELETE…RETURNING makes double-spending the same item impossible. Items on a
 * withdrawal are locked (and a database trigger refuses to delete them anyway).
 */
export async function takeItem(c: Queryable, userId: number, itemId: number) {
  touch(userId, 'me');
  const { rows } = await c.query<{ brainrot_id: string; price: string; demo: boolean }>(
    `DELETE FROM inventory i USING brainrots b
     WHERE i.id = $1 AND i.user_id = $2 AND i.withdrawal_id IS NULL AND b.id = i.brainrot_id
     RETURNING i.brainrot_id, b.price, i.demo`,
    [itemId, userId],
  );
  const row = rows[0];
  if (!row) {
    const locked = await c.query('SELECT 1 FROM inventory WHERE id = $1 AND user_id = $2 AND withdrawal_id IS NOT NULL', [itemId, userId]);
    if (locked.rows[0]) throw bad('on_withdrawal', 'Этот брейнрот на выводе — его нельзя поставить или продать');
    throw bad('no_item', 'Этого предмета уже нет в инвентаре');
  }
  return { brainrotId: row.brainrot_id, price: num(row.price), demo: row.demo === true };
}

/** `demo`: a demo grant or the win of a demo game (marked «ДЕМО», never withdrawn). */
export async function giveItems(c: Queryable, userId: number, brainrotId: string, source: string, count = 1, demo = false): Promise<number[]> {
  touch(userId, 'me');
  const { rows } = await c.query<{ id: string }>(
    `INSERT INTO inventory (user_id, brainrot_id, source, demo)
     SELECT $1, $2, $3, $5 FROM generate_series(1, $4) RETURNING id`,
    [userId, brainrotId, source, count, demo],
  );
  return rows.map((r) => num(r.id));
}

/** A case drop: a brainrot goes to the inventory, a coin prize (`brainrots.kind = 'coins'`) straight to the balance. */
export async function deliverDrop(
  c: Queryable,
  userId: number,
  brainrotId: string,
  source: string,
  demo = false,
): Promise<{ itemId: number | null; coins: number }> {
  const { rows } = await c.query<{ kind: string; price: string }>('SELECT kind, price FROM brainrots WHERE id = $1', [brainrotId]);
  if (rows[0]?.kind === 'coins') {
    const coins = num(rows[0].price);
    await addCoins(c, userId, coins, demo);
    return { itemId: null, coins };
  }
  const [itemId] = await giveItems(c, userId, brainrotId, source, 1, demo);
  return { itemId: itemId ?? null, coins: 0 };
}

/**
 * One bet in the history. `payoutValue` (what it paid back: items + coins) drives RevShare and cashback;
 * by default it is the dropped item's current price plus the coins. A `demo` game stays in the player's own history
 * only: no LIVE tile, and the quests, cashback, ranks, milestones and «Экономика» skip it.
 */
export async function recordDrop(
  c: Queryable,
  d: {
    userId: number;
    game: string;
    win: boolean;
    stakeValue: number;
    brainrotId?: string | null;
    coins?: number;
    payoutValue?: number;
    meta?: unknown;
    demo?: boolean;
  },
) {
  let payout = d.payoutValue;
  if (payout === undefined) {
    const item = d.brainrotId ? (await c.query<{ price: string }>('SELECT price FROM brainrots WHERE id = $1', [d.brainrotId])).rows[0] : undefined;
    payout = round2(num(item?.price) + (d.coins ?? 0));
  }
  const { rows } = await c.query<{ id: string }>(
    `INSERT INTO drops (user_id, game, result, stake_value, brainrot_id, coins, payout_value, meta, demo)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8::jsonb, $9) RETURNING id`,
    [d.userId, d.game, d.win ? 'win' : 'lose', d.stakeValue, d.brainrotId ?? null, d.coins ?? 0, payout, d.meta ? JSON.stringify(d.meta) : null, d.demo === true],
  );
  if (d.win && d.brainrotId && rows[0] && !d.demo) noteDrop(num(rows[0].id));
}

/** Pays a payout (brainrot + coin change) and returns the new inventory item id, if any. */
export async function payOut(c: Queryable, userId: number, payout: Payout, source: string, demo = false): Promise<number | null> {
  const itemId = payout.brainrot ? (await giveItems(c, userId, payout.brainrot.id, source, 1, demo))[0] : undefined;
  await addCoins(c, userId, payout.coins, demo);
  return itemId ?? null;
}
