import { rankOf } from '../shared/ranks';
import { round2 } from '../shared/money';
import { CANCELLABLE_WITHDRAW_STATUSES, DEMO_BLOCK, MAX_WITHDRAW_ITEMS, OPEN_WITHDRAW_STATUSES, WITHDRAW_REMIND_MS, WITHDRAW_TRADE_MS, formatMsk, parseMskDate, wagerProblem, withdrawBlock, withdrawProblem, type WithdrawStatus } from '../shared/withdraw';
import { assertActive, type Viewer } from './auth';
import { ms, num, one, q, tx, type Queryable } from './db';
import { siteUrl } from './env';
import { HttpError, bad, notFound } from './errors';
import { addCoins, giveItems, takeItem } from './economy';
import { adminIds, isAdmin } from './itemDeposits';
import { afterResponse, touch } from './live';
import { getSettings, setSetting } from './settings';
import { botApi, escapeHtml, notify } from './telegram';
import { displayName, getUser, type UserRow } from './users';
import { ids, int, optStr, robloxNick, type Body } from './validate';
export type { WithdrawStatus };

interface Item {
  brainrotId: string;
  name: string;
  count: number;
  price: number;
}

interface WithdrawalRow {
  id: string;
  user_id: string;
  items: Item[];
  value: string;
  roblox_nick: string;
  status: WithdrawStatus;
  scheduled_at: string | null;
  bot_nick: string | null;
  trade_deadline: string | null;
  note: string | null;
  processed_by: string | null;
  admin_messages: { chatId: number; messageId: number }[];
  created_at: string;
  updated_at: string;
}

const OPEN_SQL = `(${OPEN_WITHDRAW_STATUSES.map((s) => `'${s}'`).join(', ')})`;
const CANCELLABLE_SQL = `(${CANCELLABLE_WITHDRAW_STATUSES.map((s) => `'${s}'`).join(', ')})`;
const fmt = (n: number) => n.toLocaleString('ru-RU', { maximumFractionDigits: 2 });
const playButton = () => ({ inline_keyboard: [[{ text: '🎮 Открыть BrainrotCrash', web_app: { url: `${siteUrl()}/` } }]] });
const itemLines = (w: WithdrawalRow) => w.items.map((i) => `• ${escapeHtml(i.name)}${i.count > 1 ? ` ×${i.count}` : ''} — ${fmt(i.price * i.count)} B`);

function view(w: WithdrawalRow) {
  return {
    id: num(w.id),
    status: w.status,
    items: w.items,
    value: num(w.value),
    robloxNick: w.roblox_nick,
    scheduledAt: ms(w.scheduled_at),
    // The receiving account is the player's business once a time is set.
    botNick: w.status === 'pending' ? null : w.bot_nick,
    deadline: w.status === 'trading' ? ms(w.trade_deadline) : null,
    note: w.note,
    canCancel: cancellable(w),
    createdAt: ms(w.created_at)!,
    updatedAt: ms(w.updated_at)!,
  };
}

export type WithdrawalView = ReturnType<typeof view>;

/**
 * The player may take the brainrots back only while no trade can have happened: before the scheduled time and
 * if no trade window was ever opened (`trade_deadline` stays set once one was, even after a new date).
 */
const cancellable = (w: WithdrawalRow) =>
  CANCELLABLE_WITHDRAW_STATUSES.includes(w.status) && w.trade_deadline === null && (w.scheduled_at === null || ms(w.scheduled_at)! > Date.now());

// ---------- Player API ----------

/** The chosen inventory items become one request; they stay in the inventory, locked «НА ВЫВОДЕ». */
export async function createWithdrawal(v: Viewer, body: Body) {
  assertActive(v);
  const itemIds = ids(body.itemIds, 'предметы', MAX_WITHDRAW_ITEMS);
  if (!itemIds.length) throw bad('invalid', 'Выбери брейнротов для вывода');
  if (new Set(itemIds).size !== itemIds.length) throw bad('invalid', 'Предмет выбран дважды');
  const nick = robloxNick(body.robloxNick);
  // Every request pings all admins in the bot: cap cancel-and-recreate loops.
  const recent = await one<{ n: string }>(`SELECT count(*) AS n FROM withdrawals WHERE user_id = $1 AND created_at > now() - interval '10 minutes'`, [v.id]);
  if (num(recent?.n) >= 5) throw new HttpError(429, 'too_many', 'Слишком много заявок подряд — подожди несколько минут');

  const row = await tx(async (c) => {
    const { withdrawRules } = await getSettings(c);
    const { rows: picked } = await c.query<{
      id: string;
      brainrot_id: string;
      name: string;
      price: string;
      withdrawable: boolean;
      status: string;
      withdrawal_id: string | null;
      demo: boolean;
    }>(
      `SELECT i.id, i.brainrot_id, b.name, b.price, b.withdrawable, b.status, i.withdrawal_id, i.demo
       FROM inventory i JOIN brainrots b ON b.id = i.brainrot_id
       WHERE i.user_id = $1 AND i.id = ANY($2::bigint[]) FOR UPDATE OF i`,
      [v.id, itemIds],
    );
    if (picked.length !== itemIds.length) throw bad('no_item', 'Некоторых предметов уже нет в инвентаре');
    if (picked.some((p) => p.withdrawal_id !== null)) throw bad('on_withdrawal', 'Некоторые брейнроты уже на выводе');
    const items = picked.map((p) => ({ brainrotId: p.brainrot_id, name: p.name, price: num(p.price), withdrawable: p.withdrawable, status: p.status, demo: p.demo }));
    for (const it of items) {
      const why = withdrawBlock(it, withdrawRules);
      if (why) throw bad('not_withdrawable', `${it.name}: ${why.toLowerCase()}`);
    }
    const problem = withdrawProblem(items, withdrawRules);
    if (problem) throw bad('withdraw_min', problem);
    // «Отыгрыш» (iteration 36): deposits and bonuses must be played through first (after what is wrong
    // with the selection itself, which the player fixes in the same sheet).
    const { rows: me } = await c.query<{ wager_left: string; wager_total: string }>('SELECT wager_left, wager_total FROM users WHERE id = $1', [v.id]);
    const wager = { left: num(me[0]?.wager_left), total: num(me[0]?.wager_total) };
    const unplayed = wagerProblem(wager);
    if (unplayed) throw bad('wager', unplayed, wager);
    const grouped = new Map<string, Item>();
    for (const it of items) {
      const g = grouped.get(it.brainrotId);
      if (g) g.count += 1;
      else grouped.set(it.brainrotId, { brainrotId: it.brainrotId, name: it.name, count: 1, price: it.price });
    }
    const list = [...grouped.values()].sort((a, b) => b.price - a.price);
    const value = round2(items.reduce((s, it) => s + it.price, 0));
    let w: WithdrawalRow;
    try {
      w = (
        await c.query<WithdrawalRow>(
          `INSERT INTO withdrawals (user_id, items, value, roblox_nick, status) VALUES ($1, $2::jsonb, $3, $4, 'pending') RETURNING *`,
          [v.id, JSON.stringify(list), value, nick],
        )
      ).rows[0]!;
    } catch (e) {
      if ((e as { code?: string }).code === '23505') throw new HttpError(409, 'already_open', 'У тебя уже есть заявка на вывод — дождись её или отмени');
      throw e;
    }
    const locked = await c.query('UPDATE inventory SET withdrawal_id = $1 WHERE user_id = $2 AND id = ANY($3::bigint[]) AND withdrawal_id IS NULL', [w.id, v.id, itemIds]);
    if (locked.rowCount !== itemIds.length) throw bad('on_withdrawal', 'Некоторые брейнроты уже на выводе');
    return w;
  });
  touch(v.id, 'me', 'withdrawal');
  const user = (await getUser(v.id))!;
  await afterResponse(async () => {
    await notify(v.id, `📤 Заявка на вывод #${row.id} создана — подбираем время.\nКогда админ назначит время и бота, пришлём сообщение.`);
    await announce(row, user);
  });
  return view(row);
}

/**
 * «Размен»: brainrots that aren't in stock (and aren't junk) become in-stock ones of no greater total value; the
 * difference goes to the balance. Everything at catalog prices, in one transaction.
 */
export async function exchangeItems(v: Viewer, body: Body) {
  assertActive(v);
  const itemIds = ids(body.itemIds, 'предметы', MAX_WITHDRAW_ITEMS);
  if (!Array.isArray(body.take) || !body.take.length) throw bad('invalid', 'Выбери, на что разменять');
  const want = new Map<string, number>();
  for (const raw of body.take as Body[]) {
    const id = typeof raw?.brainrotId === 'string' ? raw.brainrotId : '';
    want.set(id, (want.get(id) ?? 0) + int(raw?.count, 'количество', 1, MAX_WITHDRAW_ITEMS));
  }
  const pieces = [...want.values()].reduce((a, b) => a + b, 0);
  if (pieces > MAX_WITHDRAW_ITEMS) throw bad('too_many', `За один размен — не больше ${MAX_WITHDRAW_ITEMS} брейнротов`);
  const result = await tx(async (c) => {
    const { withdrawRules } = await getSettings(c);
    const given: { brainrotId: string; price: number }[] = [];
    for (const id of itemIds) {
      const item = await takeItem(c, v.id, id);
      if (item.demo) throw bad('demo_item', DEMO_BLOCK);
      if (item.price < withdrawRules.minItemPrice) throw bad('junk', 'Хлам не размениваем — его можно продать');
      given.push(item);
    }
    const value = round2(given.reduce((s, g) => s + g.price, 0));
    const { rows: stock } = await c.query<{ id: string; name: string; price: string }>(
      `SELECT id, name, price FROM brainrots WHERE id = ANY($1::text[]) AND status = 'active' AND kind = 'brainrot' AND withdrawable AND price >= $2`,
      [[...want.keys()], withdrawRules.minItemPrice],
    );
    if (stock.length !== want.size) throw bad('not_in_stock', 'Этих брейнротов сейчас нет в наличии');
    const taken = stock.map((b) => ({ brainrotId: b.id, name: b.name, count: want.get(b.id)!, price: num(b.price) }));
    const total = round2(taken.reduce((s, t) => s + t.price * t.count, 0));
    if (total > value + 0.001) throw bad('exchange_too_much', 'Это дороже твоих брейнротов — убери что-нибудь');
    const change = round2(value - total);
    const newIds: number[] = [];
    for (const t of taken) newIds.push(...(await giveItems(c, v.id, t.brainrotId, 'exchange', t.count)));
    await addCoins(c, v.id, change);
    await c.query('INSERT INTO item_exchanges (user_id, given, taken, value, change) VALUES ($1, $2::jsonb, $3::jsonb, $4, $5)', [
      v.id,
      JSON.stringify(given),
      JSON.stringify(taken),
      value,
      change,
    ]);
    return { itemIds: newIds, value, total, change, taken };
  });
  touch(v.id, 'me');
  return result;
}

/** The latest request (open or just finished), with due reminders, windows and timeouts applied. */
export async function currentWithdrawal(v: Viewer) {
  await advanceWithdrawals({ userId: v.id });
  const row = await one<WithdrawalRow>('SELECT * FROM withdrawals WHERE user_id = $1 ORDER BY id DESC LIMIT 1', [v.id]);
  return row ? view(row) : null;
}

export async function myWithdrawals(v: Viewer) {
  const rows = await q<WithdrawalRow>('SELECT * FROM withdrawals WHERE user_id = $1 ORDER BY id DESC LIMIT 30', [v.id]);
  return rows.map(view);
}

/** Until the first trade window the player can take everything back. */
export async function cancelWithdrawal(v: Viewer, idParam: string) {
  const id = int(idParam, 'заявка');
  const row = await tx(async (c) => {
    const { rows } = await c.query<WithdrawalRow>(
      `UPDATE withdrawals SET status = 'cancelled', updated_at = now()
       WHERE id = $1 AND user_id = $2 AND status IN ${CANCELLABLE_SQL} AND trade_deadline IS NULL AND (scheduled_at IS NULL OR scheduled_at > now())
       RETURNING *`,
      [id, v.id],
    );
    if (!rows[0]) {
      const cur = (await c.query<{ status: WithdrawStatus }>('SELECT status FROM withdrawals WHERE id = $1 AND user_id = $2', [id, v.id])).rows[0];
      if (cur && OPEN_WITHDRAW_STATUSES.includes(cur.status)) {
        throw bad('not_cancellable', 'Время трейда уже наступило — теперь заявку закрывает админ (выведет или вернёт брейнротов)');
      }
      throw bad('not_cancellable', 'Эту заявку уже нельзя отменить');
    }
    await unlock(c, id);
    return rows[0];
  });
  touch(v.id, 'me', 'withdrawal');
  await afterResponse(() => refreshAdminMessages(row));
  return view(row);
}

async function unlock(c: Queryable, withdrawalId: number | string) {
  await c.query('UPDATE inventory SET withdrawal_id = NULL WHERE withdrawal_id = $1', [withdrawalId]);
}

// ---------- Admin actions (bot and mini app) ----------

type Outcome = { ok: true; row: WithdrawalRow } | { ok: false; reason: string };

/** The bot an admin picked goes first in the list: it's the default for the next requests. */
async function rememberBot(nick: string) {
  await tx(async (c) => {
    const { tradeBots } = await getSettings(c);
    if (tradeBots[0] !== nick) await setSetting(c, 'trade_bots', [nick, ...tradeBots.filter((b) => b !== nick)].slice(0, 10));
  });
}

/**
 * Sets the time and/or the receiving bot; with both the request is «scheduled». A time without a bot takes the
 * default one (the last used). A time that has already come opens the trade window right away.
 */
async function schedule(id: number, adminId: number, change: { at?: number; botNick?: string }): Promise<Outcome> {
  const fallback = change.at !== undefined ? ((await getSettings()).tradeBots[0] ?? null) : null;
  const row = await one<WithdrawalRow>(
    `UPDATE withdrawals SET
       scheduled_at = COALESCE($2, scheduled_at),
       bot_nick = COALESCE($3, bot_nick, $5),
       reminded_at = CASE WHEN $2::timestamptz IS NULL THEN reminded_at ELSE NULL END,
       status = CASE WHEN COALESCE($2, scheduled_at) IS NOT NULL AND COALESCE($3, bot_nick, $5) IS NOT NULL THEN 'scheduled' ELSE status END,
       processed_by = $4, updated_at = now()
     WHERE id = $1 AND status IN ('pending', 'scheduled', 'expired') RETURNING *`,
    [id, change.at === undefined ? null : new Date(change.at).toISOString(), change.botNick ?? null, adminId, fallback],
  );
  if (!row) return { ok: false, reason: 'Заявку уже нельзя перенести (идёт трейд или она закрыта)' };
  if (change.botNick) await rememberBot(change.botNick);
  touch(num(row.user_id), 'withdrawal');
  if (row.status === 'scheduled' && ms(row.scheduled_at)! <= Date.now() + 1000) {
    // «⚡ Сейчас»: straight to the trade window (the player gets «твоя очередь» instead of a schedule).
    await advanceWithdrawals({ userId: num(row.user_id) });
    const now = await one<WithdrawalRow>('SELECT * FROM withdrawals WHERE id = $1', [id]);
    return { ok: true, row: now ?? row };
  }
  if (row.status === 'scheduled') {
    await afterResponse(() =>
      botApi('sendMessage', {
        chat_id: num(row.user_id),
        parse_mode: 'HTML',
        text: [
          `📅 <b>Вывод #${row.id} назначен</b> на ${formatMsk(ms(row.scheduled_at)!)}.`,
          `Бот для трейда: <code>${escapeHtml(row.bot_nick ?? '')}</code>`,
          'За 5 минут пришлём напоминание, в назначенное время на трейд будет 5 минут.',
        ].join('\n'),
        reply_markup: playButton(),
      }),
    );
  }
  return { ok: true, row };
}

async function finish(id: number, adminId: number): Promise<Outcome> {
  const row = await tx(async (c) => {
    const { rows } = await c.query<WithdrawalRow>(
      `UPDATE withdrawals SET status = 'done', processed_by = $2, processed_at = now(), updated_at = now()
       WHERE id = $1 AND status IN ${OPEN_SQL} RETURNING *`,
      [id, adminId],
    );
    const w = rows[0];
    if (!w) return null;
    // The locked items leave for good (the guard trigger allows it now that the request is done).
    await c.query('DELETE FROM inventory WHERE withdrawal_id = $1', [id]);
    await c.query('UPDATE users SET withdrawn_value = withdrawn_value + $2 WHERE id = $1', [w.user_id, w.value]);
    await c.query('INSERT INTO admin_log (admin_id, action, target_user, details) VALUES ($1, $2, $3, $4::jsonb)', [
      adminId,
      'withdraw_done',
      w.user_id,
      JSON.stringify({ withdrawalId: num(w.id), value: num(w.value) }),
    ]);
    return w;
  });
  if (!row) return { ok: false, reason: 'Заявка уже закрыта' };
  touch(num(row.user_id), 'me', 'withdrawal');
  await afterResponse(() =>
    botApi('sendMessage', {
      chat_id: num(row.user_id),
      parse_mode: 'HTML',
      text: [`✅ <b>Вывод #${row.id} выполнен!</b>`, ...itemLines(row), `Всего: <b>${fmt(num(row.value))} B</b>. Проверь Roblox!`].join('\n'),
      reply_markup: playButton(),
    }),
  );
  return { ok: true, row };
}

async function reject(id: number, adminId: number, note: string | null = null): Promise<Outcome> {
  const row = await tx(async (c) => {
    const { rows } = await c.query<WithdrawalRow>(
      `UPDATE withdrawals SET status = 'rejected', note = COALESCE($3, note), processed_by = $2, processed_at = now(), updated_at = now()
       WHERE id = $1 AND status IN ${OPEN_SQL} RETURNING *`,
      [id, adminId, note],
    );
    const w = rows[0];
    if (!w) return null;
    await unlock(c, id);
    await c.query('INSERT INTO admin_log (admin_id, action, target_user, details) VALUES ($1, $2, $3, $4::jsonb)', [
      adminId,
      'withdraw_reject',
      w.user_id,
      JSON.stringify({ withdrawalId: num(w.id), note }),
    ]);
    return w;
  });
  if (!row) return { ok: false, reason: 'Заявка уже закрыта' };
  touch(num(row.user_id), 'me', 'withdrawal');
  await afterResponse(() =>
    notify(num(row.user_id), `❌ Вывод #${row.id} отклонён — брейнроты вернулись в инвентарь.${row.note ? `\nПричина: ${escapeHtml(row.note)}` : ''}\nВопросы — /paysupport.`),
  );
  return { ok: true, row };
}

/**
 * Minute work (the tick; a player's own reads too): the 5-minute heads-up, the trade window at the scheduled
 * time, and its timeout. Each step is a conditional UPDATE, so a message is sent exactly once.
 */
export async function advanceWithdrawals(scope: { userId?: number } = {}) {
  const only = scope.userId ? 'AND user_id = $1' : '';
  const params = scope.userId ? [scope.userId] : [];
  const reminded = await q<WithdrawalRow>(
    `UPDATE withdrawals SET reminded_at = now() WHERE status = 'scheduled' AND reminded_at IS NULL
       AND scheduled_at <= now() + interval '${WITHDRAW_REMIND_MS / 1000} seconds' AND scheduled_at > now() ${only} RETURNING *`,
    params,
  );
  const opened = await q<WithdrawalRow>(
    `UPDATE withdrawals SET status = 'trading', trade_deadline = now() + interval '${WITHDRAW_TRADE_MS / 1000} seconds', updated_at = now()
     WHERE status = 'scheduled' AND scheduled_at <= now() ${only} RETURNING *`,
    params,
  );
  const expired = await q<WithdrawalRow>(
    `UPDATE withdrawals SET status = 'expired', updated_at = now() WHERE status = 'trading' AND trade_deadline < now() ${only} RETURNING *`,
    params,
  );
  const work: Promise<unknown>[] = [];
  for (const w of reminded) work.push(remind(w));
  for (const w of opened) work.push(openWindow(w));
  for (const w of expired) work.push(expire(w));
  for (const w of [...reminded, ...opened, ...expired]) touch(num(w.user_id), 'withdrawal');
  // Bot messages don't hold up a player's request.
  if (scope.userId) await afterResponse(() => Promise.all(work));
  else await Promise.all(work);
  return { reminded: reminded.length, opened: opened.length, expired: expired.length };
}

async function remind(w: WithdrawalRow) {
  const user = await getUser(num(w.user_id));
  const at = formatMsk(ms(w.scheduled_at)!);
  await botApi('sendMessage', {
    chat_id: num(w.user_id),
    parse_mode: 'HTML',
    text: [
      `⏰ <b>Через 5 минут вывод #${w.id}</b> (${at}).`,
      `Будь в Roblox и готовься кинуть трейд на <code>${escapeHtml(w.bot_nick ?? '')}</code>.`,
      'Когда подойдёт время, на трейд будет 5 минут.',
    ].join('\n'),
    reply_markup: playButton(),
  });
  const text = [`⏰ <b>Через 5 минут вывод #${w.id}</b> (${at})`, `Игрок: ${playerLink(w, user)}`, `Бот: <code>${escapeHtml(w.bot_nick ?? '')}</code>`, ...itemLines(w)].join('\n');
  await Promise.all((await adminIds()).map((chatId) => botApi('sendMessage', { chat_id: chatId, text, parse_mode: 'HTML', disable_web_page_preview: true })));
}

async function openWindow(w: WithdrawalRow) {
  const user = await getUser(num(w.user_id));
  await botApi('sendMessage', {
    chat_id: num(w.user_id),
    parse_mode: 'HTML',
    text: [
      `🔔 <b>Твоя очередь — вывод #${w.id}!</b>`,
      `Кинь трейд на <code>${escapeHtml(w.bot_nick ?? '')}</code> со своего ника <code>${escapeHtml(w.roblox_nick)}</code>.`,
      ...itemLines(w),
      'На трейд 5 минут.',
    ].join('\n'),
    reply_markup: playButton(),
  });
  // A fresh message with everything for the trade, on top of the admins' chats.
  const [text, keyboard] = [await adminText(w, user, '🔔 <b>Сейчас вывод — игрок кидает трейд</b>'), await adminKeyboard(w, user)];
  const sent = await Promise.all(
    (await adminIds()).map(async (chatId) => {
      const m = await botApi<{ message_id: number }>('sendMessage', { chat_id: chatId, text, parse_mode: 'HTML', reply_markup: keyboard, disable_web_page_preview: true });
      return m ? { chatId, messageId: m.message_id } : null;
    }),
  );
  const fresh = sent.filter((m): m is { chatId: number; messageId: number } => !!m);
  const keep = w.admin_messages.filter((m) => !fresh.some((f) => f.chatId === m.chatId));
  // Every older copy is edited to the same state; those with a new card in their chat are then forgotten, the
  // rest (the new card didn't reach that chat) stay tracked.
  await refreshAdminMessages(w);
  await q('UPDATE withdrawals SET admin_messages = $2::jsonb WHERE id = $1', [w.id, JSON.stringify([...fresh, ...keep])]);
}

async function expire(w: WithdrawalRow) {
  // An admin may have pressed «Выведено» or «Отклонить» since the tick expired it: then say nothing.
  const now = await one<WithdrawalRow>('SELECT * FROM withdrawals WHERE id = $1', [w.id]);
  if (!now || now.status !== 'expired') return;
  await notify(
    num(w.user_id),
    `⌛ Время на трейд по выводу #${w.id} вышло.\nБрейнроты остаются на выводе: админ назначит новое время или вернёт их в инвентарь.`,
  );
  await refreshAdminMessages(now);
}

// ---------- Bot side ----------

function playerLink(w: WithdrawalRow, user: UserRow | undefined) {
  const who = user ? displayName(user) : `ID ${w.user_id}`;
  return `<a href="tg://user?id=${w.user_id}">${escapeHtml(who)}</a> · ID ${w.user_id}`;
}

function statusLine(w: WithdrawalRow): string {
  const at = w.scheduled_at ? formatMsk(ms(w.scheduled_at)!) : null;
  switch (w.status) {
    case 'pending':
      return at ? `⏳ время ${at} — выбери бота` : '⏳ на подборе — нажми время ниже';
    case 'scheduled':
      return `📅 ${at}, бот <code>${escapeHtml(w.bot_nick ?? '')}</code>`;
    case 'trading':
      return `🤝 трейд на <code>${escapeHtml(w.bot_nick ?? '')}</code> до ${formatMsk(ms(w.trade_deadline)!)}`;
    case 'expired':
      return '⌛ время на трейд вышло — назначь новую дату, выведи или отклони';
    case 'done':
      return '✅ выведено';
    case 'rejected':
      return `❌ отклонено${w.note ? `: ${escapeHtml(w.note)}` : ''}`;
    case 'cancelled':
      return '🚫 отменена игроком';
  }
}

async function adminText(w: WithdrawalRow, user: UserRow | undefined, header?: string): Promise<string> {
  const handler = w.processed_by ? await getUser(num(w.processed_by)).then((u) => (u ? displayName(u) : null)) : null;
  return [
    ...(header ? [header] : []),
    `📤 <b>Вывод #${w.id}</b>`,
    `Игрок: ${playerLink(w, user)}`,
    `Ник Roblox игрока: <code>${escapeHtml(w.roblox_nick)}</code>`,
    ...itemLines(w),
    `Сумма: <b>${fmt(num(w.value))} B</b>`,
    `Статус: ${statusLine(w)}${handler && w.status !== 'pending' ? ` (${escapeHtml(handler)})` : ''}`,
  ].join('\n');
}

/** Time buttons right under the request: one tap schedules it with the default bot. */
async function adminKeyboard(w: WithdrawalRow, user: UserRow | undefined) {
  const rows: { text: string; callback_data?: string; url?: string }[][] = [];
  if (w.status === 'pending' || w.status === 'scheduled' || w.status === 'expired') {
    const quick = QUICK_MINUTES.map((min) => ({ text: min === 0 ? '⚡ Сейчас' : minutesShort(min), callback_data: `w:${w.id}:m:${min}` }));
    rows.push(quick.slice(0, 3), [...quick.slice(3), { text: '✍️ Своя дата', callback_data: `w:${w.id}:c` }]);
    const bot = w.bot_nick ?? (await getSettings()).tradeBots[0] ?? null;
    rows.push([{ text: bot ? `🤖 Бот: ${bot} · сменить` : '🤖 Выбрать бота', callback_data: `w:${w.id}:p` }]);
  }
  if (w.status === 'scheduled' || w.status === 'trading' || w.status === 'expired') {
    rows.push([
      { text: '✅ Выведено', callback_data: `w:${w.id}:d` },
      { text: '❌ Отклонено', callback_data: `w:${w.id}:r` },
    ]);
  } else if (w.status === 'pending') {
    rows.push([{ text: '❌ Отклонить', callback_data: `w:${w.id}:r` }]);
  }
  rows.push([user?.username ? { text: '💬 Связаться с игроком', url: `https://t.me/${user.username}` } : { text: '💬 Связаться с игроком', callback_data: `w:${w.id}:u` }]);
  return { inline_keyboard: rows };
}

async function announce(w: WithdrawalRow, user: UserRow) {
  const [text, keyboard] = [await adminText(w, user, '🆕 Новая заявка на вывод'), await adminKeyboard(w, user)];
  const sent = await Promise.all(
    (await adminIds()).map(async (chatId) => {
      const m = await botApi<{ message_id: number }>('sendMessage', { chat_id: chatId, text, parse_mode: 'HTML', reply_markup: keyboard, disable_web_page_preview: true });
      return m ? { chatId, messageId: m.message_id } : null;
    }),
  );
  const messages = sent.filter((m): m is { chatId: number; messageId: number } => !!m);
  await q('UPDATE withdrawals SET admin_messages = $2::jsonb WHERE id = $1', [w.id, JSON.stringify(messages)]);
}

async function refreshAdminMessages(w: WithdrawalRow) {
  const user = await getUser(num(w.user_id));
  const [text, keyboard] = [await adminText(w, user), await adminKeyboard(w, user)];
  await Promise.all(
    w.admin_messages.map((m) =>
      botApi('editMessageText', { chat_id: m.chatId, message_id: m.messageId, text, parse_mode: 'HTML', reply_markup: keyboard, disable_web_page_preview: true }),
    ),
  );
}

export const WITHDRAW_QUEUE_BUTTON = '📤 Очередь выводов';
const QUEUE_LIMIT = 10;

/** «📤 Очередь выводов»: every open request again, with its buttons; this admin's copy is updated from now on. */
export async function sendWithdrawQueue(chatId: number): Promise<string> {
  const rows = await q<WithdrawalRow>(`SELECT * FROM withdrawals WHERE status IN ${OPEN_SQL} ORDER BY COALESCE(scheduled_at, created_at) LIMIT ${QUEUE_LIMIT + 1}`);
  if (!rows.length) return '✅ Заявок на вывод нет.';
  for (const w of rows.slice(0, QUEUE_LIMIT)) {
    const user = await getUser(num(w.user_id));
    const m = await botApi<{ message_id: number }>('sendMessage', {
      chat_id: chatId,
      text: await adminText(w, user),
      parse_mode: 'HTML',
      reply_markup: await adminKeyboard(w, user),
      disable_web_page_preview: true,
    });
    if (!m) continue;
    const messages = [...w.admin_messages.filter((x) => x.chatId !== chatId), { chatId, messageId: m.message_id }];
    await q('UPDATE withdrawals SET admin_messages = $2::jsonb WHERE id = $1', [w.id, JSON.stringify(messages)]);
  }
  return `📤 Открытых выводов: ${rows.length > QUEUE_LIMIT ? `больше ${QUEUE_LIMIT}` : rows.length} — заявки выше, кнопки под каждой.`;
}

/** 0 = «⚡ Сейчас»: the trade window opens at once. */
const QUICK_MINUTES = [0, 5, 15, 30, 60];
const minutesLabel = (m: number) => (m === 0 ? 'сейчас' : m < 60 ? `через ${m} мин` : `через ${m / 60} ч`);
const minutesShort = (m: number) => (m < 60 ? `${m} мин` : `${m / 60} ч`);
const DATE_PROMPT = /Дата вывода #(\d+)/;
const NICK_PROMPT = /Ник бота для вывода #(\d+)/;

async function botPicker(id: number, current: string | null) {
  const { tradeBots } = await getSettings();
  const rows: { text: string; callback_data: string }[][] = [];
  for (let i = 0; i < tradeBots.length; i += 2) {
    rows.push(tradeBots.slice(i, i + 2).map((nick) => ({ text: `🤖 ${nick}${current === nick ? ' ✓' : ''}`, callback_data: `w:${id}:b:${nick}` })));
  }
  rows.push([{ text: '➕ Новый ник бота', callback_data: `w:${id}:n` }]);
  return { inline_keyboard: rows };
}

interface CallbackQuery {
  id: string;
  from: { id: number };
  data?: string;
  message?: { message_id: number; chat: { id: number } };
}

type BotReply = Record<string, unknown> | null;

/** Buttons under a withdrawal in the admins' chats (`w:<id>:<action>[:<arg>]`). */
export async function handleWithdrawCallback(cq: CallbackQuery): Promise<BotReply> {
  const answer = (text: string, alert = false) => ({ method: 'answerCallbackQuery', callback_query_id: cq.id, text, show_alert: alert });
  const m = /^w:(\d{1,18}):([tmcpbndru])(?::([A-Za-z0-9_]{1,20}))?$/.exec(cq.data ?? '');
  if (!m) return answer('Кнопка устарела');
  if (!(await isAdmin(cq.from.id))) return answer('Только для админов', true);
  const id = Number(m[1]);
  const action = m[2]!;
  const arg = m[3];
  const w = await one<WithdrawalRow>('SELECT * FROM withdrawals WHERE id = $1', [id]);
  if (!w) return answer('Заявка не найдена', true);
  const reschedulable = w.status === 'pending' || w.status === 'scheduled' || w.status === 'expired';
  const here = cq.message ? { chat_id: cq.message.chat.id, message_id: cq.message.message_id } : null;

  if (action === 'u') return answer(`У игрока нет username. Telegram ID: ${w.user_id}`, true);
  if (action === 't') {
    if (!reschedulable) return answer('Сейчас дату не поменять', true);
    const buttons = QUICK_MINUTES.map((min) => ({ text: minutesLabel(min), callback_data: `w:${id}:m:${min}` }));
    await botApi('sendMessage', {
      chat_id: cq.from.id,
      text: `📅 Когда вывод #${id}? Выбери или нажми «Своя дата».`,
      reply_markup: { inline_keyboard: [buttons.slice(0, 3), buttons.slice(3), [{ text: '✍️ Своя дата', callback_data: `w:${id}:c` }]] },
    });
    return answer('Выбери время');
  }
  if (action === 'c') {
    if (!reschedulable) return answer('Сейчас дату не поменять', true);
    await botApi('sendMessage', {
      chat_id: cq.from.id,
      text: `Дата вывода #${id} — ответь на это сообщение: «ДД.ММ ЧЧ:ММ» или «ЧЧ:ММ» по Москве (например 19.10 18:30).`,
      reply_markup: { force_reply: true, input_field_placeholder: '19.10 18:30' },
    });
    return answer('Отправь дату ответом на сообщение');
  }
  if (action === 'p') {
    if (!reschedulable) return answer('Сейчас бота не поменять', true);
    await botApi('sendMessage', { chat_id: cq.from.id, text: `🤖 Ник бота для вывода #${id}:`, reply_markup: await botPicker(id, w.bot_nick) });
    return answer('Выбери бота');
  }
  if (action === 'n') {
    if (!reschedulable) return answer('Сейчас бота не поменять', true);
    await botApi('sendMessage', {
      chat_id: cq.from.id,
      text: `Ник бота для вывода #${id} — ответь на это сообщение ником Roblox-аккаунта. Он сохранится в кнопках.`,
      reply_markup: { force_reply: true, input_field_placeholder: 'RobloxNick' },
    });
    return answer('Отправь ник ответом на сообщение');
  }

  let outcome: Outcome;
  let done: string;
  if (action === 'm') {
    const minutes = Number(arg);
    if (!QUICK_MINUTES.includes(minutes)) return answer('Кнопка устарела');
    outcome = await schedule(id, cq.from.id, { at: Date.now() + minutes * 60_000 });
    done = `Время: ${minutesLabel(minutes)}`;
  } else if (action === 'b') {
    if (!arg || !/^[A-Za-z0-9_]{3,20}$/.test(arg)) return answer('Кнопка устарела');
    outcome = await schedule(id, cq.from.id, { botNick: arg });
    done = `Бот: ${arg}`;
  } else if (action === 'd') {
    outcome = await finish(id, cq.from.id);
    done = 'Выведено';
  } else {
    outcome = await reject(id, cq.from.id);
    done = 'Отклонено';
  }
  if (!outcome.ok) return answer(outcome.reason, true);
  const row = outcome.row;
  await afterResponse(async () => {
    await refreshAdminMessages(row);
    // A time and no bot saved yet: ask for one (the request message keeps its buttons).
    if (action === 'm' && row.status !== 'scheduled' && row.status !== 'trading') {
      await botApi('sendMessage', { chat_id: cq.from.id, text: `🤖 Время вывода #${id}: ${formatMsk(ms(row.scheduled_at)!)}. Теперь ник бота:`, reply_markup: await botPicker(id, null) });
    } else if (action === 'b' && here) {
      const text = row.status === 'scheduled' ? `✅ Вывод #${id} назначен: ${formatMsk(ms(row.scheduled_at)!)}, бот ${row.bot_nick}.` : `✅ Бот ${row.bot_nick}. Теперь нажми «📅 Указать дату вывода» под заявкой.`;
      await botApi('editMessageText', { ...here, text });
    }
  });
  return answer(done);
}

/** An admin answered a date or bot-nick prompt for a withdrawal; null when the reply is about something else. */
export async function handleWithdrawReply(msg: { from: { id: number }; text: string; reply_to_message?: { text?: string } }): Promise<BotReply> {
  const prompt = msg.reply_to_message?.text ?? '';
  const dateMatch = DATE_PROMPT.exec(prompt);
  const nickMatch = NICK_PROMPT.exec(prompt);
  if (!dateMatch && !nickMatch) return null;
  if (!(await isAdmin(msg.from.id))) return null;
  const say = (text: string, markup?: unknown) => ({ method: 'sendMessage', chat_id: msg.from.id, text, parse_mode: 'HTML', ...(markup ? { reply_markup: markup } : {}) });
  if (dateMatch) {
    const id = Number(dateMatch[1]);
    const at = parseMskDate(msg.text);
    if (at === null) return say('Не понял дату. Формат: «19.10 18:30» или «18:30» по Москве, не дальше 30 дней. Нажми «✍️ Своя дата» ещё раз.');
    const outcome = await schedule(id, msg.from.id, { at });
    if (!outcome.ok) return say(outcome.reason);
    await refreshAdminMessages(outcome.row);
    if (outcome.row.status === 'scheduled') return say(`✅ Вывод #${id} назначен: ${formatMsk(at)}, бот <code>${escapeHtml(outcome.row.bot_nick ?? '')}</code>. Бот можно сменить:`, await botPicker(id, outcome.row.bot_nick));
    return say(`✅ Время вывода #${id}: ${formatMsk(at)}. Теперь ник бота:`, await botPicker(id, null));
  }
  const id = Number(nickMatch![1]);
  let nick: string;
  try {
    nick = robloxNick(msg.text.trim());
  } catch {
    return say('Ник Roblox: латиница, цифры и _ (3–20 символов). Нажми «➕ Новый ник бота» ещё раз.');
  }
  await tx(async (c) => {
    const { tradeBots } = await getSettings(c);
    // The first nick is the default withdrawal bot: a new one joins at the end and never pushes it out.
    if (!tradeBots.includes(nick)) await setSetting(c, 'trade_bots', [...tradeBots.slice(0, 9), nick]);
  });
  const outcome = await schedule(id, msg.from.id, { botNick: nick });
  if (!outcome.ok) return say(`Ник <code>${escapeHtml(nick)}</code> сохранён, но ${outcome.reason.toLowerCase()}.`);
  await refreshAdminMessages(outcome.row);
  return say(
    outcome.row.status === 'scheduled'
      ? `✅ Вывод #${id} назначен: ${formatMsk(ms(outcome.row.scheduled_at)!)}, бот <code>${escapeHtml(nick)}</code>.`
      : `✅ Бот <code>${escapeHtml(nick)}</code>. Теперь нажми «📅 Указать дату вывода» под заявкой.`,
  );
}

// ---------- Admin mini app ----------

export async function adminWithdrawals(status: string | null) {
  await advanceWithdrawals();
  const open = status !== 'history';
  const rows = await q<WithdrawalRow & { username: string | null; first_name: string; last_name: string | null; public_id: string; photo_url: string | null; deposited: string }>(
    `SELECT w.*, u.username, u.first_name, u.last_name, u.public_id, u.photo_url,
       (SELECT coalesce(sum(p.credited), 0) FROM star_payments p WHERE p.user_id = u.id)
         + (SELECT coalesce(sum(d.credited), 0) FROM item_deposits d WHERE d.user_id = u.id AND d.status = 'credited') AS deposited
     FROM withdrawals w JOIN users u ON u.id = w.user_id
     WHERE ${open ? `w.status IN ${OPEN_SQL}` : `w.status NOT IN ${OPEN_SQL}`}
     ORDER BY ${open ? 'COALESCE(w.scheduled_at, w.created_at) ASC' : 'w.updated_at DESC'} LIMIT 200`,
  );
  return rows.map((r) => ({
    ...view(r),
    botNick: r.bot_nick,
    user: {
      id: num(r.user_id),
      publicId: r.public_id,
      username: r.username,
      name: [r.first_name, r.last_name].filter(Boolean).join(' '),
      photoUrl: r.photo_url,
      display: displayName({ id: r.user_id, username: r.username, first_name: r.first_name, last_name: r.last_name }),
      /** The brainrot rank: big players' trades can go first. */
      rank: rankOf(num(r.deposited)).level,
    },
  }));
}

export async function adminWithdrawalAction(admin: Viewer, idParam: string, body: Body) {
  const id = int(idParam, 'заявка');
  let outcome: Outcome;
  if (body.action === 'schedule') {
    const at = body.at === undefined || body.at === null ? undefined : Number(body.at);
    if (at !== undefined && (!Number.isFinite(at) || at < Date.now() - 60_000 || at > Date.now() + 30 * 86_400_000)) {
      throw bad('invalid', 'Дата — в ближайшие 30 дней');
    }
    const botNick = body.botNick === undefined || body.botNick === '' ? undefined : robloxNick(body.botNick, 'ник бота');
    if (at === undefined && botNick === undefined) throw bad('invalid', 'Укажи дату или ник бота');
    outcome = await schedule(id, admin.id, { at, botNick });
  } else if (body.action === 'done') outcome = await finish(id, admin.id);
  else if (body.action === 'reject') outcome = await reject(id, admin.id, optStr(body.note, 'причина', 200));
  else throw bad('invalid', 'Неизвестное действие');
  if (!outcome.ok) throw bad('closed', outcome.reason);
  await afterResponse(() => refreshAdminMessages(outcome.row));
  return view(outcome.row);
}

export async function adminWithdrawal(idParam: string) {
  const w = await one<WithdrawalRow>('SELECT * FROM withdrawals WHERE id = $1', [int(idParam, 'заявка')]);
  if (!w) throw notFound('Заявка не найдена');
  return view(w);
}
