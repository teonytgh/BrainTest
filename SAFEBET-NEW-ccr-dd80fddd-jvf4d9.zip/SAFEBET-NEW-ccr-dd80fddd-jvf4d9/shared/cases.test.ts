import { describe, expect, it } from 'vitest';
import { MAX_RTP, PROFIT_SHARE, cutOkup, solveCaseChances, solveChances } from './cases';

const PRICES = [45, 45, 55, 71, 90, 120, 160, 420, 2100];

describe('hand-set chances', () => {
  it('without them the case follows prices as before', () => {
    const s = solveCaseChances(PRICES, PRICES.map(() => null), 99);
    expect(s.manual).toBe(false);
    expect(s.probs).toEqual(solveChances(PRICES, 99).probs);
  });

  it('fixed items keep exactly their chance, the automatic ones share the rest in the same proportions', () => {
    const fixed = PRICES.map((_, i) => (i === 0 ? 0 : i === 8 ? 0.000001 : i === 3 ? 0.3 : null));
    const s = solveCaseChances(PRICES, fixed, 99);
    expect(s.manual).toBe(true);
    expect(s.probs[0]).toBe(0);
    expect(s.probs[8]).toBe(0.000001);
    expect(s.probs[3]).toBe(0.3);
    expect(s.probs.reduce((a, b) => a + b, 0)).toBeCloseTo(1, 12);
    const autoIdx = [1, 2, 4, 5, 6, 7];
    const sub = solveChances(autoIdx.map((i) => PRICES[i]!), 99).probs;
    autoIdx.forEach((i, k) => expect(s.probs[i]).toBeCloseTo(sub[k]! * (1 - 0.3 - 0.000001), 12));
  });

  it('only fixed chances are scaled to 100 %; nothing droppable is not ok', () => {
    const s = solveCaseChances([50, 100], [0.2, 0.2], 60);
    expect(s.probs).toEqual([0.5, 0.5]);
    expect(s.ok).toBe(true);
    expect(solveCaseChances([50, 100], [0, 0], 60).ok).toBe(false);
    // A case paying out more than its price is still the admin's call.
    const rich = solveCaseChances([50, 100], [0, 1], 60);
    expect(rich.ok).toBe(true);
    expect(rich.rtp).toBeGreaterThan(1);
  });
});

describe('x4 / x8 luck (iteration 35)', () => {
  // A case like the real ones: cheap fillers, items near the price and a few dearer than the case.
  const prices = [5, 8, 12, 18, 25, 35, 45, 60, 80, 95, 110, 140, 200, 350, 700, 1500];
  const price = 100;

  it('multiplies the окуп chance and keeps the 88 % average', () => {
    const base = solveChances(prices, price, 1);
    for (const x of [2, 4, 8]) {
      const s = solveChances(prices, price, x);
      expect(s.profit).toBeCloseTo(PROFIT_SHARE * x, 3);
      expect(s.rtp).toBeCloseTo(base.rtp, 2);
      expect(s.rtp).toBeLessThanOrEqual(MAX_RTP + 1e-9);
    }
  });
});

describe('«Окуп ×0.5» (iteration 38)', () => {
  const mean = (probs: number[], prices: number[]) => probs.reduce((s, p, i) => s + p * prices[i]!, 0);
  it('halves the chance of every drop dearer than the case and gives it to the cheaper ones', () => {
    const s = solveCaseChances(PRICES, PRICES.map(() => null), 99);
    const c = solveCaseChances(PRICES, PRICES.map(() => null), 99, 1, 0.5);
    expect(c.profit).toBeCloseTo(s.profit / 2, 12);
    expect(c.probs.reduce((a, b) => a + b, 0)).toBeCloseTo(1, 12);
    expect(c.ev).toBeLessThan(s.ev);
    expect(c.ev).toBeCloseTo(mean(c.probs, PRICES), 9);
    // The cheaper drops keep their proportions.
    expect(c.probs[0]! / c.probs[3]!).toBeCloseTo(s.probs[0]! / s.probs[3]!, 9);
  });

  it('cuts hand-set chances too; leaves free cases, all-dear and nothing-dear cases alone', () => {
    const fixed = PRICES.map((_, i) => (i === 8 ? 0.2 : null));
    const c = solveCaseChances(PRICES, fixed, 99, 1, 0.5);
    expect(c.probs[8]).toBeCloseTo(0.1, 12);
    expect(c.rtp).toBeLessThan(solveCaseChances(PRICES, fixed, 99).rtp);
    expect(cutOkup([0.5, 0.5], [10, 20], 0, 0.5)).toEqual([0.5, 0.5]);
    expect(cutOkup([0.5, 0.5], [100, 200], 50, 0.5)).toEqual([0.5, 0.5]);
    expect(cutOkup([0.5, 0.5], [10, 20], 50, 0.5)).toEqual([0.5, 0.5]);
    expect(cutOkup([0.9, 0.1], [10, 100], 50, 1)).toEqual([0.9, 0.1]);
    // «Без окупа»: nothing dearer than the case drops at all.
    expect(cutOkup([0.9, 0.1], [10, 100], 50, 0)).toEqual([1, 0]);
    const half = cutOkup([0.9, 0.1], [10, 100], 50, 0.5);
    expect(half[1]).toBeCloseTo(0.05, 12);
    expect(half[0]).toBeCloseTo(0.95, 12);
  });
});
