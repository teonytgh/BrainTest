interface TelegramUser {
  id: number;
  first_name: string;
  last_name?: string;
  username?: string;
  photo_url?: string;
}

interface TelegramWebApp {
  initData?: string;
  platform?: string;
  isFullscreen?: boolean;
  requestFullscreen?(): void;
  exitFullscreen?(): void;
  onEvent?(event: string, cb: () => void): void;
  offEvent?(event: string, cb: () => void): void;
  initDataUnsafe?: { user?: TelegramUser };
  ready(): void;
  expand(): void;
  isVersionAtLeast(version: string): boolean;
  setHeaderColor(color: string): void;
  setBackgroundColor(color: string): void;
  openTelegramLink(url: string): void;
  openInvoice?(url: string, callback?: (status: InvoiceStatus) => void): void;
  /** Bot API 8.0: Telegram's chat picker for a message prepared with savePreparedInlineMessage. */
  shareMessage?(id: string, callback?: (sent: boolean) => void): void;
  HapticFeedback: {
    notificationOccurred(type: 'success' | 'error' | 'warning'): void;
    impactOccurred(style: 'light' | 'medium' | 'heavy' | 'rigid' | 'soft'): void;
    selectionChanged(): void;
  };
  BackButton: {
    show(): void;
    hide(): void;
    onClick(cb: () => void): void;
    offClick(cb: () => void): void;
  };
}

export type InvoiceStatus = 'paid' | 'cancelled' | 'failed' | 'pending';

declare global {
  interface Window {
    Telegram?: { WebApp?: TelegramWebApp };
  }
}

/** Telegram's header/background take hex only; the palette publishes its own as --tg-color. */
function appColor(): string {
  const c = getComputedStyle(document.documentElement).getPropertyValue('--tg-color').trim();
  return /^#[0-9a-f]{6}$/i.test(c) ? c : '#0b1020';
}

function webApp(): TelegramWebApp | null {
  return window.Telegram?.WebApp ?? null;
}

function supports(version: string): TelegramWebApp | null {
  const tg = webApp();
  return tg && tg.isVersionAtLeast(version) ? tg : null;
}

/**
 * Bot buttons open the app as `/?open=case/free` (Telegram keeps the hash for its launch data, so deep links
 * ride in the query string); turn that into our hash route once Telegram's script has read its params.
 */
function applyDeepLink() {
  const open = new URLSearchParams(window.location.search).get('open');
  if (open && /^[a-z]+(\/[a-z0-9-]+)?$/.test(open)) window.history.replaceState(null, '', `${window.location.pathname}#/${open}`);
}

export function initTelegram() {
  applyDeepLink();
  const tg = webApp();
  if (!tg) return;
  tg.ready();
  tg.expand();
  const themed = supports('6.1');
  const color = appColor();
  themed?.setHeaderColor(color);
  themed?.setBackgroundColor(color);
}

export const BOT_USERNAME = 'braincrashbot';
export const BOT_LINK = `https://t.me/${BOT_USERNAME}`;

/** Opens Telegram's share sheet (falls back to a new tab outside Telegram). */
export function share(text: string, url = BOT_LINK) {
  const link = `https://t.me/share/url?url=${encodeURIComponent(url)}&text=${encodeURIComponent(text)}`;
  const tg = supports('6.1');
  if (tg) tg.openTelegramLink(link);
  else window.open(link, '_blank', 'noopener');
}

/**
 * Opens a Stars invoice over the Mini App and resolves with Telegram's verdict.
 * Old clients without openInvoice get the invoice as a Telegram link and resolve 'pending'.
 */
export function openInvoice(link: string): Promise<InvoiceStatus> {
  const tg = supports('6.1');
  if (tg?.openInvoice) {
    const open = tg.openInvoice.bind(tg);
    return new Promise((resolve) => open(link, resolve));
  }
  if (tg) tg.openTelegramLink(link);
  else window.open(link, '_blank', 'noopener');
  return Promise.resolve('pending');
}

/**
 * Sends a prepared message (photo + text + button) through Telegram's chat picker.
 * Resolves true/false with Telegram's verdict, or null when this client cannot do it (pre-8.0, or Telegram's script
 * still counts an earlier picker as open and refuses a new one). Some clients never answer at all: back in the app
 * with no answer after a short wait counts as sent — like the t.me/share fallback, which can't tell either — so the
 * share button never hangs.
 */
export function shareMessage(preparedId: string): Promise<boolean | null> {
  const tg = supports('8.0');
  if (!tg?.shareMessage) return Promise.resolve(null);
  const send = tg.shareMessage.bind(tg);
  return new Promise((resolve) => {
    let settled = false;
    let wait = 0;
    const stop = onAppReturn(() => {
      clearTimeout(wait);
      wait = window.setTimeout(() => finish(true), 1500);
    });
    function finish(sent: boolean | null) {
      if (settled) return;
      settled = true;
      clearTimeout(wait);
      stop();
      resolve(sent);
    }
    try {
      send(preparedId, (sent) => finish(!!sent));
    } catch {
      finish(null);
    }
  });
}

export function openTelegramLink(url: string) {
  const tg = supports('6.1');
  if (tg) tg.openTelegramLink(url);
  else window.open(url, '_blank', 'noopener');
}

/** Fires when the player comes back to the Mini App (from a channel, a chat picker or another app). */
export function onAppReturn(cb: () => void): () => void {
  const tg = webApp();
  const visible = () => document.visibilityState === 'visible' && cb();
  document.addEventListener('visibilitychange', visible);
  tg?.onEvent?.('activated', cb);
  return () => {
    document.removeEventListener('visibilitychange', visible);
    tg?.offEvent?.('activated', cb);
  };
}

const DESKTOP_PLATFORMS = new Set(['tdesktop', 'macos', 'web', 'weba', 'webk', 'unigram']);

export function isDesktopTelegram(): boolean {
  return DESKTOP_PLATFORMS.has(webApp()?.platform ?? '');
}

/** Bot API 8.0 fullscreen; null when this Telegram client cannot do it. */
export function fullscreenApi() {
  const tg = supports('8.0');
  if (!tg?.requestFullscreen || !tg.exitFullscreen) return null;
  return {
    get on() {
      return !!tg.isFullscreen;
    },
    enter: () => tg.requestFullscreen!(),
    exit: () => tg.exitFullscreen!(),
    subscribe(cb: () => void) {
      tg.onEvent?.('fullscreenChanged', cb);
      return () => tg.offEvent?.('fullscreenChanged', cb);
    },
  };
}

/** Signed launch payload; empty outside Telegram. */
export function getInitData(): string {
  return webApp()?.initData ?? '';
}

export function haptic(kind: 'success' | 'error' | 'tap' | 'select') {
  const tg = supports('6.1');
  if (!tg) return;
  if (kind === 'tap') tg.HapticFeedback.impactOccurred('light');
  else if (kind === 'select') tg.HapticFeedback.selectionChanged();
  else tg.HapticFeedback.notificationOccurred(kind);
}

export function bindBackButton(visible: boolean, onBack: () => void): () => void {
  const tg = supports('6.1');
  if (!tg) return () => {};
  if (!visible) {
    tg.BackButton.hide();
    return () => {};
  }
  tg.BackButton.show();
  tg.BackButton.onClick(onBack);
  return () => tg.BackButton.offClick(onBack);
}
