import { createStore, useStore } from './createStore';

export type ToastTone = 'info' | 'success' | 'error';

export interface Toast {
  id: number;
  text: string;
  tone: ToastTone;
}

const toasts = createStore<Toast[]>([]);
let nextId = 1;

export const useToasts = () => useStore(toasts);

export function toast(text: string, tone: ToastTone = 'info') {
  // The same words already on screen (a mashed button, «Не спамь») don't stack up.
  if (toasts.get().some((t) => t.text === text)) return;
  const id = nextId++;
  toasts.set((list) => [...list.slice(-2), { id, text, tone }]);
  setTimeout(() => dismissToast(id), 4500);
}

export function dismissToast(id: number) {
  toasts.set((list) => (list.some((t) => t.id === id) ? list.filter((t) => t.id !== id) : list));
}
