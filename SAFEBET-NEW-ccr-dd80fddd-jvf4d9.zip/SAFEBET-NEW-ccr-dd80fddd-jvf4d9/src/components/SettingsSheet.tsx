import { useEffect, useState } from 'react';
import { Icon } from './Icon';
import { Sheet } from './Sheet';
import { Switch } from './Toggle';
import { cx } from '../lib/format';
import { isMuted, setMuted, sfx } from '../lib/sound';
import { fullscreenApi, isDesktopTelegram } from '../lib/telegram';
import { setLayoutPref, useLayout, type LayoutPref } from '../store/layout';
import { closeSheet, useUi } from '../store/ui';
import { routeHref } from '../lib/router';
import { startTour } from '../store/tour';
import { STREAMER_PARTS, setStreamer, useStreamer, type BlurLevel } from '../store/streamer';
import { bgMusic, useBgMusic } from '../lib/bgMusic';
import { autumnSeason } from '../lib/season';
import { setLeaves, useLeaves } from '../store/leaves';

const VIEWS: { value: LayoutPref; label: string }[] = [
  { value: 'auto', label: 'Авто' },
  { value: 'phone', label: 'Телефон' },
  { value: 'pc', label: 'ПК' },
];

const BLURS: { value: BlurLevel; label: string }[] = [
  { value: 'low', label: 'Слабо' },
  { value: 'mid', label: 'Средне' },
  { value: 'high', label: 'Сильно' },
];

/** «Листопад» (iteration 40): the autumn leaves can be switched off on a weak phone. */
function LeavesSetting() {
  const leaves = useLeaves();
  return (
    <div className="settings__row">
      <div>
        <p className="settings__title">Листопад</p>
        <p className="settings__text">Осенние листья падают поверх страниц. Если телефон слабый и что-то подтормаживает — выключи.</p>
      </div>
      <Switch on={leaves} label="Листопад" onChange={setLeaves} />
    </div>
  );
}

/** Режим стримера: the streamer's own private things blurred on screen (src/store/streamer.ts). */
function StreamerSettings() {
  const sm = useStreamer();
  return (
    <>
      <div className="settings__row">
        <div>
          <p className="settings__title">
            Режим стримера {sm.on && <span className="sm__badge">в эфире</span>}
          </p>
          <p className="settings__text">
            Прячет твоё личное, пока ты стримишь: баланс, историю, кнопки пополнения и вывода, свои ставки и данные аккаунта. Ниже можно
            выбрать, что именно.
          </p>
        </div>
        <Switch on={sm.on} label="Режим стримера" onChange={(on) => setStreamer((s) => ({ ...s, on }))} />
      </div>
      {sm.on && (
        <div className="sm" role="group" aria-label="Что прятать">
          <p className="sm__head">Что прятать</p>
          {STREAMER_PARTS.map((p) => (
            <div key={p.id} className="settings__row">
              <div>
                <p className="settings__title">{p.title}</p>
                <p className="settings__text">{p.text}</p>
              </div>
              <Switch on={sm.parts[p.id]} label={p.title} onChange={(on) => setStreamer((s) => ({ ...s, parts: { ...s.parts, [p.id]: on } }))} />
            </div>
          ))}
          <div className="sm__blur">
            <div>
              <p className="settings__title">Сила размытия</p>
              <p className="settings__text">Насколько сильно замыливать.</p>
            </div>
            <div className="segmented" role="radiogroup" aria-label="Сила размытия">
              {BLURS.map((b) => (
                <button
                  key={b.value}
                  type="button"
                  role="radio"
                  aria-checked={sm.blur === b.value}
                  className={cx('segmented__opt', sm.blur === b.value && 'is-on')}
                  onClick={() => setStreamer((s) => ({ ...s, blur: b.value }))}
                >
                  {b.label}
                </button>
              ))}
            </div>
          </div>
          <div className="settings__row">
            <div>
              <p className="settings__title">Показывать под курсором</p>
              <p className="settings__text">Наводишь на размытое — оно видно, пока курсор на нём. Тебе видно, в записи нет: курсор в кадре твой.</p>
            </div>
            <Switch on={sm.reveal} label="Показывать под курсором" onChange={(reveal) => setStreamer((s) => ({ ...s, reveal }))} />
          </div>
        </div>
      )}
    </>
  );
}

export function SettingsSheet() {
  const { sheet } = useUi();
  const { pref, mode } = useLayout();
  const [sound, setSound] = useState(() => !isMuted());
  const music = useBgMusic();
  const [fs] = useState(fullscreenApi);
  const [fullscreen, setFullscreen] = useState(() => !!fs?.on);

  useEffect(() => fs?.subscribe(() => setFullscreen(fs.on)), [fs]);

  function chooseView(v: LayoutPref) {
    setLayoutPref(v);
    sfx.tap();
    // A PC layout needs room: in Telegram Desktop the Mini App window starts narrow.
    if (v === 'pc' && fs && !fs.on && isDesktopTelegram()) fs.enter();
  }

  return (
    <Sheet open={sheet === 'settings'} onClose={closeSheet} title="Настройки">
      <div className="settings">
        <StreamerSettings />
        <div className="settings__row settings__row--stack">
          <div>
            <p className="settings__title">Вид</p>
            <p className="settings__text">
              {pref === 'auto' ? `Авто — сейчас ${mode === 'pc' ? 'ПК' : 'телефон'}: на широком окне включается режим ПК.` : mode === 'pc' ? 'Широкая раскладка с меню слева.' : 'Раскладка под экран телефона.'}
            </p>
          </div>
          <div className="segmented" role="radiogroup" aria-label="Вид приложения">
            {VIEWS.map((v) => (
              <button key={v.value} type="button" role="radio" aria-checked={pref === v.value} className={cx('segmented__opt', pref === v.value && 'is-on')} onClick={() => chooseView(v.value)}>
                {v.label}
              </button>
            ))}
          </div>
        </div>
        {fs && (
          <div className="settings__row">
            <div>
              <p className="settings__title">Во весь экран</p>
              <p className="settings__text">Растянуть приложение на всё окно Telegram.</p>
            </div>
            <button type="button" className="btn btn--ghost btn--sm" onClick={() => (fullscreen ? fs.exit() : fs.enter())}>
              <Icon name={fullscreen ? 'close' : 'arrowRight'} size={16} /> {fullscreen ? 'Выйти' : 'Включить'}
            </button>
          </div>
        )}
        <div className="settings__row">
          <div>
            <p className="settings__title">Звуки</p>
            <p className="settings__text">Щелчки рулетки, выигрыши, взрыв ракеты.</p>
          </div>
          <Switch
            on={sound}
            label="Звуки"
            onChange={(on) => {
              setSound(on);
              setMuted(!on);
              if (on) sfx.coin();
            }}
          />
        </div>
        <div className="settings__row">
          <div>
            <p className="settings__title">Фоновая музыка</p>
            <p className="settings__text">
              Две мелодии по кругу, чтобы играть было веселее. Молчит, когда звуки выключены и пока играет Raining Tacos. Музыка: «The
              Arplands» — LordZintick, lofi-луп — omfgdude (CC0, OpenGameArt).
            </p>
          </div>
          <Switch on={music} label="Фоновая музыка" onChange={(on) => bgMusic.set(on)} />
        </div>
        {autumnSeason() && <LeavesSetting />}
        <button
          type="button"
          className="settings__tour"
          onClick={() => {
            closeSheet();
            startTour();
          }}
        >
          <img src="/meowl/body.webp" alt="" />
          <span>
            Обучение с Meowl
            <small>Пройти заново: бесплатный кейс, разделы, задания</small>
          </span>
          <Icon name="chevronRight" size={18} />
        </button>
        <p className="settings__docs">
          <a href={routeHref('terms')} onClick={closeSheet}>
            Пользовательское соглашение
          </a>
          <a href={routeHref('privacy')} onClick={closeSheet}>
            Политика конфиденциальности
          </a>
          <span>18+ · играй ради удовольствия</span>
        </p>
      </div>
    </Sheet>
  );
}
