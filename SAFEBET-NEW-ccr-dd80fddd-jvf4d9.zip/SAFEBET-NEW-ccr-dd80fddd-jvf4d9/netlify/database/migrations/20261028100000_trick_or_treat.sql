-- «Сладость или гадость» (trick or treat): every player's next night key. Its sha256 is shown before the walk,
-- the key itself right after; door k gives a treat when the k-th 32-bit number of sha256('trick:' || seed) is
-- below that house's chance.
CREATE TABLE trick_seeds (
  user_id BIGINT PRIMARY KEY REFERENCES users (id),
  seed TEXT NOT NULL,
  hash TEXT NOT NULL,
  nonce INT NOT NULL DEFAULT 0
);

CREATE INDEX drops_trick_top ON drops (payout_value DESC) WHERE game = 'trick';

ALTER TABLE trick_seeds ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'anon') THEN
    EXECUTE 'REVOKE ALL ON trick_seeds FROM anon, authenticated';
  END IF;
END $$;
