import { describe, expect, it } from 'vitest';
import { BRIDGE_MAX_SPANS, COOKIE_IDLE_MS, LIGHT_FIELD, bridgeSpans, NIGHT_HP, SQUID_BREAK_MS, SQUID_GONE_MS, SQUID_STAGE, cookieOutline, outlineSamples } from '../../shared/squid';
import { SquidRoom } from './squid';

function setup(n: number, rngValues?: number[]) {
  let t = 1_000_000;
  let r = 0;
  const rng = rngValues ? () => rngValues[r++ % rngValues.length]! : Math.random;
  const room = new SquidRoom(() => t, rng);
  const inbox = new Map<number, Record<string, unknown>[]>();
  const socks = new Map<number, { send: (d: string) => void; close: () => void }>();
  for (let id = 1; id <= n; id++) {
    const sock = { send: (d: string) => d !== 'pong' && inbox.set(id, [...(inbox.get(id) ?? []), JSON.parse(d)]), close: () => {} };
    socks.set(id, sock);
    room.join(id, `p${id}`, sock);
  }
  room.init(t + 1000);
  const advance = (ms: number) => {
    const end = t + ms;
    while (t < end) {
      t = Math.min(end, t + 100);
      room.tick();
    }
  };
  const send = (id: number, msg: unknown) => room.message(id, socks.get(id)!, JSON.stringify(msg));
  const got = (id: number, type: string) => (inbox.get(id) ?? []).filter((m) => m.t === type);
  return { room, advance, send, got, socks, now: () => t };
}

/** From the lobby to the start of a stage (the earlier ones passed by everyone who is meant to). */
const toStage = (s: ReturnType<typeof setup>) => s.advance(1000 + SQUID_BREAK_MS + 100);

describe('«Игра Кальмара» room', () => {
  it('red light: running on green is fine, moving on red (after the grace) is out, standing still is out; no clock', () => {
    const s = setup(3, [0.5]);
    toStage(s);
    expect(s.room.phase).toBe('light');
    // No countdown for this stage: it ends when everyone is through.
    expect(s.got(1, 'ph').at(-1)).toMatchObject({ phase: 'light', ends: null });
    expect(SQUID_STAGE.light.ms).toBeNull();
    // Player 1 runs only while it's green; player 2 runs through red; player 3 never moves.
    let prog = 0;
    for (let i = 0; i < 1200 && s.room.phase === 'light'; i++) {
      const lights = s.got(1, 'li');
      const green = lights.length ? (lights.at(-1)!.green as boolean) : true;
      if (green && prog < LIGHT_FIELD) {
        prog += 12;
        s.send(1, { t: 'mv', p: prog });
      }
      if (!s.room.out.has(2)) s.send(2, { t: 'mv', p: (i + 1) * 12 });
      s.advance(100);
    }
    expect(s.got(2, 'ok').some((m) => m.id === 1)).toBe(true);
    expect(s.room.out.has(1)).toBe(false);
    expect(s.got(3, 'out').find((m) => m.id === 2)?.why).toBe('moved');
    // Player 3 stood through 20 s of green: asleep, out — and with that everyone is through, so the stage is over.
    expect(s.got(1, 'out').find((m) => m.id === 3)?.why).toBe('idle');
    expect(s.room.phase).toBe('break');
  });

  it('a stage without a clock ends the moment the last one is through, not on a timer', () => {
    const s = setup(2, [0.5]);
    toStage(s);
    // Both run to the finish on green; the stage ends right after, long before any 3-minute mark.
    const started = s.now();
    let prog = 0;
    for (let i = 0; i < 1200 && s.room.phase === 'light'; i++) {
      const lights = s.got(1, 'li');
      const green = lights.length ? (lights.at(-1)!.green as boolean) : true;
      if (green) {
        prog = Math.min(LIGHT_FIELD, prog + 12);
        for (const id of [1, 2]) s.send(id, { t: 'mv', p: prog });
      }
      s.advance(100);
    }
    expect(s.room.phase).toBe('break');
    expect(s.room.out.size).toBe(0);
    expect(s.now() - started).toBeLessThan(90_000);
  });

  it('a player who left during a stage without a clock is out after a while, so nobody waits for them', () => {
    const s = setup(2, [0.5]);
    toStage(s);
    s.room.leave(2, s.socks.get(2)!);
    s.advance(SQUID_GONE_MS - 1000);
    expect(s.room.out.has(2)).toBe(false);
    s.advance(1100);
    expect(s.got(1, 'out').find((m) => m.id === 2)?.why).toBe('gone');
  });

  it('the candy without a clock: 40 s without tracing dries it out', () => {
    const s = setup(1, [0.1]);
    s.advance(1100);
    (s.room as unknown as { startStage(stage: string): void }).startStage('cookie');
    expect(s.got(1, 'ph').at(-1)).toMatchObject({ phase: 'cookie', ends: null });
    s.advance(COOKIE_IDLE_MS - 1000);
    expect(s.room.out.has(1)).toBe(false);
    s.advance(1100);
    expect(s.got(1, 'out').find((m) => m.id === 1)?.why).toBe('idle');
    expect(s.room.phase).toBe('done');
  });

  it('a runner can not teleport: progress grows at most at the running speed', () => {
    const s = setup(1);
    toStage(s);
    s.send(1, { t: 'mv', p: LIGHT_FIELD });
    expect(s.got(1, 'ok')).toHaveLength(0);
  });

  it('the night: hits within reach take 15–20 HP, with a cooldown; at 0 HP a player is out', () => {
    const s = setup(2, [0.5]);
    toStage(s);
    // Both reach the finish of the first stage (no red light: rng 0.5 keeps the timings long; run in short steps).
    for (const id of [1, 2]) for (let p = 12; p <= LIGHT_FIELD; p += 12) s.send(id, { t: 'mv', p });
    s.advance(50);
    let guard = 0;
    while (s.room.phase !== 'night' && guard++ < 4000) {
      for (const id of [1, 2]) s.send(id, { t: 'mv', p: LIGHT_FIELD });
      s.advance(100);
    }
    expect(s.room.phase).toBe('night');
    // Walk player 1 next to player 2.
    const start = s.got(1, 'w')[0];
    expect(start).toBeTruthy();
    let x = 0;
    let y = 0;
    for (const m of s.got(1, 's')) for (const [id, px, py] of m.p as number[][]) if (id === 2) [x, y] = [px!, py!];
    const target = { x: x || -392, y: y || 0 };
    for (let i = 0; i < 80; i++) {
      s.send(1, { t: 'p', x: target.x + 20, y: target.y });
      s.advance(100);
    }
    s.send(1, { t: 'hit' });
    const hit = s.got(2, 'hit').at(-1)!;
    expect(hit).toMatchObject({ from: 1, to: 2 });
    expect(hit.dmg as number).toBeGreaterThanOrEqual(15);
    expect(hit.dmg as number).toBeLessThanOrEqual(20);
    // Cooldown: a second hit right away does nothing.
    s.send(1, { t: 'hit' });
    expect(s.got(2, 'hit')).toHaveLength(1);
    for (let i = 0; i < 10 && !s.room.out.has(2); i++) {
      s.advance(700);
      s.send(1, { t: 'hit' });
    }
    expect(s.room.out.get(2)).toBe('night');
    expect((s.got(1, 'hit').at(-1)!.hp as number) <= 0 || NIGHT_HP).toBeTruthy();
  });

  it('the candy: a slow trace along the line passes, off the line or too fast cracks it', () => {
    const s = setup(3, [0.1]);
    // rng 0.1 → every candy is a circle (COOKIE_SHAPES[0]); skip straight to the candy stage.
    const room = s.room as unknown as { startStage(stage: string): void };
    s.advance(1100);
    room.startStage('cookie');
    expect(s.room.phase).toBe('cookie');
    expect(s.got(1, 'ck').at(-1)).toEqual({ t: 'ck', shape: 'circle' });
    const samples = outlineSamples(cookieOutline('circle'), 240);
    // 1: slowly along the whole line (≈ 3.5 units at ~0.6 per second).
    let t0 = 0;
    for (let i = 0; i < samples.length; i += 8) {
      const pts = samples.slice(i, i + 8).map(([x, y], k) => [x, y, t0 + k * 25]);
      t0 += 8 * 25;
      s.advance(200);
      s.send(1, { t: 'tr', pts });
    }
    expect(s.got(2, 'ok').some((m) => m.id === 1)).toBe(true);
    // 2: off the line.
    s.send(2, { t: 'tr', pts: [[0, 0, 100]] });
    expect(s.got(3, 'out').find((m) => m.id === 2)?.why).toBe('off');
    // 3: along the line but far too fast.
    const fast = samples
      .filter((_, i) => i % 4 === 0)
      .slice(0, 12)
      .map(([x, y], k) => [x, y, 1000 + k * 20]);
    s.send(3, { t: 'tr', pts: fast });
    expect(s.got(1, 'out').find((m) => m.id === 3)?.why).toBe('fast');
  });

  it('the bridge: a wrong glass drops the walker and shows the right one; the next walks the known spans; places by crossing', () => {
    // rng 0.2 everywhere: every tempered glass is on the left; the order shuffle with a constant keeps it fixed.
    const s = setup(3, [0.2]);
    s.advance(1100);
    (s.room as unknown as { startStage(stage: string): void }).startStage('bridge');
    const first = s.got(1, 'br').at(-1)!;
    const walker = first.walker as number;
    expect(first.at).toBe(0);
    // The first walker picks right on span 0 and falls.
    s.send(walker, { t: 'ch', side: 'r' });
    expect(s.room.out.get(walker)).toBe('bridge');
    const st = s.got(1, 'st').at(-1)!;
    expect(st).toMatchObject({ span: 0, side: 'r', ok: false });
    // The next walker starts at span 1 (span 0 is known) and steps left all the way.
    const next = s.got(1, 'br').at(-1)!;
    expect(next.at).toBe(1);
    const second = next.walker as number;
    expect(first.known as unknown[]).toHaveLength(bridgeSpans(3));
    for (let i = 1; i < BRIDGE_MAX_SPANS; i++) s.send(second, { t: 'ch', side: 'l' });
    expect(s.room.places[0]).toBe(second);
    // The third walks the known bridge at once.
    expect(s.room.places).toHaveLength(2);
    expect(s.room.phase === 'done' || s.room.phaseEnds <= s.now()).toBe(true);
    s.advance(200);
    expect(s.room.phase).toBe('done');
    expect(s.room.call('results', null)).toMatchObject({ done: true, places: s.room.places });
  });

  it('an idle walker steps by itself when the turn runs out', () => {
    const s = setup(1, [0.2]);
    s.advance(1100);
    (s.room as unknown as { startStage(stage: string): void }).startStage('bridge');
    s.advance(7_100);
    expect(s.got(1, 'st').at(-1)).toMatchObject({ auto: true, span: 0 });
  });

  it('players joining after the lobby only watch', () => {
    const s = setup(1);
    s.advance(1100);
    const msgs: Record<string, unknown>[] = [];
    s.room.join(9, 'late', { send: (d) => msgs.push(JSON.parse(d)), close: () => {} });
    expect(msgs[0]).toMatchObject({ t: 'w', spectator: true });
    expect((s.room.call('stats', null) as { players: number }).players).toBe(1);
  });

  it('an immortal admin (trailers) survives running on red and a broken pane', () => {
    let t = 1_000_000;
    const room = new SquidRoom(() => t, () => 0.5);
    const msgs: Record<string, unknown>[] = [];
    const sock = { send: (d: string) => d !== 'pong' && msgs.push(JSON.parse(d)), close: () => {} };
    room.join(1, 'admin', sock, { god: true });
    room.join(2, 'p2', { send: () => {}, close: () => {} });
    room.init(t + 1000);
    const advance = (ms: number) => {
      const end = t + ms;
      while (t < end) {
        t = Math.min(end, t + 100);
        room.tick();
      }
    };
    advance(1000 + SQUID_BREAK_MS + 100);
    expect(room.phase).toBe('light');
    // Runs straight through red: never out.
    for (let i = 1; i <= 140; i++) {
      room.message(1, sock, JSON.stringify({ t: 'mv', p: i * 12 }));
      room.message(2, { send: () => {}, close: () => {} } as never, JSON.stringify({ t: 'mv', p: 0 }));
      advance(100);
    }
    expect(room.out.has(1)).toBe(false);
    // The glass (rng 0.5: every tempered pane is on the right): the left one breaks, the admin walks on.
    (room as unknown as { startStage(stage: string): void }).startStage('bridge');
    const br = msgs.filter((m) => m.t === 'br').at(-1)!;
    if (br.walker === 1) {
      room.message(1, sock, JSON.stringify({ t: 'ch', side: 'l' }));
      expect(msgs.filter((m) => m.t === 'st').at(-1)).toMatchObject({ ok: false, id: 1 });
      expect(room.out.has(1)).toBe(false);
    }
  });

  it('the bridge has as many spans as players reach it, 2 to 18', () => {
    expect([1, 2, 5, 16, 18, 40].map(bridgeSpans)).toEqual([2, 2, 5, 16, 18, 18]);
  });
});
