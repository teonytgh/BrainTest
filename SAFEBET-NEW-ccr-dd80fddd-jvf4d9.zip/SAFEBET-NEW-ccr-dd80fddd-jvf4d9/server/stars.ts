import { noteSource } from './growth';
import { STARS_MAX, STARS_MIN, depositBonus, starsToCoins } from '../shared/stars';
import { assertActive, type Viewer } from './auth';
import { db, ms, num, one, q, tx } from './db';
import { addCoins, addWager } from './economy';
import {
  bindReferral,
  markActiveReferral,
  notifyActiveFriend,
  notifyBound,
  notifyDepositShare,
  notifyMilestones,
  payDepositShare,
  payMilestones,
  recordClick,
  referrerByCode,
  type BindResult,
} from './referrals';
import { OWNER_IDS } from './env';
import { afterResponse } from './live';
import { HttpError, bad, notFound } from './errors';
import { partnerStillBound, resolveDepositPromo, spendDepositPromo } from './depositPromo';
import { PANEL_BUTTON, QUEUE_BUTTON, adminReplyKeyboard, handleDepositCallback, handleDepositReply, isAdmin, sendQueue } from './itemDeposits';
import { WITHDRAW_QUEUE_BUTTON, handleWithdrawCallback, handleWithdrawReply, sendWithdrawQueue } from './withdrawals';
import { CODE_BUTTON, CODE_PROMPT, codePrompt, redeemFromBot, welcome } from './botWelcome';
import { getSettings } from './settings';
import { botApi, escapeHtml, notify, safeEqual, webhookSecret } from './telegram';
import { displayName, getUser, upsertTelegramUser } from './users';
import { int, type Body } from './validate';
import { PASS_PAYLOAD, passCheckout, passPaid } from './pass';

/** An unpaid invoice stays payable for this long; older ones are refused at checkout. */
const ORDER_TTL_MS = 60 * 60 * 1000;
const PAYLOAD = /^stars:(\d{1,18})$/;
const fmt = (n: number) => n.toLocaleString('ru-RU');

interface OrderRow {
  id: string;
  user_id: string;
  stars: number;
  coins: string;
  bonus: string;
  bonus_percent: number;
  promo_code: string | null;
  promo_window: string | null;
  partner_id: string | null;
  status: 'pending' | 'paid';
  created_at: string;
  paid_at: string | null;
}

// ---------- Player API ----------

export async function createInvoice(v: Viewer, body: Body) {
  assertActive(v);
  const stars = int(body.stars, 'количество звёзд', STARS_MIN, STARS_MAX);
  const { starRate } = await getSettings();
  const coins = starsToCoins(stars, starRate);
  if (coins < 1) throw bad('too_small', 'Слишком мало звёзд для пополнения');
  const promo = await resolveDepositPromo(v.id, body.promo, 'stars');
  const percent = promo?.percent ?? 0;
  const bonus = depositBonus(coins, percent);

  const recent = await one<{ n: string }>(`SELECT count(*) AS n FROM star_orders WHERE user_id = $1 AND created_at > now() - interval '10 minutes'`, [v.id]);
  if (num(recent?.n) >= 15) throw new HttpError(429, 'too_many', 'Слишком много счетов подряд — подожди пару минут');

  // A partner code binds a player who has no partner yet (as «Бонус-код» does): from now on the partner earns their
  // share of this player's deposits.
  if (promo?.partnerId) {
    const partnerId = promo.partnerId;
    const bound = await tx((c) => bindReferral(c, v.id, partnerId));
    if (bound === 'bound') await afterResponse(() => notifyBound(partnerId, v.id));
    else if (bound !== 'already') throw bad('promo_invalid', 'Этот код партнёра тебе не подходит');
  }

  const order = await one<{ id: string }>(
    `INSERT INTO star_orders (user_id, stars, coins, bonus, bonus_percent, promo_code, promo_window, partner_id)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING id`,
    [v.id, stars, coins, bonus, percent, promo?.code ?? null, promo?.window ?? null, promo?.partnerId ?? null],
  );
  const orderId = num(order!.id);
  const total = coins + bonus;
  const link = await botApi<string>('createInvoiceLink', {
    title: `Пополнение баланса ${fmt(total)} B`.slice(0, 32),
    description: `Депозит в BrainrotCrash на ${fmt(total)} B${promo ? ` (${promo.partnerId ? 'код партнёра' : 'промокод'} ${promo.code}, +${percent}%)` : ''}`,
    payload: `stars:${orderId}`,
    provider_token: '',
    currency: 'XTR',
    prices: [{ label: `${fmt(total)} B`, amount: stars }],
  });
  if (!link) throw new HttpError(502, 'telegram_error', 'Telegram не создал счёт — попробуй ещё раз');
  return { orderId, link, stars, coins, bonus, percent, partner: promo?.partnerName ?? null };
}

export async function orderStatus(v: Viewer, idParam: string) {
  const id = int(idParam, 'счёт');
  const o = await one<OrderRow>('SELECT * FROM star_orders WHERE id = $1 AND user_id = $2', [id, v.id]);
  if (!o) throw notFound('Счёт не найден');
  return { orderId: id, status: o.status, stars: o.stars, coins: num(o.coins), bonus: num(o.bonus), percent: o.bonus_percent };
}

// ---------- Bot webhook ----------

interface TgUser {
  id: number;
  first_name?: string;
  last_name?: string;
  username?: string;
}

interface Update {
  callback_query?: { id: string; from: TgUser; data?: string; message?: { message_id: number; chat: { id: number } } };
  pre_checkout_query?: { id: string; from: TgUser; currency: string; total_amount: number; invoice_payload: string };
  message?: {
    from?: TgUser;
    chat: { id: number; type: string };
    text?: string;
    reply_to_message?: { text?: string };
    successful_payment?: { currency: string; total_amount: number; invoice_payload: string; telegram_payment_charge_id: string };
  };
  /** The player blocked (kicked) or unblocked the bot in their private chat. */
  my_chat_member?: { chat: { id: number; type: string }; new_chat_member: { status: string } };
}

type BotReply = Record<string, unknown> | null;

const reply = (r: BotReply) =>
  new Response(JSON.stringify(r ?? {}), { status: 200, headers: { 'content-type': 'application/json' } });

const playButton = (origin: string) => ({ inline_keyboard: [[{ text: '🎮 Играть', web_app: { url: `${origin}/` } }]] });

/** Telegram → us. Replies ride on the webhook response, so checkout answers arrive well inside the 10 s limit. */
export async function handleWebhook(req: Request): Promise<Response> {
  const expected = webhookSecret();
  const given = req.headers.get('x-telegram-bot-api-secret-token') ?? '';
  if (!expected || !safeEqual(given, expected)) return new Response('forbidden', { status: 403 });

  let update: Update;
  try {
    update = (await req.json()) as Update;
  } catch {
    return reply(null);
  }
  const origin = new URL(req.url).origin;
  if (update.pre_checkout_query) return reply(await preCheckout(update.pre_checkout_query));
  if (update.callback_query) {
    const cq = update.callback_query;
    // «🎟 Ввести код» under the welcome: stop the button's spinner and ask for the code.
    if (cq.data === CODE_BUTTON) {
      await afterResponse(() => botApi('answerCallbackQuery', { callback_query_id: cq.id }));
      return reply(codePrompt(cq.from.id));
    }
    return reply(await (cq.data?.startsWith('w:') ? handleWithdrawCallback(cq) : handleDepositCallback(cq)));
  }
  const member = update.my_chat_member;
  if (member?.chat.type === 'private') {
    const blocked = member.new_chat_member.status === 'kicked';
    await q(`UPDATE users SET bot_blocked_at = ${blocked ? 'now()' : 'NULL'} WHERE id = $1`, [member.chat.id]);
    return reply(null);
  }
  const msg = update.message;
  // A failed credit throws → 500 → Telegram redelivers the update; the charge id keeps it idempotent.
  if (msg?.successful_payment && msg.from) return reply(await creditPayment(msg.from, msg.successful_payment, origin));
  if (msg?.text && msg.from && msg.chat.type === 'private') {
    if (msg.reply_to_message) {
      if (msg.reply_to_message.text === CODE_PROMPT) return reply(await redeemFromBot(msg.from, msg.text, origin));
      const replied = { from: msg.from, text: msg.text, reply_to_message: msg.reply_to_message };
      const answered = (await handleWithdrawReply(replied)) ?? (await handleDepositReply(replied));
      if (answered) return reply(answered);
    }
    return reply(await command(msg.from, msg.text, origin));
  }
  return reply(null);
}

async function preCheckout(pq: NonNullable<Update['pre_checkout_query']>): Promise<BotReply> {
  const answer = (error?: string) => ({
    method: 'answerPreCheckoutQuery',
    pre_checkout_query_id: pq.id,
    ok: !error,
    ...(error ? { error_message: error } : {}),
  });
  try {
    // «Батл пасс» BPlus (iteration 37) has its own orders.
    const pass = PASS_PAYLOAD.exec(pq.invoice_payload);
    if (pass && pq.currency === 'XTR') return answer((await passCheckout(pass[1]!, pq.from.id, pq.total_amount)) ?? undefined);
    const m = PAYLOAD.exec(pq.invoice_payload);
    if (!m || pq.currency !== 'XTR') return answer('Неизвестный счёт');
    const o = await one<OrderRow & { banned: boolean; promo_used: boolean }>(
      `SELECT o.*,
         EXISTS (SELECT 1 FROM punishments p WHERE p.user_id = o.user_id AND p.kind = 'ban'
                 AND p.revoked_at IS NULL AND (p.until IS NULL OR p.until > now())) AS banned,
         EXISTS (SELECT 1 FROM auto_promo_uses a WHERE a.user_id = o.user_id AND a.window_index = o.promo_window AND a.status = 'used') AS promo_used
       FROM star_orders o WHERE o.id = $1`,
      [m[1]],
    );
    if (!o || num(o.user_id) !== pq.from.id) return answer('Этот счёт выписан на другой аккаунт');
    if (o.stars !== pq.total_amount) return answer('Сумма счёта не совпадает');
    if (o.status !== 'pending') return answer('Этот счёт уже оплачен');
    if (Date.now() - ms(o.created_at)! > ORDER_TTL_MS) return answer('Счёт устарел — создай новый в приложении');
    if (o.banned) return answer('Аккаунт заблокирован');
    if (o.bonus_percent > 0 && o.promo_used) return answer('Бонус промокода уже получен — создай счёт без промокода');
    return answer();
  } catch (e) {
    console.error('pre-checkout', e);
    return answer('Временная ошибка — попробуй ещё раз через минуту');
  }
}

async function creditPayment(from: TgUser, sp: NonNullable<NonNullable<Update['message']>['successful_payment']>, origin: string): Promise<BotReply> {
  const pass = PASS_PAYLOAD.exec(sp.invoice_payload);
  if (pass && sp.currency === 'XTR') {
    const r = await passPaid(pass[1]!, sp.telegram_payment_charge_id, sp.total_amount);
    if ('unknown' in r) {
      await alertOwners(`⚠️ Оплата BPlus по несуществующему счёту #${escapeHtml(pass[1]!)}: ${sp.total_amount} ⭐ от ID ${from.id}`);
      return null;
    }
    if ('duplicate' in r) return null;
    return {
      method: 'sendMessage',
      chat_id: r.userId,
      parse_mode: 'HTML',
      text: '✅ <b>BPlus</b> открыт! Награды BPlus за все пройденные уровни уже ждут в батл пассе.',
      reply_markup: { inline_keyboard: [[{ text: '🎟 Открыть батл пасс', web_app: { url: `${origin}/?open=pass` } }]] },
    };
  }
  const m = PAYLOAD.exec(sp.invoice_payload);
  if (!m || sp.currency !== 'XTR') {
    console.error('payment without order', sp);
    await alertOwners(`⚠️ Оплата без заказа: ${sp.total_amount} ⭐ от ID ${from.id}, charge <code>${escapeHtml(sp.telegram_payment_charge_id)}</code>`);
    return null;
  }
  const credited = await tx(async (c) => {
    const { rows } = await c.query<OrderRow>('SELECT * FROM star_orders WHERE id = $1 FOR UPDATE', [m[1]]);
    const o = rows[0];
    if (!o) return { unknown: true as const };
    const userId = num(o.user_id);
    // The order fixes the price; a charge for a different amount is credited at the current rate without the bonus.
    const exact = o.stars === sp.total_amount;
    // The order's bonus: a partner code's while the payer is that partner's; the auto promo's only if this window's
    // bonus wasn't already paid on another deposit.
    const bonusOk =
      exact && o.bonus_percent > 0
        ? o.partner_id !== null
          ? await partnerStillBound(c, userId, num(o.partner_id))
          : o.promo_window !== null && (await spendDepositPromo(c, userId, num(o.promo_window), o.bonus_percent))
        : false;
    const total = exact ? num(o.coins) + (bonusOk ? num(o.bonus) : 0) : starsToCoins(sp.total_amount, (await getSettings()).starRate);
    const ins = await c.query(
      `INSERT INTO star_payments (charge_id, order_id, user_id, stars, credited) VALUES ($1, $2, $3, $4, $5)
       ON CONFLICT (charge_id) DO NOTHING RETURNING 1`,
      [sp.telegram_payment_charge_id, o.id, userId, sp.total_amount, total],
    );
    if (!ins.rows.length) return { duplicate: true as const };
    await c.query(`UPDATE star_orders SET status = 'paid', paid_at = coalesce(paid_at, now()) WHERE id = $1`, [o.id]);
    await addCoins(c, userId, total);
    // «Отыгрыш»: a deposit is played through before a withdrawal (the promo bonus on top with it).
    await addWager(c, userId, total, 'deposit');
    const referrer = await markActiveReferral(c, userId, total);
    // The referrer's share: of what was paid for (the promo bonus on top doesn't count).
    const share = await payDepositShare(c, userId, exact ? num(o.coins) : total);
    const milestones = await payMilestones(c, userId);
    return { userId, total, bonus: bonusOk ? num(o.bonus) : 0, percent: bonusOk ? o.bonus_percent : 0, mismatch: !exact || userId !== from.id, referrer, share, milestones };
  });

  if ('unknown' in credited) {
    await alertOwners(`⚠️ Оплата по несуществующему счёту #${escapeHtml(m[1]!)}: ${sp.total_amount} ⭐ от ID ${from.id}`);
    return null;
  }
  if ('duplicate' in credited) return null;
  const { referrer: becameActive, share } = credited;
  if (share) await afterResponse(() => notifyDepositShare(share, becameActive !== null));
  else if (becameActive !== null) await afterResponse(() => notifyActiveFriend(becameActive));
  if (credited.milestones.length) await afterResponse(() => notifyMilestones(credited.milestones));
  if (credited.mismatch) {
    await alertOwners(`⚠️ Нестандартная оплата счёта #${m[1]}: ${sp.total_amount} ⭐ от ID ${from.id}, зачислено ${fmt(credited.total)} B`);
  }
  return {
    method: 'sendMessage',
    chat_id: credited.userId,
    parse_mode: 'HTML',
    text: `✅ Баланс пополнен на <b>${fmt(credited.total)} B</b>${credited.bonus ? `\nВключая бонус +${credited.percent}% по промокоду` : ''}`,
    reply_markup: playButton(origin),
  };
}

function alertOwners(html: string) {
  return Promise.all(OWNER_IDS.map((id) => notify(id, html)));
}

const TERMS = [
  '<b>Условия BrainrotCrash</b> · только 18+',
  '• Сервис только для совершеннолетних: при входе ты подтверждаешь, что тебе есть 18 лет.',
  '• Монеты B и брейнроты — внутриигровые предметы без денежной стоимости, обмену на деньги не подлежат.',
  '• Пополнение звёздами Telegram зачисляет монеты сразу после оплаты по курсу, показанному в приложении.',
  '• Перед выводом пополнения и бонусы нужно отыграть — поставить в играх (множитель и остаток видны в окне вывода).',
  '• Возврат звёзд возможен, если монеты не пришли из-за технической ошибки — пиши /paysupport.',
  '• За нарушения (мультиаккаунты, обман, баги) аккаунт может быть заблокирован или заморожен.',
  'Полные тексты — Пользовательское соглашение и Политика конфиденциальности — по кнопкам ниже.',
].join('\n');

async function command(from: TgUser, text: string, origin: string): Promise<BotReply> {
  const [head = '', ...rest] = text.trim().split(/\s+/);
  const cmd = head.toLowerCase().replace(/@\w+$/, '');
  const say = (html: string, withPlay = false) => ({
    method: 'sendMessage',
    chat_id: from.id,
    parse_mode: 'HTML',
    text: html,
    ...(withPlay ? { reply_markup: playButton(origin) } : {}),
  });

  if (cmd === '/start') {
    // Writing to the bot again means it is no longer blocked for us.
    await q('UPDATE users SET bot_blocked_at = NULL WHERE id = $1 AND bot_blocked_at IS NOT NULL', [from.id]);
    if (await isAdmin(from.id)) await botApi('sendMessage', { chat_id: from.id, text: 'Админ-кнопки — внизу 👇', reply_markup: adminReplyKeyboard() });
    // An ad or creator link (t.me/braincrashbot?start=s-<tag>): a new player is marked as that source's.
    const sourceTag = /^s-([a-z0-9_]{3,32})$/.exec(rest[0] ?? '')?.[1];
    if (sourceTag) {
      await upsertTelegramUser(db, { id: from.id, first_name: from.first_name ?? '', last_name: from.last_name, username: from.username });
      await noteSource(from.id, sourceTag).catch((e) => console.error('source', e));
    }
    const refCode = /^r-([A-Za-z0-9_]{4,16})$/.exec(rest[0] ?? '')?.[1];
    if (refCode) return referralStart(from, refCode, origin);
    if (rest[0] === 'friend') {
      return welcome(from.id, origin, { intro: '🎁 Друг позвал тебя — бесплатный кейс уже ждёт!', open: 'case/free' });
    }
    return welcome(from.id, origin);
  }
  if (cmd === '/code') return rest.length ? redeemFromBot(from, rest.join(' '), origin) : codePrompt(from.id);
  if ((cmd === '/admin' || text === QUEUE_BUTTON || text === WITHDRAW_QUEUE_BUTTON || text === PANEL_BUTTON) && (await isAdmin(from.id))) {
    if (text === QUEUE_BUTTON) return say(await sendQueue(from.id));
    if (text === WITHDRAW_QUEUE_BUTTON) return say(await sendWithdrawQueue(from.id));
    if (text === PANEL_BUTTON) {
      return {
        method: 'sendMessage',
        chat_id: from.id,
        text: 'Админ-панель — пополнения, кейсы, выдача:',
        reply_markup: { inline_keyboard: [[{ text: '🛠 Открыть админку', web_app: { url: `${origin}/?open=admin/deposits` } }]] },
      };
    }
    return { method: 'sendMessage', chat_id: from.id, text: 'Админ-кнопки — внизу 👇', reply_markup: adminReplyKeyboard() };
  }
  if (cmd === '/terms') {
    return {
      method: 'sendMessage',
      chat_id: from.id,
      parse_mode: 'HTML',
      text: TERMS,
      reply_markup: {
        inline_keyboard: [
          [{ text: '📄 Соглашение', web_app: { url: `${origin}/?open=terms` } }],
          [{ text: '🔒 Конфиденциальность', web_app: { url: `${origin}/?open=privacy` } }],
        ],
      },
    };
  }
  if (cmd === '/paysupport' || cmd === '/support') {
    const problem = rest.join(' ').slice(0, 600);
    if (!problem) {
      return say('Опиши проблему одним сообщением после команды, например:\n<code>/paysupport оплатил 100 ⭐, монеты не пришли</code>');
    }
    const user = await getUser(from.id);
    if (!user) return say('Сначала открой приложение кнопкой «Играть» — так мы найдём твой аккаунт.', true);
    const throttled = await one<{ ok: boolean }>(
      `UPDATE users SET support_at = now() WHERE id = $1 AND (support_at IS NULL OR support_at < now() - interval '10 minutes') RETURNING true AS ok`,
      [from.id],
    );
    if (!throttled) return say('Мы уже получили твоё обращение — ответим в течение дня. Повторить можно через 10 минут.');
    const payments = await q<{ stars: number; credited: string; created_at: string }>(
      'SELECT stars, credited, created_at FROM star_payments WHERE user_id = $1 ORDER BY created_at DESC LIMIT 3',
      [from.id],
    );
    const recent = payments.length ? payments.map((p) => `${p.stars ? `${p.stars} ⭐` : 'крипта'} → ${fmt(num(p.credited))} B`).join(', ') : 'нет';
    await alertOwners(
      `🆘 Поддержка по оплате от <a href="tg://user?id=${from.id}">${escapeHtml(displayName(user))}</a> (ID ${from.id})\n${escapeHtml(problem)}\nПоследние оплаты: ${recent}`,
    );
    return say('Передали администрации — с тобой свяжутся в Telegram. Номер аккаунта: <code>' + escapeHtml(user.public_id) + '</code>');
  }
  return null;
}

/**
 * `/start r-CODE` from a friend's link: count the visit, make the newcomer a referral (if nobody's yet) and
 * point them to «Бонусы», where the referral case waits for both.
 */
async function referralStart(from: TgUser, code: string, origin: string): Promise<BotReply> {
  await upsertTelegramUser(db, { id: from.id, first_name: from.first_name ?? '', last_name: from.last_name, username: from.username });
  const referrer = await referrerByCode(db, code);
  let bound: BindResult | null = null;
  if (referrer !== null) {
    await recordClick(referrer, from.id);
    bound = await tx((c) => bindReferral(c, from.id, referrer));
    if (bound === 'bound') await afterResponse(() => notifyBound(referrer, from.id));
  }
  return bound === 'bound'
    ? welcome(from.id, origin, { intro: '🎁 Друг позвал тебя — тебе уже лежит <b>реферальный кейс</b> в «Бонусах»!', open: 'bonuses' })
    : welcome(from.id, origin);
}

// ---------- Admin ----------

export async function adminPayments() {
  const [rows, totals] = await Promise.all([
    q<{ charge_id: string; order_id: string; user_id: string; stars: number; credited: string; created_at: string; username: string | null; first_name: string; last_name: string | null; bonus_percent: number }>(
      `SELECT p.*, u.username, u.first_name, u.last_name, o.bonus_percent
       FROM star_payments p JOIN users u ON u.id = p.user_id JOIN star_orders o ON o.id = p.order_id
       ORDER BY p.created_at DESC LIMIT 100`,
    ),
    one<{ stars: string; coins: string; count: string; stars24: string }>(
      `SELECT coalesce(sum(stars), 0) AS stars, coalesce(sum(credited), 0) AS coins, count(*) AS count,
         coalesce(sum(stars) FILTER (WHERE created_at > now() - interval '24 hours'), 0) AS stars24
       FROM star_payments WHERE stars > 0`,
    ),
  ]);
  return {
    totals: { stars: num(totals?.stars), coins: num(totals?.coins), count: num(totals?.count), stars24: num(totals?.stars24) },
    payments: rows.map((r) => ({
      chargeId: r.charge_id,
      orderId: num(r.order_id),
      userId: num(r.user_id),
      user: displayName({ id: r.user_id, username: r.username, first_name: r.first_name, last_name: r.last_name }),
      stars: r.stars,
      credited: num(r.credited),
      percent: r.bonus_percent,
      at: ms(r.created_at)!,
    })),
  };
}
