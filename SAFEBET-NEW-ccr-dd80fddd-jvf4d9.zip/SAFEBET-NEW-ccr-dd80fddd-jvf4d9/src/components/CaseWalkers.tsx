import { useEffect, useMemo, type CSSProperties, type RefObject } from 'react';
import { useCatalog } from '../api/queries';
import type { CaseDef } from '../../shared/types';

/**
 * Iteration 37: on every case card a few brainrots of that case stroll along the bottom of the art (the owner: «у
 * всех кейсах анимация — снизу проходят персонажи»). Transform only, paused off screen (`useOnscreen`), none with
 * reduced motion; a mystery case keeps its secret.
 */
export function CaseWalkers({ kase }: { kase: CaseDef }) {
  const catalog = useCatalog();
  const walkers = useMemo(() => {
    if (kase.mystery) return [];
    return kase.items
      .map((i) => catalog.byId.get(i.brainrotId))
      .filter((b): b is NonNullable<typeof b> => !!b && b.kind !== 'coins')
      .sort((a, b) => b.price - a.price)
      .slice(0, 3);
  }, [kase, catalog.byId]);
  if (!walkers.length) return null;
  // Each case its own rhythm, so the grid doesn't march in step.
  const seed = [...kase.id].reduce((h, c) => (h * 31 + c.charCodeAt(0)) % 997, 7);
  return (
    <span className="case-walk" aria-hidden="true">
      {walkers.map((b, i) => (
        <span key={b.id} className="case-walk__one" style={{ '--dur': `${9 + ((seed + i * 5) % 5)}s`, '--delay': `${-((seed * (i + 1)) % 9) - i * 3}s` } as CSSProperties}>
          <img src={b.image} alt="" loading="lazy" decoding="async" />
        </span>
      ))}
    </span>
  );
}

/** Marks the case cards inside `ref` that are on screen (`.is-onscreen`): their walkers move only then. */
export function useOnscreen(ref: RefObject<HTMLElement | null>, deps: unknown[]) {
  useEffect(() => {
    const root = ref.current;
    if (!root || typeof IntersectionObserver === 'undefined') return;
    const io = new IntersectionObserver(
      (entries) => {
        for (const e of entries) e.target.classList.toggle('is-onscreen', e.isIntersecting);
      },
      { rootMargin: '60px' },
    );
    root.querySelectorAll('.case-card').forEach((el) => io.observe(el));
    return () => io.disconnect();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);
}
