/** Synthesised UI sounds (Web Audio) — no audio files to download, works offline. */

const MUTE_KEY = 'brainrotcrash:muted';

function readMuted(): boolean {
  try {
    return localStorage.getItem(MUTE_KEY) === '1';
  } catch {
    return false;
  }
}

let muted = readMuted();
let ctx: AudioContext | null = null;
let noise: AudioBuffer | null = null;
let lastTick = 0;
let lastType = 0;
/** When the global press click last played (see pressFeedback): a component's own tap right after is skipped. */
let lastPress = 0;

function audio(): AudioContext | null {
  if (muted) return null;
  try {
    ctx ??= new AudioContext();
    if (ctx.state === 'suspended') void ctx.resume();
    return ctx;
  } catch {
    return null;
  }
}

function noiseBuffer(ac: AudioContext): AudioBuffer {
  if (noise) return noise;
  noise = ac.createBuffer(1, ac.sampleRate, ac.sampleRate);
  const data = noise.getChannelData(0);
  for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;
  return noise;
}

interface ToneOptions {
  freq: number;
  to?: number;
  type?: OscillatorType;
  dur?: number;
  vol?: number;
  delay?: number;
  /** Where it plays into (a score's own gain, so it can be cut short); the speakers by default. */
  out?: AudioNode;
}

function tone({ freq, to, type = 'sine', dur = 0.12, vol = 0.12, delay = 0, out }: ToneOptions) {
  const ac = audio();
  if (!ac) return;
  const t = ac.currentTime + delay;
  const osc = ac.createOscillator();
  const gain = ac.createGain();
  osc.type = type;
  osc.frequency.setValueAtTime(freq, t);
  if (to) osc.frequency.exponentialRampToValueAtTime(to, t + dur);
  gain.gain.setValueAtTime(0.0001, t);
  gain.gain.exponentialRampToValueAtTime(vol, t + 0.008);
  gain.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  osc.connect(gain).connect(out ?? ac.destination);
  osc.start(t);
  osc.stop(t + dur + 0.02);
}

function burst({ dur = 0.4, vol = 0.2, from = 2000, to = 300, type = 'lowpass' as BiquadFilterType, delay = 0, out = undefined as AudioNode | undefined }) {
  const ac = audio();
  if (!ac) return;
  const t = ac.currentTime + delay;
  const src = ac.createBufferSource();
  src.buffer = noiseBuffer(ac);
  const filter = ac.createBiquadFilter();
  filter.type = type;
  filter.frequency.setValueAtTime(from, t);
  filter.frequency.exponentialRampToValueAtTime(to, t + dur);
  const gain = ac.createGain();
  gain.gain.setValueAtTime(vol, t);
  gain.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  src.connect(filter).connect(gain).connect(out ?? ac.destination);
  src.start(t);
  src.stop(t + dur + 0.05);
}

/** A cat's «мяу» (iteration 37, the broom Meowl): a buzzy voice through two vowel formants, gliding up then down. */
function catMeow(vol = 0.07) {
  const ac = audio();
  if (!ac) return;
  const t = ac.currentTime;
  const dur = 0.5 + Math.random() * 0.15;
  const base = 520 + Math.random() * 120;
  const osc = ac.createOscillator();
  osc.type = 'sawtooth';
  osc.frequency.setValueAtTime(base * 0.85, t);
  osc.frequency.linearRampToValueAtTime(base * 1.45, t + dur * 0.35);
  osc.frequency.exponentialRampToValueAtTime(base * 0.8, t + dur);
  const vib = ac.createOscillator();
  const vibGain = ac.createGain();
  vib.frequency.value = 7;
  vibGain.gain.value = 9;
  vib.connect(vibGain).connect(osc.frequency);
  const out = ac.createGain();
  out.gain.setValueAtTime(0.0001, t);
  out.gain.exponentialRampToValueAtTime(vol, t + 0.05);
  out.gain.setValueAtTime(vol, t + dur * 0.6);
  out.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  // «i» → «a» → «u»: the formants slide with the vowel.
  for (const [f0, f1, f2, q] of [
    [2300, 1300, 800, 6],
    [700, 1100, 450, 5],
  ] as const) {
    const bp = ac.createBiquadFilter();
    bp.type = 'bandpass';
    bp.Q.value = q;
    bp.frequency.setValueAtTime(f0, t);
    bp.frequency.linearRampToValueAtTime(f1, t + dur * 0.4);
    bp.frequency.linearRampToValueAtTime(f2, t + dur);
    osc.connect(bp).connect(out);
  }
  out.connect(ac.destination);
  osc.start(t);
  vib.start(t);
  osc.stop(t + dur + 0.05);
  vib.stop(t + dur + 0.05);
}

/** A loop of wind for the flight: `set(0…1)` follows the speed, `stop()` fades it out. */
export interface WindLoop {
  set(level: number): void;
  stop(): void;
}

export const sfx = {
  tap: () => {
    if (performance.now() - lastPress < 160) return;
    tone({ freq: 620, type: 'triangle', dur: 0.05, vol: 0.06 });
  },
  /** The soft click every button, tab and switch makes. */
  press: () => {
    lastPress = performance.now();
    tone({ freq: 540, to: 660, type: 'sine', dur: 0.045, vol: 0.045 });
  },
  /** One typed letter of Meowl's speech: a soft typewriter key (a click of filtered noise, a slightly random pitch). */
  type: () => {
    const now = performance.now();
    if (now - lastType < 45) return;
    lastType = now;
    burst({ dur: 0.03, vol: 0.05, from: 5200 + Math.random() * 1600, to: 2400, type: 'bandpass' });
    tone({ freq: 1150 + Math.random() * 260, type: 'triangle', dur: 0.018, vol: 0.016 });
  },
  /** Meowl appears: a short «мяу» — a rising then falling glide. */
  meow: () => {
    tone({ freq: 520, to: 880, type: 'triangle', dur: 0.14, vol: 0.06 });
    tone({ freq: 880, to: 440, type: 'triangle', dur: 0.24, vol: 0.05, delay: 0.13 });
  },
  /** The broom Meowl's own «мяу» (a coin, an egg). */
  catMeow: () => catMeow(),
  /** «Небо Meowl»: the wind of the flight, louder and brighter with speed. */
  wind: (): WindLoop => {
    const ac = audio();
    if (!ac) return { set: () => {}, stop: () => {} };
    const src = ac.createBufferSource();
    src.buffer = noiseBuffer(ac);
    src.loop = true;
    const filter = ac.createBiquadFilter();
    filter.type = 'bandpass';
    filter.Q.value = 0.8;
    filter.frequency.value = 500;
    const gain = ac.createGain();
    gain.gain.value = 0.0001;
    src.connect(filter).connect(gain).connect(ac.destination);
    src.start();
    let stopped = false;
    return {
      set(level: number) {
        if (stopped) return;
        const v = Math.max(0, Math.min(1, level));
        const t = ac.currentTime;
        gain.gain.setTargetAtTime(0.0001 + v * 0.05, t, 0.25);
        filter.frequency.setTargetAtTime(380 + v * 900, t, 0.3);
      },
      stop() {
        if (stopped) return;
        stopped = true;
        gain.gain.setTargetAtTime(0.0001, ac.currentTime, 0.15);
        src.stop(ac.currentTime + 0.6);
      },
    };
  },
  /** A sword cutting the air. */
  swing: () => burst({ dur: 0.18, vol: 0.09, from: 1800, to: 5200, type: 'bandpass' }),
  /** A sword landing. */
  hit: () => {
    burst({ dur: 0.12, vol: 0.12, from: 2400, to: 600, type: 'lowpass' });
    tone({ freq: 240, to: 120, type: 'square', dur: 0.1, vol: 0.05 });
  },
  /** Knocked out of the sky: a falling whistle and a thump. */
  ko: () => {
    tone({ freq: 1200, to: 220, type: 'sine', dur: 0.6, vol: 0.06 });
    tone({ freq: 110, to: 60, type: 'sine', dur: 0.25, vol: 0.14, delay: 0.55 });
  },
  /** The fight begins (and ends): a war horn. */
  horn: () => {
    tone({ freq: 196, type: 'sawtooth', dur: 0.7, vol: 0.05 });
    tone({ freq: 294, type: 'sawtooth', dur: 0.7, vol: 0.035, delay: 0.05 });
    tone({ freq: 392, type: 'triangle', dur: 0.5, vol: 0.04, delay: 0.35 });
  },
  /** Rate-limited so fast reels don't turn into a buzz. */
  tick: () => {
    const now = performance.now();
    if (now - lastTick < 28) return;
    lastTick = now;
    tone({ freq: 1700, type: 'square', dur: 0.02, vol: 0.025 });
  },
  coin: () => {
    tone({ freq: 1320, type: 'triangle', dur: 0.08, vol: 0.08 });
    tone({ freq: 1980, type: 'triangle', dur: 0.14, vol: 0.07, delay: 0.07 });
  },
  win: () => [523, 659, 784, 1047].forEach((f, i) => tone({ freq: f, type: 'triangle', dur: 0.22, vol: 0.09, delay: i * 0.08 })),
  /** «Небо Meowl»: an admin dropped a rare egg — a shimmer and a rising horn call. */
  eggAlert: () => {
    burst({ dur: 0.7, vol: 0.06, from: 6000, to: 9000, type: 'highpass' });
    [392, 523, 659, 784].forEach((f, i) => tone({ freq: f, type: 'sawtooth', dur: 0.28, vol: 0.035, delay: 0.05 + i * 0.12 }));
    tone({ freq: 1046, type: 'triangle', dur: 0.6, vol: 0.06, delay: 0.55 });
  },
  /** «Анонс в игре»: a two-note fanfare with a shimmer — someone important is talking. */
  announce: () => {
    burst({ dur: 0.5, vol: 0.05, from: 5000, to: 9000, type: 'highpass' });
    tone({ freq: 659, type: 'triangle', dur: 0.22, vol: 0.1 });
    tone({ freq: 988, type: 'triangle', dur: 0.4, vol: 0.1, delay: 0.16 });
    tone({ freq: 1319, type: 'sine', dur: 0.5, vol: 0.05, delay: 0.32 });
  },
  /** «Небо Meowl»: an egg picked up — a sparkling run up. */
  egg: () => {
    [880, 1109, 1319, 1760, 2217].forEach((f, i) => tone({ freq: f, type: 'triangle', dur: 0.16, vol: 0.07, delay: i * 0.05 }));
    burst({ dur: 0.5, vol: 0.05, from: 4000, to: 8000, type: 'bandpass', delay: 0.1 });
  },
  bigWin: () => {
    [523, 659, 784, 1047, 1319].forEach((f, i) => tone({ freq: f, type: 'triangle', dur: 0.3, vol: 0.09, delay: i * 0.07 }));
    [1568, 2093].forEach((f, i) => tone({ freq: f, type: 'sine', dur: 0.5, vol: 0.05, delay: 0.4 + i * 0.1 }));
  },
  lose: () => {
    tone({ freq: 330, to: 140, type: 'sawtooth', dur: 0.45, vol: 0.05 });
    tone({ freq: 220, to: 90, type: 'sine', dur: 0.5, vol: 0.08, delay: 0.05 });
  },
  whoosh: () => burst({ dur: 0.45, vol: 0.12, from: 400, to: 3200, type: 'bandpass' }),
  open: () => {
    burst({ dur: 0.35, vol: 0.12, from: 600, to: 4000, type: 'bandpass' });
    tone({ freq: 880, to: 1760, type: 'sine', dur: 0.35, vol: 0.05, delay: 0.1 });
  },
  land: () => tone({ freq: 190, to: 80, type: 'sine', dur: 0.16, vol: 0.14 }),
  /** Fingers snapping: a dry, bright click with a little room. */
  snap: () => {
    burst({ dur: 0.05, vol: 0.55, from: 9000, to: 2500, type: 'bandpass' });
    tone({ freq: 1900, to: 700, type: 'triangle', dur: 0.04, vol: 0.12 });
    burst({ dur: 0.25, vol: 0.06, from: 4000, to: 900, type: 'bandpass', delay: 0.03 });
  },
  boom: () => {
    burst({ dur: 0.9, vol: 0.35, from: 1800, to: 60 });
    tone({ freq: 120, to: 40, type: 'sine', dur: 0.7, vol: 0.25 });
  },
  cashout: () => [784, 988, 1175, 1568].forEach((f, i) => tone({ freq: f, type: 'square', dur: 0.12, vol: 0.04, delay: i * 0.05 })),
  error: () => tone({ freq: 200, type: 'square', dur: 0.12, vol: 0.05 }),
  /** The case gathering power before it bursts open: a rising hum and a swelling hiss. */
  charge: (seconds: number, delay = 0, out?: AudioNode) => {
    tone({ freq: 110, to: 440, type: 'sawtooth', dur: seconds, vol: 0.035, delay, out });
    tone({ freq: 220, to: 880, type: 'sine', dur: seconds, vol: 0.05, delay, out });
    burst({ dur: seconds, vol: 0.06, from: 300, to: 5000, type: 'bandpass', delay, out });
  },
  /**
   * «Щелчок»'s walk: a dark drone that swells with Sammyni's aura, a heavy footstep on every step (`steps`, seconds
   * from now; every other one lands on an aura pulse and flares with an eerie chord and a whoosh), then the build-up
   * hum climbs from `walkEnd` to the snap at `snapAt`. Returns stop() for a skipped cutscene.
   */
  snapScore: (steps: number[], walkEnd: number, snapAt: number): { stop(): void } => {
    const ac = audio();
    if (!ac) return { stop() {} };
    const t0 = ac.currentTime;
    const master = ac.createGain();
    master.connect(ac.destination);
    // The drone: two detuned saws and a fifth below, through a low-pass that opens as the aura grows.
    const lp = ac.createBiquadFilter();
    lp.type = 'lowpass';
    lp.frequency.setValueAtTime(120, t0);
    lp.frequency.exponentialRampToValueAtTime(900, t0 + walkEnd);
    const drone = ac.createGain();
    drone.gain.setValueAtTime(0.0001, t0);
    drone.gain.exponentialRampToValueAtTime(0.06, t0 + 1.4);
    drone.gain.setValueAtTime(0.06, t0 + walkEnd - 0.3);
    drone.gain.exponentialRampToValueAtTime(0.0001, t0 + snapAt + 0.2);
    lp.connect(drone).connect(master);
    for (const [freq, type] of [[55, 'sawtooth'], [55.6, 'sawtooth'], [36.7, 'triangle']] as const) {
      const osc = ac.createOscillator();
      osc.type = type;
      osc.frequency.value = freq;
      osc.connect(lp);
      osc.start(t0);
      osc.stop(t0 + snapAt + 0.3);
    }
    steps.forEach((at, i) => {
      const heavy = i % 2 === 0;
      tone({ freq: heavy ? 74 : 92, to: 30, type: 'sine', dur: heavy ? 0.42 : 0.24, vol: heavy ? 0.26 : 0.14, delay: at, out: master });
      burst({ dur: 0.14, vol: heavy ? 0.12 : 0.06, from: 900, to: 110, type: 'lowpass', delay: at, out: master });
      if (heavy) {
        // The aura flares: a low diminished chord and a dark whoosh.
        [110, 130.8, 155.6].forEach((f) => tone({ freq: f, type: 'sine', dur: 0.7, vol: 0.022 + i * 0.0012, delay: at + 0.02, out: master }));
        burst({ dur: 0.55, vol: 0.035 + i * 0.002, from: 2600, to: 380, type: 'bandpass', delay: at + 0.03, out: master });
      }
    });
    sfx.charge(snapAt - walkEnd + 0.4, walkEnd - 0.4, master);
    return {
      stop() {
        master.gain.setTargetAtTime(0.0001, ac.currentTime, 0.05);
      },
    };
  },
  /** The lid flies open: a deep thump, a bright crack and a shimmer. */
  burstOpen: () => {
    tone({ freq: 90, to: 38, type: 'sine', dur: 0.5, vol: 0.28 });
    burst({ dur: 0.5, vol: 0.22, from: 5000, to: 400, type: 'lowpass' });
    [1568, 2093, 2637].forEach((f, i) => tone({ freq: f, type: 'sine', dur: 0.4, vol: 0.035, delay: 0.05 + i * 0.05 }));
  },
  /**
   * A reel card passing the marker: a short woody click. `speed` 0…1 brightens it while the reel flies and
   * lets it get heavier as it slows down.
   */
  reelTick: (speed: number) => {
    const now = performance.now();
    if (now - lastTick < 34) return;
    lastTick = now;
    const ac = audio();
    if (!ac) return;
    const v = Math.max(0, Math.min(1, speed));
    tone({ freq: 900 + v * 900, to: 500 + v * 400, type: 'triangle', dur: 0.03, vol: 0.05 - v * 0.02 });
    burst({ dur: 0.025, vol: 0.05, from: 4000, to: 1500, type: 'highpass' });
  },
  /** The drop is revealed: the dearer, the grander. */
  reveal: (tier: 'common' | 'rare' | 'epic' | 'legendary' | 'secret') => {
    const chords: Record<string, number[]> = {
      common: [523, 659],
      rare: [523, 659, 784],
      epic: [587, 740, 880, 1175],
      legendary: [523, 659, 784, 1047, 1319],
      secret: [440, 554, 659, 880, 1109, 1319],
    };
    const notes = chords[tier]!;
    tone({ freq: 150, to: 60, type: 'sine', dur: 0.25, vol: 0.18 });
    notes.forEach((f, i) => tone({ freq: f, type: 'triangle', dur: 0.5, vol: 0.075, delay: 0.04 + i * 0.06 }));
    if (tier === 'legendary' || tier === 'secret') {
      burst({ dur: 0.9, vol: 0.08, from: 6000, to: 2000, type: 'highpass', delay: 0.1 });
      [2093, 2637, 3136].forEach((f, i) => tone({ freq: f, type: 'sine', dur: 0.6, vol: 0.03, delay: 0.45 + i * 0.09 }));
    }
  },
  /** The stake is sucked into the ring. */
  absorb: () => {
    burst({ dur: 0.5, vol: 0.1, from: 3200, to: 300, type: 'bandpass' });
    tone({ freq: 660, to: 165, type: 'sine', dur: 0.5, vol: 0.06 });
  },
  /** Glass (or a pumpkin shell) cracking: a sharp snap and a few splinters. */
  crack: () => {
    burst({ dur: 0.12, vol: 0.3, from: 7000, to: 1200, type: 'highpass' });
    tone({ freq: 140, to: 50, type: 'sine', dur: 0.3, vol: 0.18 });
    for (let i = 0; i < 3; i++) burst({ dur: 0.05, vol: 0.08, from: 6000, to: 2500, type: 'highpass', delay: 0.06 + i * 0.05 + Math.random() * 0.03 });
  },
  /** A safe pick: a chime that climbs with each step (`step` 0, 1, 2…). */
  chime: (step: number) => {
    const f = 523 * 2 ** (Math.min(step, 14) / 12) * 1.5;
    tone({ freq: f, type: 'triangle', dur: 0.28, vol: 0.08 });
    tone({ freq: f * 1.5, type: 'sine', dur: 0.4, vol: 0.04, delay: 0.05 });
    burst({ dur: 0.08, vol: 0.06, from: 2500, to: 700, type: 'bandpass' });
  },
  /** A ghost: a wobbling, falling «woooo» with a breath of wind. */
  ghost: () => {
    const ac = audio();
    if (!ac) return;
    const t = ac.currentTime;
    const osc = ac.createOscillator();
    const lfo = ac.createOscillator();
    const depth = ac.createGain();
    const gain = ac.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(620, t);
    osc.frequency.exponentialRampToValueAtTime(180, t + 1.1);
    lfo.frequency.value = 7;
    depth.gain.value = 26;
    lfo.connect(depth).connect(osc.frequency);
    gain.gain.setValueAtTime(0.0001, t);
    gain.gain.exponentialRampToValueAtTime(0.11, t + 0.12);
    gain.gain.exponentialRampToValueAtTime(0.0001, t + 1.2);
    osc.connect(gain).connect(ac.destination);
    osc.start(t);
    lfo.start(t);
    osc.stop(t + 1.25);
    lfo.stop(t + 1.25);
    burst({ dur: 1.1, vol: 0.07, from: 900, to: 200, type: 'bandpass' });
    tone({ freq: 70, to: 40, type: 'sine', dur: 0.6, vol: 0.2 });
  },
  /** A runner's footfall: a soft low thump, a little different every time. */
  step: () => {
    const f = 90 + Math.random() * 50;
    tone({ freq: f, to: f * 0.6, type: 'sine', dur: 0.07, vol: 0.06 });
    burst({ dur: 0.04, vol: 0.025, from: 900, to: 300, type: 'lowpass' });
  },
  /** The start countdown: three low beeps, then a high one for «Вперёд!». */
  countdown: (go: boolean) => {
    tone({ freq: go ? 1046 : 523, type: 'square', dur: go ? 0.35 : 0.16, vol: 0.05 });
    if (go) burst({ dur: 0.3, vol: 0.08, from: 500, to: 3000, type: 'bandpass' });
  },
  /** Knock-knock on a wooden door. */
  knock: () => {
    [0, 0.17].forEach((d) => {
      tone({ freq: 180, to: 90, type: 'sine', dur: 0.09, vol: 0.16, delay: d });
      burst({ dur: 0.05, vol: 0.09, from: 1600, to: 500, type: 'lowpass', delay: d });
    });
  },
  /** The Haunted Fuse's tongue lashing out: a wet rising slurp. */
  slurp: () => {
    burst({ dur: 0.32, vol: 0.12, from: 300, to: 2400, type: 'bandpass' });
    tone({ freq: 140, to: 420, type: 'sine', dur: 0.26, vol: 0.08 });
  },
  /** …and swallowing the set: a deep gulp with a pop. */
  gulp: () => {
    tone({ freq: 210, to: 60, type: 'sine', dur: 0.32, vol: 0.22 });
    tone({ freq: 90, to: 50, type: 'triangle', dur: 0.4, vol: 0.12, delay: 0.08 });
    burst({ dur: 0.08, vol: 0.12, from: 900, to: 300, type: 'lowpass', delay: 0.02 });
  },
  /** A low growl when the house is poked. */
  growl: () => {
    const ac = audio();
    if (!ac) return;
    const t = ac.currentTime;
    const osc = ac.createOscillator();
    const lfo = ac.createOscillator();
    const depth = ac.createGain();
    const gain = ac.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(70, t);
    osc.frequency.linearRampToValueAtTime(52, t + 0.6);
    lfo.frequency.value = 23;
    depth.gain.value = 0.05;
    lfo.connect(depth).connect(gain.gain);
    gain.gain.setValueAtTime(0.0001, t);
    gain.gain.exponentialRampToValueAtTime(0.07, t + 0.08);
    gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.65);
    osc.connect(gain).connect(ac.destination);
    osc.start(t);
    lfo.start(t);
    osc.stop(t + 0.7);
    lfo.stop(t + 0.7);
  },
  /** A spider scurrying off: a dry little rustle. */
  scurry: () => {
    burst({ dur: 0.22, vol: 0.06, from: 6000, to: 2600, type: 'highpass' });
    [0, 0.05, 0.1].forEach((d) => tone({ freq: 2400, to: 1800, type: 'triangle', dur: 0.03, vol: 0.02, delay: d }));
  },
  /** A door creaking open. */
  creak: () => tone({ freq: 240, to: 520, type: 'sawtooth', dur: 0.35, vol: 0.025 }),
  /** A camera flash at the finish line. */
  flash: () => {
    burst({ dur: 0.18, vol: 0.12, from: 8000, to: 3000, type: 'highpass' });
    tone({ freq: 1800, to: 900, type: 'sine', dur: 0.12, vol: 0.03 });
  },
  /** A few random tinkles (sparkles around a rare drop). */
  sparkle: () => {
    for (let i = 0; i < 4; i++) tone({ freq: 2200 + Math.random() * 1800, type: 'sine', dur: 0.12, vol: 0.025, delay: i * 0.07 + Math.random() * 0.04 });
  },
};

/** Rocket engine hum whose pitch follows the multiplier. */
export function startEngine(): { set(multiplier: number): void; stop(): void } {
  const ac = audio();
  if (!ac) return { set() {}, stop() {} };
  const osc = ac.createOscillator();
  const gain = ac.createGain();
  const filter = ac.createBiquadFilter();
  osc.type = 'sawtooth';
  osc.frequency.value = 70;
  filter.type = 'lowpass';
  filter.frequency.value = 420;
  gain.gain.setValueAtTime(0.0001, ac.currentTime);
  gain.gain.exponentialRampToValueAtTime(0.035, ac.currentTime + 0.3);
  osc.connect(filter).connect(gain).connect(ac.destination);
  osc.start();
  return {
    set(m) {
      osc.frequency.setTargetAtTime(70 + Math.log(m) * 70, ac.currentTime, 0.1);
    },
    stop() {
      gain.gain.setTargetAtTime(0.0001, ac.currentTime, 0.05);
      osc.stop(ac.currentTime + 0.3);
    },
  };
}

export function isMuted() {
  return muted;
}

export function setMuted(value: boolean) {
  muted = value;
  try {
    localStorage.setItem(MUTE_KEY, value ? '1' : '0');
  } catch {
    // Preference just won't persist.
  }
  // The tacos track follows the app's sound switch (src/lib/tacosMusic.ts).
  window.dispatchEvent(new Event(SOUND_EVENT));
}

export const SOUND_EVENT = 'brainrotcrash:sound';

/** Browsers only allow audio after a user gesture; warm the context on the first tap. */
export function unlockAudioOnFirstTap() {
  const unlock = () => {
    audio();
    window.removeEventListener('pointerdown', unlock);
  };
  window.addEventListener('pointerdown', unlock);
}
