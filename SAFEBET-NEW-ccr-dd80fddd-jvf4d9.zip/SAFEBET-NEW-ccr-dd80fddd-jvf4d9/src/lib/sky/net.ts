/**
 * The «Небо Meowl» room socket (/api/room, a GameRoom Durable Object on Cloudflare): positions of the others in, ours
 * out (~4 a second while we move), coins taken and eggs dropped as they happen. It reconnects by itself with a fresh
 * ticket; the game goes on without it (picks are plain API calls), only the other players freeze.
 */
export interface FightState {
  on: boolean;
  until?: number;
  next?: number;
}

export interface RoomHandlers {
  welcome(players: [number, string, number, number, number][], fight: FightState | null, hp: [number, number, number][]): void;
  joined(id: number, name: string, x: number, y: number): void;
  left(id: number): void;
  moved(list: [number, number, number, number][]): void;
  /** `left`: what is left of the run's coin pool after this coin (null: no pool). */
  taken(key: string, by: number, left: number | null): void;
  eggs(eggs: { key: string; x: number; y: number; near: number }[], by: string): void;
  end(): void;
  status(online: boolean): void;
  /** Fights (iteration 37): starts / ends, a swing, a hit (the target's HP), a knock-out. */
  fight(f: FightState): void;
  swing(id: number): void;
  hit(from: number, to: number, hp: number): void;
  ko(id: number, by: number): void;
}

export class SkyRoomClient {
  private ws: WebSocket | null = null;
  private stopped = false;
  private backoff = 1000;
  private retry: ReturnType<typeof setTimeout> | undefined;
  private ping: ReturnType<typeof setInterval> | undefined;
  private last = { x: NaN, y: NaN, h: NaN };

  constructor(
    private ticket: () => Promise<string>,
    private on: RoomHandlers,
  ) {}

  async connect(first?: string) {
    if (this.stopped) return;
    let t = first;
    try {
      t ??= await this.ticket();
    } catch {
      return this.schedule();
    }
    const proto = location.protocol === 'https:' ? 'wss' : 'ws';
    const ws = new WebSocket(`${proto}://${location.host}/api/room?t=${encodeURIComponent(t)}`);
    this.ws = ws;
    ws.onopen = () => {
      this.backoff = 1000;
      this.on.status(true);
      clearInterval(this.ping);
      this.ping = setInterval(() => ws.readyState === WebSocket.OPEN && ws.send('ping'), 25_000);
      this.last = { x: NaN, y: NaN, h: NaN };
    };
    ws.onmessage = (ev) => {
      if (typeof ev.data !== 'string' || ev.data === 'pong') return;
      let m: Record<string, unknown>;
      try {
        m = JSON.parse(ev.data);
      } catch {
        return;
      }
      switch (m.t) {
        case 'w':
          return this.on.welcome((m.players as [number, string, number, number, number][]) ?? [], (m.fight as FightState) ?? null, (m.hp as [number, number, number][]) ?? []);
        case 'j':
          return this.on.joined(Number(m.id), String(m.n ?? 'Игрок'), Number(m.x) || 0, Number(m.y) || 0);
        case 'l':
          return this.on.left(Number(m.id));
        case 's':
          return this.on.moved((m.p as [number, number, number, number][]) ?? []);
        case 'c':
          return this.on.taken(String(m.k), Number(m.by), m.left === null || m.left === undefined ? null : Number(m.left));
        case 'e':
          return this.on.eggs((m.eggs as { key: string; x: number; y: number; near: number }[]) ?? [], String(m.by ?? 'Админ'));
        case 'end':
          return this.on.end();
        case 'f':
          return this.on.fight({ on: m.on === true, until: Number(m.until) || undefined, next: Number(m.next) || undefined });
        case 'sw':
          return this.on.swing(Number(m.id));
        case 'hit':
          return this.on.hit(Number(m.from), Number(m.to), Number(m.hp));
        case 'ko':
          return this.on.ko(Number(m.id), Number(m.by));
        case 'full':
          this.stopped = true;
          return;
      }
    };
    ws.onclose = () => {
      clearInterval(this.ping);
      this.on.status(false);
      if (this.ws === ws) this.ws = null;
      this.schedule();
    };
  }

  private schedule() {
    if (this.stopped || this.retry) return;
    this.retry = setTimeout(
      () => {
        this.retry = undefined;
        void this.connect();
      },
      this.backoff * (0.5 + Math.random()),
    );
    this.backoff = Math.min(this.backoff * 2, 20_000);
  }

  /** Our position, only when it changed (the room drops anything faster than ~5 a second). */
  send(x: number, y: number, h: number) {
    const ws = this.ws;
    if (!ws || ws.readyState !== WebSocket.OPEN) return;
    if (Math.abs(x - this.last.x) < 3 && Math.abs(y - this.last.y) < 3 && Math.abs(h - this.last.h) < 0.15) return;
    this.last = { x, y, h };
    ws.send(JSON.stringify({ t: 'p', x: Math.round(x), y: Math.round(y), h: Math.round(h * 100) / 100 }));
  }

  /** A sword swing (the room decides who it reaches). */
  hit() {
    const ws = this.ws;
    if (ws && ws.readyState === WebSocket.OPEN) ws.send('{"t":"hit"}');
  }

  close() {
    this.stopped = true;
    clearTimeout(this.retry);
    clearInterval(this.ping);
    this.ws?.close(1000);
  }
}
