import { paintChunk } from './terrain';

/** Draws map chunks off the main thread: { seed, cx, cy } in, the chunk's pixels (transferred) and objects out. */
const scope = self as unknown as { postMessage(msg: unknown, transfer: Transferable[]): void; onmessage: ((e: MessageEvent) => void) | null };

scope.onmessage = (e: MessageEvent<{ seed: number; cx: number; cy: number }>) => {
  const { seed, cx, cy } = e.data;
  const chunk = paintChunk(seed, cx, cy);
  scope.postMessage(chunk, [chunk.pixels.buffer]);
};
