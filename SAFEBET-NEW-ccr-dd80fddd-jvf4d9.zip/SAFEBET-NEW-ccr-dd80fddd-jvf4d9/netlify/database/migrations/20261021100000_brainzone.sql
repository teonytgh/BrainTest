-- The project moved to BrainZone: bot @brainzonebot, channel @brainzonechannel.

-- The free case asks for the new channel (unless an admin already picked another one).
UPDATE settings SET value = jsonb_set(value, '{channel}', '"@brainzonechannel"')
WHERE key = 'free_case_gate' AND value->>'channel' = '@safebet_tgk';

-- «Blocked the bot» was about the old bot. The new one finds out by itself: a refused message marks the
-- player again, /start or unblocking clears it.
UPDATE users SET bot_blocked_at = NULL WHERE bot_blocked_at IS NOT NULL;
