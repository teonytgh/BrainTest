import { resolveStaleBattles } from './battles';
import { healCases } from './caseHealth';
import { expireOverdue } from './itemDeposits';
import { advanceWithdrawals } from './withdrawals';
import { runNotifications } from './notifications';
import { broadcast } from './live';
import { bumpCatalogVersion } from './catalog';
import { settleDueGiveaways } from './giveaways';
import { closeIdleRoads } from './road';
import { closeIdleMines } from './mines';
import { ensureSchema } from './autoMigrate';
import { payPlayedMilestones } from './referrals';
import { q } from './db';
import { rotateFloatingPrices } from './floatingPrice';
import { skyTick } from './sky';
import { settleSquid } from './squid';
import { checkCryptoOrders } from './crypto';

/** Netlify stops a scheduled function after 30 s; bot messages get whatever time is left up to this. */
const NOTIFY_UNTIL_MS = 20_000;

/** One job failing must not cost the others their minute. */
async function job<T>(name: string, fn: () => Promise<T>): Promise<T | { error: string }> {
  try {
    return await fn();
  } catch (e) {
    console.error('tick job failed', name, e);
    return { error: String(e) };
  }
}

/**
 * Work that must happen even when nobody has the app open: cases re-balanced after price edits (first, so
 * battles below roll healthy tables), overdue trades, abandoned battles, road runs and mines rounds, giveaways whose time is up
 * «Крупные приглашения» reached by playing, and bot notifications. (Referrers' deposit share is paid on each friend's
 * deposit, at once — there is no weekly payout any more.)
 */
export async function runTick() {
  const started = Date.now();
  // Migrations the Worker applies itself (server/autoMigrate.ts) go first: the jobs below may need them.
  await job('schema', () => ensureSchema());
  // Floating prices move first, so the healer below sees the new ones.
  const floated = await job('float', async () => {
    const moved = await rotateFloatingPrices();
    if (moved.length) {
      await bumpCatalogVersion();
      broadcast('catalog');
    }
    return moved.map((m) => `${m.id} ${m.price}`);
  });
  const healed = await job('heal', async () => {
    const done = await healCases();
    if (done.length) {
      await bumpCatalogVersion();
      broadcast('catalog');
    }
    return done.map((h) => `${h.id} ${h.before}%→${h.after}%`);
  });
  const expiredTrades = await job('trades', () => expireOverdue());
  const withdrawals = await job('withdrawals', () => advanceWithdrawals());
  const soloBattles = await job('battles', () => resolveStaleBattles());
  const roads = await job('roads', () => closeIdleRoads());
  const mines = await job('mines', () => closeIdleMines());
  const giveaways = await job('giveaways', () => settleDueGiveaways());
  const milestones = await job('milestones', () => payPlayedMilestones());
  // «Небо Meowl» with auto-repeat: the next flight once its interval since the last start has passed.
  const sky = await job('sky', () => skyTick());
  // «Игра Кальмара»: the results once the room says it is over (players' apps usually get there first).
  const squid = await job('squid', () => settleSquid());
  // Crypto invoices whose webhook didn't come (or isn't set up): asked about in one call.
  const crypto = await job('crypto', () => checkCryptoOrders());
  // Kept for the app to look up an opening it didn't hear back about: a day is plenty.
  await job('open_results', () => q(`DELETE FROM case_open_results WHERE created_at < now() - interval '1 day'`));
  const notified = await job('notify', () => runNotifications(new Date(), started + NOTIFY_UNTIL_MS));
  return { floated, healed, expiredTrades, withdrawals, soloBattles, roads, mines, giveaways, milestones, sky, squid, crypto, notified };
}
