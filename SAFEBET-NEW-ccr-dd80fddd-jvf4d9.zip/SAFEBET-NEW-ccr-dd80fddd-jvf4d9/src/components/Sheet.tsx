import { useEffect, useId, useRef, type ReactNode } from 'react';
import { Icon } from './Icon';
import { cx } from '../lib/format';

interface SheetProps {
  open: boolean;
  onClose: () => void;
  title: string;
  children: ReactNode;
  variant?: 'bottom' | 'drawer';
  className?: string;
}

/** Native <dialog> gives focus trapping, Esc-to-close and inert background for free. */
export function Sheet({ open, onClose, title, children, variant = 'bottom', className }: SheetProps) {
  const ref = useRef<HTMLDialogElement>(null);
  const openRef = useRef(open);
  const titleId = useId();

  useEffect(() => {
    openRef.current = open;
    const dialog = ref.current;
    if (!dialog) return;
    if (open && !dialog.open) dialog.showModal();
    if (!open && dialog.open) dialog.close();
  }, [open]);

  return (
    <dialog
      ref={ref}
      className={cx('sheet', `sheet--${variant}`, className)}
      aria-labelledby={titleId}
      onClose={(e) => {
        // React bubbles `close` from a nested sheet (e.g. a picker inside a form) — only react to our own dialog.
        if (e.target !== e.currentTarget) return;
        // The close event is async; ignore it when the parent already closed this sheet (e.g. switched to another).
        if (openRef.current) onClose();
      }}
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      {open && (
        <div className="sheet__panel">
          <header className="sheet__head">
            <h2 id={titleId} className="sheet__title">
              {title}
            </h2>
            <button type="button" className="icon-btn icon-btn--ghost" aria-label="Закрыть" onClick={onClose}>
              <Icon name="close" />
            </button>
          </header>
          <div className="sheet__body">{children}</div>
        </div>
      )}
    </dialog>
  );
}
