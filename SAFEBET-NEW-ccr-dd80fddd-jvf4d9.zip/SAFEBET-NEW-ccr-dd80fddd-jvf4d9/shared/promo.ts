import { seededRandom } from './random';

export const PROMO_WINDOW_MS = 2 * 60 * 60 * 1000;
export const PROMO_MIN_PERCENT = 5;
export const PROMO_MAX_PERCENT = 15;

export const AUTO_PROMO_WORDS: readonly string[] = [
  'BRAINZ', 'ROCKET', 'LUCKY', 'TURBO', 'GOLDEN', 'SKIBIDI', 'MOBY', 'DRAGON', 'KRAKEN', 'HYDRA',
  'PEGASUS', 'CANDY', 'BOOST', 'JACKPOT', 'NITRO', 'COMET', 'GALAXY', 'FROST', 'BLAZE', 'STORM',
  'PIXEL', 'MEOWL', 'COSMO', 'RUBY', 'SAPPHIRE', 'THUNDER', 'VORTEX', 'ZENITH', 'ORBIT', 'PHOENIX',
];

export interface Promo {
  code: string;
  percent: number;
  windowIndex: number;
  endsAt: number;
}

/** Deterministic per 2-hour window, so every player sees the same code at the same time. */
export function promoForWindow(windowIndex: number): Promo {
  const rng = seededRandom(Math.imul(windowIndex, 0x9e3779b1) ^ 0x5bd1e995);
  const code = AUTO_PROMO_WORDS[Math.floor(rng() * AUTO_PROMO_WORDS.length)]!;
  const span = PROMO_MAX_PERCENT - PROMO_MIN_PERCENT + 1;
  const percent = PROMO_MIN_PERCENT + Math.floor(rng() * span);
  return { code, percent, windowIndex, endsAt: (windowIndex + 1) * PROMO_WINDOW_MS };
}

export function windowIndexAt(now: number): number {
  return Math.floor(now / PROMO_WINDOW_MS);
}

export function currentPromo(now: number = Date.now()): Promo {
  return promoForWindow(windowIndexAt(now));
}
