import { useMutation, useQuery, useQueryClient, type QueryKey } from '@tanstack/react-query';
import { useEffect, useId, useState, type ReactNode } from 'react';
import type * as AdminApi from '../../../server/admin';
import { BrainrotThumb } from '../../components/BrainrotCard';
import { Coin } from '../../components/Coin';
import { Icon } from '../../components/Icon';
import { Sheet } from '../../components/Sheet';
import { api, errorMessage } from '../../api/client';
import { refreshCatalog, useCatalog } from '../../api/queries';
import type { Brainrot } from '../../../shared/types';
import { cx, formatCoins } from '../../lib/format';
import { sfx } from '../../lib/sound';
import { toast } from '../../store/toast';

export type { AdminApi };
export type Data<F extends (...args: never[]) => unknown> = Awaited<ReturnType<F>>;
export type UserBrief = Data<typeof AdminApi.searchUsers>[number];

export function adminApi<T>(path: string, method = 'GET', body?: unknown): Promise<T> {
  return api<T>(`/api/admin${path}`, { method, body });
}

export function useAdminQuery<T>(key: QueryKey, path: string, enabled = true) {
  return useQuery({ queryKey: ['admin', ...key], queryFn: () => adminApi<T>(path), staleTime: 5_000, enabled });
}

/** Runs an admin action with a success toast and refreshes the admin lists (and the catalog when asked). */
export function useAdminAction<V, R = unknown>(fn: (vars: V) => Promise<R>, opts: { success?: string | ((r: R) => string); catalog?: boolean } = {}) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: fn,
    onSuccess: async (r) => {
      sfx.coin();
      if (opts.success) toast(typeof opts.success === 'function' ? opts.success(r) : opts.success, 'success');
      await qc.invalidateQueries({ queryKey: ['admin'] });
      if (opts.catalog) await refreshCatalog();
      await qc.invalidateQueries({ queryKey: ['me'] });
    },
    onError: (e) => {
      sfx.error();
      toast(errorMessage(e), 'error');
    },
  });
}

export function notifiedText(notified: boolean | undefined) {
  return notified ? 'уведомление отправлено в бота' : 'бот не смог отправить уведомление (игрок не запускал бота?)';
}

export function Card({ title, children, actions, className }: { title?: string; children: ReactNode; actions?: ReactNode; className?: string }) {
  return (
    <section className={cx('acard', className)}>
      {(title || actions) && (
        <header className="acard__head">
          {title && <h2 className="acard__title">{title}</h2>}
          {actions}
        </header>
      )}
      {children}
    </section>
  );
}

export function Field({ label, hint, children }: { label: string; hint?: string; children: ReactNode }) {
  return (
    <label className="afield">
      <span className="afield__label">{label}</span>
      {children}
      {hint && <span className="afield__hint">{hint}</span>}
    </label>
  );
}

export function Segmented<T extends string>({ value, onChange, options, label }: { value: T; onChange: (v: T) => void; options: { value: T; label: ReactNode }[]; label: string }) {
  return (
    <div className="segmented segmented--admin" role="radiogroup" aria-label={label}>
      {options.map((o) => (
        <button key={o.value} type="button" role="radio" aria-checked={value === o.value} className={cx('segmented__opt', value === o.value && 'is-on')} onClick={() => onChange(o.value)}>
          {o.label}
        </button>
      ))}
    </div>
  );
}

/** Two-tap confirmation for destructive actions. */
export function ConfirmButton({ children, onConfirm, disabled, className = 'btn btn--danger btn--sm', confirmText = 'Точно?' }: { children: ReactNode; onConfirm: () => void; disabled?: boolean; className?: string; confirmText?: string }) {
  const [armed, setArmed] = useState(false);
  useEffect(() => {
    if (!armed) return;
    const t = setTimeout(() => setArmed(false), 3000);
    return () => clearTimeout(t);
  }, [armed]);
  return (
    <button
      type="button"
      className={cx(className, armed && 'is-armed')}
      disabled={disabled}
      onClick={() => {
        if (armed) {
          setArmed(false);
          onConfirm();
        } else setArmed(true);
      }}
    >
      {armed ? confirmText : children}
    </button>
  );
}

function useDebounced<T>(value: T, ms: number): T {
  const [v, setV] = useState(value);
  useEffect(() => {
    const t = setTimeout(() => setV(value), ms);
    return () => clearTimeout(t);
  }, [value, ms]);
  return v;
}

export function UserLine({ user, extra }: { user: Pick<UserBrief, 'display' | 'id' | 'photoUrl' | 'name' | 'username'>; extra?: ReactNode }) {
  return (
    <span className="auser">
      {user.photoUrl ? <img className="auser__avatar" src={user.photoUrl} alt="" /> : <span className="auser__avatar auser__avatar--initial">{(user.username ?? user.name ?? '?').slice(0, 1).toUpperCase()}</span>}
      <span className="auser__text">
        <span className="auser__name">{user.display}</span>
        <span className="auser__id">ID {user.id}</span>
      </span>
      {extra}
    </span>
  );
}

/** "@username" or numeric Telegram ID, with live suggestions from players who opened the app. */
export function UserField({ value, onChange, label = 'Игрок' }: { value: string; onChange: (v: string) => void; label?: string }) {
  const id = useId();
  const [focused, setFocused] = useState(false);
  const q = useDebounced(value.trim(), 250);
  const search = useQuery({
    queryKey: ['admin', 'user-search', q],
    queryFn: () => adminApi<UserBrief[]>(`/users?q=${encodeURIComponent(q)}`),
    enabled: focused && q.length >= 1,
    staleTime: 10_000,
  });
  const suggestions = focused && q ? (search.data ?? []).slice(0, 6) : [];
  return (
    <div className="afield">
      <label className="afield__label" htmlFor={id}>
        {label}
      </label>
      <span className="ainput ainput--icon">
        <Icon name="tag" size={16} />
        <input
          id={id}
          value={value}
          autoComplete="off"
          autoCapitalize="off"
          spellCheck={false}
          placeholder="@username или ID"
          onChange={(e) => onChange(e.target.value)}
          onFocus={() => setFocused(true)}
          onBlur={() => setTimeout(() => setFocused(false), 150)}
        />
      </span>
      {suggestions.length > 0 && (
        <ul className="asuggest">
          {suggestions.map((u) => (
            <li key={u.id}>
              <button type="button" onMouseDown={(e) => e.preventDefault()} onClick={() => onChange(u.username ? `@${u.username}` : String(u.id))}>
                <UserLine user={u} />
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export function BrainrotPicker({
  value,
  onChange,
  label = 'Брейнрот',
  includeHidden = true,
  coins = false,
  exclude,
}: {
  value: string | null;
  onChange: (id: string) => void;
  label?: string;
  includeHidden?: boolean;
  /** Also list coin prizes (only cases take them). */
  coins?: boolean;
  /** Ids to leave out (e.g. already in the list being edited). */
  exclude?: ReadonlySet<string>;
}) {
  const catalog = useCatalog();
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState('');
  const selected = value ? catalog.byId.get(value) : null;
  const list = catalog.brainrots
    .filter((b) => b.status !== 'deleted' && (includeHidden || b.status === 'active') && (coins || b.kind !== 'coins') && !exclude?.has(b.id))
    .filter((b) => !q || b.name.toLowerCase().includes(q.toLowerCase()));
  return (
    <div className="afield">
      <span className="afield__label">{label}</span>
      <button type="button" className="apicker" onClick={() => setOpen(true)}>
        {selected ? (
          <>
            <BrainrotThumb brainrot={selected} size={36} />
            <span className="apicker__name">{selected.name}</span>
            <span className="apicker__price">
              <Coin size={12} /> {formatCoins(selected.price)}
            </span>
          </>
        ) : (
          <span className="apicker__name apicker__name--empty">Выбрать из каталога</span>
        )}
        <Icon name="chevronDown" size={18} />
      </button>
      <Sheet open={open} onClose={() => setOpen(false)} title="Каталог">
        <span className="ainput ainput--icon">
          <Icon name="sparkle" size={16} />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Поиск по названию" aria-label="Поиск" />
        </span>
        <div className="apick-grid">
          {list.map((b) => (
            <button
              key={b.id}
              type="button"
              className={cx('apick-grid__item', b.id === value && 'is-on', b.status !== 'active' && 'is-dim')}
              onClick={() => {
                onChange(b.id);
                setOpen(false);
              }}
            >
              <BrainrotThumb brainrot={b} size={56} />
              <span className="apick-grid__name">{b.name}</span>
              <span className="apick-grid__price">{formatCoins(b.price)}</span>
            </button>
          ))}
        </div>
      </Sheet>
    </div>
  );
}

export function useBrainrot(id: string | null): Brainrot | null {
  const catalog = useCatalog();
  return id ? catalog.byId.get(id) ?? null : null;
}

/** Same rule as scripts/normalize_brainrots.py: tall figures get a little less of the stage. */
function fitShare(aspect: number): number {
  return aspect >= 1 ? 0.94 : Math.max(0.8, 0.94 - 0.1 * Math.max(0, 1 / aspect - 1.15));
}

/** Trims transparent edges and centres the picture on a square stage, like the built-in brainrots. */
function stageCanvas(bitmap: ImageBitmap, size = 480): HTMLCanvasElement {
  const k = Math.min(1, 1024 / Math.max(bitmap.width, bitmap.height));
  const src = document.createElement('canvas');
  src.width = Math.max(1, Math.round(bitmap.width * k));
  src.height = Math.max(1, Math.round(bitmap.height * k));
  const sctx = src.getContext('2d', { willReadFrequently: true })!;
  sctx.drawImage(bitmap, 0, 0, src.width, src.height);
  const { data } = sctx.getImageData(0, 0, src.width, src.height);
  let [x0, y0, x1, y1] = [src.width, src.height, -1, -1];
  for (let y = 0; y < src.height; y++) {
    for (let x = 0; x < src.width; x++) {
      if (data[(y * src.width + x) * 4 + 3]! > 16) {
        if (x < x0) x0 = x;
        if (x > x1) x1 = x;
        if (y < y0) y0 = y;
        if (y > y1) y1 = y;
      }
    }
  }
  if (x1 < 0) [x0, y0, x1, y1] = [0, 0, src.width - 1, src.height - 1];
  const w = x1 - x0 + 1;
  const h = y1 - y0 + 1;
  const scale = (fitShare(w / h) * size) / Math.max(w, h);
  const out = document.createElement('canvas');
  out.width = out.height = size;
  out.getContext('2d')!.drawImage(src, x0, y0, w, h, (size - w * scale) / 2, (size - h * scale) / 2, w * scale, h * scale);
  return out;
}

async function fileToDataUrl(file: File, max = 512, stage = false, photo = false): Promise<string> {
  if (file.type === 'image/gif' && !photo) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result));
      reader.onerror = () => reject(new Error('read failed'));
      reader.readAsDataURL(file);
    });
  }
  const bitmap = await createImageBitmap(file);
  let canvas: HTMLCanvasElement;
  if (stage) {
    canvas = stageCanvas(bitmap);
  } else {
    const scale = Math.min(1, max / Math.max(bitmap.width, bitmap.height));
    canvas = document.createElement('canvas');
    canvas.width = Math.max(1, Math.round(bitmap.width * scale));
    canvas.height = Math.max(1, Math.round(bitmap.height * scale));
    canvas.getContext('2d')!.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
  }
  // Bot photos go as JPEG: Telegram's sendPhoto does not take WebP by URL.
  if (photo) return canvas.toDataURL('image/jpeg', 0.88);
  const webp = canvas.toDataURL('image/webp', 0.86);
  return webp.startsWith('data:image/webp') ? webp : canvas.toDataURL('image/png');
}

export function ImageInput({
  value,
  onChange,
  label = 'Картинка',
  stage,
  photo,
}: {
  value: string | null;
  onChange: (url: string | null) => void;
  label?: string;
  stage?: boolean;
  /** A photo for a bot message: up to 1280 px, JPEG, removable. */
  photo?: boolean;
}) {
  const id = useId();
  const [busy, setBusy] = useState(false);
  async function pick(file: File | undefined) {
    if (!file) return;
    setBusy(true);
    try {
      const dataUrl = await fileToDataUrl(file, photo ? 1280 : 512, stage, photo);
      const { url } = await adminApi<{ url: string }>('/upload', 'POST', { dataUrl });
      onChange(url);
      toast('Картинка загружена', 'success');
    } catch (e) {
      toast(errorMessage(e), 'error');
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="afield">
      <span className="afield__label">{label}</span>
      <div className="aimage">
        <span className={cx('aimage__preview', photo && 'aimage__preview--photo')}>{value ? <img src={value} alt="" /> : <Icon name="sparkle" size={26} />}</span>
        <label className="btn btn--ghost btn--sm" htmlFor={id}>
          {busy ? 'Загружаем…' : value ? 'Заменить' : 'Загрузить'}
        </label>
        {photo && value && (
          <button type="button" className="btn btn--ghost btn--sm" onClick={() => onChange(null)}>
            Убрать
          </button>
        )}
        <input id={id} className="visually-hidden" type="file" accept="image/png,image/jpeg,image/webp,image/gif" disabled={busy} onChange={(e) => void pick(e.target.files?.[0])} />
      </div>
    </div>
  );
}

/** `<input type="datetime-local">` values in Moscow time (the owner's clock), whatever the phone's zone. */
export const toMskInput = (ms: number) => new Date(ms + 3 * 3600_000).toISOString().slice(0, 16);
export const fromMskInput = (v: string) => Date.parse(`${v}:00Z`) - 3 * 3600_000;

const when = new Intl.DateTimeFormat('ru-RU', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
export const formatWhen = (ms: number | null | undefined) => (ms ? when.format(ms) : '—');

export function Empty({ children }: { children: ReactNode }) {
  return <p className="aempty">{children}</p>;
}
