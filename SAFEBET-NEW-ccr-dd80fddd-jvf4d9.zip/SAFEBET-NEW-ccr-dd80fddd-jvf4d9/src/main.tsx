import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { QueryClientProvider } from '@tanstack/react-query';
import '@fontsource-variable/unbounded';
import '@fontsource-variable/manrope';
import '@fontsource/rubik-wet-paint/cyrillic-400.css';
import '@fontsource/rubik-wet-paint/latin-400.css';
import './styles/tokens.css';
import './styles/palette-classic.css';
import './styles/palette-halloween.css';
import './styles/palette-crash.css';
import './styles/base.css';
import './styles/components.css';
import './styles/pages.css';
import './styles/cases.css';
import './styles/halloween.css';
import './styles/fuse.css';
import './styles/tacos.css';
import './styles/road.css';
import './styles/mines.css';
import './styles/events.css';
import './styles/giveaways.css';
import './styles/growth.css';
import './styles/meowl.css';
import './styles/streamer.css';
import './styles/halloween-theme.css';
import './styles/season-halloween.css';
import './styles/season-autumn.css';
import './styles/autumn.css';
import './styles/crash-theme.css';
import './styles/desktop.css';
import './styles/motion.css';
import './styles/perf.css';
import { App } from './App';
import { queryClient } from './api/queries';
import { unlockAudioOnFirstTap } from './lib/sound';
import { initTelegram } from './lib/telegram';
import { installPressFeedback } from './lib/feedback';
import { initLayout } from './store/layout';

initTelegram();
initLayout();
unlockAudioOnFirstTap();
installPressFeedback();

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <QueryClientProvider client={queryClient}>
      <App />
    </QueryClientProvider>
  </StrictMode>,
);
