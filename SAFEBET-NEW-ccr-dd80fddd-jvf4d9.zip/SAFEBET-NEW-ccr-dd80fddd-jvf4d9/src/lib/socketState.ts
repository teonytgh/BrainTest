/** Whether the live socket is up: then changes arrive by push and polls are only a slow safety net. */
let open = false;

export const setLiveSocketOpen = (value: boolean) => {
  open = value;
};

export const liveSocketOpen = () => open;
