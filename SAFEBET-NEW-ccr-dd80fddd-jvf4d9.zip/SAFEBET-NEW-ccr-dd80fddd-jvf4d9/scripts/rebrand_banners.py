"""Puts the BrainrotCrash name on pictures that came with the project; their art stays as it is.

    python3 scripts/rebrand_banners.py

free-case.jpg  footer «BRAINZONE @brainzonebot» → «BRAINROTCRASH @braincrashbot» in the app's fonts (Unbounded,
               Manrope from node_modules); the old one is filled along the background's diagonal stripes.
uploads/*.webp the «BrainZone» plates on five case pictures → «BrainrotCrash» (Roboto Condensed Bold). Inside each
               plate (a quadrilateral, clear of its bolts and bevels) the old letters are the bright pixels; they are
               filled from the plate around them (normalised convolution) — or, where the letters had a thick dark
               extrusion, the inside gets a new panel in the plate's colours; the new name follows the old baseline's
               slope (the chests are seen at an angle) and cap height, «Brainrot» in the old left half's colours and
               «Crash» in the right half's, each with its bottom-to-top gradient.

The /start banner (welcome.jpg) is the owner's own picture now. A changed promo picture needs PROMO_VERSION in
server/env.ts bumped: Telegram caches photos by URL.
"""
import os

import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageFont

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PROMO = os.path.join(ROOT, 'public', 'promo')
FONTS = os.path.join(ROOT, 'node_modules', '@fontsource-variable')
PLATE_FONT = os.path.join(ROOT, 'scripts', 'blender', 'fonts', 'RobotoCondensed-Bold.ttf')
# Case pictures with a «BrainZone» plate: the plate's inside around the old letters, clear of bolts and bevels.
PLATES = {
    '044e8e99cf509bf72c359b42.webp': [(137, 235), (321, 253), (321, 300), (262, 293), (245, 288), (200, 287), (137, 289)],
    '1af9a3f367565e1008bde1cb.webp': [(174, 314), (367, 314), (367, 361), (174, 361)],
    '6d6ae083e7cf2ccb75dacf02.webp': [(209, 262), (361, 252), (361, 289), (209, 303)],
    'da449b50f54ba97c8766ba2a.webp': [(220, 239), (375, 233), (375, 276), (220, 279)],
    'e46312e653619615ec365dc6.webp': [(221, 226), (368, 215), (368, 252), (221, 266)],
}
# Plates whose old letters have a thick dark 3D extrusion: filling only the bright letters leaves its ghost, so the
# whole inside gets a new panel in the plate's own colours (row by row) instead.
PANEL = {'044e8e99cf509bf72c359b42.webp'}


def grow(mask, r):
    """Round dilation of an 'L' mask by about r px (a blur, then a low threshold)."""
    return mask.filter(ImageFilter.GaussianBlur(r / 2.05)).point(lambda v: 255 if v > 5 else 0)


def free_case():
    path = os.path.join(PROMO, 'free-case.jpg')
    base = Image.open(path).convert('RGB')
    a = np.asarray(base).astype(np.float32)
    # Fill the old footer along the background's «/» stripes: each pixel blends the nearest clean pixels up-right
    # and down-left on its own stripe, by distance.
    x0, y0, x1, y1 = 62, 641, 504, 683
    out = a.copy()
    for y in range(y0, y1):
        up, down = y - (y0 - 1), (y1) - y
        for x in range(x0, x1):
            pu = a[y0 - 1, min(a.shape[1] - 1, x + up)]
            pd = a[y1, max(0, x - down)]
            out[y, x] = (pu * down + pd * up) / (up + down)
    img = Image.fromarray(np.clip(out, 0, 255).astype(np.uint8))

    draw = ImageDraw.Draw(img)
    brand = ImageFont.truetype(os.path.join(FONTS, 'unbounded', 'files', 'unbounded-latin-wght-normal.woff2'), 30)
    brand.set_variation_by_axes([900])
    nick = ImageFont.truetype(os.path.join(FONTS, 'manrope', 'files', 'manrope-latin-wght-normal.woff2'), 22)
    nick.set_variation_by_axes([700])
    x, base_y = 72, 673
    for part, rgb in (('BRAINROT', (240, 243, 250)), ('CRASH', (122, 172, 240))):
        for ch in part:  # letter-spacing 0.02em, as in the app's footer
            draw.text((x, base_y), ch, font=brand, fill=rgb, anchor='ls')
            x += draw.textlength(ch, font=brand) + 30 * 0.02
    draw.text((x + 14, base_y), '@braincrashbot', font=nick, fill=(150, 160, 182), anchor='ls')
    img.save(path, quality=90)
    print('free-case.jpg: footer redrawn')


def plate(name, poly):
    path = os.path.join(ROOT, 'public', 'uploads', name)
    img = Image.open(path).convert('RGBA')
    a = np.asarray(img).astype(np.float32)
    H, W = a.shape[:2]
    inside = Image.new('L', (W, H), 0)
    ImageDraw.Draw(inside).polygon(poly, fill=255)
    inside = np.asarray(inside) > 0
    text = inside & (a[:, :, :3].max(axis=2) > 110)  # the plate is near black inside
    ys, xs = np.nonzero(text)
    X0, X1 = xs.min(), xs.max() + 1

    # The old baseline (bottom of the letters, column by column) and cap height.
    cols = [(x, ys[xs == x].min(), ys[xs == x].max()) for x in range(X0, X1) if (xs == x).sum() >= 2]
    cx = np.array([c[0] for c in cols], float)
    bottom = np.array([c[2] for c in cols], float)
    slope, icept = np.polyfit(cx, bottom, 1)
    keep = np.abs(bottom - (slope * cx + icept)) < 3  # letters with round bottoms or tails sit off the line
    slope, icept = np.polyfit(cx[keep], bottom[keep], 1)
    cap = np.percentile([c[2] - c[1] + 1 for c in cols], 92)

    # Colours of the old halves by height above the baseline (each letter has a vertical gradient).
    def gradient(x0, x1, bins=12):
        m = text[:, x0:x1]
        yy, xx = np.nonzero(m)
        xx = xx + x0
        v = np.clip((slope * xx + icept - yy) / cap, 0, 0.999)
        px = a[yy, xx, :3]
        out = []
        for b in range(bins):
            sel = (v * bins).astype(int) == b
            out.append(px[sel].mean(axis=0) if sel.any() else None)
        known = [c for c in out if c is not None]
        last = known[0]
        for i, c in enumerate(out):
            out[i] = last = c if c is not None else last
        return np.array(out)

    w = X1 - X0
    left = gradient(X0, X0 + int(w * 0.4))
    right = gradient(X0 + int(w * 0.62), X1)

    if name in PANEL:
        # A new panel over the whole inside: each row takes the mean of its dark plate pixels, smoothed downwards.
        dark = inside & (a[:, :, :3].max(axis=2) < 70)
        rows = np.nonzero(inside.any(axis=1))[0]
        tone = [a[y][dark[y], :3].mean(axis=0) if dark[y].sum() >= 5 else None for y in rows]
        last = next(t for t in tone if t is not None)
        tone = np.array([last := (t if t is not None else last) for t in tone])
        tone = np.stack([np.convolve(np.pad(tone[:, ch], 3, mode='edge'), np.ones(7) / 7, mode='valid') for ch in range(3)], axis=1)
        soft = Image.new('L', (W * 4, H * 4), 0)  # antialiased edge: drawn 4× and scaled down
        ImageDraw.Draw(soft).polygon([(x * 4, y * 4) for x, y in poly], fill=255)
        cover = np.asarray(soft.resize((W, H), Image.LANCZOS), dtype=np.float32)[:, :, None] / 255
        panel = a[:, :, :3].copy()
        panel[rows] = tone[:, None, :]
        a[:, :, :3] = a[:, :, :3] * (1 - cover) + panel * cover
    else:
        # Fill the old letters (and their antialiased edges and shadow) from the plate around them.
        hole = (np.asarray(grow(Image.fromarray(text.astype(np.uint8) * 255), 3)) > 0) & inside
        known = (inside & ~hole).astype(np.float32)
        num = np.stack([_blur(a[:, :, ch] * known, 5) for ch in range(3)], axis=2)
        den = _blur(known, 5)
        fill = num / np.maximum(den, 1e-3)[:, :, None]
        a[hole, :3] = fill[hole]

    # The new name: as tall as the old caps, no wider than the old word, sheared onto the old baseline.
    word = ('Brainrot', 'Crash')
    size = 60
    while size > 6:
        font = ImageFont.truetype(PLATE_FONT, size)
        l_, t_, r_, b_ = font.getbbox(''.join(word), anchor='ls')
        cap_new = -font.getbbox('B', anchor='ls')[1]
        if r_ - l_ <= w * 1.04 and cap_new <= cap:
            break
        size -= 1
    xc = (X0 + X1) / 2
    base = slope * xc + icept
    bx = round(xc - (r_ - l_) / 2) - l_
    mask = Image.new('L', (W, H), 0)
    ImageDraw.Draw(mask).text((bx, base), ''.join(word), font=font, fill=255, anchor='ls')
    split = bx + font.getlength(word[0])
    colour = np.zeros((H, W, 4), np.float32)
    yy = np.arange(H)[:, None]
    v = np.clip((base - yy) / cap, 0, 0.999)
    idx = (v * len(left)).astype(int)
    first = (np.arange(W)[None, :] < split)[:, :, None]  # «Brainrot» columns (before the shear)
    colour[:, :, :3] = np.where(first, left[idx], right[idx])
    colour[:, :, 3] = np.asarray(mask)
    layer = Image.fromarray(colour.clip(0, 255).astype(np.uint8))
    shadow = Image.new('RGBA', (W, H), (0, 0, 0, 0))
    shadow.putalpha(mask.filter(ImageFilter.GaussianBlur(0.8)).point(lambda p: int(p * 0.7)))
    shadow = shadow.transform((W, H), Image.AFFINE, (1, 0, -1, 0, 1, -1))
    shear = (1, 0, 0, -slope, 1, slope * xc)  # input y = y - slope·(x - xc): the horizontal text follows the baseline
    out = Image.fromarray(np.clip(a, 0, 255).astype(np.uint8))
    out.alpha_composite(shadow.transform((W, H), Image.AFFINE, shear, Image.BICUBIC))
    out.alpha_composite(layer.transform((W, H), Image.AFFINE, shear, Image.BICUBIC))
    out.save(path, quality=92, method=6)
    print(name, f'old word x {X0}–{X1}, cap {cap:.0f}, slope {slope:.3f} → font {size}')


def _blur(arr, sigma):
    """Gaussian blur of a float array (separable, numpy only)."""
    r = int(3 * sigma)
    k = np.exp(-0.5 * (np.arange(-r, r + 1) / sigma) ** 2)
    k /= k.sum()
    pad = np.pad(arr, r, mode='edge')
    tmp = np.apply_along_axis(lambda m: np.convolve(m, k, mode='valid'), 1, pad)
    return np.apply_along_axis(lambda m: np.convolve(m, k, mode='valid'), 0, tmp)


if __name__ == '__main__':
    free_case()
    for name, poly in PLATES.items():
        plate(name, poly)
