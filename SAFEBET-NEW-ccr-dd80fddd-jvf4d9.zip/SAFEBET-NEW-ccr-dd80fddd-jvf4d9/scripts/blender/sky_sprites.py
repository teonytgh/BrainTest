"""Sprites for «Небо Meowl» (iteration 35): Meowl flying seen from straight above, and the things on the map below.

    blender -b -y --factory-startup --python scripts/blender/sky_sprites.py -- OUT_DIR [--preview] [--only=meowl,tree…]

Everything is voxels, like the brainrots and the snap cutscene's cast:

    meowl-0.png … meowl-5.png — Meowl from above, head up (north), big white wings with gold tips at six moments of a
                                wing beat; the app turns the sprite to the flight heading and draws the shadow itself
    pine.png, oak.png, oak-autumn.png, rock.png, house-red.png, house-blue.png, mill.png — map objects seen from the
                                south, 35° off vertical (roofs and a bit of the south walls show), each with its soft
                                contact shadow (a shadow catcher), lit from the north-west like the map's hill shading
    layout.json               — every sprite's size and the pixel where its ground point / centre is (the anchor)

`cwebp -q 88 -alpha_q 90` → public/sky/*.webp; layout.json → src/lib/sky/sprites.json.
"""
import json
import math
import os
import sys

import bmesh
import bpy
from bpy_extras.object_utils import world_to_camera_view
from mathutils import Vector

ARGS = sys.argv[sys.argv.index('--') + 1:] if '--' in sys.argv else []
POSITIONAL = [a for a in ARGS if not a.startswith('--')]
OUT = os.path.abspath(POSITIONAL[0] if POSITIONAL else 'sky_sprites')
PREVIEW = '--preview' in ARGS
ONLY = next((a.split('=', 1)[1].split(',') for a in ARGS if a.startswith('--only=')), None)
os.makedirs(OUT, exist_ok=True)
scene = bpy.context.scene
V = 0.1  # one voxel in Blender units


def lin(c):
    def ch(v):
        v /= 255
        return v / 12.92 if v <= 0.04045 else ((v + 0.055) / 1.055) ** 2.4
    return (ch(c[0]), ch(c[1]), ch(c[2]), 1.0)


def hexrgb(h):
    h = h.lstrip('#')
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def clear():
    for o in list(bpy.data.objects):
        bpy.data.objects.remove(o, do_unlink=True)
    for m in list(bpy.data.meshes):
        bpy.data.meshes.remove(m)


MATS = {}


def material(color):
    if color not in MATS:
        m = bpy.data.materials.new(color)
        m.use_nodes = True
        b = m.node_tree.nodes['Principled BSDF']
        b.inputs['Base Color'].default_value = lin(hexrgb(color))
        b.inputs['Roughness'].default_value = 0.75
        MATS[color] = m
    return MATS[color]


def h3(x, y, z, salt=0):
    """A small deterministic hash in [0, 1) for voxel colour jitter."""
    n = (x * 374761393 + y * 668265263 + z * 2147483647 + salt * 1442695041) & 0xFFFFFFFF
    n = (n ^ (n >> 13)) * 1274126177 & 0xFFFFFFFF
    return ((n ^ (n >> 16)) & 0xFFFF) / 65536


def build(name, voxels, parent=None, origin=(0, 0, 0)):
    """voxels: {(x, y, z): '#rrggbb'} → one object per colour; only faces between filled and empty cells are made."""
    by_color = {}
    for p, c in voxels.items():
        by_color.setdefault(c, []).append(p)
    objs = []
    dirs = [((1, 0, 0), ((1, 0, 0), (1, 1, 0), (1, 1, 1), (1, 0, 1))), ((-1, 0, 0), ((0, 0, 0), (0, 0, 1), (0, 1, 1), (0, 1, 0))),
            ((0, 1, 0), ((0, 1, 0), (0, 1, 1), (1, 1, 1), (1, 1, 0))), ((0, -1, 0), ((0, 0, 0), (1, 0, 0), (1, 0, 1), (0, 0, 1))),
            ((0, 0, 1), ((0, 0, 1), (1, 0, 1), (1, 1, 1), (0, 1, 1))), ((0, 0, -1), ((0, 0, 0), (0, 1, 0), (1, 1, 0), (1, 0, 0)))]
    for color, cells in by_color.items():
        bm = bmesh.new()
        for (x, y, z) in cells:
            for (dx, dy, dz), quad in dirs:
                if (x + dx, y + dy, z + dz) in voxels:
                    continue
                vs = [bm.verts.new(((x + qx - origin[0]) * V, (y + qy - origin[1]) * V, (z + qz - origin[2]) * V)) for qx, qy, qz in quad]
                bm.faces.new(vs)
        me = bpy.data.meshes.new(f'{name}-{color}')
        bm.to_mesh(me)
        bm.free()
        o = bpy.data.objects.new(f'{name}-{color}', me)
        o.data.materials.append(material(color))
        scene.collection.objects.link(o)
        if parent:
            o.parent = parent
        objs.append(o)
    return objs


def empty(name, loc=(0, 0, 0)):
    e = bpy.data.objects.new(name, None)
    e.location = loc
    scene.collection.objects.link(e)
    return e


def ellipsoid(cx, cy, cz, rx, ry, rz):
    for x in range(math.floor(cx - rx), math.ceil(cx + rx) + 1):
        for y in range(math.floor(cy - ry), math.ceil(cy + ry) + 1):
            for z in range(math.floor(cz - rz), math.ceil(cz + rz) + 1):
                if ((x + 0.5 - cx) / rx) ** 2 + ((y + 0.5 - cy) / ry) ** 2 + ((z + 0.5 - cz) / rz) ** 2 <= 1:
                    yield x, y, z


# ---------- Render set-up ----------

def lights(sun_dir=(-0.4, 0.32, 1.0), strength=3.2):
    sun = bpy.data.lights.new('sun', 'SUN')
    sun.energy = strength
    sun.angle = math.radians(26)
    o = bpy.data.objects.new('sun', sun)
    scene.collection.objects.link(o)
    o.rotation_euler = Vector(sun_dir).to_track_quat('Z', 'Y').to_euler()
    world = bpy.data.worlds.new('w')
    world.use_nodes = True
    world.node_tree.nodes['Background'].inputs['Color'].default_value = (0.78, 0.86, 1.0, 1)
    world.node_tree.nodes['Background'].inputs['Strength'].default_value = 0.55
    scene.world = world


def render_setup(size):
    scene.render.engine = 'CYCLES'
    scene.cycles.device = 'CPU'
    scene.cycles.samples = 24 if PREVIEW else 96
    scene.cycles.use_denoising = True
    scene.render.film_transparent = True
    scene.render.resolution_x = scene.render.resolution_y = size
    scene.render.image_settings.file_format = 'PNG'
    scene.render.image_settings.color_mode = 'RGBA'
    scene.view_settings.view_transform = 'Standard'


def camera(tilt_deg, ortho, target=(0, 0, 0)):
    d = bpy.data.cameras.new('cam')
    d.type = 'ORTHO'
    d.ortho_scale = ortho
    cam = bpy.data.objects.new('cam', d)
    scene.collection.objects.link(cam)
    t = math.radians(tilt_deg)
    dist = 20
    cam.location = (target[0], target[1] - math.sin(t) * dist, target[2] + math.cos(t) * dist)
    cam.rotation_euler = (t, 0, 0)
    scene.camera = cam
    return cam


def shadow_catcher(size=6):
    bpy.ops.mesh.primitive_plane_add(size=size, location=(0, 0, 0))
    p = bpy.context.active_object
    p.is_shadow_catcher = True
    return p


def anchor(cam, point=(0, 0, 0)):
    c = world_to_camera_view(scene, cam, Vector(point))
    return [round(c.x * scene.render.resolution_x, 1), round((1 - c.y) * scene.render.resolution_y, 1)]


LAYOUT = {}


def shoot(name, cam, ground=(0, 0, 0)):
    scene.render.filepath = os.path.join(OUT, f'{name}.png')
    bpy.ops.render.render(write_still=True)
    LAYOUT[name] = {'size': scene.render.resolution_x, 'anchor': anchor(cam, ground)}
    print('rendered', name, flush=True)


# ---------- Meowl from above ----------

FUR = '#c98a4b'
FUR_DARK = '#8f5a2c'
FUR_LIGHT = '#dca46a'
WHITE = '#f6efe4'


def meowl_body():
    vox = {}
    # Body: a round loaf, tabby on the back, white low down.
    for x, y, z in ellipsoid(0, -1.5, 3.4, 6.0, 6.8, 3.8):
        if z <= 1:
            c = WHITE
        elif (y + (z // 2)) % 5 == 0 and z >= 5 and abs(x) <= 3:
            c = FUR_DARK
        else:
            c = FUR if h3(x, y, z) > 0.18 else FUR_LIGHT
        vox[(x, y, z)] = c
    # A big round head in front, the «M» of a tabby on the crown, a white muzzle at the front.
    for x, y, z in ellipsoid(0, 7.5, 5.0, 6.6, 5.6, 4.8):
        c = FUR if h3(x, y, z, 1) > 0.15 else FUR_LIGHT
        if z >= 8 and y in (6, 7) and abs(x + 0.5) in (1.5, 3.5):
            c = FUR_DARK
        if z >= 8 and y == 8 and abs(x + 0.5) == 2.5:
            c = FUR_DARK
        if y >= 11 and z <= 5:
            c = WHITE
        vox[(x, y, z)] = c
    for x in (-1, 0):
        vox[(x, 13, 5)] = '#e7889a'
    for sx in (-1, 1):
        ex = 2 if sx > 0 else -3
        for x in (ex, ex + sx):
            vox[(x, 12, 7)] = '#46b06e'
        vox[(ex, 12, 8)] = '#1d2b22'
    # Ears: pointed, pink inside (on the front face).
    for sx in (-1, 1):
        for z, (x0, x1, y0, y1) in enumerate([(2, 6, 5, 8), (3, 5, 5, 8), (3, 5, 6, 7), (4, 4, 6, 7)], start=9):
            for x in range(x0, x1 + 1):
                for y in range(y0, y1 + 1):
                    xx = x if sx > 0 else -x - 1
                    inner = y == y1 and z < 11 and x0 < x < x1
                    vox[(xx, y, z)] = '#e9a0ad' if inner else FUR
    # Tail: a short curl behind, darker rings, white tip.
    for i in range(10):
        t = i / 9
        cx = 3.6 * math.sin(t * 2.2)
        cy = -8 - i * 0.9
        r = 1.9 - t * 0.6
        for x, y, z in ellipsoid(cx, cy, 3.8 + t, r, 1.1, r):
            vox[(x, y, z)] = WHITE if i >= 8 else (FUR_DARK if i % 3 == 1 else FUR)
    return vox


def capsule(vox, ax, ay, bx, by, width, color, z=0):
    """Fills the cells within width/2 of the segment a–b (a feather)."""
    r = width / 2
    for x in range(math.floor(min(ax, bx) - r) - 1, math.ceil(max(ax, bx) + r) + 2):
        for y in range(math.floor(min(ay, by) - r) - 1, math.ceil(max(ay, by) + r) + 2):
            px, py = x + 0.5, y + 0.5
            dx, dy = bx - ax, by - ay
            t = max(0.0, min(1.0, ((px - ax) * dx + (py - ay) * dy) / (dx * dx + dy * dy or 1)))
            d = math.hypot(px - (ax + t * dx), py - (ay + t * dy))
            if d <= r:
                tip = t > 0.8
                vox[(x, y, z)] = color(tip)


def wing_voxels():
    """One wing (the right one), lying flat; x outward from the shoulder, y along the body (front = +y)."""
    vox = {}
    whites = ['#fdfaf3', '#e6dccb']
    # Secondaries along the arm, pointing back.
    for i in range(7):
        ox = 1.5 + i * 1.7
        ln = 6.5 + i * 0.35
        a = math.radians(-96 + i * 3)
        col = whites[i % 2]
        capsule(vox, ox, -0.5, ox + math.cos(a) * ln, -0.5 + math.sin(a) * ln, 2.6, lambda tip, c=col: '#e8b552' if tip else c)
    # Primaries fanning from the wrist: long, the outer ones sweeping back.
    for i in range(7):
        ox = 12.5 + i * 0.55
        ln = 13.5 - abs(i - 2) * 0.7
        a = math.radians(-12 - i * 11)
        col = whites[(i + 1) % 2]
        capsule(vox, ox, 0.5, ox + math.cos(a) * ln, 0.5 + math.sin(a) * ln, 2.0, lambda tip, c=col: '#e2a33a' if tip else c)
    # Coverts: a rounded band along the front, a layer above, with the gold leading edge.
    for x in range(0, 16):
        t = x / 15
        top = 2.4 - 1.4 * t * t
        for y in range(math.floor(top - 3.4), math.ceil(top) + 1):
            if y > top or y < top - 3.4:
                continue
            c = '#f2cf7a' if y >= top - 0.9 else ('#fffaf0' if (x + y) % 3 else '#f3ecdf')
            vox[(x, y, 1)] = c
    return vox


def meowl(frames=6):
    clear()
    lights()
    render_setup(160 if PREVIEW else 256)
    cam = camera(0, 6.2, target=(0, 0.2, 0))
    body = empty('meowl')
    build('body', meowl_body(), parent=body)
    wings = []
    for side in (1, -1):
        pivot = empty(f'shoulder{side}', loc=(side * 5.4 * V, 0.5 * V, 4.2 * V))
        pivot.parent = body
        vox = wing_voxels()
        if side < 0:
            vox = {(-x - 1, y, z): c for (x, y, z), c in vox.items()}
        build(f'wing{side}', vox, parent=pivot)
        wings.append((pivot, side))
    for k in range(frames):
        # A strong beat: seen from above, a raised wing looks shorter.
        angle = math.radians(8 + 48 * math.cos(2 * math.pi * k / frames))
        for pivot, side in wings:
            pivot.rotation_euler = (0, -side * angle, 0)
        shoot(f'meowl-{k}', cam, ground=(0, 0.2, 0))


# ---------- Map objects ----------

def env_scene(size, ortho):
    clear()
    lights()
    render_setup(size)
    shadow_catcher()
    return camera(35, ortho, target=(0, 0, 0.45))


def pine():
    cam = env_scene(112 if PREVIEW else 160, 2.0)
    vox = {}
    for x in (-1, 0):
        for y in (-1, 0):
            for z in range(0, 3):
                vox[(x, y, z)] = '#6e4a2c'
    for z in range(3, 16):
        r = 5.6 * (1 - (z - 3) / 13.5) + 0.6
        if (z - 3) % 4 == 3:
            r -= 1.1
        for x in range(-6, 6):
            for y in range(-6, 6):
                if (x + 0.5) ** 2 + (y + 0.5) ** 2 <= r * r:
                    vox[(x, y, z)] = '#2f7d4a' if h3(x, y, z, 2) > 0.3 else ('#27693d' if h3(x, y, z, 3) > 0.5 else '#3c9156')
    build('pine', vox)
    shoot('pine', cam)


def oak(name, greens):
    cam = env_scene(112 if PREVIEW else 160, 2.0)
    vox = {}
    for x in (-1, 0):
        for y in (-1, 0):
            for z in range(0, 5):
                vox[(x, y, z)] = '#77502f'
    for x, y, z in ellipsoid(0, 0, 8.5, 5.8, 5.8, 4.8):
        if h3(x, y, z, 4) < 0.06:
            continue
        vox[(x, y, z)] = greens[int(h3(x, y, z, 5) * len(greens))]
    build(name, vox)
    shoot(name, cam)


def rock():
    cam = env_scene(96 if PREVIEW else 128, 1.6)
    vox = {}
    for x, y, z in ellipsoid(0, 0, 1.2, 5.2, 4.2, 3.4):
        if z < 0 or h3(x, y, z, 6) < 0.08:
            continue
        top = z >= 3
        vox[(x, y, z)] = '#7c8f4c' if top and h3(x, y, z, 9) > 0.6 else ('#8f9399' if h3(x, y, z, 8) > 0.35 else '#a6abb2')
    for x, y, z in ellipsoid(4, -2, 0.8, 2.6, 2.4, 2.2):
        if z >= 0:
            vox[(x, y, z)] = '#999da4'
    build('rock', vox)
    shoot('rock', cam)


def house(name, roof, roof_dark, wall, w=10, d=8, h=5):
    cam = env_scene(128 if PREVIEW else 192, 2.6)
    vox = {}
    x0, y0 = -w // 2, -d // 2
    for x in range(x0, x0 + w):
        for y in range(y0, y0 + d):
            for z in range(0, h):
                edge = x in (x0, x0 + w - 1) or y in (y0, y0 + d - 1)
                if not edge:
                    continue
                c = wall
                # Windows on the long walls, a door in the middle of the front (south) wall.
                if y == y0 and z in (1, 2) and x == 0:
                    c = '#6b4528'
                elif y in (y0, y0 + d - 1) and z == 2 and (x - x0) % 3 == 1 and x != 0:
                    c = '#79b6e3'
                elif x in (x0, x0 + w - 1) and z == 2 and (y - y0) % 3 == 1:
                    c = '#79b6e3'
                vox[(x, y, z)] = c
    # A gabled roof along x, overhanging a little.
    half = d // 2 + 1
    for k in range(half + 1):
        z = h + k
        for x in range(x0 - 1, x0 + w + 1):
            for y in (y0 - 1 + k, y0 + d - k):
                vox[(x, y, z)] = roof_dark if k == half or (x - x0) % 4 == 0 else roof
        # Gable ends filled with wall.
        for y in range(y0 + k, y0 + d - k):
            for x in (x0, x0 + w - 1):
                if z < h + half:
                    vox[(x, y, z)] = wall
    for z in range(h + 1, h + half + 3):
        for x in (x0 + w - 3, x0 + w - 2):
            vox[(x, y0 + d - 3, z)] = '#7a7d84'
    build(name, vox)
    shoot(name, cam)


def mill():
    cam = env_scene(144 if PREVIEW else 208, 3.0)
    vox = {}
    for z in range(0, 15):
        r = 3.6 - z * 0.12
        for x in range(-5, 5):
            for y in range(-5, 5):
                if (x + 0.5) ** 2 + (y + 0.5) ** 2 <= r * r:
                    vox[(x, y, z)] = '#f0ebe1' if not (z == 3 and x == 0 and y < -1) else '#6b4528'
    for z in range(15, 19):
        r = 3.4 * (1 - (z - 15) / 4)
        for x in range(-5, 5):
            for y in range(-5, 5):
                if (x + 0.5) ** 2 + (y + 0.5) ** 2 <= r * r + 0.3:
                    vox[(x, y, z)] = '#9a5a33'
    build('mill', vox)
    # The sails: four arms on the south face, turned a little so it reads as a windmill, not a cross.
    hub = empty('hub', loc=(0, -3.9 * V, 12.5 * V))
    hub.rotation_euler = (math.radians(90), math.radians(22), 0)
    sails = {}
    for arm in range(4):
        a = arm * math.pi / 2
        for i in range(1, 12):
            for j in range(-1, 3 if i > 3 else 1):
                x = round(math.cos(a) * i - math.sin(a) * j)
                y = round(math.sin(a) * i + math.cos(a) * j)
                sails[(x, y, 0)] = '#b98d5e' if j <= 0 else ('#f7f3ea' if (i + j) % 2 else '#ece4d4')
    sails[(0, 0, 0)] = '#5b3b22'
    build('sails', sails, parent=hub)
    shoot('mill', cam)


JOBS = {
    'meowl': meowl,
    'pine': pine,
    'oak': lambda: oak('oak', ['#4f9e45', '#5fb04f', '#3f8a3a', '#6cbc59']),
    'oak-autumn': lambda: oak('oak-autumn', ['#d98a2b', '#e6a83c', '#c4651f', '#e9be4a']),
    'rock': rock,
    'house-red': lambda: house('house-red', '#c8483a', '#9e3328', '#efe3c8'),
    'house-blue': lambda: house('house-blue', '#3f6fb0', '#2f5590', '#ead9ba', w=12, d=9, h=5),
    'mill': mill,
}

for name, job in JOBS.items():
    if ONLY and name not in ONLY:
        continue
    job()

path = os.path.join(OUT, 'layout.json')
old = json.load(open(path)) if os.path.exists(path) else {}
old.update(LAYOUT)
json.dump(old, open(path, 'w'), indent=1)
print('done', flush=True)
