import { cx } from '../lib/format';

/**
 * A floating price's last values («Биткоин», iteration 35) as a small line chart: green when the last move went up,
 * red when down. Plain SVG stretched to its box (the strokes keep their width), fading in once.
 */
export function PriceChart({ prices, className }: { prices: number[]; className?: string }) {
  if (prices.length < 2) return null;
  // Log scale: 99 and 10 000 on one chart would otherwise flatten everything below the top.
  const ys = prices.map((p) => Math.log10(Math.max(1, p)));
  const lo = Math.min(...ys);
  const hi = Math.max(...ys);
  const span = hi - lo || 1;
  const W = 100;
  const H = 32;
  const pts = ys.map((y, i) => [(i / (ys.length - 1)) * W, H - 3 - ((y - lo) / span) * (H - 6)] as const);
  const line = pts.map(([x, y]) => `${x.toFixed(1)},${y.toFixed(1)}`).join(' ');
  const up = prices.at(-1)! >= prices.at(-2)!;
  const [lx, ly] = pts.at(-1)!;
  return (
    <svg className={cx('price-chart', up ? 'is-up' : 'is-down', className)} viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none" aria-hidden="true">
      <polyline className="price-chart__area" points={`0,${H} ${line} ${W},${H}`} />
      <polyline className="price-chart__line" points={line} />
      {/* A zero-length round-capped line: stays a round dot when the chart is stretched (a circle turned oval). */}
      <line className="price-chart__dot" x1={lx} y1={ly} x2={lx} y2={ly} />
    </svg>
  );
}

/** ▲ / ▼ after a floating price: where the last move went. */
export function PriceTrend({ prices }: { prices: number[] }) {
  if (prices.length < 2) return null;
  const up = prices.at(-1)! >= prices.at(-2)!;
  return (
    <span className={cx('price-trend', up ? 'is-up' : 'is-down')} aria-label={up ? 'цена выросла' : 'цена упала'}>
      {up ? '▲' : '▼'}
    </span>
  );
}
