import { useEffect, useRef, useState, type CSSProperties } from 'react';
import { BrainrotCard } from '../components/BrainrotCard';
import { Coin } from '../components/Coin';
import { ConsolationSheet } from '../components/ConsolationSheet';
import { Confetti, Crack } from '../components/Fx';
import { Icon } from '../components/Icon';
import { EventBanner, useEvents } from '../components/Events';
import { InventoryGrid, type InventoryItem } from '../components/InventoryGrid';
import { Tabs } from '../components/Tabs';
import { UpgradeRing, type UpgradeRingHandle } from '../components/UpgradeRing';
import { errorMessage } from '../api/client';
import { act, setMe, useCatalog, useMe, type Me } from '../api/queries';
import type { Brainrot } from '../../shared/types';
import { MAX_UPGRADE_CHANCE, MIN_UPGRADE_STAKE, pointerAngle, targetForChance, targetForMultiplier, upgradeChance, upgradeTargets } from '../../shared/upgrader';
import { useNow } from '../lib/useNow';
import { cx, formatChance, formatCoins } from '../lib/format';
import { SOUND_EVENT, isMuted, setMuted, sfx } from '../lib/sound';
import { haptic } from '../lib/telegram';
import { TIER_LABEL, tierOf } from '../lib/tier';
import { toast } from '../store/toast';
import { ShareWinButton } from '../components/ShareWin';
import { MIXED_DEMO, mixesDemo } from '../lib/demo';

type Tab = 'mine' | 'targets';

/** Quick picks by chance (the owner's 75 / 50 / 30 / 10 %): the target whose real chance is closest. */
const QUICK = [0.75, 0.5, 0.3, 0.1];
/** Same limit as the server. */
const MAX_ITEMS = 5;

/**
 * The owner's spin: done within 4 s of the tap (iteration 39: 3.5 s of turning + the server's answer), 5 turns, slowing
 * down all the way; «быстро» stays for those in a hurry.
 */
const SPIN = {
  normal: { ms: 3500, turns: 5 },
  fast: { ms: 1600, turns: 3 },
};

interface Result {
  win: boolean;
  target: Brainrot;
  chance: number;
  /** What was on the table (shown burnt in the slot after a loss). */
  stake: Stake;
  key: number;
}

/** Stake pictures flying from the «Ставишь» slot into the middle of the ring. */
interface Fly {
  key: number;
  images: string[];
  from: { x: number; y: number };
  to: { x: number; y: number };
}

interface UpgradeResponse {
  roll: number;
  win: boolean;
  chance: number;
  stakeValue: number;
  targetId: string;
  itemId: number | null;
  /** Set when a big loss earned a consolation spin. */
  consolationId: number | null;
}

/** What is on the table: up to 5 brainrots (no coins). */
interface Stake {
  items: Brainrot[];
  value: number;
}

const cents = (x: number) => Math.floor(x * 100 + 1e-6) / 100;

export function Upgrader() {
  const me = useMe();
  const catalog = useCatalog();
  const upgradeEvent = useEvents(useNow(5000)).some((e) => e.id === 'upgrade');
  const [picked, setPicked] = useState<number[]>([]);
  const [targetId, setTargetId] = useState<string | null>(null);
  const [fast, setFast] = useState(false);
  const [tab, setTab] = useState<Tab>('mine');
  const [locked, setLocked] = useState<Stake | null>(null);
  const [pending, setPending] = useState(false);
  const [result, setResult] = useState<Result | null>(null);
  const [consolation, setConsolation] = useState<number | null>(null);
  const [spinChance, setSpinChance] = useState<number | null>(null);
  const [fly, setFly] = useState<Fly | null>(null);
  const [muted, setMutedState] = useState(isMuted);
  const ring = useRef<UpgradeRingHandle>(null);
  const stage = useRef<HTMLDivElement>(null);
  const unapplied = useRef<Me | null>(null);

  useEffect(
    () => () => {
      if (unapplied.current) setMe(unapplied.current);
    },
    [],
  );

  // The HUD's sound button and the settings sheet share one switch.
  useEffect(() => {
    const sync = () => setMutedState(isMuted());
    window.addEventListener(SOUND_EVENT, sync);
    return () => window.removeEventListener(SOUND_EVENT, sync);
  }, []);

  function toggleSound() {
    setMuted(!muted);
    if (muted) sfx.tap();
  }

  const spinning = locked !== null;
  const busy = spinning || pending;
  const frozen = !!me.user.frozen;
  const items = me.inventory;
  // Items that left the inventory (sold, put on a withdrawal…) drop out of the stake by themselves.
  const pickedItems = picked.flatMap((id) => {
    const item = items.find((i) => i.id === id && !i.withdrawalId);
    const b = item ? catalog.byId.get(item.brainrotId) : undefined;
    return item && b ? [{ item, b }] : [];
  });
  const itemsValue = cents(pickedItems.reduce((s, p) => s + p.b.price, 0));
  const target = targetId ? catalog.byId.get(targetId) ?? null : null;
  const stake: Stake | null = locked ?? (pickedItems.length ? { items: pickedItems.map((p) => p.b), value: itemsValue } : null);
  const stakeValue = stake?.value ?? 0;
  const tooEasy = !!stake && !!target && target.price > stakeValue && upgradeChance(stakeValue, target.price) > MAX_UPGRADE_CHANCE;
  const liveChance = stake && target && target.price > stakeValue && !locked && !tooEasy ? upgradeChance(stakeValue, target.price) : null;
  // While the needle turns the arc keeps the chance that is being played.
  const ringChance = liveChance ?? spinChance ?? (result && !stake ? result.chance : null);
  const multiplier = stake && target && target.price > stakeValue ? target.price / stakeValue : null;
  const targets = stake ? upgradeTargets(stakeValue, catalog.active) : catalog.active.slice(1);

  /** After the stake changes: keep a target that still makes sense (at most MAX_UPGRADE_CHANCE), else take the x2 one. */
  function retarget(value: number) {
    if (value > 0 && (!target || upgradeChance(value, target.price) > MAX_UPGRADE_CHANCE)) setTargetId(targetForMultiplier(value, 2, catalog.active)?.id ?? null);
  }

  function togglePick(item: InventoryItem) {
    if (busy) return;
    const price = catalog.byId.get(item.brainrotId)?.price ?? 0;
    setResult(null);
    if (picked.includes(item.id)) {
      sfx.tap();
      setPicked((list) => list.filter((id) => id !== item.id));
      return;
    }
    if (mixesDemo(pickedItems.map((p) => p.item), item)) {
      sfx.error();
      toast(MIXED_DEMO);
      return;
    }
    if (pickedItems.length >= MAX_ITEMS) {
      sfx.error();
      toast(`В апгрейд — до ${MAX_ITEMS} брейнротов. Убери один, чтобы добавить другой`);
      return;
    }
    sfx.tap();
    setPicked((list) => [...list.filter((id) => pickedItems.some((p) => p.item.id === id)), item.id]);
    retarget(itemsValue + price);
  }

  function pickTarget(b: Brainrot) {
    if (busy) return;
    sfx.tap();
    setTargetId(b.id);
    setResult(null);
  }

  function quickPick(chance: number) {
    if (busy) return;
    if (!stake) {
      toast('Сначала выбери брейнротов в ставку');
      setTab('mine');
      return;
    }
    const found = targetForChance(stakeValue, chance, catalog.active);
    if (!found) {
      toast('Дороже брейнрота пока нет');
      return;
    }
    sfx.tap();
    setTargetId(found.id);
    setResult(null);
  }

  function clearStake() {
    sfx.tap();
    setPicked([]);
  }

  async function start() {
    if (busy || !stake || !target || liveChance === null) return;
    const snapshot = stake;
    setPending(true);
    let response;
    try {
      response = await act<UpgradeResponse>('/api/upgrade', { itemIds: pickedItems.map((p) => p.item.id), targetId: target.id });
    } catch (e) {
      sfx.error();
      toast(errorMessage(e), 'error');
      setPending(false);
      return;
    }
    setPending(false);
    const { roll, win, chance } = response.result;
    unapplied.current = response.me;
    const cfg = fast ? SPIN.fast : SPIN.normal;
    haptic('tap');
    sfx.whoosh();
    launch(snapshot);
    setSpinChance(chance);
    setLocked(snapshot);
    setPicked([]);
    setResult(null);
    await ring.current?.spin(pointerAngle(roll, chance), cfg.ms, cfg.turns);
    unapplied.current = null;
    setMe(response.me);
    setLocked(null);
    setSpinChance(null);
    setResult({ win, target, chance, stake: snapshot, key: Date.now() });
    if (win) {
      if (tierOf(target.price) === 'secret' || tierOf(target.price) === 'legendary') sfx.bigWin();
      else sfx.win();
    } else {
      sfx.lose();
      sfx.crack();
    }
    haptic(win ? 'success' : 'error');
    // Let the loss sink in for a moment, then offer the consolation spin.
    const consolationId = response.result.consolationId;
    if (!win && consolationId) setTimeout(() => setConsolation(consolationId), 900);
  }

  /** Sends the stake pictures flying into the ring. */
  function launch(snapshot: Stake) {
    const box = stage.current;
    const slot = box?.querySelector('.up-pair .slot');
    const core = box?.querySelector('.uring');
    if (!box || !slot || !core) return;
    // The button sits below the ring on a phone: bring the ring back into view for the spin.
    const top = box.getBoundingClientRect().top;
    if (top < 56) window.scrollBy({ top: top - 72, behavior: 'smooth' });
    const b = box.getBoundingClientRect();
    const s = slot.getBoundingClientRect();
    const c = core.getBoundingClientRect();
    setFly({
      key: Date.now(),
      images: snapshot.items.slice(0, 5).map((i) => i.image),
      from: { x: s.left + s.width / 2 - b.left, y: s.top + s.height / 2 - b.top },
      to: { x: c.left + c.width / 2 - b.left, y: c.top + c.height / 2 - b.top },
    });
    setTimeout(() => sfx.absorb(), 380);
    setTimeout(() => setFly(null), 1100);
  }

  const won = result?.win ? result : null;
  const big = !!won && (tierOf(won.target.price) === 'secret' || tierOf(won.target.price) === 'legendary' || won.target.price / won.stake.value >= 5);
  const hint = frozen
    ? 'Аккаунт заморожен — играть нельзя'
    : !stake
      ? 'Выбери до 5 брейнротов в ставку'
      : !locked && stakeValue < MIN_UPGRADE_STAKE
        ? `Апгрейд — от ${MIN_UPGRADE_STAKE} B: добавь брейнротов в ставку`
      : !target
        ? 'Выбери, во что прокачать'
        : target.price <= stakeValue
          ? 'Цель должна быть дороже ставки'
          : tooEasy
            ? `Шанс больше ${MAX_UPGRADE_CHANCE * 100}% — выбери цель дороже`
            : null;

  return (
    <section className={cx('game upgrader', upgradeEvent && 'is-event')} aria-labelledby="upgrader-title">
      <EventBanner id="upgrade" />
      <div className="up-head">
        <h1 id="upgrader-title" className="page-title">
          Апгрейдер
        </h1>
      </div>

      <div className={cx('up-stage', result && (result.win ? 'is-win' : 'is-lose'), spinning && 'is-spinning')} ref={stage}>
        <span className="up-stage__light" aria-hidden="true" />
        <div className="up-hud" role="group" aria-label="Апгрейд: настройки и ставка">
          <div className="up-hud__tools">
            <button type="button" className={cx('up-hud__btn', !muted && 'is-on')} onClick={toggleSound} aria-pressed={!muted} aria-label={muted ? 'Включить звук' : 'Выключить звук'}>
              <Icon name={muted ? 'volumeOff' : 'volume'} size={18} />
            </button>
            <button
              type="button"
              className={cx('up-hud__btn', fast && 'is-on')}
              onClick={() => {
                sfx.tap();
                setFast(!fast);
              }}
              disabled={busy}
              aria-pressed={fast}
              aria-label={fast ? 'Быстрый режим включён' : 'Быстрый режим выключен'}
            >
              <Icon name="bolt" size={18} />
            </button>
          </div>
          <div className={cx('up-hud__info', multiplier !== null && stake && target && 'is-set')}>
            {stake && target && multiplier !== null ? (
              <>
                <span className="up-hud__x">x{multiplier.toFixed(multiplier < 10 ? 2 : 1)}</span>
                <span className="up-hud__flow">
                  <span>
                    <Coin size={12} /> {formatCoins(stakeValue)} <Icon name="arrowRight" size={12} /> {formatCoins(target.price)}
                  </span>
                  <span className="up-hud__bar" aria-hidden="true">
                    <i style={{ transform: `scaleX(${Math.min(1, (liveChance ?? spinChance ?? 0) / MAX_UPGRADE_CHANCE)})` }} />
                  </span>
                </span>
              </>
            ) : (
              <span className="up-hud__hint">{!stake ? 'Поставь до 5 брейнротов' : 'Выбери цель дороже ставки'}</span>
            )}
          </div>
        </div>
        <UpgradeRing ref={ring} chance={ringChance} multiplier={multiplier} result={result ? (result.win ? 'win' : 'lose') : null} />
        {won && (
          <span key={won.key} className="up-float" aria-hidden="true">
            +{formatCoins(cents(won.target.price - won.stake.value))} <Coin size={18} />
          </span>
        )}
        {fly && (
          <span
            key={fly.key}
            className="up-fly"
            aria-hidden="true"
            style={{ '--fx': `${fly.from.x}px`, '--fy': `${fly.from.y}px`, '--tx': `${fly.to.x}px`, '--ty': `${fly.to.y}px` } as CSSProperties}
          >
            {fly.images.map((src, i) => (
              <img key={i} src={src} alt="" style={{ '--i': i } as CSSProperties} />
            ))}
          </span>
        )}
        <div className="up-pair">
          <StakeSlot
            stake={stake ?? (result && !result.win ? result.stake : null)}
            burnt={!stake && !!result && !result.win}
            hidden={!!fly}
            active={tab === 'mine'}
            onClick={() => setTab('mine')}
            onClear={!busy && stake ? clearStake : undefined}
          />
          <span className="up-pair__arrow" aria-hidden="true">
            <i />
            <i />
            <i />
          </span>
          <Slot
            label="Получишь"
            brainrot={result?.win && !stake ? result.target : target}
            won={!!won && !stake}
            empty="Цель"
            emptyIcon="plus"
            active={tab === 'targets'}
            onClick={() => setTab('targets')}
            onClear={!busy && target ? () => setTargetId(null) : undefined}
          />
        </div>
        {stake && target && multiplier !== null && !result && (
          <dl className="up-summary">
            <div>
              <dt>Шанс</dt>
              <dd className="is-green">{formatChance(liveChance ?? spinChance ?? 0)}</dd>
            </div>
            <div>
              <dt>Множитель</dt>
              <dd className="is-gold">x{multiplier.toFixed(multiplier < 10 ? 2 : 1)}</dd>
            </div>
            <div>
              <dt>Профит</dt>
              <dd>
                +{formatCoins(cents(target.price - stakeValue))} <Coin size={12} />
              </dd>
            </div>
          </dl>
        )}
        <p className={cx('result-line', result && (result.win ? 'is-win' : 'is-lose'))} role="status">
          {result
            ? result.win
              ? `Выигрыш! ${result.target.name} в инвентаре`
              : 'Проигрыш — ставка сгорела'
            : spinning
              ? `Крутим… шанс ${formatChance(spinChance ?? 0)}`
              : hint ?? `Шанс ${formatChance(liveChance ?? 0)} · ${fast ? 'быстро' : 'обычно'}, ${((fast ? SPIN.fast : SPIN.normal).ms / 1000).toLocaleString('ru-RU')} с`}
        </p>
        {result?.win && <ShareWinButton className="up-share" />}
      </div>

      <div className="up-quick" role="group" aria-label="Шанс апгрейда">
        {QUICK.map((c) => {
          const on = liveChance !== null && Math.abs(Math.log(liveChance / c)) < 0.15;
          return (
            <button key={c} type="button" className={cx('chip', on && 'is-active')} onClick={() => quickPick(c)} disabled={busy}>
              {Math.round(c * 100)}%
            </button>
          );
        })}
      </div>

      <button type="button" className="btn btn--primary btn--lg btn--block up-go" disabled={!!hint || busy} onClick={start}>
        {spinning ? 'Крутим…' : pending ? 'Секунду…' : (
          <>
            <Icon name="gauge" size={20} /> Апгрейд {liveChance !== null && <span className="up-go__chance">{formatChance(liveChance)}</span>}
          </>
        )}
      </button>

      <Tabs
        label="Предметы"
        value={tab}
        onChange={setTab}
        options={[
          { value: 'mine', label: `Мои предметы${pickedItems.length ? ` · ${pickedItems.length}/${MAX_ITEMS}` : ''}` },
          { value: 'targets', label: 'Цели' },
        ]}
      />

      {tab === 'mine' && (
        <>
          <p className="up-pick-hint">
            Нажми на брейнротов — до {MAX_ITEMS} в одну ставку. Цифра на карточке — порядок.
            {pickedItems.length > 0 && (
              <button type="button" className="link-btn" onClick={clearStake} disabled={busy}>
                Сбросить
              </button>
            )}
          </p>
          <InventoryGrid items={items} selected={pickedItems.map((p) => p.item.id)} disabled={busy} onPick={togglePick} sortable />
        </>
      )}
      {tab === 'targets' &&
        (targets.length ? (
          <div className="grid">
            {targets.map((b) => (
              <BrainrotCard
                key={b.id}
                brainrot={b}
                selected={targetId === b.id}
                disabled={busy}
                meta={stake ? formatChance(upgradeChance(stakeValue, b.price)) : undefined}
                onClick={() => pickTarget(b)}
              />
            ))}
          </div>
        ) : (
          <p className="hint">Дороже твоей ставки брейнротов нет — апгрейдить некуда.</p>
        ))}
      <ConsolationSheet id={consolation} onClose={() => setConsolation(null)} />
      {big && won && <Confetti key={won.key} count={56} />}
    </section>
  );
}

/** «Ставишь»: one brainrot as a card; several as a fan with their total. */
interface StakeSlotProps {
  stake: Stake | null;
  /** The stake that was just lost: greyed out under cracked glass. */
  burnt: boolean;
  /** Its pictures are flying into the ring right now. */
  hidden: boolean;
  active: boolean;
  onClick: () => void;
  onClear?: () => void;
}

function StakeSlot({ stake, burnt, hidden, active, onClick, onClear }: StakeSlotProps) {
  const top = stake?.items.reduce<Brainrot | null>((best, b) => (!best || b.price > best.price ? b : best), null) ?? null;
  const many = (stake?.items.length ?? 0) > 1;
  return (
    <div className="slot-wrap">
      <span className="slot-wrap__label">{burnt ? 'Сгорело' : 'Ставишь'}</span>
      <button
        type="button"
        className={cx('slot', stake && 'slot--filled', top && `tier-${tierOf(top.price)}`, active && 'is-active', burnt && 'is-burnt', hidden && 'is-launched')}
        onClick={onClick}
      >
        {burnt && <Crack className="slot__crack" seed={Math.round((stake?.value ?? 1) * 7)} />}
        {stake && top ? (
          <>
            {!many && <span className="slot__tier">{TIER_LABEL[tierOf(top.price)]}</span>}
            {many && <span className="slot__tier">{stake.items.length} предм.</span>}
            {many ? (
              <span className="slot__fan" aria-hidden="true">
                {stake.items.slice(0, 5).map((b, i) => (
                  <img key={i} src={b.image} alt="" style={{ '--i': i, '--n': Math.min(stake.items.length, 5) } as CSSProperties} />
                ))}
              </span>
            ) : (
              <img src={top.image} alt="" />
            )}
            <span className="slot__name">{many ? `${stake.items.length} ${stake.items.length < 5 ? 'брейнрота' : 'брейнротов'}` : top.name}</span>
            <span className="slot__price">
              <Coin size={14} /> {formatCoins(stake.value)}
            </span>
          </>
        ) : (
          <>
            <Icon name="arrowDown" size={28} />
            <span className="slot__empty">До 5 предметов</span>
          </>
        )}
      </button>
      {onClear && (
        <button type="button" className="slot__clear" aria-label="Убрать ставку" onClick={onClear}>
          <Icon name="close" size={16} />
        </button>
      )}
    </div>
  );
}

interface SlotProps {
  label: string;
  brainrot: Brainrot | null;
  /** Just won: the card pops and shines. */
  won?: boolean;
  empty: string;
  emptyIcon: 'arrowDown' | 'plus';
  active: boolean;
  onClick: () => void;
  onClear?: () => void;
}

function Slot({ label, brainrot, won, empty, emptyIcon, active, onClick, onClear }: SlotProps) {
  return (
    <div className="slot-wrap">
      <span className="slot-wrap__label">{won ? 'Твоё!' : label}</span>
      <button type="button" className={cx('slot', brainrot && `slot--filled tier-${tierOf(brainrot.price)}`, active && 'is-active', won && 'is-won')} onClick={onClick}>
        {brainrot ? (
          <>
            <span className="slot__tier">{TIER_LABEL[tierOf(brainrot.price)]}</span>
            <img src={brainrot.image} alt="" />
            <span className="slot__name">{brainrot.name}</span>
            <span className="slot__price">
              <Coin size={14} /> {formatCoins(brainrot.price)}
            </span>
          </>
        ) : (
          <>
            <Icon name={emptyIcon} size={28} />
            <span className="slot__empty">{empty}</span>
          </>
        )}
      </button>
      {onClear && (
        <button type="button" className="slot__clear" aria-label={`Убрать: ${brainrot?.name ?? ''}`} onClick={onClear}>
          <Icon name="close" size={16} />
        </button>
      )}
    </div>
  );
}
