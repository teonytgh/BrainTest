// Cloudflare Workers entry: /api/* goes to the router, everything else to the built app (static assets),
// the cron trigger runs the minute tick, /api/live is the live-updates WebSocket (one LiveHub for every open app) and
// /api/room a multiplayer room (one GameRoom per «Небо Meowl» run).
import { DurableObject } from 'cloudflare:workers';
import pg from 'pg';
// @ts-expect-error pg ships no types for its crypto helpers.
import pgCrypto from 'pg/lib/crypto/utils';
import { runWithPool, type PoolLike } from '../server/db';
import { useEnv } from '../server/env';
import { verifyLiveTicket, withLiveScope, type LivePush, type LiveTopic } from '../server/live';
import { dropsByIds, type LiveDrop } from '../server/liveDrops';
import { handle } from '../server/router';
import { useRooms, verifyRoomTicket } from '../server/rooms/bridge';
import { SkyRoom } from '../server/rooms/sky';
import { SquidRoom } from '../server/rooms/squid';
import type { RoomLogic, RoomSocket } from '../server/rooms/types';
import { useImageStore } from '../server/storage';
import { runTick } from '../server/tick';

interface KV {
  getWithMetadata<M>(key: string, type: 'arrayBuffer'): Promise<{ value: ArrayBuffer | null; metadata: M | null }>;
  put(key: string, value: ArrayBuffer, options?: { metadata?: unknown }): Promise<void>;
}

interface Env {
  ASSETS: { fetch(req: Request): Promise<Response> };
  UPLOADS: KV;
  /** Hyperdrive in front of Supabase (optional: not bound in wrangler.jsonc while DATABASE_URL is set). */
  HYPERDRIVE?: { connectionString: string };
  /**
   * Secret: Supabase's transaction pooler (port 6543) straight, without Hyperdrive. Wins when set — Hyperdrive's
   * free plan stops answering after 100 000 queries a day (the launch evening ran into it). Plain TCP: Workers
   * can't verify Supabase's own CA, so this hop is not encrypted (SCRAM keeps the password off the wire).
   * To use Hyperdrive instead: bind HYPERDRIVE in wrangler.jsonc and delete this secret.
   */
  DATABASE_URL?: string;
  LIVE: DurableObjectNamespace<LiveHub>;
  ROOMS: DurableObjectNamespace<GameRoom>;
  [key: string]: unknown;
}

const room = (env: Env, name: string) => env.ROOMS.get(env.ROOMS.idFromName(name));

function setup(env: Env) {
  useEnv(env);
  useRooms({
    send: (name, msg) => room(env, name).send(name, msg),
    call: (name, op, arg) => room(env, name).call(name, op, arg),
  });
  useImageStore({
    async put(key, image) {
      await env.UPLOADS.put(key, new Uint8Array(image.bytes).buffer, { metadata: { type: image.type } });
    },
    async get(key) {
      const r = await env.UPLOADS.getWithMetadata<{ type?: string }>(key, 'arrayBuffer');
      if (!r.value) return null;
      return { bytes: new Uint8Array(r.value), type: r.metadata?.type ?? 'application/octet-stream' };
    },
  });
}

// Every new database connection signs in with SCRAM: PBKDF2 over the password, a few ms of CPU each time (the
// free plan has ~10 ms per request). Password, salt and iteration count don't change, so derive once per isolate.
type DeriveKey = (password: string, salt: Uint8Array, iterations: number) => Promise<ArrayBuffer>;
const pbkdf2 = pgCrypto.deriveKey as DeriveKey;
const derived = new Map<string, Promise<ArrayBuffer>>();
pgCrypto.deriveKey = ((password, salt, iterations) => {
  const key = `${iterations}:${Buffer.from(salt).toString('base64')}:${password}`;
  let k = derived.get(key);
  if (!k) {
    k = pbkdf2(password, salt, iterations);
    k.catch(() => derived.delete(key));
    derived.set(key, k);
  }
  return k;
}) satisfies DeriveKey;

/** One hub for every open app: sockets are tagged with their player, so it can ping one player or everyone. */
const hub = (env: Env) => env.LIVE.get(env.LIVE.idFromName('all'));

/**
 * One request or tick with its own database pool (Workers can't keep sockets between requests; Hyperdrive
 * keeps the real ones). Bot messages queued with afterResponse and the live pushes run after the answer.
 */
async function run<T>(env: Env, ctx: ExecutionContext, fn: () => Promise<T>, timing?: Timing): Promise<T> {
  const pool = new pg.Pool(
    env.DATABASE_URL
      ? { connectionString: env.DATABASE_URL, ssl: false, max: 3 }
      : { connectionString: env.HYPERDRIVE?.connectionString, max: 4 },
  );
  const db = <R>(f: () => Promise<R>) => runWithPool((timing ? timed(pool, timing) : pool) as unknown as PoolLike, f);
  const scoped = await withLiveScope(() => db(fn)).catch(async (e) => {
    await pool.end().catch(() => {});
    throw e;
  });
  ctx.waitUntil(
    (async () => {
      const publish = (pushes: LivePush[]) => (pushes.length ? hub(env).publish(pushes) : Promise.resolve());
      await Promise.all([publish(scoped.pending()), scoped.settle().then(publish)]);
      // New winning drops go to every open app's «LIVE» feed (read back now that the request has committed).
      const ids = scoped.takeDrops();
      if (ids.length) {
        const drops = await db(() => dropsByIds(ids)).catch(() => []);
        if (drops.length) await hub(env).publishDrops(drops);
      }
      await pool.end().catch(() => {});
    })(),
  );
  return scoped.result;
}

/** Where a request's time went, for the Server-Timing header: database round trips and new connections. */
interface Timing {
  queries: number;
  db: number;
  connect: number;
}

type Query = (text: string, params?: unknown[]) => Promise<unknown>;

function timed(pool: pg.Pool, t: Timing) {
  const query =
    (f: Query): Query =>
    async (text, params) => {
      const start = performance.now();
      try {
        return await f(text, params);
      } finally {
        t.queries++;
        t.db += performance.now() - start;
      }
    };
  return {
    query: query(pool.query.bind(pool) as Query),
    async connect() {
      const start = performance.now();
      const client = await pool.connect();
      t.connect += performance.now() - start;
      return { query: query(client.query.bind(client) as Query), release: () => client.release() };
    },
  };
}

const serverTiming = (t: Timing, total: number) =>
  `app;dur=${Math.round(total)}, db;dur=${Math.round(t.db)};desc="${t.queries} queries", connect;dur=${Math.round(t.connect)}`;

export default {
  async fetch(req: Request, env: Env, ctx: ExecutionContext): Promise<Response> {
    const url = new URL(req.url);
    if (url.pathname === '/api/live') {
      if (req.headers.get('Upgrade') !== 'websocket') return new Response('Expected a WebSocket', { status: 426 });
      setup(env);
      const userId = verifyLiveTicket(url.searchParams.get('t') ?? '');
      if (!userId) return new Response('Bad ticket', { status: 401 });
      const forward = new Request(req.url, req);
      forward.headers.set('x-live-user', String(userId));
      return hub(env).fetch(forward);
    }
    if (url.pathname === '/api/room') {
      if (req.headers.get('Upgrade') !== 'websocket') return new Response('Expected a WebSocket', { status: 426 });
      setup(env);
      const pass = verifyRoomTicket(url.searchParams.get('t') ?? '');
      if (!pass) return new Response('Bad ticket', { status: 401 });
      const forward = new Request(req.url, req);
      forward.headers.set('x-room-user', String(pass.userId));
      forward.headers.set('x-room-name', encodeURIComponent(pass.name));
      forward.headers.set('x-room', pass.room);
      if (pass.god) forward.headers.set('x-room-god', '1');
      return room(env, pass.room).fetch(forward);
    }
    if (!url.pathname.startsWith('/api/')) return env.ASSETS.fetch(req);
    setup(env);
    const timing: Timing = { queries: 0, db: 0, connect: 0 };
    const start = performance.now();
    const res = await run(env, ctx, () => handle(req), timing);
    const out = new Response(res.body, res);
    out.headers.set('Server-Timing', serverTiming(timing, performance.now() - start));
    return out;
  },

  async scheduled(_event: ScheduledController, env: Env, ctx: ExecutionContext): Promise<void> {
    setup(env);
    console.log('tick', JSON.stringify(await run(env, ctx, () => runTick())));
  },
} satisfies ExportedHandler<Env>;

/**
 * Every open app. Sockets hibernate between messages (no cost while idle) and carry their player's tag; the
 * client's keep-alive «ping» is answered without waking the object.
 */
const MAX_SOCKETS_PER_PLAYER = 4;

export class LiveHub extends DurableObject<Env> {
  constructor(ctx: DurableObjectState, env: Env) {
    super(ctx, env);
    ctx.setWebSocketAutoResponse(new WebSocketRequestResponsePair('ping', 'pong'));
  }

  async fetch(req: Request): Promise<Response> {
    const tag = `u:${req.headers.get('x-live-user') ?? '0'}`;
    // A few open apps per player (phone, desktop, a reconnect in flight); more are closed oldest first, so one
    // account can't fill the hub with sockets.
    const mine = this.ctx.getWebSockets(tag);
    for (const old of mine.slice(0, Math.max(0, mine.length - (MAX_SOCKETS_PER_PLAYER - 1)))) {
      try {
        old.close(4000, 'too many');
      } catch {
        // Already closing.
      }
    }
    const pair = new WebSocketPair();
    this.ctx.acceptWebSocket(pair[1], [tag]);
    return new Response(null, { status: 101, webSocket: pair[0] });
  }

  async publish(pushes: LivePush[]): Promise<void> {
    for (const p of pushes) {
      const msg = JSON.stringify({ type: 'refresh', topics: p.topics satisfies LiveTopic[] });
      for (const ws of this.ctx.getWebSockets(p.userId === null ? undefined : `u:${p.userId}`)) {
        try {
          ws.send(msg);
        } catch {
          // A socket that is already closing; the client reconnects by itself.
        }
      }
    }
  }

  /** The «LIVE» feed: the drops themselves, so no app has to ask the server for them. */
  async publishDrops(drops: LiveDrop[]): Promise<void> {
    const msg = JSON.stringify({ type: 'drops', drops });
    for (const ws of this.ctx.getWebSockets()) {
      try {
        ws.send(msg);
      } catch {
        // Closing socket.
      }
    }
  }

  async webSocketClose(ws: WebSocket, code: number): Promise<void> {
    ws.close(code === 1005 ? 1000 : code, 'bye');
  }
}

/**
 * One multiplayer room (iteration 35): a «Небо Meowl» run (`sky:<runId>`) or an «Игра Кальмара» game
 * (`squid:<gameId>`). The logic lives in server/rooms/*.ts; this only wires WebSockets and the room's timer to it. The
 * timer runs while somebody is connected (the object stays awake for the event, then empties and sleeps). The API
 * reaches it through `send` (broadcasts) and `call` (the room's state, results, `init`, `close`).
 */
export class GameRoom extends DurableObject<Env> {
  private logic: RoomLogic | null = null;
  private timer: ReturnType<typeof setInterval> | null = null;

  private ensure(name: string): RoomLogic {
    this.logic ??= name.startsWith('squid:') ? new SquidRoom() : new SkyRoom();
    return this.logic;
  }

  async fetch(req: Request): Promise<Response> {
    const logic = this.ensure(req.headers.get('x-room') ?? 'sky:0');
    const id = Number(req.headers.get('x-room-user'));
    const name = decodeURIComponent(req.headers.get('x-room-name') ?? '') || 'Игрок';
    const pair = new WebSocketPair();
    const server = pair[1];
    server.accept();
    const sock: RoomSocket = { send: (d) => server.send(d), close: (code, reason) => server.close(code, reason) };
    if (logic.join(id, name, sock, { god: req.headers.get('x-room-god') === '1' })) {
      server.addEventListener('message', (ev) => {
        if (typeof ev.data === 'string') logic.message(id, sock, ev.data);
      });
      const bye = () => {
        logic.leave(id, sock);
        this.idle();
      };
      server.addEventListener('close', bye);
      server.addEventListener('error', bye);
      this.timer ??= setInterval(() => logic.tick(), logic.tickMs);
    }
    return new Response(null, { status: 101, webSocket: pair[0] });
  }

  private idle() {
    if (this.logic && this.logic.size === 0 && this.timer) {
      clearInterval(this.timer);
      this.timer = null;
    }
  }

  async send(name: string, msg: unknown): Promise<void> {
    this.ensure(name).broadcast(msg);
  }

  async call(name: string, op: string, arg?: unknown): Promise<unknown> {
    const result = this.ensure(name).call(op, arg);
    this.idle();
    return result;
  }
}
