"""One-off: imports images from the brainroterX repo and writes shared/seed/catalog.json.

Usage: python3 scripts/build_seed.py /path/to/brainroterx
"""
import json
import math
import os
import sys

from PIL import Image

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = sys.argv[1]

# Existing catalog (images already in public/brainrots).
EXISTING = {
    'love-love-bear': ('Love Love Bear', 12), 'spooky-and-pumpky': ('Spooky and Pumpky', 15),
    'los-sekolahs': ('Los Sekolahs', 18), 'burguro-and-fryuro': ('Burguro and Fryuro', 22),
    'fishino-clownino': ('Fishino Clownino', 26), 'dug-dug-dug': ('Dug Dug Dug', 30),
    'john-pork': ('John Pork', 35), 'jelly-moby': ('Jelly Moby', 40), 'pizza-and-ranch': ('Pizza and Ranch', 45),
    'garama-and-madundung': ('Garama and Madundung', 50), 'la-casa-boo': ('La Casa Boo', 60),
    'cooki-and-milki': ('Cooki and Milki', 70), 'fragrama': ('Fragrama and Chocrama', 85),
    'capitano-moby': ('Capitano Moby', 100), 'bunny-and-eggy': ('Bunny and Eggy', 120),
    'foxini-lanternini': ('Foxini Lanternini', 140), 'popuru-and-fizzuru': ('Popuru and Fizzuru', 165),
    'cash-or-card': ('Cash or Card', 190), 'rubiko-and-kubiko': ('Rubiko and Kubiko', 220),
    'reinito-sleighito': ('Reinito Sleighito', 260), 'fortunu-and-cashuru': ('Fortunu and Cashuru', 300),
    'moby-bros': ('Moby Bros', 350), 'antonio': ('Antonio', 420), 'los-dragons': ('Los Dragons', 500),
    'venuspino': ('Venuspino', 600), 'orchidox': ('Orchidox', 720), 'fragola-la-la-la': ('Fragola La La La', 850),
    'digi-narwhal': ('Digi Narwhal', 1000), 'kalika-bros': ('Kalika Bros', 1200), 'los-hackers': ('Los Hackers', 1450),
    'hydra-bunny': ('Hydra Bunny', 1750), 'kraken': ('Kraken', 2100), 'grabatron': ('Grabatron', 2500),
    'celestial-pegasus': ('Celestial Pegasus', 3000), 'cerberus': ('Cerberus', 3600),
    'dragon-aquanini': ('Dragon Aquanini', 4300), 'dragon-gingerini': ('Dragon Gingerini', 5200),
    'los-admins': ('Los Admins', 6200), 'la-secret-combinasion': ('La Secret Combinasion', 7500),
    'los-secret-combinasionas': ('Los Secret Combinasionas', 9000),
    'la-supreme-combinasion': ('La Supreme Combinasion', 11000), 'skibidi-toilet': ('Skibidi Toilet', 14000),
    'hydra-dragon-cannelloni': ('Hydra Dragon Cannelloni', 18000), 'dragon-cannelloni': ('Dragon Cannelloni', 24000),
    'meowl': ('Meowl', 35000), 'strawberry-elephant': ('Strawberry Elephant', 50000),
}

# New items from the repo: file -> (id, name, price).
NEW = {
    'Duggy_Bros.webp': ('duggy-bros', 'Duggy Bros', 75),
    'Festive_67.webp': ('festive-67', 'Festive 67', 230),
    'Gym_Bros.webp': ('gym-bros', 'Gym Bros', 160),
    'Money_Money_Bros.webp': ('money-money-bros', 'Money Money Bros', 900),
    'Tirilikalika_Tirilikalako.webp': ('tirilikalika-tirilikalako', 'Tirilikalika Tirilikalako', 28),
    'arcodragon.png': ('arco-dragon', 'Arco Dragon', 4800),
    'bacuruandegguru.png': ('bacuru-and-egguru', 'Bacuru and Egguru', 380),
    'bupinbani.png': ('bupin-bani', 'Bupin Bani', 55),
    'chillinchili.png': ('chillin-chili', 'Chillin Chili', 130),
    'cloveratclapat.png': ('cloverat-clapat', 'Cloverat Clapat', 310),
    'cupid-wings.png': ('cupid-wings', 'Cupid Wings', 650),
    'elefanto-frigo.png': ('elefanto-frigo', 'Elefanto Frigo', 2700),
    'eviledon.png': ('eviledon', 'Eviledon', 1600),
    'gingergerat.png': ('ginger-gerat', 'Ginger Gerat', 95),
    'globastepa.png': ('globa-stepa', 'Globa Stepa', 33),
    'goldgoldgold.png': ('gold-gold-gold', 'Gold Gold Gold', 3300),
    'griffin.png': ('griffin', 'Griffin', 2300),
    'guest666.png': ('guest-666', 'Guest 666', 6666),
    'headless-horseman.png': ('headless-horseman', 'Headless Horseman', 40000),
    'jollyjollysahur.png': ('jolly-jolly-sahur', 'Jolly Jolly Sahur', 270),
    'junk-pork.png': ('junk-pork', 'Junk Pork', 38),
    'ketchuru.png': ('ketchuru-and-musturu', 'Ketchuru and Musturu', 1300),
    'ketupatbros.png': ('ketupat-bros', 'Ketupat Bros', 2000),
    'ketupatkepat.png': ('ketupat-kepat', 'Ketupat Kepat', 8200),
    'lafoodcombinasion.png': ('la-food-combinasion', 'La Food Combinasion', 5600),
    'lagrande.webp': ('la-grande-combinasion', 'La Grande Combinasion', 16000),
    'lajollygrande.png': ('la-jolly-grande', 'La Jolly Grande', 10000),
    'lavadorito.png': ('lavadorito-spinito', 'Lavadorito Spinito', 1100),
    'losamigos.png': ('los-amigos', 'Los Amigos', 680),
    'loscombinasionas.png': ('los-combinasionas', 'Los Combinasionas', 20000),
    'losprimos.png': ('los-primos', 'Los Primos', 3900),
    'losspaghettis.png': ('los-spaghettis', 'Los Spaghettis', 780),
    'lostacoritas.png': ('los-tacoritas', 'Los Tacoritas', 460),
    'lostangcitos.png': ('los-tangcitos', 'Los Tangcitos', 540),
    'lostictacs.png': ('los-tictacs', 'Los Tictacs', 950),
    'moneymoneypuggy.png': ('money-money-puggy', 'Money Money Puggy', 1900),
    'moneymoneyreindeer.png': ('money-money-reindeer', 'Money Money Reindeer', 1500),
    'nuclearo.png': ('nuclearo-dinossauro', 'Nuclearo Dinossauro', 13000),
    'orcaledon.png': ('orcaledon', 'Orcaledon', 7000),
    'ricodinero2.png': ('rico-dinero', 'Rico Dinero', 400),
    'roseyandteddy.png': ('rosey-and-teddy', 'Rosey and Teddy', 280),
    'sammynifatini.png': ('sammyni-fatini', 'Sammyni Fatini', 330),
    'santas-sleigh.png': ('santas-sleigh', "Santa's Sleigh", 1400),
    'singore-carapace.png': ('signore-carapace', 'Signore Carapace', 12000),
    'stekinifatini.png': ('stekini-fatini', 'Stekini Fatini', 240),
    'swaggybros.png': ('swaggy-bros', 'Swaggy Bros', 620),
    'tangtang.png': ('tang-tang-keletang', 'Tang Tang Keletang', 2900),
    'tictacsahur.png': ('tictac-sahur', 'Tictac Sahur', 9800),
    'tralaledon.png': ('tralaledon', 'Tralaledon', 3400),
    'ventolieropavlino.png': ('ventoliero-pavlino', 'Ventoliero Pavlino', 5000),
    'w_or_l_brainrot.png': ('w-or-l', 'W or L', 180),
    'wave-rider.png': ('wave-rider', 'Wave Rider', 210),
    'witch-broom.png': ('witch-broom', 'Witch Broom', 145),
}

# case file -> (id, name, price, themed item ids that must be inside)
CASES = [
    ('free-case.png', 'free', 'Бесплатный', 0, []),
    ('noobini-case.png', 'noobini', 'Нубини', 19, ['tirilikalika-tirilikalako']),
    ('petrosyan.png', 'petrosyan', 'Петросян', 29, ['globa-stepa']),
    ('random-case.png', 'random', 'Рандом', 39, ['rosey-and-teddy']),
    ('lucky-case.png', 'lucky', 'Лаки', 49, ['cloverat-clapat']),
    ('toxic-case.png', 'toxic', 'Токсик', 69, ['cash-or-card']),
    ('moon-case.png', 'moon', 'Мун', 99, ['tictac-sahur']),
    ('lavaka-case.png', 'lavaka', 'Лавака', 149, ['los-tangcitos']),
    ('crazy-case.png', 'crazy', 'Крейзи', 199, ['festive-67']),
    ('pro-case.png', 'pro', 'Про', 259, ['spooky-and-pumpky']),
    ('mystery-case.png', 'mystery', 'Мистери', 349, ['w-or-l']),
    ('neon-case.png', 'neon', 'Неон', 499, ['ventoliero-pavlino']),
    ('meteor-case.png', 'meteor', 'Метеор', 699, ['dragon-aquanini']),
    ('phantom-case.png', 'phantom', 'Фантом', 999, ['los-amigos']),
    ('overdrive-case.png', 'overdrive', 'Овердрайв', 1490, ['foxini-lanternini']),
    ('chaos-case.png', 'chaos', 'Хаос', 2490, ['eviledon']),
    ('elite-case.png', 'elite', 'Элит', 3990, ['gold-gold-gold']),
    ('dragon-case.png', 'dragon', 'Драгон', 5990, ['dragon-cannelloni', 'dragon-gingerini', 'arco-dragon', 'hydra-dragon-cannelloni']),
    ('666-case.png', 'hell', '666', 6666, ['guest-666']),
    ('secret-case.png', 'secret', 'Секрет', 8990, ['la-secret-combinasion', 'los-secret-combinasionas']),
    ('og-case.png', 'og', 'OG', 14990, ['strawberry-elephant', 'meowl', 'headless-horseman']),
]
RTP = 0.88
FREE_EV = 16


def save_webp(src, dst, size):
    im = Image.open(src).convert('RGBA')
    bbox = im.getchannel('A').getbbox()
    if bbox:
        im = im.crop(bbox)
    im.thumbnail((size, size), Image.LANCZOS)
    im.save(dst, 'WEBP', quality=82, method=4)


def solve_weights(prices, target):
    """w_i = p_i^-a, bisect a so the expected value hits target."""
    def ev(a):
        w = [p ** -a for p in prices]
        return sum(p * x for p, x in zip(prices, w)) / sum(w)
    lo, hi = -12.0, 12.0
    for _ in range(200):
        mid = (lo + hi) / 2
        if ev(mid) > target:
            lo = mid
        else:
            hi = mid
    a = (lo + hi) / 2
    w = [p ** -a for p in prices]
    top = max(w)
    return [max(1, round(x / top * 100000)) for x in w]


def main():
    items = [{'id': k, 'name': v[0], 'price': v[1], 'image': f'/brainrots/{k}.webp'} for k, v in EXISTING.items()]
    for f, (bid, name, price) in NEW.items():
        save_webp(os.path.join(SRC, f), os.path.join(ROOT, 'public', 'brainrots', f'{bid}.webp'), 480)
        items.append({'id': bid, 'name': name, 'price': price, 'image': f'/brainrots/{bid}.webp'})
    items.sort(key=lambda b: b['price'])
    by_id = {b['id']: b for b in items}
    assert len(by_id) == len(items), 'duplicate ids'

    cases = []
    for order, (f, cid, name, price, themed) in enumerate(CASES):
        save_webp(os.path.join(SRC, 'cases', f), os.path.join(ROOT, 'public', 'cases', f'{cid}.webp'), 512)
        anchor = price or 40
        lo, hi = anchor * 0.25, anchor * 7
        pool = [b for b in items if lo <= b['price'] <= hi]
        # Spread ~13 items evenly across the band, then force the themed ones in.
        step = max(1, len(pool) // 13)
        chosen = {b['id'] for b in pool[::step][:13]}
        chosen.update(themed)
        chosen = sorted(chosen, key=lambda i: by_id[i]['price'])
        prices = [by_id[i]['price'] for i in chosen]
        target = FREE_EV if price == 0 else price * RTP
        assert min(prices) < target < max(prices), (cid, prices, target)
        weights = solve_weights(prices, target)
        cases.append({
            'id': cid, 'name': name, 'price': price, 'image': f'/cases/{cid}.webp', 'sort': order,
            'free': price == 0,
            'items': [{'brainrotId': i, 'weight': w} for i, w in zip(chosen, weights)],
        })
        ev = sum(p * w for p, w in zip(prices, weights)) / sum(weights)
        print(f'{cid:10} price={price:6} items={len(chosen):2} ev={ev:9.1f} ({ev / (price or FREE_EV):.2f})')

    out = os.path.join(ROOT, 'shared', 'seed', 'catalog.json')
    with open(out, 'w', encoding='utf-8') as fh:
        json.dump({'brainrots': items, 'cases': cases}, fh, ensure_ascii=False, indent=1)
    print(len(items), 'brainrots,', len(cases), 'cases ->', out)


main()
