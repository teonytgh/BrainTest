const coinFormat = new Intl.NumberFormat('ru-RU', { maximumFractionDigits: 2 });

export function formatCoins(value: number): string {
  return coinFormat.format(value);
}

/** Keeps the header chip narrow: 125 000 → 125K, 2 500 000 → 2.5M. */
export function formatCompactCoins(value: number): string {
  if (value >= 1_000_000) return `${Math.floor(value / 100_000) / 10}M`;
  if (value >= 100_000) return `${Math.floor(value / 1000)}K`;
  return formatCoins(value);
}

export function formatMultiplier(value: number): string {
  return `${value.toFixed(2)}x`;
}

export function formatChance(chance: number): string {
  const pct = chance * 100;
  const rounded = pct >= 10 ? Math.round(pct * 10) / 10 : Math.round(pct * 100) / 100;
  return `${rounded.toLocaleString('ru-RU')}%`;
}

export function formatCountdown(ms: number): string {
  const total = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  return [h, m, s].map((n) => String(n).padStart(2, '0')).join(':');
}

/** Russian plural form: `plural(5, 'кейс', 'кейса', 'кейсов')` → «кейсов». */
export function plural(n: number, one: string, few: string, many: string): string {
  const a = Math.abs(n) % 100;
  const b = a % 10;
  if (a > 10 && a < 20) return many;
  if (b === 1) return one;
  return b >= 2 && b <= 4 ? few : many;
}

export function cx(...parts: Array<string | false | null | undefined>): string {
  return parts.filter(Boolean).join(' ');
}

export function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
