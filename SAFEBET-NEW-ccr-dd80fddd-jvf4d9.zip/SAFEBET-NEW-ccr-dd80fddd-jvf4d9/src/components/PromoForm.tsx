import { useState, type FormEvent } from 'react';
import { errorMessage } from '../api/client';
import { act, setMe, useCatalog } from '../api/queries';
import { cx, formatCoins } from '../lib/format';
import { sfx } from '../lib/sound';
import { haptic } from '../lib/telegram';
import { toast } from '../store/toast';
import { openSheet } from '../store/ui';

type PromoResult =
  | { type: 'bonus'; percent: number }
  | { type: 'coins'; amount: number }
  | { type: 'brainrot'; amount: number; brainrotId: string }
  | { type: 'case'; amount: number; caseId: string }
  | { type: 'referral' };

/** One field for the 2-hour deposit bonus, gift codes (admins' and players') and friends' partner codes. */
export function PromoForm({ onDone, inline, cta = 'Активировать', placeholder = 'Введи код' }: { onDone?: () => void; inline?: boolean; cta?: string; placeholder?: string }) {
  const catalog = useCatalog();
  const [code, setCode] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(e: FormEvent) {
    e.preventDefault();
    if (!code.trim()) {
      setError('Введи промокод');
      return;
    }
    setBusy(true);
    try {
      const r = await act<PromoResult>('/api/promo', { code });
      setMe(r.me);
      sfx.win();
      haptic('success');
      setCode('');
      const res = r.result;
      if (res.type === 'bonus') {
        toast(`Бонус +${res.percent}% к следующему пополнению`, 'success');
        openSheet('deposit');
        return;
      }
      toast(
        res.type === 'referral'
          ? 'Ты теперь в команде друга — реферальный кейс (один на аккаунт) ждёт в «Бонусах», если ещё не доставался'
          : res.type === 'case'
            ? `Бесплатное открытие кейса «${catalog.caseById.get(res.caseId)?.name ?? res.caseId}» добавлено`
            : res.type === 'coins'
              ? `+${formatCoins(res.amount)} B на баланс`
              : `${catalog.byId.get(res.brainrotId)?.name ?? 'Брейнрот'}${res.amount > 1 ? ` ×${res.amount}` : ''} в инвентаре`,
        'success',
      );
      onDone?.();
    } catch (err) {
      sfx.error();
      haptic('error');
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <form className={cx('promo-form', inline && 'promo-form--inline')} onSubmit={submit} noValidate>
      <span className={cx('field__control', error && 'has-error')}>
        <input
          autoComplete="off"
          spellCheck={false}
          placeholder={placeholder}
          aria-label="Промокод"
          value={code}
          aria-invalid={!!error}
          aria-describedby={error ? 'promo-error' : undefined}
          onChange={(e) => {
            setCode(e.target.value.slice(0, 64));
            setError(null);
          }}
        />
      </span>
      <button type="submit" className="btn btn--primary" disabled={busy}>
        {cta}
      </button>
      {error && (
        <span id="promo-error" className="field__error promo-form__error">
          {error}
        </span>
      )}
    </form>
  );
}
