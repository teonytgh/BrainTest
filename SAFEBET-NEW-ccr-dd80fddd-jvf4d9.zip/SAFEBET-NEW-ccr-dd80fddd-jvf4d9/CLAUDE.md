# BrainrotCrash — notes for Claude

## Palette & layout
- Current skin: **Crash** — BrainrotCrash's own look (`<html data-palette="crash">` in `index.html`, `theme-color`
  #070b15, tokens in `src/styles/palette-crash.css`): graphite-blue night, the gold of the logo's crash arrow as the
  accent (buttons, switches, selected states, active nav), the B's red and the C's blue for red/blue. Gold is bright,
  so text on an accent fill uses `--accent-ink` (dark here, `--on-accent` white in the other palettes) — use it for any
  new accent-filled control. No Halloween decor with it (`halloweenSkin()` is false).
- Halloween season (iteration 37): `index.html` sets `<html data-season="halloween">` until 3 November 2026 00:00 MSK
  (2 November 21:00 UTC; the owner wrote «3 октября» — read as November, Halloween is 31 October) and the site goes back
  to the Crash look by itself. Replaced by the autumn season on 29 October (iteration 40); its CSS stays for later years. `src/styles/season-halloween.css`: a pumpkin-orange accent (the owner's reference
  #e98a2c) on a plum-tinted night, a witch hat on the logo; `Spiders` run too (`halloweenSeason()`). No background
  pictures (the owner: «везде без фона»). A later season = another date in index.html and its own token block.
- Autumn season (iteration 40, the owner: «весь проект в осеннем стиле, падали листья, интеракт с мявлом»): `index.html`
  sets `<html data-season="autumn">` from 29 October (it replaced the Halloween season) until 1 December 2026 00:00 MSK
  (30 November 21:00 UTC), `theme-color` #130804. `src/styles/season-autumn.css`: a walnut night, a maple-amber accent,
  leaf tokens `--leaf-*`, the gauge tokens `--gauge-disc|track`, a maple leaf on the logo (`--maple-mask`). Falling
  leaves over every page (`AutumnLeaves.tsx`, `src/styles/autumn.css`: 9 on a phone / 14 on a PC, transform/opacity,
  long cycles, never a tap; Настройки → «Листопад», device-local `brainrotcrash:leaves`) and «Осень с Meowl» on the home
  page under LIVE (`AutumnMeowl.tsx`: tap → he hops, meows, tosses leaves and types a new line; chatter only — no prizes,
  no odds). `autumnSeason()` in `src/lib/season.ts`. Spiders and the witch hat are off (they belong to the Halloween season).
- Smoothness (iteration 40, the owner: «полностью оптимизируй, чтоб не лагало»), measured with Chrome at 4× CPU
  throttling: the Halloween spiders (SVG `<g>` animations repaint on the main thread every frame) were 5–10× the idle
  work of every page; the upgrader's chevrons animated `filter`; the case walkers' 0.42 s step woke the style engine on
  every repeat; the home page re-rendered its whole case grid every second for its countdowns. Rules from it: animate
  only transform/opacity, never `filter`/`box-shadow`/SVG attributes in an infinite loop; keep infinite cycles long (put
  several beats in one keyframe cycle); tick countdowns in `Countdown` / flip at a moment with `useReached`
  (`src/lib/useNow.ts`), never a page-wide `useNow(1000)`; no `backdrop-filter` on touch screens (`src/styles/perf.css`,
  loaded last); `admin.css` loads with the admin chunk only.
- Other palettes stay in the repo: `data-palette="halloween"` (the friend's spooky skin: `palette-halloween.css` +
  `halloween-theme.css`, cobwebs, spiders, witch hat, dripping titles, `theme-color` #120b1b), no attribute = the
  soft red/blue/white «tricolor» of `tokens.css` (#070e1b), `"classic"` = `palette-classic.css` (#0b1020).
- New colours belong in tokens (every palette), not hard-coded in component CSS.
- Layout (iterations 25–27 in `docs/SPEC.md`, made so the app no longer looks like a BrainZone copy): phones get the
  bottom bar `BottomNav` (Главная · Дайсы · a raised gold «Апгрейд» disc — the owner's main game · Профиль · Ещё = the
  menu drawer — the owner's pick; `--nav-h`,
  pages pad for it, sticky `.action-bar`s ride above it); the header is logo · balance chip with «+» · your avatar →
  profile (no burger on phones, no gear; «Настройки» is a button on the profile page — the owner took it out of the menu). PC keeps the sidebar (burger only on a narrow PC
  window; the sidebar is one 264px column — a long menu line used to push the profile card past it). Home: event hero / x2 luck → free case card (`.free-hero`) → slim auto-promo strip → the running giveaway
  closest to its results (`.gw-strip`) → LIVE → theme chips +
  search → case grid (no games row: the owner removed it, the bar and the menu lead to every game); case cards show
  the art on a stage, the item count as a corner badge and the price as a gold button.

## Skills to use — ALWAYS (owner's standing rule)
Load the matching skill (Skill tool) before doing the work, every time:
- design and interface → `frontend-design` + `ux-designer`; interface check → `design-review`
- API and server → `api-design-principles`; TanStack Query → `tanstack-query`
- security → `owasp-security`
- site tests → `webapp-testing` / `playwright-testing`
- code review → `code-review`; deep audit → `full-review`
- big new feature → `technical-specification` first
- before saying «готово» → `verification-before-completion`
- 3D graphics → Blender (MCP server `blender`, see below)

Skills live in `.claude/skills/` (frontend-design, ux-designer ← github.com/Kevinchamplin/claude-skills;
design-review, tanstack-query, api-design-principles, code-review, technical-specification, playwright-testing
(= its `playwright` plugin) ← github.com/secondsky/claude-skills; owasp-security, full-review, webapp-testing,
verification-before-completion ← github.com/jojojobring/claude-skills).

Blender: `scripts/blender/setup.sh` installs Blender 5.2.2 LTS (blender.org, sha256-checked) and the MCP for Blender
add-on (ahujasid/blender-mcp, pinned to mcp-for-blender 2.2.2) and runs Blender on a virtual screen (Xvfb :99; the
add-on refuses `blender -b`) with its bridge on localhost:9876. The SessionStart hook (`.claude/settings.json`) runs
it in the background in every cloud session; `.mcp.json` starts the server (`uvx mcp-for-blender==2.2.2`,
telemetry off). Tools: `execute_blender_code` (any bpy, incl. renders), `get_scene_info`, `look` and the asset ones.
Log: `/tmp/blender-mcp.log`. Plain `blender -b -P script.py` still works for batch renders (`scripts/blender/*.py`).

## Project facts
- Brand: **BrainrotCrash** (renamed from a friend's BrainZone project, of which this repo, SAFEBET-NEW, is a separate
  copy on its own accounts) — bot @braincrashbot, site https://safebet.teonytofficial.workers.dev (`siteUrl()` in
  `server/env.ts`, the `URL` var in `wrangler.jsonc`), its own Cloudflare (worker `safebet`, KV `9fa1ea5b…`) and
  Supabase (project ref `nvbdjvdvgqfwyqfpmoql`, eu-west-1). No «BrainZone» anywhere in texts, art, localStorage keys
  (`brainrotcrash:`) or signatures — only the history in `docs/SPEC.md` and already-applied migrations keep it.
  News channel @BrainrotCrash and support bot @bcrashsupport_bot (`NEWS_URL` / `SUPPORT_URL` in `shared/links.ts`: the
  /start buttons; iteration 37: a round chat button `SupportButton` in the corner on pages without a sticky action bar,
  and «Поддержка» in the menu).
- Owners (permanent admins): Telegram IDs 7263901569, 8044175101 and 8621306718 (`OWNER_IDS` in `server/env.ts`).
  `server/api.test.ts` mocks its own two owners, so the list can change freely.
- Money has two decimals (NUMERIC(16,2)); round with `shared/money.ts`.
- Case drop weights are generated by `scripts/reprice.py` (EV = 88 % of the price); case art by
  `scripts/gen_case_art.py`; brainrot images are normalised by `scripts/normalize_brainrots.py`.
- Case chances are NOT stored: `shared/cases.ts#solveChances` derives them from current prices on every
  open (EV 88 % of the price, 2 % chance of a drop worth more than the case; x2 luck doubles that share and
  keeps the 88 % average). Players get flattened reel weights only, never the real chances.
- Admins can set a drop chance by hand per case item (`case_items.fixed_chance`, 0…1; 0 = «Невозможно», NULL = from
  prices; `solveCaseChances`): fixed items keep exactly their chance, auto items share the rest. Such a case is the
  admin's call — the healer skips it and it opens even above 100 % RTP. Zero-chance items never roll and players
  don't see them.
- Home page «темы»: `case_sections` + `cases.section_id` (admin Кейсы → «Темы на главной»).
- Every admin write (non-GET admin route) broadcasts `catalog` to every open app, so prices, names, chances and
  themes change live everywhere.
- «Saved in the project»: `node scripts/snapshot-supabase.mjs` (SUPABASE_TOKEN + SUPABASE_REF) turns production's
  catalog/cases/chances/themes/deposit list/settings into a new `*_admin_snapshot.sql` migration (marked applied on
  production; uploaded images go to `public/uploads`). Run it before every push.
- Case compositions heal themselves (`server/caseHealth.ts`): after a price edit or an admin save (and every minute in
  `tick`) a case that no longer fits its price gets the missing items from the catalog via `composeCase`. The healer
  only ADDS — what is in a case was picked by an admin and stays (the owner saw his picks vanish: «брейны не
  добавляются»); only «Пересобрать состав» (`force`) starts from scratch. A case whose items all cost more than the
  case refuses to open (`case_rebalancing`) until healed. The case editor never blocks saving an automatic case that
  doesn't fit yet (the server completes it); it says in words what is missing (picture, name, price, 2 items).
- Bot webhook (`/api/telegram/webhook`, secret header) handles Stars payments, /start /terms /paysupport, the
  admin buttons of brainrot deposits (`server/itemDeposits.ts`, callback data `d:<id>:<action>`), the admins'
  reply keyboard «📥 Очередь пополнений» and block/unblock (`my_chat_member` → `users.bot_blocked_at`).
  Its allowed_updates must include `message`, `pre_checkout_query`, `callback_query` and `my_chat_member`.
- Hosting: **Cloudflare Workers** (free plan) — `worker/index.ts` serves `/api/*`, the webhook and `dist/` assets;
  its cron runs `runTick` every minute. Database: **Supabase** Postgres (session pooler) behind **Hyperdrive**
  (`HYPERDRIVE` binding; a fresh pg pool per request via `runWithPool`). Uploads: KV namespace `UPLOADS`.
  Deploy: Cloudflare Workers Builds is connected to the GitHub repo (dashboard → safebet → Settings → Build): a push
  to its production branch builds (`npm run build`) and deploys (`npx wrangler deploy`) by itself — no token needed
  here; `npm run deploy` still works with CLOUDFLARE_API_TOKEN/ACCOUNT_ID. The production branch is `ccr-dd80fddd-jvf4d9`;
  the owner said «всегда автодеплой» (2026-10-29): push finished, tested work there yourself, then check the live site. Migrations stay in
  `netlify/database/migrations` (local dev applies them too); production gets them with
  `node scripts/migrate-supabase.mjs` (SUPABASE_TOKEN + SUPABASE_REF) — run it BEFORE deploying code that needs
  them. Without a Supabase token here, new migrations (from iteration 30) are applied by the Worker itself:
  `server/autoMigrate.ts` lists them (the .sql is bundled as text — wrangler `rules`, the `sql-text` plugin in
  vite.config.ts), runs them under an advisory lock from the tick and from the routes that need them, and records them
  in the same `_migrations` table — so they must be idempotent (IF NOT EXISTS); add each new one to its `MIGRATIONS` list
  (so far: brainflip_refund, growth, tickets, case_configs, iteration35, demo, sky, squid, wager, sky_pool, pass, ref_once, wager_x2, crypto). `handle()` also runs `ensureSchema()` once per
  isolate (errors only logged), so a fresh deploy has its tables before the first request needs them. Worker secrets (`wrangler secret put`): `BOT_TOKEN`, `DATABASE_URL`, `WIPE_PASSWORD`, `CRYPTO_PAY_TOKEN`. This copy has no
  Hyperdrive binding: `DATABASE_URL` (transaction pooler, 6543) is the only way to the database. Webhook secret =
  HMAC-SHA256(bot token, "brainrotcrash-webhook") unless `WEBHOOK_SECRET` is set. Free CPU budget is ~10 ms per request: keep handlers light.
  The old Netlify site (netlify/functions, netlify.toml) is no longer used.
- Hyperdrive query caching MUST stay disabled (`wrangler hyperdrive update <id> --caching-disabled true`): with
  it on, reads (balance, deposit status) were up to 60 s stale — the «everything happens a minute later» bug.
- Hyperdrive on the free plan stops after **100 000 queries a day** (resets 00:00 UTC; the launch evening of
  2026-10-20 did 85k in one hour and every request got «Connection terminated unexpectedly»). Since then the Worker
  secret `DATABASE_URL` (Supavisor transaction pooler, port 6543) wins over Hyperdrive (`run` in `worker/index.ts`):
  plain TCP, because Workers can't verify Supabase's own CA; SCRAM is derived once per isolate (CPU). On Workers Paid
  (Hyperdrive unlimited) delete that secret to go back to Hyperdrive (origin: pooler port 5432).
  The Worker is pinned next to the database (`placement.region = aws:eu-west-1`): every query is a round trip.
- Live updates (`server/live.ts`, `src/lib/live.ts`, `LiveHub` Durable Object in `worker/index.ts`): code that
  changes another player's state calls `touch(userId, topic)` (economy helpers, deposits, referrals and
  `notify` already do); after the response the Worker pings that player's open app over a WebSocket and it
  refetches. Bot messages that the answer doesn't need go through `afterResponse(...)`.
- The minute tick (`server/tick.ts`, formerly `netlify/functions/tick.mts`) runs every minute: heals cases, expires 5-minute trade windows, auto-opens
  battles nobody joined within 5 minutes (`server/battles.ts`) and sends bot notifications
  (`server/notifications.ts`: x2 luck broadcast, free-case-ready reminders, 3-day comeback; quiet hours
  23–09 MSK). Promo photos in `public/promo/` are rendered by `scripts/gen_promo.mjs`.
- Withdrawals (`server/withdrawals.ts`, rules in `shared/withdraw.ts`): one open request per player with several
  brainrots; it passes with ≥ `minValue` B OR ≥ `minItems` brainrots (settings `withdraw_rules`, default 100 B / 2);
  brainrots cheaper than `minItemPrice` (junk, default 45) or with `brainrots.withdrawable = false` never go out.
  The items stay in the inventory locked by `inventory.withdrawal_id` («НА ВЫВОДЕ»): `takeItem`, sell, admin take skip
  them and the `inventory_withdraw_guard` trigger refuses to delete a locked row until its request is `done`.
  Statuses pending → scheduled (admin: date + bot nick) → trading (5 min) → done/rejected; trading timeout → expired
  (admin reschedules or closes). The player cancels only before the first trade window (dupe guard). Bot buttons
  `w:<id>:<t|m|c|p|b|n|d|r|u>`, admins' «📤 Очередь выводов»; the tick sends the 5-minute heads-up, opens and expires
  windows (`advanceWithdrawals`).
- «Отыгрыш» (iteration 36, wagering; the owner: «отыграть до 1.25», researched against casino/case-site wager rules):
  `users.wager_left` (left to play) + `wager_total` (the current round, for the bar). Deposits (Stars incl. the promo
  bonus, brainrot deposits) add × `withdrawRules.wagerDeposit`, everything free × `wagerBonus` (both 1.25 by default,
  0…10, admin «Выводы» → «Правила вывода»; the SQL `wager_rate` has the same default): bonus/gift/ticket case drops
  (a `drops` row with stake 0, by the trigger), cashback, consolation spin, promo codes, the referral balance transfer,
  rank gifts, giveaway and squid prizes, sky coins/eggs, tacos, admin gifts (`addWager` / `addItemWager` in
  `server/economy.ts`, SQL `wager_add`). Every real stake in any game plays it down — the AFTER INSERT trigger
  `drops_wager` (migration `20261114100000_wager.sql`) sees every game; demo touches nothing. Winnings of own stakes
  add NOTHING (each stake returns 0.88 on average: adding 1.25 × that would grow faster than it is played — never make
  wins wagered). `createWithdrawal` refuses `wager` (after the selection's own problems) until it is 0; exchange and
  sell still work. Shown in the withdraw sheet (`WagerMeter`), the profile (`WagerChip`), the deposit sheets
  (`DepositWagerNote`), the agreement (TERMS_VERSION 2) and the admin player card. Owners only: «Без отыгрыша» in
  Выдача (`noWager`) and «Снять отыгрыш» (`POST /api/admin/users/:id/wager/clear`, logged `wager_clear`) — an admin
  could otherwise hand out coins that leave at once. Old players started at 0; the danger zone zeroes it. A new
  free credit must call `addWager(…, 'bonus')`; a new game only needs to record its drop.
- Stakes are brainrots only in every game (the owner's rule): coins in a stake → `items_only`.
- Upgrader look (iteration 37, the owner's reference, Crash skin): compact (`--size: min(66vw, 252px)`, «он гигант»), a
  thin outer ring of ticks, a dark disc (`--gauge-disc`), the chance as an arc in the track (`--gauge-track`; gold → accent → red), a small arrow
  riding the track and pointing in, our BC mark in the middle with the chance under it; no stage light behind it.
- Case cards (iteration 37): up to three brainrots of the case stroll along the bottom of the art (`CaseWalkers`,
  transform only, paused off screen by `useOnscreen`, none with reduced motion, none for a mystery case).
- Upgrader minimum stake (iteration 38, the owner: «апгрейдить от 10»): `MIN_UPGRADE_STAKE` 10 B in total
  (`stake_too_small`; the page says so instead of the spin button).
- Wagering ×2 since iteration 38 (the owner: «отыгрыш до х2»): Worker migration `wager_x2` set `withdraw_rules`
  wagerDeposit/wagerBonus to 2 and the SQL `wager_rate` default to 2 (`DEFAULT_WITHDRAW_RULES` too); requirements
  counted before stay, new credits count ×2.
- Upgrader stake: up to 5 brainrots (`POST /api/upgrade { itemIds, targetId }`), chance = stake / target ×
  `UPGRADE_RTP` 0.8 (`upgradeChance` in `shared/upgrader.ts`: the house keeps 20 % since iteration 38 — the owner: «почти
  всегда окуп падает», «зелёный большой»; was 0.88), at most 75 % (`MAX_UPGRADE_CHANCE`; 50 % for a few hours of
  iteration 38, then back at the owner's word; server refuses `too_easy`); quick picks by chance 75 / 50 / 30 / 10 %
  (`targetForChance`: the target whose real chance is closest — the catalog decides how close). The owner also asked for the needle to «не докрутить» (fake near-misses)
  and for luck events that do nothing — refused, see the luck notes: only real, shown odds change. The ring, the % on screen, the target list and the server roll all
  use that one function — the shown chance is the rolled chance (the owner asked to show 75 % and roll 50 %; refused:
  that would be lying to players about real-money odds). No shop anywhere in the app: the owner removed it from the upgrader
  and then from every stake picker (`StakeSheet`, `InventoryPicker`); `/api/shop/buy` is left unused.
  Its effects (stake fly-in, needle trail/sparks, win burst, lose cracks) live in `UpgradeRing.tsx` / `Upgrader.tsx`.
  Halloween skin: a Blender-rendered stone circle with a cauldron (`public/upgrader/plate.webp`) and a wand needle
  (`wand.webp`) from `scripts/blender/upgrader_plate.py`; Crash skin: a vault dial (gold knurled bezel, engraved ticks,
  a groove for the chance arc — `dial.webp`) and the logo's gold arrow as the needle (`arrow.webp`) from
  `scripts/blender/upgrader_dial.py` — retired in iteration 30: the owner wanted no picture under the ring («фон не
  было, png без фона», like skin sites' open gauges), so the Crash skin draws the gauge over the page itself
  (`src/styles/crash-theme.css`: a glassy track with engraved ticks, the green win arc in the same band, a gold pointer
  `.uring__tip` riding the ring, «?%» / the chance large in the open middle) and lights the stage instead of boxing it
  (a spotlight cone with drifting dust, a glow that wakes up while the needle turns, a shadow pool, green/red on the
  result). Above the ring the HUD `.up-hud`: sound (the app's switch), «быстро», and «x2.00 · 310 → 620» with a bar of the
  chance against the 75 % cap. `UpgradeRing` loads only the current skin's pictures (Halloween's still). The spin takes 3.5 s and 5 turns (`SPIN` in `Upgrader.tsx`; the owner: «до 4 секунд» from the tap, iteration 39 — the
  server's answer comes first; «быстро» 1.6 s); the chance band in the track is thin (73–82 % of the radius, iteration 39) with
  a cubic ease-out, so the needle keeps crawling to the very end; the result shows only when it stops.
- The `Coin` icon is an `<img>` sized inline (`Coin.tsx`): card rules like `.slot img { width: 64% }` must never
  stretch it — style brainrot pictures with `img:not(.coin)` when a card also shows a price.
- Brand art (`scripts/blender/brand.py`, Unbounded Black in `scripts/blender/fonts`): the BC mark — a glossy red B, a
  blue C with its mouth opened wider than the font's, a gold crash-chart arrow across them (`public/logo-bc*.webp`,
  `BrandMark` in `Logo.tsx`) — sits before «BRAINROT·CRASH» and on the loading screen; the coin icon is the gold BC
  coin (`public/coin*.webp`, `Coin.tsx`); `public/favicon.svg` is the flat mark. The header wordmark follows the room
  it has (container units, ≥ 12px on one line), folds into BRAINROT / CRASH below a 192px box, and only the mark stays
  below 104px.
- Coin prizes (`brainrots.kind = 'coins'`, admin Каталог → «Монеты»): a catalog row whose price is the amount; it goes
  into cases with chances like a brainrot, a win credits the balance (`deliverDrop` in `server/economy.ts`, cases and
  battles). Never in the shop, upgrades, payouts, fuse, exchange, deposits or admin give; a case holding one is the
  admin's call (the healer skips it, like hand-set chances).
- Test deposits are gone for good (no tab, no `/api/deposit`, no `demo_deposits` setting): coins come from Stars,
  brainrot deposits or an admin.
- «Для демо» gifts (iteration 35, admin Выдача switch, on by default and remembered per device; Worker-applied migration
  `20261111100000_demo.sql`): demo coins are `users.demo_balance` (the demo part of `balance`; demo and own coins never
  mix in one payment — demo pays when it covers the whole price, else own coins do, else `mixed_coins`: a «more than
  half» rule let a top-up launder the whole gift through one dear x5 opening; triggers keep it within 0…balance), demo brainrots
  `inventory.demo`, demo gift openings `case_keys.demo_count` (used first). Whatever a demo stake wins is demo too
  (`stakeDemo`, `spendCoins → {demo}`, the `demo` argument of `giveItems` / `addCoins` / `deliverDrop` / `payOut`;
  crash/mines/road rounds keep `demo`); a stake mixing demo and own brainrots is refused (`mixed_demo`). Demo never
  leaves: no withdrawal (`withdrawBlock`), no exchange (`demo_item`), battles and own promo codes take own coins only
  (`spendRealCoins` → `demo_coins`), no consolation spin, no share. `drops.demo` keeps demo games in the player's own
  history only — out of quests, cashback, ranks, referral milestones, LIVE, the top drop, the games' «top wins» and
  «Экономика» (holdings count own coins and brainrots only; demo gifts aren't «admin gifts»). «ДЕМО» (`DemoTag`, tokens
  `--demo*`) shows on brainrots, the balance, the case win card, history, the public profile and the admin card;
  «Забрать» takes demo coins first. A new game must carry the stake's demo mark the same way.
- Owner-only admin sections: «Рассылка» (`announce` in `server/admin.ts`: photo + text + button to an app section, test
  to self, sent to every non-blocked player through `broadcasts` by the tick, max 40 messages a minute because of the
  Worker's subrequest limit) and «Опасная зона» (`server/danger.ts`: reset one player or wipe all players' coins,
  tickets, items, history, keys, claimed quests, open withdrawals…; admins, titles, Stars payments, brainrot deposits,
  done withdrawals, rank gifts and referral milestones stay — a new game-state table/column must be added to `wipe`). The danger zone
  password is the Worker secret `WIPE_PASSWORD` — never in the repo; 5 wrong tries lock it for 15 minutes.
  Iteration 38: «Обнулить всех, кто подобрал яйцо» (`resetEggPlayers`, `POST /api/admin/danger/reset-eggs`): every
  non-staff player with `sky_players.eggs > 0` is reset like «Обнулить игрока» in one set-based wipe (`wipe(c, ids)`);
  the card lists them first; logged `danger_reset_eggs` with the ids.
- Spiders (`src/components/Spiders.tsx`, Halloween skin only): one dangles on a thread, two crawl along the edges; a tap
  scares them off. CSS/DOM only, off with reduced motion.
- «Бесплатный кейс готов» reminder: the owner's own banner `public/promo/free-case.jpg` (he chose it over a matte
  remake) and the same words as on it.
- Haunted Fuse (`#/fuse`, menu «FUSE», `server/fuse.ts`, rules in `shared/fuse.ts`, key table `fuse_seeds`): 3–4
  brainrots in, one random brainrot out — 82 % cheaper than the stake, 15 % x1–x1.5, 3 % x1.5–x2, never above x2,
  average 88 % (weights solved per stake from the catalog). The page shows only what can really drop («Может выпасть
  X–Y»): the owner asked for unreachable prizes as decoration — that would mislead players, so it isn't done. A stake
  nothing in the catalog is worth is refused (`stake_too_big`). The house is a voxel model from
  `scripts/blender/haunted_fuse.py` rendered in layers (`public/fuse/*.webp`: house with shut lids, door, mouth, eye
  glow, pupils, tongue + `src/lib/fuse-layout.json`); it is alive in CSS (`src/styles/fuse.css`): breathes, sways,
  blinks, looks around, licks its lips, stares at the set on the pad, growls when poked; the fuse runs open → grab
  (tongue out) → feed (pulled in) → gulp → chew → spit (the drop rides out on the tongue). Not in `HOUSE_GAMES`. Blender comes from `scripts/blender/setup.sh` (the SessionStart hook runs it).
- Only brainrots «в наличии» (`brainrots.withdrawable`) go out. Others from `minItemPrice` up are exchanged in the
  withdraw sheet (`POST /api/withdrawals/exchange`, `exchangeOffers` in `shared/withdraw.ts`): catalog value → in-stock
  brainrots + change in coins (`item_exchanges`).
- The Halloween event and its games («Хеллоуин-ивент» `#/event`, «Сладость или гадость» `#/trick`, «Ночной забег»
  `#/halloween`) were removed in iteration 31 at the owner's request: pages, routes, servers and the `halloween`
  setting are gone; their tables and old history rows stay. The Halloween *palette* (`data-palette="halloween"`) stays.
- Other players see a player by the Telegram first/last name only (`publicName`): top drop, public profile, battles,
  the LIVE feed.
- «LIVE» on the home page (`LiveDrops.tsx`, `server/liveDrops.ts`): one frame with «Топ дроп дня» and a strip of the
  newest winning drops of everyone (tile in its rarity colour + the player's Telegram photo or initials; a tap opens the
  public profile). `recordDrop` notes each winning drop in the live scope; after the response the Worker reads them
  back (`dropsByIds`, so rolled-back ones vanish) and `LiveHub.publishDrops` sends them to every open app — no app
  polls for them while its socket is up (`GET /api/drops/live` is the start list and the fallback). The strip reveals
  at most one new tile a second (bursts keep the newest 6) and a pricier drop takes over «Топ дроп дня». Only real
  drops — never fake activity.
  «Очистить топ дроп дня» (iteration 41, admin «Ивенты», `POST /api/admin/top-drop/reset`, logged `top_drop_reset`):
  setting `top_drop_since` (ms) — `topDrop24h` counts only later drops; nothing is deleted. Menu: «Бонусы» right after FUSE.
- New promo code → ready-to-post text (iteration 42, the owner's template «🎉ПРОМОКОД СОЗДАН … ⚡️УСПЕЙ АКТИВИРОВАТЬ»):
  `PromoAnnounce.tsx` (`promoAnnouncement`, `promoRewardText`) under the admin «Промокоды» form and a player's own code form
  in «Рефералы», with «Скопировать текст».
- Several cases at once (`count` 1/3/5 = `OPEN_COUNTS` in `shared/cases.ts`; the owner wants x1/x3/x5, no x2; paid non-bonus cases only, never with a
  gift key): one payment of price × N, every drop rolled and recorded on its own; the client spins N compact reels
  (`CaseReel` in `CaseOpening.tsx`) and ends on one card with all drops. Short of coins → «Не хватает X» on the button.
- Battles roll each case ONCE: a dearer drop takes both, equal prices are a draw (each keeps their own). Never
  reroll ties — with hand-set chances most rolls tie on the cheap item and rerolling them made battles pay 85–92 %
  on cases that pay 30–47 % when opened (two accounts could farm it).
- Toasts (`Toaster.tsx`) live in the top layer as a manual popover re-shown on every toast, so errors show above
  sheets (modal `<dialog>`s) and the case opening; old WebViews fall back to z-index 70.
- Admin protections: a frozen admin loses `/api/admin/*`, a banned/frozen admin's bot buttons stop (`isAdmin` in
  `itemDeposits.ts`), nobody lifts their own punishment, owners can't be «Забрать»-ed and admins only by an owner;
  admin promo codes can't take a player's partner code (`codeTaken`). Danger-zone tries are serialised per owner.
- Case items of switched-off brainrots stay in the case: the healer only INSERTs, the editor's save deletes only rows
  of brainrots that are on (or that it sent).
- Case reels (`src/lib/useReelSpin.ts`) are driven frame by frame (speed-aware ticks, centre highlight, overshoot);
  effects in `src/components/Fx.tsx`; keep them CSS/DOM only (Telegram webviews on weak phones). No motion blur and no
  animated `filter` (the owner disliked the blur at the start, and it cost frames): only transform/opacity animate; the
  tier light and the lifted centre card follow the marker only below 45 % of top speed.
- Deposit brainrots and their prices come from the admin list (`deposit_items`, `server/depositList.ts`);
  the player picker keeps the original grid design (the owner asked to keep it). Up to 5 pieces per deposit
  (`MAX_DEPOSIT_ITEMS` in `shared/deposit.ts`, one Roblox trade). The picker has two tabs, «Брейнроты» and «Гирсы»
  (`deposit_items.section`); admins move entries between them in Пополнения → Список.
- Free case gate (`server/freeGate.ts`): subscription to the channel in settings `free_case_gate`
  (@BrainrotCrash, migration `20261103100000_free_gate_channel.sql`; checked with getChatMember on every free opening —
  the bot must be an admin of the channel, otherwise the check can't see members and lets everyone through)
  and a share (savePreparedInlineMessage + WebApp.shareMessage) before every free opening. Sharing must work on the
  first try (the owner's complaint, iteration 34; `useFreeShare` in `FreeGate.tsx`, `shareMessage` in
  `src/lib/telegram.ts`): the message is prepared as soon as the step shows (`POST /api/free-case/share` hands out the
  same unconfirmed one for 30 min), so the tap opens the picker with no round trip; when only the share is left the
  big button is «Поделиться и открыть» (share, then the case opens); the gate's re-check on app return waits while a
  share runs and the confirmation cancels one in flight — its stale «not shared» used to undo the confirmation, so the
  first share «didn't count». Telegram's «not sent» doesn't count; a client that never answers counts once the
  player is back in the app (1.5 s grace), like the t.me/share fallback; the button is never stuck (a new tap after 8 s).
- Bot buttons deep-link with `?open=<route>/<param>` (Telegram owns the URL hash).
- /start (`server/botWelcome.ts`): the owner's own banner `public/promo/welcome.jpg` (he supplied it as is) + his
  welcome text and buttons «📢 Новости», «💬 Поддержка» (each only when `NEWS_URL` / `SUPPORT_URL` is set), «🎮 Играть»,
  «🎟 Ввести код».
- Telegram caches a sent photo by its URL: every promo picture goes out as `promo('<file>')` (`server/env.ts`,
  `/promo/<file>?v=PROMO_VERSION`). Replacing a picture in `public/promo` means bumping `PROMO_VERSION`, or players keep
  seeing the old one (that is how the /start banner kept showing «BrainrotZone»).
  The code button (and `/code`) asks by force-reply and activates through `activatePromo` with the app's gates
  (`viewerOf` in `auth.ts`: ban, maintenance, freeze). A friend's link / `friend` payload adds a line on top.
- Referrals (`server/referrals.ts`, rules in `shared/bonuses.ts`): code + link `t.me/braincrashbot?start=r-<code>`
  (code changeable once a day; old codes stay the owner's in `ref_code_history`), partner code in «Бонус-код»,
  players' own promo codes (paid up front, only after a real deposit). One referrer per account, forever
  (`bindReferral`: row locks, self/loop refused); a player already bound who follows someone else's link counts for
  nobody — no case, no invite, not even a click (`recordClick`). The referrer gets 5 / 7 / 10 / 12 / 15 % (levels at
  0 / 10 / 30 / 100 / 250 active friends = first deposit ≥ 10 B) of every friend deposit (what was paid for, the promo
  bonus aside) at once on the referral balance (`payDepositShare`, called by `stars.ts` and `itemDeposits.ts`), never
  from bets; there is no weekly payout any more. Risk to keep in mind: at 12–15 % a deposit cycled back out through
  cases (~12 % loss) pays the referrer about as much as it costs — don't raise the levels. The free case share message
  carries the sharer's referral link. Partners (bloggers): an owner sets `users.ref_percent` (5–15, never above the top
  level; admin player card → «Партнёр», `setPartner` in `server/growth.ts`) — it replaces the level percent from the
  first friend on.
- «Крупные приглашения» (`REF_MILESTONES` in `shared/bonuses.ts`, `payDue` in `server/referrals.ts`, table
  `ref_milestones`, `ref_payouts.kind = 'milestone'`): when a friend's net deposits since binding (deposits − done
  withdrawals) pass 1 000 / 5 000 / 20 000 / 50 000 B AND the friend has played `REF_MILESTONE_TURNOVER` (3) × that in
  cases and battles since binding, the referrer gets +100 / +500 / +2 000 / +5 000 B (10 %, the owner's «друг пополнил
  1000 — ему 100») once per threshold, plus a bot message. Paid in the deposit's transaction (`payMilestones`) and by
  the tick for friends who played in the last 10 min (`payPlayedMilestones`, one set-based statement). The turnover is
  what keeps it from bankrupting the house: 3× played at 12 % edge ≈ 36 % of the threshold, more than 10 % + the 5–15 %
  deposit share — never drop it or lower it below ~2.5. Net deposits, so depositing and withdrawing again never pays
  twice. The «Рефералы» page shows the ladder (reward first), the rule, each friend's progress on both conditions and
  running invite races.
- «Дорога» (`#/road`, menu item, `server/road.ts`, rules in `shared/road.ts`, tables `road_seeds`, `road_runs`): our
  take on Chicken Road on brainrot stakes (1–5, coins → `items_only`). Levels Лёгкий / Средний / Сложный / Хардкор =
  4 / 12 / 20 / 30 % crash per lane over 24 / 22 / 17 / 11 lanes; lane k pays floor2(0.94 / (1 − p)^k) (the house
  keeps 6 % wherever the player leaves), lanes above x50 are cut, a step whose win would pass 25 000 B is refused
  (`limit`), the last lane cashes out by itself. One active run per player (unique index); the run's key is
  committed before the stake (sha256 shown), lane k crashes when sha256("road:" + key + ":" + k)'s first 32 bits / 2³²
  < p, the key is revealed at the end. The tick closes runs idle for 30 min: after a step it takes the win for the
  player, before one it returns the same brainrots. A cash-out below x1 is no win (no LIVE tile). Not a house game.
  The scene (`src/styles/road.css`) is CSS only: lanes with manhole multipliers, CSS cars, barriers on crossed lanes.
- «BrainFlip» (CoinFlip on brainrots, iteration 30) was removed in iteration 31 at the owner's request: the page,
  routes, server, live topic and tick job are gone; `20261107100000_brainflip_refund.sql` (Worker-applied) returned the
  brainrots of flips still open to their creators and marked them cancelled. The `flips` table stays as history.
- «Мины» (`#/mines`, menu item, `server/mines.ts`, rules in `shared/mines.ts`, tables `mines_seeds`, `mines_runs`): a
  5×5 field, 3–24 mines (the owner set the floor at 3; presets 3/5/10/15/24), brainrot stakes 1–5 (coins → `items_only`). After k clear tiles with m mines it pays
  floor2(0.94 · C(25,k) / C(25−m,k)) — the house keeps 6 % wherever the player stops; a tile past x100 or 25 000 B is
  refused (`limit`), and when nothing more can be opened the win is taken by itself. The field is the first m places of a
  Fisher–Yates shuffle drawn from sha256("mines:" + key + ":" + i), committed before the stake, stored in
  `mines_runs.mines_at` and never sent before the round ends. The tick closes rounds idle for 30 min (after a tile: the
  win; before: the stake back). Not a house game. UI reuses the road's result/summary classes (`src/styles/mines.css`).
- Events (`shared/events.ts`, admin «Ивенты»): x2 luck in cases (`luck`, real: окуп chance ×2, average 88 %), the FUSE
  and upgrader events (`fuse_event`, `upgrade_event`) and Raining Tacos. The FUSE/upgrader events are the LOOK only —
  the owner said so explicitly — so their texts never promise better odds (no «x2 шанс» where nothing changes; same
  line as the refused «show 75 %, roll 50 %»). Icons are the owner's art in `public/events/luck-*.webp`. They ride with
  `/api/catalog` (`events`, `snap`) so a switch reaches every open app live; `EventBanner` on the game pages and
  `EventsHud` on every page (`src/components/Events.tsx`): the owner's «как ивенты удачи в SAB» — one square per
  running event (icon + time left + short name) on the phone's bottom bar, split around the upgrader disc (PC: pills in
  the header's empty middle — at the bottom it covered the upgrader's button; a narrow PC window drops the names); a tap
  leads to the event's game, the tacos square mutes / unmutes the music. While it shows on a phone,
  `<html data-hud="phone">` sets `--hud-h`, so pages and sticky `.action-bar`s make room (PC reserves nothing).
- Crypto deposits (iteration 38, `server/crypto.ts`, rules `shared/crypto.ts`, migration `crypto`): Crypto Pay
  (@CryptoBot) — the deposit sheet's «Крипта» tab: RUB packs 10…5 000 ₽ or any 10…200 000 ₽ (iteration 39, the owner: «от 0,1 $»; CryptoBot's own floor for a
  coin answers `crypto_too_small`) at `cryptoRate` B per ₽
  (setting `crypto` {rate}, default 1.4 = the owner's «100 ₽ — 140 монет»; owners change it in «Платежи»), a fiat
  invoice (`currency_type=fiat`, RUB) payable in USDT/TON/BTC/ETH/LTC/TRX/USDC/SOL, opened in Telegram
  (`mini_app_invoice_url`). Credited once (row lock + `crypto:<invoice_id>` in star_payments) by the signed webhook
  `POST /api/crypto/webhook` (HMAC-SHA256 of the body, key = SHA-256 of the token; the owner pastes the address shown in
  «Платежи» into the CryptoBot app's Webhooks) OR by asking CryptoBot (`getInvoices`) when the app polls the order and in
  the tick (`checkCryptoOrders`, 2 h back). A paid crypto invoice is also a `star_payments` row with stars = 0 and no
  order: every «deposited» sum (ranks, races, quests, milestones, sources, economy) counts it; Stars-only totals filter
  `stars > 0`. Like Stars: coins, wagering, the referrer's share, milestones; no promo/partner bonus. Secrets:
  `CRYPTO_PAY_TOKEN` (never in the repo), optional `CRYPTO_PAY_NET=testnet`. Tests fake CryptoBot with `useCryptoApi`.
- «Окуп в кейсах» (iteration 38, the owner: «укорочь шансы, в минус уйдём», temporary; owners only, admin «Ивенты»,
  setting `okup_cut` {factor 1/0.75/0.5/0.25/0.1/0 «Без окупа», until|null; one tap in the card applies it; luck can't run with 0
  — `luck_running` / `okup_zero` — or its «шанс окупа ×2» would lie; zero-chance drops vanish from the players' prize list}, `POST /api/admin/okup-cut`, logged): every drop dearer than a
  PAID case — hand-set chances too — × factor, the freed chance goes to the cheaper drops in their proportions, so cases
  and battles pay less on average (`cutOkup` → `solveCaseChances(…, cut)`, applied in `withChances` only: the healer and
  the case editor keep the usual model). Free, bonus and ticket cases (price 0) don't change; luck multiplies the cut
  chance. Migration `ref_once` switched ×0.5 on; tests delete the setting. No player text may promise «88 %» while it runs.
- «Откуда инвентарь» (iteration 38, owners; the owner: «чел с инвентарём на 15 тысяч — как он получает»): a button on
  the admin player card → `GET /api/admin/users/:id/audit` (`server/audit.ts`, `src/pages/admin/Audit.tsx`): deposits,
  withdrawals and holdings (+ what is beyond the deposits), real stakes vs payouts per game, free drops by case, other
  bonuses, admin gifts, inventory by source, top drops and the friends brought (no deposit and no play = twink flag).
- Luck x4 / x8 (iteration 35, settings `luck4` / `luck8`, admin «Ивенты» → Удача x2/x4/x8, the owner's icons
  `public/events/luck-x4|x8.webp`): REAL like x2 — the окуп share is ×4 / ×8 (capped at 50 %) and the average stays 88 %
  (`luckMultiplier` → `solveChances`). The owner asked for «ничего не делают» like the FUSE events; refused, because a
  «x8 удача» label promises odds — a do-nothing luck event would lie about real-money chances. The strongest running one
  counts (`me.luck` {x, until}); the bot broadcast names it. «Щелчок»'s default set leaves x4/x8 out
  (`SNAP_DEFAULT_EVENTS`); the admin can tick them.
- «Небо Meowl» 2.0 (iteration 37): coins lie one at a time (`SKY_COIN_CHANCE` 18 % of chunks), natural eggs are near
  impossible (`SKY_EGG_CHUNKS` 4 000); a run has a pool for everybody (`sky_runs.pool/paid`, admin «Фонд на всех»,
  default 100 B; per-player cap default 10 B) — a pick spends it in the same transaction, a spent pool refuses
  `sky_pool`. Fights: the last 30 s of every 3 minutes of the wall clock (`skyFight`, same in the room and the app):
  100 HP, a sword hit 20 within `SKY_HIT_REACH`, 0.6 s cooldown, 0 HP = knocked out (frozen, no picks) until the fight
  ends; fun only, no coins move (`server/rooms/sky.ts`: `f`/`sw`/`hit`/`ko`; button «Удар» / F). The flyer is the
  owner's broom Meowl (`public/sky/meowl-broom.webp`, background cut from the owner's picture — the checkerboard was
  painted in; `meowl-face.webp` for menus): the engine draws it from one image with the bristles fluttering apart
  (`split` in sprites.json), a lean into turns, a shadow, gold sparkles, the sword in fights; sounds `sfx.wind`
  (speed), `sfx.catMeow`, `swing`/`hit`/`ko`/`horn`. The old six winged frames are gone (`sky_sprites.py` still makes
  trees and houses).
- «Небо Meowl» (iteration 35, `#/sky`, `shared/sky.ts`, `server/sky.ts`, admin «Ивенты» → Небо Meowl, Worker-applied
  migration `sky`, tables `sky_runs|players|picks|eggs`): a multiplayer flight event. The admin launches it for N minutes
  with a coin cap per player (default 20 B; deposits only by default — multi-accounts don't farm; staff always fly),
  optionally repeated every K hours by the tick (`skyTick`), and can drop rare eggs (10 B, over the cap) next to
  everyone flying or N random players — they see «<admin> заспавнил редкое яйцо — успей подобрать!» with `sfx.eggAlert`.
  The running flight is the `sky` setting ({run, launch form}) and rides with the catalog (`catalog.sky`: seed, end, cap)
  → home card, menu item, a square in the events row, `?open=sky` from the bot. The map and the coins come from the
  run's seed: coins (0.5 B, trails per chunk) and natural eggs from a hash only (`chunkCoins`, `naturalEgg`), so the
  server re-derives every pick (`skyThing`); the terrain (`src/lib/sky/terrain.ts`: hypsometric tints, hill shading
  from the NW, contours, rivers, lakes, forests summer/autumn, rocks, villages with fields, paths and a mill) is drawn in
  Web Workers (`terrain.worker.ts`), the game on a canvas (`src/lib/sky/engine.ts`: floating joystick / WASD / held
  mouse, coins and eggs above the trees, Meowl's winged shadow, clouds with shadows, radar, arrows to eggs). A pick
  (`POST /api/sky/pick`) is real coins: the coin must be in the map, not taken (`sky_picks` primary key = shared, first
  come), within flight reach of the player's last pick or spawn (`canReach`: 1.35 × SKY_SPEED + slack) and under the
  cap. Multiplayer is a `GameRoom` Durable Object per run (`/api/room?t=<signed ticket with the public name>`, wrangler
  migration v2; `server/rooms/sky.ts` is the pure room logic, also served by `scripts/local-dev.mjs` over `ws`):
  positions in at ≤ ~4 Hz while moving, one snapshot of who moved every 250 ms out, coins taken and eggs dropped pushed
  by the API through `server/rooms/bridge.ts`; at most 150 players a room (free-plan request budget). Sprites:
  `scripts/blender/sky_sprites.py` (Meowl from above with six wing-beat frames, pine, oak, autumn oak, rock, two houses,
  mill) → `public/sky/*.webp` + `src/lib/sky/sprites.json` (anchor + units per pixel); the egg is the owner's picture.
- «Батл пасс» (iteration 37, `#/pass`, menu item, rules `shared/pass.ts`, `server/pass.ts`, tables `pass_orders`,
  `pass_plus`, `pass_claims`): a season = a Moscow calendar month, 30 levels (120 + 10·(k−1) XP each, 7 950 in all). XP is
  read, never stored: real non-demo stakes of the season (1 per B; 0.5 in mines, road, crash) + claimed quests (+20 daily,
  +60 weekly). FREE (top, iteration 39 — the owner: «на фри дохуя фармят») = a reward on 14 of 30 levels only: 5 tickets
  every third level, 15 on 5/15/25, brainrots 6/10/15 B on 10/20/30 ≈ 40 B a season (null = no reward, `no_reward`);
  BPlus (bottom) = 299 ⭐ through its own Stars
  invoice `pass:<order>` (pre-checkout/payment in `server/stars.ts` → `passCheckout`/`passPaid`, idempotent by charge
  id; no coins, no deposit, no referral share), worth 1.5× its price at the star rate (`passPlus`: weights 1, 4 every
  fifth (5 on 10/20), 10 at 30), open at once for every level reached. BPlus has no brainrots since iteration 39 (the
  owner: «всякое кроме брейнротов, а то никто не купит»): coins on most levels, tickets every third, a free opening of the
  dearest paid case ≤ the value on every fifth (`passCaseFor`: paid, on, no bonus, no floating price; the rest in coins
  → `case_keys`). Coins are wagered at once (bonus); openings and tickets through the drops trigger like any free drop;
  FREE brainrots ≤ the value + change (`payoutFor`). One row per level+track = claimed once; unclaimed burns with the season.
  «Не в минус»: the full pass ≈ 5 000+ B of stakes, whose edge (≈ 440 B after tickets) covers FREE + what BPlus gives
  over its price (≈ 200 B). «Экономика» counts BPlus stars as income (`passCoins`) and pass brainrots, coins and case
  openings (at the case price) as a bonus; the
  danger zone wipes claims, never purchases.
- «Анонс в игре» (iteration 37, like Sammy in Steal a Brainrot; admin «Ивенты» → «Анонс в игре», `shout` in
  `server/admin.ts`, rules `shared/shout.ts`): any admin, ≤ 200 chars, colour accent/red/green/gold, one per 20 s
  (advisory lock), logged; the `shout` setting rides with the catalog, `ShoutOverlay` drops it on top of every open app
  with the admin's round photo, name and `sfx.announce` for 8 s (an app opened within 2 min still gets it, once per
  device, `brainrotcrash:shout-seen`). Not the owner's «Сообщение на сайте» banner, not the bot broadcast.
- Immortality for trailers (iteration 37, admin «Ивенты», `POST /api/admin/immortal`, setting `immortal` = admin ids):
  each admin's own switch; the signed room pass carries `g:1` (`roomTicket({god})`, header `x-room-god`, `join(…, {god})`).
  In «Игра Кальмара» red light, hits, the candy and the glass never take them out (a wrong pane breaks, they walk on);
  leaving / idling / the hidden net still do (`NOT_GAMEPLAY`). In «Небо Meowl» fights they take no damage.
- «Игра Кальмара» (iteration 35, `#/squid`, rules in `shared/squid.ts`, `server/squid.ts`, the referee
  `server/rooms/squid.ts`, Worker-applied migration `squid`, tables `squid_games`, `squid_players`, setting `squid`): an
  admin event (admin «Ивенты» → Игра Кальмара): 1–10 prize places (a brainrot or coins each), «только с пополнением»
  (default on), the bot invite (default on; stopped once the lobby closes). The start puts the game in the catalog, so
  every open app gets `SquidInvite` at once (and a square in the events row, a home card, a menu item); 2 minutes to get
  in (`SQUID_LOBBY_MS`), then 4 knock-out stages with a 9-second break before each. Iteration 36 (the owner: «не
  заканчивался таймер — само закончилось, когда игрок пройдёт фулл»): only the lobby, the breaks and the night have a
  clock (`SQUID_STAGE[s].ms`, null = none); the other stages end when everyone still in is through or out, the top bar
  shows «Добежали 3 из 7» instead, and nobody waits for stragglers — 15 s disconnected = out «вышел», 20 s of green stood
  still = «уснул», 40 s without tracing the candy = «соты засохли»; a hidden 10-minute net (`SQUID_STAGE_CAP_MS`) only
  closes an abandoned room. «Тише едешь» (hold to run on
  green; moving on red after a 650 ms grace = out — easier since iteration 37: field 1 800, longer green, shorter red; the room caps the speed), «Кровавая ночь» (30 s, all
  against all, 100 HP, a sword hit 15–20 within reach, 600 ms cooldown), «Сахарные соты» (trace your shape —
  circle, triangle, star, heart — off the line or too fast cracks it; a stroke starts only on the line; the app sends a
  point every ≥ 50 ms so finger jitter never reads as «too fast»), «Стеклянный мост» (as many spans as players reach it,
  2–18 — `bridgeSpans`, else a few survivors would all fall; 7 s a step, the room steps for an idle walker; a step
  shows everyone which glass holds). Places go by crossing order; the room is the authority (the API only asks it
  `results`), `settleSquid` (players' apps when they see «done», and the tick) records everyone and pays once under the
  game's row lock; staff play but never take a place — the prize goes to the next player (as in giveaways). Players who
  join after the lobby only watch. The watcher is our own giant Meowl statue, not the show's doll; no blood — «выбыл».
  The same `GameRoom` class hosts both games (picked by the room name's `sky:` / `squid:` prefix). Art:
  `scripts/blender/squid_art.py` → `public/squid/*.webp` (watcher back / red-eyed, candy, sword, the arena — its torches
  recoloured to fire and the wood darkened to night in post —, the «Тише едешь» sand field between pink-capped walls,
  the bridge's tempered pane and the broken one, 4:1); on a PC the game page is a 600 px column. Local e2e: `scripts/local-dev.mjs` serves
  `/__dev/room?name=squid:<id>&op=skip|stage&stage=<s>` to walk a room through its phases (never in the Worker).
- «Щелчок» (admin «Ивенты» → Щелчок, `snap` setting): our take on Sammy's Snap from Steal a Brainrot. The admin picks
  1–180 minutes and the events; every chosen event runs until the same moment (a longer one keeps its end) and every
  open app — or one opened within 10 minutes — plays the 10-second cutscene once (`SnapOverlay`, seen-mark
  `brainrotcrash:snap-seen`), then the «ИВЕНТЫ ВКЛЮЧЕНЫ» card; the Raining Tacos music starts by itself when the card
  comes up. The film is `public/events/snap.mp4|webm` rendered by `scripts/blender/snap_cutscene.py` (Cycles, voxel
  brainrots built from the sprites): Sammyni Fatini (walking legs, a growing red aura) and — the second hero, the
  owner's wish — the owner's own Roblox avatar (white R6 body, sleepy face, «Zzz...» sleep mask, spiky white hair,
  «i love sleep» tee, grey plaid pyjama pants; textures in `scripts/blender/avatar/`, Zs float from his head until the
  snap wakes him) walk the red carpet side by side; the crowd each dance their own way (hop, headbang, sway, spin,
  shuffle, bounce) and turn to watch them pass; the snap at frame 181 = `SNAP_AT_SECONDS`, where the app plays
  `sfx.snap`. The app scores the walk itself (`sfx.snapScore`): a dark aura drone and a heavy footstep on each of
  Sammyni's steps (`STEP_SECONDS` in Events.tsx = the script's STRIDE: every 7.5 frames from frame 24), the charge
  hum after the walk. Headless Blender needs `libegl1` (apt) in this container; a full render is ~50 min.
- Speed: index.html starts `/api/me` and `/api/catalog` before the JS arrives (`window.__boot`, used once by `api()`);
  the catalog doesn't wait for the profile; the bottom bar's pages ship with the app and every other page is a lazy
  chunk prefetched when the app is idle (`LOADERS` in `App.tsx`); `buildMe` is one SQL round trip (`ME_SQL`); the
  catalog's reads run in parallel; `public/_headers` caches hashed bundles for good and pictures for an hour (SWR);
  every API answer carries `Server-Timing` (app / db with query count / connect).
- «Розыгрыши» (`#/giveaways`, `#/giveaways/<id>`, `server/giveaways.ts`, rules in `shared/giveaways.ts`, admin
  «Розыгрыши», tables `giveaways`, `giveaway_prizes|entries|winners`): admins make a «Гонка пополнений» (score = net
  deposits in the period: Stars + brainrot deposits − done withdrawals), a «Гонка приглашений» (friends bound in the
  period whose own net deposits reach the threshold, ≥ 10 B) or a «Розыгрыш» (join button; random winners among those
  who meet the deposit threshold and, if set, the free-case channel subscription — rechecked at the draw). Banner,
  title, description, conditions, start/end (MSK), 1–10 places with a catalog brainrot each (brainrots only, straight
  to the inventory). Top-5 leaderboard with the place's prize on the row (#1 highlighted), my place, winners. Staff
  (owners, admins) and banned/frozen players never place — an admin credits deposits himself. The minute tick
  settles giveaways at their end (row lock: once), bot message to the winners, `giveaways` live topic. A giveaway can
  also ask for a brainrot deposit of a given brainrot (`need_brainrot`, `need_brainrot_count`; must be in the deposit
  list): credited brainrot deposits in the period, checked on join, in the races and again at the draw — or (iteration 39,
  the owner: «чтоб пополнившие через крипту и звёзды тоже входили») Stars/crypto deposits in the period worth count × the
  brainrot's deposit price (`brainrotOk`, `broughtEnough`). Race scores and draw thresholds always counted Stars and
  crypto (`star_payments.credited`).
- Partner code at deposit (iteration 35): the deposit sheet's «Промокод или код партнёра» takes the 2-hour auto code OR
  a player's referral code (`resolveDepositPromo` in `server/depositPromo.ts`, live check `GET /api/deposit-promo`).
  A partner code binds the payer to that partner (`bindReferral`, same rules: once, forever, no self/loop; another
  partner's player is refused with that partner's code) and gives +15 % (`PARTNER_DEPOSIT_PERCENT`) on **Stars only**
  (`star_orders.partner_id`, paid only while still bound) — brainrot deposits are refused, they can be cycled out again.
  The partner earns the usual level percent of the deposit (`payDepositShare`), nothing extra.
- Case badges (iteration 35, `cases.badge` new|redesign + `badge_until`, 3 days): a new case gets «НОВЫЙ», a changed
  picture/name/composition «РЕДИЗАЙН» (unless a fresh «НОВЫЙ» runs); the case editor can force Авто / Новый / Редизайн /
  Нет. Card ribbon + halo, a badge on the case page.
- Floating price (iteration 35, «Биткоин» 10 000 / 5 000 / 799 / 99 B, art `scripts/blender/ticket_cases.py
  --only=bitcoin`): `cases.price_cycle` + `price_next_at`; the tick's `rotateFloatingPrices` (`server/floatingPrice.ts`)
  moves the price every 5–10 min to another value of the cycle, keeps `case_price_history` (chart + ▲/▼ on the card and
  the page) and broadcasts the catalog. The healer composes such a case for EVERY price of its cycle. Never in battles
  (both stakes must be equal: `floating_price`, the picker hides them). An opening sends `expectedPrice`; a moved price
  is refused (`price_changed`) instead of charging the new one.
- Safe openings (iteration 35): every case opening carries the app's `requestId`; the result is stored in
  `case_open_results` in the same transaction, so a repeat returns it instead of opening twice and an answer lost on the
  way («Что-то пошло не так») is recovered with `GET /api/case/opened/:requestId` (the tick deletes them after a day).
  `me.rev` (the database's clock when the profile was read) — the app never replaces its profile with an older one, so a
  late poll can't bring a spent brainrot back («этого брейнрота нет в инвентаре»).
- Economy guard: cashback and RevShare count only `HOUSE_GAMES` (case, battle) — the upgrader keeps 20 % (`UPGRADE_RTP`),
  dice already keeps ~23 % (1 match x2, 4 matches x3, else lose: 77 % RTP) and crash at high multipliers would turn a
  loss rebate into profit. Keep it that way.
- «Raining Tacos» (`TacosRain.tsx`, `src/lib/tacosMusic.ts`, settings `tacos` {enabled, endsAt}, admin «Ивенты» or
  «Щелчок»): while it runs, SVG tacos fall over every page (fixed layer under the header / bars / sheets, never takes a
  tap, off with reduced motion) and the owner's track `public/events/raining-tacos.mp3` plays by itself everywhere —
  nobody has to switch it on (the owner's wish). Browsers may refuse sound before the first touch: then it starts on
  the first tap anywhere. It waits for the snap cutscene's card, follows the app's sound switch, pauses in the
  background; the tacos square of the events row mutes it (`brainrotcrash:tacos-muted`). The owner had the old disco
  page removed («вечеринку убери, просто ивент»): `#/tacos` lands home; `server/tacos.ts` (`/api/tacos`, the golden
  taco catch, 5 % of 5 B, capped) is left unused.
- Site announcement (owner-only, admin «Рассылка» → «Сообщение на сайте»): settings `announcement`
  {text, authorName, authorPhoto, at} — the posting owner's Telegram name and photo; rides with `/api/catalog`, so it
  appears live in every open app as `AnnouncementBanner` under the header; each device hides it by its `at`
  (`brainrotcrash:announce-seen`), a new one shows again; empty text clears it. Not the bot broadcast.
- «Бонусы» (`server/bonuses.ts`): bonus cases `kind='bonus'` — `referral` (a key right on binding — the owner's
  explicit choice, don't move it back to the deposit; iteration 38: ONCE per account, «хоть миллион позовет»: at the
  account's first referral link — bound to someone, or its first friend, whichever comes first (`hadReferralCase` in
  `server/referrals.ts`); migration `ref_once` trimmed the unopened extras, what it took is in `ref_case_trim`) and `nick` (name ends with «@BrainrotCrash», any case — `NICK_TAG`, getChat on every open, 12 h);
  weekly cashback on net loss (cases, battles) at the brainrot rank's percent (3–8 %, `cashbackPercent` in
  `server/ranks.ts`), collected on Fridays (MSK) only — every finished week not collected
  yet, up to 4 back (`not_friday` otherwise); consolation spin (coins 1–30) after losing an upgrade with stake ≥ 300,
  once a day.
- 18+ (iteration 31; TERMS_VERSION 2 since iteration 36 — the wagering clause; a player who had accepted an older one
  sees «Соглашение обновлено» on the consent screen, `me.user.termsUpdated`): `users.terms_version` must be ≥ `TERMS_VERSION` (`shared/legal.ts`), else `assertActive` refuses
  every action with 403 `terms_required` and the app shows `ConsentScreen` (two checkboxes: 18+ and the documents)
  before anything else; `POST /api/legal/accept {adult: true, version}`. The texts are in `src/lib/legalDocs.ts`
  (`#/terms`, `#/privacy`, linked from Настройки and the bot's /terms) — a change players must accept again = a new
  `TERMS_VERSION`. They are templates written for the owner: a lawyer should check them. The privacy policy promises
  other players see only the Telegram name, photo and the public ID — keep it true (that is why the rank is not on the
  public profile).
- «Не в минус» — every bonus is paid out of the house's edge (12 % on cases/battles/upgrader), never from deposits:
  no coin bonus for depositing (multi-accounts would cycle it); the one deposit-linked reward is the weekly quest's
  70 tickets (≈ 8 B, 0.8 %) on the week's NET deposits, so bringing brainrots in and out again pays nothing. Brainrot ranks (`shared/ranks.ts`, `#/ranks`, opened
  from the profile's rank block — not in the menu since iteration 32): from everything ever deposited — Обычный 0 /
  Редкий 500 / Эпический 2 500 / Легендарный 10 000 / Мифический 25 000 / Brainrot God 75 000 / Секретный 250 000 B
  (the owner asked for easier ranks and more coins); cashback 3 → 8 % of net loss; a one-time gift (15 / 60 / 250 / 600 /
  1 800 / 6 000 B as a brainrot, `rank_gifts`) only after `RANK_GIFT_TURNOVER` (2) × the threshold played in cases and
  battles. The rank shows in the profile (with the way to the next one), «Бонусы», the admin player card and the admin
  withdrawal queue.
- Quests and tickets (iteration 32; `shared/quests.ts`, `server/quests.ts`, `#/quests`): every MSK day 3 new daily
  quests, every week 4 weekly ones, the same for everybody — built by `buildQuestSet` from templates and the paid cases
  (open case X N times, N games from S B, turnover in a game, net deposit 1 000 B of the week, a friend who played 300 B,
  daily quests on 5 days) and stored in `quest_sets` on first read, so catalog edits never change a running set. They
  pay **tickets** (`users.tickets`, `quest_claims.currency = 'tickets'`; older coin claims stay): 30 % of the house edge
  on the turnover asked for — 0.3 ticket per 1 B in the 12 % games, 0.15 in mines/road (a ~77 B case once = 23, like the
  owner's reference screenshots). Only paid stakes count. A ticket costs the house ≈ 0.12 B (`TICKET_VALUE`).
- Ticket cases (`cases.kind = 'tickets'`, `cases.ticket_price`; theme «Бесплатные»): «Затмение» 119 tickets (10 B coins
  68 %, 15 B coins 17 %, ≈30 / 40 / 50 B brainrots 10 / 4 / 1 %) and «Кенди» 240 (≈18 / 25 / 35 / 45 / 60 B brainrots
  35 / 30 / 20 / 10 / 5 %), hand-set chances, brainrots picked by price when the migration ran. Opened for tickets only,
  one at a time (`no_tickets`), never in battles, ×3/×5, quests or cashback (the drop has stake 0 and `meta.tickets`);
  the healer skips them. The owner also asked for «крутые брейнроты» with chance «Невозможно» inside: they are there
  (the three dearest brainrots, fixed 0) and, like every zero-chance item, players don't see them — showing a prize
  that can't drop would mislead (same line as the FUSE decoration refusal). Art: `scripts/blender/ticket_cases.py`
  → `public/cases/eclipse|candy.webp`. «Экономика» shows tickets handed out and what ticket cases really dropped.
- The Meowl tour (iteration 32; `src/components/Tour.tsx` — a lazy chunk —, state in `src/store/tour.ts`, Meowl in
  `Meowl.tsx` + `src/styles/meowl.css`): after the 18+ screen a new player (`users.onboarded_at` NULL; players who had
  already played were marked done by the migration) gets Meowl's offer «Пройти обучение / Пропустить»; the tour starts
  with «Бонусы» → the free case and waits until the player really opens it («Пропустить шаг» is always there and goes
  on to the case grid; «Вернуться к кейсу» if they left the page), then the case grid, the upgrader, quests and
  tickets, referrals, the profile (rank, inventory, withdrawals) and the balance «+». Each step spotlights its
  `data-tour` anchor (scrolled low into the band between the header and the bottom bar/disc/events row, Meowl on the
  bigger free side; only the bubble takes taps, so he never blocks a button), Meowl's line is typed with `sfx.type`
  while he talks; the close button is on every step. Done or
  skipped → `POST /api/onboarding`; Настройки → «Обучение с Meowl» replays it. Meowl is a voxel model from the sprite
  rendered in layers by `scripts/blender/meowl.py` (`public/meowl/*.webp`: body with a «ω» smile and blush, blink and
  talk overlays, two wings; pivots in `src/lib/meowl-layout.json`): CSS breathes, sways, flaps, blinks and moves the
  mouth (transform/opacity only, still with reduced motion).
- «Поделиться» after a win (case win card, upgrader win; `ShareWin.tsx`, `POST /api/share/win`): a prepared message
  with the brainrot's JPEG card (`public/share/brainrots/*.jpg` from `scripts/gen_share_cards.py`; uploads get
  `promo/share.jpg`) and «Играть» on the player's referral link; only the latest win of the last 15 minutes, 5 per
  10 minutes (`win_shares`).
- Owner-only «Экономика» (`economyReport`) and «Источники» (`traffic_sources`, `source_clicks`, `users.source`) in the
  admin. Источники: links `t.me/braincrashbot?start=s-<tag>`; a click counts once per player, a player belongs to the
  source only if that /start created them (within 10 min). Экономика: 7 / 30 days / all time — stars, deposits,
  withdrawals, played, what the games kept, every bonus (incl. admin gifts at catalog prices) — and the verdict: all-time
  deposits − done withdrawals − what players hold now (coins, referral balances, brainrots at catalog prices). Above
  zero = no bonus cost more than it brought.
- Anti-spam (iteration 33, `server/rateLimit.ts`): every non-GET action of a signed-in player goes through
  `rateLimit('act:<id>', ACTION_LIMIT)` in the router — 8 actions a second, then 429 `too_fast` «Не спамь — подожди
  N сек.»; player search 10 per 10 s. The counter lives in the Worker isolate's memory (cheap, no DB), so it stops
  bursts on one isolate, not a determined spread across several — the money paths keep their own row locks. `api()`
  holds the same 8/s on the client (no request is sent), and the toaster drops a toast whose text is already showing.
  Tests turn it off with `RATE_LIMIT=off` (the anti-spam test freezes `Date.now`).
- «Конфиги кейсов» (admin Кейсы, `server/caseConfigs.ts`, table `case_configs`, Worker-applied migration
  `case_configs`): «Сохранить текущий» stores every case (price, ticket price, kind, status, theme, order, mystery),
  the compositions with hand-set chances, the themes, the coin prizes and the brainrot prices as one JSONB; «Загрузить»
  first saves an automatic copy («Автокопия перед …», the last 10 are kept), then upserts it all set-based under the
  healer's advisory lock; cases newer than the config are hidden, never deleted; brainrot prices come back only with
  the checkbox (they move upgrades, withdrawals and inventories); brainrots deleted since are skipped and counted; then
  the healer runs, as after any admin save (a case that no longer fits today's prices is completed at once).
  Max 60 named configs; every save/load/delete is in `admin_log`.
- Staff are not players (iteration 33): `notStaff(col)` (`server/staff.ts`: not in `admins`, not an owner) keeps admins
  and owners out of the LIVE strip, «Топ дроп дня», player search, the admin stats (players, active, coins held) and
  «Экономика» (played, house result, holdings, admin gifts to staff). They still play everything for tests; their
  own history, profile and inventory are untouched.
- Режим стримера (Настройки, `src/store/streamer.ts`, `src/styles/streamer.css`, device-local
  `brainrotcrash:streamer`): blurs the streamer's OWN private things — balance and history, deposit/withdraw buttons
  (also stop taking taps), own stakes, the profile ID and @username — with a static blur (Слабо / Средне / Сильно) and
  «показывать под курсором» (hover un-blurs on a PC). Mark a new private element with `data-private="balance|money|
  stakes|account"`. Deliberately NOT done (the competitor's screenshot had them): trigger-word filters, hiding the case
  spin, blurring case art, hiding prices/amounts — those exist to slip gambling past TikTok/YouTube moderation in front
  of a mostly underage audience. Don't add them.
- Titles: a tap on a title icon opens a card anchored under it (`TitleBadges` in `TitleBadge.tsx`, portalled into the
  open `<dialog>` or body): picture, name, description, «Получен», «Редкость» = share of all players holding it
  (`percent` from `PERCENT_SQL` in `server/me.ts`; «Единственный в игре», «меньше чем у 1%»), «Поделиться».
- «Найти игрока» on the profile (`GET /api/players/search?q=`, `searchPlayers` in `server/players.ts`): ≥ 2 characters,
  by public ID, the exact @username or part of the Telegram name; staff never show; the answer carries only the public
  ID, name and photo (never the username) — the privacy policy says so. A result opens the public profile.
- Background music (`src/lib/bgMusic.ts`, `public/music/`): a CC0 playlist from OpenGameArt — «The Arplands»
  (LordZintick) and «Champloo Loop» (omfgdude), volume 0.28 — starts on the first tap and loops forever; its own switch
  in Настройки («Фоновая музыка», `brainrotcrash:music`, on by default); silent when the app's sounds are off, the page
  is hidden, the Snap cutscene plays or Raining Tacos is audible. New tracks must be CC0 / free for commercial use.
- Every button/tab/switch press gets a soft click + haptic (`src/lib/feedback.ts`); crash reaches x2 in 8 s.
- GitHub Pages is not an option: the app needs the server (DB, payments, webhook). Production is Cloudflare + Supabase
  (Netlify's free credits ran out).
- Local full stack: `node scripts/local-dev.mjs` (in-memory Postgres, fake bot API) applies every migration, so it
  mirrors production's catalog and cases; `SEED_ONLY=1` gives the seed lineup instead (what the e2e scripts expect). `server/api.test.ts` applies schema + seed only (skips `*_admin_snapshot.sql`):
  the owner reshapes production at will (he deleted most seed cases), the tests keep the stable seed lineup.
- Never commit the bot token or any Cloudflare/Supabase credentials; the token lives only in the Worker secret `BOT_TOKEN`.
