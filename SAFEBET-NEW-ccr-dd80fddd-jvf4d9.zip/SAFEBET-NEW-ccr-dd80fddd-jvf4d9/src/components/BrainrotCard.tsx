import type { ReactNode } from 'react';
import { Coin } from './Coin';
import type { Brainrot } from '../../shared/types';
import { cx, formatCoins } from '../lib/format';
import { TIER_LABEL, tierOf } from '../lib/tier';
import { DemoTag } from './DemoTag';

interface Props {
  brainrot: Brainrot;
  selected?: boolean;
  disabled?: boolean;
  muted?: boolean;
  meta?: ReactNode;
  /** A corner mark, e.g. the pick order «1…5» or «НА ВЫВОДЕ». */
  badge?: ReactNode;
  /** «ДЕМО»: an admin's demo gift or a demo game's win — plays, never leaves the game. */
  demo?: boolean;
  onClick?: () => void;
}

export function BrainrotCard({ brainrot, selected, disabled, muted, meta, badge, demo, onClick }: Props) {
  const tier = tierOf(brainrot.price);
  return (
    <button
      type="button"
      className={cx('bcard', `tier-${tier}`, selected && 'is-selected', muted && 'is-muted', demo && 'is-demo')}
      aria-pressed={selected}
      disabled={disabled}
      onClick={onClick}
    >
      <span className="bcard__art">
        <img src={brainrot.image} alt="" loading="lazy" decoding="async" />
        {demo && <DemoTag corner />}
      </span>
      <span className="bcard__name">{brainrot.name}</span>
      <span className="bcard__price">
        <Coin size={14} />
        {formatCoins(brainrot.price)}
      </span>
      <span className="visually-hidden">{TIER_LABEL[tier]}</span>
      {meta && <span className="bcard__meta">{meta}</span>}
      {badge && <span className="bcard__badge">{badge}</span>}
    </button>
  );
}

export function BrainrotThumb({ brainrot, size = 40 }: { brainrot: Brainrot; size?: number }) {
  return (
    <span className={cx('bthumb', `tier-${tierOf(brainrot.price)}`)} style={{ width: size, height: size }}>
      <img src={brainrot.image} alt="" decoding="async" />
    </span>
  );
}
