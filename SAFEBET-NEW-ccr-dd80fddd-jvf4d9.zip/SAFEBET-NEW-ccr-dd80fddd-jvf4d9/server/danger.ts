import type { Viewer } from './auth';
import { ensureSchema } from './autoMigrate';
import { num, one, q, tx, type Queryable } from './db';
import { env, isOwnerId } from './env';
import { HttpError, bad, forbidden } from './errors';
import { broadcast, touch } from './live';
import { notStaff } from './staff';
import { displayName, resolveUser } from './users';
import { str, type Body } from './validate';

/**
 * «Опасная зона» of the admin panel: reset one player or wipe every player's game state. Owners only, and every
 * call carries the password from the Worker secret WIPE_PASSWORD (never in the code). Payment ledgers (Stars
 * payments, brainrot deposits) and completed withdrawals stay: they are records of real money and real items.
 */

const MAX_TRIES = 5;
const LOCK_MINUTES = 15;
/** Typed by the owner before a full wipe, on top of the password. */
export const WIPE_PHRASE = 'СТЕРЕТЬ ВСЁ';

async function sha256(text: string): Promise<Uint8Array> {
  return new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text)));
}

/** Compares digests, so the time taken says nothing about how much of the password was right. */
async function samePassword(given: string, expected: string): Promise<boolean> {
  const [a, b] = await Promise.all([sha256(given), sha256(expected)]);
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a[i]! ^ b[i]!;
  return diff === 0;
}

async function checkPassword(admin: Viewer, body: Body) {
  if (!admin.isOwner) throw forbidden('Опасная зона — только для владельцев');
  const expected = env('WIPE_PASSWORD');
  if (!expected) throw new HttpError(503, 'danger_off', 'Опасная зона выключена: на сервере не задан пароль');
  const given = typeof body.password === 'string' ? body.password : '';
  // Count, compare and record one try at a time per owner: parallel requests can't slip past the lock.
  const verdict = await tx(async (c) => {
    await c.query(`SELECT pg_advisory_xact_lock(hashtext('danger:' || $1::text))`, [admin.id]);
    const tries = await c.query<{ n: string }>(
      `SELECT count(*) AS n FROM admin_log WHERE admin_id = $1 AND action = 'danger_denied' AND created_at > now() - interval '${LOCK_MINUTES} minutes'`,
      [admin.id],
    );
    if (num(tries.rows[0]?.n) >= MAX_TRIES) return 'locked' as const;
    if (given && (await samePassword(given, expected))) return 'ok' as const;
    await c.query(`INSERT INTO admin_log (admin_id, action, target_user, details) VALUES ($1, 'danger_denied', NULL, '{}'::jsonb)`, [admin.id]);
    return 'wrong' as const;
  });
  if (verdict === 'locked') throw new HttpError(429, 'danger_locked', `Слишком много неверных паролей — подожди ${LOCK_MINUTES} минут`);
  if (verdict === 'wrong') throw new HttpError(403, 'wrong_password', 'Неверный пароль');
}

/** Open withdrawals are closed first: their brainrots are locked against deletion until then. */
const OPEN_WITHDRAWALS = `status IN ('pending', 'scheduled', 'trading', 'expired')`;

/** These players' (or, with null, every player's) coins, items, history and game state; the accounts stay. */
async function wipe(c: Queryable, userIds: number[] | null) {
  const only = (col: string) => (userIds === null ? '' : `WHERE ${col} = ANY($1::bigint[])`);
  const and = (col: string) => (userIds === null ? '' : `AND ${col} = ANY($1::bigint[])`);
  const p = userIds === null ? [] : [userIds];
  const count = async (sql: string) => (await c.query(sql, p)).rowCount ?? 0;
  const out = {
    withdrawals: await count(
      `UPDATE withdrawals SET status = 'cancelled', note = 'Обнулено администрацией', updated_at = now() WHERE ${OPEN_WITHDRAWALS} ${and('user_id')}`,
    ),
    items: 0,
    history: 0,
  };
  await c.query(`UPDATE inventory SET withdrawal_id = NULL WHERE withdrawal_id IS NOT NULL ${and('user_id')}`, p);
  out.items = await count(`DELETE FROM inventory ${only('user_id')}`);
  await count(`DELETE FROM withdrawals WHERE status <> 'done' ${and('user_id')}`);
  out.history = await count(`DELETE FROM drops ${only('user_id')}`);
  for (const table of [
    'crash_rounds',
    'case_keys',
    'cashback_claims',
    'consolations',
    'item_exchanges',
    'free_shares',
    'auto_promo_uses',
    'halloween_seeds',
    'trick_seeds',
    'fuse_seeds',
    'road_seeds',
    'road_runs',
    'mines_seeds',
    'mines_runs',
    'giveaway_entries',
    // Claimed quests: the progress comes from the drops wiped above, so the running quests start over too.
    'quest_claims',
    'win_shares',
    // «Небо Meowl» and «Игра Кальмара» (iteration 35): who flew / played and what they picked up.
    'sky_picks',
    'sky_players',
    // Claimed battle pass rewards are game state; BPlus purchases (paid Stars) stay.
    'pass_claims',
    'squid_players',
  ]) {
    await c.query(`DELETE FROM ${table} ${only('user_id')}`, p);
  }
  await c.query(`DELETE FROM ref_payouts ${only('referrer_id')}`, p);
  // ref_milestones and rank_gifts stay: a threshold already paid (ranks come from deposits, which stay) never pays twice.
  // A battle is shared history: a reset player loses only the ones nobody joined yet.
  await c.query(userIds === null ? 'DELETE FROM battles' : `DELETE FROM battles WHERE status = 'waiting' AND creator_id = ANY($1::bigint[])`, p);
  // Players' own promo codes were paid from the coins being wiped.
  await c.query(`DELETE FROM promo_codes WHERE owner_id IS NOT NULL ${and('owner_id')}`, p);
  await c.query(
    `UPDATE users SET balance = 0, ref_balance = 0, ref_carry = 0, tickets = 0, cases_opened = 0, upgrades = 0, dice_rolls = 0, crash_rounds = 0,
       withdrawn_value = 0, wager_left = 0, wager_total = 0, free_case_at = NULL, free_share_at = NULL, nick_case_at = NULL, free_notified_at = NULL ${only('id')}`,
    p,
  );
  return out;
}

export async function resetPlayer(admin: Viewer, body: Body) {
  await checkPassword(admin, body);
  // The tables of the Worker-applied migrations (tickets, quests) must exist before the wipe touches them.
  await ensureSchema();
  const user = await resolveUser(body.user);
  const id = num(user.id);
  if (isOwnerId(id) && id !== admin.id) throw forbidden('Владельца может обнулить только он сам');
  const result = await tx(async (c) => {
    const r = await wipe(c, [id]);
    await c.query(`INSERT INTO admin_log (admin_id, action, target_user, details) VALUES ($1, 'danger_reset', $2, $3::jsonb)`, [
      admin.id,
      id,
      JSON.stringify(r),
    ]);
    return r;
  });
  touch(id, 'me', 'withdrawal', 'bonuses', 'battles');
  broadcast('battles');
  return { user: { id, display: displayName(user) }, ...result };
}

export async function wipeAllPlayers(admin: Viewer, body: Body) {
  await checkPassword(admin, body);
  // The tables of the Worker-applied migrations (tickets, quests) must exist before the wipe touches them.
  await ensureSchema();
  if (str(body.confirm, 'подтверждение', 1, 40) !== WIPE_PHRASE) throw bad('invalid', `Впиши «${WIPE_PHRASE}» для подтверждения`);
  const result = await tx(async (c) => {
    // Nothing else may touch balances while they are being zeroed.
    await c.query('LOCK TABLE users, inventory IN SHARE ROW EXCLUSIVE MODE');
    const players = await c.query<{ n: string }>('SELECT count(*) AS n FROM users');
    const r = { players: num(players.rows[0]?.n), ...(await wipe(c, null)) };
    await c.query(`INSERT INTO admin_log (admin_id, action, target_user, details) VALUES ($1, 'danger_wipe', NULL, $2::jsonb)`, [admin.id, JSON.stringify(r)]);
    return r;
  });
  // Every open app refetches its profile.
  broadcast('me', 'battles', 'bonuses', 'withdrawal');
  return result;
}

/** Players (staff aside) who picked up an egg in «Небо Meowl», with what the eggs gave them. */
const EGG_PLAYERS_SQL = `
  SELECT u.id, u.first_name, u.last_name, u.username, sum(p.eggs) AS eggs
  FROM sky_players p JOIN users u ON u.id = p.user_id
  WHERE p.eggs > 0 AND ${notStaff('u.id')}
  GROUP BY u.id ORDER BY sum(p.eggs) DESC, u.id`;

type EggRow = { id: string; first_name: string; last_name: string | null; username: string | null; eggs: string };

/**
 * «Обнулить всех с яйцом» (iteration 38, the owner): every player who picked up an egg in «Небо Meowl» is reset like
 * «Обнулить игрока» — one set-based wipe in one transaction. The panel lists them first.
 */
export async function resetEggPlayers(admin: Viewer, body: Body) {
  await checkPassword(admin, body);
  await ensureSchema();
  const result = await tx(async (c) => {
    const rows = (await c.query<EggRow>(EGG_PLAYERS_SQL)).rows;
    const ids = rows.map((r) => num(r.id));
    if (!ids.length) throw bad('nobody', 'Никто из игроков не подбирал яйцо');
    const r = { players: ids.length, ...(await wipe(c, ids)) };
    await c.query(`INSERT INTO admin_log (admin_id, action, target_user, details) VALUES ($1, 'danger_reset_eggs', NULL, $2::jsonb)`, [
      admin.id,
      JSON.stringify({ ...r, ids }),
    ]);
    return { ...r, ids };
  });
  for (const id of result.ids) touch(id, 'me', 'withdrawal', 'bonuses', 'battles');
  broadcast('battles');
  return { players: result.players, items: result.items, history: result.history };
}

/** What the panel shows before anything is pressed. */
export async function dangerInfo(admin: Viewer) {
  if (!admin.isOwner) throw forbidden('Опасная зона — только для владельцев');
  await ensureSchema();
  const [last, eggs] = await Promise.all([
    one<{
      created_at: string;
      details: Record<string, unknown>;
    }>(`SELECT created_at, details FROM admin_log WHERE action = 'danger_wipe' ORDER BY id DESC LIMIT 1`),
    q<EggRow>(EGG_PLAYERS_SQL),
  ]);
  return {
    enabled: !!env('WIPE_PASSWORD'),
    phrase: WIPE_PHRASE,
    lastWipe: last ? { at: new Date(last.created_at).getTime(), details: last.details } : null,
    /** Who would be reset by «Обнулить всех с яйцом». */
    eggPlayers: eggs.map((r) => ({ id: num(r.id), name: displayName(r), eggs: num(r.eggs) })),
  };
}
