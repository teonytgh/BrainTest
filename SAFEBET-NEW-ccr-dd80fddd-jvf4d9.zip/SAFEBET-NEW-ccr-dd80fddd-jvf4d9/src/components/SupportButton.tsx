import { Icon } from './Icon';
import { SUPPORT_URL } from '../../shared/links';
import { openTelegramLink } from '../lib/telegram';
import { useRoute, type RouteName } from '../lib/router';

/** Pages without a sticky action bar at the bottom: the chat button never covers a game's main button there. */
const SHOWN_ON: readonly RouteName[] = ['home', 'profile', 'quests', 'bonuses', 'referrals', 'faq', 'ranks', 'giveaways', 'pass'];

/** Tech support (iteration 37): a round chat button in the corner that opens the support bot. */
export function SupportButton() {
  const route = useRoute();
  if (!SHOWN_ON.includes(route.name)) return null;
  return (
    <button type="button" className="support-fab" aria-label="Техподдержка" title="Техподдержка" onClick={() => openTelegramLink(SUPPORT_URL)}>
      <Icon name="chat" size={26} />
    </button>
  );
}
