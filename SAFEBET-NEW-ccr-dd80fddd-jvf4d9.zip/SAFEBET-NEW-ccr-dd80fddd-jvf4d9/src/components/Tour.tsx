import { useEffect, useState } from 'react';
import { Icon } from './Icon';
import { Meowl } from './Meowl';
import { act, setMe, useMe } from '../api/queries';
import { FREE_CASE_COOLDOWN_MS } from '../../shared/types';
import { formatCountdown } from '../lib/format';
import { navigate, useRoute, type RouteName } from '../lib/router';
import { sfx } from '../lib/sound';
import { useStore } from '../store/createStore';
import { closedHere, goTo, markClosed, save, saved, tour } from '../store/tour';

/**
 * The first-visit tour with Meowl (iteration 32). A new player (after the 18+ screen) is offered it once; it starts
 * with the free case — the player opens it for real — then walks through the sections with a spotlight on each and
 * Meowl's typed explanations. Closing it at any step is always possible; done or skipped, the server remembers
 * (`users.onboarded_at`) and it never starts by itself again. Настройки → «Обучение с Meowl» replays it.
 */

interface Step {
  id: string;
  /** Where the step takes place (the tour goes there). */
  route?: [RouteName, string?];
  /** data-tour anchors lit together (the spotlight covers all that are on screen). */
  targets?: string[];
  text: string;
  /** The button; a step without one waits for the player (the free case). */
  next?: string;
  /** Steps to jump on «Пропустить шаг» (a waiting step can always be skipped). */
  skip?: number;
}

const STEPS: Step[] = [
  {
    id: 'bonuses',
    route: ['bonuses'],
    targets: ['free-case'],
    text: 'Начнём с подарка! В «Бонусах» каждые 12 часов ждёт бесплатный кейс. Жми на него — откроем вместе 👇',
    next: 'К бесплатному кейсу',
  },
  {
    id: 'free',
    route: ['case', 'free'],
    targets: ['free-gate', 'free-open'],
    // Past «Ура, первый дроп» too: nothing was won.
    skip: 2,
    text: 'Подпишись на канал и жми «Поделиться и открыть» — кейс откроется сразу! 🎁',
  },
  {
    id: 'won',
    text: 'Ура, первый дроп! 🎉 Монеты сразу падают на баланс, брейнроты — в инвентарь: их можно продать, поставить в апгрейд или вывести в Roblox.',
    next: 'Дальше',
  },
  {
    id: 'cases',
    route: ['home'],
    targets: ['case-grid'],
    text: 'Здесь все кейсы. Шансы честные: исход решает сервер в момент открытия, а редкие брейнроты правда выпадают — смотри ленту LIVE.',
    next: 'Дальше',
  },
  {
    id: 'upgrader',
    route: ['upgrader'],
    targets: ['nav-upgrader'],
    text: 'Апгрейдер: поставь до 5 брейнротов и рискни забрать брейнрота дороже. Шанс на экране — ровно тот, с которым крутится стрелка.',
    next: 'Дальше',
  },
  {
    id: 'quests',
    route: ['quests'],
    targets: ['tickets'],
    text: 'Каждый день — новые задания. За них дают тикеты, а за тикеты открываются бесплатные кейсы «Затмение» и «Кенди».',
    next: 'Дальше',
  },
  {
    id: 'refs',
    route: ['referrals'],
    targets: ['refs'],
    text: 'Зови друзей по своей ссылке: другу — реферальный кейс (тебе тоже, один раз на аккаунт), а тебе до 15% с каждого их пополнения — сразу на баланс.',
    next: 'Дальше',
  },
  {
    id: 'profile',
    route: ['profile'],
    targets: ['rank'],
    text: 'Твой профиль. Ранг растёт с пополнениями — больше кэшбэк и подарки. Ниже инвентарь: брейнротов «в наличии» выводим трейдом прямо в Roblox.',
    next: 'Дальше',
  },
  {
    id: 'deposit',
    targets: ['balance'],
    text: 'Монеты пополняются звёздами Telegram или твоими брейнротами из Roblox — жми на баланс с «+».',
    next: 'Дальше',
  },
  {
    id: 'bye',
    text: 'Вот и всё! Заходи каждый день: бесплатный кейс, новые задания и розыгрыши. Удачи — мяу! 🐾',
    next: 'Начать играть',
  },
];

/** Types `text` out letter by letter with a key click; a tap shows the rest at once. Instant with reduced motion. */
function useTyping(text: string) {
  const reduce = typeof matchMedia === 'function' && matchMedia('(prefers-reduced-motion: reduce)').matches;
  const [n, setN] = useState(reduce ? text.length : 0);
  useEffect(() => setN(reduce ? text.length : 0), [text, reduce]);
  useEffect(() => {
    if (n >= text.length) return;
    const prev = text[n - 1] ?? '';
    const t = setTimeout(
      () => {
        setN(n + 1);
        if (text[n] !== ' ') sfx.type();
      },
      '.!?'.includes(prev) ? 260 : ',:—'.includes(prev) ? 120 : 26,
    );
    return () => clearTimeout(t);
  }, [n, text]);
  return { shown: text.slice(0, n), done: n >= text.length, finish: () => setN(text.length) };
}

interface Box {
  x: number;
  y: number;
  w: number;
  h: number;
}

/** The visible band between the header and whatever is fixed at the bottom (the bar, its raised disc, the events row). */
function freeBand(): { top: number; bottom: number } {
  const edge = (sel: string, side: 'top' | 'bottom') => {
    const r = document.querySelector(sel)?.getBoundingClientRect();
    return r && r.height > 0 ? r[side] : null;
  };
  const top = (edge('.topbar', 'bottom') ?? 0) + 8;
  const lows = ['.tabbar', '.tabbar__disc', '.ev-hud'].map((sel) => edge(sel, 'top')).filter((y): y is number => y !== null);
  return { top, bottom: Math.min(window.innerHeight, ...lows) - 8 };
}

/**
 * Brings the anchors into the band, low in it, so Meowl fits above and nothing fixed covers them (the upgrader disc
 * used to sit on «Открыть бесплатно» on short phones). Taller than the band: their top goes under the header.
 */
function scrollToFit(all: HTMLElement[]) {
  // The header and the bottom bar don't move with the page.
  const els = all.filter((e) => !e.closest('.topbar, .tabbar, .ev-hud'));
  if (!els.length) return;
  const rs = els.map((e) => e.getBoundingClientRect());
  const top = Math.min(...rs.map((r) => r.top));
  const bottom = Math.max(...rs.map((r) => r.bottom));
  const band = freeBand();
  const delta = bottom - top > band.bottom - band.top ? top - band.top : bottom - band.bottom;
  if (Math.abs(delta) > 4) window.scrollBy({ top: delta, behavior: 'smooth' });
}

/** The union of the step's anchors on screen, followed every frame (pages scroll, cards load in). */
function useSpot(targets: string[] | undefined, stepKey: string): Box | null {
  const [box, setBox] = useState<Box | null>(null);
  useEffect(() => {
    setBox(null);
    if (!targets?.length) return;
    let raf = 0;
    // How many anchors were on screen at the last fit: one that loads in later (the free case conditions) fits again.
    let fitted = 0;
    let last = '';
    const loop = () => {
      const els = targets.map((t) => document.querySelector<HTMLElement>(`[data-tour="${t}"]`)).filter((e): e is HTMLElement => !!e);
      if (els.length) {
        if (els.length > fitted) {
          scrollToFit(els);
          fitted = els.length;
        }
        const rs = els.map((e) => e.getBoundingClientRect());
        const x0 = Math.min(...rs.map((r) => r.left));
        const y0 = Math.min(...rs.map((r) => r.top));
        const x1 = Math.max(...rs.map((r) => r.right));
        const y1 = Math.max(...rs.map((r) => r.bottom));
        const next = { x: x0 - 6, y: y0 - 6, w: x1 - x0 + 12, h: y1 - y0 + 12 };
        const sig = `${Math.round(next.x)},${Math.round(next.y)},${Math.round(next.w)},${Math.round(next.h)}`;
        if (sig !== last) {
          last = sig;
          setBox(next);
        }
      } else if (last) {
        last = '';
        setBox(null);
      }
      raf = requestAnimationFrame(loop);
    };
    loop();
    return () => cancelAnimationFrame(raf);
    // The step decides the anchors.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [stepKey]);
  return box;
}

/** Hidden while something takes the whole screen: a case opening, a sheet, the snap cutscene. */
function useCovered(active: boolean) {
  const [covered, setCovered] = useState(false);
  useEffect(() => {
    if (!active) return;
    const check = () => setCovered(!!document.querySelector('.opening, dialog[open], .snap'));
    check();
    const t = setInterval(check, 300);
    return () => clearInterval(t);
  }, [active]);
  return covered;
}

const STEP_COUNT = STEPS.length;

export default function TourHost() {
  const me = useMe();
  const state = useStore(tour);
  const onboarded = me.user.onboarded;

  // A new player: offer the tour (or resume where a reload left it).
  useEffect(() => {
    if (onboarded || closedHere() || tour.get().active) return;
    goTo(saved(STEP_COUNT) ?? -1);
  }, [onboarded]);

  if (!state.active) return null;
  return state.step < 0 ? <Offer /> : <Guide key={state.step} step={state.step} />;
}

async function close() {
  markClosed();
  save(null);
  tour.set(() => ({ active: false, step: -1 }));
  try {
    const r = await act<{ ok: boolean }>('/api/onboarding');
    setMe(r.me);
  } catch {
    // Offline: the tour may be offered again next time — no harm.
  }
}

function Offer() {
  const text = 'Мяу! Я Meowl. Здесь выбивают брейнротов из Steal a Brainrot и выводят их прямо в Roblox. Показать, как всё устроено? Займёт минуту — и начнём с бесплатного кейса.';
  const typing = useTyping(text);
  useEffect(() => sfx.meow(), []);
  return (
    <div className="tour-offer" role="dialog" aria-modal="true" aria-labelledby="tour-offer-title">
      <div className="tour-offer__card">
        <Meowl size={172} talking={!typing.done} className="tour-offer__meowl" />
        <h2 id="tour-offer-title" className="tour-offer__title">
          Привет! Я Meowl
        </h2>
        <p className="tour__text" onClick={typing.finish}>
          <span aria-hidden="true">
            {typing.shown}
            {!typing.done && <span className="tour__caret" />}
          </span>
          <span className="visually-hidden">{text}</span>
        </p>
        <ul className="tour-offer__perks" aria-label="Что внутри">
          <li>🎁 Бесплатный кейс</li>
          <li>📦 Вывод в Roblox</li>
          <li>🎟 Задания каждый день</li>
        </ul>
        <div className="tour-offer__actions">
          <button
            type="button"
            className="btn btn--primary btn--lg btn--block"
            onClick={() => {
              sfx.coin();
              goTo(0);
            }}
          >
            Пройти обучение
          </button>
          <button type="button" className="btn btn--ghost btn--lg btn--block" onClick={() => void close()}>
            Пропустить
          </button>
        </div>
      </div>
    </div>
  );
}

function Guide({ step: index }: { step: number }) {
  const me = useMe();
  const route = useRoute();
  const step = STEPS[index]!;
  const freeAt = me.user.freeCaseAt;
  // The free case step: what the player's free case looked like when it began (undefined on other steps).
  const [freeAtStart, setFreeAtStart] = useState<number | null | undefined>(() => (step.id === 'free' ? freeAt : undefined));
  const cooling = step.id === 'free' && !!freeAtStart && freeAtStart + FREE_CASE_COOLDOWN_MS > Date.now() && freeAt === freeAtStart;
  const text = cooling
    ? `Бесплатный кейс ты уже открывал — следующий через ${formatCountdown(freeAtStart + FREE_CASE_COOLDOWN_MS - Date.now())}. Он ждёт тебя каждые 12 часов!`
    : step.text;
  const typing = useTyping(text);
  const spot = useSpot(step.targets, step.id);
  const covered = useCovered(true);
  const total = STEPS.length;

  // Entering a step: go to its page; remember the free case's state.
  useEffect(() => {
    if (step.route && (route.name !== step.route[0] || (step.route[1] ?? null) !== (route.param ?? null))) navigate(step.route[0], step.route[1]);
    setFreeAtStart(step.id === 'free' ? me.user.freeCaseAt : undefined);
    // Only on entering the step.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [index]);

  // «Бонусы»: tapping the free case card itself moves on.
  useEffect(() => {
    if (step.id === 'bonuses' && route.name === 'case' && route.param === 'free') goTo(index + 1);
  }, [route, step.id, index]);

  // The free case opened for real: on to «Ура» once the opening is closed.
  useEffect(() => {
    if (step.id !== 'free' || freeAtStart === undefined) return;
    if (freeAt && freeAt !== freeAtStart) goTo(index + 1);
  }, [freeAt, freeAtStart, step.id, index]);

  function next() {
    if (step.id === 'bonuses') {
      navigate('case', 'free');
      return;
    }
    if (index + 1 >= total) {
      sfx.coin();
      void close();
      return;
    }
    // The free case was already used: no «Ура» step.
    goTo(cooling ? index + 2 : index + 1);
  }

  // A waiting step whose page the player left: the way back.
  const away = !!step.route && !step.next && (route.name !== step.route[0] || (step.route[1] ?? null) !== (route.param ?? null));

  function skip() {
    goTo(Math.min(index + (step.skip ?? 1), total - 1));
  }

  if (covered) return null;
  // Meowl takes the bigger free side of the spotlight.
  const band = spot ? freeBand() : null;
  const place = spot && band && spot.y - band.top > band.bottom - (spot.y + spot.h) ? 'top' : 'bottom';
  const button = cooling ? 'Дальше' : step.next;
  return (
    <>
      {spot ? (
        <div className="tour-spot" style={{ transform: `translate(${spot.x}px, ${spot.y}px)`, width: spot.w, height: spot.h }} aria-hidden="true" />
      ) : step.targets ? null : (
        <div className="tour-shade" aria-hidden="true" />
      )}
      <div className={`tour tour--${place}`} role="dialog" aria-label="Обучение с Meowl" aria-live="polite">
        <Meowl size={96} talking={!typing.done} className="tour__meowl" />
        <div className="tour__bubble" onClick={typing.done ? undefined : typing.finish}>
          <div className="tour__head">
            <span className="tour__name">Meowl</span>
            <span className="tour__steps">
              {index + 1} / {total}
            </span>
            <button type="button" className="tour__close" aria-label="Закончить обучение" onClick={() => void close()}>
              <Icon name="close" size={18} />
            </button>
          </div>
          <p className="tour__text">
            <span aria-hidden="true">
              {typing.shown}
              {!typing.done && <span className="tour__caret" />}
            </span>
            <span className="visually-hidden">{text}</span>
          </p>
          <div className="tour__actions">
            {button ? (
              <button type="button" className="btn btn--primary btn--sm" onClick={next} disabled={!typing.done}>
                {button}
              </button>
            ) : (
              <>
                {away ? (
                  <button type="button" className="btn btn--primary btn--sm" onClick={() => navigate(step.route![0], step.route![1])}>
                    Вернуться к кейсу
                  </button>
                ) : (
                  <span className="tour__wait" aria-label="Жду, пока откроешь кейс">
                    <i /> Жду…
                  </span>
                )}
                <button type="button" className="btn btn--ghost btn--sm tour__skip" onClick={skip}>
                  Пропустить шаг
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    </>
  );
}
