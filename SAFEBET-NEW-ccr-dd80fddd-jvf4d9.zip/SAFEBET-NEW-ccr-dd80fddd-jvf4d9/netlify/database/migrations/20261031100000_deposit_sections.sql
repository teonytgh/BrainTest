-- The deposit picker gets tabs: «Брейнроты» and «Гирсы». Admins move list entries between them.
ALTER TABLE deposit_items ADD COLUMN section TEXT NOT NULL DEFAULT 'brainrots' CHECK (section IN ('brainrots', 'gears'));
