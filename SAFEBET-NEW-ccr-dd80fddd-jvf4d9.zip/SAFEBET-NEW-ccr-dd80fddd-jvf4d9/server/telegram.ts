import { createHmac, timingSafeEqual } from 'node:crypto';
import { env } from './env';
import { touch } from './live';

const MAX_AGE_SECONDS = 48 * 60 * 60;

export interface TelegramUser {
  id: number;
  first_name: string;
  last_name?: string;
  username?: string;
  photo_url?: string;
}

/** Validates Telegram Mini App initData: https://core.telegram.org/bots/webapps#validating-data-received-via-the-mini-app */
export function verifyInitData(initData: string, botToken: string, nowSeconds = Math.floor(Date.now() / 1000)): TelegramUser | null {
  const params = new URLSearchParams(initData);
  const hash = params.get('hash');
  if (!hash) return null;
  params.delete('hash');
  const dataCheckString = [...params.entries()]
    .sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0))
    .map(([k, v]) => `${k}=${v}`)
    .join('\n');
  const secret = createHmac('sha256', 'WebAppData').update(botToken).digest();
  const expected = createHmac('sha256', secret).update(dataCheckString).digest();
  const given = Buffer.from(hash, 'hex');
  if (given.length !== expected.length || !timingSafeEqual(given, expected)) return null;

  const authDate = Number(params.get('auth_date'));
  if (!Number.isFinite(authDate) || nowSeconds - authDate > MAX_AGE_SECONDS) return null;

  try {
    const user = JSON.parse(params.get('user') ?? 'null') as TelegramUser | null;
    return user && Number.isSafeInteger(user.id) && user.id > 0 ? user : null;
  } catch {
    return null;
  }
}

export function escapeHtml(s: string): string {
  return s.replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]!);
}

/** Telegram sends this in X-Telegram-Bot-Api-Secret-Token; derived from the bot token so no extra secret has to be configured. */
export function webhookSecret(): string | null {
  const token = env('BOT_TOKEN');
  if (!token) return null;
  return env('WEBHOOK_SECRET') || createHmac('sha256', token).update('brainrotcrash-webhook').digest('hex');
}

export function safeEqual(a: string, b: string): boolean {
  const x = Buffer.from(a);
  const y = Buffer.from(b);
  return x.length === y.length && timingSafeEqual(x, y);
}

/** Telegram answered ok: false (blocked by the user, flood limit, bad request…). */
export class BotRefusal {
  constructor(
    readonly code: number,
    readonly description: string,
    readonly retryAfter = 0,
  ) {}
  /** The user blocked the bot, deleted the account or never started it — stop writing to them. */
  get unreachable() {
    return this.code === 403 || /chat not found|user is deactivated|bot was blocked/i.test(this.description);
  }
}

export type BotApi = (method: string, params: Record<string, unknown>) => Promise<unknown>;

const realBotApi: BotApi = async (method, params) => {
  const token = env('BOT_TOKEN');
  if (!token) return null;
  try {
    const res = await fetch(`https://api.telegram.org/bot${token}/${method}`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(params),
      signal: AbortSignal.timeout(6000),
    });
    const data = (await res.json()) as { ok: boolean; result?: unknown; description?: string; error_code?: number; parameters?: { retry_after?: number } };
    if (data.ok) return data.result;
    console.error('bot api', method, data.description);
    return new BotRefusal(data.error_code ?? res.status, data.description ?? '', data.parameters?.retry_after ?? 0);
  } catch (e) {
    console.error('bot api', method, e);
    return null;
  }
};

let botApiImpl: BotApi = realBotApi;

export function useBotApi(fn: BotApi | null) {
  botApiImpl = fn ?? realBotApi;
}

/** Calls a Bot API method; null when Telegram refused or did not answer. */
export async function botApi<T>(method: string, params: Record<string, unknown>): Promise<T | null> {
  const r = await botApiImpl(method, params);
  return r instanceof BotRefusal ? null : (r as T | null);
}

/** Like botApi, but tells a refusal (with its reason) apart from no answer at all. */
export function botCall<T>(method: string, params: Record<string, unknown>): Promise<T | BotRefusal | null> {
  return botApiImpl(method, params) as Promise<T | BotRefusal | null>;
}

export type Notifier = (chatId: number, html: string) => Promise<boolean>;

const botNotifier: Notifier = async (chatId, html) => {
  const token = env('BOT_TOKEN');
  if (!token) return false;
  try {
    const res = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ chat_id: chatId, text: html, parse_mode: 'HTML', disable_web_page_preview: true }),
      signal: AbortSignal.timeout(4000),
    });
    return res.ok;
  } catch {
    return false;
  }
};

let notifier: Notifier = botNotifier;

export function useNotifier(n: Notifier | null) {
  notifier = n ?? botNotifier;
}

/**
 * Messages go to the bot chat (not the Mini App); a user who blocked the bot just doesn't get them. Something
 * about the player changed (a gift, a ban, a title…), so their open app refreshes too.
 */
export function notify(chatId: number, html: string): Promise<boolean> {
  touch(chatId, 'me');
  return notifier(chatId, html);
}
