import { useEffect } from 'react';
import { api } from '../api/client';
import { queryClient } from '../api/queries';
import { meIsHeld } from '../api/queries';
import { receiveDrops, setLiveSocketOpen, type LiveDrop } from './liveDrops';

/**
 * Live updates: one WebSocket to the server (/api/live). When something changes for this player elsewhere —
 * an admin credits a deposit, Stars arrive, a gift, a referral — the server says which data to refetch and the
 * app does it at once. Polling stays as the fallback (local dev has no socket).
 */

const TOPIC_KEYS: Record<string, readonly unknown[]> = {
  me: ['me'],
  itemDeposit: ['itemDeposit'],
  withdrawal: ['withdrawal'],
  battles: ['battles'],
  bonuses: ['bonuses'],
  catalog: ['catalog'],
  giveaways: ['giveaways'],
};

const PING_MS = 25_000;
const MAX_BACKOFF_MS = 30_000;
/** Catalog refetches after an admin edit are spread over this long. */
const CATALOG_SPREAD_MS = 4000;

export function useLiveUpdates(enabled: boolean) {
  useEffect(() => {
    if (!enabled || typeof WebSocket === 'undefined') return;
    let ws: WebSocket | null = null;
    let stopped = false;
    let retry: ReturnType<typeof setTimeout> | undefined;
    let ping: ReturnType<typeof setInterval> | undefined;
    let backoff = 1000;
    let connecting = false;

    const schedule = () => {
      if (stopped || retry) return;
      // Jittered: when the hub restarts, hundreds of apps must not all reconnect in the same second.
      retry = setTimeout(
        () => {
          retry = undefined;
          void connect();
        },
        backoff * (0.5 + Math.random()),
      );
      backoff = Math.min(backoff * 2, MAX_BACKOFF_MS);
    };

    async function connect() {
      if (stopped || connecting || (ws && ws.readyState <= WebSocket.OPEN)) return;
      let ticket: string | null;
      connecting = true;
      try {
        ticket = (await api<{ ticket: string | null }>('/api/live/ticket')).ticket;
      } catch {
        schedule();
        return;
      } finally {
        connecting = false;
      }
      // No socket here (local dev) — polling covers it.
      if (stopped || !ticket) return;
      const proto = location.protocol === 'https:' ? 'wss' : 'ws';
      const socket = new WebSocket(`${proto}://${location.host}/api/live?t=${encodeURIComponent(ticket)}`);
      ws = socket;
      socket.onopen = () => {
        backoff = 1000;
        setLiveSocketOpen(true);
        clearInterval(ping);
        ping = setInterval(() => socket.readyState === WebSocket.OPEN && socket.send('ping'), PING_MS);
        // Anything that happened while we were offline (unless a game is mid-animation — it catches up on release).
        if (!meIsHeld()) void queryClient.invalidateQueries({ queryKey: ['me'] });
      };
      socket.onmessage = (ev) => {
        if (typeof ev.data !== 'string' || ev.data === 'pong') return;
        try {
          const msg = JSON.parse(ev.data) as { type?: string; topics?: string[]; drops?: LiveDrop[] };
          if (msg.type === 'drops') return receiveDrops(msg.drops ?? []);
          if (msg.type !== 'refresh') return;
          for (const t of msg.topics ?? []) {
            const key = TOPIC_KEYS[t];
            if (!key) continue;
            // A game mid-animation holds `me`; the refresh is deferred and caught up when the hold releases.
            if (t === 'me' && meIsHeld()) continue;
            // An admin edit reaches every open app at once: spread their refetches over a few seconds. Admin writes (a new
            // or edited giveaway among them) come as `catalog`; settled giveaways as `giveaways`.
            if (t === 'catalog' || t === 'giveaways') {
              const delay = Math.random() * CATALOG_SPREAD_MS;
              if (t === 'catalog') setTimeout(() => void queryClient.invalidateQueries({ queryKey: key }), delay);
              setTimeout(() => void queryClient.invalidateQueries({ queryKey: ['giveaways'] }), delay);
            } else void queryClient.invalidateQueries({ queryKey: key });
          }
        } catch {
          // Not ours.
        }
      };
      socket.onclose = () => {
        clearInterval(ping);
        setLiveSocketOpen(false);
        if (ws === socket) ws = null;
        schedule();
      };
    }

    // Telegram keeps the WebView alive in the background: reconnect and catch up when it comes back.
    const onVisible = () => {
      if (document.visibilityState !== 'visible') return;
      if (!meIsHeld()) void queryClient.invalidateQueries({ queryKey: ['me'] });
      backoff = 1000;
      void connect();
    };
    document.addEventListener('visibilitychange', onVisible);
    void connect();
    return () => {
      stopped = true;
      document.removeEventListener('visibilitychange', onVisible);
      clearTimeout(retry);
      clearInterval(ping);
      ws?.close(1000);
    };
  }, [enabled]);
}
