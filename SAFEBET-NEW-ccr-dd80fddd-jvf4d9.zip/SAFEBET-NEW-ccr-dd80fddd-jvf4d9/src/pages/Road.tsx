import { useQuery } from '@tanstack/react-query';
import { useEffect, useLayoutEffect, useRef, useState, type CSSProperties } from 'react';
import { BrainrotThumb } from '../components/BrainrotCard';
import { Coin } from '../components/Coin';
import { Burst, Confetti, CountUp } from '../components/Fx';
import { Icon } from '../components/Icon';
import type { InventoryItem } from '../components/InventoryGrid';
import { StakeSheet } from '../components/StakeSheet';
import { ApiError, api, errorMessage } from '../api/client';
import { act, queryClient, setMe, useCatalog, useMe, type Me } from '../api/queries';
import { floor2, round2 } from '../../shared/money';
import {
  MAX_ROAD_ITEMS,
  MAX_ROAD_PAYOUT,
  MIN_ROAD_STAKE,
  ROAD_LEVELS,
  laneCrashes,
  laneMultiplier,
  roadLanes,
  roadLevel,
  roadMessage,
  type RoadLevel,
  type RoadRun,
  type RoadState,
} from '../../shared/road';
import { cx, formatCoins } from '../lib/format';
import { sha256Hex, sleep } from '../lib/halloween';
import { sfx } from '../lib/sound';
import { haptic } from '../lib/telegram';
import { tierOf } from '../lib/tier';
import { toast } from '../store/toast';
import { MIXED_DEMO, mixesDemo } from '../lib/demo';

const STATE_KEY = ['road'] as const;
const MEDALS = ['🥇', '🥈', '🥉'];
const mult = (x: number) => `x${x.toFixed(2)}`;
/** Scene geometry (px): the kerb the brainrot starts on and one lane. */
const SIDE = 64;
const LANE = 78;
/** Where the brainrot stands in the scene, as a share of its width. */
const FOCUS = 0.3;

type Fx = { kind: 'crash' | 'win'; key: number } | null;

/** «Дорога»: a brainrot crosses a road lane by lane; every lane can end in a crash, every clear one pays more. */
export function Road() {
  const me = useMe();
  const catalog = useCatalog();
  const state = useQuery({ queryKey: STATE_KEY, queryFn: () => api<RoadState>('/api/road'), staleTime: 30_000 });
  const [level, setLevel] = useState<RoadLevel>('easy');
  const [picked, setPicked] = useState<number[]>([]);
  const [sheet, setSheet] = useState(false);
  const [pending, setPending] = useState(false);
  /** The run on screen: the active one, or the one that just ended (until «Новый забег»). */
  const [run, setRun] = useState<RoadRun | null>(null);
  const [fx, setFx] = useState<Fx>(null);
  const [verified, setVerified] = useState<boolean | null>(null);
  const [width, setWidth] = useState(360);
  const scene = useRef<HTMLDivElement>(null);
  const unapplied = useRef<Me | null>(null);

  useEffect(
    () => () => {
      if (unapplied.current) setMe(unapplied.current);
    },
    [],
  );

  // A run left open (another device, a closed app) comes back as it was.
  const serverRun = state.data?.run ?? null;
  useEffect(() => {
    if (serverRun && (!run || run.id !== serverRun.id)) {
      setRun(serverRun);
      setLevel(serverRun.level);
    }
  }, [serverRun]); // eslint-disable-line react-hooks/exhaustive-deps

  useLayoutEffect(() => {
    const el = scene.current;
    if (!el) return;
    const ro = new ResizeObserver(() => setWidth(el.clientWidth));
    ro.observe(el);
    setWidth(el.clientWidth);
    return () => ro.disconnect();
  }, []);

  // Provably fair: the revealed key hashes to what was shown, and the lanes follow from it.
  useEffect(() => {
    if (!run?.seed) return;
    let alive = true;
    const seed = run.seed;
    const checks = Array.from({ length: run.step + (run.status === 'crashed' ? 1 : 0) }, (_, i) => sha256Hex(roadMessage(seed, i + 1)));
    Promise.all([sha256Hex(seed), ...checks])
      .then(([h, ...lanes]) => {
        const ok = lanes.every((hex, i) => laneCrashes(run.level, hex) === (run.status === 'crashed' && i === run.step));
        if (alive) setVerified(h === run.hash && ok);
      })
      .catch(() => {});
    return () => {
      alive = false;
    };
  }, [run]);

  const frozen = !!me.user.frozen;
  const active = run?.status === 'active';
  const over = !!run && !active;
  const busy = pending;
  const shownLevel = run?.level ?? level;
  const lanes = roadLanes(shownLevel);
  const risk = roadLevel(shownLevel)!.risk;
  const pickedItems = picked.flatMap((id) => {
    const item = me.inventory.find((i) => i.id === id && !i.withdrawalId);
    const b = item ? catalog.byId.get(item.brainrotId) : undefined;
    return item && b ? [{ item, b }] : [];
  });
  const stakeValue = active || over ? run!.stakeValue : round2(pickedItems.reduce((s, p) => s + p.b.price, 0));
  const step = run?.step ?? 0;
  const nowWin = floor2(stakeValue * laneMultiplier(shownLevel, step));
  const nextMult = lanes[step] ?? null;
  const nextWin = nextMult ? floor2(stakeValue * nextMult) : null;
  const limit = active && run!.next.problem === 'limit';
  // The runner: the stake's dearest brainrot.
  const heroId = run
    ? [...run.stake].sort((a, b) => (catalog.byId.get(b)?.price ?? 0) - (catalog.byId.get(a)?.price ?? 0))[0]
    : [...pickedItems].sort((a, b) => b.b.price - a.b.price)[0]?.b.id;
  const hero = heroId ? catalog.byId.get(heroId) ?? null : null;

  const problem = frozen
    ? 'Аккаунт заморожен — играть нельзя'
    : stakeValue < MIN_ROAD_STAKE
      ? 'Выбери брейнротов в ставку'
      : stakeValue * (lanes[0] ?? 0) > MAX_ROAD_PAYOUT
        ? `Ставка слишком большая: выигрыш до ${formatCoins(MAX_ROAD_PAYOUT)} B`
        : null;

  function toggle(item: InventoryItem) {
    if (picked.includes(item.id)) {
      sfx.tap();
      setPicked((list) => list.filter((id) => id !== item.id));
      return;
    }
    if (mixesDemo(pickedItems.map((p) => p.item), item)) {
      sfx.error();
      toast(MIXED_DEMO);
      return;
    }
    if (pickedItems.length >= MAX_ROAD_ITEMS) {
      sfx.error();
      toast(`В ставку — до ${MAX_ROAD_ITEMS} брейнротов`);
      return;
    }
    sfx.tap();
    setPicked((list) => [...list.filter((id) => pickedItems.some((p) => p.item.id === id)), item.id]);
  }

  function pickLevel(id: RoadLevel) {
    if (active || busy) return;
    sfx.tap();
    if (over) reset();
    setLevel(id);
  }

  function reset() {
    setRun(null);
    setFx(null);
    setVerified(null);
  }

  /** Server errors that mean the screen is out of date: reload the run. */
  function onError(e: unknown) {
    sfx.error();
    toast(errorMessage(e), 'error');
    if (e instanceof ApiError && ['no_run', 'run_active', 'limit'].includes(e.code)) void queryClient.invalidateQueries({ queryKey: STATE_KEY });
  }

  async function start() {
    if (busy || problem || active) return;
    setPending(true);
    try {
      const r = await act<{ run: RoadRun; nextHash: string }>('/api/road/start', { level, itemIds: pickedItems.map((p) => p.item.id) });
      setMe(r.me);
      setPicked([]);
      setFx(null);
      setVerified(null);
      setRun(r.result.run);
      sfx.press();
      haptic('tap');
      queryClient.setQueryData<RoadState>(STATE_KEY, (old) => (old ? { ...old, nextHash: r.result.nextHash, run: r.result.run } : old));
    } catch (e) {
      onError(e);
    } finally {
      setPending(false);
    }
  }

  async function stepOnce() {
    if (busy || !active || limit) return;
    setPending(true);
    try {
      const r = await act<{ run: RoadRun; crashed: boolean }>('/api/road/step');
      const next = r.result.run;
      if (r.result.crashed) {
        unapplied.current = r.me;
        // The car comes first, then the verdict.
        setRun({ ...next, status: 'active' });
        setFx({ kind: 'crash', key: Date.now() });
        sfx.whoosh();
        await sleep(380);
        sfx.boom();
        sfx.crack();
        haptic('error');
        setRun(next);
        unapplied.current = null;
        setMe(r.me);
        sfx.lose();
        finish(next);
      } else {
        setRun(next.status === 'active' ? next : { ...next, status: 'active' });
        sfx.land();
        haptic('tap');
        if (next.status === 'cashed') {
          // The end of the road (or the limit): the win is taken by itself.
          await sleep(420);
          won(next, r.me);
        } else setMe(r.me);
      }
    } catch (e) {
      onError(e);
    } finally {
      setPending(false);
    }
  }

  async function cashout() {
    if (busy || !active || step < 1) return;
    setPending(true);
    try {
      const r = await act<{ run: RoadRun }>('/api/road/cashout');
      won(r.result.run, r.me);
    } catch (e) {
      onError(e);
    } finally {
      setPending(false);
    }
  }

  function won(r: RoadRun, fresh: Me) {
    setRun(r);
    setMe(fresh);
    setFx({ kind: 'win', key: Date.now() });
    const prize = r.payout?.brainrotId ? catalog.byId.get(r.payout.brainrotId) : null;
    if (r.multiplier >= 10 || (prize && ['legendary', 'secret'].includes(tierOf(prize.price)))) sfx.bigWin();
    else sfx.cashout();
    haptic('success');
    finish(r);
  }

  function finish(r: RoadRun) {
    queryClient.setQueryData<RoadState>(STATE_KEY, (old) =>
      old
        ? {
            ...old,
            run: null,
            mine: [
              { level: r.level, step: r.step, won: r.status === 'cashed', multiplier: r.status === 'cashed' ? r.multiplier : 0, value: r.payout?.value ?? 0, stakeValue: r.stakeValue, at: Date.now() },
              ...old.mine,
            ].slice(0, 12),
          }
        : old,
    );
    if (r.status === 'cashed') void queryClient.invalidateQueries({ queryKey: STATE_KEY });
  }

  const crashing = fx?.kind === 'crash';
  const crashLane = run?.status === 'crashed' || crashing ? step + 1 : null;
  // The road slides so the runner keeps its place in the scene (on a crash it stands on the fatal lane).
  const heroStep = crashLane ?? step;
  const heroX = heroStep === 0 ? SIDE / 2 : SIDE + (heroStep - 0.5) * LANE;
  const shift = Math.round(width * FOCUS - heroX);
  const prize = over && run.payout?.brainrotId ? catalog.byId.get(run.payout.brainrotId) ?? null : null;
  const big = over && run.status === 'cashed' && (run.multiplier >= 10 || (!!prize && ['legendary', 'secret'].includes(tierOf(prize.price))));
  const top = state.data?.top ?? [];
  const mine = state.data?.mine ?? [];

  return (
    <section className="game road" aria-labelledby="road-title">
      <div className="road-head">
        <h1 id="road-title" className="page-title">
          Дорога
        </h1>
        <span className="road-head__tag">
          <Icon name="road" size={14} /> {lanes.length} полос · до {mult(lanes[lanes.length - 1] ?? 0)}
        </span>
      </div>

      <div className="segmented road-levels" role="radiogroup" aria-label="Сложность">
        {ROAD_LEVELS.map((l) => (
          <button
            key={l.id}
            type="button"
            role="radio"
            aria-checked={shownLevel === l.id}
            className={cx('segmented__opt', shownLevel === l.id && 'is-on', `road-levels__${l.id}`)}
            onClick={() => pickLevel(l.id)}
            disabled={active || busy}
          >
            <b>{l.name}</b>
            <small>{Math.round(l.risk * 100)}% аварии</small>
          </button>
        ))}
      </div>

      <div
        ref={scene}
        className={cx('road-scene', `road-scene--${shownLevel}`, active && 'is-live', run?.status === 'crashed' && 'is-crashed', over && run.status === 'cashed' && 'is-won', big && 'is-big')}
        style={{ '--lane': `${LANE}px`, '--side': `${SIDE}px` } as CSSProperties}
      >
        <div className="road-track" style={{ transform: `translate3d(${shift}px, 0, 0)` }}>
          <div className="road-kerb road-kerb--start" aria-hidden="true">
            <span>СТАРТ</span>
          </div>
          {lanes.map((m, i) => {
            const k = i + 1;
            const crossed = k <= step;
            const isNext = active && k === step + 1;
            const hit = crashLane === k;
            return (
              <div key={k} className={cx('road-lane', crossed && 'is-crossed', isNext && 'is-next', hit && 'is-hit')} aria-hidden="true">
                {!crossed && !hit && k > step + 1 && <span className="road-car road-car--ambient" style={{ '--d': `${(k * 0.73) % 2.4}s`, '--t': `${1.6 + ((k * 7) % 5) * 0.22}s` } as CSSProperties} />}
                {crossed && <span className="road-barrier" />}
                <span className={cx('road-hatch', crossed && 'is-lit')}>
                  <b>{mult(m)}</b>
                </span>
                {hit && <span key={fx?.key} className="road-car road-car--hit" />}
              </div>
            );
          })}
          <div className="road-kerb road-kerb--finish" aria-hidden="true">
            <span>ФИНИШ</span>
          </div>
          <div className={cx('road-hero', run?.status === 'crashed' && 'is-down', over && run.status === 'cashed' && 'is-safe')} style={{ transform: `translate3d(${heroX}px, 0, 0)` }}>
            <span key={heroStep} className={cx('road-hero__body', !hero && 'road-hero__body--empty')}>
              {hero ? <img src={hero.image} alt="" draggable={false} /> : <Icon name="plus" size={22} />}
            </span>
            <span className="road-hero__shadow" />
            {fx?.kind === 'win' && <Burst key={fx.key} count={22} spread={0.7} />}
          </div>
        </div>

        <p className="road-shout" role="status">
          <span key={`${run?.id ?? 'idle'}-${step}-${run?.status ?? ''}`}>
            {!run
              ? 'Брейнрот ждёт у обочины — выбери ставку'
              : run.status === 'crashed'
                ? `Авария на полосе ${step + 1}! Ставка сгорела`
                : run.status === 'cashed'
                  ? `Забрал на полосе ${step}: ${mult(run.multiplier)}`
                  : run.status === 'refunded'
                    ? 'Забег закрыт — ставка вернулась'
                    : step === 0
                      ? 'Готов к переходу — первый шаг!'
                      : limit
                        ? 'Лимит выигрыша — забирай!'
                        : `Полоса ${step} пройдена · ${mult(run.multiplier)}`}
          </span>
        </p>

        {over && run.status === 'cashed' && (
          <button type="button" className="road-result is-won" onClick={reset}>
            <span className="road-result__title">Забрал {mult(run.multiplier)}</span>
            {prize && <img className="road-result__img" src={prize.image} alt="" />}
            <span className="road-result__name">{prize?.name ?? 'Монеты'}</span>
            {(run.payout?.coins ?? 0) > 0 && (
              <span className="road-result__coins">
                +<CountUp to={run.payout!.coins} format={formatCoins} /> <Coin size={16} />
              </span>
            )}
            <span className="road-result__hint">Нажми — новый забег</span>
          </button>
        )}
        {over && run.status === 'crashed' && (
          <button type="button" className="road-result is-lost" onClick={reset}>
            <span className="road-result__title">Авария!</span>
            <span className="road-result__name">
              Полоса {step + 1} из {lanes.length}
            </span>
            <span className="road-result__hint">Нажми — новый забег</span>
          </button>
        )}
      </div>

      <dl className="up-summary road-summary">
        <div>
          <dt>Сейчас</dt>
          <dd className="is-green">
            {active && step > 0 ? (
              <>
                <Coin size={12} /> {formatCoins(nowWin)}
              </>
            ) : (
              '—'
            )}
          </dd>
        </div>
        <div>
          <dt>Дальше</dt>
          <dd className="is-gold">{nextMult && !over ? mult(nextMult) : '—'}</dd>
        </div>
        <div>
          <dt>Авария</dt>
          <dd className="is-red">{Math.round(risk * 100)}%</dd>
        </div>
      </dl>

      <div className="bet-panel road-panel">
        {active ? (
          <div className="road-actions">
            <button type="button" className="btn btn--primary btn--lg road-step" disabled={busy || limit} onClick={stepOnce}>
              <Icon name="arrowRight" size={20} />
              <span>
                {limit ? 'Лимит' : 'Шаг'}
                {nextWin !== null && !limit && (
                  <small>
                    {mult(nextMult!)} · {formatCoins(nextWin)} B
                  </small>
                )}
              </span>
            </button>
            <button type="button" className="btn btn--lg road-cash" disabled={busy || step < 1} onClick={cashout}>
              <span>
                Забрать
                <small>{step < 1 ? 'после 1-го шага' : `${formatCoins(nowWin)} B`}</small>
              </span>
            </button>
          </div>
        ) : (
          <>
            <button type="button" className="select select--wide hw-stake" onClick={() => setSheet(true)} disabled={busy || frozen}>
              {pickedItems.length ? (
                <>
                  <span className="hw-stake__thumbs">
                    {pickedItems.map((p) => (
                      <BrainrotThumb key={p.item.id} brainrot={p.b} size={30} />
                    ))}
                  </span>
                  <span className="select__text">{pickedItems.length === 1 ? pickedItems[0]!.b.name : `${pickedItems.length} брейнрота`}</span>
                  <span className="select__price">
                    <Coin size={13} /> {formatCoins(stakeValue)}
                  </span>
                </>
              ) : (
                <span className="select__text">Брейнроты в ставку (до {MAX_ROAD_ITEMS})</span>
              )}
              <Icon name="chevronDown" size={18} />
            </button>
            {over ? (
              <button type="button" className="btn btn--primary btn--lg btn--block" onClick={reset}>
                <Icon name="reset" size={20} /> Новый забег
              </button>
            ) : (
              <button type="button" className="btn btn--primary btn--lg btn--block" disabled={!!problem || busy} onClick={start}>
                {pending ? (
                  'Секунду…'
                ) : problem ? (
                  problem
                ) : (
                  <>
                    <Icon name="road" size={20} /> На старт · {formatCoins(stakeValue)} B
                  </>
                )}
              </button>
            )}
          </>
        )}
        <p className="hint hint--left">
          Брейнрот переходит дорогу по полосам. Каждая пройденная полоса поднимает множитель, на каждой может случиться авария — тогда ставка сгорает.
          Забрать выигрыш можно после любого шага: самый дорогой брейнрот, который влезает в ставку × множитель, и сдача монетами. Ставка — только
          брейнроты (до {MAX_ROAD_ITEMS}), выигрыш — до {formatCoins(MAX_ROAD_PAYOUT)} B. Брошенный забег через 30 минут закрывается сам: после шага
          выигрыш забирается за тебя.
        </p>
      </div>

      <p className="road-fair">
        <Icon name="shield" size={14} /> Честная игра ·{' '}
        {active ? (
          <>
            ключ забега: хэш <code>{run.hash.slice(0, 12)}…</code>
          </>
        ) : (
          <>
            следующий забег: хэш <code>{(state.data?.nextHash ?? '').slice(0, 12)}…</code>
          </>
        )}
        {over && run.seed && (
          <>
            {' '}
            · ключ прошлого <code>{run.seed.slice(0, 8)}…</code> {verified === true && <span className="road-fair__ok">совпадает ✓</span>}
            {verified === false && <span className="road-fair__bad">не совпадает</span>}
          </>
        )}
      </p>

      {mine.length > 0 && (
        <div className="history" aria-label="Мои забеги">
          {mine.map((m, i) => (
            <span key={`${m.at}-${i}`} className={cx('history__chip', m.multiplier >= 1 ? 'is-high' : 'is-low')} title={`${roadLevel(m.level)?.name ?? ''} · полоса ${m.step}`}>
              {m.won ? mult(m.multiplier) : '✕'}
            </span>
          ))}
        </div>
      )}

      <section className="panel hw-top" aria-labelledby="road-top-title">
        <h2 id="road-top-title" className="panel__title">
          Самые дальние забеги
        </h2>
        {top.length === 0 ? (
          <p className="hint hint--left">Пока никто не забрал выигрыш. Будь первым!</p>
        ) : (
          <ol className="hw-top__list">
            {top.map((t, i) => {
              const b = t.brainrotId ? catalog.byId.get(t.brainrotId) : null;
              return (
                <li key={`${t.at}-${i}`} className={cx('hw-top__row', i < 3 && 'is-podium')}>
                  <span className="hw-top__rank">{MEDALS[i] ?? i + 1}</span>
                  <span className="hw-top__who">
                    <b>{t.name}</b>
                    <small>
                      {roadLevel(t.level)?.name} · полоса {t.step} · {mult(t.multiplier)}
                    </small>
                  </span>
                  {b && <BrainrotThumb brainrot={b} size={30} />}
                  <span className="hw-top__value">
                    <Coin size={13} /> {formatCoins(t.value)}
                  </span>
                </li>
              );
            })}
          </ol>
        )}
      </section>

      <StakeSheet open={sheet} onClose={() => setSheet(false)} picked={pickedItems.map((p) => p.item.id)} max={MAX_ROAD_ITEMS} onToggle={toggle} />
      {big && fx && <Confetti key={fx.key} count={70} />}
    </section>
  );
}
