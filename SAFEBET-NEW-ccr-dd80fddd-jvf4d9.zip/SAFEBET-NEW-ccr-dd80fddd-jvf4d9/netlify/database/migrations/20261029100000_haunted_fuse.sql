-- Haunted Fuse: every player's next fuse key. Its sha256 is shown before the fuse, the key itself right after;
-- the first two 32-bit numbers of sha256('fuse:' || seed) pick the range and the brainrot (shared/fuse.ts).
CREATE TABLE fuse_seeds (
  user_id BIGINT PRIMARY KEY REFERENCES users (id),
  seed TEXT NOT NULL,
  hash TEXT NOT NULL,
  nonce INT NOT NULL DEFAULT 0
);

CREATE INDEX drops_fuse_top ON drops (payout_value DESC) WHERE game = 'fuse';

ALTER TABLE fuse_seeds ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'anon') THEN
    EXECUTE 'REVOKE ALL ON fuse_seeds FROM anon, authenticated';
  END IF;
END $$;
