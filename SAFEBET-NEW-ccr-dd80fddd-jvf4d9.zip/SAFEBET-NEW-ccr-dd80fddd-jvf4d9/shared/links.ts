/** Public links shared by the bot and the app. */
export const NEWS_URL = 'https://t.me/BrainrotCrash';
/** Tech support (iteration 37): the owner's support bot; the /start button and the app's chat button lead here. */
export const SUPPORT_URL = 'https://t.me/bcrashsupport_bot';
