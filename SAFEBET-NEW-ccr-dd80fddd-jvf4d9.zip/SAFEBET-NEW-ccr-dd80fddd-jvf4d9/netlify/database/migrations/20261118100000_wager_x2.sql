-- Iteration 38 (the owner, urgent): «отыгрыш до х2» — deposits and bonuses are played through ×2 before a withdrawal.
-- The panel's rules get 2 (the owner can change them again in «Выводы» → «Правила вывода»), and an unset rule means 2.
-- Requirements already counted stay as they are; new credits count ×2. Applied by the Worker — safe to run twice.

INSERT INTO settings (key, value) VALUES ('withdraw_rules', '{"wagerDeposit": 2, "wagerBonus": 2}'::jsonb)
ON CONFLICT (key) DO UPDATE SET value = settings.value || '{"wagerDeposit": 2, "wagerBonus": 2}'::jsonb;

CREATE OR REPLACE FUNCTION wager_rate(kind TEXT) RETURNS NUMERIC LANGUAGE sql STABLE AS $$
  SELECT coalesce(
    (SELECT least(greatest((value ->> CASE WHEN kind = 'deposit' THEN 'wagerDeposit' ELSE 'wagerBonus' END)::numeric, 0), 10)
       FROM settings
      WHERE key = 'withdraw_rules'
        AND jsonb_typeof(value -> CASE WHEN kind = 'deposit' THEN 'wagerDeposit' ELSE 'wagerBonus' END) = 'number'),
    2)
$$;
