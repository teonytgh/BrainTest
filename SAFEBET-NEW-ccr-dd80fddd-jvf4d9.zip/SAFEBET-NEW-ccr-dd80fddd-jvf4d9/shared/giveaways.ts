/**
 * «Розыгрыши» made by admins. Prizes are catalog brainrots chosen per place, landing in the winners' inventories; the
 * house pays exactly what the admin put up.
 *  - deposit_race: score = net deposits in the period (Stars, crypto + brainrot deposits − finished withdrawals), so
 *    depositing and withdrawing again doesn't score;
 *  - referral_race: score = friends bound in the period whose own net deposits in the period reach `minDeposit`
 *    (at least MIN_REFERRAL_RACE_DEPOSIT: empty accounts never count);
 *  - draw: players press «Участвовать»; winners are drawn at random among those who meet the requirements.
 * Equal scores: the earlier registered player ranks higher. Banned or frozen players and staff (owners, admins) never
 * place.
 */
export const GIVEAWAY_KINDS = ['deposit_race', 'referral_race', 'draw'] as const;
export type GiveawayKind = (typeof GIVEAWAY_KINDS)[number];

export const GIVEAWAY_KIND_NAMES: Record<GiveawayKind, string> = {
  deposit_race: 'Гонка пополнений',
  referral_race: 'Гонка приглашений',
  draw: 'Розыгрыш',
};

export const MAX_GIVEAWAY_PLACES = 10;
/** Places on the public leaderboard. */
export const GIVEAWAY_TOP = 5;
export const MIN_REFERRAL_RACE_DEPOSIT = 10;
export const MAX_GIVEAWAY_DAYS = 60;

export type GiveawayStatus = 'upcoming' | 'active' | 'finished' | 'cancelled';

export interface GiveawayPrize {
  place: number;
  brainrotId: string;
}

export interface GiveawayPlayer {
  place: number;
  name: string;
  photo: string | null;
  playerId: string | null;
  score: number;
}

export interface GiveawayCard {
  id: number;
  kind: GiveawayKind;
  title: string;
  banner: string | null;
  startsAt: number;
  endsAt: number;
  status: GiveawayStatus;
  prizes: GiveawayPrize[];
  /** Players who joined a draw; null for races (their field is everyone who scores). */
  entries: number | null;
  /** The first place of a finished giveaway. */
  winner: (GiveawayPlayer & { brainrotId: string }) | null;
}

export interface GiveawayDetail extends GiveawayCard {
  description: string;
  conditions: string;
  minDeposit: number;
  /**
   * «Пополни брейнрота X ×N» in the period (iteration 35): what is asked and how many the player brought; since
   * iteration 39 Stars/crypto deposits of `paidNeed` B in the period meet it too (`paid` = what the player paid so).
   */
  needBrainrot: { brainrotId: string; count: number; have: number; paid: number; paidNeed: number } | null;
  /** The channel a draw needs a subscription to (the free case channel), when it does. */
  channel: { username: string; url: string } | null;
  /** Races: the top GIVEAWAY_TOP; draws: empty (winners come at the end). */
  top: GiveawayPlayer[];
  /** Everyone who scores (races) or joined (draws). */
  field: number;
  me: { place: number | null; score: number; joined: boolean; eligible: boolean };
  winners: (GiveawayPlayer & { brainrotId: string })[];
}

export function giveawayStatus(g: { status: 'active' | 'finished' | 'cancelled'; startsAt: number }, now = Date.now()): GiveawayStatus {
  if (g.status !== 'active') return g.status;
  return g.startsAt > now ? 'upcoming' : 'active';
}
