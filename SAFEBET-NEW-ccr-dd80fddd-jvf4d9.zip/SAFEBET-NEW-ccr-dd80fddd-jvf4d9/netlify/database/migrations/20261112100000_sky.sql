-- Iteration 35 (part 3): «Небо Meowl». Applied by the Worker (server/autoMigrate.ts), so every statement is safe to run
-- twice. The running event itself lives in settings `sky` (it rides with the catalog to every open app); these tables
-- keep each run's players, picks and eggs.

CREATE TABLE IF NOT EXISTS sky_runs (
  id BIGSERIAL PRIMARY KEY,
  seed BIGINT NOT NULL,
  started_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  ends_at TIMESTAMPTZ NOT NULL,
  max_per_player NUMERIC(16, 2) NOT NULL CHECK (max_per_player > 0),
  need_deposit BOOLEAN NOT NULL DEFAULT true,
  created_by BIGINT,
  -- Started by the tick's auto-repeat rather than by an admin.
  auto BOOLEAN NOT NULL DEFAULT false
);

-- Where the server last knew a player to be (spawn or last pick) and what they collected this run.
CREATE TABLE IF NOT EXISTS sky_players (
  run_id BIGINT NOT NULL REFERENCES sky_runs (id) ON DELETE CASCADE,
  user_id BIGINT NOT NULL REFERENCES users (id),
  x INT NOT NULL,
  y INT NOT NULL,
  at TIMESTAMPTZ NOT NULL DEFAULT now(),
  coins NUMERIC(16, 2) NOT NULL DEFAULT 0,
  eggs NUMERIC(16, 2) NOT NULL DEFAULT 0,
  joined_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (run_id, user_id)
);

-- One row per coin or egg taken: the primary key makes a coin shared (the first player gets it).
CREATE TABLE IF NOT EXISTS sky_picks (
  run_id BIGINT NOT NULL REFERENCES sky_runs (id) ON DELETE CASCADE,
  key TEXT NOT NULL,
  user_id BIGINT NOT NULL REFERENCES users (id),
  value NUMERIC(16, 2) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (run_id, key)
);
CREATE INDEX IF NOT EXISTS sky_picks_user ON sky_picks (user_id, created_at);

-- Eggs an admin dropped next to players (key `e:<id>` in sky_picks once taken).
CREATE TABLE IF NOT EXISTS sky_eggs (
  id BIGSERIAL PRIMARY KEY,
  run_id BIGINT NOT NULL REFERENCES sky_runs (id) ON DELETE CASCADE,
  x INT NOT NULL,
  y INT NOT NULL,
  near_user BIGINT,
  spawned_by BIGINT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS sky_eggs_run ON sky_eggs (run_id);

DO $$
DECLARE t TEXT;
BEGIN
  FOREACH t IN ARRAY ARRAY['sky_runs', 'sky_players', 'sky_picks', 'sky_eggs'] LOOP
    EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', t);
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'anon') THEN
      EXECUTE format('REVOKE ALL ON %I FROM anon, authenticated', t);
    END IF;
  END LOOP;
END $$;
