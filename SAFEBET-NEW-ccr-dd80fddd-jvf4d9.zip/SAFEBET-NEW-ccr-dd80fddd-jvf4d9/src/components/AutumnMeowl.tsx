import { useEffect, useRef, useState, type CSSProperties } from 'react';
import { Leaf, LEAF_COLORS, type LeafKind } from './AutumnLeaves';
import { Meowl } from './Meowl';
import { sfx } from '../lib/sound';
import { haptic } from '../lib/telegram';

/** What Meowl says when tapped — just autumn chatter: no odds, no prizes promised. */
const LINES = [
  'Мяу! Осень пришла — листья падают, а я собираю их в кучу.',
  'Шуршу листьями… Слышишь? Это самый уютный звук осени.',
  'Не трогай кучу! Я её всё утро собирал.',
  'Ветер сегодня сильный — держи шарф крепче.',
  'Осень — время пледа, какао и спокойной игры.',
  'Этот кленовый лист я нашёл у апгрейдера. Красивый, правда?',
  'Если устанешь — выключи листопад в настройках, я не обижусь.',
  'Тапни ещё — подброшу листья повыше!',
  'Мур-р-р… Обожаю, когда листья хрустят под лапами.',
  'Говорят, осенью совы умнеют. А я Meowl — я и так умный.',
];
const TIRED = 'Всё, я зарылся в листья. Меня тут нет… мур.';
const KINDS: LeafKind[] = ['maple', 'oak', 'birch'];
const TYPE_MS = 26;

interface Burst {
  id: number;
  leaves: { kind: LeafKind; color: (typeof LEAF_COLORS)[number]; style: CSSProperties }[];
}

/**
 * «Осень с Meowl» on the home page (iteration 40, the owner: «интеракт с мявлом»): Meowl sits in a pile of leaves with
 * a maple leaf on his head; a tap makes him hop, meow and toss a handful of leaves, and he says something new — typed out
 * like in his tour. Fun only: nothing to win. Home mounts it only while the autumn season runs.
 */
export function AutumnMeowl() {
  const [line, setLine] = useState(0);
  const [typed, setTyped] = useState(0);
  const [taps, setTaps] = useState(0);
  const [hop, setHop] = useState(0);
  const [bursts, setBursts] = useState<Burst[]>([]);
  const nextBurst = useRef(1);
  // Silent typing until the first tap: no clatter every time the home page opens.
  const tapped = taps > 0;
  const text = taps >= 15 ? TIRED : LINES[line]!;

  // Type the line out, letter by letter.
  useEffect(() => {
    setTyped(0);
    let n = 0;
    const id = setInterval(() => {
      n += 1;
      setTyped(n);
      if (tapped && n % 2 === 0) sfx.type();
      if (n >= text.length) clearInterval(id);
    }, TYPE_MS);
    return () => clearInterval(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [text]);

  function tap() {
    haptic('tap');
    if ((taps + 1) % 3 === 0) sfx.catMeow();
    else sfx.meow();
    setTaps((t) => t + 1);
    setHop((h) => h + 1);
    setLine((l) => {
      let n = Math.floor(Math.random() * LINES.length);
      if (n === l) n = (n + 1) % LINES.length;
      return n;
    });
    const id = nextBurst.current++;
    const leaves = Array.from({ length: 7 }, (_, i) => {
      const angle = (-150 + (i / 6) * 120 + (Math.random() * 16 - 8)) * (Math.PI / 180);
      const dist = 46 + Math.random() * 40;
      return {
        kind: KINDS[(i + id) % KINDS.length]!,
        color: LEAF_COLORS[(i + id) % LEAF_COLORS.length]!,
        style: {
          '--dx': `${Math.round(Math.cos(angle) * dist)}px`,
          '--dy': `${Math.round(Math.sin(angle) * dist)}px`,
          '--r': `${Math.round(Math.random() * 540 - 270)}deg`,
          animationDelay: `${i * 18}ms`,
        } as CSSProperties,
      };
    });
    setBursts((b) => [...b.slice(-2), { id, leaves }]);
    setTimeout(() => setBursts((b) => b.filter((x) => x.id !== id)), 1300);
  }

  return (
    <section className="ameowl" aria-label="Осень с Meowl">
      <button type="button" className="ameowl__pet" onClick={tap} aria-label="Погладить Meowl">
        <span className="ameowl__pile" aria-hidden="true">
          {Array.from({ length: 9 }, (_, i) => (
            <span key={i} className={`ameowl__heap ameowl__heap--${i}`}>
              <Leaf kind={KINDS[i % 3]!} color={LEAF_COLORS[i % LEAF_COLORS.length]!} />
            </span>
          ))}
        </span>
        <span key={hop} className={hop ? 'ameowl__hop is-hopping' : 'ameowl__hop'}>
          <Meowl size={92} talking={typed < text.length} />
          <span className="ameowl__hat" aria-hidden="true">
            <Leaf kind="maple" color="rust" />
          </span>
        </span>
        {bursts.map((b) => (
          <span key={b.id} className="ameowl__burst" aria-hidden="true">
            {b.leaves.map((l, i) => (
              <span key={i} className="ameowl__flying" style={l.style}>
                <Leaf kind={l.kind} color={l.color} />
              </span>
            ))}
          </span>
        ))}
      </button>
      <div className="ameowl__bubble">
        <p className="ameowl__kicker">Осень с Meowl</p>
        <p className="ameowl__text" aria-live="polite">
          {text.slice(0, typed)}
          <span className="ameowl__rest" aria-hidden="true">
            {text.slice(typed)}
          </span>
        </p>
        <p className="ameowl__hint">{taps === 0 ? 'Тапни Meowl' : `Поглажен ${taps} ${plural(taps)}`}</p>
      </div>
    </section>
  );
}

const plural = (n: number) => (n % 10 === 1 && n % 100 !== 11 ? 'раз' : n % 10 >= 2 && n % 10 <= 4 && (n % 100 < 12 || n % 100 > 14) ? 'раза' : 'раз');
