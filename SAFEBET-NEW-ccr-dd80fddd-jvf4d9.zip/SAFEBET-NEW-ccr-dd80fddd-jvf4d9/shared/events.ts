/**
 * Timed events admins switch on in «Ивенты», one by one or all at once with «Щелчок» (our take on Sammy's Snap from
 * Steal a Brainrot: a 10-second cutscene plays in every open app, then the events run until the same moment).
 *  - cases / luck4 / luck8: x2 / x4 / x8 luck — real: the chance of a drop dearer than the case is multiplied, the
 *    88 % average stays (the strongest running one counts). Never a «luck» that changes nothing: the name promises
 *    odds;
 *  - fuse, upgrade: the owner's party look for FUSE and the upgrader (banner, glow, effects) — chances don't change,
 *    so their texts never promise any (the owner's call: the look only);
 *  - tacos: «Raining Tacos» — tacos fall over every page and its track plays by itself.
 */
export const EVENT_IDS = ['cases', 'luck4', 'luck8', 'fuse', 'upgrade', 'tacos'] as const;
export type EventId = (typeof EVENT_IDS)[number];

export const EVENT_INFO: Record<EventId, { name: string; icon: string; route: string }> = {
  cases: { name: 'x2 удача в кейсах', icon: '/events/luck-cases.webp', route: 'home' },
  luck4: { name: 'x4 удача в кейсах', icon: '/events/luck-x4.webp', route: 'home' },
  luck8: { name: 'x8 удача в кейсах', icon: '/events/luck-x8.webp', route: 'home' },
  fuse: { name: 'Ивент FUSE', icon: '/events/luck-fuse.webp', route: 'fuse' },
  upgrade: { name: 'Ивент апгрейдера', icon: '/events/luck-upgrade.webp', route: 'upgrader' },
  tacos: { name: 'Raining Tacos', icon: '/events/tacos-icon.webp', route: 'home' },
};

/** When each event ends (ms), or null when it is off. */
export type EventsState = Record<EventId, number | null>;

export interface Snap {
  /** When the snap happened (ms) — doubles as the id every device remembers once it has played the cutscene. */
  at: number;
  endsAt: number;
  events: EventId[];
}

export const MAX_EVENT_MINUTES = 7 * 24 * 60;
export const MAX_SNAP_MINUTES = 180;
/** The cutscene: its length and the moment the fingers snap (s), as rendered by scripts/blender/snap_cutscene.py. */
export const SNAP_VIDEO_SECONDS = 10;
export const SNAP_AT_SECONDS = 181 / 24;
/** A device that opens the app this long after the snap no longer gets the cutscene (the events still run). */
export const SNAP_REPLAY_MS = 10 * 60 * 1000;

export const eventOn = (until: number | null | undefined, now = Date.now()) => !!until && until > now;

/** The luck events by strength: which multiplier each one gives the cases. */
export const LUCK_EVENTS = [
  { id: 'luck8', x: 8 },
  { id: 'luck4', x: 4 },
  { id: 'cases', x: 2 },
] as const satisfies readonly { id: EventId; x: number }[];

/**
 * What «Щелчок» switches on when the admin picks nothing: every event, with x2 luck — x4 and x8 are stronger
 * alternatives to it, run only when picked.
 */
export const SNAP_DEFAULT_EVENTS: readonly EventId[] = EVENT_IDS.filter((e) => e !== 'luck4' && e !== 'luck8');
