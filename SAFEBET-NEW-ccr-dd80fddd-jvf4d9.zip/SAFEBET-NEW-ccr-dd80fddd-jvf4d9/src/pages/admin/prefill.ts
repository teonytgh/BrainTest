/** Hands a chosen player from the Users section to the Give / Punish forms. */
let pending = '';

export function prefillUser(ref: string) {
  pending = ref;
}

export function takePrefilledUser(): string {
  const v = pending;
  pending = '';
  return v;
}
