import brainflipRefund from '../netlify/database/migrations/20261107100000_brainflip_refund.sql';
import growth from '../netlify/database/migrations/20261107100001_growth.sql';
import tickets from '../netlify/database/migrations/20261108100000_tickets.sql';
import caseConfigs from '../netlify/database/migrations/20261109100000_case_configs.sql';
import iteration35 from '../netlify/database/migrations/20261110100000_iteration35.sql';
import demo from '../netlify/database/migrations/20261111100000_demo.sql';
import sky from '../netlify/database/migrations/20261112100000_sky.sql';
import squid from '../netlify/database/migrations/20261113100000_squid.sql';
import wager from '../netlify/database/migrations/20261114100000_wager.sql';
import skyPool from '../netlify/database/migrations/20261115100000_sky_pool.sql';
import pass from '../netlify/database/migrations/20261116100000_pass.sql';
import refOnce from '../netlify/database/migrations/20261117100000_ref_once.sql';
import wagerX2 from '../netlify/database/migrations/20261118100000_wager_x2.sql';
import cryptoPay from '../netlify/database/migrations/20261119100000_crypto.sql';
import { q, tx } from './db';

/**
 * Migrations the Worker applies to production by itself. Deploys come from Cloudflare Workers Builds on every push,
 * and production's other migrations need `node scripts/migrate-supabase.mjs` with a Supabase token — so from
 * iteration 30 on, new ones are listed here (their SQL is bundled as text) and recorded in the same `_migrations`
 * table that script uses, so it skips them later. Each must be safe to run twice (local dev and the tests have
 * already applied the file). Called by the tick and by the routes that need the new tables.
 */
const MIGRATIONS: { name: string; sql: string }[] = [
  // BrainFlip's own table (20261106100000_brainflip.sql) went out with the game; this closes what was left open.
  { name: '20261107100000_brainflip_refund.sql', sql: brainflipRefund },
  { name: '20261107100001_growth.sql', sql: growth },
  { name: '20261108100000_tickets.sql', sql: tickets },
  { name: '20261109100000_case_configs.sql', sql: caseConfigs },
  { name: '20261110100000_iteration35.sql', sql: iteration35 },
  { name: '20261111100000_demo.sql', sql: demo },
  { name: '20261112100000_sky.sql', sql: sky },
  { name: '20261113100000_squid.sql', sql: squid },
  { name: '20261114100000_wager.sql', sql: wager },
  { name: '20261115100000_sky_pool.sql', sql: skyPool },
  { name: '20261116100000_pass.sql', sql: pass },
  { name: '20261117100000_ref_once.sql', sql: refOnce },
  { name: '20261118100000_wager_x2.sql', sql: wagerX2 },
  { name: '20261119100000_crypto.sql', sql: cryptoPay },
];

/** Once per isolate (a flag, not a shared promise: a Worker can't await another request's I/O). */
let applied = false;

export async function ensureSchema(): Promise<void> {
  if (applied) return;
  let done = new Set<string>();
  try {
    const rows = await q<{ name: string }>('SELECT name FROM _migrations WHERE name = ANY($1)', [MIGRATIONS.map((m) => m.name)]);
    done = new Set(rows.map((r) => r.name));
  } catch (e) {
    // No _migrations table yet (a fresh local database): everything below is idempotent.
    if ((e as { code?: string }).code !== '42P01') throw e;
  }
  for (const m of MIGRATIONS) {
    if (done.has(m.name)) continue;
    await tx(async (c) => {
      // Two isolates starting at once: one applies, the other finds it done.
      await c.query(`SELECT pg_advisory_xact_lock(hashtext('auto-migrate'))`);
      await c.query('CREATE TABLE IF NOT EXISTS _migrations (name TEXT PRIMARY KEY, applied_at TIMESTAMPTZ DEFAULT now())');
      if ((await c.query('SELECT 1 FROM _migrations WHERE name = $1', [m.name])).rows.length) return;
      await c.query(m.sql);
      await c.query('INSERT INTO _migrations (name) VALUES ($1)', [m.name]);
      console.log('auto-migrate: applied', m.name);
    });
  }
  applied = true;
}
