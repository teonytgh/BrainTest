import { randomInt } from 'node:crypto';
import {
  GIVEAWAY_KINDS,
  GIVEAWAY_TOP,
  MAX_GIVEAWAY_DAYS,
  MAX_GIVEAWAY_PLACES,
  MIN_REFERRAL_RACE_DEPOSIT,
  giveawayStatus,
  type GiveawayCard,
  type GiveawayDetail,
  type GiveawayKind,
  type GiveawayPlayer,
  type GiveawayPrize,
} from '../shared/giveaways';
import { round2 } from '../shared/money';
import { assertActive, type Viewer } from './auth';
import { publicName } from './catalog';
import { db, ms, num, one, q, tx, type Queryable } from './db';
import { addItemWager, giveItems } from './economy';
import { OWNER_IDS } from './env';
import { bad, notFound } from './errors';
import { channelStatus, channelUrl } from './freeGate';
import { afterResponse, broadcast } from './live';
import { appLink } from './notifications';
import { getSettings } from './settings';
import { isImageUrl } from './storage';
import { botApi, escapeHtml } from './telegram';
import { bool, int, money, oneOf, optStr, str, type Body } from './validate';

const DAY = 24 * 60 * 60 * 1000;
/** How many random draw winners may be checked against the channel at settlement (each check is a Bot API call). */
const MAX_CHANNEL_CHECKS = 30;

interface GiveawayRow {
  id: string;
  kind: GiveawayKind;
  title: string;
  description: string;
  conditions: string;
  banner: string | null;
  starts_at: string;
  ends_at: string;
  min_deposit: string;
  need_channel: boolean;
  /** Iteration 35: a brainrot deposit of this brainrot (this many) in the period. */
  need_brainrot?: string | null;
  need_brainrot_count?: number;
  status: 'active' | 'finished' | 'cancelled';
  created_at: string;
  settled_at: string | null;
}

interface PlayerRow {
  user_id: string;
  score: string;
  first_name: string;
  last_name: string | null;
  photo_url: string | null;
  public_id: string | null;
}

/**
 * Who may place: no active ban or freeze, and no staff — an admin credits brainrot deposits himself, so he could
 * win his own race with a deposit that never happened. `$staff` is the owners' IDs.
 */
const eligible = (staff: string) =>
  `NOT EXISTS (SELECT 1 FROM punishments p WHERE p.user_id = u.id AND p.revoked_at IS NULL AND (p.until IS NULL OR p.until > now()))
   AND NOT EXISTS (SELECT 1 FROM admins a WHERE a.user_id = u.id) AND u.id <> ALL(${staff}::bigint[])`;

/**
 * «Пополни брейнрота X» (iteration 35): how many of brainrot `$nb` the player brought in credited brainrot deposits
 * from $1 to $2 must reach `$nc`. With no brainrot asked ($nb NULL) it always holds. Iteration 39 (the owner: «чтоб
 * пополнившие через крипту и звёзды тоже входили»): Stars and crypto deposits in the period worth `$nc` × the brainrot's
 * deposit price meet it too.
 */
const brainrotOk = (nb: string, nc: string) =>
  `(${nb}::text IS NULL OR (SELECT coalesce(sum((it->>'count')::int), 0) FROM item_deposits d, jsonb_array_elements(d.items) it
     WHERE d.user_id = u.id AND d.status = 'credited' AND d.updated_at >= $1 AND d.updated_at < $2 AND it->>'brainrotId' = ${nb}) >= ${nc}
   OR (SELECT coalesce(sum(sp.credited), 0) FROM star_payments sp WHERE sp.user_id = u.id AND sp.created_at >= $1 AND sp.created_at < $2)
     >= ${nc} * (${NEED_PRICE(nb)}))`;

/** The coins that stand for one asked brainrot: its deposit-list price, else its catalog price. */
const NEED_PRICE = (nb: string) => `SELECT coalesce(di.price, b.price) FROM brainrots b LEFT JOIN deposit_items di ON di.brainrot_id = b.id WHERE b.id = ${nb}`;

const needOf = (g: GiveawayRow) => [g.need_brainrot ?? null, g.need_brainrot_count ?? 1] as const;

const isStaff = async (userId: number) => OWNER_IDS.includes(userId) || !!(await one('SELECT 1 FROM admins WHERE user_id = $1', [userId]));

/**
 * Net deposits per player from $1 to $2: Stars and credited brainrot deposits minus finished withdrawals, so a
 * deposit taken back out doesn't count.
 */
const NET_DEPOSITS = `
  SELECT user_id, sum(amt) AS net FROM (
    SELECT user_id, credited AS amt FROM star_payments WHERE created_at >= $1 AND created_at < $2
    UNION ALL SELECT user_id, credited FROM item_deposits WHERE status = 'credited' AND updated_at >= $1 AND updated_at < $2
    UNION ALL SELECT user_id, -value FROM withdrawals WHERE status = 'done' AND processed_at >= $1 AND processed_at < $2
  ) m GROUP BY user_id`;

/**
 * A race's standings, best first ($3 = the deposit threshold): the first $4 places plus player $5's own row, each
 * with its place and the size of the whole field.
 */
function raceSql(kind: 'deposit_race' | 'referral_race') {
  const scores =
    kind === 'deposit_race'
      ? `SELECT user_id, net AS score FROM net WHERE net > 0 AND net >= $3`
      : `SELECT f.referred_by AS user_id, count(*) AS score FROM users f JOIN net n ON n.user_id = f.id
         WHERE f.referred_by IS NOT NULL AND f.referred_at >= $1 AND f.referred_at < $2 AND n.net >= $3
         GROUP BY f.referred_by`;
  return `WITH net AS (${NET_DEPOSITS}), scores AS (${scores}), ranked AS (
      SELECT s.user_id, s.score, u.first_name, u.last_name, u.photo_url, u.public_id,
        row_number() OVER (ORDER BY s.score DESC, u.created_at, u.id) AS place, count(*) OVER () AS field
      FROM scores s JOIN users u ON u.id = s.user_id
      WHERE ${eligible('$6')} AND ${brainrotOk('$7', '$8')})
    SELECT * FROM ranked WHERE place <= $4 OR user_id = $5 ORDER BY place`;
}

const periodEnd = (g: GiveawayRow, now = Date.now()) => new Date(Math.min(ms(g.ends_at)!, now));

interface RankedRow extends PlayerRow {
  place: string;
  field: string;
}

async function raceStandings(c: Queryable, g: GiveawayRow, top: number, me = 0): Promise<RankedRow[]> {
  const { rows } = await c.query<RankedRow>(raceSql(g.kind as 'deposit_race' | 'referral_race'), [
    new Date(g.starts_at),
    periodEnd(g),
    num(g.min_deposit),
    top,
    me,
    OWNER_IDS,
    ...needOf(g),
  ]);
  return rows;
}

/**
 * How many of the asked brainrot the player brought in the period, and the Stars/crypto alternative: what they paid
 * and what it takes (null when no brainrot is asked).
 */
async function myBrainrots(c: Queryable, g: GiveawayRow, userId: number): Promise<{ have: number; paid: number; paidNeed: number } | null> {
  if (!g.need_brainrot) return null;
  const { rows } = await c.query<{ n: string; paid: string; price: string | null }>(
    `SELECT (SELECT coalesce(sum((it->>'count')::int), 0) FROM item_deposits d, jsonb_array_elements(d.items) it
             WHERE d.user_id = $3 AND d.status = 'credited' AND d.updated_at >= $1 AND d.updated_at < $2 AND it->>'brainrotId' = $4) AS n,
       (SELECT coalesce(sum(credited), 0) FROM star_payments WHERE user_id = $3 AND created_at >= $1 AND created_at < $2) AS paid,
       (${NEED_PRICE('$4')}) AS price`,
    [new Date(g.starts_at), periodEnd(g), userId, g.need_brainrot],
  );
  const r = rows[0];
  return { have: num(r?.n), paid: num(r?.paid), paidNeed: round2(num(r?.price) * (g.need_brainrot_count ?? 1)) };
}

/** The brainrot condition is met: enough of the brainrot brought, or Stars/crypto deposits worth as much. */
const broughtEnough = (b: { have: number; paid: number; paidNeed: number }, count: number) => b.have >= count || (b.paidNeed > 0 && b.paid >= b.paidNeed);

/** A player's own net deposits in the giveaway's period (draw requirements). */
async function myNet(c: Queryable, g: GiveawayRow, userId: number) {
  const { rows } = await c.query<{ net: string }>(`WITH net AS (${NET_DEPOSITS}) SELECT net FROM net WHERE user_id = $3`, [new Date(g.starts_at), periodEnd(g), userId]);
  return num(rows[0]?.net);
}

const player = (r: PlayerRow, place: number): GiveawayPlayer => ({
  place,
  name: publicName(r),
  photo: r.photo_url,
  playerId: r.public_id,
  score: num(r.score),
});

async function prizesOf(ids: number[]): Promise<Map<number, GiveawayPrize[]>> {
  const out = new Map<number, GiveawayPrize[]>();
  if (!ids.length) return out;
  const rows = await q<{ giveaway_id: string; place: number; brainrot_id: string }>(
    'SELECT giveaway_id, place, brainrot_id FROM giveaway_prizes WHERE giveaway_id = ANY($1) ORDER BY place',
    [ids],
  );
  for (const r of rows) {
    const list = out.get(num(r.giveaway_id)) ?? [];
    list.push({ place: r.place, brainrotId: r.brainrot_id });
    out.set(num(r.giveaway_id), list);
  }
  return out;
}

interface WinnerRow extends PlayerRow {
  giveaway_id: string;
  place: number;
  brainrot_id: string;
}

async function winnersOf(ids: number[], firstOnly: boolean): Promise<Map<number, (GiveawayPlayer & { brainrotId: string })[]>> {
  const out = new Map<number, (GiveawayPlayer & { brainrotId: string })[]>();
  if (!ids.length) return out;
  const rows = await q<WinnerRow>(
    `SELECT w.giveaway_id, w.place, w.brainrot_id, w.user_id, coalesce(w.score, 0) AS score, u.first_name, u.last_name, u.photo_url, u.public_id
     FROM giveaway_winners w JOIN users u ON u.id = w.user_id
     WHERE w.giveaway_id = ANY($1)${firstOnly ? ' AND w.place = 1' : ''} ORDER BY w.place`,
    [ids],
  );
  for (const r of rows) {
    const list = out.get(num(r.giveaway_id)) ?? [];
    list.push({ ...player(r, r.place), brainrotId: r.brainrot_id });
    out.set(num(r.giveaway_id), list);
  }
  return out;
}

function card(g: GiveawayRow, prizes: GiveawayPrize[], entries: number | null, winner: GiveawayCard['winner']): GiveawayCard {
  const startsAt = ms(g.starts_at)!;
  return {
    id: num(g.id),
    kind: g.kind,
    title: g.title,
    banner: g.banner,
    startsAt,
    endsAt: ms(g.ends_at)!,
    status: giveawayStatus({ status: g.status, startsAt }),
    prizes,
    entries,
    winner,
  };
}

// ---------- Player API ----------

/** Running and upcoming giveaways, then the last finished ones. */
export async function listGiveaways(): Promise<{ active: GiveawayCard[]; finished: GiveawayCard[] }> {
  const rows = await q<GiveawayRow & { entries: string }>(
    `(SELECT g.*, (SELECT count(*) FROM giveaway_entries e WHERE e.giveaway_id = g.id) AS entries FROM giveaways g WHERE g.status = 'active' ORDER BY g.ends_at LIMIT 20)
     UNION ALL
     (SELECT g.*, 0 AS entries FROM giveaways g WHERE g.status = 'finished' ORDER BY g.settled_at DESC LIMIT 10)`,
  );
  const ids = rows.map((r) => num(r.id));
  const [prizes, winners] = await Promise.all([prizesOf(ids), winnersOf(rows.filter((r) => r.status === 'finished').map((r) => num(r.id)), true)]);
  const cards = rows.map((r) => card(r, prizes.get(num(r.id)) ?? [], r.kind === 'draw' && r.status === 'active' ? num(r.entries) : null, winners.get(num(r.id))?.[0] ?? null));
  return { active: cards.filter((c) => c.status === 'active' || c.status === 'upcoming'), finished: cards.filter((c) => c.status === 'finished') };
}

async function loadGiveaway(c: Queryable, idParam: string, lock = false) {
  const id = int(idParam, 'розыгрыш');
  const { rows } = await c.query<GiveawayRow>(`SELECT * FROM giveaways WHERE id = $1${lock ? ' FOR UPDATE' : ''}`, [id]);
  if (!rows[0]) throw notFound('Розыгрыш не найден');
  return rows[0];
}

export async function giveawayDetail(v: Viewer, idParam: string): Promise<GiveawayDetail> {
  const g = await loadGiveaway(db, idParam);
  if (g.status === 'cancelled') throw notFound('Розыгрыш отменён');
  const id = num(g.id);
  const race = g.kind !== 'draw';
  const { freeGate } = await getSettings();
  const [prizes, winners, entries, standings, joined, net, myWin, brought] = await Promise.all([
    prizesOf([id]),
    winnersOf([id], false),
    one<{ n: string }>('SELECT count(*) AS n FROM giveaway_entries WHERE giveaway_id = $1', [id]),
    race && g.status === 'active' ? raceStandings(db, g, GIVEAWAY_TOP, v.id) : Promise.resolve([]),
    one('SELECT 1 FROM giveaway_entries WHERE giveaway_id = $1 AND user_id = $2', [id, v.id]),
    race ? Promise.resolve(0) : myNet(db, g, v.id),
    one<{ place: number; score: string | null }>('SELECT place, score FROM giveaway_winners WHERE giveaway_id = $1 AND user_id = $2', [id, v.id]),
    myBrainrots(db, g, v.id),
  ]);
  const needBrainrot =
    g.need_brainrot && brought
      ? { brainrotId: g.need_brainrot, count: g.need_brainrot_count ?? 1, have: brought.have, paid: brought.paid, paidNeed: brought.paidNeed }
      : null;
  const brainrotDone = !needBrainrot || broughtEnough(needBrainrot, needBrainrot.count);
  const won = winners.get(id) ?? [];
  const mine = standings.find((r) => num(r.user_id) === v.id);
  const channel = g.need_channel && freeGate.channel ? { username: freeGate.channel, url: channelUrl(freeGate.channel) } : null;
  return {
    ...card(g, prizes.get(id) ?? [], race ? null : num(entries?.n), won[0] ?? null),
    description: g.description,
    conditions: g.conditions,
    minDeposit: num(g.min_deposit),
    needBrainrot,
    channel,
    top: standings.filter((r) => num(r.place) <= GIVEAWAY_TOP).map((r) => player(r, num(r.place))),
    field: race ? num(standings[0]?.field) : num(entries?.n),
    me: {
      place: mine ? num(mine.place) : (myWin?.place ?? null),
      score: mine ? num(mine.score) : race ? num(myWin?.score) : net,
      joined: !!joined,
      eligible: race ? !!mine || !!myWin : net >= num(g.min_deposit) && brainrotDone,
    },
    winners: won,
  };
}

/** A draw entry: only while it runs, after the requirements (deposits in the period, the channel) are met. */
export async function joinGiveaway(v: Viewer, idParam: string) {
  assertActive(v);
  const g = await loadGiveaway(db, idParam);
  if (g.kind !== 'draw') throw bad('invalid', 'В гонке участвуют все — просто пополняй или приглашай друзей');
  const status = giveawayStatus({ status: g.status, startsAt: ms(g.starts_at)! });
  if (status === 'upcoming') throw bad('not_started', 'Розыгрыш ещё не начался');
  if (status !== 'active' || ms(g.ends_at)! <= Date.now()) throw bad('finished', 'Розыгрыш уже закончился');
  if (await isStaff(v.id)) throw bad('staff', 'Админы не участвуют в розыгрышах');
  const need = num(g.min_deposit);
  if (need > 0) {
    const net = await myNet(db, g, v.id);
    if (net < need) throw bad('need_deposit', `Нужно пополнить на ${need.toLocaleString('ru-RU')} B за время розыгрыша`, { need, have: net });
  }
  if (g.need_brainrot) {
    const brought = (await myBrainrots(db, g, v.id))!;
    const want = g.need_brainrot_count ?? 1;
    if (!broughtEnough(brought, want)) {
      const b = await one<{ name: string }>('SELECT name FROM brainrots WHERE id = $1', [g.need_brainrot]);
      throw bad(
        'need_brainrot',
        `Пополни ${b?.name ?? 'брейнрота'}${want > 1 ? ` ×${want}` : ''} или звёздами/криптой на ${brought.paidNeed.toLocaleString('ru-RU')} B за время розыгрыша (сейчас ${brought.have} шт. и ${brought.paid.toLocaleString('ru-RU')} B)`,
        { have: brought.have, want, paid: brought.paid, paidNeed: brought.paidNeed },
      );
    }
  }
  if (g.need_channel) {
    const { freeGate } = await getSettings();
    if (freeGate.channel && (await channelStatus(freeGate.channel, v.id)) === 'missing') {
      throw bad('need_channel', `Подпишись на канал ${freeGate.channel}`, { channel: freeGate.channel, url: channelUrl(freeGate.channel) });
    }
  }
  await q('INSERT INTO giveaway_entries (giveaway_id, user_id) VALUES ($1, $2) ON CONFLICT DO NOTHING', [num(g.id), v.id]);
  return { ok: true };
}

// ---------- Settlement ----------

/** Draw winners in random order, skipping those who no longer meet the requirements. */
async function drawWinners(g: GiveawayRow, places: number): Promise<PlayerRow[]> {
  const pool = await q<PlayerRow>(
    `WITH net AS (${NET_DEPOSITS})
     SELECT e.user_id, coalesce(n.net, 0) AS score, u.first_name, u.last_name, u.photo_url, u.public_id
     FROM giveaway_entries e JOIN users u ON u.id = e.user_id LEFT JOIN net n ON n.user_id = e.user_id
     WHERE e.giveaway_id = $4 AND coalesce(n.net, 0) >= $3 AND ${eligible('$5')} AND ${brainrotOk('$6', '$7')}`,
    [new Date(g.starts_at), periodEnd(g), num(g.min_deposit), num(g.id), OWNER_IDS, ...needOf(g)],
  );
  for (let i = pool.length - 1; i > 0; i--) {
    const j = randomInt(i + 1);
    [pool[i], pool[j]] = [pool[j]!, pool[i]!];
  }
  const { freeGate } = await getSettings();
  if (!g.need_channel || !freeGate.channel) return pool.slice(0, places);
  const out: PlayerRow[] = [];
  let checks = 0;
  for (const p of pool) {
    if (out.length >= places) break;
    // Past the check budget the rest are taken as they are (they were checked when they joined).
    if (checks++ < MAX_CHANNEL_CHECKS && (await channelStatus(freeGate.channel, num(p.user_id))) === 'missing') continue;
    out.push(p);
  }
  return out;
}

/**
 * Hands out the prizes: place k goes to the k-th of the standings (races) or of the random draw; places nobody took
 * stay unpaid. Runs once — the row lock and the status make a second call a no-op.
 */
export async function settleGiveaway(idParam: string, now = Date.now()) {
  const g0 = await loadGiveaway(db, idParam);
  if (g0.status !== 'active') return null;
  const prizes = (await prizesOf([num(g0.id)])).get(num(g0.id)) ?? [];
  const picked = g0.kind === 'draw' ? await drawWinners(g0, prizes.length) : null;
  const result = await tx(async (c) => {
    const g = await loadGiveaway(c, idParam, true);
    if (g.status !== 'active') return null;
    // Settling early closes the period now.
    if (ms(g.ends_at)! > now) g.ends_at = new Date(now).toISOString();
    const ranked = picked ?? (await raceStandings(c, g, prizes.length));
    // raceStandings is ordered by place: ranked[k - 1] is place k.
    const winners: { userId: number; place: number; brainrotId: string; score: number }[] = [];
    for (const prize of prizes) {
      const w = ranked[prize.place - 1];
      if (!w) continue;
      const userId = num(w.user_id);
      const [itemId] = await giveItems(c, userId, prize.brainrotId, 'giveaway');
      await addItemWager(c, userId, prize.brainrotId);
      await c.query('INSERT INTO giveaway_winners (giveaway_id, place, user_id, brainrot_id, item_id, score) VALUES ($1, $2, $3, $4, $5, $6)', [
        g.id,
        prize.place,
        userId,
        prize.brainrotId,
        itemId ?? null,
        g.kind === 'draw' ? null : num(w.score),
      ]);
      winners.push({ userId, place: prize.place, brainrotId: prize.brainrotId, score: num(w.score) });
    }
    await c.query(`UPDATE giveaways SET status = 'finished', settled_at = now(), ends_at = $2 WHERE id = $1`, [g.id, g.ends_at]);
    return { g, winners };
  });
  if (!result) return null;
  broadcast('giveaways');
  const { g, winners } = result;
  if (winners.length) {
    const names = new Map((await q<{ id: string; name: string }>('SELECT id, name FROM brainrots WHERE id = ANY($1)', [winners.map((w) => w.brainrotId)])).map((r) => [r.id, r.name]));
    await afterResponse(async () => {
      for (const w of winners) {
        await botApi('sendMessage', {
          chat_id: w.userId,
          parse_mode: 'HTML',
          text: `🏆 <b>Ты победил в «${escapeHtml(g.title)}»</b> — ${w.place} место!\nПриз <b>${escapeHtml(names.get(w.brainrotId) ?? w.brainrotId)}</b> уже в инвентаре.`,
          reply_markup: { inline_keyboard: [[{ text: '🎁 Открыть розыгрыш', web_app: { url: appLink(`giveaways/${num(g.id)}`) } }]] },
        });
      }
    });
  }
  return { id: num(g.id), winners: winners.length };
}

/** The tick settles giveaways whose time is up. */
export async function settleDueGiveaways(now = Date.now()) {
  const due = await q<{ id: string }>(`SELECT id FROM giveaways WHERE status = 'active' AND ends_at <= $1 ORDER BY ends_at LIMIT 3`, [new Date(now)]);
  const done = [];
  for (const { id } of due) {
    const r = await settleGiveaway(id, now);
    if (r) done.push(r);
  }
  return done;
}

// ---------- Admin ----------

function fields(body: Body, partial: boolean) {
  const out: Partial<{
    kind: GiveawayKind;
    title: string;
    description: string;
    conditions: string;
    banner: string | null;
    starts_at: Date;
    ends_at: Date;
    min_deposit: number;
    need_channel: boolean;
    need_brainrot: string | null;
    need_brainrot_count: number;
  }> = {};
  if (!partial) out.kind = oneOf<GiveawayKind>(body.kind, 'формат', GIVEAWAY_KINDS);
  if (!partial || body.title !== undefined) out.title = str(body.title, 'название', 2, 60).trim();
  if (!partial || body.description !== undefined) out.description = optStr(body.description, 'описание', 1500) ?? '';
  if (!partial || body.conditions !== undefined) out.conditions = optStr(body.conditions, 'условия', 800) ?? '';
  if (!partial || body.banner !== undefined) {
    if (body.banner === null || body.banner === '' || body.banner === undefined) out.banner = null;
    else if (isImageUrl(body.banner)) out.banner = body.banner;
    else throw bad('invalid', 'Загрузи баннер ещё раз');
  }
  if (!partial || body.startsAt !== undefined) out.starts_at = new Date(body.startsAt === undefined || body.startsAt === null ? Date.now() : int(body.startsAt, 'начало', 0));
  if (!partial || body.endsAt !== undefined) out.ends_at = new Date(int(body.endsAt, 'окончание', 0));
  if (!partial || body.minDeposit !== undefined) out.min_deposit = body.minDeposit === 0 || body.minDeposit === '' || body.minDeposit === undefined ? 0 : money(body.minDeposit, 'порог пополнений', 0, 10_000_000);
  if (!partial || body.needChannel !== undefined) out.need_channel = bool(body.needChannel);
  // «Пополни брейнрота X»: a brainrot from the deposit list, how many (1–50); empty = no such condition.
  if (!partial || body.needBrainrot !== undefined) {
    out.need_brainrot = body.needBrainrot === null || body.needBrainrot === '' || body.needBrainrot === undefined ? null : str(body.needBrainrot, 'брейнрот', 1, 80);
  }
  if (!partial || body.needBrainrotCount !== undefined) out.need_brainrot_count = body.needBrainrotCount === undefined || body.needBrainrotCount === '' ? 1 : int(body.needBrainrotCount, 'сколько штук', 1, 50);
  return out;
}

/** The asked brainrot must be one players can deposit. */
async function checkNeedBrainrot(c: Queryable, id: string | null | undefined) {
  if (!id) return;
  const { rows } = await c.query('SELECT 1 FROM deposit_items WHERE brainrot_id = $1', [id]);
  if (!rows[0]) throw bad('invalid', 'Этого брейнрота нет в списке пополнений — его нельзя внести');
}

/** Prize brainrots per place, 1…N in order, from the active catalog (brainrots only: they land in the inventory). */
async function prizeList(c: Queryable, raw: unknown): Promise<string[]> {
  if (!Array.isArray(raw) || raw.length < 1 || raw.length > MAX_GIVEAWAY_PLACES) throw bad('invalid', `Призовых мест — от 1 до ${MAX_GIVEAWAY_PLACES}`);
  if (!raw.every((x) => typeof x === 'string' && x.length > 0 && x.length <= 64)) throw bad('invalid', 'Выбери приз на каждое место');
  const list = raw as string[];
  const { rows } = await c.query<{ id: string }>(`SELECT id FROM brainrots WHERE id = ANY($1) AND status = 'active' AND kind = 'brainrot'`, [list]);
  const ok = new Set(rows.map((r) => r.id));
  const missing = list.findIndex((id) => !ok.has(id));
  if (missing >= 0) throw bad('invalid', `Приз за ${missing + 1} место не найден в каталоге`);
  return list;
}

function checkPeriod(g: { kind: GiveawayKind; starts_at: Date; ends_at: Date; min_deposit: number }, now = Date.now()) {
  if (Number.isNaN(g.starts_at.getTime()) || Number.isNaN(g.ends_at.getTime())) throw bad('invalid', 'Неверные даты');
  if (g.ends_at.getTime() <= now) throw bad('invalid', 'Окончание — в будущем');
  if (g.ends_at <= g.starts_at) throw bad('invalid', 'Окончание — позже начала');
  if (g.ends_at.getTime() - g.starts_at.getTime() > MAX_GIVEAWAY_DAYS * DAY) throw bad('invalid', `Не дольше ${MAX_GIVEAWAY_DAYS} дней`);
  if (g.kind === 'referral_race' && g.min_deposit < MIN_REFERRAL_RACE_DEPOSIT) {
    throw bad('invalid', `Порог для гонки приглашений — от ${MIN_REFERRAL_RACE_DEPOSIT} B: иначе считаются пустые аккаунты`);
  }
}

async function log(c: Queryable, admin: Viewer, action: string, details: Record<string, unknown>) {
  await c.query('INSERT INTO admin_log (admin_id, action, target_user, details) VALUES ($1, $2, NULL, $3::jsonb)', [admin.id, action, JSON.stringify(details)]);
}

export async function adminGiveaways() {
  const rows = await q<GiveawayRow & { entries: string; winners: string }>(
    `SELECT g.*, (SELECT count(*) FROM giveaway_entries e WHERE e.giveaway_id = g.id) AS entries,
       (SELECT count(*) FROM giveaway_winners w WHERE w.giveaway_id = g.id) AS winners
     FROM giveaways g ORDER BY (g.status = 'active') DESC, g.ends_at DESC LIMIT 100`,
  );
  const prizes = await prizesOf(rows.map((r) => num(r.id)));
  return rows.map((r) => ({
    ...card(r, prizes.get(num(r.id)) ?? [], num(r.entries), null),
    description: r.description,
    conditions: r.conditions,
    minDeposit: num(r.min_deposit),
    needChannel: r.need_channel,
    needBrainrot: r.need_brainrot ?? null,
    needBrainrotCount: r.need_brainrot_count ?? 1,
    winners: num(r.winners),
    settledAt: ms(r.settled_at),
  }));
}

export async function createGiveaway(admin: Viewer, body: Body) {
  const f = fields(body, false) as Required<ReturnType<typeof fields>>;
  checkPeriod(f);
  return tx(async (c) => {
    const prizes = await prizeList(c, body.prizes);
    const { rows } = await c.query<{ id: string }>(
      `INSERT INTO giveaways (kind, title, description, conditions, banner, starts_at, ends_at, min_deposit, need_channel, created_by)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10) RETURNING id`,
      [f.kind, f.title, f.description, f.conditions, f.banner, f.starts_at, f.ends_at, f.min_deposit, f.need_channel, admin.id],
    );
    const id = num(rows[0]!.id);
    await checkNeedBrainrot(c, f.need_brainrot);
    await c.query('UPDATE giveaways SET need_brainrot = $2, need_brainrot_count = $3 WHERE id = $1', [id, f.need_brainrot, f.need_brainrot_count]);
    for (const [i, brainrotId] of prizes.entries()) {
      await c.query('INSERT INTO giveaway_prizes (giveaway_id, place, brainrot_id) VALUES ($1, $2, $3)', [id, i + 1, brainrotId]);
    }
    await log(c, admin, 'giveaway_create', { id, kind: f.kind, title: f.title, prizes });
    return { id };
  });
}

/** Edits a giveaway that is still running (the format stays). */
export async function updateGiveaway(admin: Viewer, idParam: string, body: Body) {
  const f = fields(body, true);
  return tx(async (c) => {
    const g = await loadGiveaway(c, idParam, true);
    if (g.status !== 'active') throw bad('finished', 'Розыгрыш уже закрыт');
    const merged = {
      kind: g.kind,
      starts_at: f.starts_at ?? new Date(g.starts_at),
      ends_at: f.ends_at ?? new Date(g.ends_at),
      min_deposit: f.min_deposit ?? num(g.min_deposit),
    };
    checkPeriod(merged);
    await checkNeedBrainrot(c, f.need_brainrot);
    const sets: string[] = [];
    const params: unknown[] = [g.id];
    for (const [k, val] of Object.entries(f)) {
      params.push(val);
      sets.push(`${k} = $${params.length}`);
    }
    if (sets.length) await c.query(`UPDATE giveaways SET ${sets.join(', ')} WHERE id = $1`, params);
    if (body.prizes !== undefined) {
      const prizes = await prizeList(c, body.prizes);
      await c.query('DELETE FROM giveaway_prizes WHERE giveaway_id = $1', [g.id]);
      for (const [i, brainrotId] of prizes.entries()) {
        await c.query('INSERT INTO giveaway_prizes (giveaway_id, place, brainrot_id) VALUES ($1, $2, $3)', [g.id, i + 1, brainrotId]);
      }
    }
    await log(c, admin, 'giveaway_update', { id: num(g.id), fields: Object.keys(f), prizes: body.prizes !== undefined });
    return { ok: true };
  });
}

export async function settleGiveawayNow(admin: Viewer, idParam: string) {
  const r = await settleGiveaway(idParam);
  if (!r) throw bad('finished', 'Розыгрыш уже закрыт');
  await tx((c) => log(c, admin, 'giveaway_settle', r));
  return r;
}

export async function cancelGiveaway(admin: Viewer, idParam: string) {
  return tx(async (c) => {
    const g = await loadGiveaway(c, idParam, true);
    if (g.status !== 'active') throw bad('finished', 'Розыгрыш уже закрыт');
    await c.query(`UPDATE giveaways SET status = 'cancelled', settled_at = now() WHERE id = $1`, [g.id]);
    await log(c, admin, 'giveaway_cancel', { id: num(g.id), title: g.title });
    return { ok: true };
  });
}

