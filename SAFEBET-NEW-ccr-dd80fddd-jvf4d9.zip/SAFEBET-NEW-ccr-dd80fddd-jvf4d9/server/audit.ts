import type { Viewer } from './auth';
import { ensureSchema } from './autoMigrate';
import { ms, num, q } from './db';
import { forbidden, notFound } from './errors';
import { displayName, getUser } from './users';
import { int } from './validate';

/**
 * «Откуда инвентарь» (iteration 38, owners): where a player's coins and brainrots came from — paid stakes against what
 * they paid back per game, every free source (bonus/gift/ticket cases by case, sky, pass, cashback, referrals, admin
 * gifts), the inventory by source, the best drops and the friends they brought (the referral-farm signals: friends who
 * never deposited or played). Read-only.
 */
export async function playerAudit(admin: Viewer, idParam: string) {
  if (!admin.isOwner) throw forbidden('Проверку игрока видят только владельцы');
  const id = int(idParam, 'игрок');
  await ensureSchema();
  const user = await getUser(id);
  if (!user) throw notFound('Пользователь не найден');
  const [money, games, free, inventory, top, gifts, friends, other] = await Promise.all([
    q<{ stars: string; items: string; withdrawn: string; balance: string; demo_balance: string; ref_balance: string; tickets: number; wager_left: string; created_at: string }>(
      `SELECT (SELECT coalesce(sum(credited), 0) FROM star_payments WHERE user_id = $1) AS stars,
              (SELECT coalesce(sum(credited), 0) FROM item_deposits WHERE user_id = $1 AND status = 'credited') AS items,
              (SELECT coalesce(sum(value), 0) FROM withdrawals WHERE user_id = $1 AND status = 'done') AS withdrawn,
              u.balance, u.demo_balance, u.ref_balance, u.tickets, u.wager_left, u.created_at
       FROM users u WHERE u.id = $1`,
      [id],
    ),
    // Real stakes per game: what went in, what came back.
    q<{ game: string; n: number; staked: string; won: string; best: string | null }>(
      `SELECT game, count(*)::int AS n, coalesce(sum(stake_value), 0) AS staked, coalesce(sum(payout_value) FILTER (WHERE result = 'win'), 0) AS won,
              max(payout_value) FILTER (WHERE result = 'win') AS best
       FROM drops WHERE user_id = $1 AND stake_value > 0 AND NOT demo GROUP BY game ORDER BY 4 DESC`,
      [id],
    ),
    // Free openings and prizes (no stake): by game and case.
    q<{ game: string; case_id: string | null; n: number; won: string; best: string | null }>(
      `SELECT game, meta->>'caseId' AS case_id, count(*)::int AS n, coalesce(sum(payout_value), 0) AS won, max(payout_value) AS best
       FROM drops WHERE user_id = $1 AND stake_value = 0 AND result = 'win' AND NOT demo GROUP BY 1, 2 ORDER BY 4 DESC`,
      [id],
    ),
    q<{ source: string; demo: boolean; n: number; value: string }>(
      `SELECT i.source, i.demo, count(*)::int AS n, coalesce(sum(b.price), 0) AS value
       FROM inventory i JOIN brainrots b ON b.id = i.brainrot_id WHERE i.user_id = $1 GROUP BY 1, 2 ORDER BY 4 DESC`,
      [id],
    ),
    q<{ game: string; stake_value: string; payout_value: string | null; brainrot_id: string | null; case_id: string | null; created_at: string }>(
      `SELECT game, stake_value, payout_value, brainrot_id, meta->>'caseId' AS case_id, created_at FROM drops
       WHERE user_id = $1 AND result = 'win' AND NOT demo ORDER BY payout_value DESC NULLS LAST LIMIT 15`,
      [id],
    ),
    q<{ action: string; details: Record<string, unknown> | null; created_at: string; admin_id: string; first_name: string | null; last_name: string | null; username: string | null }>(
      `SELECT a.action, a.details, a.created_at, a.admin_id, u.first_name, u.last_name, u.username FROM admin_log a LEFT JOIN users u ON u.id = a.admin_id
       WHERE a.target_user = $1 AND a.action IN ('give_coins', 'give_brainrot', 'give_case', 'wager_clear') ORDER BY a.id DESC LIMIT 40`,
      [id],
    ),
    q<{ id: string; first_name: string; last_name: string | null; username: string | null; created_at: string; referred_at: string | null; deposited: string; staked: string; ref_case: string }>(
      `SELECT f.id, f.first_name, f.last_name, f.username, f.created_at, f.referred_at,
              (SELECT coalesce(sum(credited), 0) FROM star_payments WHERE user_id = f.id)
                + (SELECT coalesce(sum(credited), 0) FROM item_deposits WHERE user_id = f.id AND status = 'credited') AS deposited,
              (SELECT coalesce(sum(stake_value), 0) FROM drops WHERE user_id = f.id AND stake_value > 0 AND NOT demo) AS staked,
              (SELECT coalesce(sum(payout_value), 0) FROM drops WHERE user_id = f.id AND game = 'case' AND meta->>'caseId' = 'referral') AS ref_case
       FROM users f WHERE f.referred_by = $1 ORDER BY f.referred_at DESC NULLS LAST LIMIT 200`,
      [id],
    ),
    q<{ cashback: string; ref_paid: string; sky: string; pass: string; rank: string; consolation: string; giveaways: number; squid: number }>(
      `SELECT (SELECT coalesce(sum(amount), 0) FROM cashback_claims WHERE user_id = $1) AS cashback,
              (SELECT coalesce(sum(amount), 0) FROM ref_payouts WHERE referrer_id = $1) AS ref_paid,
              (SELECT coalesce(sum(value), 0) FROM sky_picks WHERE user_id = $1) AS sky,
              (SELECT coalesce(sum(value), 0) FROM pass_claims WHERE user_id = $1) AS pass,
              (SELECT coalesce(sum(value), 0) FROM rank_gifts WHERE user_id = $1) AS rank,
              (SELECT coalesce(sum(coins), 0) FROM consolations WHERE user_id = $1 AND opened_at IS NOT NULL) AS consolation,
              (SELECT count(*)::int FROM giveaway_winners WHERE user_id = $1) AS giveaways,
              (SELECT count(*)::int FROM squid_players WHERE user_id = $1 AND prize IS NOT NULL) AS squid`,
      [id],
    ),
  ]);
  const m = money[0]!;
  const deposited = num(m.stars) + num(m.items);
  const inv = inventory.map((r) => ({ source: r.source, demo: r.demo, count: r.n, value: num(r.value) }));
  const friendRows = friends.map((f) => ({
    id: num(f.id),
    name: displayName(f),
    at: ms(f.referred_at) ?? ms(f.created_at),
    deposited: num(f.deposited),
    staked: num(f.staked),
    refCase: num(f.ref_case),
  }));
  const o = other[0]!;
  return {
    user: { id, name: displayName(user), username: user.username, since: ms(m.created_at) },
    money: {
      deposited,
      stars: num(m.stars),
      items: num(m.items),
      withdrawn: num(m.withdrawn),
      balance: num(m.balance),
      demoBalance: num(m.demo_balance),
      refBalance: num(m.ref_balance),
      tickets: m.tickets,
      wagerLeft: num(m.wager_left),
      inventoryValue: inv.filter((r) => !r.demo).reduce((s, r) => s + r.value, 0),
      demoInventoryValue: inv.filter((r) => r.demo).reduce((s, r) => s + r.value, 0),
    },
    games: games.map((g) => ({ game: g.game, count: g.n, staked: num(g.staked), won: num(g.won), best: num(g.best) })),
    free: free.map((f) => ({ game: f.game, caseId: f.case_id, count: f.n, won: num(f.won), best: num(f.best) })),
    other: {
      cashback: num(o.cashback),
      refPaid: num(o.ref_paid),
      sky: num(o.sky),
      pass: num(o.pass),
      rankGifts: num(o.rank),
      consolation: num(o.consolation),
      giveaways: o.giveaways,
      squid: o.squid,
    },
    inventory: inv,
    top: top.map((t) => ({ game: t.game, stake: num(t.stake_value), value: num(t.payout_value), brainrotId: t.brainrot_id, caseId: t.case_id, at: ms(t.created_at) })),
    gifts: gifts.map((g) => ({
      action: g.action,
      details: g.details ?? {},
      at: ms(g.created_at),
      admin: g.first_name ? displayName({ id: g.admin_id, first_name: g.first_name, last_name: g.last_name, username: g.username }) : `ID ${g.admin_id}`,
    })),
    friends: {
      count: friendRows.length,
      deposited: friendRows.filter((f) => f.deposited > 0).length,
      /** Friends who never deposited nor played: the usual sign of accounts made for the referral case. */
      empty: friendRows.filter((f) => f.deposited === 0 && f.staked === 0).length,
      refCaseValue: friendRows.reduce((s, f) => s + f.refCase, 0),
      list: friendRows.slice(0, 60),
    },
  };
}
