import { useEffect, useState, type FormEvent } from 'react';
import { BrainrotThumb } from '../../components/BrainrotCard';
import { Coin } from '../../components/Coin';
import { MediaBadge, PLATFORM_LABEL, PlatformLogo } from '../../components/MediaBadge';
import { Sheet } from '../../components/Sheet';
import { Switch } from '../../components/Toggle';
import { DemoTag } from '../../components/DemoTag';
import { RankBadge } from '../../components/RankBadge';
import { RANKS } from '../../../shared/ranks';
import { REF_LEVELS } from '../../../shared/bonuses';
import { useCatalog, useMe } from '../../api/queries';
import type { MediaPlatform } from '../../../shared/types';
import { cx, formatCoins } from '../../lib/format';
import { navigate } from '../../lib/router';
import { prefillUser, takePrefilledUser } from './prefill';
import { AuditBlock } from './Audit';
import {
  BrainrotPicker,
  Card,
  ConfirmButton,
  Empty,
  Field,
  Segmented,
  UserField,
  UserLine,
  adminApi,
  formatWhen,
  notifiedText,
  useAdminAction,
  useAdminQuery,
  type AdminApi,
  type Data,
  type UserBrief,
} from './ui';

const untilFmt = new Intl.DateTimeFormat('ru-RU', { dateStyle: 'medium', timeStyle: 'short' });
const untilText = (until: number | null) => (until ? `до ${untilFmt.format(until)}` : 'навсегда');

// ---------- Give ----------

/** «Для демо» is remembered on this device (on by default: a gift is demo unless the admin says otherwise). */
const DEMO_KEY = 'brainrotcrash:admin-give-demo';

function savedDemo(): boolean {
  try {
    return localStorage.getItem(DEMO_KEY) !== 'off';
  } catch {
    return true;
  }
}

export function Give() {
  const [user, setUser] = useState(takePrefilledUser);
  const [type, setType] = useState<'coins' | 'brainrot' | 'case'>('coins');
  const [demo, setDemoState] = useState(savedDemo);
  const setDemo = (on: boolean) => {
    setDemoState(on);
    try {
      localStorage.setItem(DEMO_KEY, on ? 'on' : 'off');
    } catch {
      // Just not remembered.
    }
  };
  // «Без отыгрыша» (iteration 36, owners only): never remembered — a gift is wagered unless said otherwise each time.
  const [noWager, setNoWager] = useState(false);
  const me = useMe();
  const [amount, setAmount] = useState('100');
  const [brainrotId, setBrainrotId] = useState<string | null>(null);
  const [caseId, setCaseId] = useState<string | null>(null);
  const catalog = useCatalog();
  const give = useAdminAction(
    (body: object) => adminApi<Data<typeof AdminApi.give>>('/give', 'POST', body),
    { success: (r) => `${r.user.display}: выдано ${r.given} — ${notifiedText(r.notified)}` },
  );

  function submit(e: FormEvent) {
    e.preventDefault();
    give.mutate({ user, type, amount: Number(amount), brainrotId, caseId, demo, noWager: !demo && type !== 'case' && noWager });
  }

  return (
    <Card title="Выдача">
      <form className="aform" onSubmit={submit}>
        <UserField value={user} onChange={setUser} />
        <Segmented
          label="Что выдать"
          value={type}
          onChange={(t) => {
            setType(t);
            setAmount(t === 'coins' ? '100' : '1');
          }}
          options={[
            { value: 'coins', label: 'Монеты' },
            { value: 'brainrot', label: 'Брейнрот' },
            { value: 'case', label: 'Кейс' },
          ]}
        />
        {type === 'brainrot' && <BrainrotPicker value={brainrotId} onChange={setBrainrotId} />}
        {type === 'case' && (
          <div className="afield">
            <span className="afield__label">Кейс — игрок откроет его бесплатно</span>
            <div className="acase-pick" role="radiogroup" aria-label="Кейс">
              {catalog.cases.map((c) => (
                <button key={c.id} type="button" role="radio" aria-checked={caseId === c.id} className={cx('acase-pick__item', caseId === c.id && 'is-on')} onClick={() => setCaseId(c.id)}>
                  <img src={c.image} alt="" />
                  <span>{c.name}</span>
                </button>
              ))}
            </div>
          </div>
        )}
        <Field label={type === 'coins' ? 'Количество монет' : type === 'case' ? 'Сколько открытий' : 'Сколько штук'}>
          <span className="ainput">
            {type === 'coins' && <Coin size={18} />}
            <input inputMode="numeric" value={amount} onChange={(e) => setAmount(e.target.value.replace(/\D/g, '').slice(0, 9))} />
          </span>
        </Field>
        {type === 'coins' && (
          <div className="achips">
            {[100, 1000, 10000, 100000].map((n) => (
              <button key={n} type="button" className={cx('chip', String(n) === amount && 'is-active')} onClick={() => setAmount(String(n))}>
                +{formatCoins(n)}
              </button>
            ))}
          </div>
        )}
        <div className={cx('arow', 'agive-demo', demo && 'is-on')}>
          <div>
            <p className="arow__title">
              Для демо <DemoTag />
            </p>
            <p className="acard__text">
              {demo
                ? 'Играть можно во всё, кроме батлов, но вывести, разменять или потратить на свой промокод — нет. Всё, что выиграно с этого, тоже демо. Игрок и зрители видят метку «ДЕМО».'
                : 'Обычная выдача: как свои монеты и брейнроты — выводятся после отыгрыша. Выключай только для настоящих компенсаций.'}
            </p>
          </div>
          <Switch on={demo} onChange={setDemo} label="Для демо" />
        </div>
        {!demo && type !== 'case' && (
          <div className={cx('arow', noWager && 'is-on')}>
            <div>
              <p className="arow__title">Без отыгрыша</p>
              <p className="acard__text">
                {noWager
                  ? 'Можно вывести сразу, не отыгрывая. Только для настоящих компенсаций и призов, выданных вручную.'
                  : `Перед выводом игрок отыграет выданное ×${me.withdrawRules.wagerBonus.toLocaleString('ru-RU')} — как любой бонус.${me.user.isOwner ? '' : ' Выдать без отыгрыша может только владелец.'}`}
              </p>
            </div>
            {me.user.isOwner && <Switch on={noWager} onChange={setNoWager} label="Без отыгрыша" />}
          </div>
        )}
        <button type="submit" className="btn btn--primary btn--lg btn--block" disabled={give.isPending || !user || (type === 'brainrot' && !brainrotId) || (type === 'case' && !caseId)}>
          {demo ? 'Выдать демо' : 'Выдать'}
        </button>
      </form>
    </Card>
  );
}

// ---------- Punish ----------

export function Punish() {
  const [user, setUser] = useState(takePrefilledUser);
  const [kind, setKind] = useState<'ban' | 'freeze'>('ban');
  const [unit, setUnit] = useState<'day' | 'month' | 'year' | 'forever'>('day');
  const [amount, setAmount] = useState('1');
  const [reason, setReason] = useState('');
  const punish = useAdminAction(
    (body: object) => adminApi<Data<typeof AdminApi.punish>>('/punish', 'POST', body),
    { success: (r) => `${r.user.display}: ${kind === 'ban' ? 'бан' : 'заморозка'} ${untilText(r.until)} — ${notifiedText(r.notified)}` },
  );

  function submit(e: FormEvent) {
    e.preventDefault();
    punish.mutate({ user, kind, unit, amount: Number(amount), reason });
  }

  return (
    <Card title="Наказания">
      <form className="aform" onSubmit={submit}>
        <UserField value={user} onChange={setUser} />
        <Segmented
          label="Наказание"
          value={kind}
          onChange={setKind}
          options={[
            { value: 'ban', label: '⛔ Бан' },
            { value: 'freeze', label: '❄️ Заморозка' },
          ]}
        />
        <p className="acard__text">
          {kind === 'ban'
            ? 'Игрок не сможет открыть мини-приложение, а в бот придёт сообщение о блокировке.'
            : 'Игрок станет наблюдателем: смотреть можно, а играть, продавать, выводить и активировать промокоды — нет.'}
        </p>
        <div className="aduration">
          {unit !== 'forever' && (
            <span className="ainput ainput--short">
              <input inputMode="numeric" aria-label="Срок" value={amount} onChange={(e) => setAmount(e.target.value.replace(/\D/g, '').slice(0, 4))} />
            </span>
          )}
          <Segmented
            label="Единица срока"
            value={unit}
            onChange={setUnit}
            options={[
              { value: 'day', label: 'Дней' },
              { value: 'month', label: 'Мес.' },
              { value: 'year', label: 'Лет' },
              { value: 'forever', label: '∞' },
            ]}
          />
        </div>
        <Field label="Причина (увидит игрок)">
          <span className="ainput">
            <input value={reason} maxLength={200} placeholder="Необязательно" onChange={(e) => setReason(e.target.value)} />
          </span>
        </Field>
        <button type="submit" className="btn btn--danger btn--lg btn--block" disabled={punish.isPending || !user}>
          {kind === 'ban' ? 'Выдать бан' : 'Заморозить аккаунт'}
        </button>
      </form>
    </Card>
  );
}

// ---------- Blacklist ----------

type PunishmentRow = Data<typeof AdminApi.punishments>[number];

export function Blacklist() {
  const list = useAdminQuery<PunishmentRow[]>(['punishments'], '/punishments');
  const revoke = useAdminAction((id: number) => adminApi<{ notified: boolean }>(`/punishments/${id}/revoke`, 'POST'), {
    success: (r) => `Снято — ${notifiedText(r.notified)}`,
  });
  const active = (list.data ?? []).filter((p) => p.active);
  const past = (list.data ?? []).filter((p) => !p.active);

  return (
    <>
      <Card title={`Чёрный список · ${active.length}`}>
        {list.isPending && <Empty>Загружаем…</Empty>}
        {!list.isPending && !active.length && <Empty>Сейчас никто не наказан.</Empty>}
        <ul className="alist">
          {active.map((p) => (
            <li key={p.id} className="alist__row">
              <UserLine user={p.user} extra={<span className={cx('pill', p.kind === 'ban' ? 'pill--red' : 'pill--blue')}>{p.kind === 'ban' ? 'Бан' : 'Заморозка'}</span>} />
              <p className="alist__meta">
                {untilText(p.until)} · выдал {p.by ?? '—'} · {formatWhen(p.at)}
                {p.reason && <span className="alist__reason">«{p.reason}»</span>}
              </p>
              <ConfirmButton className="btn btn--ghost btn--sm" onConfirm={() => revoke.mutate(p.id)} disabled={revoke.isPending}>
                {p.kind === 'ban' ? 'Разблокировать' : 'Разморозить'}
              </ConfirmButton>
            </li>
          ))}
        </ul>
      </Card>
      {past.length > 0 && (
        <Card title="История">
          <ul className="alist alist--compact">
            {past.slice(0, 40).map((p) => (
              <li key={p.id} className="alist__row">
                <UserLine user={p.user} extra={<span className="pill">{p.revokedAt ? 'снято' : 'истекло'}</span>} />
                <p className="alist__meta">
                  {p.kind === 'ban' ? 'Бан' : 'Заморозка'} {untilText(p.until)} · {formatWhen(p.at)}
                </p>
              </li>
            ))}
          </ul>
        </Card>
      )}
    </>
  );
}

// ---------- Users ----------

export function Users() {
  const [q, setQ] = useState('');
  const [openId, setOpenId] = useState<number | null>(null);
  const list = useAdminQuery<UserBrief[]>(['users', q], `/users?q=${encodeURIComponent(q.trim())}`);
  return (
    <Card title="Игроки">
      <span className="ainput ainput--icon">
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="@username, имя, ID или публичный ID" aria-label="Поиск игрока" />
      </span>
      <ul className="alist">
        {(list.data ?? []).map((u) => (
          <li key={u.id}>
            <button type="button" className="alist__btn" onClick={() => setOpenId(u.id)}>
              <UserLine
                user={u}
                extra={
                  <span className="auser__balance">
                    {formatCoins(u.balance)} <Coin size={12} />
                  </span>
                }
              />
            </button>
          </li>
        ))}
      </ul>
      {list.data?.length === 0 && <Empty>Никого не нашли.</Empty>}
      <UserSheet id={openId} onClose={() => setOpenId(null)} />
    </Card>
  );
}

/**
 * A partner (a blogger who brings players) gets their own referral percent from the first friend on, within the usual
 * levels' range (server/growth.ts setPartner). Owners only.
 */
function PartnerField({ userId, percent }: { userId: number; percent: number | null }) {
  const [value, setValue] = useState(percent === null ? '' : String(percent));
  useEffect(() => setValue(percent === null ? '' : String(percent)), [userId, percent]);
  const save = useAdminAction((body: { percent: number | null }) => adminApi<{ percent: number | null }>(`/users/${userId}/partner`, 'POST', body), {
    success: (r) => (r.percent === null ? 'Партнёрский процент снят — обычные уровни' : `Партнёр: ${r.percent}% с пополнений друзей`),
  });
  const min = REF_LEVELS[0]!.percent;
  const max = REF_LEVELS[REF_LEVELS.length - 1]!.percent;
  const n = Number(value.replace(',', '.'));
  const valid = value !== '' && Number.isFinite(n) && n >= min && n <= max;
  return (
    <Field label="Партнёр (процент с пополнений друзей)" hint={`${min}–${max} %: сразу, без набора друзей. Пусто — обычные уровни. Выше ${max} % нельзя: депозит, прокрученный через кейсы, начнёт стоить больше, чем приносит.`}>
      <span className="ainput">
        <input inputMode="decimal" value={value} onChange={(e) => setValue(e.target.value.replace(/[^\d.,]/g, '').slice(0, 5))} placeholder={percent === null ? 'Обычный игрок' : ''} aria-label="Процент партнёра" />
        <span className="ainput__suffix">%</span>
        <button type="button" className="btn btn--primary btn--sm" disabled={!valid || save.isPending || n === percent} onClick={() => save.mutate({ percent: n })}>
          Сохранить
        </button>
        {percent !== null && (
          <ConfirmButton className="btn btn--ghost btn--sm" disabled={save.isPending} onConfirm={() => save.mutate({ percent: null })}>
            Снять
          </ConfirmButton>
        )}
      </span>
    </Field>
  );
}

/** «Снять отыгрыш» (owners only): the player may withdraw at once; the server logs what was left. */
function ClearWager({ userId, left }: { userId: number; left: number }) {
  const clear = useAdminAction(() => adminApi<{ cleared: number }>(`/users/${userId}/wager/clear`, 'POST'), {
    success: (r) => `Отыгрыш снят (было ${formatCoins(r.cleared)} B) — вывод открыт`,
  });
  return (
    <Field label="Отыгрыш" hint="Снимать — только по делу (компенсация, ошибка). Иначе пополнение и бонусы уходят на вывод, не сыграв.">
      <span className="ainput">
        <span className="ainput__text">осталось {formatCoins(left)} B</span>
        <ConfirmButton className="btn btn--ghost btn--sm" disabled={clear.isPending} onConfirm={() => clear.mutate(undefined)}>
          Снять отыгрыш
        </ConfirmButton>
      </span>
    </Field>
  );
}

function UserSheet({ id, onClose }: { id: number | null; onClose: () => void }) {
  const catalog = useCatalog();
  const me = useMe();
  const detail = useAdminQuery<Data<typeof AdminApi.userDetail>>(['user', id], `/users/${id}`, id !== null);
  const [coins, setCoins] = useState('');
  const [selected, setSelected] = useState<number[]>([]);
  // The sheet stays mounted between players: what was typed for one must never be taken from the next.
  useEffect(() => {
    setCoins('');
    setSelected([]);
  }, [id]);
  const take = useAdminAction((body: object) => adminApi<{ coins: number; items: number }>('/take', 'POST', body), {
    success: (r) => `Забрано: ${formatCoins(r.coins)} B и ${r.items} предм.`,
  });
  const d = id ? detail.data : undefined;
  const ref = d ? (d.user.username ? `@${d.user.username}` : String(d.user.id)) : '';

  return (
    <Sheet open={id !== null} onClose={onClose} title="Игрок">
      {!d ? (
        <Empty>Загружаем…</Empty>
      ) : (
        <div className="aform">
          <UserLine user={d.user} extra={d.user.isOwner ? <span className="pill pill--green">Владелец</span> : d.user.isAdmin ? <span className="pill pill--blue">Админ</span> : null} />
          <dl className="adl">
            <div>
              <dt>Баланс</dt>
              <dd>
                {formatCoins(d.user.balance)} B
                {d.user.demoBalance > 0 && (
                  <small className="adl__demo">
                    <DemoTag /> {formatCoins(d.user.demoBalance)} B
                  </small>
                )}
              </dd>
            </div>
            <div>
              <dt>Публичный ID</dt>
              <dd>{d.user.publicId}</dd>
            </div>
            <div>
              <dt>Кейсов / апгрейдов</dt>
              <dd>
                {d.user.stats.cases} / {d.user.stats.upgrades}
              </dd>
            </div>
            <div>
              <dt>Дайс / краш</dt>
              <dd>
                {d.user.stats.dice} / {d.user.stats.crash}
              </dd>
            </div>
            <div>
              <dt>Выведено</dt>
              <dd>{formatCoins(d.user.stats.withdrawn)} B</dd>
            </div>
            <div>
              <dt>Был в сети</dt>
              <dd>{formatWhen(d.user.lastSeen)}</dd>
            </div>
            <div>
              <dt>Пополнено · ранг</dt>
              <dd className="adl__rank">
                {formatCoins(d.user.deposited)} B · <RankBadge rank={RANKS[d.user.rank]!} size={20} /> {RANKS[d.user.rank]!.name}
              </dd>
            </div>
            <div>
              <dt>Отыгрыш</dt>
              <dd>{d.user.wager.left > 0 ? `осталось ${formatCoins(d.user.wager.left)} из ${formatCoins(d.user.wager.total)} B` : 'отыгран — вывод открыт'}</dd>
            </div>
            {d.user.source && (
              <div>
                <dt>Пришёл по ссылке</dt>
                <dd>{d.user.source}</dd>
              </div>
            )}
          </dl>
          {d.user.media && <MediaBadge platform={d.user.media} />}
          {me.user.isOwner && <PartnerField userId={d.user.id} percent={d.user.refPercent} />}
          {me.user.isOwner && d.user.wager.left > 0 && <ClearWager userId={d.user.id} left={d.user.wager.left} />}
          {me.user.isOwner && <AuditBlock key={d.user.id} userId={d.user.id} />}
          <div className="abuttons">
            <button
              type="button"
              className="btn btn--primary btn--sm"
              onClick={() => {
                prefillUser(ref);
                navigate('admin', 'give');
              }}
            >
              Выдать
            </button>
            <button
              type="button"
              className="btn btn--danger btn--sm"
              onClick={() => {
                prefillUser(ref);
                navigate('admin', 'punish');
              }}
            >
              Наказать
            </button>
          </div>

          <Field label="Забрать монеты" hint={d.user.demoBalance > 0 ? 'Сначала уходят демо-монеты' : undefined}>
            <span className="ainput">
              <Coin size={18} />
              <input inputMode="numeric" value={coins} onChange={(e) => setCoins(e.target.value.replace(/\D/g, '').slice(0, 12))} placeholder="Сколько" />
              <ConfirmButton className="btn btn--ghost btn--sm" disabled={!coins || take.isPending} onConfirm={() => take.mutate({ userId: d.user.id, coins: Number(coins) })}>
                Забрать
              </ConfirmButton>
            </span>
          </Field>

          <div className="afield">
            <span className="afield__label">
              Инвентарь · {d.inventory.length} шт.
              {d.inventory.some((i) => i.demo) && ` · демо ${d.inventory.filter((i) => i.demo).length}`} {selected.length > 0 && `· выбрано ${selected.length}`}
            </span>
            <div className="apick-grid apick-grid--small">
              {d.inventory.map((i) => {
                const b = catalog.byId.get(i.brainrotId);
                if (!b) return null;
                const on = selected.includes(i.id);
                return (
                  <button
                    key={i.id}
                    type="button"
                    className={cx('apick-grid__item', on && 'is-on', i.demo && 'is-demo')}
                    aria-pressed={on}
                    onClick={() => setSelected((s) => (on ? s.filter((x) => x !== i.id) : [...s, i.id]))}
                  >
                    <BrainrotThumb brainrot={b} size={44} />
                    <span className="apick-grid__name">{b.name}</span>
                    {i.demo && <DemoTag corner />}
                  </button>
                );
              })}
            </div>
            {selected.length > 0 && (
              <ConfirmButton
                className="btn btn--danger btn--sm btn--block"
                disabled={take.isPending}
                onConfirm={() => {
                  take.mutate({ userId: d.user.id, itemIds: selected });
                  setSelected([]);
                }}
              >
                Забрать выбранные ({selected.length})
              </ConfirmButton>
            )}
          </div>

          {d.punishments.length > 0 && (
            <div className="afield">
              <span className="afield__label">Наказания</span>
              <ul className="alist alist--compact">
                {d.punishments.map((p) => (
                  <li key={p.id} className="alist__row">
                    <span className={cx('pill', p.active ? (p.kind === 'ban' ? 'pill--red' : 'pill--blue') : '')}>
                      {p.kind === 'ban' ? 'Бан' : 'Заморозка'} {p.active ? 'активен' : 'снят'}
                    </span>
                    <span className="alist__meta">
                      {untilText(p.until)} · {formatWhen(p.at)}
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}
    </Sheet>
  );
}

// ---------- Media ----------

const PLATFORMS: MediaPlatform[] = ['tiktok', 'youtube', 'twitch'];

export function Media() {
  const [user, setUser] = useState('');
  const [platform, setPlatform] = useState<MediaPlatform>('tiktok');
  const list = useAdminQuery<UserBrief[]>(['media'], '/media');
  const grant = useAdminAction((body: object) => adminApi<Data<typeof AdminApi.setMedia>>('/media', 'POST', body), {
    success: (r) => `${r.user.display} теперь Партнёр — ${notifiedText(r.notified)}`,
  });
  const remove = useAdminAction((id: number) => adminApi(`/media/${id}`, 'DELETE'), { success: 'Статус партнёра снят' });

  return (
    <>
      <Card title="Медиа-партнёры">
        <p className="acard__text">Партнёр получает в профиле значок «Партнёр» с логотипом своей площадки.</p>
        <form
          className="aform"
          onSubmit={(e) => {
            e.preventDefault();
            grant.mutate({ user, platform });
          }}
        >
          <UserField value={user} onChange={setUser} />
          <Segmented
            label="Площадка"
            value={platform}
            onChange={setPlatform}
            options={PLATFORMS.map((p) => ({
              value: p,
              label: (
                <>
                  <PlatformLogo platform={p} /> {PLATFORM_LABEL[p]}
                </>
              ),
            }))}
          />
          <div className="apreview">
            <span className="afield__label">Так будет в профиле</span>
            <MediaBadge platform={platform} />
          </div>
          <button type="submit" className="btn btn--primary btn--block" disabled={!user || grant.isPending}>
            Выдать статус «Партнёр»
          </button>
        </form>
      </Card>
      <Card title={`Партнёры · ${list.data?.length ?? 0}`}>
        {list.data?.length === 0 && <Empty>Партнёров пока нет.</Empty>}
        <ul className="alist">
          {(list.data ?? []).map((u) => (
            <li key={u.id} className="alist__row">
              <UserLine user={u} extra={u.media && <MediaBadge platform={u.media} />} />
              <ConfirmButton className="btn btn--ghost btn--sm" onConfirm={() => remove.mutate(u.id)}>
                Снять
              </ConfirmButton>
            </li>
          ))}
        </ul>
      </Card>
    </>
  );
}

// ---------- Admins ----------

export function Admins() {
  const me = useMe();
  const [user, setUser] = useState('');
  const list = useAdminQuery<Data<typeof AdminApi.admins>>(['admins'], '/admins');
  const add = useAdminAction((body: object) => adminApi<Data<typeof AdminApi.addAdmin>>('/admins', 'POST', body), {
    success: (r) => `${r.user.display} теперь админ — ${notifiedText(r.notified)}`,
  });
  const remove = useAdminAction((id: number) => adminApi(`/admins/${id}`, 'DELETE'), { success: 'Админ снят' });

  return (
    <>
      <Card title="Владельцы">
        <p className="acard__text">Владельцев нельзя снять, забанить или заморозить.</p>
        <ul className="alist">
          {(list.data?.owners ?? []).map((o) => (
            <li key={o.id} className="alist__row">
              {'publicId' in o ? <UserLine user={o} extra={<span className="pill pill--green">Владелец</span>} /> : <span className="auser__name">{o.display} — ещё не заходил</span>}
            </li>
          ))}
        </ul>
      </Card>
      <Card title={`Админы · ${list.data?.admins.length ?? 0}`}>
        {list.data?.admins.length === 0 && <Empty>Других админов нет.</Empty>}
        <ul className="alist">
          {(list.data?.admins ?? []).map((a) => (
            <li key={a.id} className="alist__row">
              <UserLine user={a} />
              {me.user.isOwner && (
                <ConfirmButton className="btn btn--ghost btn--sm" onConfirm={() => remove.mutate(a.id)}>
                  Снять
                </ConfirmButton>
              )}
            </li>
          ))}
        </ul>
        {me.user.isOwner ? (
          <form
            className="aform"
            onSubmit={(e) => {
              e.preventDefault();
              add.mutate({ user });
              setUser('');
            }}
          >
            <UserField value={user} onChange={setUser} label="Новый админ" />
            <button type="submit" className="btn btn--primary btn--block" disabled={!user || add.isPending}>
              Выдать админку
            </button>
          </form>
        ) : (
          <p className="acard__text">Добавлять и снимать админов могут только владельцы.</p>
        )}
      </Card>
    </>
  );
}
