import '../../styles/admin.css';
import { Icon, type IconName } from '../../components/Icon';
import { useMe } from '../../api/queries';
import { cx, formatCoins } from '../../lib/format';
import { routeHref } from '../../lib/router';
import { Catalog, Cases, Promos, Titles } from './Content';
import { Admins, Blacklist, Give, Media, Punish, Users } from './People';
import { ItemDeposits } from './Deposits';
import { AdminGiveaways } from './Giveaways';
import { Announce, DangerZone } from './Owner';
import { Economy, Sources } from './Growth';
import { Logs, Luck, Maintenance, Payments, Withdrawals } from './System';
import { Card, type AdminApi, type Data, useAdminQuery } from './ui';

export const SECTIONS: { id: string; label: string; icon: IconName; owner?: boolean }[] = [
  { id: 'overview', label: 'Обзор', icon: 'gauge' },
  { id: 'give', label: 'Выдача', icon: 'gift' },
  { id: 'punish', label: 'Наказания', icon: 'shield' },
  { id: 'blacklist', label: 'Чёрный список', icon: 'close' },
  { id: 'promos', label: 'Промокоды', icon: 'tag' },
  { id: 'media', label: 'Медиа', icon: 'sparkle' },
  { id: 'maintenance', label: 'Тех. работы', icon: 'settings' },
  { id: 'catalog', label: 'Каталог', icon: 'box' },
  { id: 'cases', label: 'Кейсы', icon: 'bag' },
  { id: 'titles', label: 'Титулы', icon: 'trophy' },
  { id: 'users', label: 'Игроки', icon: 'home' },
  { id: 'withdrawals', label: 'Выводы', icon: 'arrowDown' },
  { id: 'payments', label: 'Платежи', icon: 'star' },
  { id: 'deposits', label: 'Пополнения', icon: 'box' },
  { id: 'luck', label: 'Ивенты', icon: 'sparkle' },
  { id: 'giveaways', label: 'Розыгрыши', icon: 'trophy' },
  { id: 'admins', label: 'Админы', icon: 'shield' },
  { id: 'logs', label: 'Журнал', icon: 'quests' },
  { id: 'economy', label: 'Экономика', icon: 'gauge', owner: true },
  { id: 'sources', label: 'Источники', icon: 'users', owner: true },
  { id: 'announce', label: 'Рассылка', icon: 'bot', owner: true },
  { id: 'danger', label: 'Опасная зона', icon: 'trash', owner: true },
];

/** The sections this admin may open: owners also get the economy, the traffic sources, announcements and the danger zone. */
function useSections() {
  const me = useMe();
  return SECTIONS.filter((s) => !s.owner || me.user.isOwner);
}

export function Admin({ section }: { section: string | null }) {
  const sections = useSections();
  const current = sections.find((s) => s.id === section)?.id ?? 'overview';
  return (
    <section className="admin" aria-labelledby="admin-title">
      <h1 id="admin-title" className="page-title">
        Админ-панель
      </h1>
      <nav className="admin-nav" aria-label="Разделы админки">
        {sections.map((s) => (
          <a key={s.id} href={routeHref('admin', s.id)} className={cx('admin-nav__link', current === s.id && 'is-on', s.id === 'danger' && 'admin-nav__link--danger')} aria-current={current === s.id ? 'page' : undefined}>
            <Icon name={s.icon} size={16} />
            {s.label}
          </a>
        ))}
      </nav>
      <div className="admin__body">
        {current === 'overview' && <Overview />}
        {current === 'give' && <Give />}
        {current === 'punish' && <Punish />}
        {current === 'blacklist' && <Blacklist />}
        {current === 'promos' && <Promos />}
        {current === 'media' && <Media />}
        {current === 'maintenance' && <Maintenance />}
        {current === 'catalog' && <Catalog />}
        {current === 'cases' && <Cases />}
        {current === 'titles' && <Titles />}
        {current === 'users' && <Users />}
        {current === 'withdrawals' && <Withdrawals />}
        {current === 'payments' && <Payments />}
        {current === 'deposits' && <ItemDeposits />}
        {current === 'luck' && <Luck />}
        {current === 'giveaways' && <AdminGiveaways />}
        {current === 'admins' && <Admins />}
        {current === 'logs' && <Logs />}
        {current === 'economy' && <Economy />}
        {current === 'sources' && <Sources />}
        {current === 'announce' && <Announce />}
        {current === 'danger' && <DangerZone />}
      </div>
    </section>
  );
}

const TILES: { key: string; label: string; coins?: boolean }[] = [
  { key: 'users', label: 'Игроков' },
  { key: 'active24', label: 'Активны за 24 ч' },
  { key: 'games24', label: 'Игр за 24 ч' },
  { key: 'cases_total', label: 'Кейсов открыто' },
  { key: 'stars24', label: 'Звёзд за 24 ч' },
  { key: 'stars', label: 'Звёзд всего' },
  { key: 'coins', label: 'Монет на балансах', coins: true },
  { key: 'items', label: 'Предметов у игроков' },
  { key: 'withdrawals', label: 'Выводов в очереди' },
  { key: 'bans', label: 'Активных банов' },
  { key: 'freezes', label: 'Заморозок' },
];

function Overview() {
  const me = useMe();
  const sections = useSections();
  const stats = useAdminQuery<Data<typeof AdminApi.stats>>(['stats'], '/stats');
  return (
    <>
      <Card title={`Привет, ${me.user.username ? `@${me.user.username}` : me.user.name}`}>
        <p className="acard__text">{me.user.isOwner ? 'Ты владелец — доступно всё, включая управление админами.' : 'Ты админ. Управлять админами могут только владельцы.'}</p>
      </Card>
      <div className="atiles">
        {TILES.map((t) => (
          <div key={t.key} className={cx('atile', t.key === 'withdrawals' && (stats.data?.withdrawals ?? 0) > 0 && 'is-alert')}>
            <span className="atile__value">{stats.data ? formatCoins(stats.data[t.key] ?? 0) : '…'}</span>
            <span className="atile__label">{t.label}</span>
          </div>
        ))}
      </div>
      <div className="ashortcuts">
        {sections.slice(1).map((s) => (
          <a key={s.id} className="ashortcut" href={routeHref('admin', s.id)}>
            <Icon name={s.icon} size={20} />
            {s.label}
          </a>
        ))}
      </div>
    </>
  );
}
