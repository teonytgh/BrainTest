import { SKY_CHUNK, SKY_HIT_REACH, SKY_HP, SKY_PICK_RADIUS, SKY_SPEED, chunkCoins, chunkOf, naturalEgg, rand01, type SkyCoin } from '../../../shared/sky';
import { RES, type ChunkPaint, type Thing, type ThingKind } from './terrain';
import layout from './sprites.json';

/**
 * «Небо Meowl» on a canvas: the map comes in chunks drawn by Web Workers (terrain.ts), the camera follows Meowl, and
 * every frame draws the ground, cloud shadows, coins, trees and houses, eggs, the other players, Meowl, the clouds
 * above and the little effects. Picks are only proposed here (`onPick`): the page asks the server and reports back
 * (`picked`, `refused`). Only transform/opacity-like canvas work per frame; nothing allocates much.
 */

type SpriteName = ThingKind | 'meowl-broom';
/** `split`: where the broom's bristles start (they flutter on their own). */
type SpriteInfo = { w: number; h: number; ax: number; ay: number; upp: number; split?: number };
const SPRITES = layout as Record<string, SpriteInfo>;

interface Chunk {
  ground: HTMLCanvasElement;
  things: Thing[];
  coins: SkyCoin[];
  egg: SkyCoin | null;
}

interface Other {
  id: number;
  name: string;
  x: number;
  y: number;
  h: number;
  tx: number;
  ty: number;
  th: number;
  seen: boolean;
  /** How fast they turn (rad/s, smoothed): the lean of the broom. */
  turn: number;
  speed: number;
  hp: number;
  ko: boolean;
  swingAt: number;
}

interface Effect {
  x: number;
  y: number;
  text: string;
  born: number;
  big: boolean;
  hit?: boolean;
}

export interface EngineOptions {
  seed: number;
  start: { x: number; y: number };
  taken: Iterable<string>;
  eggs: { key: string; x: number; y: number }[];
  capped: boolean;
  me: number;
  onPick: (key: string, kind: 'coin' | 'egg') => void;
}

const COIN_SIZE = 28;
/** The broom Meowl (iteration 37, the owner's art): one picture, its bristles drawn apart so they flutter. */
const MEOWL = 'meowl-broom';
const EGG_SIZE = 64;
const KEEP_CHUNKS = 4;
const WIND = { x: 9, y: 4 };

/** A new player in sight: full HP, standing, never swung. */
const FRESH = { turn: 0, speed: 0, hp: SKY_HP, ko: false, swingAt: -10 };

const img = (src: string) => {
  const i = new Image();
  i.decoding = 'async';
  i.src = src;
  return i;
};

function cloudSprite(seed: number): HTMLCanvasElement {
  const c = document.createElement('canvas');
  c.width = 320;
  c.height = 200;
  const g = c.getContext('2d')!;
  for (let i = 0; i < 9; i++) {
    const x = 70 + rand01(seed, i, 1) * 180;
    const y = 70 + rand01(seed, i, 2) * 60;
    const r = 34 + rand01(seed, i, 3) * 40;
    const grad = g.createRadialGradient(x, y - r * 0.2, r * 0.1, x, y, r);
    grad.addColorStop(0, 'rgba(255,255,255,0.95)');
    grad.addColorStop(0.7, 'rgba(244,248,255,0.8)');
    grad.addColorStop(1, 'rgba(230,238,250,0)');
    g.fillStyle = grad;
    g.beginPath();
    g.arc(x, y, r, 0, Math.PI * 2);
    g.fill();
  }
  return c;
}

export class SkyEngine {
  x: number;
  y: number;
  vx = 0;
  vy = 0;
  heading = -Math.PI / 2;
  /** Wanted direction, length 0…1 (joystick, keys or the mouse). */
  input = { x: 0, y: 0 };
  capped: boolean;
  zoom = 1;
  readonly others = new Map<number, Other>();
  /** Fights (iteration 37): on/off, our HP, knocked out, our last swing (engine time). */
  fighting = false;
  hp = SKY_HP;
  ko = false;
  private swingAt = -10;
  private turn = 0;
  private trail: { x: number; y: number; born: number }[] = [];
  private trailAt = 0;
  private readonly swordImg = img('/squid/sword.webp');

  private readonly canvas: HTMLCanvasElement;
  private readonly ctx: CanvasRenderingContext2D;
  private readonly seed: number;
  private readonly me: number;
  private readonly onPick: EngineOptions['onPick'];
  private readonly taken = new Set<string>();
  private readonly pending = new Set<string>();
  private readonly eggs = new Map<string, { x: number; y: number }>();
  private readonly chunks = new Map<string, Chunk | null>();
  private readonly queue: [number, number][] = [];
  private readonly workers: { w: Worker; busy: boolean }[] = [];
  private readonly sprites = new Map<string, HTMLImageElement>();
  /** Meowl as a dark silhouette: his shadow on the ground.  */
  private readonly shadows = new Map<string, HTMLCanvasElement>();
  private readonly coinImg = img('/coin-256.webp');
  private readonly eggImg = img('/sky/egg.webp');
  private readonly clouds = [0, 1, 2, 3].map((k) => cloudSprite(k + 17));
  /** The same clouds in one dark tone: their shadows on the ground. */
  private readonly cloudShadows = this.clouds.map((c) => {
    const d = document.createElement('canvas');
    d.width = c.width;
    d.height = c.height;
    const g = d.getContext('2d')!;
    g.drawImage(c, 0, 0);
    g.globalCompositeOperation = 'source-in';
    g.fillStyle = '#0d2a2a';
    g.fillRect(0, 0, d.width, d.height);
    return d;
  });
  private effects: Effect[] = [];
  private raf = 0;
  private last = 0;
  private time = 0;
  private w = 0;
  private h = 0;
  private dpr = 1;

  constructor(canvas: HTMLCanvasElement, o: EngineOptions) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d', { alpha: false })!;
    this.seed = o.seed;
    this.me = o.me;
    this.x = o.start.x;
    this.y = o.start.y;
    this.capped = o.capped;
    this.onPick = o.onPick;
    for (const k of o.taken) this.taken.add(k);
    for (const e of o.eggs) this.eggs.set(e.key, { x: e.x, y: e.y });
    for (const name of Object.keys(SPRITES)) this.sprites.set(name, img(`/sky/${name}.webp`));
    const n = Math.min(2, Math.max(1, (navigator.hardwareConcurrency ?? 2) - 1));
    for (let i = 0; i < n; i++) {
      const w = new Worker(new URL('./terrain.worker.ts', import.meta.url), { type: 'module' });
      const slot = { w, busy: false };
      w.onmessage = (e: MessageEvent<ChunkPaint>) => {
        slot.busy = false;
        this.receive(e.data);
        this.dispatch();
      };
      this.workers.push(slot);
    }
  }

  start() {
    this.last = performance.now();
    const frame = (now: number) => {
      const dt = Math.min(0.05, (now - this.last) / 1000);
      this.last = now;
      this.time += dt;
      this.update(dt);
      this.draw();
      this.raf = requestAnimationFrame(frame);
    };
    this.raf = requestAnimationFrame(frame);
  }

  stop() {
    cancelAnimationFrame(this.raf);
    for (const { w } of this.workers) w.terminate();
    this.workers.length = 0;
  }

  // ---------- From the page / the room ----------

  picked(key: string, value: number, kind: 'coin' | 'egg') {
    this.pending.delete(key);
    this.taken.add(key);
    const at = this.thingAt(key);
    this.effects.push({ x: at?.x ?? this.x, y: at?.y ?? this.y, text: `+${String(value).replace('.', ',')} B`, born: this.time, big: kind === 'egg' });
    this.eggs.delete(key);
  }

  /** The server said no: taken (gone for good), cap reached, or try again later. */
  refused(key: string, why: 'taken' | 'cap' | 'retry') {
    if (why === 'retry') {
      setTimeout(() => this.pending.delete(key), 1500);
      return;
    }
    this.pending.delete(key);
    if (why === 'taken') {
      this.taken.add(key);
      this.eggs.delete(key);
    } else this.capped = true;
  }

  /** Someone (anyone) took it: it vanishes everywhere. */
  gone(key: string) {
    this.taken.add(key);
    this.eggs.delete(key);
  }

  addEggs(eggs: { key: string; x: number; y: number }[]) {
    for (const e of eggs) if (!this.taken.has(e.key)) this.eggs.set(e.key, { x: e.x, y: e.y });
  }

  setOthers(list: [number, string, number, number, number][]) {
    this.others.clear();
    for (const [id, name, x, y, h] of list) if (id !== this.me) this.others.set(id, { id, name, x, y, h, tx: x, ty: y, th: h, seen: x !== 0 || y !== 0, ...FRESH });
  }

  joined(id: number, name: string, x: number, y: number) {
    if (id === this.me) return;
    this.others.set(id, { id, name, x, y, h: 0, tx: x, ty: y, th: 0, seen: x !== 0 || y !== 0, ...FRESH });
  }

  left(id: number) {
    this.others.delete(id);
  }

  moved(list: [number, number, number, number][]) {
    for (const [id, x, y, h] of list) {
      const o = this.others.get(id);
      if (!o) continue;
      if (!o.seen) {
        o.x = x;
        o.y = y;
        o.h = h;
        o.seen = true;
      }
      o.tx = x;
      o.ty = y;
      o.th = h;
    }
  }

  // ---------- Fights (iteration 37) ----------

  /** A fight starts or ends: everyone back to full HP and on their feet. */
  setFight(on: boolean) {
    this.fighting = on;
    this.hp = SKY_HP;
    this.ko = false;
    for (const o of this.others.values()) {
      o.hp = SKY_HP;
      o.ko = false;
    }
  }

  setHp(id: number, hp: number, ko = false) {
    if (id === this.me) {
      this.hp = hp;
      this.ko = this.ko || ko;
      return;
    }
    const o = this.others.get(id);
    if (o) {
      o.hp = hp;
      o.ko = o.ko || ko;
    }
  }

  knockOut(id: number) {
    this.setHp(id, 0, true);
    if (id === this.me) this.input = { x: 0, y: 0 };
  }

  swing(id: number) {
    if (id === this.me) this.swingAt = this.time;
    else {
      const o = this.others.get(id);
      if (o) o.swingAt = this.time;
    }
  }

  /** A floating «−20» over whoever was hit. */
  hitMark(id: number) {
    const at = id === this.me ? { x: this.x, y: this.y } : this.others.get(id);
    if (at) this.effects.push({ x: at.x, y: at.y - 30, text: '−20', born: this.time, big: false, hit: true });
  }

  /** Is anybody within the sword's reach (the HUD lights the button)? */
  inReach(): boolean {
    for (const o of this.others.values()) if (o.seen && !o.ko && Math.hypot(o.x - this.x, o.y - this.y) <= SKY_HIT_REACH) return true;
    return false;
  }

  /** The nearest egg (for the HUD's pointer), or null. */
  nearestEgg(): { dx: number; dy: number; d: number } | null {
    let best: { dx: number; dy: number; d: number } | null = null;
    for (const e of this.allEggs()) {
      const dx = e.x - this.x;
      const dy = e.y - this.y;
      const d = Math.hypot(dx, dy);
      if (!best || d < best.d) best = { dx, dy, d };
    }
    return best;
  }

  // ---------- Simulation ----------

  private update(dt: number) {
    // Knocked out: no flying until the fight is over.
    if (this.ko) this.input = { x: 0, y: 0 };
    const len = Math.hypot(this.input.x, this.input.y);
    const k = len > 1 ? 1 / len : 1;
    const tx = this.input.x * k * SKY_SPEED;
    const ty = this.input.y * k * SKY_SPEED;
    const a = Math.min(1, dt * 4.5);
    this.vx += (tx - this.vx) * a;
    this.vy += (ty - this.vy) * a;
    this.x += this.vx * dt;
    this.y += this.vy * dt;
    if (Math.hypot(this.vx, this.vy) > 12) {
      const want = Math.atan2(this.vy, this.vx);
      let d = want - this.heading;
      while (d > Math.PI) d -= Math.PI * 2;
      while (d < -Math.PI) d += Math.PI * 2;
      const step = d * Math.min(1, dt * 8);
      this.heading += step;
      this.turn += (step / Math.max(dt, 1e-3) - this.turn) * Math.min(1, dt * 6);
    } else this.turn *= 1 - Math.min(1, dt * 4);
    // Sparkles off the bristles while flying fast.
    const speed = Math.hypot(this.vx, this.vy);
    if (speed > 80 && this.time - this.trailAt > 0.05) {
      this.trailAt = this.time;
      const back = 70;
      this.trail.push({ x: this.x - Math.cos(this.heading) * back + (Math.random() - 0.5) * 14, y: this.y - Math.sin(this.heading) * back + (Math.random() - 0.5) * 14, born: this.time });
      if (this.trail.length > 24) this.trail.shift();
    }
    for (const o of this.others.values()) {
      const f = Math.min(1, dt * 7);
      const px = o.x;
      const py = o.y;
      o.x += (o.tx - o.x) * f;
      o.y += (o.ty - o.y) * f;
      o.speed += (Math.hypot(o.x - px, o.y - py) / Math.max(dt, 1e-3) - o.speed) * Math.min(1, dt * 4);
      let d = o.th - o.h;
      while (d > Math.PI) d -= Math.PI * 2;
      while (d < -Math.PI) d += Math.PI * 2;
      o.h += d * f;
      o.turn += ((d * f) / Math.max(dt, 1e-3) - o.turn) * Math.min(1, dt * 6);
    }
    this.effects = this.effects.filter((e) => this.time - e.born < 1.1);
    this.ensureChunks();
    this.checkPicks();
  }

  private checkPicks() {
    if (this.ko) return;
    const r2 = (SKY_PICK_RADIUS - 6) ** 2;
    const cx = chunkOf(this.x);
    const cy = chunkOf(this.y);
    for (let j = -1; j <= 1; j++) {
      for (let i = -1; i <= 1; i++) {
        const c = this.chunks.get(`${cx + i},${cy + j}`);
        if (!c) continue;
        if (!this.capped) {
          for (const coin of c.coins) {
            if (this.taken.has(coin.key) || this.pending.has(coin.key)) continue;
            if ((coin.x - this.x) ** 2 + (coin.y - this.y) ** 2 < r2) {
              this.pending.add(coin.key);
              this.onPick(coin.key, 'coin');
            }
          }
        }
        const egg = c.egg;
        if (egg && !this.taken.has(egg.key) && !this.pending.has(egg.key) && (egg.x - this.x) ** 2 + (egg.y - this.y) ** 2 < r2 * 1.6) {
          this.pending.add(egg.key);
          this.onPick(egg.key, 'egg');
        }
      }
    }
    for (const [key, e] of this.eggs) {
      if (this.pending.has(key) || this.taken.has(key)) continue;
      if ((e.x - this.x) ** 2 + (e.y - this.y) ** 2 < r2 * 1.6) {
        this.pending.add(key);
        this.onPick(key, 'egg');
      }
    }
  }

  private *allEggs() {
    for (const [key, e] of this.eggs) if (!this.taken.has(key)) yield e;
    for (const c of this.chunks.values()) if (c?.egg && !this.taken.has(c.egg.key)) yield c.egg;
  }

  private thingAt(key: string) {
    const e = this.eggs.get(key);
    if (e) return e;
    const m = /^[cn]:(-?\d+):(-?\d+)/.exec(key);
    if (!m) return null;
    const c = this.chunks.get(`${m[1]},${m[2]}`);
    return c?.coins.find((x) => x.key === key) ?? (c?.egg?.key === key ? c.egg : null);
  }

  // ---------- Chunks ----------

  private view() {
    const hw = this.w / 2 / this.zoom;
    const hh = this.h / 2 / this.zoom;
    return { x0: this.x - hw, y0: this.y - hh, x1: this.x + hw, y1: this.y + hh };
  }

  private ensureChunks() {
    const v = this.view();
    const cx0 = chunkOf(v.x0) - 1;
    const cx1 = chunkOf(v.x1) + 1;
    const cy0 = chunkOf(v.y0) - 1;
    const cy1 = chunkOf(v.y1) + 1;
    const want: [number, number, number][] = [];
    for (let cy = cy0; cy <= cy1; cy++) {
      for (let cx = cx0; cx <= cx1; cx++) {
        if (this.chunks.has(`${cx},${cy}`)) continue;
        const d = Math.hypot((cx + 0.5) * SKY_CHUNK - this.x, (cy + 0.5) * SKY_CHUNK - this.y);
        want.push([cx, cy, d]);
      }
    }
    if (want.length) {
      want.sort((a, b) => a[2] - b[2]);
      for (const [cx, cy] of want) {
        this.chunks.set(`${cx},${cy}`, null);
        this.queue.push([cx, cy]);
      }
      this.dispatch();
    }
    // Forget chunks far behind.
    const mx = chunkOf(this.x);
    const my = chunkOf(this.y);
    const span = Math.ceil(Math.max(this.w, this.h) / this.zoom / SKY_CHUNK / 2) + KEEP_CHUNKS;
    for (const key of this.chunks.keys()) {
      const [a, b] = key.split(',').map(Number) as [number, number];
      if (Math.abs(a - mx) > span || Math.abs(b - my) > span) this.chunks.delete(key);
    }
  }

  private dispatch() {
    for (const slot of this.workers) {
      if (slot.busy) continue;
      const next = this.queue.shift();
      if (!next) return;
      if (!this.chunks.has(`${next[0]},${next[1]}`)) continue;
      slot.busy = true;
      slot.w.postMessage({ seed: this.seed, cx: next[0], cy: next[1] });
    }
  }

  private receive(p: ChunkPaint) {
    const key = `${p.cx},${p.cy}`;
    if (!this.chunks.has(key)) return;
    const ground = document.createElement('canvas');
    ground.width = ground.height = RES;
    ground.getContext('2d')!.putImageData(new ImageData(new Uint8ClampedArray(p.pixels), RES, RES), 0, 0);
    this.chunks.set(key, { ground, things: p.things, coins: chunkCoins(this.seed, p.cx, p.cy), egg: naturalEgg(this.seed, p.cx, p.cy) });
  }

  // ---------- Drawing ----------

  private resize() {
    const r = this.canvas.getBoundingClientRect();
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    if (r.width !== this.w || r.height !== this.h || dpr !== this.dpr) {
      this.w = r.width;
      this.h = r.height;
      this.dpr = dpr;
      this.canvas.width = Math.round(r.width * dpr);
      this.canvas.height = Math.round(r.height * dpr);
      this.zoom = r.width < 600 ? 0.82 : 1;
    }
  }

  private toWorld() {
    const z = this.zoom * this.dpr;
    this.ctx.setTransform(z, 0, 0, z, this.dpr * (this.w / 2) - this.x * z, this.dpr * (this.h / 2) - this.y * z);
  }

  private sprite(name: SpriteName, x: number, y: number, scale = 1, angle?: number) {
    const im = this.sprites.get(name);
    const s = SPRITES[name];
    if (!im?.complete || !im.naturalWidth || !s) return;
    const u = s.upp * scale;
    if (angle === undefined) {
      this.ctx.drawImage(im, x - s.ax * u, y - s.ay * u, s.w * u, s.h * u);
      return;
    }
    this.ctx.save();
    this.ctx.translate(x, y);
    this.ctx.rotate(angle);
    this.ctx.drawImage(im, -s.ax * u, -s.ay * u, s.w * u, s.h * u);
    this.ctx.restore();
  }

  private draw() {
    this.resize();
    const ctx = this.ctx;
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.fillStyle = '#3f86bd';
    ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
    this.toWorld();
    ctx.imageSmoothingEnabled = true;
    const v = this.view();
    const visible: [number, number, Chunk][] = [];
    for (let cy = chunkOf(v.y0); cy <= chunkOf(v.y1); cy++) {
      for (let cx = chunkOf(v.x0); cx <= chunkOf(v.x1); cx++) {
        const c = this.chunks.get(`${cx},${cy}`);
        if (!c) continue;
        visible.push([cx, cy, c]);
        // A hair of overlap hides the seams between chunks.
        ctx.drawImage(c.ground, cx * SKY_CHUNK - 0.5, cy * SKY_CHUNK - 0.5, SKY_CHUNK + 1, SKY_CHUNK + 1);
      }
    }
    this.drawClouds(v, true);
    // Trees, houses, rocks, row by row so the nearer ones overlap the farther.
    for (const [cx, cy, c] of visible) {
      for (const t of c.things) {
        const x = cx * SKY_CHUNK + t.x;
        const y = cy * SKY_CHUNK + t.y;
        if (x < v.x0 - 60 || x > v.x1 + 60 || y < v.y0 - 40 || y > v.y1 + 90) continue;
        this.sprite(t.k, x, y, t.s);
      }
    }
    // Coins and eggs hang in the air: above the trees, never hidden in a forest.
    for (const [, , c] of visible) for (const coin of c.coins) if (!this.taken.has(coin.key)) this.drawCoin(coin);
    for (const e of this.allEggs()) this.drawEgg(e.x, e.y);
    // Players: the other Meowls, then ours on top (each with its shadow), and the sparkles behind ours.
    this.drawTrail();
    for (const o of this.others.values()) if (o.seen) this.drawMeowl(o.x, o.y, o.h, 0.95, { turn: o.turn, speed: o.speed, ko: o.ko, swingAt: o.swingAt, seed: o.id % 97 });
    this.drawMeowl(this.x, this.y, this.heading, 1, { turn: this.turn, speed: Math.hypot(this.vx, this.vy), ko: this.ko, swingAt: this.swingAt, seed: 0 });
    this.drawClouds(v, false);
    this.drawEffects();
    ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    this.drawNames();
    this.drawRadar();
    this.drawEggPointer();
  }

  private drawCoin(c: SkyCoin) {
    const ctx = this.ctx;
    const spin = Math.abs(Math.cos(this.time * 3 + (c.x + c.y) * 0.01));
    const bob = Math.sin(this.time * 2.4 + c.x * 0.03) * 2;
    ctx.globalAlpha = this.capped ? 0.35 : 1;
    const glow = ctx.createRadialGradient(c.x, c.y + bob, 2, c.x, c.y + bob, COIN_SIZE);
    glow.addColorStop(0, 'rgba(255,214,90,0.55)');
    glow.addColorStop(1, 'rgba(255,214,90,0)');
    ctx.fillStyle = glow;
    ctx.fillRect(c.x - COIN_SIZE, c.y + bob - COIN_SIZE, COIN_SIZE * 2, COIN_SIZE * 2);
    if (this.coinImg.complete && this.coinImg.naturalWidth) {
      const w = COIN_SIZE * Math.max(0.18, spin);
      ctx.drawImage(this.coinImg, c.x - w / 2, c.y + bob - COIN_SIZE / 2, w, COIN_SIZE);
    }
    ctx.globalAlpha = 1;
  }

  private drawEgg(x: number, y: number) {
    const ctx = this.ctx;
    const pulse = 1 + Math.sin(this.time * 4) * 0.08;
    const glow = ctx.createRadialGradient(x, y, 4, x, y, EGG_SIZE * pulse);
    glow.addColorStop(0, 'rgba(255,120,200,0.55)');
    glow.addColorStop(0.5, 'rgba(255,200,90,0.25)');
    glow.addColorStop(1, 'rgba(255,200,90,0)');
    ctx.fillStyle = glow;
    ctx.fillRect(x - EGG_SIZE * 1.2, y - EGG_SIZE * 1.2, EGG_SIZE * 2.4, EGG_SIZE * 2.4);
    // Rays turning slowly behind it.
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(this.time * 0.6);
    ctx.fillStyle = 'rgba(255,236,170,0.22)';
    for (let i = 0; i < 8; i++) {
      ctx.rotate(Math.PI / 4);
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.lineTo(-7, -EGG_SIZE * 0.95);
      ctx.lineTo(7, -EGG_SIZE * 0.95);
      ctx.fill();
    }
    ctx.restore();
    if (this.eggImg.complete && this.eggImg.naturalWidth) {
      const w = EGG_SIZE * pulse;
      const h = (w * this.eggImg.naturalHeight) / this.eggImg.naturalWidth;
      ctx.drawImage(this.eggImg, x - w / 2, y - h / 2 + Math.sin(this.time * 2) * 3, w, h);
    }
  }

  private shadowOf(name: string): HTMLCanvasElement | null {
    const cached = this.shadows.get(name);
    if (cached) return cached;
    const im = this.sprites.get(name);
    if (!im?.complete || !im.naturalWidth) return null;
    const c = document.createElement('canvas');
    c.width = im.naturalWidth;
    c.height = im.naturalHeight;
    const g = c.getContext('2d')!;
    g.drawImage(im, 0, 0);
    g.globalCompositeOperation = 'source-in';
    g.fillStyle = '#0b1f18';
    g.fillRect(0, 0, c.width, c.height);
    this.shadows.set(name, c);
    return c;
  }

  /**
   * The broom Meowl: a shadow down-right (the sun is in the north-west), a gentle bob, a lean into turns (narrower and
   * sliding outwards, seen from above), the bristles fluttering on their own — harder the faster he flies. In a fight he
   * holds a sword at his side and sweeps it on a swing; knocked out, he spins faded until the fight ends.
   */
  private drawMeowl(x: number, y: number, heading: number, alpha: number, st: { turn: number; speed: number; ko: boolean; swingAt: number; seed: number }) {
    const ctx = this.ctx;
    const im = this.sprites.get(MEOWL);
    const s = SPRITES[MEOWL];
    if (!im?.complete || !im.naturalWidth || !s) return;
    const u = s.upp;
    const t = this.time + st.seed;
    const angle = heading + Math.PI / 2 + (st.ko ? t * 2.6 : 0);
    const bob = 1 + Math.sin(t * 3.2) * 0.03;
    const lean = Math.max(-1, Math.min(1, st.turn / 3));
    const sx = (1 - Math.abs(lean) * 0.16) * bob;
    const split = s.split ?? s.h * 0.75;
    const shadow = this.shadowOf(MEOWL);
    if (shadow) {
      ctx.save();
      ctx.globalAlpha = (st.ko ? 0.36 : 0.24) * alpha;
      ctx.translate(x + 30, y + 46);
      ctx.rotate(angle);
      ctx.scale(sx * 0.86, bob * 0.86);
      ctx.drawImage(shadow, -s.ax * u, -s.ay * u, s.w * u, s.h * u);
      ctx.restore();
    }
    ctx.save();
    ctx.globalAlpha = alpha * (st.ko ? 0.62 : 1);
    ctx.translate(x, y);
    ctx.rotate(angle);
    ctx.translate(lean * 6, 0);
    ctx.scale(sx, bob);
    // The bristles first (the body covers the binding), swinging around it.
    const k = im.naturalHeight / s.h;
    const flutter = Math.sin(t * 22) * (0.03 + Math.min(1, st.speed / SKY_SPEED) * 0.07) - lean * 0.12;
    ctx.save();
    ctx.translate(0, (split - s.ay) * u);
    ctx.rotate(flutter);
    ctx.drawImage(im, 0, split * k, im.naturalWidth, im.naturalHeight - split * k, -s.ax * u, 0, s.w * u, (s.h - split) * u);
    ctx.restore();
    ctx.drawImage(im, 0, 0, im.naturalWidth, split * k, -s.ax * u, -s.ay * u, s.w * u, split * u);
    if (this.fighting && !st.ko) this.drawSword(t, this.time - st.swingAt);
    ctx.restore();
  }

  /** The sword at Meowl's right paw (local space: forward is up); a swing sweeps it across the front with a gleam. */
  private drawSword(t: number, since: number) {
    const ctx = this.ctx;
    const swinging = since < 0.3;
    const p = swinging ? since / 0.3 : 0;
    // Resting: held up and a little out; swinging: from the right round to the left.
    const a = swinging ? 0.9 - p * 2.6 : 0.5 + Math.sin(t * 2) * 0.05;
    ctx.save();
    ctx.translate(18, -6);
    ctx.rotate(a);
    if (this.swordImg.complete && this.swordImg.naturalWidth) {
      const h = 64;
      const w = (h * this.swordImg.naturalWidth) / this.swordImg.naturalHeight;
      ctx.drawImage(this.swordImg, -w / 2, -h, w, h);
    } else {
      ctx.fillStyle = '#dfe7f2';
      ctx.fillRect(-2, -60, 4, 60);
    }
    ctx.restore();
    if (swinging) {
      ctx.save();
      ctx.globalAlpha = 0.55 * (1 - p);
      ctx.strokeStyle = '#fff4d6';
      ctx.lineWidth = 7;
      ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.arc(0, -10, 74, -Math.PI / 2 + 0.9 - p * 2.6, -Math.PI / 2 + 0.9, false);
      ctx.stroke();
      ctx.restore();
    }
  }

  /** Gold sparkles left behind by the broom. */
  private drawTrail() {
    const ctx = this.ctx;
    for (const d of this.trail) {
      const age = this.time - d.born;
      if (age > 0.7) continue;
      ctx.globalAlpha = (1 - age / 0.7) * 0.8;
      ctx.fillStyle = age < 0.2 ? '#fff1b8' : '#ffb347';
      const r = 3.2 * (1 - age / 0.7) + 1;
      ctx.fillRect(d.x - r, d.y - r, r * 2, r * 2);
    }
    ctx.globalAlpha = 1;
  }

  private drawClouds(v: { x0: number; y0: number; x1: number; y1: number }, shadows: boolean) {
    const ctx = this.ctx;
    const CELL = 1300;
    const ox = WIND.x * this.time;
    const oy = WIND.y * this.time;
    const gx0 = Math.floor((v.x0 - ox - 400) / CELL);
    const gx1 = Math.floor((v.x1 - ox + 400) / CELL);
    const gy0 = Math.floor((v.y0 - oy - 300) / CELL);
    const gy1 = Math.floor((v.y1 - oy + 300) / CELL);
    for (let gy = gy0; gy <= gy1; gy++) {
      for (let gx = gx0; gx <= gx1; gx++) {
        if (rand01(this.seed, gx, gy, 71) > 0.55) continue;
        const kind = Math.floor(rand01(this.seed, gx, gy, 72) * this.clouds.length);
        const sprite = (shadows ? this.cloudShadows : this.clouds)[kind]!;
        const s = 1.2 + rand01(this.seed, gx, gy, 73) * 1.4;
        const x = gx * CELL + rand01(this.seed, gx, gy, 74) * CELL + ox;
        const y = gy * CELL + rand01(this.seed, gx, gy, 75) * CELL + oy;
        const w = sprite.width * s;
        const h = sprite.height * s;
        if (shadows) {
          // High up, so the shadow falls well down-right of the cloud (the sun is in the north-west).
          ctx.globalAlpha = 0.16;
          ctx.drawImage(sprite, x - w / 2 + 90, y - h / 2 + 140, w, h);
        } else {
          // Thin out a cloud right over the player, so Meowl never disappears.
          const d = Math.hypot(x - this.x, y - this.y);
          ctx.globalAlpha = d < w * 0.45 ? 0.3 : 0.72;
          ctx.drawImage(sprite, x - w / 2, y - h / 2, w, h);
        }
      }
    }
    ctx.globalAlpha = 1;
  }

  private drawEffects() {
    const ctx = this.ctx;
    for (const e of this.effects) {
      const t = (this.time - e.born) / 1.1;
      const y = e.y - 18 - t * 46;
      ctx.globalAlpha = 1 - t;
      ctx.font = `800 ${e.big ? 26 : 17}px 'Unbounded Variable', system-ui, sans-serif`;
      ctx.textAlign = 'center';
      ctx.lineWidth = 4;
      ctx.strokeStyle = 'rgba(20,14,4,0.7)';
      ctx.strokeText(e.text, e.x, y);
      ctx.fillStyle = e.hit ? '#ff6b5e' : e.big ? '#ffd1f0' : '#ffd75e';
      ctx.fillText(e.text, e.x, y);
      if (e.hit) continue;
      // Sparkles flying out.
      ctx.fillStyle = e.big ? '#ffe9a8' : '#fff3b0';
      for (let i = 0; i < (e.big ? 14 : 7); i++) {
        const a = (i / (e.big ? 14 : 7)) * Math.PI * 2;
        const r = 10 + t * (e.big ? 80 : 40);
        ctx.fillRect(e.x + Math.cos(a) * r - 2, e.y + Math.sin(a) * r - 2, 4, 4);
      }
    }
    ctx.globalAlpha = 1;
  }

  private drawNames() {
    const ctx = this.ctx;
    ctx.font = `700 11px 'Manrope Variable', system-ui, sans-serif`;
    ctx.textAlign = 'center';
    for (const o of this.others.values()) {
      if (!o.seen) continue;
      const sx = (o.x - this.x) * this.zoom + this.w / 2;
      const sy = (o.y - this.y) * this.zoom + this.h / 2 - 46 * this.zoom;
      if (sx < -80 || sx > this.w + 80 || sy < -20 || sy > this.h + 20) continue;
      const tw = ctx.measureText(o.name).width + 14;
      ctx.fillStyle = 'rgba(8,12,24,0.62)';
      ctx.beginPath();
      ctx.roundRect(sx - tw / 2, sy - 10, tw, 18, 9);
      ctx.fill();
      ctx.fillStyle = '#eaf2ff';
      ctx.fillText(o.name, sx, sy + 3);
      if (this.fighting) this.drawHp(sx, sy - 16, o.hp, o.ko);
    }
    if (this.fighting) this.drawHp(this.w / 2, this.h / 2 - 62 * this.zoom, this.hp, this.ko);
  }

  /** A small HP bar (screen space) over a Meowl in a fight; knocked out shows «сбит». */
  private drawHp(x: number, y: number, hp: number, ko: boolean) {
    const ctx = this.ctx;
    const w = 46;
    ctx.fillStyle = 'rgba(8,12,24,0.7)';
    ctx.beginPath();
    ctx.roundRect(x - w / 2 - 2, y - 4, w + 4, 8, 4);
    ctx.fill();
    if (ko) {
      ctx.font = `800 10px 'Manrope Variable', system-ui, sans-serif`;
      ctx.fillStyle = '#ff8a80';
      ctx.fillText('сбит', x, y + 3.5);
      return;
    }
    const k = Math.max(0, Math.min(1, hp / SKY_HP));
    ctx.fillStyle = k > 0.5 ? '#5fe08a' : k > 0.25 ? '#ffc04d' : '#ff5e57';
    ctx.beginPath();
    ctx.roundRect(x - w / 2, y - 2, w * k, 4, 2);
    ctx.fill();
  }

  /** A little radar under the HUD: coins (gold), eggs (pink), other players (blue) within 1 500 units. */
  private drawRadar() {
    const ctx = this.ctx;
    const R = 44;
    const cx = this.w - R - 12;
    // Bottom right, above the tip line: the egg banner takes the top.
    const cy = this.h - R - 64;
    const range = 1500;
    ctx.fillStyle = 'rgba(8,14,28,0.55)';
    ctx.strokeStyle = 'rgba(255,214,90,0.5)';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.arc(cx, cy, R, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    ctx.strokeStyle = 'rgba(255,255,255,0.12)';
    ctx.beginPath();
    ctx.arc(cx, cy, R / 2, 0, Math.PI * 2);
    ctx.stroke();
    const dot = (x: number, y: number, color: string, r: number) => {
      const dx = ((x - this.x) / range) * R;
      const dy = ((y - this.y) / range) * R;
      if (dx * dx + dy * dy > (R - 3) ** 2) return;
      ctx.fillStyle = color;
      ctx.beginPath();
      ctx.arc(cx + dx, cy + dy, r, 0, Math.PI * 2);
      ctx.fill();
    };
    if (!this.capped) {
      for (const c of this.chunks.values()) if (c) for (const coin of c.coins) if (!this.taken.has(coin.key)) dot(coin.x, coin.y, '#ffd34d', 1.6);
    }
    for (const o of this.others.values()) if (o.seen) dot(o.x, o.y, '#7cc4ff', 2.4);
    for (const e of this.allEggs()) dot(e.x, e.y, '#ff7ad1', 3.4);
    ctx.save();
    ctx.translate(cx, cy);
    ctx.rotate(this.heading + Math.PI / 2);
    ctx.fillStyle = '#fff';
    ctx.beginPath();
    ctx.moveTo(0, -5);
    ctx.lineTo(4, 4);
    ctx.lineTo(-4, 4);
    ctx.fill();
    ctx.restore();
  }

  /** An arrow at the screen's edge towards the nearest egg off screen, with the distance. */
  private drawEggPointer() {
    const e = this.nearestEgg();
    if (!e || e.d > 4000) return;
    const sx = e.dx * this.zoom;
    const sy = e.dy * this.zoom;
    if (Math.abs(sx) < this.w / 2 - 30 && Math.abs(sy) < this.h / 2 - 30) return;
    const a = Math.atan2(sy, sx);
    const m = 40;
    const t = Math.min((this.w / 2 - m) / Math.abs(Math.cos(a) || 1e-6), (this.h / 2 - m - 40) / Math.abs(Math.sin(a) || 1e-6));
    const x = this.w / 2 + Math.cos(a) * t;
    const y = this.h / 2 + Math.sin(a) * t;
    const ctx = this.ctx;
    ctx.save();
    ctx.translate(x, y);
    ctx.globalAlpha = 0.75 + Math.sin(this.time * 6) * 0.25;
    ctx.fillStyle = '#ff7ad1';
    ctx.rotate(a);
    ctx.beginPath();
    ctx.moveTo(16, 0);
    ctx.lineTo(-8, -11);
    ctx.lineTo(-3, 0);
    ctx.lineTo(-8, 11);
    ctx.fill();
    ctx.restore();
    ctx.globalAlpha = 1;
    ctx.font = `800 11px 'Manrope Variable', system-ui, sans-serif`;
    ctx.textAlign = 'center';
    ctx.fillStyle = '#ffe1f4';
    ctx.fillText(`🥚 ${Math.round(e.d / 10) * 10}`, x - Math.cos(a) * 30, y - Math.sin(a) * 30 + 4);
  }
}
