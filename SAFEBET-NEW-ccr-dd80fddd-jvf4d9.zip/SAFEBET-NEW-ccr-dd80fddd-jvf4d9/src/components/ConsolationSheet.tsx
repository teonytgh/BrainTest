import { useEffect, useLayoutEffect, useMemo, useRef, useState, type CSSProperties } from 'react';
import { Coin } from './Coin';
import { Sheet } from './Sheet';
import { errorMessage } from '../api/client';
import { act, queryClient, setMe, useCatalog, type Me } from '../api/queries';
import { CONSOLATION_PRIZES } from '../../shared/bonuses';
import { pickWeighted } from '../../shared/cases';
import type { Brainrot } from '../../shared/types';
import { cx, formatCoins } from '../lib/format';
import { sfx } from '../lib/sound';
import { haptic } from '../lib/telegram';
import { tierOf } from '../lib/tier';
import { toast } from '../store/toast';

const LENGTH = 42;
const WIN_INDEX = 34;
const CARD = 112;
const SPIN_MS = 4200;

type Card = { kind: 'brainrot'; b: Brainrot } | { kind: 'coins'; coins: number };

/** Reel cards: brainrots for show, coin cards like the real prizes; the server's prize sits at WIN_INDEX. */
function buildCards(decor: Brainrot[], won: number): Card[] {
  return Array.from({ length: LENGTH }, (_, i): Card => {
    if (i === WIN_INDEX) return { kind: 'coins', coins: won };
    if (decor.length && Math.random() < 0.55) return { kind: 'brainrot', b: decor[Math.floor(Math.random() * decor.length)]! };
    return { kind: 'coins', coins: pickWeighted(CONSOLATION_PRIZES.map((p) => ({ ...p })), Math.random).coins };
  });
}

function Reel({ cards, onLanded }: { cards: Card[]; onLanded: () => void }) {
  const viewport = useRef<HTMLDivElement>(null);
  const [x, setX] = useState(0);
  const [landed, setLanded] = useState(false);
  const jitter = useMemo(() => (Math.random() - 0.5) * (CARD - 40), []);
  const done = useRef(onLanded);
  done.current = onLanded;

  useLayoutEffect(() => {
    const width = viewport.current?.clientWidth ?? 0;
    // Next frame, so the transition runs from 0.
    const raf = requestAnimationFrame(() => setX(-(WIN_INDEX * CARD + CARD / 2 - width / 2 + jitter)));
    return () => cancelAnimationFrame(raf);
  }, [jitter]);

  useEffect(() => {
    if (!x) return;
    let last = -1;
    const width = viewport.current?.clientWidth ?? 0;
    const track = viewport.current?.querySelector<HTMLElement>('.reel__track');
    let frame = requestAnimationFrame(function loop() {
      if (track) {
        const pos = new DOMMatrixReadOnly(getComputedStyle(track).transform).m41;
        const index = Math.floor((-pos + width / 2) / CARD);
        if (index !== last) {
          if (last !== -1) sfx.tick();
          last = index;
        }
      }
      frame = requestAnimationFrame(loop);
    });
    const t = setTimeout(() => {
      setLanded(true);
      done.current();
    }, SPIN_MS + 80);
    return () => {
      cancelAnimationFrame(frame);
      clearTimeout(t);
    };
  }, [x]);

  const style: CSSProperties = { transform: `translateX(${x}px)`, transition: x ? `transform ${SPIN_MS}ms cubic-bezier(0.08, 0.7, 0.12, 1)` : 'none' };
  return (
    <div className="reel" ref={viewport}>
      <span className="reel__marker" aria-hidden="true" />
      <div className="reel__track" style={style}>
        {cards.map((c, i) =>
          c.kind === 'brainrot' ? (
            <div key={i} className={cx('reel__card', `tier-${tierOf(c.b.price)}`)} aria-hidden="true">
              <img src={c.b.image} alt="" />
              <span>{c.b.name}</span>
            </div>
          ) : (
            <div key={i} className={cx('reel__card reel__card--coins', landed && i === WIN_INDEX && 'is-won')} aria-hidden={i !== WIN_INDEX}>
              <Coin size={44} />
              <span>{formatCoins(c.coins)} B</span>
            </div>
          ),
        )}
      </div>
    </div>
  );
}

/**
 * «Утешительный кейс» after a big upgrade loss: one free spin that always pays coins (1–30 B) — the card says
 * so; the brainrots on the reel are decoration.
 */
export function ConsolationSheet({ id, onClose }: { id: number | null; onClose: () => void }) {
  const catalog = useCatalog();
  const [won, setWon] = useState<number | null>(null);
  const [landed, setLanded] = useState(false);
  const [busy, setBusy] = useState(false);
  const pendingMe = useRef<Me | null>(null);
  const decor = useMemo(() => catalog.active.filter((b) => b.price >= 150).slice(0, 40), [catalog.active]);
  const cards = useMemo(() => (won === null ? null : buildCards(decor, won)), [won, decor]);

  useEffect(() => {
    setWon(null);
    setLanded(false);
  }, [id]);

  async function spin() {
    if (id === null || busy) return;
    setBusy(true);
    try {
      const r = await act<{ coins: number }>(`/api/consolations/${id}/open`);
      sfx.open();
      haptic('tap');
      setWon(r.result.coins);
      // The balance updates once the reel lands.
      pendingMe.current = r.me;
    } catch (e) {
      sfx.error();
      toast(errorMessage(e), 'error');
      onClose();
    } finally {
      setBusy(false);
    }
  }

  function land() {
    setLanded(true);
    sfx.coin();
    haptic('success');
    if (pendingMe.current) setMe(pendingMe.current);
    pendingMe.current = null;
    void queryClient.invalidateQueries({ queryKey: ['bonuses'] });
  }

  return (
    <Sheet open={id !== null} onClose={landed || won === null ? onClose : () => {}} title="Утешительный кейс">
      <div className="consolation">
        <p className="consolation__text">
          Не повезло в апгрейде — держи утешение. <b>Приз: от 1 до 30 B</b>, крутится бесплатно.
        </p>
        {cards ? (
          <Reel cards={cards} onLanded={land} />
        ) : (
          <div className="consolation__chest" aria-hidden="true">
            <img src="/cases/consolation.svg" alt="" />
          </div>
        )}
        {landed && won !== null && (
          <p className="consolation__won" role="status">
            +{formatCoins(won)} <Coin size={26} />
          </p>
        )}
        {won === null ? (
          <button type="button" className="btn btn--primary btn--lg btn--block" onClick={() => void spin()} disabled={busy}>
            {busy ? 'Открываем…' : 'Крутить бесплатно'}
          </button>
        ) : (
          <button type="button" className="btn btn--primary btn--lg btn--block" onClick={onClose} disabled={!landed}>
            {landed ? 'Забрать' : 'Крутится…'}
          </button>
        )}
      </div>
    </Sheet>
  );
}
