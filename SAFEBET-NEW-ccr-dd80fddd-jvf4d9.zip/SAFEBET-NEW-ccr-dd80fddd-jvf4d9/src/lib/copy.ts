import { toast } from '../store/toast';

/** Copies to the clipboard; a WebView that refuses it gets the text in a toast instead, so the tap never does nothing. */
export function copyText(text: string, done: string) {
  const fallback = () => toast(text.trim());
  try {
    if (!navigator.clipboard) return fallback();
    void navigator.clipboard.writeText(text).then(() => toast(done, 'success'), fallback);
  } catch {
    fallback();
  }
}
