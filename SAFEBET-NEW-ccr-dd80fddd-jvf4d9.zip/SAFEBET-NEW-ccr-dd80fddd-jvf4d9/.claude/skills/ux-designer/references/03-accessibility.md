# Accessibility & WCAG 2.2

Accessibility ensures digital products are usable by people with disabilities. Beyond ethics and inclusion, it's increasingly a legal requirement.

---

## WCAG 2.2 Overview

**Web Content Accessibility Guidelines 2.2** is the latest W3C recommendation (October 2023, updated December 2024), now also an ISO standard (ISO/IEC 40500:2025).

### Conformance Levels

| Level | Description | Requirement |
|-------|-------------|-------------|
| **A** | Minimum accessibility | Essential barriers removed |
| **AA** | Recommended standard | Most common target for compliance |
| **AAA** | Highest accessibility | Maximum inclusion (not always feasible) |

### Four Principles (POUR)

1. **Perceivable** - Information must be presentable in ways users can perceive
2. **Operable** - Interface components must be operable
3. **Understandable** - Information and operation must be understandable
4. **Robust** - Content must be robust enough for various assistive technologies

---

## New Success Criteria in WCAG 2.2

### Focus Not Obscured (Minimum) - 2.4.11 (AA)
When an element receives keyboard focus, it is not entirely hidden by other content.

```css
/* Ensure focused elements aren't covered */
.modal {
  /* Don't cover the element that triggered focus */
}

/* Sticky headers should not cover focused content */
.sticky-header {
  /* Account for header height in scroll calculations */
}
```

### Focus Not Obscured (Enhanced) - 2.4.12 (AAA)
When focused, no part of the element is hidden by author-created content.

### Focus Appearance - 2.4.13 (AAA)
Focus indicators must have sufficient size and contrast.

### Dragging Movements - 2.5.7 (AA)
Functionality using dragging can be operated with a single pointer without dragging.

```html
<!-- Provide alternative to drag-and-drop -->
<div draggable="true">Item</div>
<button>Move Up</button>
<button>Move Down</button>
```

### Target Size (Minimum) - 2.5.8 (AA)
Touch targets must be at least 24×24 CSS pixels, with exceptions for inline links, user agent controls, and essential presentations.

### Accessible Authentication (Minimum) - 3.3.8 (AA)
Authentication processes don't require cognitive function tests (like remembering passwords) unless alternatives are provided.

```
Compliant methods:
- Password managers (paste allowed)
- Email/SMS verification codes
- Biometric authentication
- OAuth/social login
```

### Accessible Authentication (Enhanced) - 3.3.9 (AAA)
No cognitive test required at all for authentication.

### Redundant Entry - 3.3.7 (A)
Don't require users to re-enter information already provided in the same session.

---

## Color and Contrast

### Contrast Requirements

| Content Type | Minimum Ratio (AA) | Enhanced (AAA) |
|--------------|-------------------|----------------|
| Normal text (< 24px, or < 18.66px bold) | 4.5:1 | 7:1 |
| Large text (≥ 24px, or ≥ 18.66px bold) | 3:1 | 4.5:1 |
| UI components & graphics | 3:1 | - |
| Focus indicators | 3:1 | - |

"Large text" is **≥ 24px** regular or **≥ 18.66px bold** (the px equivalents of the 18pt / 14pt-bold thresholds in the spec). Below that, normal-text ratios apply.

### Non-text Contrast — 1.4.11 (AA)
The **3:1** requirement isn't just for text. SC 1.4.11 (Non-text Contrast) applies it to anything you need to *see and operate or understand*:
- Input borders, button boundaries, and other control edges (against the adjacent background)
- Focus indicators and selection states
- Icons and glyphs that convey meaning (not purely decorative ones)
- Meaningful parts of charts and data visualizations (bars, lines, slices) where the part carries information

A hairline 1px border that's only 1.5:1 against the page fails this even when the text inside the field passes 4.5:1.

### WCAG Is the Floor, Not the Ceiling
A pass of 4.52:1 is *technically* AA but still hard for some readers — treat the numbers as a minimum and give body text more headroom where you can. Going the other way, **avoid pure black on pure white (21:1)**: the maximum-contrast extreme causes haloing/visual vibration and can trigger eye strain or migraines for some users. Pair a near-black with an off-white instead of `#000` on `#fff`.

### Testing Contrast
```javascript
// Calculate contrast ratio
function getContrastRatio(l1, l2) {
  const lighter = Math.max(l1, l2);
  const darker = Math.min(l1, l2);
  return (lighter + 0.05) / (darker + 0.05);
}
```

**Tools:**
- WebAIM Contrast Checker
- TPGi Colour Contrast Analyser (CCA) — desktop eyedropper
- Stark (Figma plugin)
- Chrome DevTools accessibility panel (inline ratios)
- axe-core / Pa11y / Lighthouse — wire one into CI so contrast regressions fail the build automatically

Low contrast is not an edge case — it's *the* most common failure on the web. The **WebAIM Million 2026 report** (analysis of the top 1,000,000 home pages) found low-contrast text below WCAG 2 AA thresholds on **83.9% of home pages**, up from 79.1% the prior year, making it the single most commonly-detected accessibility issue.

### Use of Color — 1.4.1 (A)
Color is the *most common* failure's quieter cousin: never use color as the **only** visual means of conveying information, indicating an action, or distinguishing an element. This is a Level A requirement (the floor), and it matters for color-vision deficiency, which affects roughly **1 in 12 men (~8%)** and **1 in 200 women (~0.5%)** — on the order of **300 million people worldwide**.

```
Never rely on color alone to convey:
- Error states (add icons, text)
- Success/failure (add icons, patterns)
- Required fields (add asterisks or "(required)")
- Link differentiation (add underline)
- Data visualization (add patterns, direct labels, distinct shapes)
```

### APCA / WCAG 3 (Emerging)
The **Advanced Perceptual Contrast Algorithm (APCA)** under development for WCAG 3 models human perception better than the 2.x ratio (it accounts for text size, weight, and polarity rather than a single number). It's worth tracking, but it is **not yet the legal or conformance standard** — **build to WCAG 2.2 AA today** and treat APCA as a forward-looking sanity check, not a replacement.

---

## Keyboard Navigation

### Requirements
All functionality must be accessible via keyboard.

```html
<!-- Ensure logical tab order -->
<nav>
  <a href="/">Home</a>
  <a href="/about">About</a>
  <a href="/contact">Contact</a>
</nav>

<!-- Use tabindex appropriately -->
<div tabindex="0" role="button">Custom Button</div>
<div tabindex="-1">Programmatically focusable only</div>
<!-- Never use tabindex > 0 -->
```

### Focus Management
```css
/* Never hide focus outlines without replacement */
:focus {
  outline: 2px solid #005fcc;
  outline-offset: 2px;
}

/* For mouse users who don't need visible focus */
:focus:not(:focus-visible) {
  outline: none;
}

:focus-visible {
  outline: 2px solid #005fcc;
  outline-offset: 2px;
}
```

### Keyboard Shortcuts
```
Standard expectations:
- Tab: Move to next focusable element
- Shift+Tab: Move to previous element
- Enter/Space: Activate buttons
- Arrow keys: Navigate within widgets
- Escape: Close modals/popups
```

---

## Screen Reader Compatibility

### Semantic HTML
```html
<!-- Use semantic elements -->
<header>...</header>
<nav>...</nav>
<main>...</main>
<article>...</article>
<aside>...</aside>
<footer>...</footer>

<!-- Not divs with roles -->
<div role="navigation">...</div> <!-- Less ideal -->
```

### ARIA (Accessible Rich Internet Applications)
```html
<!-- Labels -->
<button aria-label="Close dialog">×</button>

<!-- Descriptions -->
<input aria-describedby="password-hint" />
<p id="password-hint">Must be at least 8 characters</p>

<!-- States -->
<button aria-expanded="false" aria-controls="menu">Menu</button>
<ul id="menu" aria-hidden="true">...</ul>

<!-- Live regions for dynamic content -->
<div aria-live="polite" aria-atomic="true">
  <!-- Updates announced to screen readers -->
</div>
```

### Image Accessibility
```html
<!-- Informative images -->
<img src="chart.png" alt="Sales increased 20% in Q4 2024" />

<!-- Decorative images -->
<img src="divider.png" alt="" role="presentation" />

<!-- Complex images -->
<figure>
  <img src="diagram.png" alt="System architecture diagram" />
  <figcaption>
    Full description of the system architecture...
  </figcaption>
</figure>
```

---

## Forms Accessibility

```html
<form>
  <!-- Always associate labels -->
  <label for="email">Email address</label>
  <input type="email" id="email" name="email"
         aria-required="true"
         aria-describedby="email-error" />
  <span id="email-error" role="alert">
    Please enter a valid email address
  </span>

  <!-- Group related fields -->
  <fieldset>
    <legend>Shipping Address</legend>
    <!-- Address fields -->
  </fieldset>

  <!-- Required field indication -->
  <label for="name">
    Name <span aria-hidden="true">*</span>
    <span class="sr-only">(required)</span>
  </label>
</form>
```

### Error Handling
```html
<!-- Announce errors -->
<div role="alert" aria-live="assertive">
  Please correct the following errors:
  <ul>
    <li><a href="#email">Email is required</a></li>
  </ul>
</div>
```

---

## Motion and Animation

### Respecting User Preferences
```css
/* Reduce motion for users who prefer it */
@media (prefers-reduced-motion: reduce) {
  *,
  *::before,
  *::after {
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
  }
}

/* Or provide opt-out */
.animation {
  animation: slide-in 0.3s ease;
}

@media (prefers-reduced-motion: reduce) {
  .animation {
    animation: none;
  }
}
```

### Auto-Playing Content
- Never auto-play video with sound
- Provide pause/stop controls for any auto-playing content
- Avoid flashing content (> 3 flashes per second can trigger seizures)

---

## Touch Accessibility

### Target Sizes (WCAG 2.2)
```css
/* Minimum 24×24px for WCAG 2.2 AA */
/* Recommended 44×44px for comfortable tapping */
.button {
  min-width: 44px;
  min-height: 44px;
  padding: 12px 24px;
}

/* Adequate spacing between targets */
.button + .button {
  margin-left: 8px;
}
```

### Touch Alternatives
```html
<!-- Provide alternatives to complex gestures -->
<div class="carousel">
  <button aria-label="Previous slide">←</button>
  <!-- Content (also swipeable) -->
  <button aria-label="Next slide">→</button>
</div>
```

---

## Legal Requirements

### European Accessibility Act (EAA)
- **Directive:** (EU) 2019/882 — **in force June 28, 2025**
- **Applies to:** Products/services sold in the EU (e-commerce, banking, transport, e-books, and more)
- **Standard:** EN 301 549 (based on WCAG 2.1 AA)
- **Penalties:** set by each member state and can be steep — e.g., Germany's BFSG allows fines up to **€100,000 per violation or up to 4% of annual revenue**. Accessibility has moved from "nice to have" to enforceable compliance.

### Other Regulations
- **US:** ADA, Section 508
- **UK:** Equality Act 2010
- **Canada:** AODA, ACA
- **Australia:** DDA

---

## Testing Checklist

### Automated Testing
- [ ] axe DevTools
- [ ] WAVE
- [ ] Lighthouse
- [ ] Pa11y

### Manual Testing
- [ ] Keyboard-only navigation
- [ ] Screen reader testing (NVDA, VoiceOver, JAWS)
- [ ] 200% zoom level
- [ ] High contrast mode
- [ ] Reduced motion preference

### User Testing
- [ ] Include users with disabilities
- [ ] Test with assistive technologies
- [ ] Gather feedback on pain points

---

## Sources

- [WCAG 2.2](https://www.w3.org/TR/WCAG22/)
- [WAI-ARIA 1.2](https://www.w3.org/TR/wai-aria-1.2/)
- [WebAIM](https://webaim.org/)
- [A11y Project](https://www.a11yproject.com/)
- [Deque University](https://dequeuniversity.com/)
