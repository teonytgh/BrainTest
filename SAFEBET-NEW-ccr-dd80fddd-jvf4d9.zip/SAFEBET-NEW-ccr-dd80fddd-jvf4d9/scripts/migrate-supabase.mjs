// Applies pending SQL migrations (netlify/database/migrations/*.sql, in name order) to the production
// Supabase database over the Supabase Management API (HTTPS only, works where port 5432/6543 is blocked).
// Applied files are recorded in the _migrations table.
// Usage: SUPABASE_TOKEN=sbp_... SUPABASE_REF=<project ref> node scripts/migrate-supabase.mjs
import { readdirSync, readFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const DIR = path.join(ROOT, 'netlify', 'database', 'migrations');
const { SUPABASE_TOKEN, SUPABASE_REF } = process.env;
if (!SUPABASE_TOKEN || !SUPABASE_REF) throw new Error('Set SUPABASE_TOKEN and SUPABASE_REF');

async function query(sql) {
  const r = await fetch(`https://api.supabase.com/v1/projects/${SUPABASE_REF}/database/query`, {
    method: 'POST',
    headers: { authorization: `Bearer ${SUPABASE_TOKEN}`, 'content-type': 'application/json' },
    body: JSON.stringify({ query: sql }),
  });
  const text = await r.text();
  if (!r.ok) throw new Error(`${r.status} ${text.slice(0, 500)}`);
  return JSON.parse(text);
}

await query('CREATE TABLE IF NOT EXISTS _migrations (name TEXT PRIMARY KEY, applied_at TIMESTAMPTZ DEFAULT now())');
const done = new Set((await query('SELECT name FROM _migrations')).map((r) => r.name));
for (const file of readdirSync(DIR).filter((f) => f.endsWith('.sql')).sort()) {
  if (done.has(file)) continue;
  const sql = readFileSync(path.join(DIR, file), 'utf8');
  await query(`BEGIN;\n${sql}\nINSERT INTO _migrations (name) VALUES ('${file.replace(/'/g, "''")}');\nCOMMIT;`);
  console.log('applied', file);
}
console.log('up to date');
