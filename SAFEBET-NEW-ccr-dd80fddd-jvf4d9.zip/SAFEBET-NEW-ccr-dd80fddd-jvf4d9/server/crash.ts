import { floor2, generateCrashPoint, msToReach, multiplierAt, parseAutoCashout } from '../shared/crash';
import { payoutFor, type Payout } from '../shared/payout';
import { assertActive, type Viewer } from './auth';
import { activeBrainrots } from './catalog';
import { num, ms, one, tx, type Queryable } from './db';
import { payOut, recordDrop, takeItem } from './economy';
import { bad, notFound } from './errors';
import { int, type Body } from './validate';

interface RoundRow {
  id: string;
  user_id: string;
  brainrot_id: string;
  stake_value: string;
  crash_point: string;
  auto_cashout: string | null;
  started_at: string;
  status: 'flying' | 'crashed' | 'cashed';
  cashed_at: string | null;
  /** A demo brainrot's flight (iteration 35): the cash-out is demo. */
  demo?: boolean;
}

export interface CrashResult {
  status: 'flying' | 'crashed' | 'cashed';
  roundId: number;
  crashPoint?: number;
  cashedAt?: number;
  payout?: { brainrotId: string | null; coins: number; itemId: number | null };
}

const WAIT_LIMIT_MS = 24_000;

function timeline(r: RoundRow) {
  const crashPoint = Number(r.crash_point);
  const auto = r.auto_cashout === null ? null : Number(r.auto_cashout);
  return {
    crashPoint,
    auto,
    startedAt: ms(r.started_at)!,
    crashAt: msToReach(crashPoint),
    autoAt: auto !== null && auto <= crashPoint ? msToReach(auto) : Infinity,
  };
}

function finished(r: RoundRow, payout?: CrashResult['payout']): CrashResult {
  return {
    status: r.status,
    roundId: num(r.id),
    crashPoint: Number(r.crash_point),
    cashedAt: r.cashed_at === null ? undefined : Number(r.cashed_at),
    payout,
  };
}

/** Decides a locked flying round at time `now`; `manual` means the player pressed cash-out. */
async function settle(c: Queryable, r: RoundRow, now: number, manual: boolean): Promise<CrashResult> {
  if (r.status !== 'flying') return finished(r);
  const t = timeline(r);
  const elapsed = now - t.startedAt;
  let cashAt: number | null = null;
  if (t.autoAt <= elapsed) cashAt = t.auto;
  else if (t.crashAt <= elapsed) cashAt = null;
  else if (manual) cashAt = Math.max(1, floor2(multiplierAt(elapsed)));
  else return { status: 'flying', roundId: num(r.id) };

  const userId = num(r.user_id);
  const stake = num(r.stake_value);
  const demo = r.demo === true;
  if (cashAt === null) {
    await c.query(`UPDATE crash_rounds SET status = 'crashed', finished_at = now() WHERE id = $1`, [r.id]);
    await recordDrop(c, { userId, game: 'crash', win: false, stakeValue: stake, meta: { crashPoint: t.crashPoint }, demo });
    return finished({ ...r, status: 'crashed' });
  }
  const payout: Payout = payoutFor(stake * cashAt, await activeBrainrots(c));
  const itemId = await payOut(c, userId, payout, 'crash', demo);
  await c.query(`UPDATE crash_rounds SET status = 'cashed', cashed_at = $2, finished_at = now() WHERE id = $1`, [r.id, cashAt]);
  await recordDrop(c, {
    userId,
    game: 'crash',
    win: true,
    stakeValue: stake,
    brainrotId: payout.brainrot?.id,
    coins: payout.coins,
    meta: { crashPoint: t.crashPoint, cashedAt: cashAt },
    demo,
  });
  return finished({ ...r, status: 'cashed', cashed_at: String(cashAt) }, {
    brainrotId: payout.brainrot?.id ?? null,
    coins: payout.coins,
    itemId,
  });
}

async function lockRound(c: Queryable, userId: number, roundId: number) {
  const { rows } = await c.query<RoundRow>('SELECT * FROM crash_rounds WHERE id = $1 AND user_id = $2 FOR UPDATE', [roundId, userId]);
  if (!rows[0]) throw notFound('Раунд не найден');
  return rows[0];
}

/** Closes a round whose outcome is already decided by time (player closed the app mid-flight). */
export async function resolveStaleCrash(userId: number) {
  const open = await one<{ id: string }>(`SELECT id FROM crash_rounds WHERE user_id = $1 AND status = 'flying'`, [userId]);
  if (!open) return;
  await tx(async (c) => settle(c, await lockRound(c, userId, num(open.id)), Date.now(), false));
}

export async function startCrash(v: Viewer, body: Body) {
  assertActive(v);
  const itemId = int(body.itemId, 'предмет');
  const auto = body.auto === null || body.auto === undefined ? null : parseAutoCashout(String(body.auto));
  if (body.auto !== null && body.auto !== undefined && auto === null) throw bad('invalid', 'Авто-вывод: от 1.01 до 100');
  await resolveStaleCrash(v.id);
  return tx(async (c) => {
    const flying = await c.query(`SELECT 1 FROM crash_rounds WHERE user_id = $1 AND status = 'flying'`, [v.id]);
    if (flying.rows.length) throw bad('active_round', 'Сначала дождись конца текущего полёта');
    const stake = await takeItem(c, v.id, itemId);
    const crashPoint = generateCrashPoint();
    const { rows } = await c.query<{ id: string; started_at: string }>(
      `INSERT INTO crash_rounds (user_id, brainrot_id, stake_value, crash_point, auto_cashout, demo)
       VALUES ($1, $2, $3, $4, $5, $6) RETURNING id, started_at`,
      [v.id, stake.brainrotId, stake.price, crashPoint, auto, stake.demo],
    );
    await c.query('UPDATE users SET crash_rounds = crash_rounds + 1 WHERE id = $1', [v.id]);
    return { roundId: num(rows[0]!.id), startedAt: ms(rows[0]!.started_at)!, serverNow: Date.now(), auto };
  });
}

export async function cashOutCrash(v: Viewer, body: Body): Promise<CrashResult> {
  const roundId = int(body.roundId, 'раунд');
  return tx(async (c) => settle(c, await lockRound(c, v.id, roundId), Date.now(), true));
}

/** Long-poll until the round ends (crash or auto cash-out) or ~24 s pass; the client simply calls again. */
export async function waitCrash(v: Viewer, body: Body, sleep = (ms: number) => new Promise((r) => setTimeout(r, ms))): Promise<CrashResult> {
  const roundId = int(body.roundId, 'раунд');
  const deadline = Date.now() + WAIT_LIMIT_MS;
  for (;;) {
    const row = await one<RoundRow>('SELECT * FROM crash_rounds WHERE id = $1 AND user_id = $2', [roundId, v.id]);
    if (!row) throw notFound('Раунд не найден');
    if (row.status !== 'flying') return finished(row);
    const t = timeline(row);
    const now = Date.now();
    const nextEvent = t.startedAt + Math.min(t.autoAt, t.crashAt);
    if (now >= nextEvent) {
      const result = await tx(async (c) => settle(c, await lockRound(c, v.id, roundId), Date.now(), false));
      if (result.status !== 'flying') return result;
    }
    if (now >= deadline) return { status: 'flying', roundId };
    // The crash / auto cash-out moment is known: sleep until it (a cash-out answers its own request), re-reading at
    // most once a second instead of four times — under a crowd those reads held the database's connections.
    await sleep(Math.max(20, Math.min(1000, nextEvent - now)));
  }
}
