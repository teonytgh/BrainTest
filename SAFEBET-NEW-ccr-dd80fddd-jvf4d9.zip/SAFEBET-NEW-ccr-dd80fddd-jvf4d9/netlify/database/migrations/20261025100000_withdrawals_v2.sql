-- Iteration 12: withdrawals of several brainrots with a scheduled 5-minute trade window; locked items.

-- The 8 brainrots from the BRAINROTFARM screenshots were added hidden; the owner wants them in the catalog
-- (the picture comes later). Only the ones still hidden — an admin's own choice since then stays.
UPDATE brainrots SET status = 'active', updated_at = now()
WHERE status = 'hidden' AND id IN ('pancake-and-syrup', 'bumbatron', 'la-breakfast-combinasion', 'sammyni-cakini',
  'la-fuse-machine', 'los-chillis', 'rubrikiko', 'examen-bros');

-- Admins choose which brainrots can be withdrawn (without removing them from the catalog).
ALTER TABLE brainrots ADD COLUMN withdrawable BOOLEAN NOT NULL DEFAULT true;

ALTER TABLE withdrawals ALTER COLUMN brainrot_id DROP NOT NULL;
ALTER TABLE withdrawals DROP CONSTRAINT IF EXISTS withdrawals_status_check;
ALTER TABLE withdrawals ADD CONSTRAINT withdrawals_status_check
  CHECK (status IN ('pending', 'scheduled', 'trading', 'expired', 'done', 'rejected', 'cancelled'));
ALTER TABLE withdrawals
  ADD COLUMN items JSONB NOT NULL DEFAULT '[]'::jsonb,
  ADD COLUMN scheduled_at TIMESTAMPTZ,
  ADD COLUMN bot_nick TEXT,
  ADD COLUMN trade_deadline TIMESTAMPTZ,
  ADD COLUMN reminded_at TIMESTAMPTZ,
  ADD COLUMN admin_messages JSONB NOT NULL DEFAULT '[]'::jsonb,
  ADD COLUMN updated_at TIMESTAMPTZ NOT NULL DEFAULT now();
-- Old single-item requests keep their history in the new shape.
UPDATE withdrawals w SET items = jsonb_build_array(jsonb_build_object('brainrotId', w.brainrot_id, 'name', b.name, 'count', 1, 'price', w.value))
FROM brainrots b WHERE b.id = w.brainrot_id AND w.items = '[]'::jsonb;
-- One open request per player: the inventory shows «НА ВЫВОДЕ» for exactly one request.
CREATE UNIQUE INDEX withdrawals_one_open ON withdrawals (user_id) WHERE status IN ('pending', 'scheduled', 'trading', 'expired');
CREATE INDEX withdrawals_due ON withdrawals (scheduled_at) WHERE status IN ('scheduled', 'trading');

-- Items on a withdrawal stay in the inventory, locked. Nothing may delete them until the request is done.
ALTER TABLE inventory ADD COLUMN withdrawal_id BIGINT REFERENCES withdrawals (id);
CREATE INDEX inventory_withdrawal ON inventory (withdrawal_id) WHERE withdrawal_id IS NOT NULL;

CREATE FUNCTION inventory_withdraw_guard() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF OLD.withdrawal_id IS NOT NULL
     AND NOT EXISTS (SELECT 1 FROM withdrawals w WHERE w.id = OLD.withdrawal_id AND w.status = 'done') THEN
    RAISE EXCEPTION 'inventory item % is on withdrawal %', OLD.id, OLD.withdrawal_id USING ERRCODE = 'P0001';
  END IF;
  RETURN OLD;
END $$;
CREATE TRIGGER inventory_withdraw_guard BEFORE DELETE ON inventory FOR EACH ROW EXECUTE FUNCTION inventory_withdraw_guard();
REVOKE ALL ON FUNCTION inventory_withdraw_guard() FROM PUBLIC;

INSERT INTO settings (key, value) VALUES ('withdraw_rules', '{"minValue": 100, "minItems": 2, "minItemPrice": 45}')
ON CONFLICT (key) DO NOTHING;
