import { sfx } from './sound';
import { haptic } from './telegram';

const PRESSABLE = 'button, a[href], [role="tab"], [role="radio"], [role="switch"], summary, label.chip';

/**
 * Every press of a button, link, tab or switch gets a soft click and a light tick of vibration, so the whole
 * app feels the same without each component wiring it up. Components keep their own richer sounds (coins,
 * wins); sfx.tap() right after this one is skipped to avoid a double click.
 */
export function installPressFeedback() {
  let last = 0;
  document.addEventListener(
    'pointerdown',
    (e) => {
      const el = (e.target as Element | null)?.closest?.(PRESSABLE);
      if (!el || el.matches(':disabled, [aria-disabled="true"]')) return;
      const now = performance.now();
      if (now - last < 70) return;
      last = now;
      sfx.press();
      haptic('select');
    },
    { capture: true, passive: true },
  );
}
