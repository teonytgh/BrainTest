/**
 * Батл пасс (iteration 37, reworked in iteration 39): a season is a calendar month (Moscow time), 30 levels. Experience
 * comes from real stakes (1 per 1 B in the 12 % games, 0.5 in mines, road and crash — they keep 6 %) and from claimed
 * quests. Two tracks: FREE on top for everybody (iteration 39, the owner: «на фри дохуя фармят» — a reward on about
 * every other level only: a few tickets and three cheap brainrots, ≈ 40 B over the season) and BPlus below, bought for
 * 299 ⭐: coins, tickets and free openings of paid cases (no brainrots — the owner: «всякое кроме брейнротов, а то никто
 * не купит»), 1.5× its price over the 30 levels, open at once for every level already reached.
 *
 * «Не в минус»: the whole pass is ≈ 8 000 XP ≈ 5 000+ B of stakes; the house's edge on them (≈ 440 B after the quest
 * tickets) pays for FREE (≈ 40 B) and for what BPlus gives over its price (≈ 200 B; a case opening is counted at the
 * case's price, while it costs the house only what the case pays back). Rewards are bonus value: coins and what the
 * openings and tickets drop are played through before a withdrawal like any bonus. What is not claimed burns with the
 * season.
 */

export const PASS_LEVELS = 30;
export const PASS_PLUS_STARS = 299;
/** BPlus gives this many times its price (at the current star rate) over the whole track. */
export const PASS_PLUS_RETURN = 1.5;

/** XP to go from level `level - 1` to `level` (1…30): 120, 130, … 410 — 7 950 in all. */
export const passXpFor = (level: number) => 120 + 10 * (level - 1);
export const PASS_XP_TOTAL = Array.from({ length: PASS_LEVELS }, (_, i) => passXpFor(i + 1)).reduce((a, b) => a + b, 0);

/** XP per 1 B staked, by game: the 6 % games give half (their edge pays half as much). */
export const PASS_XP_PER_B: Record<string, number> = { case: 1, battle: 1, upgrade: 1, fuse: 1, dice: 1, mines: 0.5, road: 0.5, crash: 0.5 };
export const PASS_QUEST_XP = { daily: 20, weekly: 60 };

/** The level reached with `xp`, and the progress towards the next one. */
export function passLevelOf(xp: number): { level: number; into: number; need: number } {
  let left = Math.max(0, Math.floor(xp));
  for (let level = 1; level <= PASS_LEVELS; level++) {
    const need = passXpFor(level);
    if (left < need) return { level: level - 1, into: left, need };
    left -= need;
  }
  return { level: PASS_LEVELS, into: 0, need: 0 };
}

/**
 * tickets / coins: that many; brainrot: the dearest brainrot not above the value + change in coins (FREE); case: a free
 * opening of the dearest paid case not above the value + change in coins (BPlus).
 */
export type PassReward = { kind: 'tickets'; amount: number } | { kind: 'brainrot'; value: number } | { kind: 'coins'; amount: number } | { kind: 'case'; value: number };
export type PassTrack = 'free' | 'plus';

/**
 * FREE (null = nothing on that level): a cheap brainrot on levels 10 / 20 / 30, 15 tickets on 5 / 15 / 25, 5 tickets on
 * every third level — ≈ 30 B in brainrots + 85 tickets.
 */
export const PASS_FREE: (PassReward | null)[] = Array.from({ length: PASS_LEVELS }, (_, i) => {
  const level = i + 1;
  if (level % 10 === 0) return { kind: 'brainrot', value: level === PASS_LEVELS ? 15 : level === 20 ? 10 : 6 };
  if (level % 5 === 0) return { kind: 'tickets', amount: 15 };
  if (level % 3 === 0) return { kind: 'tickets', amount: 5 };
  return null;
});

/** BPlus: a case opening every fifth level (bigger on 10, 20 and the top), tickets every third, coins on the rest. */
const PLUS_SLOTS = Array.from({ length: PASS_LEVELS }, (_, i) => {
  const level = i + 1;
  if (level === PASS_LEVELS) return { kind: 'case' as const, weight: 10 };
  if (level % 10 === 0) return { kind: 'case' as const, weight: 5 };
  if (level % 5 === 0) return { kind: 'case' as const, weight: 4 };
  if (level % 3 === 0) return { kind: 'tickets' as const, weight: 1 };
  return { kind: 'coins' as const, weight: 1 };
});
const PLUS_WEIGHT_SUM = PLUS_SLOTS.reduce((a, b) => a + b.weight, 0);

/** The BPlus track at a star rate: worth 1.5× the price in coins (tickets at their cost to the house), spread by the weights. */
export function passPlus(starRate: number, ticketValue: number): PassReward[] {
  const total = PASS_PLUS_STARS * starRate * PASS_PLUS_RETURN;
  return PLUS_SLOTS.map(({ kind, weight }) => {
    const value = (total * weight) / PLUS_WEIGHT_SUM;
    if (kind === 'tickets') return { kind, amount: Math.floor(value / ticketValue) };
    if (kind === 'coins') return { kind, amount: Math.floor(value) };
    return { kind, value: Math.floor(value) };
  });
}

/** Cases a BPlus opening can be: paid, on, with a fixed price (a floating one moves under the reward). */
export interface PassCaseOption {
  id: string;
  name: string;
  image: string;
  price: number;
  kind: string;
  status: string;
  bonus: string | null;
  priceCycle: readonly number[] | null;
}

/** The case of a `case` reward: the dearest one not above the value; the rest comes as coins (all of it when none fits). */
export function passCaseFor<T extends PassCaseOption>(value: number, cases: readonly T[]): { case: T | null; coins: number } {
  let best: T | null = null;
  for (const c of cases) {
    if (c.kind !== 'paid' || c.status !== 'active' || c.bonus || c.priceCycle?.length || !(c.price > 0)) continue;
    if (c.price <= value && (!best || c.price > best.price)) best = c;
  }
  return { case: best, coins: Math.max(0, Math.round((value - (best?.price ?? 0)) * 100) / 100) };
}

/** What a reward is worth in B (a ticket ≈ its cost to the house, a case opening its price). */
export const rewardValue = (r: PassReward | null, ticketValue: number) =>
  !r ? 0 : r.kind === 'tickets' ? r.amount * ticketValue : r.kind === 'coins' ? r.amount : r.value;

// ---------- Seasons ----------

const MSK_MS = 3 * 3_600_000;

/** The season of a moment: its id (`2026-10`), start and end (ms), in Moscow time. */
export function passSeason(now: number): { id: string; start: number; end: number; name: string } {
  const d = new Date(now + MSK_MS);
  const y = d.getUTCFullYear();
  const m = d.getUTCMonth();
  const start = Date.UTC(y, m, 1) - MSK_MS;
  const end = Date.UTC(y, m + 1, 1) - MSK_MS;
  return { id: `${y}-${String(m + 1).padStart(2, '0')}`, start, end, name: SEASON_NAMES[m]! };
}

const SEASON_NAMES = ['Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь', 'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'];
