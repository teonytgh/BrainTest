import { useLayoutEffect, useRef } from 'react';
import { dismissToast, useToasts } from '../store/toast';

/** The Popover API puts the toasts in the top layer; older WebViews just get a high z-index. */
const canPopover = typeof HTMLElement !== 'undefined' && typeof HTMLElement.prototype.showPopover === 'function';

/**
 * Sheets are modal <dialog>s in the browser's top layer, above any z-index, and the case opening covers the page:
 * a plain fixed toast would sit under them and errors there would go unseen. So each new toast re-shows the toaster
 * as a popover — the top layer stacks in show order, so it lands above whatever is open.
 */
export function Toaster() {
  const toasts = useToasts();
  const ref = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const el = ref.current;
    if (!el || !canPopover) return;
    if (!el.hasAttribute('popover')) el.setAttribute('popover', 'manual');
    try {
      if (el.matches(':popover-open')) el.hidePopover();
      if (toasts.length) el.showPopover();
    } catch {
      // Not connected yet or the API misbehaves: the z-index fallback still shows the toasts.
    }
  }, [toasts]);

  return (
    <div ref={ref} className="toaster" role="status" aria-live="polite">
      {toasts.map((t) => (
        <button key={t.id} type="button" className={`toast toast--${t.tone}`} onClick={() => dismissToast(t.id)}>
          {t.text}
        </button>
      ))}
    </div>
  );
}
