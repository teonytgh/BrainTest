import { useMemo, useSyncExternalStore } from 'react';

export const ROUTES = [
  'home',
  'upgrader',
  'battle',
  'dice',
  'crash',
  'road',
  'mines',
  'fuse',
  'sky',
  'squid',
  'tacos',
  'quests',
  'pass',
  'ranks',
  'terms',
  'privacy',
  'giveaways',
  'faq',
  'bonuses',
  'referrals',
  'profile',
  'case',
  'admin',
] as const;

export type RouteName = (typeof ROUTES)[number];
export type Route = RouteName;

export interface RouteState {
  name: RouteName;
  param: string | null;
}

function subscribe(cb: () => void) {
  window.addEventListener('hashchange', cb);
  return () => window.removeEventListener('hashchange', cb);
}

export function parseHash(hash: string): RouteState {
  const [head = '', ...rest] = hash.replace(/^#\/?/, '').split('/');
  const name = (ROUTES as readonly string[]).includes(head) ? (head as RouteName) : 'home';
  return { name, param: rest.length ? decodeURIComponent(rest.join('/')) : null };
}

export function useRoute(): RouteState {
  const hash = useSyncExternalStore(subscribe, () => window.location.hash, () => '');
  return useMemo(() => parseHash(hash), [hash]);
}

export function routeHref(name: RouteName, param?: string | null): string {
  if (name === 'home') return '#/';
  return param ? `#/${name}/${encodeURIComponent(param)}` : `#/${name}`;
}

export function navigate(name: RouteName, param?: string | null) {
  window.location.hash = routeHref(name, param);
}
