import { useSyncExternalStore } from 'react';

/**
 * «Листопад» (iteration 40): the falling autumn leaves, on by default; a weak phone can switch them off in Настройки.
 * Device-local (brainrotcrash:leaves), like the music switch.
 */
const KEY = 'brainrotcrash:leaves';
const listeners = new Set<() => void>();

function read(): boolean {
  try {
    return localStorage.getItem(KEY) !== 'off';
  } catch {
    return true;
  }
}

let on = read();

export function setLeaves(value: boolean) {
  on = value;
  try {
    localStorage.setItem(KEY, value ? 'on' : 'off');
  } catch {
    // Private mode: the switch lasts this visit.
  }
  listeners.forEach((l) => l());
}

export function useLeaves(): boolean {
  return useSyncExternalStore(
    (l) => {
      listeners.add(l);
      return () => listeners.delete(l);
    },
    () => on,
  );
}
