import { useQuery } from '@tanstack/react-query';
import { useEffect, useMemo, useState, type FormEvent } from 'react';
import { BrainrotCard, BrainrotThumb } from './BrainrotCard';
import { Coin } from './Coin';
import { EmptyState } from './EmptyState';
import { Icon } from './Icon';
import { Sheet } from './Sheet';
import { api, errorMessage } from '../api/client';
import { act, queryClient, setMe, useCatalog, useMe } from '../api/queries';
import type { WithdrawalView } from '../../server/withdrawals';
import { MAX_WITHDRAW_ITEMS, OPEN_WITHDRAW_STATUSES, WITHDRAW_STATUS_LABEL, exchangeOffers, exchangeable, formatMsk, inStock, wagerProblem, withdrawBlock, withdrawProblem, type ExchangeOffer } from '../../shared/withdraw';
import type { Brainrot } from '../../shared/types';
import { tierOf } from '../lib/tier';
import { cx, formatCoins } from '../lib/format';
import { sfx } from '../lib/sound';
import { haptic } from '../lib/telegram';
import { useNow } from '../lib/useNow';
import { toast } from '../store/toast';
import { closeWithdraw, useUi } from '../store/ui';
import { copyText } from '../lib/copy';
import { navigate } from '../lib/router';
import { WagerMeter } from './Wager';

const NICK_KEY = 'brainrotcrash:robloxNick';
const SEEN_KEY = 'brainrotcrash:withdrawSeen';

export type Withdrawal = WithdrawalView;

export const isOpenWithdrawal = (w: Withdrawal | null | undefined): w is Withdrawal => !!w && OPEN_WITHDRAW_STATUSES.includes(w.status);

/** The player's latest withdrawal; refreshed live (topic «withdrawal») and every 30 s while one is open. */
export function useCurrentWithdrawal() {
  return useQuery({
    queryKey: ['withdrawal'],
    queryFn: () => api<Withdrawal | null>('/api/withdrawals/current'),
    staleTime: 10_000,
    refetchInterval: (q) => (isOpenWithdrawal(q.state.data) ? 30_000 : false),
  });
}

function refreshWithdrawals() {
  void queryClient.invalidateQueries({ queryKey: ['withdrawal'] });
  void queryClient.invalidateQueries({ queryKey: ['withdrawals'] });
}

/** «Вывод»: a new request (pick brainrots, nick, send) or the open one with its status and «Отменить». */
export function WithdrawSheet() {
  const { withdraw } = useUi();
  const current = useCurrentWithdrawal();
  const open = isOpenWithdrawal(current.data) ? current.data : null;
  return (
    <Sheet open={withdraw.open} onClose={closeWithdraw} title={open ? `Вывод #${open.id}` : 'Вывод в Roblox'}>
      {withdraw.open && (open ? <WithdrawStatus w={open} /> : <WithdrawForm key={withdraw.preselect ?? 'none'} preselect={withdraw.preselect} />)}
    </Sheet>
  );
}

/** `demo`: an admin's demo gift or its win — never withdrawn or exchanged (iteration 35). */
type RowKind = 'ok' | 'swap' | 'junk' | 'demo';

function WithdrawForm({ preselect }: { preselect: number | null }) {
  const me = useMe();
  const catalog = useCatalog();
  const rules = me.withdrawRules;
  const [picked, setPicked] = useState<number[]>(() => (preselect !== null ? [preselect] : []));
  const [nick, setNick] = useState(() => {
    try {
      return localStorage.getItem(NICK_KEY) ?? '';
    } catch {
      return '';
    }
  });
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const stock = useMemo(() => inStock(catalog.brainrots, rules), [catalog.brainrots, rules]);

  // In stock first (dearest on top), then what has to be exchanged, then junk.
  const rows = useMemo(
    () =>
      me.inventory
        .filter((i) => !i.withdrawalId && catalog.byId.has(i.brainrotId))
        .map((item) => {
          const b = catalog.byId.get(item.brainrotId)!;
          const kind: RowKind = item.demo ? 'demo' : !withdrawBlock(b, rules) ? 'ok' : exchangeable(b, rules) ? 'swap' : 'junk';
          return { item, b, kind };
        })
        .sort((x, y) => ORDER[x.kind] - ORDER[y.kind] || y.b.price - x.b.price),
    [me.inventory, catalog.byId, rules],
  );
  const chosen = rows.filter((r) => picked.includes(r.item.id) && r.kind !== 'junk' && r.kind !== 'demo');
  const ready = chosen.filter((r) => r.kind === 'ok');
  const toSwap = chosen.filter((r) => r.kind === 'swap');
  const total = Math.round(ready.reduce((s, r) => s + r.b.price, 0) * 100) / 100;
  const problem = toSwap.length ? null : withdrawProblem(ready.map((r) => r.b), rules);
  // «Отыгрыш» (iteration 36): the server refuses the request until it is played out; exchanging still works.
  const unplayed = wagerProblem(me.user.wager);

  function toggle(id: number) {
    setError(null);
    setPicked((list) => {
      if (list.includes(id)) return list.filter((x) => x !== id);
      if (list.length >= MAX_WITHDRAW_ITEMS) {
        toast(`За один вывод — до ${MAX_WITHDRAW_ITEMS} брейнротов`);
        return list;
      }
      return [...list, id];
    });
    sfx.tap();
  }

  async function submit(e: FormEvent) {
    e.preventDefault();
    if (toSwap.length) {
      setError('Сначала разменяй брейнротов, которых нет в наличии');
      sfx.error();
      return;
    }
    if (problem) {
      setError(problem);
      sfx.error();
      return;
    }
    if (unplayed) {
      setError(unplayed);
      sfx.error();
      return;
    }
    if (!/^[A-Za-z0-9_]{3,20}$/.test(nick)) {
      setError('Ник в Roblox: латиница, цифры и _ (3–20 символов)');
      return;
    }
    setBusy(true);
    try {
      const r = await act<Withdrawal>('/api/withdrawals', { itemIds: ready.map((c) => c.item.id), robloxNick: nick });
      setMe(r.me);
      queryClient.setQueryData(['withdrawal'], r.result);
      void queryClient.invalidateQueries({ queryKey: ['withdrawals'] });
      try {
        localStorage.setItem(NICK_KEY, nick);
      } catch {
        // The nick just won't be remembered.
      }
      sfx.coin();
      haptic('success');
      toast('Заявка на вывод отправлена — подбираем время', 'success');
    } catch (err) {
      sfx.error();
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  }

  if (!rows.length) {
    return <EmptyState icon="box" title="Выводить нечего" text="Брейнроты из инвентаря появятся здесь — открой кейс или выиграй в апгрейдере." />;
  }

  return (
    <form className="form wd-form" onSubmit={submit} noValidate>
      <WagerMeter
        wager={me.user.wager}
        rules={rules}
        onPlay={() => {
          closeWithdraw();
          navigate('home');
        }}
      />
      <div className="wd-stock">
        <p className="wd-stock__title">
          <Icon name="check" size={14} /> В наличии для вывода
        </p>
        <div className="wd-stock__list">
          {stock.map((b) => (
            <span key={b.id} className={cx('wd-stock__item', `tier-${tierOf(b.price)}`)}>
              <img src={b.image} alt="" />
              <span>
                {b.name}
                <small>
                  {formatCoins(b.price)} <Coin size={10} />
                </small>
              </span>
            </span>
          ))}
        </div>
        <p className="wd-stock__hint">
          Других брейнротов (от {formatCoins(rules.minItemPrice)} B) можно разменять на эти — сдача придёт монетами. Вывод — от {rules.minItems} брейнротов или на сумму от{' '}
          {formatCoins(rules.minValue)} B.
        </p>
      </div>
      <div className="grid wd-grid">
        {rows.map(({ item, b, kind }) => {
          const on = picked.includes(item.id) && kind !== 'junk' && kind !== 'demo';
          return (
            <BrainrotCard
              key={item.id}
              brainrot={b}
              selected={on}
              disabled={kind === 'junk' || kind === 'demo' || busy}
              muted={kind !== 'ok'}
              demo={kind === 'demo'}
              meta={kind === 'swap' ? 'Нет в наличии · размен' : kind === 'junk' ? 'Хлам — только продать' : kind === 'demo' ? 'Демо — не выводится' : undefined}
              badge={on ? <Icon name={kind === 'swap' ? 'reset' : 'check'} size={12} /> : undefined}
              onClick={() => toggle(item.id)}
            />
          );
        })}
      </div>
      {toSwap.length > 0 && (
        <ExchangeBox
          // A new selection starts again from the best offer.
          key={toSwap.map((r) => r.item.id).join(',')}
          items={toSwap.map((r) => ({ id: r.item.id, brainrot: r.b }))}
          stock={stock}
          onDone={(newIds) => {
            // The exchanged brainrots leave; what came in is picked for the withdrawal right away.
            setPicked((list) => [...list.filter((id) => !toSwap.some((r) => r.item.id === id)), ...newIds].slice(0, MAX_WITHDRAW_ITEMS));
            setError(null);
          }}
        />
      )}
      <div className={cx('wd-total', !problem && !toSwap.length && ready.length > 0 && 'is-ok')}>
        <span>
          К выводу <b>{ready.length}</b> на <b>{formatCoins(total)}</b> <Coin size={14} />
        </span>
        {chosen.length > 0 && (
          <button type="button" className="link-btn" onClick={() => setPicked([])}>
            Сбросить
          </button>
        )}
      </div>
      {ready.length > 0 && problem && <p className="wd-problem">{problem}</p>}
      <label className="field">
        <span className="field__label">Твой ник в Roblox</span>
        <span className={cx('field__control', error && 'has-error')}>
          <input
            autoComplete="off"
            autoCapitalize="off"
            spellCheck={false}
            value={nick}
            placeholder="Nickname"
            onChange={(e) => {
              setNick(e.target.value.trim().slice(0, 20));
              setError(null);
            }}
          />
        </span>
        {error && <span className="field__error">{error}</span>}
      </label>
      <button type="submit" className="btn btn--primary btn--lg btn--block" disabled={busy || !ready.length || toSwap.length > 0 || !!unplayed}>
        <Icon name={unplayed ? 'lock' : 'arrowUp'} size={18} /> {unplayed ? `Сначала отыграй ${formatCoins(me.user.wager.left)} B` : 'Отправить вывод'}
      </button>
      <p className="form__note">Брейнроты остаются в инвентаре с пометкой «НА ВЫВОДЕ» — их нельзя продать или поставить. Админ назначит время и бота для трейда, мы пришлём сообщение в бот.</p>
    </form>
  );
}

const ORDER: Record<RowKind, number> = { ok: 0, swap: 1, junk: 2, demo: 3 };

/**
 * «Нет в наличии»: ready-made offers (closest fit first, then one kind each) and steppers to adjust; the change
 * is paid to the balance.
 */
function ExchangeBox({ items, stock, onDone }: { items: { id: number; brainrot: Brainrot }[]; stock: Brainrot[]; onDone: (newIds: number[]) => void }) {
  const value = Math.round(items.reduce((s, i) => s + i.brainrot.price, 0) * 100) / 100;
  const offers = useMemo(() => exchangeOffers(value, stock), [value, stock]);
  const [take, setTake] = useState<Record<string, number>>(() => Object.fromEntries((offers[0]?.take ?? []).map((t) => [t.brainrotId, t.count])));
  const [busy, setBusy] = useState(false);
  const priceOf = (id: string) => stock.find((b) => b.id === id)?.price ?? 0;
  const pieces = Object.values(take).reduce((a, b) => a + b, 0);
  const totalTake = Math.round(Object.entries(take).reduce((s, [id, n]) => s + priceOf(id) * n, 0) * 100) / 100;
  const change = Math.round((value - totalTake) * 100) / 100;
  const sameAs = (o: ExchangeOffer) => o.take.length === Object.values(take).filter((n) => n > 0).length && o.take.every((t) => take[t.brainrotId] === t.count);

  function step(id: string, d: number) {
    const next = Math.max(0, (take[id] ?? 0) + d);
    const nextTotal = totalTake + d * priceOf(id);
    if (d > 0 && (nextTotal > value + 0.001 || pieces >= MAX_WITHDRAW_ITEMS)) {
      sfx.error();
      return;
    }
    sfx.tick();
    setTake((t) => ({ ...t, [id]: next }));
  }

  async function exchange() {
    setBusy(true);
    try {
      const r = await act<{ itemIds: number[]; change: number }>('/api/withdrawals/exchange', {
        itemIds: items.map((i) => i.id),
        take: Object.entries(take)
          .filter(([, n]) => n > 0)
          .map(([brainrotId, count]) => ({ brainrotId, count })),
      });
      setMe(r.me);
      sfx.coin();
      haptic('success');
      toast(`Размен готов${r.result.change > 0 ? ` — сдача ${formatCoins(r.result.change)} B на балансе` : ''}`, 'success');
      onDone(r.result.itemIds);
    } catch (e) {
      sfx.error();
      toast(errorMessage(e), 'error');
    } finally {
      setBusy(false);
    }
  }

  if (!offers.length) {
    return (
      <div className="wd-swap">
        <p className="wd-swap__title">Нет в наличии · {formatCoins(value)} B</p>
        <p className="wd-swap__text">Этого не хватает даже на самого дешёвого брейнрота из наличия. Добавь ещё брейнротов или продай их.</p>
      </div>
    );
  }

  return (
    <div className="wd-swap">
      <p className="wd-swap__title">
        <Icon name="reset" size={16} /> Таких брейнротов нет в наличии — разменяй их на {formatCoins(value)} B
      </p>
      <div className="wd-swap__offers" role="group" aria-label="Варианты размена">
        {offers.slice(0, 4).map((o, i) => (
          <button
            key={i}
            type="button"
            className={cx('wd-offer', sameAs(o) && 'is-on')}
            onClick={() => {
              sfx.tap();
              setTake(Object.fromEntries(o.take.map((t) => [t.brainrotId, t.count])));
            }}
          >
            <span className="wd-offer__take">
              {o.take.map((t) => {
                const b = stock.find((x) => x.id === t.brainrotId)!;
                return (
                  <span key={t.brainrotId} className="wd-offer__piece">
                    <img src={b.image} alt="" />
                    {t.count > 1 && <b>×{t.count}</b>}
                  </span>
                );
              })}
            </span>
            <small>{i === 0 ? 'Выгоднее всего · ' : ''}сдача {formatCoins(o.change)} B</small>
          </button>
        ))}
      </div>
      <ul className="wd-swap__steppers">
        {stock
          .filter((b) => b.price <= value + 0.001)
          .map((b) => (
            <li key={b.id}>
              <BrainrotThumb brainrot={b} size={34} />
              <span className="wd-swap__name">
                {b.name}
                <small>{formatCoins(b.price)} B</small>
              </span>
              <span className="wd-stepper">
                <button type="button" aria-label={`Меньше: ${b.name}`} disabled={!take[b.id] || busy} onClick={() => step(b.id, -1)}>
                  −
                </button>
                <b>{take[b.id] ?? 0}</b>
                <button type="button" aria-label={`Больше: ${b.name}`} disabled={busy} onClick={() => step(b.id, 1)}>
                  +
                </button>
              </span>
            </li>
          ))}
      </ul>
      <div className="wd-swap__sum">
        <span>
          Получишь {pieces} шт. на {formatCoins(totalTake)} B
        </span>
        <b>
          + сдача {formatCoins(change)} <Coin size={13} />
        </b>
      </div>
      <button type="button" className="btn btn--primary btn--block" disabled={busy || pieces === 0} onClick={exchange}>
        <Icon name="reset" size={16} /> Разменять
      </button>
    </div>
  );
}

function WithdrawStatus({ w }: { w: Withdrawal }) {
  const catalog = useCatalog();
  const now = useNow(1000);
  const [busy, setBusy] = useState(false);
  const left = w.deadline ? Math.max(0, w.deadline - now) : 0;

  async function cancel() {
    setBusy(true);
    try {
      const r = await act<Withdrawal>(`/api/withdrawals/${w.id}/cancel`);
      setMe(r.me);
      refreshWithdrawals();
      sfx.tap();
      toast('Вывод отменён — брейнроты снова в инвентаре', 'success');
      closeWithdraw();
    } catch (e) {
      toast(errorMessage(e), 'error');
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className={cx('wd-status', `is-${w.status}`)}>
      <WithdrawSteps status={w.status} />
      <div className="wd-status__card">
        {w.status === 'pending' && (
          <p>
            <b>На подборе.</b> Админ назначит дату и бота для трейда — придёт сообщение в бот.
          </p>
        )}
        {w.status === 'scheduled' && w.scheduledAt && (
          <p>
            <b>Назначено на {formatMsk(w.scheduledAt)}.</b> За 5 минут пришлём напоминание. Будь готов кинуть трейд на <code>{w.botNick}</code>.
          </p>
        )}
        {w.status === 'trading' && (
          <>
            <p>
              <b>Твоя очередь!</b> Кинь трейд в Roblox на ник:
            </p>
            <BotNick nick={w.botNick ?? ''} />
            <p className="wd-status__timer">
              <Icon name="clock" size={16} /> {Math.floor(left / 60_000)}:{String(Math.floor((left % 60_000) / 1000)).padStart(2, '0')}
            </p>
          </>
        )}
        {w.status === 'expired' && (
          <p>
            <b>Время на трейд вышло.</b> Брейнроты пока на выводе: админ назначит новое время или вернёт их в инвентарь.
          </p>
        )}
      </div>
      <ul className="wd-items">
        {w.items.map((i) => {
          const b = catalog.byId.get(i.brainrotId);
          return (
            <li key={i.brainrotId}>
              {b && <BrainrotThumb brainrot={b} size={40} />}
              <span className="wd-items__name">
                {i.name}
                {i.count > 1 && <small> ×{i.count}</small>}
              </span>
              <b>
                {formatCoins(i.price * i.count)} <Coin size={12} />
              </b>
            </li>
          );
        })}
      </ul>
      <p className="wd-status__sum">
        Всего {formatCoins(w.value)} <Coin size={14} /> · ник <code>{w.robloxNick}</code>
      </p>
      {w.canCancel ? (
        <button type="button" className="btn btn--ghost btn--block" disabled={busy} onClick={cancel}>
          Отменить вывод — вернуть брейнротов
        </button>
      ) : (
        <p className="form__note">После начала трейда отменить нельзя — заявку закроет админ: выведет или вернёт брейнротов. Вопросы — /paysupport в боте.</p>
      )}
    </div>
  );
}

const STEPS = [
  { id: 'pending', label: 'Подбор' },
  { id: 'scheduled', label: 'Время' },
  { id: 'trading', label: 'Трейд' },
  { id: 'done', label: 'Готово' },
] as const;

function WithdrawSteps({ status }: { status: Withdrawal['status'] }) {
  const at = status === 'expired' ? 2 : Math.max(0, STEPS.findIndex((s) => s.id === status));
  return (
    <ol className="wd-steps" aria-label={`Статус: ${WITHDRAW_STATUS_LABEL[status]}`}>
      {STEPS.map((s, i) => (
        <li key={s.id} className={cx(i < at && 'is-done', i === at && 'is-now', i === at && status === 'expired' && 'is-late')}>
          <span>{i < at ? <Icon name="check" size={12} /> : i + 1}</span>
          {s.label}
        </li>
      ))}
    </ol>
  );
}

function BotNick({ nick }: { nick: string }) {
  return (
    <button
      type="button"
      className="wd-bot"
      onClick={() => {
        copyText(nick, 'Ник скопирован');
      }}
    >
      <Icon name="bot" size={18} /> <b>{nick}</b> <Icon name="copy" size={14} />
    </button>
  );
}

/**
 * Pops up when the withdrawal changes in a way the player must see right now: it's their turn (bot nick and a
 * 5-minute timer), the time ran out, it was withdrawn or rejected. Each change is shown once.
 */
export function WithdrawalWatcher() {
  const current = useCurrentWithdrawal();
  const [shown, setShown] = useState<Withdrawal | null>(null);
  const w = current.data ?? null;

  useEffect(() => {
    if (!w || !['trading', 'expired', 'done', 'rejected'].includes(w.status)) return;
    const key = `${w.id}:${w.status}`;
    let seen: string[] = [];
    try {
      seen = JSON.parse(localStorage.getItem(SEEN_KEY) ?? '[]') as string[];
    } catch {
      seen = [];
    }
    // Finished requests older than a day aren't news any more.
    if (seen.includes(key) || (w.status !== 'trading' && Date.now() - w.updatedAt > 86_400_000)) return;
    try {
      localStorage.setItem(SEEN_KEY, JSON.stringify([...seen, key].slice(-20)));
    } catch {
      // Then it may show once more after a reload.
    }
    setShown(w);
    if (w.status === 'done') sfx.bigWin();
    else if (w.status === 'trading') sfx.whoosh();
    else sfx.error();
    haptic(w.status === 'done' ? 'success' : w.status === 'trading' ? 'tap' : 'error');
    void queryClient.invalidateQueries({ queryKey: ['me'] });
    void queryClient.invalidateQueries({ queryKey: ['withdrawals'] });
  }, [w]);

  const live = shown && w && w.id === shown.id ? w : shown;
  const title = live ? { trading: '🔔 Твоя очередь!', expired: '⌛ Время вышло', done: '✅ Вывод выполнен', rejected: '❌ Вывод отклонён' }[live.status as 'trading'] ?? '' : '';
  return (
    <Sheet open={!!live} onClose={() => setShown(null)} title={title}>
      {live && (
        <div className={cx('wd-pop', `is-${live.status}`)}>
          {live.status === 'trading' ? (
            <WithdrawStatus w={live} />
          ) : (
            <>
              <p>
                {live.status === 'expired' && `За 5 минут трейд по выводу #${live.id} не состоялся. Брейнроты пока на выводе — админ назначит новое время или вернёт их.`}
                {live.status === 'done' && `Вывод #${live.id} на ${formatCoins(live.value)} B выполнен — проверь Roblox!`}
                {live.status === 'rejected' && `Вывод #${live.id} отклонён — брейнроты вернулись в инвентарь.${live.note ? ` Причина: ${live.note}` : ''}`}
              </p>
              <button type="button" className="btn btn--primary btn--block" onClick={() => setShown(null)}>
                Понятно
              </button>
            </>
          )}
        </div>
      )}
    </Sheet>
  );
}
