-- Case pictures are now our own SVG chests (public/cases/<id>.svg); admin-uploaded images are left alone.
UPDATE cases SET image = '/cases/' || id || '.svg' WHERE image = '/cases/' || id || '.webp';
