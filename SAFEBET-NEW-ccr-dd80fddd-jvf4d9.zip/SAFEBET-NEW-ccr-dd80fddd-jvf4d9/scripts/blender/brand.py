"""BrainrotCrash brand art: the «BC» mark with a crash-chart arrow and the gold BC coin.

    blender -b --factory-startup --python scripts/blender/brand.py -- public [--quick]

Writes (WebP, alpha, cropped to the art):
  logo-bc-256.webp / logo-bc.webp  the mark: a glossy red B and blue C (Unbounded Black, scripts/blender/fonts) with a
                                    glowing gold zigzag arrow — the crash multiplier going up — cutting across them;
                                    256 px and 112 px high (header, splash, gate screens)
  coin-256.webp / coin.webp        the currency: a gold coin with an embossed BC, a beaded rim; 256 and 128 px
  brainrots/coin-prize.webp        the same coin as the picture of coin prizes in cases (COIN_PRIZE_IMAGE)
"""
import math
import os
import sys

import bpy
import numpy as np
from mathutils import Vector

ARGS = sys.argv[sys.argv.index('--') + 1:] if '--' in sys.argv else []
POSITIONAL = [a for a in ARGS if not a.startswith('--')]
OUT = os.path.abspath(POSITIONAL[0] if POSITIONAL else 'public')
QUICK = '--quick' in ARGS
SAMPLES = 32 if QUICK else 256
FONT = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'fonts', 'Unbounded-Black.ttf')


def lin(c):
    def ch(v):
        v /= 255
        return v / 12.92 if v <= 0.04045 else ((v + 0.055) / 1.055) ** 2.4
    return (ch(c[0]), ch(c[1]), ch(c[2]), 1.0)


def material(name, rgb, roughness=0.3, metallic=0.0, coat=0.0, emission=0.0, brushed=0.0):
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    nt = m.node_tree
    bsdf = nt.nodes['Principled BSDF']
    bsdf.inputs['Base Color'].default_value = lin(rgb)
    bsdf.inputs['Roughness'].default_value = roughness
    bsdf.inputs['Metallic'].default_value = metallic
    bsdf.inputs['Coat Weight'].default_value = coat
    bsdf.inputs['Coat Roughness'].default_value = 0.05
    if emission:
        bsdf.inputs['Emission Color'].default_value = lin(rgb)
        bsdf.inputs['Emission Strength'].default_value = emission
    if brushed:
        # Fine circular brushing on the coin field: a stretched noise drives the roughness and a faint bump.
        coord = nt.nodes.new('ShaderNodeTexCoord')
        noise = nt.nodes.new('ShaderNodeTexNoise')
        noise.inputs['Scale'].default_value = 60
        noise.inputs['Detail'].default_value = 6
        mapping = nt.nodes.new('ShaderNodeMapping')
        mapping.inputs['Scale'].default_value = (1, 1, 40)
        nt.links.new(coord.outputs['Object'], mapping.inputs['Vector'])
        nt.links.new(mapping.outputs['Vector'], noise.inputs['Vector'])
        rng = nt.nodes.new('ShaderNodeMapRange')
        rng.inputs['To Min'].default_value = roughness * 0.6
        rng.inputs['To Max'].default_value = roughness * 1.6
        nt.links.new(noise.outputs['Fac'], rng.inputs['Value'])
        nt.links.new(rng.outputs['Result'], bsdf.inputs['Roughness'])
        bump = nt.nodes.new('ShaderNodeBump')
        bump.inputs['Strength'].default_value = brushed
        nt.links.new(noise.outputs['Fac'], bump.inputs['Height'])
        nt.links.new(bump.outputs['Normal'], bsdf.inputs['Normal'])
    return m


def link(obj, mat=None, parent=None):
    bpy.context.scene.collection.objects.link(obj)
    if mat:
        obj.data.materials.append(mat)
    if parent:
        obj.parent = parent
    return obj


def text(body, size, depth, bevel, mat, parent=None):
    cu = bpy.data.curves.new(f'text_{body}', 'FONT')
    cu.body = body
    cu.font = bpy.data.fonts.load(FONT, check_existing=True)
    cu.size = size
    cu.extrude = depth
    cu.bevel_depth = bevel
    cu.bevel_resolution = 5
    cu.align_x = 'LEFT'
    cu.align_y = 'BOTTOM_BASELINE'
    return link(bpy.data.objects.new(f'text_{body}', cu), mat, parent)


def open_mouth(obj, angle=64):
    """Unbounded's C is nearly closed (it reads as an O when small): cut a wedge out of its right side."""
    x0, x1, y0, y1 = bounds(obj)
    cx, cy, r = (x0 + x1) / 2, (y0 + y1) / 2, (x1 - x0)
    half = math.radians(angle / 2)
    verts = [(cx, cy, -1), (cx + r * 2 * math.cos(half), cy + r * 2 * math.sin(half), -1), (cx + r * 2 * math.cos(half), cy - r * 2 * math.sin(half), -1)]
    verts += [(x, y, 1) for x, y, _ in verts]
    me = bpy.data.meshes.new('wedge')
    me.from_pydata(verts, [], [(0, 1, 2), (5, 4, 3), (0, 3, 4, 1), (1, 4, 5, 2), (2, 5, 3, 0)])
    wedge = link(bpy.data.objects.new('wedge', me))
    wedge.hide_render = True
    bpy.context.view_layer.objects.active = obj
    obj.select_set(True)
    bpy.ops.object.convert(target='MESH')
    mod = obj.modifiers.new('mouth', 'BOOLEAN')
    mod.operation = 'DIFFERENCE'
    mod.object = wedge
    mod.solver = 'EXACT'
    bpy.ops.object.modifier_apply(modifier='mouth')
    bpy.data.objects.remove(wedge, do_unlink=True)
    bpy.ops.object.shade_auto_smooth(angle=math.radians(40))
    return obj


def bounds(obj):
    bpy.context.view_layer.update()
    pts = [obj.matrix_world @ Vector(c) for c in obj.bound_box]
    return (min(p.x for p in pts), max(p.x for p in pts), min(p.y for p in pts), max(p.y for p in pts))


def flat_shape(name, outline, depth, bevel, mat, parent=None):
    """A filled 2D polygon (a curve, so concave outlines fill correctly), extruded and bevelled."""
    cu = bpy.data.curves.new(name, 'CURVE')
    cu.dimensions = '2D'
    cu.fill_mode = 'BOTH'
    cu.extrude = depth
    cu.bevel_depth = bevel
    cu.bevel_resolution = 4
    sp = cu.splines.new('POLY')
    sp.points.add(len(outline) - 1)
    for p, (x, y) in zip(sp.points, outline):
        p.co = (x, y, 0, 1)
    sp.use_cyclic_u = True
    return link(bpy.data.objects.new(name, cu), mat, parent)


def arrow_outline(points, half, head_half, head_len):
    """Outline of a polyline ribbon (mitred joints) that ends in an arrowhead at the last point."""
    pts = [Vector(p) for p in points]
    tip = pts[-1]
    d_last = (pts[-1] - pts[-2]).normalized()
    pts[-1] = tip - d_last * head_len  # the ribbon stops at the head's base
    left, right = [], []
    for i, p in enumerate(pts):
        d_in = (p - pts[i - 1]).normalized() if i > 0 else None
        d_out = (pts[i + 1] - p).normalized() if i < len(pts) - 1 else None
        if d_in is None:
            d_in = d_out
        if d_out is None:
            d_out = d_in
        n_in = Vector((-d_in.y, d_in.x))
        n_out = Vector((-d_out.y, d_out.x))
        miter = (n_in + n_out).normalized()
        scale = half / max(0.35, miter.dot(n_out))
        left.append(p + miter * scale)
        right.append(p - miter * scale)
    n = Vector((-d_last.y, d_last.x))
    base = pts[-1]
    head = [base + n * head_half, tip, base - n * head_half]
    return [tuple(v) for v in left + head + right[::-1]]


def setup_render(scene):
    scene.render.engine = 'CYCLES'
    scene.cycles.device = 'CPU'
    scene.cycles.samples = SAMPLES
    scene.cycles.use_denoising = True
    scene.render.film_transparent = True
    scene.render.image_settings.file_format = 'PNG'
    scene.render.image_settings.color_mode = 'RGBA'
    # Standard, not AgX: AgX drains the saturation out of lacquered red/blue and gold.
    scene.view_settings.view_transform = 'Standard'
    scene.view_settings.look = 'None'
    # A soft studio dome — bright above, deep navy below — so metal and lacquer have something to reflect.
    world = bpy.data.worlds.new('studio')
    world.use_nodes = True
    nt = world.node_tree
    coord = nt.nodes.new('ShaderNodeTexCoord')
    xyz = nt.nodes.new('ShaderNodeSeparateXYZ')
    ramp = nt.nodes.new('ShaderNodeValToRGB')
    ramp.color_ramp.elements[0].position = 0.3
    ramp.color_ramp.elements[0].color = (0.02, 0.02, 0.05, 1)
    ramp.color_ramp.elements[1].position = 1.0
    ramp.color_ramp.elements[1].color = (0.9, 0.88, 0.85, 1)
    nt.links.new(coord.outputs['Generated'], xyz.inputs['Vector'])
    nt.links.new(xyz.outputs['Z'], ramp.inputs['Fac'])
    nt.links.new(ramp.outputs['Color'], nt.nodes['Background'].inputs['Color'])
    nt.nodes['Background'].inputs['Strength'].default_value = 0.7
    scene.world = world


def softbox(name, loc, size, energy, color=(1, 1, 1), target=(0, 0, 0)):
    light = bpy.data.objects.new(name, bpy.data.lights.new(name, 'AREA'))
    light.data.shape = 'RECTANGLE'
    light.data.size, light.data.size_y = size
    light.data.energy = energy
    light.data.color = color
    light.location = loc
    direction = Vector(target) - Vector(loc)
    light.rotation_euler = direction.to_track_quat('-Z', 'Y').to_euler()
    return link(light)


def ortho_camera(scene, loc, scale, aspect):
    cam = bpy.data.objects.new('cam', bpy.data.cameras.new('cam'))
    cam.data.type = 'ORTHO'
    cam.data.ortho_scale = scale
    cam.location = loc
    cam.rotation_euler = (0, 0, 0)
    link(cam)
    scene.camera = cam
    return cam


def save_cropped(scene, outputs, pad=0.02, square=False):
    """Renders once at full size, crops to the art (alpha) and writes each (filename, height) as WebP."""
    tmp = os.path.join(bpy.app.tempdir, 'brand_render.png')
    scene.render.filepath = tmp
    bpy.ops.render.render(write_still=True)
    img = bpy.data.images.load(tmp)
    w, h = img.size
    px = np.empty(w * h * 4, dtype=np.float32)
    img.pixels.foreach_get(px)
    px = px.reshape(h, w, 4)
    ys, xs = np.nonzero(px[:, :, 3] > 0.02)
    x0, x1, y0, y1 = xs.min(), xs.max() + 1, ys.min(), ys.max() + 1
    p = int(pad * max(x1 - x0, y1 - y0))
    x0, y0, x1, y1 = max(0, x0 - p), max(0, y0 - p), min(w, x1 + p), min(h, y1 + p)
    if square:
        side = max(x1 - x0, y1 - y0)
        cx, cy = (x0 + x1) // 2, (y0 + y1) // 2
        x0, y0 = max(0, cx - side // 2), max(0, cy - side // 2)
        x1, y1 = min(w, x0 + side), min(h, y0 + side)
    crop = np.ascontiguousarray(px[y0:y1, x0:x1])
    cw, ch = x1 - x0, y1 - y0
    for name, height in outputs:
        out = bpy.data.images.new(name, cw, ch, alpha=True)
        out.pixels.foreach_set(crop.ravel())
        out.scale(max(1, round(cw * height / ch)), height)
        out.filepath_raw = os.path.join(OUT, name)
        out.file_format = 'WEBP'
        scene.render.image_settings.quality = 90
        out.save(filepath=os.path.join(OUT, name), quality=90)
        print('wrote', name, out.size[:])
    bpy.data.images.remove(img)


def clear():
    for o in list(bpy.data.objects):
        bpy.data.objects.remove(o, do_unlink=True)


os.makedirs(OUT, exist_ok=True)
scene = bpy.context.scene
for o in list(scene.objects):
    bpy.data.objects.remove(o, do_unlink=True)
setup_render(scene)

# ---------- The mark: B + C + the crash arrow ----------

rig = link(bpy.data.objects.new('mark', None))
red = material('red', (255, 38, 64), roughness=0.22, coat=1.0)
blue = material('blue', (40, 104, 255), roughness=0.22, coat=1.0)
gold = material('arrow', (255, 178, 0), roughness=0.2, coat=1.0, emission=0.9)
ink = material('ink', (10, 12, 26), roughness=0.5)

DEPTH, BEVEL = 0.11, 0.035
b = text('B', 1.0, DEPTH, BEVEL, red, rig)
c = text('C', 1.0, DEPTH, BEVEL, blue, rig)
bx0, bx1, by0, by1 = bounds(b)
c.location.x = bx1 - 0.03  # C tucks right in behind B, like a monogram
open_mouth(c)
cx0, cx1, cy0, cy1 = bounds(c)
x0, x1, y0, y1 = bx0, cx1, min(by0, cy0), max(by1, cy1)
W, H = x1 - x0, y1 - y0
front = DEPTH + BEVEL

# Crash chart: up, a dip, then the big run up and out past the C.
u = lambda a, b_: (x0 + a * W, y0 + b_ * H)
# It runs low across the B, dips at the seam and leaves over the C's top, so the C's mouth stays open.
path = [u(-0.06, 0.06), u(0.30, 0.42), u(0.47, 0.24), u(1.05, 1.10)]
stroke = H * 0.052
ribbon = arrow_outline(path, stroke, stroke * 2.9, stroke * 3.4)
border = arrow_outline(path, stroke + H * 0.034, stroke * 2.9 + H * 0.055, stroke * 3.4 + H * 0.02)
glow = flat_shape('arrow', ribbon, 0.05, 0.02, gold, rig)
glow.location.z = front + 0.11
edge = flat_shape('arrow_edge', border, 0.04, 0.0, ink, rig)
edge.location.z = front + 0.04

# Centre the rig and give it a slight turn so the bevels and the depth catch the light.
rig.location = (-(x0 + W / 2), -(y0 + H / 2), 0)
pivot = link(bpy.data.objects.new('pivot', None))
rig.parent = pivot
pivot.rotation_euler = (math.radians(-7), math.radians(11), 0)

softbox('key', (-3.5, 4.5, 6), (6, 3), 700)
softbox('front', (-1.5, 2.5, 11), (7, 3), 500)  # seen in the lacquer: the long glossy highlight
softbox('fill', (5, -2, 5), (4, 4), 350, (0.85, 0.9, 1.0))
softbox('rim', (0, 5, -2), (6, 1), 700)
ortho_camera(scene, (0, 0, 10), max(W, H) * 1.45, W / H)
scene.render.resolution_x, scene.render.resolution_y = 1400, 900
save_cropped(scene, [('logo-bc-256.webp', 256), ('logo-bc.webp', 112)])

# ---------- The coin ----------

clear()
coin_gold = material('coin_gold', (255, 196, 70), roughness=0.32, metallic=1.0, brushed=0.03)
polished = material('polished', (255, 200, 80), roughness=0.2, metallic=1.0)
deep = material('deep', (240, 160, 40), roughness=0.3, metallic=1.0)
coin = link(bpy.data.objects.new('coin', None))


def disc(name, r, z0, z1, mat, bevel=0.0, segments=160):
    bpy.ops.mesh.primitive_cylinder_add(vertices=segments, radius=r, depth=z1 - z0, location=(0, 0, (z0 + z1) / 2))
    o = bpy.context.active_object
    o.name = name
    o.data.materials.append(mat)
    if bevel:
        mod = o.modifiers.new('bevel', 'BEVEL')
        mod.width = bevel
        mod.segments = 5
        mod.limit_method = 'ANGLE'
    bpy.ops.object.shade_smooth()
    o.parent = coin
    return o


def ring(name, r_in, r_out, z0, z1, mat, bevel=0.0):
    o = disc(name, r_out, z0, z1, mat, bevel)
    hole = disc(name + '_hole', r_in, z0 - 0.05, z1 + 0.05, mat)
    mod = o.modifiers.new('hole', 'BOOLEAN')
    mod.operation = 'DIFFERENCE'
    mod.object = hole
    o.modifiers.move(len(o.modifiers) - 1, 0)
    hole.hide_render = True
    return o


disc('body', 1.0, -0.12, 0.0, deep, bevel=0.03)
disc('field', 0.84, 0.0, 0.03, coin_gold)
ring('rim', 0.84, 1.0, 0.0, 0.11, polished, bevel=0.035)
ring('inner_line', 0.74, 0.77, 0.03, 0.07, polished, bevel=0.012)
for k in range(30):
    a = 2 * math.pi * k / 30
    bpy.ops.mesh.primitive_uv_sphere_add(segments=16, ring_count=8, radius=0.03, location=(0.92 * math.cos(a), 0.92 * math.sin(a), 0.1))
    dot = bpy.context.active_object
    dot.data.materials.append(polished)
    bpy.ops.object.shade_smooth()
    dot.parent = coin

letters = link(bpy.data.objects.new('letters', None), parent=coin)
cb = text('B', 1.0, 0.05, 0.02, polished, letters)
cc = text('C', 1.0, 0.05, 0.02, polished, letters)
bx0, bx1, by0, by1 = bounds(cb)
cc.location.x = bx1 - 0.03
open_mouth(cc)
cx0, cx1, cy0, cy1 = bounds(cc)
lw, lh = cx1 - bx0, max(by1, cy1) - min(by0, cy0)
k = 1.02 / lw
letters.scale = (k, k, 1)
letters.location = (-(bx0 + lw / 2) * k, -(min(by0, cy0) + lh / 2) * k, 0.03 + 0.07)

softbox('key', (-3, 3.5, 6), (5, 5), 600)
softbox('front', (-1.2, 1.6, 11), (5, 5), 300, (1.0, 0.94, 0.85))  # what the polished faces mirror
softbox('fill', (4, -3, 5), (4, 4), 300, (1.0, 0.95, 0.88))
softbox('rim', (0, 6, 1), (6, 1), 500)
ortho_camera(scene, (0, 0, 10), 2.25, 1.0)
scene.render.resolution_x = scene.render.resolution_y = 900
save_cropped(scene, [('coin-256.webp', 256), ('coin.webp', 128), ('brainrots/coin-prize.webp', 256)], pad=0.01, square=True)
