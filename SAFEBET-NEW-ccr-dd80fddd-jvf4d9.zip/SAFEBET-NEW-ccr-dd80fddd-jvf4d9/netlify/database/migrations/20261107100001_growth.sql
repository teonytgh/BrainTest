-- Iteration 31: the 18+ consent, brainrot ranks, quests, partners and traffic sources. Applied by the Worker
-- (server/autoMigrate.ts), so every statement must be safe to run twice.

-- The version of the user agreement + privacy policy the player accepted (with «мне есть 18»), and when.
ALTER TABLE users ADD COLUMN IF NOT EXISTS terms_version INT;
ALTER TABLE users ADD COLUMN IF NOT EXISTS terms_accepted_at TIMESTAMPTZ;
-- A partner's referral percent, set by an owner instead of the level's (5–15).
ALTER TABLE users ADD COLUMN IF NOT EXISTS ref_percent NUMERIC(5, 2);
-- The traffic source a new player came from (/start s-<tag>).
ALTER TABLE users ADD COLUMN IF NOT EXISTS source TEXT;
CREATE INDEX IF NOT EXISTS users_source ON users (source) WHERE source IS NOT NULL;

CREATE TABLE IF NOT EXISTS traffic_sources (
  tag TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  created_by BIGINT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
-- Who pressed /start with a source link (once per player and source).
CREATE TABLE IF NOT EXISTS source_clicks (
  tag TEXT NOT NULL REFERENCES traffic_sources (tag) ON DELETE CASCADE,
  user_id BIGINT NOT NULL REFERENCES users (id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (tag, user_id)
);

-- A rank's gift, once per player and rank.
CREATE TABLE IF NOT EXISTS rank_gifts (
  user_id BIGINT NOT NULL REFERENCES users (id),
  rank INT NOT NULL,
  brainrot_id TEXT,
  coins NUMERIC(16, 2) NOT NULL DEFAULT 0,
  value NUMERIC(16, 2) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, rank)
);

-- A quest's reward, once per player, quest and period (an MSK day or week).
CREATE TABLE IF NOT EXISTS quest_claims (
  user_id BIGINT NOT NULL REFERENCES users (id),
  quest TEXT NOT NULL,
  period TEXT NOT NULL,
  reward NUMERIC(16, 2) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, quest, period)
);
CREATE INDEX IF NOT EXISTS quest_claims_time ON quest_claims (user_id, created_at);

-- «Поделиться выигрышем»: prepared share messages (a few per 10 minutes per player).
CREATE TABLE IF NOT EXISTS win_shares (
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT NOT NULL REFERENCES users (id),
  drop_id BIGINT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS win_shares_user ON win_shares (user_id, created_at);

-- Turnover per player and game (quests, ranks, sources).
CREATE INDEX IF NOT EXISTS drops_user_game ON drops (user_id, game, created_at);

DO $$
DECLARE t TEXT;
BEGIN
  FOREACH t IN ARRAY ARRAY['traffic_sources', 'source_clicks', 'rank_gifts', 'quest_claims', 'win_shares'] LOOP
    EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', t);
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'anon') THEN
      EXECUTE format('REVOKE ALL ON %I FROM anon, authenticated', t);
    END IF;
  END LOOP;
END $$;
