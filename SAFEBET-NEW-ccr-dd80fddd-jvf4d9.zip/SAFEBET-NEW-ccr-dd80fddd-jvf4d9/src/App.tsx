import { useQuery } from '@tanstack/react-query';
import { AnnouncementBanner } from './components/AnnouncementBanner';
import { BottomNav } from './components/BottomNav';
import { SupportButton } from './components/SupportButton';
import { ShoutOverlay } from './components/ShoutOverlay';
import { SpookyLayer } from './components/HalloweenArt';
import { Spiders } from './components/Spiders';
import { Suspense, lazy, useEffect } from 'react';
import { DepositSheet } from './components/DepositSheet';
import { BannedScreen, ErrorScreen, MaintenanceScreen, SplashScreen, TelegramOnlyScreen } from './components/GateScreen';
import { Header } from './components/Header';
import { PlayerSheet } from './components/PlayerSheet';
import { PromoSheet } from './components/PromoSheet';
import { SettingsSheet } from './components/SettingsSheet';
import { SideMenu, Sidebar } from './components/SideMenu';
import { Toaster } from './components/Toaster';
import { EventsHud, SnapOverlay } from './components/Events';
import { ConsentScreen } from './components/Consent';
import { useTour } from './store/tour';
import { bgMusic } from './lib/bgMusic';
import { TacosRain } from './components/TacosRain';
import { AutumnLeaves } from './components/AutumnLeaves';
import { SquidInvite } from './components/SquidInvite';
import { WithdrawSheet, WithdrawalWatcher } from './components/WithdrawSheet';
import { ApiError, useGate } from './api/client';
import { catalogQuery, meQuery, useMe } from './api/queries';
import { useLiveUpdates } from './lib/live';
import { navigate, useRoute, type RouteState } from './lib/router';
import { bindBackButton, getInitData } from './lib/telegram';
import { useLayout } from './store/layout';
import { CasePage } from './pages/CasePage';
import { Dice } from './pages/Dice';
import { Home } from './pages/Home';
import { Profile } from './pages/Profile';
import { Upgrader } from './pages/Upgrader';

/**
 * Speed: the bottom bar's pages (and a case) come with the app; every other page is its own chunk, so the first
 * download is smaller — and all of them are fetched as soon as the app is idle, so opening one is still instant.
 */
const LOADERS = {
  admin: () => import('./pages/admin/Admin'),
  battles: () => import('./pages/Battles'),
  bonuses: () => import('./pages/Bonuses'),
  faq: () => import('./pages/Faq'),
  referrals: () => import('./pages/Referrals'),
  crash: () => import('./pages/Crash'),
  road: () => import('./pages/Road'),
  mines: () => import('./pages/Mines'),
  sky: () => import('./pages/Sky'),
  squid: () => import('./pages/Squid'),
  giveaways: () => import('./pages/Giveaways'),
  fuse: () => import('./pages/Fuse'),
  quests: () => import('./pages/Quests'),
  pass: () => import('./pages/Pass'),
  ranks: () => import('./pages/Ranks'),
  legal: () => import('./pages/Legal'),
};
const Admin = lazy(() => LOADERS.admin().then((m) => ({ default: m.Admin })));
const Battles = lazy(() => LOADERS.battles().then((m) => ({ default: m.Battles })));
const Bonuses = lazy(() => LOADERS.bonuses().then((m) => ({ default: m.Bonuses })));
const Faq = lazy(() => LOADERS.faq().then((m) => ({ default: m.Faq })));
const Referrals = lazy(() => LOADERS.referrals().then((m) => ({ default: m.Referrals })));
/** The Meowl tour: only new players (and replays from Настройки) load it. */
const TourHost = lazy(() => import('./components/Tour'));
const Crash = lazy(() => LOADERS.crash().then((m) => ({ default: m.Crash })));
const Road = lazy(() => LOADERS.road().then((m) => ({ default: m.Road })));
const Mines = lazy(() => LOADERS.mines().then((m) => ({ default: m.Mines })));
const Sky = lazy(() => LOADERS.sky().then((m) => ({ default: m.Sky })));
const Squid = lazy(() => LOADERS.squid().then((m) => ({ default: m.Squid })));
const Giveaways = lazy(() => LOADERS.giveaways().then((m) => ({ default: m.Giveaways })));
const Fuse = lazy(() => LOADERS.fuse().then((m) => ({ default: m.Fuse })));
const Quests = lazy(() => LOADERS.quests().then((m) => ({ default: m.Quests })));
const Pass = lazy(() => LOADERS.pass().then((m) => ({ default: m.Pass })));
const Ranks = lazy(() => LOADERS.ranks().then((m) => ({ default: m.Ranks })));
const Legal = lazy(() => LOADERS.legal().then((m) => ({ default: m.Legal })));

function prefetchPages() {
  const all = () => Object.values(LOADERS).forEach((load) => void load().catch(() => {}));
  const idle = (window as unknown as { requestIdleCallback?: (cb: () => void, o?: { timeout: number }) => void }).requestIdleCallback;
  if (idle) idle(all, { timeout: 3000 });
  else setTimeout(all, 1500);
}

function Page({ route }: { route: RouteState }) {
  const me = useMe();
  switch (route.name) {
    case 'home':
      return <Home />;
    case 'upgrader':
      return <Upgrader />;
    case 'dice':
      return <Dice />;
    case 'crash':
      return <Crash />;
    case 'fuse':
      return <Fuse />;
    case 'road':
      return <Road />;
    case 'mines':
      return <Mines />;
    case 'sky':
      return <Sky />;
    case 'squid':
      return <Squid />;
    case 'tacos':
      // Raining Tacos has no page any more: it rains over every page while it runs. Old links land home.
      return <Home />;
    case 'profile':
      return <Profile />;
    case 'case':
      return route.param ? <CasePage id={route.param} /> : <Home />;
    case 'admin':
      return me.user.isAdmin ? <Admin section={route.param} /> : <Home />;
    case 'battle':
      return <Battles key={route.param ?? 'lobby'} id={route.param} />;
    case 'quests':
      return <Quests />;
    case 'pass':
      return <Pass />;
    case 'ranks':
      return <Ranks />;
    case 'terms':
    case 'privacy':
      return <Legal which={route.name} />;
    case 'giveaways':
      return <Giveaways key={route.param ?? 'list'} id={route.param} />;
    case 'bonuses':
      return <Bonuses />;
    case 'referrals':
      return <Referrals />;
    case 'faq':
      return <Faq />;
  }
}

function backTarget(route: RouteState): (() => void) | null {
  if (route.name === 'home') return null;
  if (route.name === 'admin' && route.param) return () => navigate('admin');
  if (route.name === 'battle' && route.param) return () => navigate('battle');
  if (route.name === 'giveaways' && route.param) return () => navigate('giveaways');
  if (route.name === 'referrals') return () => navigate('bonuses');
  return () => navigate('home');
}

function Shell() {
  const route = useRoute();
  const { mode } = useLayout();
  const me = useMe();
  const tourState = useTour();

  useEffect(prefetchPages, []);
  useEffect(() => bgMusic.start(), []);

  useEffect(() => {
    window.scrollTo(0, 0);
    const back = backTarget(route);
    return bindBackButton(!!back, back ?? (() => {}));
  }, [route]);

  return (
    <>
      <SpookyLayer />
      <Header />
      <AnnouncementBanner />
      <div className="shell">
        {mode === 'pc' && <Sidebar />}
        <main className="page">
          <Suspense fallback={<div className="page-loading" aria-busy="true" />}>
            <Page key={`${route.name}/${route.param ?? ''}`} route={route} />
          </Suspense>
        </main>
      </div>
      <AutumnLeaves />
      <TacosRain />
      <EventsHud phone={mode === 'phone'} />
      {mode === 'phone' && <BottomNav />}
      <Spiders />
      <SupportButton />
      <ShoutOverlay />
      <SideMenu />
      <DepositSheet />
      <PromoSheet />
      <SettingsSheet />
      <PlayerSheet />
      <WithdrawSheet />
      <WithdrawalWatcher />
      <SnapOverlay />
      <SquidInvite />
      {(!me.user.onboarded || tourState.active) && (
        <Suspense fallback={null}>
          <TourHost />
        </Suspense>
      )}
      <Toaster />
    </>
  );
}

export function App() {
  const inTelegram = !!getInitData();
  const gate = useGate();
  const me = useQuery({ ...meQuery, enabled: inTelegram });
  // Both at once (index.html has already started both): the catalog doesn't wait for the profile.
  const catalog = useQuery({ ...catalogQuery, enabled: inTelegram });
  useLiveUpdates(inTelegram && me.isSuccess);

  if (!inTelegram) return <TelegramOnlyScreen />;
  if (gate.kind === 'banned') return <BannedScreen until={gate.until} reason={gate.reason} />;
  if (gate.kind === 'maintenance') return <MaintenanceScreen message={gate.message} />;
  const error = me.error ?? catalog.error;
  if (error && !(me.data && catalog.data)) {
    return (
      <ErrorScreen
        message={error instanceof ApiError ? error.message : 'Сервер не отвечает'}
        onRetry={() => {
          void me.refetch();
          void catalog.refetch();
        }}
      />
    );
  }
  if (!me.data || !catalog.data) return <SplashScreen />;
  // 18+: confirm the age and accept the documents first (the server refuses to play without it too).
  if (!me.data.user.termsOk) return <ConsentScreen />;
  return <Shell />;
}
