/** Coins have two decimals (824.60 B). Floats drift, so every computed amount goes through these. */
export function round2(value: number): number {
  return Math.round((value + Math.sign(value) * 1e-9) * 100) / 100;
}

/** Rounds down to the kopeck, e.g. a payout of 100.459 → 100.45. */
export function floor2(value: number): number {
  return Math.floor(value * 100 + 1e-6) / 100;
}
