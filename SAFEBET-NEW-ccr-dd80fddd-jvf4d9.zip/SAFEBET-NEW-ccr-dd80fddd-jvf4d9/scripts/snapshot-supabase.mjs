// Saves what the admins changed on production into the project: the catalog (brainrots, prices, statuses),
// cases with their items and hand-set chances, home page themes, the deposit list and admin settings become a
// new migration in netlify/database/migrations. Images uploaded in the admin panel are downloaded into
// public/uploads. Production already has this state, so the migration is recorded there as applied; a fresh
// or local database (and the tests) get the same catalog.
// Usage: SUPABASE_TOKEN=sbp_... SUPABASE_REF=<project ref> node scripts/snapshot-supabase.mjs
import { mkdirSync, readdirSync, readFileSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const DIR = path.join(ROOT, 'netlify', 'database', 'migrations');
const UPLOADS = path.join(ROOT, 'public', 'uploads');
const SITE = process.env.SITE ?? 'https://safebet.teonytofficial.workers.dev';
const { SUPABASE_TOKEN, SUPABASE_REF } = process.env;
if (!SUPABASE_TOKEN || !SUPABASE_REF) throw new Error('Set SUPABASE_TOKEN and SUPABASE_REF');
/** Admin choices worth keeping; luck timers, RevShare progress and maintenance stay where they are. */
const SETTINGS = ['stars', 'free_case_gate', 'trade_bots', 'withdraw_rules'];

async function query(sql) {
  const r = await fetch(`https://api.supabase.com/v1/projects/${SUPABASE_REF}/database/query`, {
    method: 'POST',
    headers: { authorization: `Bearer ${SUPABASE_TOKEN}`, 'content-type': 'application/json' },
    body: JSON.stringify({ query: sql }),
  });
  const text = await r.text();
  if (!r.ok) throw new Error(`${r.status} ${text.slice(0, 500)}`);
  return JSON.parse(text);
}

const lit = (v) => {
  if (v === null || v === undefined) return 'NULL';
  if (typeof v === 'boolean') return v ? 'TRUE' : 'FALSE';
  if (typeof v === 'number') return String(v);
  return `'${String(v).replace(/'/g, "''")}'`;
};
const values = (rows, cols) => rows.map((r) => `  (${cols.map((c) => lit(r[c])).join(', ')})`).join(',\n');

/** Uploaded images live in the Worker's KV; the snapshot keeps a copy as a static file. */
const EXT = { 'image/png': 'png', 'image/jpeg': 'jpg', 'image/gif': 'gif', 'image/webp': 'webp' };
async function keepImage(url) {
  const m = /^\/api\/img\/([a-f0-9]{24})$/.exec(url ?? '');
  if (!m) return url;
  const known = readdirSync(UPLOADS, { withFileTypes: true }).find((f) => f.name.startsWith(`${m[1]}.`));
  if (known) return `/uploads/${known.name}`;
  const r = await fetch(`${SITE}${url}`);
  const ext = EXT[r.headers.get('content-type') ?? ''];
  if (!r.ok || !ext) {
    console.warn('image not saved:', url, r.status);
    return url;
  }
  writeFileSync(path.join(UPLOADS, `${m[1]}.${ext}`), Buffer.from(await r.arrayBuffer()));
  return `/uploads/${m[1]}.${ext}`;
}

mkdirSync(UPLOADS, { recursive: true });
const brainrots = await query('SELECT id, name, price::text AS price, image, status, withdrawable, kind FROM brainrots ORDER BY id');
const sections = await query('SELECT id::int AS id, title, sort FROM case_sections ORDER BY id');
const cases = await query('SELECT id, name, price::text AS price, image, kind, status, sort, mystery, bonus, section_id::int AS section_id, ticket_price FROM cases ORDER BY id');
const items = await query('SELECT case_id, brainrot_id, weight, fixed_chance::text AS fixed_chance FROM case_items ORDER BY case_id, brainrot_id');
const deposit = await query('SELECT brainrot_id, price::text AS price, section FROM deposit_items ORDER BY brainrot_id');
const settings = await query(`SELECT key, value::text AS value FROM settings WHERE key IN (${SETTINGS.map(lit).join(', ')}) ORDER BY key`);
for (const row of [...brainrots, ...cases]) row.image = await keepImage(row.image);
const num = (rows, ...cols) => rows.forEach((r) => cols.forEach((c) => r[c] !== null && (r[c] = Number(r[c]))));
num(brainrots, 'price');
num(cases, 'price');
num(items, 'fixed_chance');
num(deposit, 'price');

const body = [
  `INSERT INTO brainrots (id, name, price, image, status, withdrawable, kind) VALUES\n${values(brainrots, ['id', 'name', 'price', 'image', 'status', 'withdrawable', 'kind'])}
ON CONFLICT (id) DO UPDATE SET name = EXCLUDED.name, price = EXCLUDED.price, image = EXCLUDED.image, status = EXCLUDED.status,
  withdrawable = EXCLUDED.withdrawable, kind = EXCLUDED.kind, updated_at = now();`,
  `DELETE FROM case_sections WHERE id NOT IN (${sections.map((s) => s.id).join(', ') || 'NULL'});`,
  sections.length
    ? `INSERT INTO case_sections (id, title, sort) VALUES\n${values(sections, ['id', 'title', 'sort'])}
ON CONFLICT (id) DO UPDATE SET title = EXCLUDED.title, sort = EXCLUDED.sort;
SELECT setval('case_sections_id_seq', (SELECT max(id) FROM case_sections));`
    : '',
  `DELETE FROM cases WHERE id NOT IN (${cases.map((c) => lit(c.id)).join(', ')});`,
  `INSERT INTO cases (id, name, price, image, kind, status, sort, mystery, bonus, section_id, ticket_price) VALUES\n${values(cases, ['id', 'name', 'price', 'image', 'kind', 'status', 'sort', 'mystery', 'bonus', 'section_id', 'ticket_price'])}
ON CONFLICT (id) DO UPDATE SET name = EXCLUDED.name, price = EXCLUDED.price, image = EXCLUDED.image, kind = EXCLUDED.kind,
  status = EXCLUDED.status, sort = EXCLUDED.sort, mystery = EXCLUDED.mystery, bonus = EXCLUDED.bonus, section_id = EXCLUDED.section_id,
  ticket_price = EXCLUDED.ticket_price;`,
  `DELETE FROM case_items;
INSERT INTO case_items (case_id, brainrot_id, weight, fixed_chance) VALUES\n${values(items, ['case_id', 'brainrot_id', 'weight', 'fixed_chance'])};`,
  `DELETE FROM deposit_items;${deposit.length ? `\nINSERT INTO deposit_items (brainrot_id, price, section) VALUES\n${values(deposit, ['brainrot_id', 'price', 'section'])};` : ''}`,
  settings.length
    ? `INSERT INTO settings (key, value) VALUES\n${settings.map((s) => `  (${lit(s.key)}, ${lit(s.value)}::jsonb)`).join(',\n')}
ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value;`
    : '',
]
  .filter(Boolean)
  .join('\n\n');

// Nothing new since the last snapshot → no new file.
const previous = readdirSync(DIR).filter((f) => f.endsWith('_admin_snapshot.sql')).sort().at(-1);
if (previous && readFileSync(path.join(DIR, previous), 'utf8').endsWith(`${body}\n`)) {
  console.log('no admin changes since', previous);
  process.exit(0);
}
const now = new Date();
// Migrations run in name order: the snapshot must come after every schema change it relies on.
const last = readdirSync(DIR).filter((f) => /^\d{14}_/.test(f)).sort().at(-1)?.slice(0, 14) ?? '0';
const stamp = String(Math.max(Number(now.toISOString().replace(/\D/g, '').slice(0, 14)), Number(last) + 1));
const file = `${stamp}_admin_snapshot.sql`;
writeFileSync(
  path.join(DIR, file),
  `-- Admin changes on production up to ${now.toISOString()} (scripts/snapshot-supabase.mjs): catalog, cases with their
-- items and hand-set chances, home page themes, deposit list, settings. Production already has them.\n\n${body}\n`,
);
await query(`INSERT INTO _migrations (name) VALUES (${lit(file)}) ON CONFLICT DO NOTHING`);
console.log('saved', file, `(${brainrots.length} brainrots, ${cases.length} cases, ${items.length} case items, ${deposit.length} deposit items)`);
