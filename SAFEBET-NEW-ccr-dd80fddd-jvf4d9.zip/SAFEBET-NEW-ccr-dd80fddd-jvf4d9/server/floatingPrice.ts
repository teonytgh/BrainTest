import { round2 } from '../shared/money';
import { secureRandom } from '../shared/random';
import { num, tx, type Queryable } from './db';
import { bad } from './errors';

/**
 * Floating prices (iteration 35, «Биткоин»): a case may list 2–6 prices; every 5–10 minutes the tick moves it to
 * another one of them at random. Chances follow the price like every case's (88 % average), the healer composes the
 * case for all of its prices, an opening carries the price the player saw (`price_changed` otherwise) and battles
 * don't take such a case.
 */
export const FLOAT_MIN_MS = 5 * 60_000;
export const FLOAT_MAX_MS = 10 * 60_000;
const MAX_PRICES = 6;

const nextDelayMs = () => FLOAT_MIN_MS + Math.floor(secureRandom() * (FLOAT_MAX_MS - FLOAT_MIN_MS));

/** The editor's list: null/empty = a fixed price. */
export function priceCycleOf(v: unknown): number[] | null {
  if (v === null || v === undefined || v === '' || (Array.isArray(v) && v.length === 0)) return null;
  if (!Array.isArray(v) || v.length < 2 || v.length > MAX_PRICES) throw bad('invalid', `Плавающая цена: от 2 до ${MAX_PRICES} цен`);
  const prices = v.map((p) => round2(Number(p)));
  if (prices.some((p) => !Number.isFinite(p) || p < 1 || p > 10_000_000)) throw bad('invalid', 'Цены — от 1 до 10 000 000 B');
  if (new Set(prices).size !== prices.length) throw bad('invalid', 'Цены не должны повторяться');
  return prices;
}

/** Sets (or clears) a case's cycle; the price jumps into the cycle if it isn't in it. */
export async function setPriceCycle(c: Queryable, caseId: string, cycle: number[] | null) {
  if (!cycle) {
    await c.query('UPDATE cases SET price_cycle = NULL, price_next_at = NULL WHERE id = $1', [caseId]);
    return;
  }
  const { rows } = await c.query<{ price: string }>('SELECT price FROM cases WHERE id = $1', [caseId]);
  const current = num(rows[0]?.price);
  const price = cycle.includes(current) ? current : cycle[0]!;
  await c.query(`UPDATE cases SET price_cycle = $2::numeric[], price = $3, price_next_at = now() + make_interval(secs => $4) WHERE id = $1`, [
    caseId,
    cycle,
    price,
    nextDelayMs() / 1000,
  ]);
  if (price !== current) await c.query('INSERT INTO case_price_history (case_id, price) VALUES ($1, $2)', [caseId, price]);
}

/** The tick: every floating case whose time has come moves to another of its prices. Returns the moved cases. */
export async function rotateFloatingPrices(): Promise<{ id: string; price: number }[]> {
  return tx(async (c) => {
    const { rows } = await c.query<{ id: string; price: string; price_cycle: string[] }>(
      `SELECT id, price, price_cycle FROM cases
       WHERE price_cycle IS NOT NULL AND cardinality(price_cycle) >= 2 AND (price_next_at IS NULL OR price_next_at <= now())
       FOR UPDATE SKIP LOCKED`,
    );
    const moved: { id: string; price: number }[] = [];
    for (const r of rows) {
      const current = num(r.price);
      const others = r.price_cycle.map(num).filter((p) => p !== current);
      if (!others.length) continue;
      const price = others[Math.floor(secureRandom() * others.length)]!;
      await c.query('UPDATE cases SET price = $2, price_next_at = now() + make_interval(secs => $3) WHERE id = $1', [r.id, price, nextDelayMs() / 1000]);
      await c.query('INSERT INTO case_price_history (case_id, price) VALUES ($1, $2)', [r.id, price]);
      moved.push({ id: r.id, price });
    }
    // The chart needs a dozen points; older ones go.
    if (moved.length) {
      await c.query(
        `DELETE FROM case_price_history h WHERE h.case_id = ANY($1::text[])
         AND h.id NOT IN (SELECT id FROM case_price_history x WHERE x.case_id = h.case_id ORDER BY id DESC LIMIT 50)`,
        [moved.map((m) => m.id)],
      );
    }
    return moved;
  });
}
