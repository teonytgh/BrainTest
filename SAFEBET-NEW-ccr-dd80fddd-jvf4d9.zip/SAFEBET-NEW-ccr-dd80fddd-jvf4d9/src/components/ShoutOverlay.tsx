import { useEffect, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { catalogQuery, serverOffset } from '../api/queries';
import { SHOUT_FRESH_MS, SHOUT_SHOW_MS, type Shout } from '../../shared/shout';
import { cx } from '../lib/format';
import { sfx } from '../lib/sound';
import { haptic } from '../lib/telegram';

const KEY = 'brainrotcrash:shout-seen';

function seenAt(): number {
  try {
    return Number(localStorage.getItem(KEY)) || 0;
  } catch {
    return 0;
  }
}

function markSeen(at: number) {
  try {
    localStorage.setItem(KEY, String(at));
  } catch {
    // Private mode: at worst it shows once more.
  }
}

const initials = (name: string) =>
  name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((w) => w[0]!.toUpperCase())
    .join('') || '★';

/**
 * «Анонс в игре» (iteration 37), like Sammy's in Steal a Brainrot: an admin's line drops in on top of every open app —
 * their round photo, name and the text, with a fanfare — for SHOUT_SHOW_MS (a tap closes it). Only a fresh one shows,
 * once per device.
 */
export function ShoutOverlay() {
  const { data } = useQuery(catalogQuery);
  const shout = data?.shout ?? null;
  const [shown, setShown] = useState<Shout | null>(null);
  const [leaving, setLeaving] = useState(false);

  useEffect(() => {
    if (!shout || shout.at <= seenAt()) return;
    const age = Date.now() + serverOffset() - shout.at;
    if (age > SHOUT_FRESH_MS) return;
    markSeen(shout.at);
    setLeaving(false);
    setShown(shout);
    sfx.announce();
    haptic('success');
  }, [shout]);

  useEffect(() => {
    if (!shown) return;
    const out = setTimeout(() => setLeaving(true), SHOUT_SHOW_MS);
    return () => clearTimeout(out);
  }, [shown]);

  useEffect(() => {
    if (!leaving) return;
    const gone = setTimeout(() => setShown(null), 320);
    return () => clearTimeout(gone);
  }, [leaving]);

  if (!shown) return null;
  return (
    <div className={cx('shout', `shout--${shown.color}`, leaving && 'is-leaving')} role="alert" onClick={() => setLeaving(true)}>
      <span className="shout__ring">
        {shown.authorPhoto ? <img src={shown.authorPhoto} alt="" className="shout__ava" /> : <span className="shout__ava shout__ava--text">{initials(shown.authorName)}</span>}
      </span>
      <span className="shout__body">
        <span className="shout__who">
          <b>{shown.authorName}</b>
          <span className="shout__tag">анонс</span>
        </span>
        <span className="shout__text">{shown.text}</span>
      </span>
    </div>
  );
}
