/** A WebSocket as a room sees it (the Durable Object's, the local dev server's or a test's). */
export interface RoomSocket {
  send(data: string): void;
  close(code?: number, reason?: string): void;
}

/** What the signed pass says about the player beyond who they are. */
export interface JoinOpts {
  /** An admin's immortality for trailers (iteration 37). */
  god?: boolean;
}

/**
 * A multiplayer room's logic, independent of where it runs: the host (GameRoom in worker/index.ts, the local dev
 * server) wires sockets to join/message/leave, calls tick() every `tickMs` while somebody is in, and forwards the
 * API's sends (`broadcast`) and calls (`call`).
 */
export interface RoomLogic {
  readonly size: number;
  readonly tickMs: number;
  join(id: number, name: string, sock: RoomSocket, opts?: JoinOpts): boolean;
  message(id: number, sock: RoomSocket, raw: string): void;
  leave(id: number, sock: RoomSocket): void;
  tick(): void;
  broadcast(msg: unknown, except?: number): void;
  call(op: string, arg: unknown): unknown;
}
