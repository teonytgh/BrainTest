import { MAX_OPEN_COUNT, OPEN_COUNTS, pickWeighted } from '../shared/cases';
import { DICE_COLORS, countMatches, diceMultiplier, rollDice, type DiceColorId } from '../shared/dice';
import { round2 } from '../shared/money';
import { payoutFor } from '../shared/payout';
import { currentPromo } from '../shared/promo';
import { MAX_UPGRADE_CHANCE, MIN_UPGRADE_STAKE, rollUpgrade, upgradeChance } from '../shared/upgrader';
import { FREE_CASE_COOLDOWN_MS } from '../shared/types';
import { assertActive, type Viewer } from './auth';
import { activeBrainrots, caseDropTable, rebalancing, toBrainrot } from './catalog';
import { ms, num, one, q, tx } from './db';
import { addCoins, addItemWager, addWager, deliverDrop, giveItems, payOut, recordDrop, spendCoins, stakeDemo, takeItem } from './economy';
import { assertFreeGate } from './freeGate';
import { grantConsolation, nickTagOk, takeNickCase } from './bonuses';
import { bindReferral, notifyBound, referrerByCode } from './referrals';
import { bad, notFound } from './errors';
import { afterResponse } from './live';
import { ids, int, oneOf, str, type Body } from './validate';

/** Up to this many brainrots go into one upgrade (brainrots only, no coins). */
export const MAX_UPGRADE_ITEMS = 5;

export async function upgrade(v: Viewer, body: Body) {
  assertActive(v);
  // `itemId` is the old single-item request.
  if (body.coins) throw bad('items_only', 'Ставка — только брейнроты');
  const raw = body.itemIds ?? (body.itemId !== undefined ? [body.itemId] : []);
  if (Array.isArray(raw) && raw.length === 0) throw bad('invalid', 'Выбери брейнротов');
  const itemIds = ids(raw, 'вклад', MAX_UPGRADE_ITEMS);
  const targetId = str(body.targetId, 'цель', 1, 80);
  return tx(async (c) => {
    const stakes = [];
    for (const id of itemIds) stakes.push(await takeItem(c, v.id, id));
    const demo = stakeDemo(stakes);
    const stakeValue = round2(stakes.reduce((s, x) => s + x.price, 0));
    if (stakeValue < MIN_UPGRADE_STAKE) throw bad('stake_too_small', `Апгрейд — от ${MIN_UPGRADE_STAKE} B: добавь брейнротов в ставку`);
    const { rows } = await c.query<{ id: string; name: string; price: string; image: string; status: 'active'; withdrawable: boolean }>(
      `SELECT id, name, price, image, status, withdrawable, kind FROM brainrots WHERE id = $1 AND status = 'active' AND kind = 'brainrot'`,
      [targetId],
    );
    const target = rows[0] ? toBrainrot(rows[0]) : null;
    if (!target) throw bad('no_target', 'Этот брейнрот сейчас недоступен');
    if (target.price <= stakeValue) throw bad('bad_target', 'Цель должна быть дороже ставки');
    const chance = upgradeChance(stakeValue, target.price);
    if (chance > MAX_UPGRADE_CHANCE) throw bad('too_easy', `Шанс апгрейда — не больше ${MAX_UPGRADE_CHANCE * 100}%. Выбери цель дороже`);
    const { roll, win } = rollUpgrade(chance);
    const [itemId2] = win ? await giveItems(c, v.id, target.id, 'upgrade', 1, demo) : [null];
    await c.query('UPDATE users SET upgrades = upgrades + 1 WHERE id = $1', [v.id]);
    await recordDrop(c, {
      userId: v.id,
      game: 'upgrade',
      win,
      stakeValue,
      brainrotId: win ? target.id : null,
      meta: { chance, from: stakes.map((x) => x.brainrotId), to: target.id },
      demo,
    });
    // A big loss earns a free consolation spin (coins only) — never for a demo stake (its coins would be real).
    const consolationId = win || demo ? null : await grantConsolation(c, v.id, stakeValue);
    return { roll, win, chance, stakeValue, targetId: target.id, itemId: itemId2 ?? null, consolationId };
  });
}

const COLOR_IDS = DICE_COLORS.map((c) => c.id);

export async function dice(v: Viewer, body: Body) {
  assertActive(v);
  // Stakes are brainrots only, like every other game (the owner's rule).
  if (body.coins) throw bad('items_only', 'Ставка — только брейнроты');
  const itemId = int(body.itemId, 'ставка');
  const color = oneOf<DiceColorId>(body.color, 'цвет', COLOR_IDS);
  return tx(async (c) => {
    const stake = await takeItem(c, v.id, itemId);
    const faces = rollDice();
    const matches = countMatches(faces, color);
    const multiplier = diceMultiplier(matches);
    const payout = multiplier ? payoutFor(stake.price * multiplier, await activeBrainrots(c)) : null;
    const newItemId = payout ? await payOut(c, v.id, payout, 'dice', stake.demo) : null;
    await c.query('UPDATE users SET dice_rolls = dice_rolls + 1 WHERE id = $1', [v.id]);
    await recordDrop(c, {
      userId: v.id,
      game: 'dice',
      win: !!payout,
      stakeValue: stake.price,
      brainrotId: payout?.brainrot?.id,
      coins: payout?.coins,
      meta: { faces, color, multiplier },
      demo: stake.demo,
    });
    return {
      faces,
      matches,
      multiplier,
      payout: payout ? { brainrotId: payout.brainrot?.id ?? null, coins: payout.coins, itemId: newItemId } : null,
    };
  });
}

type OpenResult = {
  brainrotId: string;
  itemId: number | null;
  coins: number;
  drops: { brainrotId: string; itemId: number | null; coins: number }[];
  /** Paid with demo coins or a demo key: the drops are «ДЕМО». */
  demo?: boolean;
};

/** The app's id for one press of «Открыть»: letters, digits, «-» and «_». */
function requestIdOf(raw: unknown): string | null {
  if (raw === undefined || raw === null) return null;
  const id = str(raw, 'запрос', 8, 64);
  if (!/^[A-Za-z0-9_-]+$/.test(id)) throw bad('invalid', 'Неверный запрос');
  return id;
}

const storedOpen = async (userId: number, requestId: string) =>
  (await one<{ result: OpenResult }>('SELECT result FROM case_open_results WHERE user_id = $1 AND request_id = $2', [userId, requestId]))?.result ?? null;

/**
 * What an opening the app didn't hear back about gave: the spin can still play. 404 means it never happened (no
 * coins were taken).
 */
export async function openedCase(v: Viewer, requestIdParam: string) {
  const result = await storedOpen(v.id, requestIdOf(requestIdParam)!);
  if (!result) throw notFound('Открытия не было — монеты не списаны');
  return result;
}

/** A gift opening (admin-granted key) is free; otherwise the free case has a cooldown and paid ones cost coins. */
export async function openCase(v: Viewer, body: Body) {
  assertActive(v);
  const requestId = requestIdOf(body.requestId);
  // The same press again (a retry after a lost answer): its result, never a second opening.
  if (requestId) {
    const done = await storedOpen(v.id, requestId);
    if (done) return done;
  }
  try {
    return await openCaseOnce(v, body, requestId);
  } catch (e) {
    // Two copies of one press at the same moment: the second one's transaction hit the stored result.
    if (requestId && (e as { code?: string }).code === '23505') {
      const done = await storedOpen(v.id, requestId);
      if (done) return done;
    }
    throw e;
  }
}

async function openCaseOnce(v: Viewer, body: Body, requestId: string | null): Promise<OpenResult> {
  const caseId = str(body.caseId, 'кейс', 1, 80);
  // The price the player saw: a floating price («Биткоин») may have moved since.
  const expectedPrice = body.expectedPrice === undefined || body.expectedPrice === null ? null : Number(body.expectedPrice);
  const useKey = body.useKey === true;
  // Several paid openings in one press: one payment of price × count, every drop rolled and recorded on its own.
  const count = body.count === undefined ? 1 : int(body.count, 'количество', 1, MAX_OPEN_COUNT);
  if (count > 1 && !(OPEN_COUNTS as readonly number[]).includes(count)) throw bad('invalid', `За раз открывается ${OPEN_COUNTS.slice(0, -1).join(', ')} или ${OPEN_COUNTS.at(-1)} кейсов`);
  if (count > 1 && useKey) throw bad('invalid', 'Подарочные открытия — по одному');
  let nickTagged = false;
  let gateChecked = false;
  // The daily free case asks for the channel subscription and a fresh share first (network calls: outside the
  // tx). While it is recharging the cooldown error below is the one that matters.
  if (!useKey) {
    const pre = await one<{ kind: string; bonus: string | null; free_case_at: string | null }>(
      'SELECT c.kind, c.bonus, u.free_case_at FROM cases c, users u WHERE c.id = $1 AND u.id = $2',
      [caseId, v.id],
    );
    if (count > 1 && pre && (pre.kind !== 'paid' || pre.bonus)) throw bad('invalid', 'Этот кейс открывается по одному');
    const last = ms(pre?.free_case_at);
    if (pre?.kind === 'free' && !(last && Date.now() - last < FREE_CASE_COOLDOWN_MS)) {
      await assertFreeGate(v.id);
      gateChecked = true;
    }
    // «Кейс за ник»: the tag is checked against the name Telegram shows right now, on every opening.
    if (pre?.bonus === 'nick') nickTagged = await nickTagOk(v.id);
  }
  return tx(async (c) => {
    const table = await caseDropTable(c, caseId);
    if (!table) throw notFound('Кейс недоступен');
    if (!table.items.length) throw bad('empty_case', 'В кейсе пока нет предметов');
    if (table.losing) throw rebalancing();
    if (count > 1 && (table.kind !== 'paid' || table.bonus)) throw bad('invalid', 'Этот кейс открывается по одному');
    if (!useKey && table.kind === 'paid' && expectedPrice !== null && Math.abs(expectedPrice - table.price) > 0.001) {
      throw bad('price_changed', `Цена изменилась — теперь ${table.price.toLocaleString('ru-RU')} B`, { price: table.price });
    }
    let paid = table.price;
    // Paid with demo coins or a demo key: the drops are demo.
    let demo = false;
    if (useKey) {
      // Demo keys (an admin's «для демо» gift) go first.
      const key = await c.query<{ demo: boolean }>(
        `WITH o AS (SELECT demo_count FROM case_keys WHERE user_id = $1 AND case_id = $2 FOR UPDATE)
         UPDATE case_keys k SET count = k.count - 1, demo_count = greatest(k.demo_count - 1, 0)
         FROM o WHERE k.user_id = $1 AND k.case_id = $2 AND k.count > 0 RETURNING o.demo_count > 0 AS demo`,
        [v.id, caseId],
      );
      if (!key.rows[0]) throw bad('no_key', 'Подарочных открытий этого кейса больше нет');
      demo = key.rows[0].demo === true;
      paid = 0;
    } else if (table.kind === 'tickets') {
      // Quest tickets only: the price in tickets comes off the ticket balance, never coins.
      const cost = table.ticketPrice;
      if (!cost) throw bad('unavailable', 'Кейс недоступен');
      const spent = await c.query('UPDATE users SET tickets = tickets - $2 WHERE id = $1 AND tickets >= $2 RETURNING tickets', [v.id, cost]);
      if (!spent.rows[0]) {
        const { rows: have } = await c.query<{ tickets: number }>('SELECT tickets FROM users WHERE id = $1', [v.id]);
        const short = cost - (have[0]?.tickets ?? 0);
        throw bad('no_tickets', `Не хватает ${short} тикетов — их дают за задания`, { short });
      }
      paid = 0;
    } else if (table.bonus === 'referral') {
      throw bad('need_invite', 'Реферальный кейс даётся один раз на аккаунт: за вход по ссылке друга или за первого друга по твоей ссылке');
    } else if (table.bonus === 'nick') {
      await takeNickCase(c, v.id, nickTagged);
      // Free: its drop is bonus value (the wagering adds it), never a played stake.
      paid = 0;
    } else if (table.kind === 'free') {
      const { rows: u } = await c.query<{ free_case_at: string | null }>('SELECT free_case_at FROM users WHERE id = $1 FOR UPDATE', [v.id]);
      const last = ms(u[0]?.free_case_at);
      if (last && Date.now() - last < FREE_CASE_COOLDOWN_MS) {
        throw bad('cooldown', 'Бесплатный кейс ещё перезаряжается', { nextAt: last + FREE_CASE_COOLDOWN_MS });
      }
      // Recharged between the pre-check and here: the subscription and share were never asked for.
      if (!gateChecked) throw bad('cooldown', 'Бесплатный кейс только что перезарядился — нажми ещё раз', { nextAt: Date.now() });
      await c.query('UPDATE users SET free_case_at = now() WHERE id = $1', [v.id]);
      paid = 0;
    } else {
      ({ demo } = await spendCoins(c, v.id, round2(table.price * count)));
    }
    const drops: { brainrotId: string; itemId: number | null; coins: number }[] = [];
    for (let k = 0; k < count; k++) {
      const won = pickWeighted(table.items);
      const got = await deliverDrop(c, v.id, won.brainrotId, `case:${caseId}`, demo);
      await recordDrop(c, {
        userId: v.id,
        game: 'case',
        win: true,
        stakeValue: paid,
        brainrotId: won.brainrotId,
        meta: { caseId, gift: useKey || undefined, of: count > 1 ? count : undefined, tickets: table.kind === 'tickets' && !useKey ? table.ticketPrice : undefined },
        demo,
      });
      // A coin prize is already on the balance: no item to sell.
      drops.push({ brainrotId: won.brainrotId, itemId: got.itemId, coins: got.coins });
    }
    await c.query('UPDATE users SET cases_opened = cases_opened + $2 WHERE id = $1', [v.id, count]);
    const result: OpenResult = { ...drops[0]!, drops, demo: demo || undefined };
    // In the same transaction: committed together with the opening, or not at all.
    if (requestId) await c.query('INSERT INTO case_open_results (user_id, request_id, result) VALUES ($1, $2, $3::jsonb)', [v.id, requestId, JSON.stringify(result)]);
    return result;
  });
}

export async function buy(v: Viewer, body: Body) {
  assertActive(v);
  const brainrotId = str(body.brainrotId, 'брейнрот', 1, 80);
  return tx(async (c) => {
    const { rows } = await c.query<{ price: string }>(`SELECT price FROM brainrots WHERE id = $1 AND status = 'active' AND kind = 'brainrot'`, [brainrotId]);
    if (!rows[0]) throw bad('unavailable', 'Этот брейнрот нельзя купить');
    const { demo } = await spendCoins(c, v.id, num(rows[0].price));
    const [itemId] = await giveItems(c, v.id, brainrotId, 'shop', 1, demo);
    return { itemId };
  });
}

export async function sell(v: Viewer, body: Body) {
  assertActive(v);
  const all = body.all === true;
  const itemIds = all ? null : ids(body.itemIds, 'предметы');
  return tx(async (c) => {
    const { rows } = await c.query<{ price: string; demo: boolean }>(
      `DELETE FROM inventory i USING brainrots b
       WHERE i.user_id = $1 AND i.withdrawal_id IS NULL AND b.id = i.brainrot_id ${all ? '' : 'AND i.id = ANY($2::bigint[])'}
       RETURNING b.price, i.demo`,
      all ? [v.id] : [v.id, itemIds],
    );
    // Brainrots on a withdrawal are never sold, not even by «Продать всё».
    if (!rows.length) throw bad('no_item', all ? 'Нечего продавать (брейнроты на выводе не продаются)' : 'Нечего продавать');
    const total = round2(rows.reduce((s, r) => s + num(r.price), 0));
    // A demo brainrot sells for demo coins.
    const demoTotal = round2(rows.reduce((s, r) => s + (r.demo ? num(r.price) : 0), 0));
    await addCoins(c, v.id, round2(total - demoTotal));
    await addCoins(c, v.id, demoTotal, true);
    return { sold: rows.length, coins: total };
  });
}

export async function history(v: Viewer) {
  const rows = await q<{ id: string; game: string; result: string; stake_value: string; brainrot_id: string | null; coins: string; created_at: string; demo: boolean }>(
    'SELECT id, game, result, stake_value, brainrot_id, coins, created_at, demo FROM drops WHERE user_id = $1 ORDER BY id DESC LIMIT 40',
    [v.id],
  );
  return rows.map((r) => ({
    id: num(r.id),
    game: r.game,
    win: r.result === 'win',
    stake: num(r.stake_value),
    brainrotId: r.brainrot_id,
    coins: num(r.coins),
    at: ms(r.created_at)!,
    demo: r.demo === true,
  }));
}

/** Promo keys ignore case and repeated spaces, so «Летний Бонус» == «летний  бонус». */
export function promoKey(code: string): string {
  return code.trim().replace(/\s+/g, ' ').toLowerCase();
}

export async function activatePromo(v: Viewer, body: Body) {
  assertActive(v);
  const code = str(body.code, 'промокод', 1, 64);
  const key = promoKey(code);
  const auto = currentPromo();
  if (key === auto.code.toLowerCase()) {
    const rows = await q<{ status: string }>(
      `INSERT INTO auto_promo_uses (user_id, window_index, percent, status) VALUES ($1, $2, $3, 'active')
       ON CONFLICT (user_id, window_index) DO NOTHING RETURNING status`,
      [v.id, auto.windowIndex, auto.percent],
    );
    if (!rows.length) throw bad('promo_used', 'Этот авто-промокод уже активирован');
    return { type: 'bonus' as const, percent: auto.percent };
  }
  const result = await tx(async (c) => {
    const { rows } = await c.query<{
      id: string;
      uses: number;
      max_uses: number;
      reward_type: 'coins' | 'brainrot' | 'case';
      reward_brainrot_id: string | null;
      reward_case_id: string | null;
      reward_amount: string;
      owner_id: string | null;
    }>('SELECT * FROM promo_codes WHERE code_key = $1 FOR UPDATE', [key]);
    const promo = rows[0];
    if (!promo) {
      // A friend's partner code: you become their referral (once); the referral case comes once per account.
      const referrer = /^[a-z0-9_]{4,16}$/i.test(code.trim()) ? await referrerByCode(c, code) : null;
      if (referrer === null) throw bad('promo_invalid', 'Такого промокода нет');
      const bound = await bindReferral(c, v.id, referrer);
      if (bound === 'self') throw bad('own_code', 'Это твой собственный код — отправь его друзьям');
      if (bound === 'cycle') throw bad('ref_cycle', 'Этот игрок пришёл по твоей ссылке — его код ввести нельзя');
      if (bound !== 'bound') throw bad('already_referred', 'Ты уже привязан к другу — партнёрский код вводится один раз');
      return { reward: { type: 'referral' as const }, referrer };
    }
    const owner = promo.owner_id ? num(promo.owner_id) : null;
    if (owner === v.id) throw bad('own_promo', 'Свой промокод активировать нельзя — он для друзей');
    if (promo.uses >= promo.max_uses) throw bad('promo_exhausted', 'Активации этого промокода закончились');
    const inserted = await c.query('INSERT INTO promo_activations (promo_id, user_id) VALUES ($1, $2) ON CONFLICT DO NOTHING RETURNING 1', [promo.id, v.id]);
    if (!inserted.rows.length) throw bad('promo_used', 'Ты уже активировал этот промокод');
    await c.query('UPDATE promo_codes SET uses = uses + 1 WHERE id = $1', [promo.id]);
    // A player's own promo code also makes the activator their referral (if nobody's yet).
    const referrer = owner !== null && (await bindReferral(c, v.id, owner)) === 'bound' ? owner : null;
    const amount = num(promo.reward_amount);
    if (promo.reward_type === 'coins') {
      await addCoins(c, v.id, amount);
      await addWager(c, v.id, amount, 'bonus');
      return { reward: { type: 'coins' as const, amount }, referrer };
    }
    if (promo.reward_type === 'case') {
      if (!promo.reward_case_id) throw bad('promo_invalid', 'Кейс этого промокода больше недоступен');
      await c.query(
        `INSERT INTO case_keys (user_id, case_id, count) VALUES ($1, $2, $3)
         ON CONFLICT (user_id, case_id) DO UPDATE SET count = case_keys.count + EXCLUDED.count`,
        [v.id, promo.reward_case_id, amount],
      );
      return { reward: { type: 'case' as const, amount, caseId: promo.reward_case_id }, referrer };
    }
    const itemIds = await giveItems(c, v.id, promo.reward_brainrot_id!, 'promo', amount);
    await addItemWager(c, v.id, promo.reward_brainrot_id!, amount);
    return { reward: { type: 'brainrot' as const, amount, brainrotId: promo.reward_brainrot_id, itemIds }, referrer };
  });
  const referrer = result.referrer;
  if (referrer !== null) await afterResponse(() => notifyBound(referrer, v.id));
  return result.reward;
}

