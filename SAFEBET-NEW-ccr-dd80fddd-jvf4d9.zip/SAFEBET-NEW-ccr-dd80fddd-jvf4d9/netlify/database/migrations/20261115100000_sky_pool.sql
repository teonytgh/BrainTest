-- Iteration 37: «Небо Meowl» shares one coin pool per run among everybody (an admin sets it). Applied by the Worker
-- (server/autoMigrate.ts), so every statement is safe to run twice. Runs started before it have no pool (NULL).
ALTER TABLE sky_runs ADD COLUMN IF NOT EXISTS pool NUMERIC(16, 2);
ALTER TABLE sky_runs ADD COLUMN IF NOT EXISTS paid NUMERIC(16, 2) NOT NULL DEFAULT 0;
