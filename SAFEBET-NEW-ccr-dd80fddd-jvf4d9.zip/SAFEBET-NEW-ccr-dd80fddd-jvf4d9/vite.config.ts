import { readFileSync } from 'node:fs';
import type { Plugin } from 'vite';
import { defineConfig } from 'vitest/config';
import react from '@vitejs/plugin-react';

/** `import sql from '….sql'` gives the file's text (server/autoMigrate.ts); the Worker build does the same (wrangler rules). */
const sqlText: Plugin = {
  name: 'sql-text',
  enforce: 'pre',
  load(id) {
    if (id.endsWith('.sql')) return `export default ${JSON.stringify(readFileSync(id, 'utf8'))};`;
  },
};

export default defineConfig({
  base: './',
  plugins: [react(), sqlText],
  test: {
    include: ['src/**/*.test.ts', 'shared/**/*.test.ts', 'server/**/*.test.ts'],
  },
});
