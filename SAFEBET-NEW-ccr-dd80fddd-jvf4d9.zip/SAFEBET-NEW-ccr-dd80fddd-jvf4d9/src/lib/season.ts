/** The season over the Crash look, set by index.html on <html data-season> (iteration 37: halloween, 40: autumn). */
export const season = (): string | undefined => (typeof document === 'undefined' ? undefined : document.documentElement.dataset.season);
export const autumnSeason = () => season() === 'autumn';
