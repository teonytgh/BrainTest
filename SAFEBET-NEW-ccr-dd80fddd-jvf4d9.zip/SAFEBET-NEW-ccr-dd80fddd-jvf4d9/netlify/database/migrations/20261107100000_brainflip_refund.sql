-- Iteration 31: BrainFlip is gone (the owner took it out). Flips still open go back to their creators — the same
-- brainrots, as new inventory rows — and are closed. Applied by the Worker (server/autoMigrate.ts); safe to run twice
-- (the second run finds nothing open) and on a database that never had the table.
DO $$
BEGIN
  IF to_regclass('public.flips') IS NOT NULL THEN
    INSERT INTO inventory (user_id, brainrot_id, source)
    SELECT f.creator_id, x.id, 'flip_refund'
    FROM flips f CROSS JOIN LATERAL jsonb_array_elements_text(f.creator_items) AS x (id)
    WHERE f.status = 'open';
    UPDATE flips SET status = 'cancelled', finished_at = now() WHERE status = 'open';
  END IF;
END $$;
