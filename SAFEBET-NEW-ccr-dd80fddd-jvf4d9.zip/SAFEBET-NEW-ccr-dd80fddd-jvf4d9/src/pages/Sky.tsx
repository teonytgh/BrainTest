import { useQuery } from '@tanstack/react-query';
import { useEffect, useRef, useState, type PointerEvent as ReactPointerEvent } from 'react';
import { Coin } from '../components/Coin';
import { Icon } from '../components/Icon';
import { ApiError, api, errorMessage } from '../api/client';
import { queryClient, useCatalog, useMe, type Me } from '../api/queries';
import { SKY_COIN_VALUE, SKY_EGG_VALUE, SKY_FIGHT_MS, SKY_HIT, SKY_HP, skyFight, type SkyRun } from '../../shared/sky';
import { round2 } from '../../shared/money';
import { cx, formatCoins } from '../lib/format';
import { navigate } from '../lib/router';
import { SkyEngine } from '../lib/sky/engine';
import { SkyRoomClient } from '../lib/sky/net';
import { sfx, type WindLoop } from '../lib/sound';
import { haptic } from '../lib/telegram';
import { toast } from '../store/toast';
import { openSheet } from '../store/ui';
import '../styles/sky.css';

/**
 * «Небо Meowl» (iteration 35): the event's page. The lobby says what it is and lets the player take off; the flight
 * itself is a full-screen canvas (src/lib/sky/engine.ts) with a floating joystick (touch), WASD / arrows or the
 * held mouse (PC), and a HUD: time left, players in the sky, coins collected against the cap, the radar, banners
 * when an admin drops an egg.
 */

interface SkyPlayer {
  x: number;
  y: number;
  at: number;
  coins: number;
  eggs: number;
}

interface SkyStateView {
  run: SkyRun | null;
  block?: string | null;
  me?: SkyPlayer | null;
  taken?: string[];
  eggs?: { key: string; x: number; y: number }[];
  /** What is left of the run's coin pool for everybody (iteration 37); null: no pool. */
  poolLeft?: number | null;
  serverNow?: number;
}

interface JoinView extends SkyStateView {
  ticket: string;
}

const clock = (ms: number) => {
  const s = Math.max(0, Math.ceil(ms / 1000));
  const m = Math.floor(s / 60);
  return `${m}:${String(s % 60).padStart(2, '0')}`;
};

export function Sky() {
  const catalog = useCatalog();
  const run = catalog.sky ?? null;
  const [flight, setFlight] = useState<JoinView | null>(null);
  const [busy, setBusy] = useState(false);
  const state = useQuery({
    queryKey: ['sky', run?.runId ?? 0],
    queryFn: () => api<SkyStateView>('/api/sky'),
    enabled: !!run,
    staleTime: 10_000,
  });

  async function takeOff() {
    setBusy(true);
    try {
      const j = await api<JoinView>('/api/sky/join', { method: 'POST' });
      sfx.whoosh();
      haptic('select');
      setFlight(j);
    } catch (e) {
      sfx.error();
      toast(errorMessage(e), 'error');
    } finally {
      setBusy(false);
    }
  }

  if (flight?.run && run && flight.run.runId === run.runId) {
    return (
      <SkyFlight
        join={flight}
        onExit={() => {
          setFlight(null);
          void state.refetch();
        }}
      />
    );
  }
  return <SkyLobby run={run} state={state.data ?? null} busy={busy} onTakeOff={() => void takeOff()} />;
}

function SkyLobby({ run, state, busy, onTakeOff }: { run: SkyRun | null; state: SkyStateView | null; busy: boolean; onTakeOff: () => void }) {
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, []);
  const mine = state?.me;
  return (
    <div className="sky-page">
      <section className={cx('sky-hero', !run && 'is-closed')}>
        <div className="sky-hero__sky" aria-hidden="true">
          <span className="sky-hero__cloud sky-hero__cloud--a" />
          <span className="sky-hero__cloud sky-hero__cloud--b" />
          <img className="sky-hero__meowl" src="/sky/meowl-broom.webp" alt="" />
        </div>
        <div className="sky-hero__body">
          <p className="sky-hero__kicker">{run ? <span className="sky-live">LIVE</span> : 'Ивент'}</p>
          <h1 className="sky-hero__title">Небо Meowl</h1>
          {run ? (
            <p className="sky-hero__time">
              <Icon name="clock" size={16} /> ещё {clock(run.endsAt - now)}
            </p>
          ) : (
            <p className="sky-hero__text">Сейчас небо закрыто. Полёт запускает админ — следи за новостями в канале и в боте.</p>
          )}
        </div>
      </section>

      <div className="sky-facts">
        <div className="sky-fact">
          <Coin size={22} />
          <b>{String(SKY_COIN_VALUE).replace('.', ',')} B</b>
          <span>за монету</span>
        </div>
        <div className="sky-fact">
          <span className="sky-fact__cap">{run ? formatCoins(run.max) : '—'} B</span>
          <span>максимум на игрока</span>
        </div>
        {run?.pool != null && (
          <div className="sky-fact">
            <span className="sky-fact__cap">{state?.poolLeft != null ? formatCoins(state.poolLeft) : formatCoins(run.pool)} B</span>
            <span>осталось в фонде на всех</span>
          </div>
        )}
        <div className="sky-fact sky-fact--egg">
          <img src="/sky/egg.webp" alt="" />
          <b>{SKY_EGG_VALUE} B</b>
          <span>яйцо — почти не найти</span>
        </div>
      </div>

      <div className="panel sky-rules">
        <h2 className="panel__title">Как играть</h2>
        <ul>
          <li>Лети на Meowl над бесконечной картой: на телефоне — джойстик там, где коснулся экрана, на ПК — WASD, стрелки или зажатая мышь.</li>
          <li>Монеты разбросаны по одной и общие: кто первый долетел — тот и забрал. Фонд полёта один на всех — кончился, и монеты больше не платят.</li>
          <li>Каждые 3 минуты — бой на 30 секунд: все против всех, 100 HP, удар мечом снимает {SKY_HIT}. Сбили — падаешь до конца боя. Монеты в бою не теряются.</li>
          <li>Яйцо на карте найти почти нереально, а админ может уронить яйцо рядом с игроками — успей подобрать первым.</li>
          <li>Все игроки летают в одном небе — их Meowl видно с именами, а на радаре — ближайшие монеты и яйца.</li>
          {run?.needDeposit && <li>Летают игроки с пополнением.</li>}
        </ul>
      </div>

      {run && mine && (
        <p className="sky-mine">
          В этом полёте ты собрал {formatCoins(mine.coins)} из {formatCoins(run.max)} B{mine.eggs ? ` и яйца на ${formatCoins(mine.eggs)} B` : ''}.
        </p>
      )}

      {run &&
        (state?.block ? (
          <div className="sky-block">
            <p>{state.block}</p>
            <button type="button" className="btn btn--primary btn--lg btn--block" onClick={() => openSheet('deposit')}>
              <Icon name="plus" size={18} /> Пополнить
            </button>
          </div>
        ) : (
          <button type="button" className="btn btn--primary btn--lg btn--block sky-takeoff" disabled={busy || !state} onClick={onTakeOff}>
            🪽 {mine ? 'Продолжить полёт' : 'Взлететь'}
          </button>
        ))}
    </div>
  );
}

interface Banner {
  id: number;
  by: string;
  mine: boolean;
}

function SkyFlight({ join, onExit }: { join: JoinView; onExit: () => void }) {
  const me = useMe();
  const run = join.run!;
  const canvas = useRef<HTMLCanvasElement>(null);
  const engine = useRef<SkyEngine | null>(null);
  const [coins, setCoins] = useState(join.me?.coins ?? 0);
  const [eggs, setEggs] = useState(join.me?.eggs ?? 0);
  const [online, setOnline] = useState(1);
  const [connected, setConnected] = useState(false);
  const [banner, setBanner] = useState<Banner | null>(null);
  const [over, setOver] = useState(false);
  const [now, setNow] = useState(Date.now());
  const [stick, setStick] = useState<{ x: number; y: number; dx: number; dy: number } | null>(null);
  const [pool, setPool] = useState<number | null>(join.poolLeft ?? null);
  const [fightOn, setFightOn] = useState(false);
  const [hp, setHp] = useState(SKY_HP);
  const [ko, setKo] = useState(false);
  const [fightBanner, setFightBanner] = useState<{ id: number; text: string } | null>(null);
  const room = useRef<SkyRoomClient | null>(null);
  const capped = coins + SKY_COIN_VALUE > run.max + 1e-9 || (pool !== null && pool < SKY_COIN_VALUE);
  // Server time minus ours, measured once at take-off (recomputing it on every render froze every clock here).
  const [skew] = useState(() => (join.serverNow ?? Date.now()) - Date.now());

  useEffect(() => {
    const el = canvas.current!;
    const pick = async (key: string, kind: 'coin' | 'egg') => {
      try {
        const r = await api<{ value: number; coins: number; eggs: number; balance: number; poolLeft: number | null }>('/api/sky/pick', { method: 'POST', body: { key } });
        engine.current?.picked(key, r.value, kind);
        setCoins(r.coins);
        setEggs(r.eggs);
        if (r.poolLeft !== null && r.poolLeft !== undefined) setPool(r.poolLeft);
        if (kind === 'egg') {
          sfx.egg();
          sfx.catMeow();
          haptic('success');
        } else {
          sfx.coin();
          if (Math.random() < 0.35) sfx.catMeow();
          haptic('tap');
        }
        queryClient.setQueryData<Me>(['me'], (cur) => (cur ? { ...cur, user: { ...cur.user, balance: r.balance } } : cur));
      } catch (e) {
        const code = e instanceof ApiError ? e.code : '';
        if (code === 'taken' || code === 'no_coin') engine.current?.refused(key, 'taken');
        else if (code === 'sky_cap') {
          engine.current?.refused(key, 'cap');
          toast(errorMessage(e));
        } else if (code === 'sky_pool') {
          engine.current?.refused(key, 'cap');
          setPool(0);
          toast(errorMessage(e));
        } else if (code === 'sky_over') setOver(true);
        else engine.current?.refused(key, 'retry');
      }
    };
    const game = new SkyEngine(el, {
      seed: run.seed,
      start: { x: join.me?.x ?? 0, y: join.me?.y ?? 0 },
      taken: join.taken ?? [],
      eggs: join.eggs ?? [],
      capped: (join.me?.coins ?? 0) + SKY_COIN_VALUE > run.max + 1e-9 || (join.poolLeft != null && join.poolLeft < SKY_COIN_VALUE),
      me: me.user.id,
      onPick: (key, kind) => void pick(key, kind),
    });
    engine.current = game;
    game.start();
    const meId = me.user.id;
    const fightNow = (on: boolean) => {
      game.setFight(on);
      setFightOn(on);
      setHp(SKY_HP);
      setKo(false);
    };
    const client = new SkyRoomClient(async () => (await api<{ ticket: string }>('/api/sky/ticket')).ticket, {
      welcome: (players, fight, hps) => {
        game.setOthers(players);
        setOnline(players.length);
        if (fight) fightNow(fight.on);
        for (const [id, h, k] of hps) {
          game.setHp(id, h, k === 1);
          if (id === meId) {
            setHp(h);
            setKo(k === 1);
          }
        }
      },
      joined: (id, name, x, y) => {
        game.joined(id, name, x, y);
        setOnline(game.others.size + 1);
      },
      left: (id) => {
        game.left(id);
        setOnline(game.others.size + 1);
      },
      moved: (list) => game.moved(list),
      taken: (key, _by, left) => {
        game.gone(key);
        if (left !== null) {
          setPool(left);
          if (left < SKY_COIN_VALUE) game.capped = true;
        }
      },
      eggs: (list, by) => {
        game.addEggs(list);
        sfx.eggAlert();
        haptic('success');
        setBanner({ id: Date.now(), by, mine: list.some((e) => e.near === me.user.id) });
      },
      end: () => setOver(true),
      status: setConnected,
      fight: (f) => {
        fightNow(f.on);
        sfx.horn();
        haptic(f.on ? 'error' : 'success');
        setFightBanner({ id: Date.now(), text: f.on ? `⚔️ БОЙ! ${SKY_FIGHT_MS / 1000} секунд — все против всех` : 'Бой окончен — все снова в небе' });
      },
      swing: (id) => {
        if (id === meId) return;
        game.swing(id);
      },
      hit: (from, to, h) => {
        game.setHp(to, h);
        game.hitMark(to);
        if (to === meId) {
          setHp(h);
          sfx.hit();
          haptic('error');
        } else if (from === meId) sfx.hit();
      },
      ko: (id, by) => {
        game.knockOut(id);
        if (id === meId) {
          setKo(true);
          setHp(0);
          sfx.ko();
          setFightBanner({ id: Date.now(), text: 'Тебя сбили! Дождись конца боя' });
        } else if (by === meId) {
          sfx.catMeow();
          setFightBanner({ id: Date.now(), text: 'Ты сбил соперника!' });
        }
      },
    });
    room.current = client;
    void client.connect(join.ticket);
    // The wind follows the speed.
    let wind: WindLoop | null = null;
    const windTick = setInterval(() => {
      wind ??= sfx.wind();
      wind.set(game.ko ? 0 : Math.hypot(game.vx, game.vy) / 260);
    }, 250);
    const send = setInterval(() => client.send(game.x, game.y, game.heading), 250);
    const tick = setInterval(() => setNow(Date.now()), 500);
    // Keys (PC): WASD / arrows.
    const keys = new Set<string>();
    const steer = () => {
      const x = (keys.has('d') || keys.has('arrowright') ? 1 : 0) - (keys.has('a') || keys.has('arrowleft') ? 1 : 0);
      const y = (keys.has('s') || keys.has('arrowdown') ? 1 : 0) - (keys.has('w') || keys.has('arrowup') ? 1 : 0);
      game.input = { x, y };
    };
    const down = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase();
      if (e.code === 'KeyF' || e.code === 'Space' || e.code === 'KeyJ') {
        e.preventDefault();
        if (!e.repeat) swingRef.current();
        return;
      }
      const code = { KeyW: 'w', KeyA: 'a', KeyS: 's', KeyD: 'd' }[e.code] ?? k;
      if (!['w', 'a', 's', 'd', 'arrowup', 'arrowdown', 'arrowleft', 'arrowright'].includes(code)) return;
      e.preventDefault();
      keys.add(code);
      steer();
    };
    const up = (e: KeyboardEvent) => {
      const code = { KeyW: 'w', KeyA: 'a', KeyS: 's', KeyD: 'd' }[e.code] ?? e.key.toLowerCase();
      keys.delete(code);
      steer();
    };
    window.addEventListener('keydown', down);
    window.addEventListener('keyup', up);
    document.documentElement.classList.add('sky-flying');
    return () => {
      game.stop();
      client.close();
      room.current = null;
      clearInterval(windTick);
      wind?.stop();
      clearInterval(send);
      clearInterval(tick);
      window.removeEventListener('keydown', down);
      window.removeEventListener('keyup', up);
      document.documentElement.classList.remove('sky-flying');
      engine.current = null;
    };
    // The flight is set up once per take-off.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!banner) return;
    const t = setTimeout(() => setBanner(null), 6000);
    return () => clearTimeout(t);
  }, [banner]);

  useEffect(() => {
    if (!fightBanner) return;
    const t = setTimeout(() => setFightBanner(null), 3200);
    return () => clearTimeout(t);
  }, [fightBanner]);

  /** A sword swing: shown at once, judged by the room. */
  const lastSwing = useRef(0);
  const swingRef = useRef(() => {});
  swingRef.current = () => {
    const g = engine.current;
    if (!g || !g.fighting || g.ko) return;
    const t = performance.now();
    if (t - lastSwing.current < 600) return;
    lastSwing.current = t;
    g.swing(me.user.id);
    sfx.swing();
    haptic('tap');
    room.current?.hit();
  };

  const left = run.endsAt - (now + skew);
  useEffect(() => {
    if (left <= 0 && !over) {
      setOver(true);
      sfx.win();
    }
  }, [left, over]);

  // Touch: a joystick appears where the finger lands. Mouse: hold to fly towards the pointer.
  const origin = useRef<{ x: number; y: number; id: number; mouse: boolean } | null>(null);
  function onDown(e: ReactPointerEvent<HTMLDivElement>) {
    if ((e.target as HTMLElement).closest('button')) return;
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    const mouse = e.pointerType === 'mouse';
    origin.current = { x: e.clientX, y: e.clientY, id: e.pointerId, mouse };
    if (mouse) steerMouse(e);
    else setStick({ x: e.clientX, y: e.clientY, dx: 0, dy: 0 });
  }
  function steerMouse(e: ReactPointerEvent<HTMLDivElement>) {
    const r = (e.currentTarget as HTMLElement).getBoundingClientRect();
    const dx = e.clientX - (r.left + r.width / 2);
    const dy = e.clientY - (r.top + r.height / 2);
    const d = Math.hypot(dx, dy);
    if (engine.current) engine.current.input = d < 20 ? { x: 0, y: 0 } : { x: dx / Math.max(d, 160), y: dy / Math.max(d, 160) };
  }
  function onMove(e: ReactPointerEvent<HTMLDivElement>) {
    const o = origin.current;
    if (!o || o.id !== e.pointerId) return;
    if (o.mouse) return steerMouse(e);
    const R = 58;
    let dx = e.clientX - o.x;
    let dy = e.clientY - o.y;
    const d = Math.hypot(dx, dy);
    if (d > R) {
      dx = (dx / d) * R;
      dy = (dy / d) * R;
    }
    setStick({ x: o.x, y: o.y, dx, dy });
    if (engine.current) engine.current.input = { x: dx / R, y: dy / R };
  }
  function onUp(e: ReactPointerEvent<HTMLDivElement>) {
    if (origin.current?.id !== e.pointerId) return;
    origin.current = null;
    setStick(null);
    if (engine.current) engine.current.input = { x: 0, y: 0 };
  }

  const pct = Math.min(100, (coins / run.max) * 100);
  const fight = skyFight(now + skew);
  return (
    <div className="sky-game" onPointerDown={onDown} onPointerMove={onMove} onPointerUp={onUp} onPointerCancel={onUp}>
      <canvas ref={canvas} className="sky-game__canvas" />
      <div className="sky-hud">
        <button type="button" className="sky-hud__close" aria-label="Выйти из полёта" onClick={onExit}>
          <Icon name="close" size={20} />
        </button>
        <span className={cx('sky-hud__chip', left < 60_000 && 'is-hot')}>
          <Icon name="clock" size={15} /> {clock(left)}
        </span>
        <span className="sky-hud__chip" title={connected ? 'В небе' : 'Связь с небом восстанавливается'}>
          <Icon name="users" size={15} /> {connected ? online : '…'}
        </span>
        <span className={cx('sky-hud__chip sky-hud__fight', fightOn && 'is-on')} title="Бой на мечах каждые 3 минуты">
          ⚔️ {fightOn ? `бой ${clock(fight.until - (now + skew))}` : `бой через ${clock(fight.next - (now + skew))}`}
        </span>
      </div>
      {fightOn && (
        <div className={cx('sky-hp', ko && 'is-ko')} aria-label={`HP ${hp} из ${SKY_HP}`}>
          <span className="sky-hp__bar">
            <span style={{ transform: `scaleX(${hp / SKY_HP})` }} />
          </span>
          <b>{ko ? 'сбит' : `${hp} HP`}</b>
        </div>
      )}
      {fightOn && (
        <button type="button" className="sky-attack" disabled={ko} aria-label="Удар мечом (F)" onPointerDown={(e) => e.stopPropagation()} onClick={() => swingRef.current()}>
          <img src="/squid/sword.webp" alt="" />
          <span>Удар</span>
        </button>
      )}
      {fightBanner && (
        <div key={fightBanner.id} className="sky-fightbanner" role="status">
          {fightBanner.text}
        </div>
      )}
      <div className={cx('sky-loot', capped && 'is-capped')}>
        <span className="sky-loot__row">
          <Coin size={18} />
          <b>
            {formatCoins(coins)} / {formatCoins(run.max)} B
          </b>
          {eggs > 0 && <span className="sky-loot__eggs">+ 🥚 {formatCoins(eggs)} B</span>}
        </span>
        {pool !== null && <span className="sky-loot__pool">фонд на всех: {formatCoins(pool)} B</span>}
        <span className="sky-loot__bar">
          <span style={{ transform: `scaleX(${pct / 100})` }} />
        </span>
        {capped && <span className="sky-loot__note">{pool !== null && pool < SKY_COIN_VALUE ? 'Фонд монет закончился — остались яйца' : 'Лимит монет собран — ищи яйца!'}</span>}
      </div>
      {banner && (
        <div key={banner.id} className="sky-banner" role="status">
          <img src="/sky/egg.webp" alt="" />
          <span>
            <b>{banner.by}</b> заспавнил редкое яйцо{banner.mine ? ' рядом с тобой' : ''} — успей подобрать!
            <small>{SKY_EGG_VALUE} B сверх лимита · стрелка покажет путь</small>
          </span>
        </div>
      )}
      {stick && (
        <span className="sky-stick" style={{ left: stick.x, top: stick.y }} aria-hidden="true">
          <span className="sky-stick__knob" style={{ transform: `translate(${stick.dx}px, ${stick.dy}px)` }} />
        </span>
      )}
      <p className="sky-hint">Коснись и веди пальцем · WASD / мышь на ПК · F — удар в бою</p>
      {over && (
        <div className="sky-over" role="dialog" aria-label="Полёт окончен">
          <div className="sky-over__card">
            <img src="/sky/meowl-face.webp" alt="" />
            <h2>Полёт окончен!</h2>
            <p>
              Монеты: <b>{formatCoins(coins)} B</b>
              {eggs > 0 && (
                <>
                  {' '}
                  · яйца: <b>{formatCoins(eggs)} B</b>
                </>
              )}
            </p>
            <p className="sky-over__total">
              Итого на балансе +{formatCoins(round2(coins + eggs))} <Coin size={18} />
            </p>
            <button type="button" className="btn btn--primary btn--lg btn--block" onClick={() => navigate('home')}>
              На главную
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
