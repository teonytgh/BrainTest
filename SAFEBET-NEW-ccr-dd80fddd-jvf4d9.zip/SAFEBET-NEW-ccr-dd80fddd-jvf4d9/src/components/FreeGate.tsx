import { queryOptions, useQuery } from '@tanstack/react-query';
import { useEffect, useRef, useState } from 'react';
import { Icon } from './Icon';
import { api, errorMessage } from '../api/client';
import { queryClient } from '../api/queries';
import { cx } from '../lib/format';
import { sfx } from '../lib/sound';
import { haptic, onAppReturn, openTelegramLink, share, shareMessage } from '../lib/telegram';
import { toast } from '../store/toast';

export interface FreeGateState {
  channel: { username: string; url: string; status: 'ok' | 'missing' | 'unverifiable' } | null;
  share: { done: boolean } | null;
  ready: boolean;
}

const VISITED_KEY = 'brainrotcrash:channelVisited';
const GATE_KEY = ['freeGate'] as const;

/** Remembered for this session too: some WebViews refuse localStorage, and the step must still count. */
const visitedNow = new Set<string>();

function visited(channel: string, mark = false): boolean {
  if (mark) visitedNow.add(channel);
  try {
    if (mark) localStorage.setItem(VISITED_KEY, channel);
    return localStorage.getItem(VISITED_KEY) === channel || visitedNow.has(channel);
  } catch {
    return visitedNow.has(channel);
  }
}

/**
 * A share is under way. Coming back from Telegram's chat picker would re-check the gate, and that answer (read before
 * the confirmation) could land after it and bring «Поделиться» back — the «works from the second try» bug. So the
 * re-check waits while a share runs, and the confirmation cancels one already on its way.
 */
let shareInFlight = false;

/** Server state of the free case conditions; re-checked whenever the player comes back to the app. */
export function useFreeGate(enabled: boolean) {
  const q = useQuery({ queryKey: GATE_KEY, queryFn: () => api<FreeGateState>('/api/free-case/gate'), enabled, staleTime: 0 });
  useEffect(() => (enabled ? onAppReturn(() => void (shareInFlight || q.refetch())) : undefined), [enabled, q.refetch]);
  return q;
}

export const refreshFreeGate = () => queryClient.invalidateQueries({ queryKey: GATE_KEY });

/** The channel step is done. When the bot cannot see the channel members, it counts once the player went there. */
export function channelReady(gate: FreeGateState): boolean {
  const ch = gate.channel;
  return !ch || ch.status === 'ok' || (ch.status === 'unverifiable' && visited(ch.username));
}

/** True when the player may press «Открыть бесплатно». */
export function freeGateReady(gate: FreeGateState | undefined): boolean {
  return !!gate && gate.ready && channelReady(gate);
}

/** Only the share is left: the big button shares and then opens the case in one tap. */
export function onlyShareLeft(gate: FreeGateState | undefined): boolean {
  return !!gate && channelReady(gate) && !!gate.share && !gate.share.done;
}

interface Prepared {
  shareId: number;
  preparedId: string | null;
  text: string;
  url: string;
}

/** The message for Telegram's chat picker, prepared as soon as the share step shows (the server hands out the same one until it is sent). */
const preparedQuery = queryOptions({
  queryKey: ['freeShare'] as const,
  queryFn: () => api<Prepared>('/api/free-case/share', { body: {} }),
  staleTime: 20 * 60_000,
  gcTime: 20 * 60_000,
  // A page left open: keep it fresh (a confirmation is taken within an hour of preparing).
  refetchInterval: 15 * 60_000,
  retry: 1,
});

export interface FreeShare {
  sharing: boolean;
  /** Shares with a friend; resolves true once the share counts. */
  run(): Promise<boolean>;
}

/**
 * «Поделиться с другом» in one tap. The message is prepared before the tap, so the tap opens the picker straight away
 * (no round trip between the tap and Telegram). The button never hangs: a client that doesn't answer is handled in
 * `shareMessage`, and after 8 s the button takes a new tap anyway (a newer tap wins over an older one).
 */
export function useFreeShare(needed: boolean): FreeShare {
  const prepared = useQuery({ ...preparedQuery, enabled: needed });
  const [sharing, setSharing] = useState(false);
  const attempt = useRef(0);

  async function run(): Promise<boolean> {
    const mine = ++attempt.current;
    const latest = () => attempt.current === mine;
    shareInFlight = true;
    setSharing(true);
    // A client that never answers and a player who never comes back: the button and the gate's re-check work again.
    const unlock = setTimeout(() => {
      if (!latest()) return;
      shareInFlight = false;
      setSharing(false);
    }, 8000);
    try {
      const ready = prepared.data;
      // Called in the tap itself, before any await.
      const picker = ready?.preparedId ? shareMessage(ready.preparedId) : null;
      const msg = ready ?? (await queryClient.fetchQuery(preparedQuery));
      let sent = picker ? await picker : msg.preparedId ? await shareMessage(msg.preparedId) : null;
      if (!latest()) return false;
      if (sent === null) {
        // Older Telegram (or a browser): the classic share sheet; it cannot tell us whether a message went out.
        share(msg.text, msg.url);
        sent = true;
      }
      if (!sent) {
        toast('Сообщение не ушло — выбери чат и нажми «Отправить»');
        return false;
      }
      const state = await api<FreeGateState>('/api/free-case/share/confirm', { body: { shareId: msg.shareId } });
      // A re-check started before the confirmation would land with the old «not shared»: drop it.
      await queryClient.cancelQueries({ queryKey: GATE_KEY });
      queryClient.setQueryData(GATE_KEY, state);
      queryClient.removeQueries({ queryKey: preparedQuery.queryKey });
      sfx.coin();
      haptic('success');
      return true;
    } catch (e) {
      if (!latest()) return false;
      sfx.error();
      toast(errorMessage(e), 'error');
      // E.g. an expired message: the next tap gets a fresh one.
      void queryClient.invalidateQueries({ queryKey: preparedQuery.queryKey });
      return false;
    } finally {
      clearTimeout(unlock);
      if (latest()) {
        shareInFlight = false;
        setSharing(false);
      }
    }
  }

  return { sharing, run };
}

/** «Условия бесплатного кейса»: subscribe to the channel (once, unless they leave) and share before every opening. */
export function FreeGate({ gate, share: shareStep }: { gate: FreeGateState; share: FreeShare }) {
  const [checking, setChecking] = useState(false);
  const [, rerender] = useState(0);
  const ch = gate.channel;
  const channelDone = channelReady(gate);
  const wentToChannel = !!ch && visited(ch.username);
  const shareDone = !gate.share || gate.share.done;

  function subscribe() {
    if (!ch) return;
    visited(ch.username, true);
    rerender((n) => n + 1);
    haptic('tap');
    openTelegramLink(ch.url);
  }

  async function check() {
    setChecking(true);
    try {
      const r = await queryClient.fetchQuery({ queryKey: GATE_KEY, queryFn: () => api<FreeGateState>('/api/free-case/gate'), staleTime: 0 });
      if (r.channel?.status === 'missing') {
        sfx.error();
        toast('Пока не видим подписку — подпишись и нажми «Проверить» ещё раз');
      } else {
        sfx.coin();
        haptic('success');
      }
    } catch (e) {
      toast(errorMessage(e), 'error');
    } finally {
      setChecking(false);
    }
  }

  return (
    <div className="free-gate" aria-label="Условия бесплатного кейса" data-tour="free-gate">
      <p className="free-gate__title">
        <Icon name="gift" size={18} /> Чтобы открыть бесплатно
      </p>
      <ol className="free-gate__steps">
        {ch && (
          <li className={cx('free-step', channelDone && 'is-done')}>
            <span className="free-step__n" aria-hidden="true">
              {channelDone ? <Icon name="check" size={16} /> : 1}
            </span>
            <span className="free-step__text">
              <b>Подпишись на {ch.username}</b>
              <small>{channelDone ? 'Подписка есть — спасибо!' : 'Новости, раздачи и промокоды — подписаться нужно один раз'}</small>
            </span>
            {!channelDone &&
              (wentToChannel && ch.status === 'missing' ? (
                <button type="button" className="btn btn--ghost btn--sm" onClick={() => void check()} disabled={checking}>
                  {checking ? '…' : 'Проверить'}
                </button>
              ) : (
                <button type="button" className="btn btn--primary btn--sm" onClick={subscribe}>
                  Подписаться
                </button>
              ))}
          </li>
        )}
        {gate.share && (
          <li className={cx('free-step', shareDone && 'is-done')}>
            <span className="free-step__n" aria-hidden="true">
              {shareDone ? <Icon name="check" size={16} /> : ch ? 2 : 1}
            </span>
            <span className="free-step__text">
              <b>Поделись с другом</b>
              <small>{shareDone ? 'Готово — можно открывать' : 'Отправь BrainrotCrash в любой чат — перед каждым открытием'}</small>
            </span>
            {!shareDone && (
              <button
                type="button"
                className="btn btn--primary btn--sm"
                onClick={() => void shareStep.run().then((ok) => ok && toast('Готово! Теперь открывай кейс', 'success'))}
                disabled={shareStep.sharing || !channelDone}
              >
                {shareStep.sharing ? '…' : 'Поделиться'}
              </button>
            )}
          </li>
        )}
      </ol>
    </div>
  );
}
