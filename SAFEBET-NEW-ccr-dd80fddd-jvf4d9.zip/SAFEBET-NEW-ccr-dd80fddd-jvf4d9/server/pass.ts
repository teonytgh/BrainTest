import { PASS_FREE, PASS_LEVELS, PASS_PLUS_STARS, PASS_QUEST_XP, PASS_XP_PER_B, passCaseFor, passLevelOf, passPlus, passSeason, rewardValue, type PassReward, type PassTrack } from '../shared/pass';
import { TICKET_VALUE } from '../shared/quests';
import { payoutFor } from '../shared/payout';
import { round2 } from '../shared/money';
import { assertActive, type Viewer } from './auth';
import { ensureSchema } from './autoMigrate';
import { activeBrainrots } from './catalog';
import { ms, num, one, q, tx, type Queryable } from './db';
import { addCoins, addWager, payOut } from './economy';
import { HttpError, bad, notFound } from './errors';
import { touch } from './live';
import { getSettings } from './settings';
import { botApi } from './telegram';
import { int, oneOf, type Body } from './validate';

/**
 * «Батл пасс» (iteration 37, rules in shared/pass.ts). Experience is read from what was really staked this season
 * (drops, demo and free openings aside) and the quests claimed; levels and rewards follow from it. BPlus comes through a
 * Stars invoice (`pass:<order>`, paid in the bot's webhook, server/stars.ts); a claim is one row per level and track.
 */

const XP_SQL = `
  SELECT
    (SELECT coalesce(sum(d.stake_value * CASE d.game ${Object.entries(PASS_XP_PER_B)
      .map(([g, k]) => `WHEN '${g}' THEN ${k}`)
      .join(' ')} ELSE 0 END), 0)
       FROM drops d WHERE d.user_id = $1 AND d.stake_value > 0 AND NOT d.demo AND d.created_at >= $2 AND d.created_at < $3) AS play,
    (SELECT count(*) FROM quest_claims c WHERE c.user_id = $1 AND c.period LIKE 'd%' AND c.created_at >= $2 AND c.created_at < $3) AS daily,
    (SELECT count(*) FROM quest_claims c WHERE c.user_id = $1 AND c.period LIKE 'w%' AND c.created_at >= $2 AND c.created_at < $3) AS weekly,
    EXISTS (SELECT 1 FROM pass_plus p WHERE p.user_id = $1 AND p.season = $4) AS plus`;

interface XpRow {
  play: string;
  daily: string;
  weekly: string;
  plus: boolean;
}

async function progress(c: Queryable, userId: number, season: ReturnType<typeof passSeason>) {
  const row = (await c.query<XpRow>(XP_SQL, [userId, new Date(season.start), new Date(season.end), season.id])).rows[0]!;
  const fromPlay = Math.floor(num(row.play));
  const fromQuests = num(row.daily) * PASS_QUEST_XP.daily + num(row.weekly) * PASS_QUEST_XP.weekly;
  const xp = fromPlay + fromQuests;
  return { xp, fromPlay, fromQuests, plus: row.plus, ...passLevelOf(xp) };
}

const tracks = (starRate: number): Record<PassTrack, (PassReward | null)[]> => ({ free: PASS_FREE, plus: passPlus(starRate, TICKET_VALUE) });

/** The paid cases a BPlus opening can be (shared/pass.ts#passCaseFor picks one by value). */
async function passCases(c: Queryable) {
  const { rows } = await c.query<{ id: string; name: string; image: string; price: string; kind: string; status: string; bonus: string | null; price_cycle: string[] | null }>(
    `SELECT id, name, image, price, kind, status, bonus, price_cycle FROM cases WHERE kind = 'paid' AND status = 'active' AND bonus IS NULL AND price > 0`,
  );
  return rows.map((r) => ({ ...r, price: num(r.price), priceCycle: r.price_cycle?.length ? r.price_cycle.map(num) : null }));
}

export async function passState(v: Viewer) {
  await ensureSchema();
  const season = passSeason(Date.now());
  const { starRate } = await getSettings();
  const [p, claims, pending] = await Promise.all([
    tx((c) => progress(c, v.id, season)),
    q<{ level: number; track: PassTrack }>('SELECT level, track FROM pass_claims WHERE user_id = $1 AND season = $2', [v.id, season.id]),
    one<{ id: string }>(`SELECT id FROM pass_orders WHERE user_id = $1 AND season = $2 AND status = 'pending' AND created_at > now() - interval '1 hour' ORDER BY id DESC LIMIT 1`, [v.id, season.id]),
  ]);
  const t = tracks(starRate);
  return {
    season: { id: season.id, name: season.name, endsAt: season.end },
    xp: p.xp,
    fromPlay: p.fromPlay,
    fromQuests: p.fromQuests,
    level: p.level,
    into: p.into,
    need: p.need,
    plus: p.plus,
    plusStars: PASS_PLUS_STARS,
    /** What the whole BPlus track is worth now (B) — shown next to its price. */
    plusValue: round2(t.plus.reduce((s, r) => s + rewardValue(r, TICKET_VALUE), 0)),
    plusPrice: round2(PASS_PLUS_STARS * starRate),
    free: t.free,
    plusTrack: t.plus,
    claimed: claims.map((c) => `${c.track}:${c.level}`),
    pendingOrder: pending ? num(pending.id) : null,
    ticketValue: TICKET_VALUE,
  };
}

export type PassState = Awaited<ReturnType<typeof passState>>;

interface Granted {
  reward: PassReward;
  brainrotId: string | null;
  caseId: string | null;
  coins: number;
  tickets: number;
  value: number;
}

/**
 * Gives one reward inside the claim's transaction: tickets, coins, a free case opening (+ change in coins) or a brainrot
 * (+ change). Coins and brainrots are bonus value (wagered here); what an opening or the tickets drop is wagered by the
 * drops trigger, like every free drop.
 */
async function grant(c: Queryable, userId: number, reward: PassReward, source: string, cases: () => Promise<Awaited<ReturnType<typeof passCases>>>): Promise<Granted> {
  const none = { reward, brainrotId: null, caseId: null, coins: 0, tickets: 0 };
  if (reward.kind === 'tickets') {
    await c.query('UPDATE users SET tickets = tickets + $2 WHERE id = $1', [userId, reward.amount]);
    touch(userId, 'me');
    return { ...none, tickets: reward.amount, value: round2(reward.amount * TICKET_VALUE) };
  }
  if (reward.kind === 'coins') {
    await addCoins(c, userId, reward.amount);
    await addWager(c, userId, reward.amount, 'bonus');
    return { ...none, coins: reward.amount, value: reward.amount };
  }
  if (reward.kind === 'case') {
    const pick = passCaseFor(reward.value, await cases());
    if (pick.case) {
      await c.query(
        `INSERT INTO case_keys (user_id, case_id, count) VALUES ($1, $2, 1)
         ON CONFLICT (user_id, case_id) DO UPDATE SET count = case_keys.count + 1`,
        [userId, pick.case.id],
      );
    }
    await addCoins(c, userId, pick.coins);
    await addWager(c, userId, pick.coins, 'bonus');
    touch(userId, 'me');
    return { ...none, caseId: pick.case?.id ?? null, coins: pick.coins, value: reward.value };
  }
  const payout = payoutFor(reward.value, await activeBrainrots(c));
  await payOut(c, userId, payout, source);
  // Free value: played through before a withdrawal, like every bonus.
  await addWager(c, userId, payout.value, 'bonus');
  return { ...none, brainrotId: payout.brainrot?.id ?? null, coins: payout.coins, value: payout.value };
}

/** Claims every reward reached and not yet taken (`level`/`track` narrow it to one). */
export async function claimPass(v: Viewer, body: Body) {
  assertActive(v);
  await ensureSchema();
  const only = body.level === undefined ? null : { level: int(body.level, 'уровень', 1, PASS_LEVELS), track: oneOf(body.track, 'дорожка', ['free', 'plus'] as const) };
  const season = passSeason(Date.now());
  const { starRate } = await getSettings();
  const t = tracks(starRate);
  const given = await tx(async (c) => {
    // One claim at a time per player (two taps, two devices): the rows' primary key would refuse the second anyway.
    await c.query('SELECT 1 FROM users WHERE id = $1 FOR UPDATE', [v.id]);
    const p = await progress(c, v.id, season);
    if (only) {
      if (only.level > p.level) throw bad('pass_locked', `Уровень ${only.level} ещё не открыт`);
      if (only.track === 'plus' && !p.plus) throw bad('pass_no_plus', 'Эта награда — для BPlus');
      if (!t[only.track][only.level - 1]) throw bad('no_reward', 'На этом уровне награды нет');
    }
    const out: Granted[] = [];
    let caseList: Awaited<ReturnType<typeof passCases>> | null = null;
    const cases = async () => (caseList ??= await passCases(c));
    for (let level = 1; level <= p.level; level++) {
      for (const track of ['free', 'plus'] as const) {
        if (only && (only.level !== level || only.track !== track)) continue;
        if (track === 'plus' && !p.plus) continue;
        const reward = t[track][level - 1];
        if (!reward) continue;
        const ins = await c.query(
          `INSERT INTO pass_claims (user_id, season, level, track, reward) VALUES ($1, $2, $3, $4, $5::jsonb) ON CONFLICT DO NOTHING RETURNING 1`,
          [v.id, season.id, level, track, JSON.stringify(reward)],
        );
        if (!ins.rows.length) continue;
        const g = await grant(c, v.id, reward, `pass:${season.id}:${track}:${level}`, cases);
        await c.query('UPDATE pass_claims SET value = $5 WHERE user_id = $1 AND season = $2 AND level = $3 AND track = $4', [v.id, season.id, level, track, g.value]);
        out.push(g);
      }
    }
    if (only && !out.length) throw bad('claimed', 'Эта награда уже получена');
    if (!out.length) throw bad('nothing', 'Пока нечего забирать — набирай опыт в играх и заданиях');
    return out;
  });
  touch(v.id, 'me');
  return {
    rewards: given.map((g) => ({ brainrotId: g.brainrotId, caseId: g.caseId, coins: g.coins, tickets: g.tickets, value: g.value })),
    total: round2(given.reduce((s, g) => s + g.value, 0)),
  };
}

// ---------- BPlus through Telegram Stars ----------

export const PASS_PAYLOAD = /^pass:(\d{1,18})$/;

export async function buyPlus(v: Viewer) {
  assertActive(v);
  await ensureSchema();
  const season = passSeason(Date.now());
  const has = await one('SELECT 1 FROM pass_plus WHERE user_id = $1 AND season = $2', [v.id, season.id]);
  if (has) throw new HttpError(409, 'already_plus', 'BPlus этого сезона у тебя уже есть');
  const recent = await one<{ n: string }>(`SELECT count(*) AS n FROM pass_orders WHERE user_id = $1 AND created_at > now() - interval '10 minutes'`, [v.id]);
  if (num(recent?.n) >= 5) throw new HttpError(429, 'too_many', 'Слишком много счетов подряд — подожди пару минут');
  const order = await one<{ id: string }>('INSERT INTO pass_orders (user_id, season, stars) VALUES ($1, $2, $3) RETURNING id', [v.id, season.id, PASS_PLUS_STARS]);
  const orderId = num(order!.id);
  const link = await botApi<string>('createInvoiceLink', {
    title: `BPlus — батл пасс (${season.name})`.slice(0, 32),
    description: `BPlus на сезон «${season.name}»: монеты, тикеты и открытия кейсов на всех 30 уровнях батл пасса — в 1,5 раза больше цены, сразу за все пройденные.`,
    payload: `pass:${orderId}`,
    provider_token: '',
    currency: 'XTR',
    prices: [{ label: 'BPlus', amount: PASS_PLUS_STARS }],
  });
  if (!link) throw new HttpError(502, 'telegram_error', 'Telegram не создал счёт — попробуй ещё раз');
  return { orderId, link, stars: PASS_PLUS_STARS };
}

export async function passOrderStatus(v: Viewer, idParam: string) {
  const id = int(idParam, 'счёт');
  const o = await one<{ status: string }>('SELECT status FROM pass_orders WHERE id = $1 AND user_id = $2', [id, v.id]);
  if (!o) throw notFound('Счёт не найден');
  return { orderId: id, status: o.status };
}

/** The webhook's pre-checkout for a BPlus invoice: why it can't be paid, or null. */
export async function passCheckout(orderId: string, fromId: number, amount: number): Promise<string | null> {
  const o = await one<{ user_id: string; season: string; stars: number; status: string; created_at: string; plus: boolean }>(
    `SELECT o.*, EXISTS (SELECT 1 FROM pass_plus p WHERE p.user_id = o.user_id AND p.season = o.season) AS plus FROM pass_orders o WHERE o.id = $1`,
    [orderId],
  );
  if (!o || num(o.user_id) !== fromId) return 'Этот счёт выписан на другой аккаунт';
  if (o.stars !== amount) return 'Сумма счёта не совпадает';
  if (o.status !== 'pending') return 'Этот счёт уже оплачен';
  if (o.plus) return 'BPlus этого сезона у тебя уже есть';
  if (o.season !== passSeason(Date.now()).id || Date.now() - ms(o.created_at)! > 3_600_000) return 'Счёт устарел — открой батл пасс заново';
  return null;
}

/** The webhook's successful payment for a BPlus invoice (idempotent by the charge id). */
export async function passPaid(orderId: string, chargeId: string, amount: number): Promise<{ userId: number; season: string } | { duplicate: true } | { unknown: true }> {
  return tx(async (c) => {
    const { rows } = await c.query<{ id: string; user_id: string; season: string; stars: number }>('SELECT * FROM pass_orders WHERE id = $1 FOR UPDATE', [orderId]);
    const o = rows[0];
    if (!o) return { unknown: true as const };
    const upd = await c.query(`UPDATE pass_orders SET status = 'paid', paid_at = now(), charge_id = $2 WHERE id = $1 AND charge_id IS NULL RETURNING 1`, [o.id, chargeId]);
    if (!upd.rows.length) return { duplicate: true as const };
    if (o.stars !== amount) console.error('pass payment amount mismatch', o.id, amount);
    await c.query('INSERT INTO pass_plus (user_id, season, order_id) VALUES ($1, $2, $3) ON CONFLICT DO NOTHING', [o.user_id, o.season, o.id]);
    touch(num(o.user_id), 'me');
    return { userId: num(o.user_id), season: o.season };
  });
}
