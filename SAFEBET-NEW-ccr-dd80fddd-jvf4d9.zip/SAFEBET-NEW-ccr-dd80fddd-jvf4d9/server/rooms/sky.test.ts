import { describe, expect, it } from 'vitest';
import { SKY_COIN_CHANCE, SKY_FIGHT_EVERY_MS, SKY_FIGHT_MS, SKY_HIT, SKY_HP, chunkCoins, skyFight } from '../../shared/sky';
import { SkyRoom } from './sky';

function setup(start: number) {
  let t = start;
  const room = new SkyRoom(() => t);
  const inbox = new Map<number, Record<string, unknown>[]>();
  const socks = new Map<number, { send: (d: string) => void; close: () => void }>();
  const join = (id: number, god = false) => {
    const sock = { send: (d: string) => d !== 'pong' && inbox.set(id, [...(inbox.get(id) ?? []), JSON.parse(d)]), close: () => {} };
    socks.set(id, sock);
    room.join(id, `p${id}`, sock, { god });
  };
  const send = (id: number, msg: unknown) => room.message(id, socks.get(id)!, JSON.stringify(msg));
  const got = (id: number, type: string) => (inbox.get(id) ?? []).filter((m) => m.t === type);
  const at = (ms: number) => {
    t = ms;
    room.tick();
  };
  return { room, join, send, got, at, now: () => t };
}

describe('«Небо Meowl» (iteration 37)', () => {
  it('coins lie one at a time, in about SKY_COIN_CHANCE of the chunks', () => {
    let coins = 0;
    for (let cx = 0; cx < 40; cx++) {
      for (let cy = 0; cy < 40; cy++) {
        const c = chunkCoins(12345, cx, cy);
        expect(c.length).toBeLessThanOrEqual(1);
        coins += c.length;
      }
    }
    expect(coins / 1600).toBeGreaterThan(SKY_COIN_CHANCE * 0.7);
    expect(coins / 1600).toBeLessThan(SKY_COIN_CHANCE * 1.3);
  });

  it('the fight is the last 30 s of every 3 minutes of the wall clock', () => {
    const base = SKY_FIGHT_EVERY_MS * 1000;
    expect(skyFight(base)).toEqual({ on: false, until: base + SKY_FIGHT_EVERY_MS - SKY_FIGHT_MS, next: base + SKY_FIGHT_EVERY_MS - SKY_FIGHT_MS });
    expect(skyFight(base + SKY_FIGHT_EVERY_MS - 1).on).toBe(true);
    expect(skyFight(base + SKY_FIGHT_EVERY_MS).on).toBe(false);
  });

  it('a sword takes 20 HP within reach, with a cooldown; at 0 HP the flyer is knocked out and frozen until the fight ends', () => {
    const fightAt = SKY_FIGHT_EVERY_MS * 1000 + SKY_FIGHT_EVERY_MS - SKY_FIGHT_MS;
    const s = setup(fightAt - 5000);
    s.join(1);
    s.join(2);
    s.join(3, true);
    s.send(1, { t: 'p', x: 0, y: 0, h: 0 });
    s.send(2, { t: 'p', x: 60, y: 0, h: 0 });
    s.send(3, { t: 'p', x: 5000, y: 0, h: 0 });
    // No fight yet: swings do nothing.
    s.send(1, { t: 'hit' });
    expect(s.got(2, 'hit')).toHaveLength(0);
    s.at(fightAt);
    expect(s.got(2, 'f').at(-1)).toMatchObject({ on: true });
    let t = fightAt;
    for (let i = 0; i < SKY_HP / SKY_HIT; i++) {
      s.send(1, { t: 'hit' });
      // The cooldown: a second swing at once is ignored.
      s.send(1, { t: 'hit' });
      t += 700;
      s.at(t);
    }
    const hits = s.got(2, 'hit');
    expect(hits).toHaveLength(SKY_HP / SKY_HIT);
    expect(hits.at(-1)).toMatchObject({ from: 1, to: 2, hp: 0 });
    expect(s.got(1, 'ko').at(-1)).toMatchObject({ id: 2, by: 1 });
    // Knocked out: their moves are ignored, and they are no target any more.
    s.send(2, { t: 'p', x: 900, y: 900, h: 0 });
    s.room.flush();
    expect(s.got(1, 's').some((m) => (m.p as number[][]).some((r) => r[0] === 2 && r[1] === 900))).toBe(false);
    // The fight ends: everyone is back on their feet.
    s.at(fightAt + SKY_FIGHT_MS);
    expect(s.got(2, 'f').at(-1)).toMatchObject({ on: false });
    s.send(2, { t: 'p', x: 900, y: 900, h: 0 });
    s.room.flush();
    expect(s.got(1, 's').some((m) => (m.p as number[][]).some((r) => r[0] === 2 && r[1] === 900))).toBe(true);
  });

  it('an immortal admin (trailers) takes no damage', () => {
    const fightAt = SKY_FIGHT_EVERY_MS * 2000 + SKY_FIGHT_EVERY_MS - SKY_FIGHT_MS;
    const s = setup(fightAt);
    s.join(1);
    s.join(2, true);
    s.send(1, { t: 'p', x: 0, y: 0, h: 0 });
    s.send(2, { t: 'p', x: 50, y: 0, h: 0 });
    s.at(fightAt + 10);
    for (let i = 0; i < 8; i++) {
      s.send(1, { t: 'hit' });
      s.at(fightAt + 10 + (i + 1) * 700);
    }
    expect(s.got(1, 'hit').every((m) => m.hp === SKY_HP)).toBe(true);
    expect(s.got(1, 'ko')).toHaveLength(0);
  });
});
