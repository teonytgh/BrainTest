import { Sheet } from './Sheet';
import { PromoForm } from './PromoForm';
import { closeSheet, useUi } from '../store/ui';

export function PromoSheet() {
  const { sheet } = useUi();
  return (
    <Sheet open={sheet === 'promo'} onClose={closeSheet} title="Промокод">
      <PromoForm onDone={closeSheet} />
      <p className="form__note">Авто-промокод на главной меняется каждые 2 часа. Подарочные промокоды — в нашем канале.</p>
    </Sheet>
  );
}
