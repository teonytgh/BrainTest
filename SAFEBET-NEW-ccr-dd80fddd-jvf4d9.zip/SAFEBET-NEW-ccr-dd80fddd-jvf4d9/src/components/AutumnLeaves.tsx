import { useMemo, type CSSProperties } from 'react';
import { cx } from '../lib/format';
import { autumnSeason } from '../lib/season';
import { useLeaves } from '../store/leaves';

const reducedMotion = () => typeof matchMedia === 'function' && matchMedia('(prefers-reduced-motion: reduce)').matches;

export type LeafKind = 'maple' | 'oak' | 'birch';
export const LEAF_COLORS = ['rust', 'amber', 'gold', 'red', 'brown'] as const;

/** One autumn leaf: a maple, an oak or a birch leaf with its veins, in a leaf colour token. */
export function Leaf({ kind, color, className }: { kind: LeafKind; color: (typeof LEAF_COLORS)[number]; className?: string }) {
  return (
    <svg viewBox="0 0 64 64" className={cx('leaf', `leaf--${color}`, className)} aria-hidden="true">
      {kind === 'maple' ? (
        <path d="M32 2l5 12 8-4-2 13 11-6-3 11 10 2-11 9 3 5-14-1 1 16h-4l1-16-14 1 3-5-11-9 10-2-3-11 11 6-2-13 8 4z" />
      ) : kind === 'oak' ? (
        <path d="M32 4c4 3 3 7 1 9 5-2 9 0 8 5-1 3-4 4-6 4 5 0 8 3 7 7-1 3-5 4-8 3 4 2 5 6 3 9-2 2-5 2-7 1l1 18h-3l1-18c-2 1-5 1-7-1-2-3-1-7 3-9-3 1-7 0-8-3-1-4 2-7 7-7-2 0-5-1-6-4-1-5 3-7 8-5-2-2-3-6 1-9z" />
      ) : (
        <path d="M32 3c11 9 16 19 14 30-2 9-8 15-13 17l1 11h-4l1-11c-5-2-11-8-13-17-2-11 3-21 14-30z" />
      )}
      <path className="leaf__vein" d={kind === 'birch' ? 'M32 8v50M32 22l-8-5M32 22l8-5M32 33l-10-6M32 33l10-6M32 44l-8-5M32 44l8-5' : 'M32 10v50M32 30l-12-12M32 30l12-12M32 40l-14-4M32 40l14-4'} />
    </svg>
  );
}

const KINDS: LeafKind[] = ['maple', 'oak', 'birch'];

/**
 * Листопад over every page while the autumn season runs (iteration 40). Over the page, under the header, the bars and
 * every sheet; never takes a tap. Cheap on weak phones: few leaves, transform/opacity only, long cycles (a short
 * infinite animation wakes the style engine on every repeat), none with reduced motion or the «Листопад» switch off.
 */
export function AutumnLeaves() {
  const wanted = useLeaves();
  const count = wanted && autumnSeason() && !reducedMotion() ? (window.innerWidth > 900 ? 14 : 9) : 0;
  const leaves = useMemo(
    () =>
      Array.from({ length: count }, (_, i) => {
        const dur = 11 + Math.random() * 8;
        return {
          key: i,
          kind: KINDS[i % KINDS.length]!,
          color: LEAF_COLORS[(i * 2 + 1) % LEAF_COLORS.length]!,
          sway: (i % 3) + 1,
          fall: {
            left: `${Math.round((i / count) * 100 + (Math.random() * 8 - 4))}%`,
            animationDuration: `${dur.toFixed(2)}s`,
            // Negative: the sky is already full of leaves when the app opens.
            animationDelay: `${(-Math.random() * dur).toFixed(2)}s`,
          } as CSSProperties,
          swayStyle: { animationDuration: `${(dur * (0.9 + Math.random() * 0.3)).toFixed(2)}s` } as CSSProperties,
          size: { width: `${Math.round(18 + Math.random() * 16)}px` } as CSSProperties,
        };
      }),
    [count],
  );
  if (!count) return null;
  return (
    <div className="leaves" aria-hidden="true">
      {leaves.map((l) => (
        <span key={l.key} className="leaves__fall" style={l.fall}>
          <span className={cx('leaves__sway', `leaves__sway--${l.sway}`)} style={l.swayStyle}>
            <span className="leaves__size" style={l.size}>
              <Leaf kind={l.kind} color={l.color} />
            </span>
          </span>
        </span>
      ))}
    </div>
  );
}
