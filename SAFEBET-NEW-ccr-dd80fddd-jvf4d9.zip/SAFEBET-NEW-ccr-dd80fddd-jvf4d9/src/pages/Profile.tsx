import { useQuery } from '@tanstack/react-query';
import { useEffect, useState } from 'react';
import { RankBadge } from '../components/RankBadge';
import { RANKS, nextRank } from '../../shared/ranks';
import { Ticket } from '../components/Ticket';
import { Avatar } from '../components/Avatar';
import { BrainrotThumb } from '../components/BrainrotCard';
import { Coin } from '../components/Coin';
import { EmptyState } from '../components/EmptyState';
import { Icon } from '../components/Icon';
import { WagerChip } from '../components/Wager';
import { MediaBadge } from '../components/MediaBadge';
import { PromoForm } from '../components/PromoForm';
import { TitleBadges } from '../components/TitleBadge';
import { isOpenWithdrawal, useCurrentWithdrawal, type Withdrawal } from '../components/WithdrawSheet';
import { WITHDRAW_STATUS_LABEL, formatMsk } from '../../shared/withdraw';
import { api, errorMessage } from '../api/client';
import { act, queryClient, setMe, useCatalog, useMe } from '../api/queries';
import { cx, formatCoins } from '../lib/format';
import { routeHref } from '../lib/router';
import { sfx } from '../lib/sound';
import { haptic } from '../lib/telegram';
import { tierOf } from '../lib/tier';
import { toast } from '../store/toast';
import { openPlayer, openSheet, openWithdraw } from '../store/ui';
import { copyText } from '../lib/copy';
import { DemoTag } from '../components/DemoTag';

const GAME_LABEL: Record<string, string> = { case: 'Кейс', upgrade: 'Апгрейд', dice: 'Дайс', crash: 'Краш', battle: 'Батл', pumpkins: 'Тыквы', halloween: 'Забег', trick: 'Сладость или гадость', fuse: 'Haunted Fuse' };
const time = new Intl.DateTimeFormat('ru-RU', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
const until = new Intl.DateTimeFormat('ru-RU', { dateStyle: 'long', timeStyle: 'short' });

interface HistoryRow {
  id: number;
  game: string;
  win: boolean;
  stake: number;
  brainrotId: string | null;
  coins: number;
  at: number;
  /** Played with demo coins or brainrots (iteration 35). */
  demo?: boolean;
}

/** The brainrot rank with the way to the next one (the ranks page opens from here: the menu no longer lists it). */
function ProfileRank({ rank: level, deposited }: { rank: number; deposited: number }) {
  const rank = RANKS[level] ?? RANKS[0]!;
  const next = nextRank(rank);
  const share = next ? Math.min(1, Math.max(0, (deposited - rank.from) / (next.from - rank.from))) : 1;
  return (
    <a className={cx('prank', `prank--${rank.tier}`)} href={routeHref('ranks')} data-tour="rank">
      <RankBadge rank={rank} size={44} />
      <span className="prank__body">
        <span className="prank__title">
          Ранг: <b>{rank.name}</b> · кэшбэк {rank.cashback}%
        </span>
        <span className="prank__bar" aria-hidden="true">
          <i style={{ transform: `scaleX(${share})` }} />
        </span>
        <small>{next ? `до «${next.name}» ещё ${formatCoins(Math.max(0, next.from - deposited))} B пополнений · подарок ${formatCoins(next.gift)} B` : 'Высший ранг — все подарки открыты'}</small>
      </span>
      <Icon name="chevronRight" size={18} />
    </a>
  );
}

/** «Найти игрока»: by name, profile ID or the exact @username; a tap opens their public profile. */
function PlayerSearch() {
  const [text, setText] = useState('');
  const [query, setQuery] = useState('');
  useEffect(() => {
    const t = setTimeout(() => setQuery(text.trim()), 350);
    return () => clearTimeout(t);
  }, [text]);
  const enabled = query.replace(/^@/, '').length >= 2;
  const found = useQuery({
    queryKey: ['player-search', query],
    queryFn: () => api<{ publicId: string; name: string; photoUrl: string | null }[]>(`/api/players/search?q=${encodeURIComponent(query)}`),
    enabled,
    staleTime: 30_000,
  });
  return (
    <div className="panel psearch">
      <h2 className="panel__title">Найти игрока</h2>
      <label className="search">
        <Icon name="users" size={18} />
        <input
          type="search"
          placeholder="Имя, ID профиля или @username"
          value={text}
          onChange={(e) => setText(e.target.value.slice(0, 40))}
          aria-label="Найти игрока"
          autoCapitalize="off"
          spellCheck={false}
        />
      </label>
      {enabled && found.isPending && <p className="hint hint--left">Ищем…</p>}
      {enabled && found.isError && <p className="hint hint--left">{errorMessage(found.error)}</p>}
      {enabled && found.data?.length === 0 && <p className="hint hint--left">Никого не нашли — проверь имя или ID</p>}
      {!!found.data?.length && enabled && (
        <ul className="psearch__results">
          {found.data.map((p) => (
            <li key={p.publicId}>
              <button type="button" className="psearch__row" onClick={() => openPlayer(p.publicId)}>
                <Avatar user={{ name: p.name, photoUrl: p.photoUrl }} size={40} />
                <span>
                  <b>{p.name}</b>
                  <small>ID: {p.publicId}</small>
                </span>
                <Icon name="chevronRight" size={18} />
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export function Profile() {
  const me = useMe();
  const catalog = useCatalog();
  const { user } = me;
  const [historyOpen, setHistoryOpen] = useState(false);
  const [confirmSellAll, setConfirmSellAll] = useState(false);
  const [busy, setBusy] = useState(false);

  // Titles, gifts and partner badges come from admins — refresh when the player opens the profile.
  useEffect(() => {
    void queryClient.invalidateQueries({ queryKey: ['me'] });
  }, []);

  const history = useQuery({ queryKey: ['history'], queryFn: () => api<HistoryRow[]>('/api/history'), enabled: historyOpen, staleTime: 0 });
  const withdrawals = useQuery({ queryKey: ['withdrawals'], queryFn: () => api<Withdrawal[]>('/api/withdrawals') });
  const current = useCurrentWithdrawal();
  const openWd = isOpenWithdrawal(current.data) ? current.data : null;

  // Brainrots on the withdrawal go last; they can't be sold.
  const items = me.inventory
    .filter((i) => catalog.byId.has(i.brainrotId))
    .sort((a, b) => Number(!!a.withdrawalId) - Number(!!b.withdrawalId) || catalog.byId.get(b.brainrotId)!.price - catalog.byId.get(a.brainrotId)!.price);
  const sellable = items.filter((i) => !i.withdrawalId);
  const inventoryValue = items.reduce((s, i) => s + catalog.byId.get(i.brainrotId)!.price, 0);
  const sellableValue = sellable.reduce((s, i) => s + catalog.byId.get(i.brainrotId)!.price, 0);
  const best = user.bestDrop ? catalog.byId.get(user.bestDrop) : null;
  const frozen = !!user.frozen;
  const display = user.username ? `@${user.username}` : user.name;

  async function sell(body: { itemIds?: number[]; all?: boolean }) {
    setBusy(true);
    try {
      const r = await act<{ sold: number; coins: number }>('/api/inventory/sell', body);
      setMe(r.me);
      sfx.coin();
      haptic('success');
      toast(`Продано ${r.result.sold} шт. за ${formatCoins(r.result.coins)} B`, 'success');
    } catch (e) {
      toast(errorMessage(e), 'error');
    } finally {
      setBusy(false);
      setConfirmSellAll(false);
    }
  }

  return (
    <section className="profile-page" aria-labelledby="profile-title">
      <div className="road-head">
        <h1 id="profile-title" className="page-title">
          Профиль
        </h1>
        {/* Settings live here now (the owner took them out of the menu). */}
        <button type="button" className="btn btn--ghost btn--sm" onClick={() => openSheet('settings')}>
          <Icon name="settings" size={16} /> Настройки
        </button>
      </div>

      {user.frozen && (
        <div className="notice notice--frozen" role="status">
          <Icon name="clock" size={20} />
          <span>
            Аккаунт заморожен {user.frozen.until ? `до ${until.format(user.frozen.until)}` : 'бессрочно'}. Можно только смотреть.
            {user.frozen.reason && <span className="notice__sub">Причина: {user.frozen.reason}</span>}
          </span>
        </div>
      )}

      <div className="pcard">
        <div className="pcard__head">
          <Avatar user={user} size={72} />
          <div className="pcard__who">
            <span className="pcard__source">Telegram</span>
            <span className="pcard__name">
              <span data-private="account">{display}</span>
              <TitleBadges titles={user.titles} owner={display} />
            </span>
            {user.media && <MediaBadge platform={user.media} />}
            <button
              type="button"
              className="pcard__id"
              onClick={() => {
                copyText(user.publicId, 'ID скопирован');
              }}
            >
              ID: {user.publicId}
            </button>
          </div>
        </div>
        <div className="pcard__balance">
          <div>
            <span className="pcard__label">Текущий баланс</span>
            <span className="pcard__coins">
              {formatCoins(user.balance)} <Coin size={20} />
            </span>
            {user.demoBalance > 0 && (
              <span className="pcard__demo" data-private="balance">
                <DemoTag /> из них {formatCoins(user.demoBalance)} B — платят, когда их хватает на всю цену (со своими не складываются), выигрыш с них тоже демо
              </span>
            )}
          </div>
          <button type="button" className="wallet-btn" aria-label="Пополнить баланс" onClick={() => openSheet('deposit')}>
            <Icon name="plus" size={26} />
          </button>
        </div>
        <ProfileRank rank={user.rank} deposited={user.deposited} />
        <a className="pcard__refs pcard__tickets" href={routeHref('quests')}>
          <Ticket size={26} />
          <span>
            Тикеты: {formatCoins(user.tickets)}
            <small>новые задания каждый день · кейсы «Затмение» и «Кенди»</small>
          </span>
          <Icon name="chevronRight" size={18} />
        </a>
        <a className="pcard__refs" href={routeHref('referrals')}>
          <Icon name="users" size={20} />
          <span>
            Рефералы
            {user.refBalance > 0 && <small data-private="balance">на реф. балансе {formatCoins(user.refBalance)} B</small>}
          </span>
          <Icon name="chevronRight" size={18} />
        </a>
        {user.isAdmin && (
          <a className="btn btn--ghost btn--block pcard__admin" href={routeHref('admin')}>
            <Icon name="shield" size={18} /> Админ-панель
          </a>
        )}
      </div>

      <PlayerSearch />

      <div className="panel panel--half">
        <h2 className="panel__title">Лучший дроп</h2>
        {best ? (
          <div className={cx('best-drop', `tier-${tierOf(best.price)}`)}>
            <img src={best.image} alt="" />
            <div>
              <p className="best-drop__name">{best.name}</p>
              <p className="best-drop__price">
                {formatCoins(best.price)} <Coin size={18} />
              </p>
            </div>
          </div>
        ) : (
          <p className="hint hint--left">Пока нет — открой кейс или сыграй в апгрейдер.</p>
        )}
      </div>

      <div className="panel panel--half">
        <h2 className="panel__title">Статистика аккаунта</h2>
        <dl className="stats">
          <div>
            <dt>Кейсов открыто</dt>
            <dd>{formatCoins(user.stats.casesOpened)}</dd>
          </div>
          <div>
            <dt>Апгрейдов</dt>
            <dd>{formatCoins(user.stats.upgrades)}</dd>
          </div>
          <div>
            <dt>Бросков дайса</dt>
            <dd>{formatCoins(user.stats.diceRolls)}</dd>
          </div>
          <div>
            <dt>Раундов краша</dt>
            <dd>{formatCoins(user.stats.crashRounds)}</dd>
          </div>
          <div className="stats__wide">
            <dt>Выведено</dt>
            <dd>
              {formatCoins(user.stats.withdrawn)} <Coin size={18} />
            </dd>
          </div>
        </dl>
      </div>

      <div className="panel">
        <button type="button" className="panel__toggle" aria-expanded={historyOpen} onClick={() => setHistoryOpen((o) => !o)}>
          <span>
            <span className="panel__title">Активность</span>
            <span className="panel__big">Общая история</span>
          </span>
          <Icon name="chevronDown" className={cx('panel__chev', historyOpen && 'is-open')} />
        </button>
        {historyOpen && (
          <div className="history-list">
            {history.isPending && <p className="hint hint--left">Загружаем…</p>}
            {history.data?.length === 0 && <p className="hint hint--left">Пока пусто — самое время сыграть.</p>}
            {history.data?.map((h) => {
              const b = h.brainrotId ? catalog.byId.get(h.brainrotId) : null;
              return (
                <div key={h.id} className={cx('history-row', h.win ? 'is-win' : 'is-lose')}>
                  {b ? <BrainrotThumb brainrot={b} size={38} /> : <span className="history-row__dot" aria-hidden="true" />}
                  <span className="history-row__body">
                    <span className="history-row__game">
                      {GAME_LABEL[h.game] ?? h.game}
                      {h.demo && <DemoTag className="history-row__demo" />}
                    </span>
                    <span className="history-row__what">
                      {h.win ? [b?.name, h.coins ? `${formatCoins(h.coins)} B` : null].filter(Boolean).join(' + ') || 'Выигрыш' : 'Проигрыш'}
                    </span>
                  </span>
                  <time className="history-row__time">{time.format(h.at)}</time>
                </div>
              );
            })}
          </div>
        )}
      </div>

      <div className="panel" data-tour="inventory">
        <div className="panel__row">
          <div>
            <h2 className="panel__title">Инвентарь</h2>
            <p className="panel__sub" data-private="balance">
              {items.length} шт. · {formatCoins(inventoryValue)} <Coin size={13} />
            </p>
            <WagerChip wager={me.user.wager} />
          </div>
          <div className="panel__actions">
            <button
              type="button"
              className={cx('btn btn--sm', openWd ? 'btn--primary' : 'btn--ghost')}
              disabled={(!items.length && !openWd) || frozen}
              onClick={() => openWithdraw()}
              data-private="money"
            >
              {openWd ? `Вывод · ${WITHDRAW_STATUS_LABEL[openWd.status]}` : 'Вывод'}
            </button>
            <button type="button" className="btn btn--ghost btn--sm" disabled={!sellable.length || frozen || busy} onClick={() => setConfirmSellAll(true)}>
              Продать всё
            </button>
          </div>
        </div>
        {confirmSellAll && (
          <div className="confirm">
            <p>
              Продать {sellable.length} шт. за {formatCoins(sellableValue)} B?{sellable.length < items.length ? ' Брейнроты на выводе останутся.' : ''}
            </p>
            <div className="confirm__actions">
              <button type="button" className="btn btn--ghost btn--sm" onClick={() => setConfirmSellAll(false)}>
                Отмена
              </button>
              <button type="button" className="btn btn--danger btn--sm" disabled={busy} onClick={() => sell({ all: true })}>
                Продать всё
              </button>
            </div>
          </div>
        )}
        {items.length === 0 ? (
          <EmptyState
            icon="box"
            title="Инвентарь пуст"
            text="Открой кейс — брейнроты появятся здесь."
            action={
              <a className="btn btn--primary" href={routeHref('home')}>
                К кейсам
              </a>
            }
          />
        ) : (
          <div className="inv-grid">
            {items.map((item) => {
              const b = catalog.byId.get(item.brainrotId)!;
              if (item.withdrawalId) {
                // Locked: tapping it opens the withdrawal (status, «Отменить»).
                return (
                  <button key={item.id} type="button" className={cx('inv-card inv-card--locked', `tier-${tierOf(b.price)}`)} onClick={() => openWithdraw()}>
                    <img src={b.image} alt="" loading="lazy" />
                    <span className="inv-card__name">{b.name}</span>
                    <span className="inv-card__price">
                      {formatCoins(b.price)} <Coin size={13} />
                    </span>
                    <span className="inv-card__lock">НА ВЫВОДЕ</span>
                  </button>
                );
              }
              return (
                <div key={item.id} className={cx('inv-card', `tier-${tierOf(b.price)}`, item.demo && 'inv-card--demo')}>
                  <img src={b.image} alt="" loading="lazy" />
                  {item.demo && <DemoTag corner />}
                  <span className="inv-card__name">{b.name}</span>
                  <span className="inv-card__price">
                    {formatCoins(b.price)} <Coin size={13} />
                  </span>
                  <button type="button" className="btn btn--primary btn--sm btn--block" disabled={frozen || busy} onClick={() => sell({ itemIds: [item.id] })}>
                    Продать
                  </button>
                  {item.demo ? (
                    // A demo gift never leaves the game: no «Вывод» button to tap in vain.
                    <span className="inv-card__demo-note">Не выводится</span>
                  ) : (
                    <button type="button" className="btn btn--ghost btn--sm btn--block" disabled={frozen || !!openWd} onClick={() => openWithdraw(item.id)} data-private="money">
                      Вывод
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {!!withdrawals.data?.length && (
        <div className="panel">
          <h2 className="panel__title">История выводов</h2>
          <div className="history-list">
            {withdrawals.data.map((w) => {
              const b = w.items[0] ? catalog.byId.get(w.items[0].brainrotId) : undefined;
              const pieces = w.items.reduce((s, i) => s + i.count, 0);
              return (
                <button key={w.id} type="button" className={cx('history-row', `wd-${w.status}`)} onClick={() => isOpenWithdrawal(w) && openWithdraw()}>
                  {b && <BrainrotThumb brainrot={b} size={38} />}
                  <span className="history-row__body">
                    <span className="history-row__game">
                      #{w.id} · {time.format(w.createdAt)}
                      {w.scheduledAt && w.status === 'scheduled' ? ` · на ${formatMsk(w.scheduledAt)}` : ''}
                    </span>
                    <span className="history-row__what">
                      {w.items.map((i) => (i.count > 1 ? `${i.name} ×${i.count}` : i.name)).join(', ')} · {pieces} шт. · {formatCoins(w.value)} B
                    </span>
                  </span>
                  <span className={cx('pill', w.status === 'done' && 'pill--green', (w.status === 'rejected' || w.status === 'expired') && 'pill--red', isOpenWithdrawal(w) && 'pill--gold')}>
                    {WITHDRAW_STATUS_LABEL[w.status]}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      )}

      <div className="panel">
        <h2 className="panel__title">Промокод</h2>
        <p className="panel__sub">Введи код — монеты, предмет, открытие кейса, бонус к депозиту или код друга.</p>
        <PromoForm inline />
      </div>

    </section>
  );
}
