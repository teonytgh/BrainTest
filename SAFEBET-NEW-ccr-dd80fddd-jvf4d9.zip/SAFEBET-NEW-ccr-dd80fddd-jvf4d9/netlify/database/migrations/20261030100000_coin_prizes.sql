-- Coin prizes: catalog rows that drop from cases like brainrots (same chances, same reels), but a won coin prize
-- goes straight to the balance (price = the amount) and never into an inventory, a shop, an upgrade or a payout.
ALTER TABLE brainrots ADD COLUMN kind TEXT NOT NULL DEFAULT 'brainrot' CHECK (kind IN ('brainrot', 'coins'));
