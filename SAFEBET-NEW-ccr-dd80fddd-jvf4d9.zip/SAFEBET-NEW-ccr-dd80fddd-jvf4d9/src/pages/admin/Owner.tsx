import { useState } from 'react';
import { Icon } from '../../components/Icon';
import type * as DangerApi from '../../../server/danger';
import { cx, formatCoins } from '../../lib/format';
import {
  Card,
  ConfirmButton,
  Empty,
  Field,
  ImageInput,
  Segmented,
  UserField,
  adminApi,
  formatWhen,
  useAdminAction,
  useAdminQuery,
  type AdminApi,
  type Data,
} from './ui';

// ---------- Announcements ----------

type BroadcastsData = Data<typeof AdminApi.broadcasts>;
type SettingsData = Data<typeof AdminApi.readSettings>;

/** Where the message button opens the app (server/notifications.ts ANNOUNCE_OPEN). */
const OPEN_OPTIONS: { value: string; label: string }[] = [
  { value: '', label: 'Главная' },
  { value: 'case/free', label: 'Бесплатный кейс' },
  { value: 'giveaways', label: 'Розыгрыши' },
  { value: 'mines', label: 'Мины' },
  { value: 'road', label: 'Дорога' },
  { value: 'fuse', label: 'Haunted Fuse' },
  { value: 'upgrader', label: 'Апгрейдер' },
  { value: 'battle', label: 'Батлы' },
  { value: 'bonuses', label: 'Бонусы' },
  { value: 'quests', label: 'Задания' },
  { value: 'ranks', label: 'Ранги' },
  { value: 'referrals', label: 'Рефералы' },
  { value: 'profile', label: 'Профиль' },
];
const CAPTION_MAX = 1024;
const MESSAGE_MAX = 4096;
const KIND_LABEL: Record<string, string> = {
  announce: 'Объявление',
  luck: 'x2 удача',
};

/** The bot's HTML of the admin's text, for the preview (same rules as announceHtml on the server). */
function previewHtml(text: string): string {
  return text
    .trim()
    .replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]!)
    .replace(/\*\*([^*]+?)\*\*/g, '<b>$1</b>')
    .replace(/__([^_]+?)__/g, '<i>$1</i>')
    .replace(/\|\|([^|]+?)\|\|/g, '<span class="atg__spoiler">$1</span>')
    .replace(/\n/g, '<br>');
}

/** A site-wide banner inside the app (not the bot), shown with the owner's Telegram name and photo. */
function SiteAnnounceCard() {
  const settings = useAdminQuery<SettingsData>(['settings'], '/settings');
  const [text, setText] = useState('');
  const current = settings.data?.announcement ?? null;
  const publish = useAdminAction((body: object) => adminApi<SettingsData>('/settings', 'POST', body), { success: 'Опубликовано — видно всем в приложении', catalog: true });
  return (
    <Card title="Сообщение на сайте">
      <p className="acard__text">
        Баннер внутри приложения (не в боте) — с твоим именем и фото из Telegram. Появляется у всех сразу и висит, пока игрок его не закроет; новое сообщение показывается
        заново.
      </p>
      {current && (
        <div className="arow">
          <div>
            <p className="arow__title">Сейчас висит</p>
            <p className="acard__text">
              {current.authorName}: {current.text}
            </p>
          </div>
          <button type="button" className="btn btn--ghost btn--sm" disabled={publish.isPending} onClick={() => publish.mutate({ announcement: { text: '' } })}>
            Снять
          </button>
        </div>
      )}
      <Field label="Текст сообщения" hint={`${text.length}/500`}>
        <textarea className="atextarea" rows={3} maxLength={500} value={text} onChange={(e) => setText(e.target.value)} placeholder="Например: Сегодня вечером розыгрыш — заходите!" />
      </Field>
      <button
        type="button"
        className="btn btn--primary btn--block"
        disabled={publish.isPending || !text.trim()}
        onClick={() => publish.mutate({ announcement: { text: text.trim() } }, { onSuccess: () => setText('') })}
      >
        Опубликовать на сайте
      </button>
    </Card>
  );
}

export function Announce() {
  const list = useAdminQuery<BroadcastsData>(['broadcasts'], '/broadcasts');
  const [photo, setPhoto] = useState<string | null>(null);
  const [text, setText] = useState('');
  const [withButton, setWithButton] = useState<'yes' | 'no'>('yes');
  const [buttonText, setButtonText] = useState('🎮 Открыть BrainrotCrash');
  const [open, setOpen] = useState('');
  const body = () => ({
    text,
    photo,
    button: withButton === 'yes' ? { text: buttonText, open } : null,
  });
  const test = useAdminAction(
    () =>
      adminApi<{ test: string }>('/announce', 'POST', {
        ...body(),
        test: true,
      }),
    {
      success: (r) => (r.test === 'sent' ? 'Отправлено тебе в бота — проверь, как выглядит' : 'Бот не смог написать тебе: запусти бота и попробуй ещё раз'),
    },
  );
  const send = useAdminAction(() => adminApi<BroadcastsData>('/announce', 'POST', body()), {
    success: 'Рассылка запущена — бот отправляет её пачками каждую минуту',
  });
  const stop = useAdminAction((id: number) => adminApi(`/broadcasts/${id}/stop`, 'POST'), { success: 'Рассылка остановлена' });

  const html = previewHtml(text);
  const limit = photo ? CAPTION_MAX : MESSAGE_MAX;
  const tooLong = html.length > limit;
  const ready = text.trim().length > 0 && !tooLong && (withButton === 'no' || buttonText.trim().length > 0);
  const reachable = list.data?.reachable ?? 0;
  const perMinute = list.data?.perMinute ?? 40;
  const minutes = Math.max(1, Math.ceil(reachable / perMinute));

  return (
    <>
      <SiteAnnounceCard />
      <Card title="Рассылка в бота">
        <p className="acard__text">
          Сообщение придёт от @braincrashbot в обычный чат с ботом — всем, кто его не заблокировал (сейчас {formatCoins(reachable)}). Уходит пачками по{' '}
          {perMinute} в минуту: всех охватит примерно за {minutes} мин.
        </p>
        <ImageInput value={photo} onChange={setPhoto} label="Фото (необязательно)" photo />
        <Field label="Текст" hint={`**жирный**, __курсив__, ||спойлер||. ${html.length}/${limit}${photo ? ' — с фото Telegram пускает до 1024 символов' : ''}`}>
          <textarea
            className={cx('atextarea', tooLong && 'is-invalid')}
            rows={6}
            maxLength={MESSAGE_MAX}
            value={text}
            placeholder="**Новый ивент!** Haunted Fuse уже открыт — заходи и сплавляй брейнротов 👻"
            onChange={(e) => setText(e.target.value)}
          />
        </Field>
        <Segmented
          label="Кнопка под сообщением"
          value={withButton}
          onChange={setWithButton}
          options={[
            { value: 'yes', label: 'С кнопкой' },
            { value: 'no', label: 'Без кнопки' },
          ]}
        />
        {withButton === 'yes' && (
          <>
            <Field label="Текст кнопки">
              <span className="ainput">
                <input value={buttonText} maxLength={40} onChange={(e) => setButtonText(e.target.value)} aria-label="Текст кнопки" />
              </span>
            </Field>
            <Field label="Кнопка открывает">
              <span className="ainput">
                <select className="aselect" value={open} onChange={(e) => setOpen(e.target.value)} aria-label="Раздел приложения">
                  {OPEN_OPTIONS.map((o) => (
                    <option key={o.value} value={o.value}>
                      {o.label}
                    </option>
                  ))}
                </select>
              </span>
            </Field>
          </>
        )}
        <div className="atg" aria-label="Так увидят игроки">
          <div className="atg__bubble">
            {photo && <img className="atg__photo" src={photo} alt="" />}
            {text.trim() ? (
              <p className="atg__text" dangerouslySetInnerHTML={{ __html: html }} />
            ) : (
              <p className="atg__text atg__text--empty">Здесь будет текст сообщения</p>
            )}
          </div>
          {withButton === 'yes' && buttonText.trim() && <span className="atg__button">{buttonText}</span>}
        </div>
        <button type="button" className="btn btn--ghost btn--block" disabled={!ready || test.isPending} onClick={() => test.mutate(undefined)}>
          <Icon name="bot" size={16} /> Отправить тест себе
        </button>
        <ConfirmButton
          className="btn btn--primary btn--lg btn--block"
          disabled={!ready || send.isPending}
          confirmText={`Отправить ${formatCoins(reachable)} игрокам?`}
          onConfirm={() =>
            send.mutate(undefined, {
              onSuccess: () => {
                setText('');
                setPhoto(null);
              },
            })
          }
        >
          Отправить всем
        </ConfirmButton>
      </Card>
      <Card title="Последние рассылки">
        {list.data?.list.length === 0 && <Empty>Рассылок ещё не было.</Empty>}
        <ul className="alist">
          {(list.data?.list ?? []).map((b) => (
            <li key={b.id} className="abroadcast">
              {b.photo ? <img className="abroadcast__photo" src={b.photo} alt="" /> : <span className="abroadcast__photo abroadcast__photo--none">✉️</span>}
              <span className="abroadcast__text">
                <span className="abroadcast__title">
                  {KIND_LABEL[b.kind] ?? b.kind} · {formatWhen(b.at)}
                </span>
                <span className="abroadcast__body">{b.text}</span>
                <span className="abroadcast__meta">
                  {b.done ? 'завершена' : 'идёт'} · доставлено {formatCoins(b.sent)}
                  {b.failed ? ` · не дошло ${formatCoins(b.failed)}` : ''}
                </span>
              </span>
              {!b.done && (
                <ConfirmButton className="btn btn--ghost btn--sm" disabled={stop.isPending} confirmText="Стоп?" onConfirm={() => stop.mutate(b.id)}>
                  Стоп
                </ConfirmButton>
              )}
            </li>
          ))}
        </ul>
      </Card>
    </>
  );
}

// ---------- Danger zone ----------

type EggResetResult = Data<typeof DangerApi.resetEggPlayers>;

/** «Небо Meowl» (iteration 38, the owner): every player who picked up an egg is reset at once; the list shows who. */
function EggResetCard({ players }: { players: { id: number; name: string; eggs: number }[] }) {
  const [password, setPassword] = useState('');
  const reset = useAdminAction((body: object) => adminApi<EggResetResult>('/danger/reset-eggs', 'POST', body), {
    success: (r) => `Обнулено игроков: ${r.players}, предметов удалено ${formatCoins(r.items)}`,
  });
  return (
    <Card title="Обнулить всех, кто подобрал яйцо" className="acard--danger">
      <p className="acard__text">
        Все игроки, которые подобрали яйцо в «Небе Meowl», обнуляются как в «Обнулить игрока»: монеты, инвентарь, история, ключи, задания, открытые выводы.
        Админы и владельцы в список не попадают.
      </p>
      {players.length ? (
        <ul className="aaudit__rows">
          {players.map((p) => (
            <li key={p.id}>
              <span>
                {p.name} <small>ID {p.id}</small>
              </span>
              <span>яйца {formatCoins(p.eggs)} B</span>
            </li>
          ))}
        </ul>
      ) : (
        <p className="acard__text">Никто из игроков не подбирал яйцо.</p>
      )}
      <Field label="Пароль">
        <span className="ainput">
          <input type="password" autoComplete="off" value={password} onChange={(e) => setPassword(e.target.value)} aria-label="Пароль для обнуления по яйцам" />
        </span>
      </Field>
      <ConfirmButton
        className="btn btn--danger btn--block"
        disabled={!players.length || !password || reset.isPending}
        confirmText={`Обнулить ${players.length} игрок.?`}
        onConfirm={() => reset.mutate({ password }, { onSettled: () => setPassword('') })}
      >
        <Icon name="reset" size={16} /> Обнулить всех с яйцом ({players.length})
      </ConfirmButton>
    </Card>
  );
}

type DangerInfo = Data<typeof DangerApi.dangerInfo>;
type ResetResult = Data<typeof DangerApi.resetPlayer>;
type WipeResult = Data<typeof DangerApi.wipeAllPlayers>;

export function DangerZone() {
  const info = useAdminQuery<DangerInfo>(['danger'], '/danger');
  const [user, setUser] = useState('');
  const [resetPassword, setResetPassword] = useState('');
  const [wipePassword, setWipePassword] = useState('');
  const [phrase, setPhrase] = useState('');
  const reset = useAdminAction((body: object) => adminApi<ResetResult>('/danger/reset', 'POST', body), {
    success: (r) => `${r.user.display} обнулён: предметов ${r.items}, записей истории ${r.history}`,
  });
  const wipe = useAdminAction((body: object) => adminApi<WipeResult>('/danger/wipe', 'POST', body), {
    success: (r) => `Готово: обнулены все игроки (${formatCoins(r.players)}), предметов удалено ${formatCoins(r.items)}`,
  });
  const expected = info.data?.phrase ?? 'СТЕРЕТЬ ВСЁ';

  if (info.data && !info.data.enabled) {
    return (
      <Card title="Опасная зона" className="acard--danger">
        <p className="acard__text">Выключена: на сервере не задан пароль (секрет WIPE_PASSWORD у Worker).</p>
      </Card>
    );
  }

  return (
    <>
      <div className="anote anote--warn" role="note">
        <p>
          <b>Опасная зона.</b> Действия здесь не отменить. Каждое просит пароль; после 5 неверных попыток раздел закрывается на 15 минут. Всё записывается в
          журнал.
        </p>
      </div>
      <Card title="Обнулить игрока" className="acard--danger">
        <p className="acard__text">
          Стирает у игрока монеты, реферальный баланс, тикеты, инвентарь, историю игр, ключи кейсов, задания, открытые выводы, кэшбэк и его промокоды.
          Аккаунт, ник, баны, админка и титулы остаются.
        </p>
        <UserField value={user} onChange={setUser} />
        <Field label="Пароль">
          <span className="ainput">
            <input type="password" autoComplete="off" value={resetPassword} onChange={(e) => setResetPassword(e.target.value)} aria-label="Пароль" />
          </span>
        </Field>
        <ConfirmButton
          className="btn btn--danger btn--block"
          disabled={!user.trim() || !resetPassword || reset.isPending}
          confirmText={`Обнулить ${user.trim()}?`}
          onConfirm={() => reset.mutate({ user: user.trim(), password: resetPassword }, { onSettled: () => setResetPassword('') })}
        >
          <Icon name="reset" size={16} /> Обнулить игрока
        </ConfirmButton>
      </Card>
      <EggResetCard players={info.data?.eggPlayers ?? []} />
      <Card title="Обнулить всех игроков" className="acard--danger">
        <p className="acard__text">
          У <b>всех</b> игроков: монеты, реферальные балансы и тикеты → 0, инвентари, вся история игр и дропов (LIVE, топ дроп), батлы, ключи, задания, открытые
          выводы, кэшбэк, утешительные спины, игроковые промокоды. Остаются аккаунты, админы, рефералы, баны, титулы, каталог и кейсы, а также платежи Stars,
          пополнения брейнротами и выполненные выводы — это записи о настоящих деньгах и предметах (ранги считаются по ним).
        </p>
        {info.data?.lastWipe && <p className="acard__text">Последнее полное обнуление: {formatWhen(info.data.lastWipe.at)}.</p>}
        <Field label="Пароль">
          <span className="ainput">
            <input
              type="password"
              autoComplete="off"
              value={wipePassword}
              onChange={(e) => setWipePassword(e.target.value)}
              aria-label="Пароль для полного обнуления"
            />
          </span>
        </Field>
        <Field label={`Впиши «${expected}»`}>
          <span className="ainput">
            <input value={phrase} autoComplete="off" onChange={(e) => setPhrase(e.target.value)} aria-label="Подтверждение" placeholder={expected} />
          </span>
        </Field>
        <ConfirmButton
          className="btn btn--danger btn--lg btn--block"
          disabled={!wipePassword || phrase.trim() !== expected || wipe.isPending}
          confirmText="Последний шанс: стереть всех?"
          onConfirm={() =>
            wipe.mutate(
              { password: wipePassword, confirm: phrase.trim() },
              {
                onSettled: () => {
                  setWipePassword('');
                  setPhrase('');
                },
              },
            )
          }
        >
          <Icon name="trash" size={16} /> Обнулить всех игроков
        </ConfirmButton>
      </Card>
    </>
  );
}
