import { useState } from 'react';
import { BrandMark, Logo } from './Logo';
import { Sheet } from './Sheet';
import { errorMessage } from '../api/client';
import { act, setMe, useMe } from '../api/queries';
import { MIN_AGE, TERMS_VERSION } from '../../shared/legal';
import { cx } from '../lib/format';
import { PRIVACY, TERMS, type LegalDoc } from '../lib/legalDocs';
import { sfx } from '../lib/sound';
import { toast } from '../store/toast';

/** One document: the title, the date, then the numbered sections. */
export function LegalText({ doc }: { doc: LegalDoc }) {
  return (
    <article className="legal">
      <p className="legal__updated">Редакция от {doc.updated}</p>
      <p className="legal__intro">{doc.intro}</p>
      {doc.sections.map((s) => (
        <section key={s.h} className="legal__section">
          <h2>{s.h}</h2>
          {s.p.map((p, i) => (
            <p key={i}>{p}</p>
          ))}
        </section>
      ))}
    </article>
  );
}

/**
 * The first screen for a player who hasn't confirmed 18+ and accepted the documents (or whose accepted version is
 * old): two honest checkboxes, both documents one tap away, one button. The server refuses to play without it.
 */
export function ConsentScreen() {
  const [adult, setAdult] = useState(false);
  const [agree, setAgree] = useState(false);
  const [doc, setDoc] = useState<LegalDoc | null>(null);
  const [busy, setBusy] = useState(false);
  const me = useMe();
  const ready = adult && agree;

  async function accept() {
    if (!ready || busy) return;
    setBusy(true);
    try {
      const r = await act<{ version: number }>('/api/legal/accept', { adult: true, version: TERMS_VERSION });
      sfx.coin();
      setMe(r.me);
    } catch (e) {
      sfx.error();
      toast(errorMessage(e), 'error');
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="gate consent">
      <div className="gate__logo">
        <Logo />
      </div>
      <span className="consent__age" aria-hidden="true">
        {MIN_AGE}+
      </span>
      <h1 className="gate__title">Добро пожаловать в BrainrotCrash</h1>
      <p className="gate__text">
        Кейсы, апгрейды и игры на брейнротах — только для взрослых. Монеты и брейнроты здесь для развлечения, это не способ заработать.
      </p>
      {me.user.termsUpdated && (
        <p className="consent__news" role="status">
          Соглашение обновлено (п. 2): перед выводом пополнения и бонусы нужно отыграть — поставить их в играх. Сколько осталось, видно в окне вывода.
        </p>
      )}
      <div className="consent__checks">
        <label className={cx('consent__check', adult && 'is-on')}>
          <input type="checkbox" checked={adult} onChange={(e) => setAdult(e.target.checked)} />
          <span className="consent__box" aria-hidden="true" />
          <span>Мне исполнилось {MIN_AGE} лет</span>
        </label>
        <label className={cx('consent__check', agree && 'is-on')}>
          <input type="checkbox" checked={agree} onChange={(e) => setAgree(e.target.checked)} />
          <span className="consent__box" aria-hidden="true" />
          <span>
            Я принимаю{' '}
            <button type="button" className="link-btn" onClick={() => setDoc(TERMS)}>
              Пользовательское соглашение
            </button>{' '}
            и{' '}
            <button type="button" className="link-btn" onClick={() => setDoc(PRIVACY)}>
              Политику конфиденциальности
            </button>
          </span>
        </label>
      </div>
      <button type="button" className="btn btn--primary btn--lg btn--block consent__go" disabled={!ready || busy} onClick={accept}>
        {busy ? 'Секунду…' : ready ? 'Войти' : 'Отметь оба пункта'}
      </button>
      <p className="gate__hint">
        <BrandMark height={14} /> Играй ради удовольствия и только тем, что готов потерять.
      </p>
      <Sheet open={!!doc} onClose={() => setDoc(null)} title={doc?.title ?? ''}>
        {doc && <LegalText doc={doc} />}
      </Sheet>
    </main>
  );
}
