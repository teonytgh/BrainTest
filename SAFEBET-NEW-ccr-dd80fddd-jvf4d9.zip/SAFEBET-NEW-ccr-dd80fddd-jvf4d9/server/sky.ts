import {
  SKY_COIN_VALUE,
  SKY_DEFAULT_MAX,
  SKY_DEFAULT_POOL,
  SKY_EGG_NEAR,
  SKY_EGG_VALUE,
  SKY_MAX_CAP,
  SKY_MAX_MINUTES,
  SKY_MAX_POOL,
  SKY_MAX_REPEAT_HOURS,
  canReach,
  skyThing,
  spawnPoint,
  type SkyRun,
} from '../shared/sky';
import { round2 } from '../shared/money';
import { assertActive, type Viewer } from './auth';
import { ensureSchema } from './autoMigrate';
import { bumpCatalogVersion, publicName } from './catalog';
import { ms, num, one, q, tx, type Queryable } from './db';
import { addCoins, addWager } from './economy';
import { bad } from './errors';
import { afterResponse, broadcast } from './live';
import { queueBroadcast } from './notifications';
import { roomCall, roomSend, roomTicket, skyRoom } from './rooms/bridge';
import { getSettings, setSetting, type SkySettings } from './settings';
import { bool, int, oneOf, str, type Body } from './validate';

/**
 * «Небо Meowl» (iteration 35, rules in shared/sky.ts). The running flight is the `sky` setting (it rides with the
 * catalog to every open app); `sky_players` keeps where the server last knew each player to be (spawn or last pick),
 * `sky_picks` every coin or egg taken — its primary key is what makes a coin shared. The room (server/rooms/sky.ts)
 * only shows the other players; every pick is checked here: the coin is in the run's map, not taken, the player could
 * have flown to it since the last pick, and the coin cap of the run. Coins are real coins: by default only players
 * with a real deposit fly (multi-accounts don't farm), staff can always test.
 */

interface PlayerRow {
  x: number;
  y: number;
  at: string;
  coins: string;
  eggs: string;
}

async function hasDeposited(c: Queryable, userId: number) {
  const { rows } = await c.query(
    `SELECT 1 FROM star_payments WHERE user_id = $1 UNION ALL SELECT 1 FROM item_deposits WHERE user_id = $1 AND status = 'credited' LIMIT 1`,
    [userId],
  );
  return rows.length > 0;
}

/** Why this player can't fly in this run, or null. */
async function blockOf(c: Queryable, v: Viewer, run: SkyRun): Promise<string | null> {
  if (v.frozen) return 'Аккаунт заморожен';
  if (run.needDeposit && !v.isAdmin && !(await hasDeposited(c, v.id))) return 'Летают игроки с пополнением — пополни баланс и залетай';
  return null;
}

const playerOf = (r: PlayerRow | undefined) =>
  r ? { x: r.x, y: r.y, at: ms(r.at)!, coins: num(r.coins), eggs: num(r.eggs) } : null;

/** What is left of the run's coin pool (null: an older run without one). */
async function poolLeft(run: SkyRun): Promise<number | null> {
  if (run.pool === null || run.pool === undefined) return null;
  const row = await one<{ left: string }>('SELECT greatest(pool - paid, 0) AS left FROM sky_runs WHERE id = $1', [run.runId]);
  return row ? num(row.left) : run.pool;
}

async function runState(v: Viewer, run: SkyRun) {
  const [player, taken, eggs, block, left] = await Promise.all([
    one<PlayerRow>('SELECT x, y, at, coins, eggs FROM sky_players WHERE run_id = $1 AND user_id = $2', [run.runId, v.id]),
    q<{ key: string }>('SELECT key FROM sky_picks WHERE run_id = $1 ORDER BY created_at DESC LIMIT 20000', [run.runId]),
    q<{ id: string; x: number; y: number }>(
      `SELECT e.id, e.x, e.y FROM sky_eggs e
       WHERE e.run_id = $1 AND NOT EXISTS (SELECT 1 FROM sky_picks p WHERE p.run_id = e.run_id AND p.key = 'e:' || e.id)
       ORDER BY e.id DESC LIMIT 500`,
      [run.runId],
    ),
    tx((c) => blockOf(c, v, run)),
    poolLeft(run),
  ]);
  return {
    run,
    block,
    poolLeft: left,
    me: playerOf(player),
    taken: taken.map((t) => t.key),
    eggs: eggs.map((e) => ({ key: `e:${e.id}`, x: e.x, y: e.y })),
    values: { coin: SKY_COIN_VALUE, egg: SKY_EGG_VALUE },
    serverNow: Date.now(),
  };
}

export async function skyState(v: Viewer) {
  await ensureSchema();
  const run = (await getSettings()).sky.run;
  if (!run) return { run: null };
  return runState(v, run);
}

/** Takes off: the player's spawn point (kept on a second visit) and a pass into the room. */
export async function joinSky(v: Viewer) {
  assertActive(v);
  await ensureSchema();
  const settings = await getSettings();
  const run = settings.sky.run;
  if (!run) throw bad('sky_over', 'Сейчас «Небо Meowl» не идёт');
  const name = await tx(async (c) => {
    const block = await blockOf(c, v, run);
    if (block) throw bad('sky_closed', block);
    const spawn = spawnPoint(run.seed, v.id);
    await c.query(`INSERT INTO sky_players (run_id, user_id, x, y) VALUES ($1, $2, $3, $4) ON CONFLICT DO NOTHING`, [run.runId, v.id, spawn.x, spawn.y]);
    const { rows } = await c.query<{ first_name: string; last_name: string | null }>('SELECT first_name, last_name FROM users WHERE id = $1', [v.id]);
    return publicName(rows[0] ?? { first_name: 'Игрок', last_name: null });
  });
  const god = v.isAdmin && settings.immortal.includes(v.id);
  return { ...(await runState(v, run)), ticket: roomTicket({ userId: v.id, name, room: skyRoom(run.runId), god }) };
}

/** A fresh pass for a reconnect (they live a minute). */
export async function skyTicket(v: Viewer) {
  const settings = await getSettings();
  const run = settings.sky.run;
  if (!run) throw bad('sky_over', 'Полёт закончился');
  const row = await one<{ first_name: string; last_name: string | null }>(
    `SELECT u.first_name, u.last_name FROM sky_players p JOIN users u ON u.id = p.user_id WHERE p.run_id = $1 AND p.user_id = $2`,
    [run.runId, v.id],
  );
  if (!row) throw bad('not_joined', 'Сначала взлети');
  return { ticket: roomTicket({ userId: v.id, name: publicName(row), room: skyRoom(run.runId), god: v.isAdmin && settings.immortal.includes(v.id) }) };
}

/** One coin or egg: shared (first come), within flight reach, coins up to the run's cap, eggs on top of it. */
export async function skyPick(v: Viewer, body: Body) {
  assertActive(v);
  const key = str(body.key, 'монета', 3, 40);
  const run = (await getSettings()).sky.run;
  if (!run) throw bad('sky_over', 'Полёт закончился');
  let target: { x: number; y: number; kind: 'coin' | 'egg' } | null = null;
  const spawned = /^e:(\d{1,15})$/.exec(key);
  if (spawned) {
    const egg = await one<{ x: number; y: number }>('SELECT x, y FROM sky_eggs WHERE id = $1 AND run_id = $2', [spawned[1], run.runId]);
    if (egg) target = { x: egg.x, y: egg.y, kind: 'egg' };
  } else {
    target = skyThing(run.seed, key);
  }
  if (!target) throw bad('no_coin', 'Такой монеты нет');
  const at = Date.now();
  const result = await tx(async (c) => {
    const p = (await c.query<PlayerRow>('SELECT x, y, at, coins, eggs FROM sky_players WHERE run_id = $1 AND user_id = $2 FOR UPDATE', [run.runId, v.id])).rows[0];
    if (!p) throw bad('not_joined', 'Сначала взлети');
    if (!canReach({ x: p.x, y: p.y }, ms(p.at)!, target!, at)) throw bad('too_far', 'Слишком далеко — подлети ближе');
    const value = target!.kind === 'coin' ? SKY_COIN_VALUE : SKY_EGG_VALUE;
    if (target!.kind === 'coin' && num(p.coins) + value > run.max + 1e-9) {
      throw bad('sky_cap', `Лимит ${run.max.toLocaleString('ru-RU')} B за полёт собран — дальше только яйца`);
    }
    // The run's pool for everybody (iteration 37): taken before the coin is marked, so a spent pool pays nobody.
    let left: number | null = null;
    if (target!.kind === 'coin' && run.pool !== null && run.pool !== undefined) {
      const spent = await c.query<{ left: string }>('UPDATE sky_runs SET paid = paid + $2 WHERE id = $1 AND paid + $2 <= pool RETURNING pool - paid AS left', [run.runId, value]);
      if (!spent.rows[0]) throw bad('sky_pool', 'Монеты этого полёта закончились — остались только яйца');
      left = num(spent.rows[0].left);
    }
    const ins = await c.query('INSERT INTO sky_picks (run_id, key, user_id, value) VALUES ($1, $2, $3, $4) ON CONFLICT DO NOTHING RETURNING 1', [run.runId, key, v.id, value]);
    if (!ins.rows.length) throw bad('taken', target!.kind === 'egg' ? 'Яйцо уже подобрали' : 'Эту монету уже подобрали');
    const coin = target!.kind === 'coin' ? value : 0;
    const egg = target!.kind === 'egg' ? value : 0;
    const { rows } = await c.query<{ coins: string; eggs: string }>(
      `UPDATE sky_players SET x = $3, y = $4, at = now(), coins = coins + $5, eggs = eggs + $6 WHERE run_id = $1 AND user_id = $2 RETURNING coins, eggs`,
      [run.runId, v.id, target!.x, target!.y, coin, egg],
    );
    await addCoins(c, v.id, value);
    await addWager(c, v.id, value, 'bonus');
    const bal = (await c.query<{ balance: string }>('SELECT balance FROM users WHERE id = $1', [v.id])).rows[0];
    return { key, kind: target!.kind, value, coins: num(rows[0]?.coins), eggs: num(rows[0]?.eggs), balance: num(bal?.balance), poolLeft: left };
  });
  await afterResponse(() => roomSend(skyRoom(run.runId), { t: 'c', k: key, by: v.id, left: result.poolLeft }));
  return result;
}

// ---------- Admin ----------

export async function adminSky() {
  await ensureSchema();
  const s = (await getSettings()).sky;
  const run = s.run;
  const [stats, room] = await Promise.all([
    run
      ? one<{ players: string; coins: string; eggs: string; picks: string; pool: string | null; paid: string }>(
          `SELECT (SELECT count(*) FROM sky_players WHERE run_id = $1) AS players,
             (SELECT pool FROM sky_runs WHERE id = $1) AS pool,
             (SELECT paid FROM sky_runs WHERE id = $1) AS paid,
             (SELECT coalesce(sum(coins), 0) FROM sky_players WHERE run_id = $1) AS coins,
             (SELECT coalesce(sum(eggs), 0) FROM sky_players WHERE run_id = $1) AS eggs,
             (SELECT count(*) FROM sky_picks WHERE run_id = $1) AS picks`,
          [run.runId],
        )
      : null,
    run ? roomCall<{ online: number }>(skyRoom(run.runId), 'stats') : null,
  ]);
  return {
    settings: s,
    stats: stats
      ? {
          players: num(stats.players),
          coins: num(stats.coins),
          eggs: num(stats.eggs),
          picks: num(stats.picks),
          online: room?.online ?? null,
          pool: stats.pool === null ? null : num(stats.pool),
          paid: num(stats.paid),
        }
      : null,
  };
}

function configOf(body: Body, s: SkySettings) {
  return {
    minutes: body.minutes === undefined ? s.minutes : int(body.minutes, 'длительность', 1, SKY_MAX_MINUTES),
    max: body.max === undefined ? s.max : int(body.max, 'лимит на игрока', 1, SKY_MAX_CAP),
    pool: body.pool === undefined ? s.pool : int(body.pool, 'фонд полёта', 1, SKY_MAX_POOL),
    needDeposit: body.needDeposit === undefined ? s.needDeposit : bool(body.needDeposit),
    repeatHours: body.repeatHours === undefined ? s.repeatHours : int(body.repeatHours, 'автоповтор', 0, SKY_MAX_REPEAT_HOURS),
    notify: body.notify === undefined ? s.notify : bool(body.notify),
  };
}

type SkyConfig = ReturnType<typeof configOf>;

/** The `sky` setting: the running flight (or null) and the launch form for the next one. */
const skySetting = (run: SkyRun | null, cfg: SkyConfig, lastStartAt: number | null) => ({
  run,
  minutes: cfg.minutes,
  max: cfg.max,
  pool: cfg.pool,
  needDeposit: cfg.needDeposit,
  repeatHours: cfg.repeatHours,
  notify: cfg.notify,
  lastStartAt,
});

const logAdmin = (c: Queryable, admin: Viewer, action: string, details: Record<string, unknown>) =>
  c.query('INSERT INTO admin_log (admin_id, action, target_user, details) VALUES ($1, $2, NULL, $3::jsonb)', [admin.id, action, JSON.stringify(details)]);

async function startRun(c: Queryable, by: number | null, cfg: SkyConfig): Promise<SkyRun> {
  const seed = Math.floor(Math.random() * 2 ** 31);
  const startedAt = Date.now();
  const endsAt = startedAt + cfg.minutes * 60_000;
  const { rows } = await c.query<{ id: string }>(
    `INSERT INTO sky_runs (seed, started_at, ends_at, max_per_player, need_deposit, created_by, auto, pool) VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING id`,
    [seed, new Date(startedAt), new Date(endsAt), cfg.max, cfg.needDeposit, by, by === null, cfg.pool],
  );
  const run: SkyRun = { runId: num(rows[0]!.id), seed, startedAt, endsAt, max: cfg.max, needDeposit: cfg.needDeposit, pool: cfg.pool };
  await setSetting(c, 'sky', skySetting(run, cfg, startedAt));
  if (cfg.notify && by !== null) {
    await queueBroadcast(c, by, 'sky', {
      html: `🪽 <b>Небо Meowl</b> открыто на ${cfg.minutes} мин! Лети на Meowl и собирай монеты — до ${cfg.max} B за полёт (фонд ${cfg.pool} B на всех), а каждые 3 минуты — бой на мечах.`,
      button: { text: '🪽 Взлететь', open: 'sky' },
    });
  }
  return run;
}

export async function adminSkyStart(admin: Viewer, body: Body) {
  await ensureSchema();
  const s = (await getSettings()).sky;
  const cfg = configOf(body, s);
  const previous = s.run;
  const run = await tx(async (c) => {
    if (previous) await c.query('UPDATE sky_runs SET ends_at = now() WHERE id = $1', [previous.runId]);
    const r = await startRun(c, admin.id, cfg);
    await logAdmin(c, admin, 'sky_start', { ...cfg, runId: r.runId });
    return r;
  });
  if (previous) await afterResponse(() => roomCall(skyRoom(previous.runId), 'close'));
  return { run };
}

/** Saves the launch form (auto-repeat among it) without starting anything. */
export async function adminSkyConfig(admin: Viewer, body: Body) {
  await ensureSchema();
  const s = (await getSettings()).sky;
  const cfg = configOf(body, s);
  await tx(async (c) => {
    // The running flight keeps its own cap; the form applies to the next launches.
    await setSetting(c, 'sky', skySetting(s.run, cfg, s.lastStartAt));
    await logAdmin(c, admin, 'sky_config', cfg);
  });
  return adminSky();
}

export async function adminSkyStop(admin: Viewer) {
  const s = (await getSettings()).sky;
  if (!s.run) throw bad('sky_over', 'Полёт и так не идёт');
  const run = s.run;
  await tx(async (c) => {
    await c.query('UPDATE sky_runs SET ends_at = now() WHERE id = $1', [run.runId]);
    await setSetting(c, 'sky', skySetting(null, { minutes: s.minutes, max: s.max, pool: s.pool, needDeposit: s.needDeposit, repeatHours: s.repeatHours, notify: s.notify }, s.lastStartAt));
    await logAdmin(c, admin, 'sky_stop', { runId: run.runId });
  });
  await afterResponse(() => roomCall(skyRoom(run.runId), 'close'));
  return adminSky();
}

/**
 * Drops a rare egg next to every player online, or next to N random ones; each of them sees «<admin> заспавнил редкое
 * яйцо — успей подобрать!» with a sound. Any player can grab it (first come). Without a room (tests) the players the
 * server saw in the last 5 minutes stand in.
 */
export async function adminSkyEggs(admin: Viewer, body: Body) {
  const run = (await getSettings()).sky.run;
  if (!run) throw bad('sky_over', 'Сначала запусти «Небо Meowl»');
  const mode = oneOf(body.mode, 'кому', ['all', 'random'] as const);
  const count = mode === 'random' ? int(body.count, 'сколько игроков', 1, 100) : 0;
  let targets = await roomCall<{ userId: number; x: number; y: number }[]>(skyRoom(run.runId), 'targets', { mode, count });
  if (!targets) {
    const seen = await q<{ user_id: string; x: number; y: number }>(
      `SELECT user_id, x, y FROM sky_players WHERE run_id = $1 AND at > now() - interval '5 minutes' ORDER BY random() LIMIT $2`,
      [run.runId, mode === 'all' ? 500 : count],
    );
    targets = seen.map((s) => ({ userId: num(s.user_id), x: s.x, y: s.y }));
  }
  if (!targets.length) throw bad('nobody', 'Сейчас в небе никого нет');
  const me = await one<{ first_name: string; last_name: string | null }>('SELECT first_name, last_name FROM users WHERE id = $1', [admin.id]);
  const by = publicName(me ?? { first_name: 'Админ', last_name: null });
  const eggs = await tx(async (c) => {
    const out: { key: string; x: number; y: number; near: number }[] = [];
    for (const t of targets!) {
      const a = Math.random() * Math.PI * 2;
      const d = SKY_EGG_NEAR[0] + Math.random() * (SKY_EGG_NEAR[1] - SKY_EGG_NEAR[0]);
      const x = Math.round(t.x + Math.cos(a) * d);
      const y = Math.round(t.y + Math.sin(a) * d);
      const { rows } = await c.query<{ id: string }>('INSERT INTO sky_eggs (run_id, x, y, near_user, spawned_by) VALUES ($1, $2, $3, $4, $5) RETURNING id', [run.runId, x, y, t.userId, admin.id]);
      out.push({ key: `e:${rows[0]!.id}`, x, y, near: t.userId });
    }
    await logAdmin(c, admin, 'sky_eggs', { mode, count: out.length });
    return out;
  });
  await roomSend(skyRoom(run.runId), { t: 'e', eggs, by });
  return { spawned: eggs.length, eggs };
}

/**
 * The minute tick: a run with auto-repeat starts again once its interval has passed since the last start (and none is
 * running). Returns the new run's id, or null.
 */
export async function skyTick(now = Date.now()): Promise<number | null> {
  const s = (await getSettings()).sky;
  if (s.run || s.repeatHours <= 0 || !s.lastStartAt || now - s.lastStartAt < s.repeatHours * 3_600_000) return null;
  const run = await tx(async (c) => {
    // Two ticks at once: the lock lets one start it.
    await c.query(`SELECT pg_advisory_xact_lock(hashtext('sky-repeat'))`);
    const fresh = (await getSettings(c)).sky;
    if (fresh.run || !fresh.lastStartAt || now - fresh.lastStartAt < fresh.repeatHours * 3_600_000) return null;
    return startRun(c, null, {
      minutes: fresh.minutes,
      max: fresh.max || SKY_DEFAULT_MAX,
      pool: fresh.pool || SKY_DEFAULT_POOL,
      needDeposit: fresh.needDeposit,
      repeatHours: fresh.repeatHours,
      notify: fresh.notify,
    });
  });
  if (!run) return null;
  await bumpCatalogVersion();
  broadcast('catalog');
  return run.runId;
}

/** What the player collected in the last run (shown on the end screen). */
export const skyTotal = (coins: number, eggs: number) => round2(coins + eggs);
