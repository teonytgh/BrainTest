import { createHash, randomBytes } from 'node:crypto';
import { round2 } from '../shared/money';
import { payoutFor } from '../shared/payout';
import {
  MAX_ROAD_ITEMS,
  MAX_ROAD_PAYOUT,
  MIN_ROAD_STAKE,
  ROAD_LEVEL_IDS,
  laneCrashes,
  laneMultiplier,
  nextLaneProblem,
  roadMessage,
  type RoadLevel,
  type RoadRun,
  type RoadState,
} from '../shared/road';
import { assertActive, type Viewer } from './auth';
import { activeBrainrots, publicName } from './catalog';
import { ms, num, q, tx, type Queryable } from './db';
import { giveItems, payOut, recordDrop, stakeDemo, takeItem } from './economy';
import { bad } from './errors';
import { afterResponse } from './live';
import { notify } from './telegram';
import { ids, oneOf, type Body } from './validate';

const sha256 = (s: string) => createHash('sha256').update(s).digest('hex');

/** A run nobody touched for this long is closed by the tick: the win is taken for the player, or the stake returned. */
export const ROAD_IDLE_MS = 30 * 60 * 1000;

function newSeed() {
  const seed = randomBytes(32).toString('hex');
  return { seed, hash: sha256(seed) };
}

/** The player's next road key, created on first use; locked by a start so that it is used exactly once. */
async function seedRow(c: Queryable, userId: number, lock: boolean) {
  const s = newSeed();
  await c.query('INSERT INTO road_seeds (user_id, seed, hash) VALUES ($1, $2, $3) ON CONFLICT (user_id) DO NOTHING', [userId, s.seed, s.hash]);
  const { rows } = await c.query<{ seed: string; hash: string }>(`SELECT seed, hash FROM road_seeds WHERE user_id = $1${lock ? ' FOR UPDATE' : ''}`, [userId]);
  return rows[0]!;
}

interface RunRow {
  id: string;
  user_id: string;
  level: RoadLevel;
  stake_value: string;
  stake: string[];
  seed: string;
  hash: string;
  step: number;
  status: RoadRun['status'];
  payout: RoadRun['payout'];
  /** Played with demo brainrots (iteration 35): the win or the refund is demo. */
  demo: boolean;
}

function runView(r: RunRow): RoadRun {
  const stakeValue = num(r.stake_value);
  const over = r.status !== 'active';
  return {
    id: num(r.id),
    level: r.level,
    step: r.step,
    status: r.status,
    stakeValue,
    stake: r.stake,
    multiplier: laneMultiplier(r.level, r.step),
    next: { multiplier: laneMultiplier(r.level, r.step + 1), problem: nextLaneProblem(r.level, r.step, stakeValue) },
    hash: r.hash,
    seed: over ? r.seed : null,
    payout: r.payout,
  };
}

const activeRun = async (c: Queryable, userId: number) =>
  (await c.query<RunRow>(`SELECT * FROM road_runs WHERE user_id = $1 AND status = 'active' FOR UPDATE`, [userId])).rows[0];

interface DropRow {
  result: 'win' | 'lose';
  stake_value: string;
  payout_value: string | null;
  brainrot_id: string | null;
  meta: { level?: RoadLevel; step?: number; multiplier?: number } | null;
  created_at: string;
}

export async function roadState(v: Viewer): Promise<RoadState> {
  const [seed, run, mine, top] = await Promise.all([
    tx((c) => seedRow(c, v.id, false)),
    q<RunRow>(`SELECT * FROM road_runs WHERE user_id = $1 AND status = 'active'`, [v.id]),
    q<DropRow>(`SELECT result, stake_value, payout_value, brainrot_id, meta, created_at FROM drops WHERE user_id = $1 AND game = 'road' ORDER BY id DESC LIMIT 12`, [v.id]),
    q<DropRow & { first_name: string; last_name: string | null }>(
      `SELECT d.result, d.stake_value, d.payout_value, d.brainrot_id, d.meta, d.created_at, u.first_name, u.last_name
       FROM drops d JOIN users u ON u.id = d.user_id
       WHERE d.game = 'road' AND d.result = 'win' AND NOT d.demo
       ORDER BY d.payout_value DESC, d.id LIMIT 10`,
    ),
  ]);
  return {
    nextHash: seed.hash,
    run: run[0] ? runView(run[0]) : null,
    mine: mine.map((d) => ({
      level: d.meta?.level ?? 'easy',
      step: d.meta?.step ?? 0,
      won: Number(d.meta?.multiplier ?? 0) > 0,
      multiplier: Number(d.meta?.multiplier ?? 0),
      value: num(d.payout_value),
      stakeValue: num(d.stake_value),
      at: ms(d.created_at)!,
    })),
    top: top.map((d) => ({
      name: publicName(d),
      level: d.meta?.level ?? 'easy',
      step: d.meta?.step ?? 0,
      multiplier: Number(d.meta?.multiplier ?? 0),
      value: num(d.payout_value),
      brainrotId: d.brainrot_id,
      at: ms(d.created_at)!,
    })),
  };
}

/** The stake goes in and the brainrot stands at the kerb, on the key whose hash the player saw. */
export async function startRoad(v: Viewer, body: Body): Promise<{ run: RoadRun; nextHash: string }> {
  assertActive(v);
  const level = oneOf<RoadLevel>(body.level, 'уровень', ROAD_LEVEL_IDS);
  if (body.coins) throw bad('items_only', 'Ставка — только брейнроты');
  const raw = body.itemIds ?? [];
  if (Array.isArray(raw) && raw.length === 0) throw bad('invalid', 'Поставь брейнротов');
  const itemIds = ids(raw, 'брейнроты', MAX_ROAD_ITEMS);
  return tx(async (c) => {
    // The key row lock serialises the player's starts: the active-run check below can't race.
    const key = await seedRow(c, v.id, true);
    if (await activeRun(c, v.id)) throw bad('run_active', 'Сначала закончи забег');
    const stakes = [];
    for (const id of itemIds) stakes.push(await takeItem(c, v.id, id));
    const demo = stakeDemo(stakes);
    const stakeValue = round2(stakes.reduce((s, x) => s + x.price, 0));
    if (stakeValue < MIN_ROAD_STAKE) throw bad('stake_too_small', `Ставка — от ${MIN_ROAD_STAKE} B`);
    if (nextLaneProblem(level, 0, stakeValue)) throw bad('limit', `Слишком большая ставка: выигрыш больше ${MAX_ROAD_PAYOUT.toLocaleString('ru-RU')} B`);
    const { rows } = await c.query<RunRow>(
      `INSERT INTO road_runs (user_id, level, stake_value, stake, seed, hash, demo) VALUES ($1, $2, $3, $4::jsonb, $5, $6, $7) RETURNING *`,
      [v.id, level, stakeValue, JSON.stringify(stakes.map((x) => x.brainrotId)), key.seed, key.hash, demo],
    );
    const next = newSeed();
    await c.query('UPDATE road_seeds SET seed = $2, hash = $3, nonce = nonce + 1 WHERE user_id = $1', [v.id, next.seed, next.hash]);
    return { run: runView(rows[0]!), nextHash: next.hash };
  });
}

/** Takes the current lane's win: a catalog brainrot + change in coins. */
async function cashOut(c: Queryable, r: RunRow): Promise<RunRow> {
  const userId = num(r.user_id);
  const stakeValue = num(r.stake_value);
  const multiplier = laneMultiplier(r.level, r.step);
  const payout = payoutFor(stakeValue * multiplier, await activeBrainrots(c));
  const itemId = await payOut(c, userId, payout, 'road', r.demo);
  const paid = { brainrotId: payout.brainrot?.id ?? null, coins: payout.coins, itemId, value: payout.value };
  const { rows } = await c.query<RunRow>(
    `UPDATE road_runs SET status = 'cashed', payout = $2::jsonb, updated_at = now(), finished_at = now() WHERE id = $1 RETURNING *`,
    [r.id, JSON.stringify(paid)],
  );
  await recordDrop(c, {
    userId,
    game: 'road',
    // Leaving below x1 gives part of the stake back: taken, but no win (and no LIVE tile).
    win: multiplier >= 1,
    stakeValue,
    brainrotId: paid.brainrotId,
    coins: paid.coins,
    payoutValue: paid.value,
    meta: { level: r.level, step: r.step, multiplier, hash: r.hash, seed: r.seed, from: r.stake },
    demo: r.demo,
  });
  return rows[0]!;
}

/** One lane further: a crash burns the stake; the last lane the road (or the limit) allows is taken at once. */
export async function stepRoad(v: Viewer): Promise<{ run: RoadRun; crashed: boolean }> {
  assertActive(v);
  return tx(async (c) => {
    const r = await activeRun(c, v.id);
    if (!r) throw bad('no_run', 'Забег не начат');
    const stakeValue = num(r.stake_value);
    const problem = nextLaneProblem(r.level, r.step, stakeValue);
    if (problem) throw bad('limit', 'Дальше дороги нет — забирай выигрыш');
    const lane = r.step + 1;
    if (laneCrashes(r.level, sha256(roadMessage(r.seed, lane)))) {
      const { rows } = await c.query<RunRow>(
        `UPDATE road_runs SET status = 'crashed', updated_at = now(), finished_at = now() WHERE id = $1 RETURNING *`,
        [r.id],
      );
      await recordDrop(c, {
        userId: v.id,
        game: 'road',
        win: false,
        stakeValue,
        payoutValue: 0,
        meta: { level: r.level, step: r.step, crashedAt: lane, multiplier: 0, hash: r.hash, seed: r.seed, from: r.stake },
        demo: r.demo,
      });
      return { run: runView(rows[0]!), crashed: true };
    }
    const { rows } = await c.query<RunRow>(`UPDATE road_runs SET step = $2, updated_at = now() WHERE id = $1 RETURNING *`, [r.id, lane]);
    const moved = rows[0]!;
    const done = nextLaneProblem(r.level, lane, stakeValue) ? await cashOut(c, moved) : moved;
    return { run: runView(done), crashed: false };
  });
}

export async function cashoutRoad(v: Viewer): Promise<{ run: RoadRun }> {
  assertActive(v);
  return tx(async (c) => {
    const r = await activeRun(c, v.id);
    if (!r) throw bad('no_run', 'Забег не начат');
    if (r.step < 1) throw bad('no_step', 'Сделай хотя бы один шаг');
    return { run: runView(await cashOut(c, r)) };
  });
}

/**
 * The tick closes runs left alone for ROAD_IDLE_MS: after a step the win is taken for the player (it is theirs —
 * the lane is already crossed), before one the same brainrots go back.
 */
export async function closeIdleRoads(now = Date.now()) {
  const stale = await q<{ id: string }>(
    `SELECT id FROM road_runs WHERE status = 'active' AND updated_at < $1 ORDER BY updated_at LIMIT 20`,
    [new Date(now - ROAD_IDLE_MS)],
  );
  let closed = 0;
  for (const { id } of stale) {
    const done = await tx(async (c) => {
      const r = (await c.query<RunRow>(`SELECT * FROM road_runs WHERE id = $1 AND status = 'active' AND updated_at < $2 FOR UPDATE`, [id, new Date(now - ROAD_IDLE_MS)])).rows[0];
      if (!r) return null;
      if (r.step >= 1) return cashOut(c, r);
      for (const brainrotId of r.stake) await giveItems(c, num(r.user_id), brainrotId, 'road_refund', 1, r.demo);
      return (
        await c.query<RunRow>(`UPDATE road_runs SET status = 'refunded', updated_at = now(), finished_at = now() WHERE id = $1 RETURNING *`, [r.id])
      ).rows[0]!;
    });
    if (!done) continue;
    closed++;
    const value = done.payout?.value ?? 0;
    await afterResponse(() =>
      notify(
        num(done.user_id),
        done.status === 'refunded'
          ? '🛣 Забег в «Дороге» простоял 30 минут без шага — ставка вернулась в инвентарь.'
          : `🛣 Ты оставил забег в «Дороге» на полосе ${done.step} — выигрыш <b>${value.toLocaleString('ru-RU')} B</b> уже в инвентаре.`,
      ),
    );
  }
  return closed;
}
