import { randomBytes } from 'node:crypto';
import { bad } from './errors';

export interface StoredImage {
  bytes: Uint8Array;
  type: string;
}

export interface ImageStore {
  put(key: string, image: StoredImage): Promise<void>;
  get(key: string): Promise<StoredImage | null>;
}

let store: ImageStore | null = null;

export function useImageStore(s: ImageStore | null) {
  store = s;
}

async function getStore(): Promise<ImageStore> {
  if (store) return store;
  const { getStore: blobs } = await import('@netlify/blobs');
  const s = blobs({ name: 'uploads', consistency: 'strong' });
  store = {
    async put(key, image) {
      const copy = new Uint8Array(image.bytes);
      await s.set(key, copy.buffer, { metadata: { type: image.type } });
    },
    async get(key) {
      const r = await s.getWithMetadata(key, { type: 'arrayBuffer' });
      if (!r) return null;
      return { bytes: new Uint8Array(r.data), type: String(r.metadata.type ?? 'application/octet-stream') };
    },
  };
  return store;
}

const TYPES: Record<string, (b: Uint8Array) => boolean> = {
  'image/png': (b) => b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47,
  'image/jpeg': (b) => b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff,
  'image/gif': (b) => b[0] === 0x47 && b[1] === 0x49 && b[2] === 0x46,
  'image/webp': (b) => String.fromCharCode(...b.slice(0, 4)) === 'RIFF' && String.fromCharCode(...b.slice(8, 12)) === 'WEBP',
};

const MAX_BYTES = 1_500_000;

/** Accepts a data: URL of a raster image (SVG is refused — it can carry scripts) and returns its public URL. */
export async function saveUpload(dataUrl: unknown): Promise<string> {
  if (typeof dataUrl !== 'string') throw bad('invalid', 'Нет файла');
  const m = /^data:(image\/(?:png|jpeg|gif|webp));base64,([A-Za-z0-9+/=]+)$/.exec(dataUrl);
  if (!m) throw bad('invalid', 'Поддерживаются PNG, JPG, WEBP и GIF');
  const type = m[1]!;
  const bytes = new Uint8Array(Buffer.from(m[2]!, 'base64'));
  if (bytes.length > MAX_BYTES) throw bad('too_big', 'Картинка больше 1,5 МБ');
  if (!TYPES[type]!(bytes)) throw bad('invalid', 'Файл не похож на картинку');
  const key = randomBytes(12).toString('hex');
  await (await getStore()).put(key, { bytes, type });
  return `/api/img/${key}`;
}

export async function serveUpload(key: string): Promise<Response> {
  if (!/^[a-f0-9]{24}$/.test(key)) return new Response('Not found', { status: 404 });
  const image = await (await getStore()).get(key);
  if (!image || !TYPES[image.type]) return new Response('Not found', { status: 404 });
  return new Response(new Uint8Array(image.bytes).buffer, {
    headers: {
      'content-type': image.type,
      'cache-control': 'public, max-age=31536000, immutable',
      'x-content-type-options': 'nosniff',
    },
  });
}

export function isImageUrl(url: unknown): url is string {
  return typeof url === 'string' && /^\/brainrots\/[a-z0-9-]+\.webp$|^\/cases\/[a-z0-9-]+\.(?:webp|svg)$|^\/api\/img\/[a-f0-9]{24}$|^\/uploads\/[a-f0-9]{24}\.(?:png|jpg|gif|webp)$/.test(url);
}
