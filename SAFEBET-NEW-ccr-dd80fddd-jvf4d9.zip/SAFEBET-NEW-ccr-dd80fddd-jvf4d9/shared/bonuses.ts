/** Rules of the referral programme and the bonus section, shared by the server and the UI. */

/**
 * RevShare: a share of what the house wins on the referred players' cases and battles (their net loss — not their
 * deposits), paid on Saturdays. The level grows with the number of active friends: those whose first real
 * deposit reached REF_DEPOSIT_MIN (so fake accounts don't count).
 */
export const REF_LEVELS = [
  { level: 1, from: 0, percent: 5 },
  { level: 2, from: 10, percent: 7 },
  { level: 3, from: 30, percent: 10 },
  { level: 4, from: 100, percent: 12 },
  { level: 5, from: 250, percent: 15 },
] as const;

export function refLevel(active: number) {
  let current: (typeof REF_LEVELS)[number] = REF_LEVELS[0];
  for (const l of REF_LEVELS) if (active >= l.from) current = l;
  const next = REF_LEVELS.find((l) => l.from > active) ?? null;
  return { ...current, next };
}

/** A friend becomes active (counts towards the level) with a first real deposit of at least this many coins. */
export const REF_DEPOSIT_MIN = 10;

/**
 * A Stars deposit made with the payer's partner code gets this much more (iteration 35, the owner's «+15 % от кода
 * партнёра»). Stars only: brainrots can be deposited and withdrawn again, so a bonus on them would pay for the round
 * trip. The partner still gets their usual share of what was paid (the bonus aside).
 */
export const PARTNER_DEPOSIT_PERCENT = 15;

/**
 * «Крупные приглашения»: when a friend's net deposits since binding (deposits − finished withdrawals) pass a
 * threshold, the referrer gets 10 % of it on the referral balance, once per friend and threshold (1 000 → 100 B …) —
 * on top of the share of each deposit. The owner asked for big rewards; what keeps them from bankrupting the house is
 * the second condition: the friend has also played REF_MILESTONE_TURNOVER × the threshold in cases and battles
 * (HOUSE_GAMES) since binding. Those keep 12 %, so 3× the threshold played earns the house ~36 % of it on average —
 * more than this 10 % plus the deposit share (5–15 %), and two accounts depositing and withdrawing can't farm it
 * (withdrawals take the net back down, turnover costs them 12 % of everything played).
 */
export const REF_MILESTONE_TURNOVER = 3;
export const REF_MILESTONES = [
  { step: 1, from: 1_000, reward: 100 },
  { step: 2, from: 5_000, reward: 500 },
  { step: 3, from: 20_000, reward: 2_000 },
  { step: 4, from: 50_000, reward: 5_000 },
] as const;

/** The first threshold not paid yet (`paidStep` = the highest step paid for this friend, 0 if none). */
export const nextMilestone = (paidStep: number) => {
  const m = REF_MILESTONES.find((x) => x.step > paidStep);
  return m ? { step: m.step, from: m.from, reward: m.reward, turnover: m.from * REF_MILESTONE_TURNOVER } : null;
};

/** A personal referral code can be changed once a day; old codes keep pointing at their owner. */
export const REF_CODE_COOLDOWN_MS = 24 * 60 * 60 * 1000;

/**
 * Games whose house result feeds RevShare and cashback: only those with a built-in house edge, so a rebate on
 * losses can't turn a zero-edge game (upgrader, dice) or a high-multiplier crash bet into a sure profit.
 */
export const HOUSE_GAMES = ['case', 'battle'] as const;

/** «Кейс за ник»: the Telegram name has to end with this tag. */
export const NICK_TAG = '@BrainrotCrash';
export const NICK_CASE_COOLDOWN_MS = 12 * 60 * 60 * 1000;

export function hasNickTag(first: string, last?: string | null): boolean {
  const name = [first, last].filter(Boolean).join(' ').trim();
  return name.toLowerCase().endsWith(NICK_TAG.toLowerCase());
}

/** Weekly cashback: this share of a week's net loss on paid cases and battles, handed out on Fridays. */
/** Weekly cashback of a player without a rank; ranks raise it (shared/ranks.ts). */
export const CASHBACK_PERCENT = 3;
/** On a Friday the player collects every finished week they haven't collected yet, up to this many back. */
export const CASHBACK_WEEKS_BACK = 4;

/** Losing an upgrade with a stake of at least this much gives a consolation spin, at most once a day. */
export const CONSOLATION_MIN_STAKE = 300;
export const CONSOLATION_COOLDOWN_MS = 24 * 60 * 60 * 1000;
/** The consolation spin pays coins only; brainrots on its reel are decoration. */
export const CONSOLATION_PRIZES: readonly { coins: number; weight: number }[] = [
  { coins: 1, weight: 20 },
  { coins: 2, weight: 18 },
  { coins: 3, weight: 15 },
  { coins: 5, weight: 13 },
  { coins: 7, weight: 10 },
  { coins: 10, weight: 9 },
  { coins: 12, weight: 6 },
  { coins: 15, weight: 4 },
  { coins: 20, weight: 3 },
  { coins: 25, weight: 1.5 },
  { coins: 30, weight: 0.5 },
];

const HOUR = 3_600_000;
const DAY = 24 * HOUR;
const MSK = 3 * HOUR;

/** Week number (weeks start on Monday 00:00 Moscow time). */
export function weekIndex(ms: number): number {
  const day = Math.floor((ms + MSK) / DAY); // day 0 = Thursday 1970-01-01
  return Math.floor((day + 3) / 7);
}

/** UTC ms when week `w` starts (Monday 00:00 MSK). */
export function weekStart(w: number): number {
  return (w * 7 - 3) * DAY - MSK;
}

/** RevShare is paid on Saturdays at 15:00 MSK: the latest such moment at or before `ms`. */
export function lastPayoutMoment(ms: number): number {
  const saturday = weekStart(weekIndex(ms)) + 5 * DAY + 15 * HOUR;
  return saturday <= ms ? saturday : saturday - 7 * DAY;
}

export const nextPayoutMoment = (ms: number) => lastPayoutMoment(ms) + 7 * DAY;

/** Cashback is collected on Fridays (Moscow time) only. */
export const isCashbackDay = (ms: number) => new Date(ms + MSK).getUTCDay() === 5;

/** The Friday (00:00 MSK) when cashback can be collected next: today's when it is Friday already. */
export function cashbackDayStart(ms: number): number {
  const friday = weekStart(weekIndex(ms)) + 4 * DAY;
  return ms < friday + DAY ? friday : friday + 7 * DAY;
}
