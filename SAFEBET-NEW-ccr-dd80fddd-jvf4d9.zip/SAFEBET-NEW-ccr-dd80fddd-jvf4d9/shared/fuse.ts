import { floor2, round2 } from './money';

/**
 * Haunted Fuse: 3–4 brainrots go into the machine (their total price is the stake) and one random brainrot comes
 * out. 82 % of the time it is cheaper than the stake, 15 % between x1 and x1.5, 3 % between x1.5 and x2, never
 * dearer than x2; on average it is worth FUSE_RTP of the stake (like a case). Cheaper profitable brainrots are
 * likelier than dear ones; inside the losing range the weights are tuned so the average comes out right.
 *
 * The pick comes from the player's pre-committed key: u1 picks the range and u2 the brainrot in it, the first two
 * 32-bit numbers of sha256("fuse:" + key).
 */
export const FUSE_RTP = 0.88;
export const MIN_FUSE_ITEMS = 3;
export const MAX_FUSE_ITEMS = 4;

export const FUSE_BANDS = [
  { id: 'loss', share: 0.82 },
  { id: 'okup', share: 0.15 },
  { id: 'big', share: 0.03 },
] as const;
export type FuseBand = (typeof FUSE_BANDS)[number]['id'];

/** The losing range starts at a quarter of the stake (lower only when the catalog is thin there). */
const LOSS_FLOOR = 0.25;
/** …and must reach down to at least this share of the stake with a few brainrots in it. */
const LOSS_REACH = 0.6;
const LOSS_MIN_ITEMS = 3;
/** Among the profitable brainrots weight ∝ price^-PROFIT_EXP: cheaper ones are likelier. */
const PROFIT_EXP = 1.5;
/** Bounds for the exponent tuned inside the losing range. */
const LOSS_EXP = 12;

export interface FuseCandidate {
  id: string;
  price: number;
  band: FuseBand;
  /** Probability of this brainrot (all candidates add up to 1). */
  p: number;
}

export interface FuseTable {
  stake: number;
  candidates: FuseCandidate[];
  /** Probability of each range (a range with nothing in the catalog gives its share to the losing one). */
  bands: Record<FuseBand, number>;
  ev: number;
  /** What can come out, cheapest and dearest. */
  min: number;
  max: number;
}

export const fuseMessage = (seed: string) => `fuse:${seed}`;

const normalize = (w: number[]) => {
  const total = w.reduce((s, x) => s + x, 0);
  return w.map((x) => x / total);
};
const mean = (items: readonly { price: number }[], p: readonly number[]) => items.reduce((s, b, i) => s + b.price * p[i]!, 0);

/**
 * Who can come out of a fuse worth `stake`, with what chance. Null when nothing in the catalog is worth the stake
 * or more (the machine would only ever give less).
 */
export function fuseTable(stake: number, catalog: readonly { id: string; price: number }[]): FuseTable | null {
  if (!(stake > 0)) return null;
  const items = catalog.filter((b) => b.price > 0).sort((a, b) => a.price - b.price || a.id.localeCompare(b.id));
  const okup = items.filter((b) => b.price >= stake && b.price < stake * 1.5);
  const big = items.filter((b) => b.price >= stake * 1.5 && b.price <= stake * 2);
  const below = items.filter((b) => b.price < stake);
  if ((!okup.length && !big.length) || !below.length) return null;

  // The losing range: from a quarter of the stake up; reach lower when the catalog is thin there.
  let from = below.findIndex((b) => b.price >= stake * LOSS_FLOOR);
  if (from < 0) from = below.length;
  while (from > 0 && (below.length - from < LOSS_MIN_ITEMS || below[from]!.price > stake * LOSS_REACH)) from--;
  const loss = below.slice(from);

  const wOkup = okup.length ? normalize(okup.map((b) => b.price ** -PROFIT_EXP)) : [];
  const wBig = big.length ? normalize(big.map((b) => b.price ** -PROFIT_EXP)) : [];
  const eOkup = mean(okup, wOkup);
  const eBig = mean(big, wBig);
  const lossWeights = (a: number) => normalize(loss.map((b) => (b.price / stake) ** a));
  const eLoss = (a: number) => mean(loss, lossWeights(a));

  let pOkup = okup.length ? FUSE_BANDS[1].share : 0;
  let pBig = big.length ? FUSE_BANDS[2].share : 0;
  const target = stake * FUSE_RTP;
  const need = (target - pOkup * eOkup - pBig * eBig) / (1 - pOkup - pBig);
  const low = eLoss(-LOSS_EXP);
  let a: number;
  if (need <= low) {
    // Even the cheapest losses keep the average too high: part of the profitable share goes to the losing range.
    a = -LOSS_EXP;
    const k = Math.max(0, Math.min(1, (target - low) / (pOkup * (eOkup - low) + pBig * (eBig - low))));
    pOkup *= k;
    pBig *= k;
  } else if (need >= eLoss(LOSS_EXP)) {
    a = LOSS_EXP; // the catalog can't reach the target: the average stays below it
  } else {
    let lo = -LOSS_EXP;
    let hi = LOSS_EXP;
    for (let i = 0; i < 60; i++) {
      const mid = (lo + hi) / 2;
      if (eLoss(mid) < need) lo = mid;
      else hi = mid;
    }
    a = lo;
  }
  const pLoss = 1 - pOkup - pBig;
  const wLoss = lossWeights(a);
  const candidates: FuseCandidate[] = [
    ...loss.map((b, i) => ({ id: b.id, price: b.price, band: 'loss' as const, p: pLoss * wLoss[i]! })),
    ...okup.map((b, i) => ({ id: b.id, price: b.price, band: 'okup' as const, p: pOkup * wOkup[i]! })),
    ...big.map((b, i) => ({ id: b.id, price: b.price, band: 'big' as const, p: pBig * wBig[i]! })),
  ].filter((c) => c.p > 0);
  return {
    stake,
    candidates,
    bands: { loss: pLoss, okup: pOkup, big: pBig },
    ev: candidates.reduce((s, c) => s + c.p * c.price, 0),
    min: candidates[0]!.price,
    max: candidates[candidates.length - 1]!.price,
  };
}

/** The brainrot a key gives: u1 picks the range, u2 the brainrot inside it. */
export function pickFuse(table: FuseTable, hex: string): FuseCandidate {
  const u1 = parseInt(hex.slice(0, 8), 16) / 2 ** 32;
  const u2 = parseInt(hex.slice(8, 16), 16) / 2 ** 32;
  let band: FuseBand = 'loss';
  let acc = 0;
  for (const b of FUSE_BANDS) {
    if (table.bands[b.id] <= 0) continue;
    band = b.id;
    acc += table.bands[b.id];
    if (u1 < acc) break;
  }
  const inBand = table.candidates.filter((c) => c.band === band);
  const total = inBand.reduce((s, c) => s + c.p, 0);
  let x = u2 * total;
  for (const c of inBand) {
    x -= c.p;
    if (x < 0) return c;
  }
  return inBand[inBand.length - 1]!;
}

/** «x0.44 · −56 % к ставке» for the result card. */
export function fuseOutcome(stake: number, value: number) {
  const multiplier = floor2(value / stake);
  return { multiplier, percent: round2(((value - stake) / stake) * 100) };
}

export interface FuseResult {
  stakeValue: number;
  brainrotId: string;
  itemId: number;
  value: number;
  multiplier: number;
  seed: string;
  hash: string;
  nextHash: string;
}

export interface FuseState {
  nextHash: string;
  mine: { from: string[]; brainrotId: string; stakeValue: number; value: number; at: number }[];
  top: { name: string; brainrotId: string; stakeValue: number; value: number; multiplier: number; at: number }[];
}
