#!/usr/bin/env bash
# Blender for Claude Code: installs Blender LTS from blender.org (checksum-verified), the MCP for Blender add-on
# (github.com/ahujasid/blender-mcp, pinned) and starts Blender on a virtual screen (Xvfb :99) with the add-on's
# bridge on localhost:9876. The MCP server itself is `uvx mcp-for-blender` from .mcp.json.
# The add-on refuses `blender -b` (its commands run on the UI timer), hence the virtual screen.
# Cloud containers are fresh every session: the SessionStart hook in .claude/settings.json runs this.
# Usage: scripts/blender/setup.sh            install + start, wait for the bridge
#        scripts/blender/setup.sh --background  the same, detached (for the hook)
set -euo pipefail

BLENDER_VERSION=5.2.2
BLENDER_SERIES=5.2
ADDON_COMMIT=5a3618fccb2d982d0dd61e7a1879912c3100073b # matches mcp-for-blender 2.2.2 on PyPI
PREFIX=/opt/blender-$BLENDER_VERSION-linux-x64
PORT=9876
DISPLAY_NUM=:99
LOG=/tmp/blender-mcp.log

if [[ "${1:-}" == "--background" ]]; then
  nohup "$0" >>"$LOG" 2>&1 &
  exit 0
fi

listening() { (exec 3<>"/dev/tcp/127.0.0.1/$PORT") 2>/dev/null; }

if [[ ! -x $PREFIX/blender ]]; then
  echo "Installing Blender $BLENDER_VERSION LTS…"
  tmp=$(mktemp -d)
  tarball=blender-$BLENDER_VERSION-linux-x64.tar.xz
  base=https://download.blender.org/release/Blender$BLENDER_SERIES
  curl -fsSL -o "$tmp/$tarball" "$base/$tarball"
  (cd "$tmp" && curl -fsSL "$base/blender-$BLENDER_VERSION.sha256" | grep " $tarball\$" | sha256sum -c -)
  tar -xf "$tmp/$tarball" -C /opt
  rm -rf "$tmp"
fi
ln -sfn "$PREFIX/blender" /usr/local/bin/blender

addons="$HOME/.config/blender/$BLENDER_SERIES/scripts/addons"
if [[ ! -f $addons/blender_mcp.py ]]; then
  mkdir -p "$addons"
  curl -fsSL -o "$addons/blender_mcp.py" "https://raw.githubusercontent.com/ahujasid/blender-mcp/$ADDON_COMMIT/addon.py"
fi

if listening; then
  echo "Blender MCP bridge already on :$PORT"
  exit 0
fi

pgrep -f "Xvfb $DISPLAY_NUM" >/dev/null || { Xvfb "$DISPLAY_NUM" -screen 0 1920x1080x24 -nolisten tcp >/dev/null 2>&1 & }
sleep 1
# The add-on's update check phones home on start; not needed here.
DISPLAY=$DISPLAY_NUM BLENDERMCP_NO_UPDATE_CHECK=1 nohup blender --addons blender_mcp >>"$LOG" 2>&1 &

for _ in $(seq 1 90); do
  if listening; then
    echo "Blender $BLENDER_VERSION is up, MCP bridge on :$PORT"
    exit 0
  fi
  sleep 1
done
echo "Blender did not open the MCP bridge on :$PORT — see $LOG" >&2
exit 1
