-- «LIVE» on the home page reads the newest winning drops of everyone.
CREATE INDEX drops_live ON drops (id DESC) WHERE result = 'win' AND brainrot_id IS NOT NULL;
