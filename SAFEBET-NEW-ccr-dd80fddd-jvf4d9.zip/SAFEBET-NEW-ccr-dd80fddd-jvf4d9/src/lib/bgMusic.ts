import { useSyncExternalStore } from 'react';
import { SOUND_EVENT, isMuted as soundsOff } from './sound';
import { tacosMusic } from './tacosMusic';

/**
 * Background music (iteration 33): two CC0 tracks from OpenGameArt on a loop — «The Arplands» by LordZintick (upbeat
 * 8-bit) and a lofi loop by omfgdude (public/music, loudness-matched with ffmpeg). On by default, its own switch in
 * Настройки; quiet when the app's sounds are off, in the background, during the «Щелчок» cutscene and while the
 * Raining Tacos track has the stage. Browsers refuse sound before the first touch, so it starts on the first tap.
 */
const KEY = 'brainrotcrash:music';
const PLAYLIST = ['/music/arplands.mp3', '/music/champloo-loop.mp3', '/music/champloo-loop.mp3', '/music/champloo-loop.mp3'];
const VOLUME = 0.28;

function readOn(): boolean {
  try {
    return localStorage.getItem(KEY) !== '0';
  } catch {
    return true;
  }
}

let on = readOn();
let held = false;
let track = 0;
let audio: HTMLAudioElement | null = null;
let armed = false;
let started = false;
const listeners = new Set<() => void>();
const emit = () => listeners.forEach((l) => l());

function element(): HTMLAudioElement {
  if (audio) return audio;
  audio = new Audio(PLAYLIST[track]);
  audio.preload = 'none';
  audio.volume = VOLUME;
  audio.addEventListener('ended', () => {
    track = (track + 1) % PLAYLIST.length;
    audio!.src = PLAYLIST[track]!;
    sync();
  });
  return audio;
}

const GESTURES = ['click', 'touchend', 'keydown'] as const;

function armGesture() {
  if (armed) return;
  armed = true;
  const go = () => {
    armed = false;
    GESTURES.forEach((g) => window.removeEventListener(g, go, true));
    sync();
  };
  GESTURES.forEach((g) => window.addEventListener(g, go, true));
}

function sync() {
  if (!started) return;
  const should = on && !held && !soundsOff() && !tacosMusic.audible() && document.visibilityState === 'visible';
  if (should) {
    const a = element();
    if (a.paused) a.play().catch(() => armGesture());
  } else if (audio && !audio.paused) {
    audio.pause();
  }
}

export const bgMusic = {
  /** Once, when the app opens: from here on it plays whenever it may (after the first tap at the latest). */
  start() {
    if (started) return;
    started = true;
    document.addEventListener('visibilitychange', sync);
    window.addEventListener(SOUND_EVENT, sync);
    tacosMusic.subscribe(sync);
    sync();
  },
  /** The snap cutscene plays: keep quiet. */
  hold(value: boolean) {
    held = value;
    sync();
  },
  set(value: boolean) {
    on = value;
    try {
      localStorage.setItem(KEY, value ? '1' : '0');
    } catch {
      // Won't persist; fine.
    }
    emit();
    sync();
  },
};

export function useBgMusic(): boolean {
  return useSyncExternalStore(
    (l) => {
      listeners.add(l);
      return () => listeners.delete(l);
    },
    () => on,
  );
}
