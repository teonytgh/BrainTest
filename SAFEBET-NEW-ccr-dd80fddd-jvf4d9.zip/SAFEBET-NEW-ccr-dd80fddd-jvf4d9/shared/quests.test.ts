import { describe, expect, it } from 'vitest';
import { DAILY_COUNT, TICKETS_PER_B, WEEKLY_COUNT, buildQuestSet, type QuestCase } from './quests';

const CASES: QuestCase[] = [
  { id: 'a', name: 'Нубини', price: 19, image: '/a.webp' },
  { id: 'b', name: 'Тако', price: 87, image: '/b.webp' },
  { id: 'c', name: 'Драгон', price: 208, image: '/c.webp' },
  { id: 'd', name: 'Семми', price: 150, image: '/d.webp' },
  { id: 'e', name: 'Лаки', price: 499, image: '/e.webp' },
];

describe('rotating quests', () => {
  it('the same day always gives the same set, whatever order the catalog comes in', () => {
    expect(buildQuestSet('daily', 20_400, CASES)).toEqual(buildQuestSet('daily', 20_400, [...CASES].reverse()));
    expect(buildQuestSet('weekly', 2_900, CASES)).toEqual(buildQuestSet('weekly', 2_900, CASES));
  });

  it('a new set every day: over two weeks the daily quests change', () => {
    const sets = new Set(Array.from({ length: 14 }, (_, i) => JSON.stringify(buildQuestSet('daily', 20_400 + i, CASES).map((q) => q.name))));
    expect(sets.size).toBeGreaterThan(10);
  });

  it('3 daily quests on 3 different games, the first one a case; 4 weekly with two cases and the net deposit', () => {
    for (let i = 0; i < 30; i++) {
      const d = buildQuestSet('daily', 20_000 + i, CASES);
      expect(d).toHaveLength(DAILY_COUNT);
      expect(d.map((q) => q.id)).toEqual(['d0', 'd1', 'd2']);
      expect(d[0]!.type).toBe('case_open');
      expect(new Set(d.map((q) => q.game)).size).toBe(DAILY_COUNT);
      const w = buildQuestSet('weekly', 2_000 + i, CASES);
      expect(w).toHaveLength(WEEKLY_COUNT);
      expect(w.filter((q) => q.type === 'case_open')).toHaveLength(2);
      expect(w[0]!.caseId).not.toBe(w[1]!.caseId);
      expect(w.some((q) => q.type === 'deposit')).toBe(true);
    }
  });

  it('rewards are 30 % of the house edge on the turnover asked for (in tickets)', () => {
    for (let i = 0; i < 30; i++) {
      for (const q of [...buildQuestSet('daily', 21_000 + i, CASES), ...buildQuestSet('weekly', 3_000 + i, CASES)]) {
        if (q.type === 'case_open') {
          const price = CASES.find((c) => c.id === q.caseId)!.price;
          expect(q.reward).toBe(Math.max(3, Math.round(0.3 * price * q.target)));
        }
        if (q.type === 'turnover') expect(q.reward).toBe(Math.max(3, Math.round(TICKETS_PER_B[q.game!] * q.target)));
        if (q.type === 'plays') expect(q.reward).toBe(Math.max(3, Math.round(TICKETS_PER_B[q.game!] * q.target * q.minStake!)));
      }
    }
    // The owner's example: opening a ~77 B case pays 23 tickets.
    const one = buildQuestSet('daily', 1, [{ id: 'x', name: 'Сикс Севен', price: 77, image: '' }]);
    expect(one[0]!.reward).toBe(23);
  });

  it('no paid cases at all: the case quests are left out instead of breaking', () => {
    expect(buildQuestSet('daily', 5, [])).toHaveLength(DAILY_COUNT);
    expect(buildQuestSet('weekly', 5, []).some((q) => q.type === 'case_open')).toBe(false);
  });
});
