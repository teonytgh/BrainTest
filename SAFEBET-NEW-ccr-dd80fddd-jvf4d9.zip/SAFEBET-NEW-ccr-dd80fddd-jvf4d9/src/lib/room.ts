/**
 * A multiplayer room's socket (/api/room, a GameRoom Durable Object): raw messages in, JSON out, a keep-alive ping
 * and reconnects with a fresh ticket. «Игра Кальмара» uses it as is; «Небо Meowl» has its own (src/lib/sky/net.ts).
 */
export class RoomSocketClient {
  private ws: WebSocket | null = null;
  private stopped = false;
  private backoff = 1000;
  private retry: ReturnType<typeof setTimeout> | undefined;
  private ping: ReturnType<typeof setInterval> | undefined;

  constructor(
    private ticket: () => Promise<string | null>,
    private onMessage: (msg: Record<string, unknown>) => void,
    private onStatus: (open: boolean) => void = () => {},
  ) {}

  async connect(first?: string | null) {
    if (this.stopped) return;
    let t = first ?? null;
    try {
      t ??= await this.ticket();
    } catch {
      return this.schedule();
    }
    if (!t || this.stopped) return;
    const proto = location.protocol === 'https:' ? 'wss' : 'ws';
    const ws = new WebSocket(`${proto}://${location.host}/api/room?t=${encodeURIComponent(t)}`);
    this.ws = ws;
    ws.onopen = () => {
      this.backoff = 1000;
      this.onStatus(true);
      clearInterval(this.ping);
      this.ping = setInterval(() => ws.readyState === WebSocket.OPEN && ws.send('ping'), 25_000);
    };
    ws.onmessage = (ev) => {
      if (typeof ev.data !== 'string' || ev.data === 'pong') return;
      try {
        this.onMessage(JSON.parse(ev.data));
      } catch {
        // Not ours.
      }
    };
    ws.onclose = () => {
      clearInterval(this.ping);
      this.onStatus(false);
      if (this.ws === ws) this.ws = null;
      this.schedule();
    };
  }

  private schedule() {
    if (this.stopped || this.retry) return;
    this.retry = setTimeout(
      () => {
        this.retry = undefined;
        void this.connect();
      },
      this.backoff * (0.5 + Math.random()),
    );
    this.backoff = Math.min(this.backoff * 2, 15_000);
  }

  send(msg: unknown) {
    if (this.ws?.readyState === WebSocket.OPEN) this.ws.send(JSON.stringify(msg));
  }

  close() {
    this.stopped = true;
    clearTimeout(this.retry);
    clearInterval(this.ping);
    this.ws?.close(1000);
  }
}
