import { describe, expect, it } from 'vitest';
import { DEFAULT_WITHDRAW_RULES, exchangeOffers, inStock, parseMskDate, withdrawBlock, withdrawProblem } from './withdraw';

const G = { name: 'Garama and Madundung', price: 45, withdrawable: true };

describe('withdrawal rules', () => {
  it('100 B or 2 brainrots', () => {
    expect(withdrawProblem([G], DEFAULT_WITHDRAW_RULES)).toContain('2 × Garama and Madundung');
    expect(withdrawProblem([G, G], DEFAULT_WITHDRAW_RULES)).toBeNull();
    expect(withdrawProblem([{ name: 'Big', price: 100 }], DEFAULT_WITHDRAW_RULES)).toBeNull();
    expect(withdrawProblem([], DEFAULT_WITHDRAW_RULES)).not.toBeNull();
  });

  it('junk and closed brainrots are blocked', () => {
    expect(withdrawBlock(G, DEFAULT_WITHDRAW_RULES)).toBeNull();
    expect(withdrawBlock({ ...G, price: 44.99 }, DEFAULT_WITHDRAW_RULES)).toContain('Хлам');
    expect(withdrawBlock({ ...G, withdrawable: false }, DEFAULT_WITHDRAW_RULES)).not.toBeNull();
  });
});

describe('admin dates (Moscow time)', () => {
  // 18 Oct 2026, 12:00 MSK = 09:00 UTC.
  const now = Date.UTC(2026, 9, 18, 9, 0);
  it('reads «ДД.ММ ЧЧ:ММ», «ЧЧ:ММ» and full dates', () => {
    expect(parseMskDate('19.10 18:30', now)).toBe(Date.UTC(2026, 9, 19, 15, 30));
    expect(parseMskDate('18:30', now)).toBe(Date.UTC(2026, 9, 18, 15, 30));
    // Earlier today → tomorrow.
    expect(parseMskDate('09:15', now)).toBe(Date.UTC(2026, 9, 19, 6, 15));
    expect(parseMskDate('20.10.2026 00:05', now)).toBe(Date.UTC(2026, 9, 19, 21, 5));
  });
  it('refuses nonsense and far dates', () => {
    expect(parseMskDate('завтра', now)).toBeNull();
    expect(parseMskDate('31.02 10:00', now)).toBeNull();
    expect(parseMskDate('25:00', now)).toBeNull();
    expect(parseMskDate('18.12 10:00', now)).toBeNull();
  });
});

describe('exchange into brainrots in stock', () => {
  const stock = [
    { id: 'strawberry-elephant', price: 41600 },
    { id: 'dragon-cannelloni', price: 840 },
    { id: 'garama', price: 45 },
  ];
  it('2 × 55 B → 2 Garama + 20 B change', () => {
    const [best] = exchangeOffers(110, stock);
    expect(best).toEqual({ take: [{ brainrotId: 'garama', count: 2 }], total: 90, change: 20 });
  });
  it('1000 B → Dragon + Garamas closest, then one kind each', () => {
    const offers = exchangeOffers(1000, stock);
    expect(offers[0]).toEqual({ take: [{ brainrotId: 'dragon-cannelloni', count: 1 }, { brainrotId: 'garama', count: 3 }], total: 975, change: 25 });
    expect(offers).toContainEqual({ take: [{ brainrotId: 'dragon-cannelloni', count: 1 }], total: 840, change: 160 });
    // Within the 20-piece limit.
    expect(offers).toContainEqual({ take: [{ brainrotId: 'garama', count: 20 }], total: 900, change: 100 });
  });
  it('nothing fits below the cheapest one', () => {
    expect(exchangeOffers(40, stock)).toEqual([]);
  });
  it('in stock = active, switched on, not junk', () => {
    const list = inStock(
      [
        { id: 'a', price: 45, withdrawable: true, status: 'active' },
        { id: 'b', price: 40, withdrawable: true, status: 'active' },
        { id: 'c', price: 900, withdrawable: false, status: 'active' },
        { id: 'd', price: 900, withdrawable: true, status: 'hidden' },
      ],
      DEFAULT_WITHDRAW_RULES,
    );
    expect(list.map((b) => b.id)).toEqual(['a']);
  });
});
