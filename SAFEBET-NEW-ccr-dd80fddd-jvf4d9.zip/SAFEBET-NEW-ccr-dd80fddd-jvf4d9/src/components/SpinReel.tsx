import { useMemo, useRef, useState } from 'react';
import type { Brainrot } from '../../shared/types';
import { cx } from '../lib/format';
import { buildReel } from '../lib/reel';
import { tierOf } from '../lib/tier';
import { useReelSpin } from '../lib/useReelSpin';

const REEL_LENGTH = 48;
const WIN_INDEX = 40;
const STEP = 112;

interface Props {
  pool: { brainrot: Brainrot; weight: number }[];
  won: Brainrot;
  durationMs: number;
  /** Mystery cases keep every card a glowing «?» until the winner flips over. */
  mystery?: boolean;
  /** Only one of several simultaneous reels should click, or the ticks double up. */
  ticks?: boolean;
  onLanded?: () => void;
}

/** A horizontal case reel that spins once on mount and lands the given drop under the marker. */
export function SpinReel({ pool, won, durationMs, mystery, ticks = true, onLanded }: Props) {
  const viewport = useRef<HTMLDivElement>(null);
  const track = useRef<HTMLDivElement>(null);
  const marker = useRef<HTMLSpanElement>(null);
  const [landed, setLanded] = useState(false);
  const items = useMemo(() => buildReel(pool, REEL_LENGTH, WIN_INDEX, won), [won, pool]);

  useReelSpin({
    viewport,
    track,
    stage: viewport,
    marker,
    winIndex: WIN_INDEX,
    step: STEP,
    durationMs,
    running: true,
    ticks,
    onLanded: () => {
      setLanded(true);
      onLanded?.();
    },
  });

  return (
    <div className="reel reel--battle" ref={viewport}>
      <span className="reel__marker" ref={marker} aria-hidden="true" />
      <div className="reel__track" ref={track}>
        {items.map((b, i) => {
          const reveal = landed && i === WIN_INDEX;
          if (mystery && !reveal) {
            return (
              <div key={i} className="reel__card reel__card--mystery" aria-hidden="true">
                <span className="reel__q">?</span>
              </div>
            );
          }
          return (
            <div key={i} data-tier={tierOf(b.price)} className={cx('reel__card', `tier-${tierOf(b.price)}`, reveal && 'is-won', reveal && mystery && 'is-flipped')}>
              <img src={b.image} alt="" />
              <span>{b.name}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
}
