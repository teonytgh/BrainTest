import { floor2 } from './money';

/**
 * «Мины» — the classic 5×5 field on brainrot stakes (1–5, coins never). The player picks how many of the 25 tiles
 * hide a mine (3–24: the owner's floor — with fewer mines a tile pays next to nothing), then opens tiles one by one:
 * every clear tile raises the multiplier (the fewer the mines, the smaller each step), a mine burns the stake,
 * «Забрать» is there after the first tile.
 *
 * After k clear tiles with m mines the chance of having got that far is C(25−m, k) / C(25, k); the multiplier is
 * floor2(MINES_RTP / that chance), so wherever the player stops the house keeps 6 % (like «Дорога»). A tile whose
 * multiplier would pass MAX_MINES_MULT, or whose win would pass MAX_MINES_PAYOUT, is not offered: the win is taken.
 *
 * The mines come from the round's key, committed before the stake (its sha256 is shown first): the first m places of
 * a Fisher–Yates shuffle of tiles 0…24, step i drawing the first 32 bits of sha256("mines:" + key + ":" + i).
 * The key and every mine are shown when the round ends.
 */
export const MINES_TILES = 25;
export const MIN_MINES = 3;
export const MAX_MINES = 24;
export const MINES_RTP = 0.94;
export const MAX_MINES_MULT = 100;
export const MAX_MINES_PAYOUT = 25_000;
export const MAX_MINES_ITEMS = 5;
export const MIN_MINES_STAKE = 1;
/** Quick picks for the mine count. */
export const MINES_PRESETS = [3, 5, 10, 15, 24] as const;

/** Chance that k tiles in a row are clear with `mines` mines on the field. */
export function clearChance(mines: number, k: number): number {
  let p = 1;
  for (let i = 0; i < k; i++) p *= (MINES_TILES - mines - i) / (MINES_TILES - i);
  return p;
}

/** What leaving after k clear tiles pays; 0 before the first tile. */
export function minesMultiplier(mines: number, k: number): number {
  if (k <= 0) return 0;
  const p = clearChance(mines, k);
  return p > 0 ? floor2(MINES_RTP / p) : 0;
}

/** Can one more tile be opened? Not when the clear tiles are all open, nor past the multiplier or payout limit. */
export function nextPickProblem(mines: number, opened: number, stakeValue: number): 'end' | 'limit' | null {
  if (opened >= MINES_TILES - mines) return 'end';
  const m = minesMultiplier(mines, opened + 1);
  if (m > MAX_MINES_MULT || stakeValue * m > MAX_MINES_PAYOUT) return 'limit';
  return null;
}

export const minesMessage = (seed: string, step: number) => `mines:${seed}:${step}`;

/** The mined tiles for these digests (sha256 hex of minesMessage(key, i) for i = 0…mines−1), sorted. */
export function minesFromDigests(mines: number, digests: readonly string[]): number[] {
  const tiles = Array.from({ length: MINES_TILES }, (_, i) => i);
  for (let i = 0; i < mines; i++) {
    const u = parseInt(digests[i]!.slice(0, 8), 16) / 2 ** 32;
    const j = i + Math.floor(u * (MINES_TILES - i));
    [tiles[i], tiles[j]] = [tiles[j]!, tiles[i]!];
  }
  return tiles.slice(0, mines).sort((a, b) => a - b);
}

export interface MinesRun {
  id: number;
  mines: number;
  /** Clear tiles opened, in order. */
  picks: number[];
  status: 'active' | 'cashed' | 'busted' | 'refunded';
  /** The tile that blew up. */
  bust: number | null;
  stakeValue: number;
  stake: string[];
  /** What leaving now pays (0 before the first tile). */
  multiplier: number;
  next: { multiplier: number; problem: 'end' | 'limit' | null };
  hash: string;
  /** Shown when the round is over. */
  seed: string | null;
  minesAt: number[] | null;
  payout: { brainrotId: string | null; coins: number; itemId: number | null; value: number } | null;
}

export interface MinesState {
  nextHash: string;
  run: MinesRun | null;
  mine: { mines: number; picks: number; won: boolean; multiplier: number; value: number; stakeValue: number; at: number }[];
  top: { name: string; mines: number; picks: number; multiplier: number; value: number; brainrotId: string | null; at: number }[];
}
