import { OWNER_IDS } from './env';

/**
 * Admins and owners are not players (iteration 33): their drops stay out of LIVE and the top drop, they are not in
 * the player search, the player counts or the economy's «what players hold». They still play like anyone for tests.
 * `col` is the SQL expression holding a user id; the owners' ids are numbers from env.ts, so they go in as literals.
 */
export function notStaff(col: string): string {
  const owners = OWNER_IDS.map((id) => Math.trunc(Number(id))).join(', ');
  return `(NOT EXISTS (SELECT 1 FROM admins st WHERE st.user_id = ${col}) AND ${col} <> ALL(ARRAY[${owners}]::bigint[]))`;
}
