import { createHash } from 'node:crypto';
import { describe, expect, it } from 'vitest';
import { FUSE_RTP, fuseMessage, fuseOutcome, fuseTable, pickFuse } from './fuse';
import { SEED_BRAINROTS } from './seed';

const sha = (s: string) => createHash('sha256').update(s).digest('hex');
// Two of the cheapest seed brainrots (26 B) and up.
const STAKES = [52, 60, 90, 150, 300, 600, 1200, 2500, 5000, 9000, 14000];

describe('Haunted Fuse', () => {
  it('never gives more than x2, keeps 82 / 15 / 3 and averages 88 % of the stake', () => {
    for (const stake of STAKES) {
      const t = fuseTable(stake, SEED_BRAINROTS);
      expect(t, `stake ${stake}`).not.toBeNull();
      const total = t!.candidates.reduce((s, c) => s + c.p, 0);
      expect(total).toBeCloseTo(1, 9);
      expect(t!.max).toBeLessThanOrEqual(stake * 2);
      expect(t!.candidates.filter((c) => c.band === 'loss').every((c) => c.price < stake)).toBe(true);
      expect(t!.candidates.filter((c) => c.band !== 'loss').every((c) => c.price >= stake)).toBe(true);
      // The house never gives more than 88 % on average.
      expect(t!.ev / stake, `stake ${stake}`).toBeLessThanOrEqual(FUSE_RTP + 1e-9);
      if (t!.bands.okup > 0 && t!.bands.big > 0 && t!.ev / stake > FUSE_RTP - 0.005) {
        expect(t!.bands).toEqual({ loss: 0.82, okup: 0.15, big: 0.03 });
      }
    }
  });

  it('a dearer set can bring a dearer brainrot', () => {
    const small = fuseTable(60, SEED_BRAINROTS)!;
    const large = fuseTable(1200, SEED_BRAINROTS)!;
    expect(large.max).toBeGreaterThan(small.max);
    expect(large.min).toBeGreaterThan(small.min);
  });

  it('refuses a stake nothing in the catalog is worth', () => {
    const top = Math.max(...SEED_BRAINROTS.map((b) => b.price));
    expect(fuseTable(top + 1, SEED_BRAINROTS)).toBeNull();
    expect(fuseTable(0, SEED_BRAINROTS)).toBeNull();
  });

  it('the key decides the brainrot, and keys land in the ranges as often as promised', () => {
    const t = fuseTable(300, SEED_BRAINROTS)!;
    const k = sha(fuseMessage('abc'));
    expect(pickFuse(t, k)).toEqual(pickFuse(t, k));
    const counts = { loss: 0, okup: 0, big: 0 };
    let value = 0;
    const runs = 20000;
    for (let n = 0; n < runs; n++) {
      const c = pickFuse(t, sha(fuseMessage(String(n))));
      counts[c.band]++;
      value += c.price;
    }
    expect(Math.abs(counts.loss / runs - t.bands.loss)).toBeLessThan(0.012);
    expect(Math.abs(counts.okup / runs - t.bands.okup)).toBeLessThan(0.01);
    expect(Math.abs(counts.big / runs - t.bands.big)).toBeLessThan(0.006);
    expect(value / runs / 300).toBeLessThan(FUSE_RTP + 0.03);
  });

  it('describes the result against the stake', () => {
    expect(fuseOutcome(36, 16)).toEqual({ multiplier: 0.44, percent: -55.56 });
    expect(fuseOutcome(100, 150)).toEqual({ multiplier: 1.5, percent: 50 });
  });
});
