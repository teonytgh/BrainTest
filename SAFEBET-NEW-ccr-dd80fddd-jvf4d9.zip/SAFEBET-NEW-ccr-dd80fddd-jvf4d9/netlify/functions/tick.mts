import type { Config } from '@netlify/functions';
import { runTick } from '../../server/tick';

export default async () => {
  console.log('tick', JSON.stringify(await runTick()));
};

// Every minute (UTC): heal cases, expire trade windows, auto-open battles nobody joined, bot notifications.
export const config: Config = { schedule: '* * * * *' };
