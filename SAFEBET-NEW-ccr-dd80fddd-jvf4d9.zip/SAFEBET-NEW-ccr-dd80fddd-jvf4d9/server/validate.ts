import { bad } from './errors';

export type Body = Record<string, unknown>;

export function int(v: unknown, name: string, min = 1, max = Number.MAX_SAFE_INTEGER): number {
  const n = typeof v === 'string' && v.trim() !== '' ? Number(v) : v;
  if (typeof n !== 'number' || !Number.isInteger(n) || n < min || n > max) {
    throw bad('invalid', `Поле «${name}» должно быть целым числом от ${min} до ${max}`);
  }
  return n;
}

/** A coin amount: up to two decimals, "12,5" and "12.5" both accepted. */
export function money(v: unknown, name: string, min = 0.01, max = 100_000_000): number {
  const s = typeof v === 'number' ? String(v) : typeof v === 'string' ? v.trim().replace(',', '.') : '';
  const n = Number(s);
  if (!/^\d+(\.\d{1,2})?$/.test(s) || !Number.isFinite(n) || n < min || n > max) {
    throw bad('invalid', `Поле «${name}»: число от ${min} до ${max}, не больше двух знаков после запятой`);
  }
  return n;
}

export function robloxNick(v: unknown, name = 'ник в Roblox'): string {
  const nick = str(v, name, 3, 20).replace(/^@/, '');
  if (!/^[A-Za-z0-9_]{3,20}$/.test(nick)) throw bad('invalid', 'Ник в Roblox: латиница, цифры и _ (3–20 символов)');
  return nick;
}

export function str(v: unknown, name: string, min = 1, max = 200): string {
  if (typeof v !== 'string') throw bad('invalid', `Заполни поле «${name}»`);
  const s = v.trim();
  if (s.length < min || s.length > max) throw bad('invalid', `Поле «${name}»: от ${min} до ${max} символов`);
  return s;
}

export function optStr(v: unknown, name: string, max = 200): string | null {
  if (v === undefined || v === null || v === '') return null;
  return str(v, name, 0, max);
}

export function oneOf<T extends string>(v: unknown, name: string, options: readonly T[]): T {
  if (typeof v !== 'string' || !options.includes(v as T)) throw bad('invalid', `Неверное значение поля «${name}»`);
  return v as T;
}

export function ids(v: unknown, name: string, max = 500): number[] {
  if (!Array.isArray(v) || v.length === 0 || v.length > max) throw bad('invalid', `Поле «${name}» должно быть списком`);
  return [...new Set(v.map((x) => int(x, name)))];
}

export function bool(v: unknown): boolean {
  return v === true;
}
