import { useEffect, useMemo, type CSSProperties } from 'react';
import { cx } from '../lib/format';
import { tacosMusic } from '../lib/tacosMusic';
import { useNow } from '../lib/useNow';
import { useEvents } from './Events';

const reducedMotion = () => typeof matchMedia === 'function' && matchMedia('(prefers-reduced-motion: reduce)').matches;

/** A detailed little taco: folded shell, meat, cheese, lettuce, tomato. */
export function Taco({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 64 56" className={cx('taco', className)} aria-hidden="true">
      <path d="M4 50c0-20 12-34 28-34s28 14 28 34z" fill="var(--taco-shell)" />
      <path d="M4 50c0-20 12-34 28-34s28 14 28 34z" fill="none" stroke="rgba(0,0,0,.18)" strokeWidth="1.5" />
      <path d="M9 34c6-3 10 2 15-1s9-5 15-3 9 6 16 3c-3-8-12-17-23-17S13 26 9 34z" fill="var(--taco-lettuce)" />
      <circle cx="22" cy="31" r="4" fill="var(--taco-tomato)" />
      <circle cx="42" cy="30" r="4" fill="var(--taco-tomato)" />
      <path d="M14 40c8 4 12 4 18 4s10 0 18-4c-2 6-9 9-18 9s-16-3-18-9z" fill="var(--taco-meat)" />
      <path d="M26 24l4 5-5 1zM38 26l5 3-5 2z" fill="var(--taco-cheese)" />
    </svg>
  );
}

/**
 * «Raining Tacos» over the whole app while the event runs: tacos fall over every page (never catching a tap) and the
 * track plays by itself (src/lib/tacosMusic.ts). No page of its own any more — the owner wanted it to be just the
 * event, everywhere. CSS transform/opacity only; no rain with reduced motion (the music still plays).
 */
export function TacosRain() {
  const now = useNow(1000);
  const on = useEvents(now).some((e) => e.id === 'tacos');

  useEffect(() => {
    tacosMusic.setWanted(on);
  }, [on]);
  useEffect(() => () => tacosMusic.setWanted(false), []);

  const count = on && !reducedMotion() ? 12 : 0;
  const drops = useMemo(
    () =>
      Array.from({ length: count }, (_, i) => ({
        key: i,
        style: {
          '--x': `${Math.round((i / count) * 100 + (Math.random() * 8 - 4))}%`,
          '--delay': `${(Math.random() * 7).toFixed(2)}s`,
          '--dur': `${(6 + Math.random() * 4).toFixed(2)}s`,
          '--scale': (0.5 + Math.random() * 0.45).toFixed(2),
          '--spin': `${Math.random() < 0.5 ? '' : '-'}${(120 + Math.random() * 240).toFixed(0)}deg`,
          '--sway': `${(10 + Math.random() * 26).toFixed(0)}px`,
        } as CSSProperties,
      })),
    [count],
  );
  if (!count) return null;
  return (
    <div className="tacos-sky" aria-hidden="true">
      {drops.map((d) => (
        <span key={d.key} className="tacos-drop" style={d.style}>
          <Taco />
        </span>
      ))}
    </div>
  );
}
