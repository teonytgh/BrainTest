import { useEffect, useState } from 'react';
import { useCatalog } from '../api/queries';
import { cx } from '../lib/format';
import { navigate, useRoute } from '../lib/router';
import { sfx } from '../lib/sound';
import { haptic } from '../lib/telegram';
import { useNow } from '../lib/useNow';

const SEEN_KEY = 'brainrotcrash:squid-seen';

function seen(): number {
  try {
    return Number(localStorage.getItem(SEEN_KEY)) || 0;
  } catch {
    return 0;
  }
}

/**
 * «Игра Кальмара» starts: every open app gets this invite at once (the `squid` setting rides with the live catalog)
 * and keeps it while the lobby is open — «Войти» or «Не сейчас» hides it for this game on this device.
 */
export function SquidInvite() {
  const game = useCatalog().squid;
  const route = useRoute();
  const now = useNow(1000);
  const [hidden, setHidden] = useState(seen);
  const open = !!game && game.lobbyUntil > now && hidden !== game.gameId && route.name !== 'squid';

  useEffect(() => {
    if (!open) return;
    sfx.eggAlert();
    haptic('select');
  }, [open]);

  if (!open || !game) return null;
  const dismiss = () => {
    setHidden(game.gameId);
    try {
      localStorage.setItem(SEEN_KEY, String(game.gameId));
    } catch {
      // Private mode: it shows again on the next open while the lobby lasts.
    }
  };
  const left = Math.max(0, Math.ceil((game.lobbyUntil - now) / 1000));
  return (
    <div className="squid-invite" role="alertdialog" aria-labelledby="squid-invite-title" aria-describedby="squid-invite-text">
      <img className="squid-invite__watcher" src="/squid/watcher-red.webp" alt="" />
      <div className="squid-invite__body">
        <b id="squid-invite-title">Игра Кальмара начинается!</b>
        <span id="squid-invite-text">
          4 испытания, призы за {game.prizes.length > 1 ? `первые ${game.prizes.length} места` : 'первое место'}. Вход ещё{' '}
          <span className={cx('squid-invite__time', left <= 30 && 'is-hot')}>
            {Math.floor(left / 60)}:{String(left % 60).padStart(2, '0')}
          </span>
        </span>
      </div>
      <div className="squid-invite__actions">
        <button
          type="button"
          className="btn btn--primary btn--sm"
          onClick={() => {
            dismiss();
            navigate('squid');
          }}
        >
          Войти
        </button>
        <button type="button" className="btn btn--ghost btn--sm" onClick={dismiss}>
          Не сейчас
        </button>
      </div>
    </div>
  );
}
