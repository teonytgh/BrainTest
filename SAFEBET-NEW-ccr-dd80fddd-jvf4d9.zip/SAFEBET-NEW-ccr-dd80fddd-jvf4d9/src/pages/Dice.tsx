import { useEffect, useRef, useState, type CSSProperties } from 'react';
import { BrainrotThumb } from '../components/BrainrotCard';
import { Coin } from '../components/Coin';
import { Icon } from '../components/Icon';
import { InventoryPicker } from '../components/InventoryPicker';
import { FastToggle } from '../components/Toggle';
import { errorMessage } from '../api/client';
import { act, holdMe, setMe, useCatalog, useMe, type Me } from '../api/queries';
import type { Brainrot } from '../../shared/types';
import { DICE_COLORS, DICE_COUNT, DICE_RULES, type DiceColorId } from '../../shared/dice';
import { payoutFor } from '../../shared/payout';
import { cx, formatCoins, sleep } from '../lib/format';
import { sfx } from '../lib/sound';
import { haptic } from '../lib/telegram';
import { toast } from '../store/toast';

const EMPTY_FACES: (DiceColorId | null)[] = Array(DICE_COUNT).fill(null);
/** One cube's roll (they go one after another). */
const DIE_MS = 1100;
const DIE_FAST_MS = 480;
const COLOR_LABEL = Object.fromEntries(DICE_COLORS.map((c) => [c.id, c.label])) as Record<DiceColorId, string>;

interface DiceResponse {
  faces: DiceColorId[];
  matches: number;
  multiplier: number;
  payout: { brainrotId: string | null; coins: number; itemId: number | null } | null;
}

export function Dice() {
  const me = useMe();
  const catalog = useCatalog();
  const [stakeUid, setStakeUid] = useState<number | null>(null);
  const [color, setColor] = useState<DiceColorId | null>(null);
  const [fast, setFast] = useState(false);
  const [pickerOpen, setPickerOpen] = useState(false);
  const [faces, setFaces] = useState(EMPTY_FACES);
  // The server's faces are known before the animation: each cube spins straight onto its colour.
  const [targets, setTargets] = useState(EMPTY_FACES);
  const [rollingIndex, setRollingIndex] = useState(-1);
  const [locked, setLocked] = useState<{ brainrot: Brainrot; color: DiceColorId } | null>(null);
  const [outcome, setOutcome] = useState<DiceResponse | null>(null);
  const [pending, setPending] = useState(false);
  const run = useRef(0);
  const unapplied = useRef<Me | null>(null);

  useEffect(
    () => () => {
      run.current++;
      // Leaving mid-roll: stop holding `me` and reveal the committed result.
      if (unapplied.current) setMe(unapplied.current);
      holdMe(false);
    },
    [],
  );

  const rolling = locked !== null;
  const busy = rolling || pending;
  const frozen = !!me.user.frozen;
  // A brainrot that got locked onto a withdrawal since it was picked is no longer a valid stake.
  const stakeItem = me.inventory.find((i) => i.id === stakeUid && !i.withdrawalId) ?? null;
  const stake = locked?.brainrot ?? (stakeItem ? catalog.byId.get(stakeItem.brainrotId) ?? null : null);
  const betColor = locked?.color ?? color;
  const ready = !frozen && !!stakeItem && !!color;

  /** Picking a new colour or stake drops the finished roll so nothing on screen contradicts the new choice. */
  function clearResult() {
    setOutcome(null);
    setFaces(EMPTY_FACES);
    setTargets(EMPTY_FACES);
  }

  async function roll() {
    if (busy || !stakeItem || !color) return;
    const brainrot = catalog.byId.get(stakeItem.brainrotId)!;
    // Claim the run before the await: if the player leaves while «Секунду…», the response is ignored.
    const id = ++run.current;
    setPending(true);
    let r;
    try {
      r = await act<DiceResponse>('/api/dice', { itemId: stakeItem.id, color });
    } catch (e) {
      if (run.current === id) {
        sfx.error();
        toast(errorMessage(e), 'error');
        setPending(false);
      }
      return;
    }
    if (run.current !== id) return;
    setPending(false);
    unapplied.current = r.me;
    // Hold `me` so the balance in the top bar can't jump to the post-roll value before the dice land.
    holdMe(true);
    const perDie = fast ? DIE_FAST_MS : DIE_MS;
    haptic('tap');
    setLocked({ brainrot, color });
    setStakeUid(null);
    clearResult();
    setTargets(r.result.faces);

    for (let i = 0; i < r.result.faces.length; i++) {
      setRollingIndex(i);
      await sleep(perDie);
      if (run.current !== id) return;
      const face = r.result.faces[i]!;
      setFaces((f) => f.map((v, j) => (j === i ? face : v)));
      sfx.land();
      haptic('tap');
    }
    setRollingIndex(-1);
    await sleep(fast ? 150 : 400);
    if (run.current !== id) return;
    unapplied.current = null;
    setMe(r.me);
    holdMe(false);
    setLocked(null);
    setOutcome(r.result);
    if (r.result.multiplier === 3) sfx.bigWin();
    else if (r.result.multiplier) sfx.win();
    else sfx.lose();
    haptic(r.result.multiplier ? 'success' : 'error');
  }

  const hint = frozen
    ? 'Аккаунт заморожен — играть нельзя'
    : !stake && !color
      ? 'Выбери цвет и брейнрота для ставки'
      : !stake
        ? 'Выбери брейнрота для ставки'
        : !color
          ? 'Выбери цвет'
          : null;

  function describe(o: DiceResponse): string {
    if (!o.payout) return `Совпадений: ${o.matches} — проигрыш`;
    const name = o.payout.brainrotId ? catalog.byId.get(o.payout.brainrotId)?.name : null;
    const parts = [name, o.payout.coins ? `${formatCoins(o.payout.coins)} B` : null].filter(Boolean);
    return `x${o.multiplier}! Получено: ${parts.join(' + ')}`;
  }

  return (
    <section className="game dice" aria-labelledby="dice-title">
      <div className="dice__board">
        <h1 id="dice-title" className="page-title page-title--center dice__title">
          Колор дайс
        </h1>
        <p className="dice__sub">
          <span className="badge badge--outline">{DICE_COUNT} дайса</span>
        </p>

        <div className="dice__controls">
          <button type="button" className="select" onClick={() => setPickerOpen(true)} disabled={busy}>
            {stake ? (
              <>
                <BrainrotThumb brainrot={stake} size={30} />
                <span className="select__text">{stake.name}</span>
                <span className="select__price">
                  <Coin size={13} /> {formatCoins(stake.price)}
                </span>
              </>
            ) : (
              <span className="select__text">Выбрать ставку</span>
            )}
            <Icon name="chevronDown" size={18} />
          </button>
          <FastToggle on={fast} onChange={setFast} disabled={busy} />
        </div>

        <div className="dice__row" aria-label="Кубики">
          {faces.map((face, i) => (
            <DiceTile
              key={i}
              index={i}
              face={face}
              target={targets[i] ?? null}
              rolling={rollingIndex === i}
              duration={fast ? DIE_FAST_MS : DIE_MS}
              match={!!face && face === betColor}
            />
          ))}
        </div>

        <div className="dice__colors" role="radiogroup" aria-label="Цвет ставки">
          {DICE_COLORS.map((c) => (
            <button
              key={c.id}
              type="button"
              role="radio"
              aria-checked={color === c.id}
              aria-label={c.label}
              className={cx('swatch', color === c.id && 'is-selected')}
              style={{ '--swatch': `var(--dice-${c.id})` } as CSSProperties}
              disabled={busy}
              onClick={() => {
                sfx.tap();
                setColor(c.id);
                clearResult();
              }}
            >
              {color === c.id && <Icon name="check" size={20} />}
            </button>
          ))}
        </div>

        <button type="button" className="btn btn--primary btn--lg btn--block" disabled={!!hint || busy} onClick={roll}>
          {rolling ? 'Крутим…' : pending ? 'Секунду…' : outcome && ready ? 'Бросить ещё раз' : 'Бросить'}
        </button>
        <p className="hint">{hint ?? (fast ? 'Быстрый режим' : `Ставка на ${COLOR_LABEL[color!].toLowerCase()}`)}</p>

        {stake && !rolling && !outcome && <PayoutPreview price={stake.price} catalog={catalog.active} />}

        <p className={cx('result-line', outcome && (outcome.multiplier ? 'is-win' : 'is-lose'))} role="status">
          {outcome ? describe(outcome) : ' '}
        </p>
      </div>

      <div className="dice__rules">
        <h2 className="section-title">Правила игры</h2>
        <ol className="rules">
          {DICE_RULES.map((r) => (
            <li key={r.matches} className={cx('rules__row', r.multiplier ? 'is-win' : 'is-lose', outcome?.matches === r.matches && 'is-current')}>
              <span className="rules__count">
                {r.matches}/{DICE_COUNT}
              </span>
              <span className="rules__text">{r.multiplier ? `выигрыш x${r.multiplier}` : 'проигрыш'}</span>
            </li>
          ))}
        </ol>
        <p className="hint hint--left">Кубики крутятся по очереди. Выигрыш выдаётся брейнротом ближайшей цены, остаток — монетами.</p>
      </div>

      <InventoryPicker
        open={pickerOpen}
        onClose={() => setPickerOpen(false)}
        onPick={(i) => {
          setStakeUid(i.id);
          clearResult();
        }}
        selectedUid={stakeUid}
      />
    </section>
  );
}

function PayoutPreview({ price, catalog }: { price: number; catalog: Brainrot[] }) {
  return (
    <ul className="preview">
      {[2, 3].map((m) => {
        const p = payoutFor(price * m, catalog);
        return (
          <li key={m}>
            <span className="preview__mult">x{m}</span>
            <span className="preview__value">
              {p.brainrot?.name ?? 'монеты'}
              {p.coins > 0 && (
                <>
                  {' '}+ <Coin size={12} /> {formatCoins(p.coins)}
                </>
              )}
            </span>
          </li>
        );
      })}
    </ul>
  );
}

/** Which way the cube turns to show each colour in front (faces: front, right, back, left, top, bottom). */
const FACE_TURN: Record<DiceColorId, readonly [number, number]> = {
  red: [0, 0],
  orange: [0, -90],
  yellow: [0, 180],
  green: [0, 90],
  blue: [-90, 0],
  purple: [90, 0],
};
const FACE_SIDE: Record<DiceColorId, string> = { red: 'front', orange: 'right', yellow: 'back', green: 'left', blue: 'top', purple: 'bottom' };
/** A resting cube shows three faces at an angle. */
const IDLE_TURN: readonly [number, number] = [-24, 34];

/**
 * A 3D cube with the six colours on its faces. While it rolls it hops and spins several full turns, easing
 * out exactly onto the server's colour; an empty slot rests pale at an angle.
 */
function DiceTile({ face, target, rolling, match, index, duration }: { face: DiceColorId | null; target: DiceColorId | null; rolling: boolean; match: boolean; index: number; duration: number }) {
  const spins = useRef(0);
  const [turn, setTurn] = useState<readonly [number, number]>(IDLE_TURN);

  useEffect(() => {
    if (!rolling || !target) return;
    // Every roll keeps spinning forward (no rewinding) and the dice don't all turn alike.
    spins.current += 2 + (index % 2);
    const [x, y] = FACE_TURN[target];
    setTurn([x + 360 * spins.current, y + 360 * (spins.current + (index % 3))]);
    const tick = setInterval(() => sfx.tick(), 85);
    const stop = setTimeout(() => clearInterval(tick), duration * 0.7);
    return () => {
      clearInterval(tick);
      clearTimeout(stop);
    };
  }, [rolling, target, index, duration]);

  // Cleared for the next roll (no face, not yet spinning): rest at the idle angle instead of freezing on the
  // previous roll's colour. A landed cube keeps the angle that shows its colour.
  useEffect(() => {
    if (!rolling && !face) {
      spins.current = 0;
      setTurn(IDLE_TURN);
    }
  }, [rolling, face]);

  const label = `Кубик ${index + 1}: ${face ? COLOR_LABEL[face] : rolling ? 'крутится' : 'пусто'}`;
  // The CSS vars live on the outer `.die` so the hop, the shadow and the match glow (all siblings/ancestors of
  // the cube) can read them; only the live rotation stays on the cube itself.
  const dieStyle = {
    '--die-ms': `${duration}ms`,
    '--glow': face ? `var(--dice-${face})` : 'transparent',
  } as CSSProperties;
  const cubeStyle = { transform: `rotateX(${turn[0]}deg) rotateY(${turn[1]}deg)` } as CSSProperties;

  return (
    <div
      className={cx('die', rolling && 'is-rolling', !face && !rolling && 'is-idle', face && !rolling && 'is-landed', match && 'is-match')}
      style={dieStyle}
      role="img"
      aria-label={label}
    >
      <span className="die__shadow" aria-hidden="true" />
      <span className="die__hop" aria-hidden="true">
        <span className="die__cube" style={cubeStyle}>
          {DICE_COLORS.map((c) => (
            <span key={c.id} className={`die__face die__face--${FACE_SIDE[c.id]}`} style={{ '--c': `var(--dice-${c.id})` } as CSSProperties} />
          ))}
        </span>
      </span>
    </div>
  );
}
