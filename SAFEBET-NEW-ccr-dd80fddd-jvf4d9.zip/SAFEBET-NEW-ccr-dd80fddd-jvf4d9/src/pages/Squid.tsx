import { useQuery } from '@tanstack/react-query';
import { useEffect, useMemo, useReducer, useRef, useState, type PointerEvent as ReactPointerEvent } from 'react';
import { BrainrotThumb } from '../components/BrainrotCard';
import { Coin } from '../components/Coin';
import { Icon } from '../components/Icon';
import { api } from '../api/client';
import { queryClient, useCatalog, useMe } from '../api/queries';
import {
  COOKIE_MAX_SPEED,
  COOKIE_TOLERANCE,
  COOKIE_SHAPE_NAME,
  LIGHT_FIELD,
  LIGHT_SPEED,
  NIGHT_COOLDOWN_MS,
  NIGHT_HP,
  NIGHT_RADIUS,
  NIGHT_SPEED,
  SQUID_STAGE,
  SQUID_STAGES,
  cookieOutline,
  outlineDistance,
  type BridgeSide,
  type CookieShape,
  type SquidGameView,
  type SquidPhase,
  type SquidPrize,
  type SquidStage,
} from '../../shared/squid';
import { cx, formatCoins } from '../lib/format';
import { RoomSocketClient } from '../lib/room';
import { sfx } from '../lib/sound';
import { haptic } from '../lib/telegram';
import { openSheet } from '../store/ui';
import '../styles/squid.css';

/**
 * «Игра Кальмара» (iteration 35): the lobby, the four stages and the results, all driven by the room (the referee).
 * The app sends input only and shows what the room says; its own runner / fighter is predicted locally so it feels
 * immediate, and corrected when the room disagrees.
 */

interface StateView {
  game: SquidGameView | null;
  block?: string | null;
  ticket?: string | null;
  serverNow?: number;
}

interface Bridge {
  order: number[];
  turn: number;
  walker: number | null;
  at: number;
  known: (BridgeSide | null)[];
  ends: number;
}

interface Game {
  me: number;
  phase: SquidPhase;
  /** The phase's clock; Infinity for a stage without one (it ends when everyone is through). */
  ends: number;
  /** When the phase began (the candy's trace times count from it). */
  start: number;
  next: SquidStage | null;
  spectator: boolean;
  players: Map<number, { name: string; alive: boolean }>;
  green: boolean;
  lightUntil: number;
  prog: Map<number, number>;
  night: Map<number, { x: number; y: number; hp: number; tx: number; ty: number }>;
  cookie: { shape: CookieShape | null; cover: number; done: boolean };
  bridge: Bridge | null;
  broken: Map<number, BridgeSide>;
  places: number[];
  out: Map<number, string>;
  passed: Set<number>;
  feed: { id: number; text: string; at: number }[];
  swings: Map<number, number>;
  hits: { to: number; dmg: number; at: number }[];
  connected: boolean;
}

const STAGE_NO: Record<SquidStage, number> = { light: 1, night: 2, cookie: 3, bridge: 4 };
const OUT_WHY: Record<string, string> = {
  moved: 'двинулся на красный',
  'idle-light': 'уснул — стоял на зелёном',
  'idle-cookie': 'соты засохли — долго не вёл',
  gone: 'вышел из игры',
  time: 'не успел',
  hp: 'кончились HP',
  off: 'соты треснули — мимо линии',
  fast: 'соты треснули — слишком быстро',
  fell: 'стекло разбилось',
};

/** The room sends null for a stage without a clock. */
const endsOf = (v: unknown) => (v === null || v === undefined ? Number.POSITIVE_INFINITY : Number(v));

/** What the top bar shows instead of a clock while a stage waits for everyone. */
function stageProgress(g: Game): string | null {
  const alive = [...g.players.values()].filter((p) => p.alive).length;
  if (g.phase === 'light') return `Добежали ${g.passed.size} из ${alive}`;
  if (g.phase === 'cookie') return `Вырезали ${g.passed.size} из ${alive}`;
  if (g.phase === 'bridge') return `Перешли ${g.places.length}`;
  return null;
}

const clock = (ms: number) => {
  const s = Math.max(0, Math.ceil(ms / 1000));
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
};

function newGame(me: number): Game {
  return {
    me,
    phase: 'lobby',
    ends: 0,
    start: 0,
    next: null,
    spectator: false,
    players: new Map(),
    green: true,
    lightUntil: 0,
    prog: new Map(),
    night: new Map(),
    cookie: { shape: null, cover: 0, done: false },
    bridge: null,
    broken: new Map(),
    places: [],
    out: new Map(),
    passed: new Set(),
    feed: [],
    swings: new Map(),
    hits: [],
    connected: false,
  };
}

export function Squid() {
  const catalog = useCatalog();
  const game = catalog.squid ?? null;
  const state = useQuery({
    queryKey: ['squid', game?.gameId ?? 0],
    queryFn: () => api<StateView>('/api/squid'),
    enabled: !!game,
    staleTime: 5_000,
  });
  const mine = useQuery({
    queryKey: ['squid-mine'],
    queryFn: () => api<{ place: number | null; outStage: string | null; prize: SquidPrize | null } | null>('/api/squid/mine'),
    enabled: !game,
  });
  const data = state.data;
  // The lobby closed for a player who couldn't join: ask again for a pass to watch.
  useEffect(() => {
    if (!game || data?.ticket || !data) return;
    const t = setTimeout(() => void state.refetch(), Math.max(1000, game.lobbyUntil - Date.now() + 500));
    return () => clearTimeout(t);
  }, [game, data, state]);

  if (!game) {
    return (
      <div className="squid-page">
        <SquidHero />
        <div className="panel squid-empty">
          <h2 className="panel__title">Сейчас игры нет</h2>
          <p>Игру запускает админ — всем придёт приглашение, на вход будет 2 минуты. Следи за ботом и каналом.</p>
          {mine.data && (
            <p className="squid-empty__mine">
              В прошлой игре:{' '}
              {mine.data.place
                ? `${mine.data.place}-е место${mine.data.prize ? ' с призом' : ''}`
                : `выбыл${mine.data.outStage ? ` (${SQUID_STAGE[mine.data.outStage as SquidStage]?.name ?? ''})` : ''}`}
            </p>
          )}
        </div>
        <StageList />
      </div>
    );
  }
  if (!data)
    return (
      <div className="squid-page">
        <SquidHero />
      </div>
    );
  if (!data.ticket) {
    return (
      <div className="squid-page">
        <SquidHero />
        <div className="squid-block">
          <p>{data.block}</p>
          <button type="button" className="btn btn--primary btn--lg btn--block" onClick={() => openSheet('deposit')}>
            <Icon name="plus" size={18} /> Пополнить
          </button>
          <small>Когда вход закроется, игру можно будет смотреть.</small>
        </div>
        <Prizes prizes={game.prizes} />
        <StageList />
      </div>
    );
  }
  return <SquidLive game={game} ticket={data.ticket} skew={(data.serverNow ?? Date.now()) - Date.now()} />;
}

function SquidHero() {
  return (
    <section className="squid-hero">
      <img className="squid-hero__watcher" src="/squid/watcher-red.webp" alt="" />
      <div>
        <p className="squid-hero__kicker">Ивент</p>
        <h1 className="squid-hero__title">Игра Кальмара</h1>
        <p className="squid-hero__text">4 испытания на выбывание. Прошёл стеклянный мост — занял место и забрал приз.</p>
      </div>
    </section>
  );
}

function StageList() {
  return (
    <div className="squid-stages">
      {SQUID_STAGES.map((s) => (
        <div key={s} className={cx('squid-stage-card', `is-${s}`)}>
          <b>
            {STAGE_NO[s]}. {SQUID_STAGE[s].name}
          </b>
          <p>{SQUID_STAGE[s].rules}</p>
        </div>
      ))}
    </div>
  );
}

function Prizes({ prizes }: { prizes: SquidPrize[] }) {
  const catalog = useCatalog();
  if (!prizes.length) return null;
  return (
    <div className="panel squid-prizes">
      <h2 className="panel__title">Призы</h2>
      <ol>
        {prizes.map((p, i) => {
          const b = p.type === 'brainrot' ? catalog.byId.get(p.brainrotId) : null;
          return (
            <li key={i} className={cx(i === 0 && 'is-first')}>
              <span className="squid-prizes__place">{i + 1}</span>
              {b ? (
                <>
                  <BrainrotThumb brainrot={b} size={34} />
                  <span>{b.name}</span>
                  <b>
                    {formatCoins(b.price)} <Coin size={13} />
                  </b>
                </>
              ) : p.type === 'coins' ? (
                <>
                  <Coin size={30} />
                  <span>Монеты</span>
                  <b>{formatCoins(p.amount)} B</b>
                </>
              ) : null}
            </li>
          );
        })}
      </ol>
    </div>
  );
}

// ---------- The live game ----------

function SquidLive({ game, ticket, skew: measured }: { game: SquidGameView; ticket: string; skew: number }) {
  // Measured once: the parent re-renders with the same old serverNow and a newer clock, which would drift it.
  const [skew] = useState(measured);
  const me = useMe();
  const g = useRef<Game>(newGame(me.user.id));
  const [, render] = useReducer((n: number) => n + 1, 0);
  const room = useRef<RoomSocketClient | null>(null);
  const [now, setNow] = useState(Date.now() + skew);
  const lastRender = useRef(0);

  useEffect(() => {
    const soon = () => {
      const t = performance.now();
      if (t - lastRender.current > 150) {
        lastRender.current = t;
        render();
      }
    };
    const feed = (id: number, text: string) => {
      g.current.feed = [{ id, text, at: Date.now() }, ...g.current.feed].slice(0, 6);
    };
    const name = (id: number) => g.current.players.get(id)?.name ?? 'Игрок';
    const onMessage = (m: Record<string, unknown>) => {
      const s = g.current;
      switch (m.t) {
        case 'w': {
          s.phase = m.phase as SquidPhase;
          s.ends = endsOf(m.ends);
          s.start = Number(m.start) || 0;
          s.next = (m.next as SquidStage | null) ?? null;
          s.spectator = m.spectator === true;
          s.players = new Map((m.players as [number, string, number][]).map(([id, n, alive]) => [id, { name: n, alive: !!alive }]));
          const light = m.light as { green: boolean; until: number };
          s.green = light.green;
          s.lightUntil = light.until;
          for (const [id, p] of m.prog as [number, number][]) {
            s.prog.set(id, p);
            if (s.phase === 'light' && p >= LIGHT_FIELD) s.passed.add(id);
          }
          for (const [id, x, y, hp] of m.night as [number, number, number, number][]) s.night.set(id, { x, y, hp, tx: x, ty: y });
          const cookie = m.cookie as { shape: CookieShape; cover: number; done: boolean } | null;
          if (cookie) s.cookie = { shape: cookie.shape, cover: cookie.cover / 120, done: cookie.done };
          if (m.bridge) s.bridge = m.bridge as Bridge;
          s.places = (m.places as number[]) ?? [];
          break;
        }
        case 'j':
          s.players.set(Number(m.id), { name: String(m.n), alive: true });
          break;
        case 'l':
          s.players.delete(Number(m.id));
          break;
        case 'ph':
          s.phase = m.phase as SquidPhase;
          s.ends = endsOf(m.ends);
          s.start = Number(m.start) || 0;
          s.next = (m.next as SquidStage | null) ?? null;
          s.passed = new Set();
          if (s.phase === 'light') {
            s.prog = new Map();
            myProg.current = 0;
          }
          if (s.phase === 'night') s.night = new Map();
          if (s.phase === 'cookie') s.cookie = { shape: null, cover: 0, done: false };
          if (s.phase === 'bridge') s.broken = new Map();
          sfx.countdown(s.phase !== 'break' && s.phase !== 'lobby');
          break;
        case 'li':
          s.green = m.green === true;
          s.lightUntil = Number(m.until);
          if (!s.green) {
            sfx.error();
            haptic('error');
          } else sfx.tap();
          break;
        case 's':
          for (const row of m.p as number[][]) {
            const [id, a, b, hp] = row as [number, number, number?, number?];
            if (s.phase === 'light') {
              s.prog.set(id, a);
              if (id === s.me && myProg.current > a + 40) myProg.current = a;
            } else if (b !== undefined) {
              const cur = s.night.get(id);
              if (cur) Object.assign(cur, { tx: a, ty: b, hp: hp ?? cur.hp });
              else s.night.set(id, { x: a, y: b, tx: a, ty: b, hp: hp ?? NIGHT_HP });
              if (id === s.me && myPos.current && Math.hypot(myPos.current.x - a, myPos.current.y - b) > 90) myPos.current = { x: a, y: b };
            }
          }
          soon();
          return;
        case 'out': {
          const id = Number(m.id);
          const p = s.players.get(id);
          if (p) p.alive = false;
          // «Asleep» reads differently on the field and over the candy.
          const why = m.why === 'idle' ? `idle-${s.phase}` : String(m.why);
          s.out.set(id, why);
          feed(id, `${name(id)} выбыл — ${OUT_WHY[why] ?? ''}`);
          if (id === s.me) {
            sfx.lose();
            haptic('error');
          }
          break;
        }
        case 'ok':
          s.passed.add(Number(m.id));
          if (Number(m.id) === s.me) {
            sfx.win();
            haptic('success');
            if (m.stage === 'cookie') s.cookie.done = true;
          }
          break;
        case 'ck':
          s.cookie = { shape: m.shape as CookieShape, cover: 0, done: false };
          break;
        case 'cv':
          s.cookie.cover = Number(m.cover);
          break;
        case 'sw':
          s.swings.set(Number(m.id), Date.now());
          break;
        case 'hit': {
          const to = Number(m.to);
          s.hits = [...s.hits.filter((h) => Date.now() - h.at < 900), { to, dmg: Number(m.dmg), at: Date.now() }];
          const t = s.night.get(to);
          if (t) t.hp = Number(m.hp);
          if (to === s.me) haptic('error');
          sfx.knock();
          break;
        }
        case 'br':
          s.bridge = m as unknown as Bridge;
          if (s.bridge.walker === s.me) {
            sfx.eggAlert();
            haptic('select');
          }
          break;
        case 'st': {
          const span = Number(m.span);
          if (m.ok) sfx.land();
          else {
            s.broken.set(span, m.side as BridgeSide);
            sfx.crack();
          }
          break;
        }
        case 'cross':
          s.places = [...s.places.filter((x) => x !== Number(m.id)), Number(m.id)];
          feed(Number(m.id), `${name(Number(m.id))} перешёл мост — ${m.place}-е место!`);
          break;
        case 'done':
          s.phase = 'done';
          s.places = (m.places as number[]) ?? s.places;
          void api('/api/squid/settle', { method: 'POST' })
            .catch(() => null)
            .finally(() => setTimeout(() => void queryClient.invalidateQueries({ queryKey: ['me'] }), 800));
          break;
        case 'end':
          s.phase = 'done';
          break;
      }
      render();
    };
    const client = new RoomSocketClient(
      async () => (await api<StateView>('/api/squid')).ticket ?? null,
      onMessage,
      (open) => {
        g.current.connected = open;
        render();
      },
    );
    room.current = client;
    void client.connect(ticket);
    const t = setInterval(() => setNow(Date.now() + skew), 250);
    return () => {
      clearInterval(t);
      client.close();
    };
    // One connection per game.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const myProg = useRef(0);
  const myPos = useRef<{ x: number; y: number } | null>(null);
  const s = g.current;
  const send = (msg: unknown) => room.current?.send(msg);
  const meAlive = !!s.players.get(s.me)?.alive;
  const left = s.ends - now;
  const outWhy = s.out.get(s.me);

  return (
    <div className={cx('squid-page squid-live', `is-${s.phase}`)}>
      <div className="squid-top">
        <span className="squid-top__title">
          {s.phase === 'lobby'
            ? 'Вход открыт'
            : s.phase === 'break'
              ? `Готовься: ${SQUID_STAGE[s.next!]?.name ?? ''}`
              : s.phase === 'done'
                ? 'Игра окончена'
                : `${STAGE_NO[s.phase as SquidStage]}. ${SQUID_STAGE[s.phase as SquidStage].name}`}
        </span>
        {s.phase !== 'done' && Number.isFinite(s.ends) ? (
          <span className={cx('squid-top__time', left < 10_000 && 'is-hot')}>{clock(left)}</span>
        ) : (
          stageProgress(s) && <span className="squid-top__time is-progress">{stageProgress(s)}</span>
        )}
        <span className="squid-top__alive">
          <Icon name="users" size={14} /> {[...s.players.values()].filter((p) => p.alive).length}
        </span>
      </div>
      {s.spectator && <p className="squid-note">Вход уже закрыт — ты смотришь игру.</p>}
      {!s.spectator && outWhy && s.phase !== 'done' && <p className="squid-note is-out">Ты выбыл: {OUT_WHY[outWhy] ?? ''}. Можно досмотреть игру.</p>}
      {!s.connected && <p className="squid-note">Соединяемся с игрой…</p>}

      {s.phase === 'lobby' && <Lobby g={s} prizes={game.prizes} left={left} />}
      {s.phase === 'break' && s.next && <Break next={s.next} left={left} alive={[...s.players.values()].filter((p) => p.alive).length} />}
      {s.phase === 'light' && <LightStage g={s} me={s.me} alive={meAlive} myProg={myProg} send={send} now={now} />}
      {s.phase === 'night' && <NightStage g={s} alive={meAlive} myPos={myPos} send={send} />}
      {s.phase === 'cookie' && <CookieStage g={s} alive={meAlive} send={send} stageStart={s.start} skew={skew} />}
      {s.phase === 'bridge' && <BridgeStage g={s} send={send} now={now} />}
      {s.phase === 'done' && <Done g={s} prizes={game.prizes} />}

      {s.feed.length > 0 && s.phase !== 'lobby' && (
        <ul className="squid-feed" aria-live="polite">
          {s.feed.slice(0, 4).map((f) => (
            <li key={`${f.id}-${f.at}`}>{f.text}</li>
          ))}
        </ul>
      )}
    </div>
  );
}

function Lobby({ g, prizes, left }: { g: Game; prizes: SquidPrize[]; left: number }) {
  const players = [...g.players.entries()];
  return (
    <>
      <SquidHero />
      <div className="squid-lobby">
        <p className="squid-lobby__count">
          В игре <b>{players.length}</b> · старт через <b>{clock(left)}</b>
        </p>
        <div className="squid-lobby__players">
          {players.map(([id, p]) => (
            <span key={id} className={cx('squid-chip', id === g.me && 'is-me')}>
              {p.name}
            </span>
          ))}
        </div>
      </div>
      <Prizes prizes={prizes} />
      <StageList />
    </>
  );
}

function Break({ next, left, alive }: { next: SquidStage; left: number; alive: number }) {
  return (
    <div className={cx('squid-break', `is-${next}`)}>
      <span className="squid-break__no">Испытание {STAGE_NO[next]} из 4</span>
      <h2>{SQUID_STAGE[next].name}</h2>
      <p>{SQUID_STAGE[next].rules}</p>
      <span className="squid-break__go">
        Старт через {clock(left)} · в игре {alive}
      </span>
    </div>
  );
}

// ---------- Stage 1 ----------

function LightStage({
  g,
  me,
  alive,
  myProg,
  send,
  now,
}: {
  g: Game;
  me: number;
  alive: boolean;
  myProg: React.MutableRefObject<number>;
  send: (m: unknown) => void;
  now: number;
}) {
  const [running, setRunning] = useState(false);
  const runRef = useRef(false);
  const finished = g.passed.has(me) || myProg.current >= LIGHT_FIELD;
  useEffect(() => {
    let last = performance.now();
    let sentAt = 0;
    let raf = 0;
    const loop = (t: number) => {
      const dt = (t - last) / 1000;
      last = t;
      if (runRef.current && alive && myProg.current < LIGHT_FIELD) {
        myProg.current = Math.min(LIGHT_FIELD, myProg.current + LIGHT_SPEED * dt);
        if (t - sentAt > 120) {
          sentAt = t;
          send({ t: 'mv', p: Math.round(myProg.current) });
        }
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [alive, myProg, send]);
  const press = (on: boolean) => {
    runRef.current = on;
    setRunning(on);
    if (!on) send({ t: 'mv', p: Math.round(myProg.current) });
  };
  const runners = [...g.players.entries()];
  const lightLeft = g.lightUntil - now;
  return (
    <div className={cx('squid-light', g.green ? 'is-green' : 'is-red')}>
      <div className="squid-light__sign" role="status">
        {g.green ? 'ЗЕЛЁНЫЙ — беги!' : 'КРАСНЫЙ — замри!'}
        <small>{g.green && lightLeft < 900 ? 'сейчас обернётся…' : ' '}</small>
      </div>
      <div className="squid-field">
        <img className={cx('squid-field__watcher', !g.green && 'is-turned')} src={g.green ? '/squid/watcher-back.webp' : '/squid/watcher-red.webp'} alt="" />
        <span className="squid-field__finish" />
        {runners.map(([id, p], i) => {
          const prog = id === me ? myProg.current : (g.prog.get(id) ?? 0);
          return (
            <span
              key={id}
              className={cx('squid-runner', id === me && 'is-me', !p.alive && 'is-out', g.passed.has(id) && 'is-safe')}
              style={{ left: `${8 + ((i * 37) % 84)}%`, bottom: `calc(14px + ${Math.min(1, prog / LIGHT_FIELD)} * (100% - 132px))` }}
              title={p.name}
            >
              {p.name.slice(0, 1)}
            </span>
          );
        })}
      </div>
      {alive && !finished ? (
        <button
          type="button"
          className={cx('squid-run', running && 'is-on')}
          onPointerDown={(e) => {
            (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
            press(true);
          }}
          onPointerUp={() => press(false)}
          onPointerCancel={() => press(false)}
          onContextMenu={(e) => e.preventDefault()}
        >
          {running ? 'Бегу… отпусти, чтобы замереть' : 'Держи, чтобы бежать'}
        </button>
      ) : (
        <p className="squid-wait">{finished ? 'Ты добежал! Ждём остальных.' : 'Смотришь забег.'}</p>
      )}
      <div className="squid-progress">
        <span style={{ transform: `scaleX(${myProg.current / LIGHT_FIELD})` }} />
      </div>
    </div>
  );
}

// ---------- Stage 2 ----------

function NightStage({
  g,
  alive,
  myPos,
  send,
}: {
  g: Game;
  alive: boolean;
  myPos: React.MutableRefObject<{ x: number; y: number } | null>;
  send: (m: unknown) => void;
}) {
  const canvas = useRef<HTMLCanvasElement>(null);
  const input = useRef({ x: 0, y: 0 });
  const [stick, setStick] = useState<{ x: number; y: number; dx: number; dy: number } | null>(null);
  const hitAt = useRef(0);
  const arena = useMemo(() => {
    const i = new Image();
    i.src = '/squid/arena.webp';
    return i;
  }, []);
  const sword = useMemo(() => {
    const i = new Image();
    i.src = '/squid/sword.webp';
    return i;
  }, []);

  useEffect(() => {
    const el = canvas.current!;
    const ctx = el.getContext('2d')!;
    let raf = 0;
    let last = performance.now();
    let sentAt = 0;
    const loop = (t: number) => {
      const dt = Math.min(0.05, (t - last) / 1000);
      last = t;
      const me = g.night.get(g.me);
      if (me && !myPos.current) myPos.current = { x: me.x, y: me.y };
      if (myPos.current && alive) {
        const len = Math.hypot(input.current.x, input.current.y);
        if (len > 0.05) {
          const k = Math.min(1, len) / len;
          myPos.current.x += input.current.x * k * NIGHT_SPEED * dt;
          myPos.current.y += input.current.y * k * NIGHT_SPEED * dt;
          const r = Math.hypot(myPos.current.x, myPos.current.y);
          if (r > NIGHT_RADIUS) {
            myPos.current.x *= NIGHT_RADIUS / r;
            myPos.current.y *= NIGHT_RADIUS / r;
          }
          if (t - sentAt > 120) {
            sentAt = t;
            send({ t: 'p', x: Math.round(myPos.current.x), y: Math.round(myPos.current.y) });
          }
        }
      }
      for (const p of g.night.values()) {
        p.x += (p.tx - p.x) * Math.min(1, dt * 8);
        p.y += (p.ty - p.y) * Math.min(1, dt * 8);
      }
      // Draw.
      const r = el.getBoundingClientRect();
      const dpr = Math.min(2, devicePixelRatio || 1);
      if (el.width !== Math.round(r.width * dpr)) {
        el.width = Math.round(r.width * dpr);
        el.height = Math.round(r.height * dpr);
      }
      const scale = (Math.min(r.width, r.height) / (NIGHT_RADIUS * 2.15)) * dpr;
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      ctx.fillStyle = '#12070b';
      ctx.fillRect(0, 0, el.width, el.height);
      ctx.setTransform(scale, 0, 0, scale, el.width / 2, el.height / 2);
      if (arena.complete && arena.naturalWidth) ctx.drawImage(arena, -NIGHT_RADIUS * 1.07, -NIGHT_RADIUS * 1.07, NIGHT_RADIUS * 2.14, NIGHT_RADIUS * 2.14);
      // The night closes in from the edges; a blood-red moonlight in the middle.
      const shade = ctx.createRadialGradient(0, 0, NIGHT_RADIUS * 0.15, 0, 0, NIGHT_RADIUS * 1.1);
      shade.addColorStop(0, 'rgba(120,10,30,0.12)');
      shade.addColorStop(1, 'rgba(8,0,6,0.55)');
      ctx.fillStyle = shade;
      ctx.fillRect(-NIGHT_RADIUS * 1.1, -NIGHT_RADIUS * 1.1, NIGHT_RADIUS * 2.2, NIGHT_RADIUS * 2.2);
      const now = Date.now();
      for (const [id, p] of g.night) {
        const info = g.players.get(id);
        if (!info?.alive) continue;
        const pos = id === g.me && myPos.current ? myPos.current : p;
        const mine = id === g.me;
        ctx.fillStyle = 'rgba(0,0,0,0.35)';
        ctx.beginPath();
        ctx.ellipse(pos.x + 6, pos.y + 16, 40, 20, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = mine ? '#ffd34d' : '#e8edf7';
        ctx.strokeStyle = mine ? '#8a5a00' : '#2a2f3a';
        ctx.lineWidth = 6;
        ctx.beginPath();
        ctx.arc(pos.x, pos.y, 40, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
        ctx.fillStyle = '#1b1f2a';
        ctx.font = "800 40px 'Unbounded Variable', system-ui";
        ctx.textAlign = 'center';
        ctx.fillText(info.name.slice(0, 1).toUpperCase(), pos.x, pos.y + 14);
        // HP bar.
        ctx.fillStyle = 'rgba(0,0,0,0.6)';
        ctx.fillRect(pos.x - 46, pos.y - 68, 92, 12);
        ctx.fillStyle = p.hp > 50 ? '#4ade80' : p.hp > 25 ? '#facc15' : '#f87171';
        ctx.fillRect(pos.x - 46, pos.y - 68, (92 * Math.max(0, p.hp)) / NIGHT_HP, 12);
        // A swing: the sword sweeps an arc.
        const sw = g.swings.get(id);
        if (sw && now - sw < 260 && sword.complete) {
          const a = -1.2 + ((now - sw) / 260) * 2.4;
          ctx.save();
          ctx.translate(pos.x, pos.y);
          ctx.rotate(a);
          ctx.drawImage(sword, 18, -110, 64, 128);
          ctx.restore();
        }
      }
      for (const h of g.hits) {
        const p = g.night.get(h.to);
        if (!p) continue;
        const k = (now - h.at) / 900;
        if (k > 1) continue;
        ctx.globalAlpha = 1 - k;
        ctx.fillStyle = '#ff6b6b';
        ctx.font = "800 44px 'Unbounded Variable', system-ui";
        ctx.fillText(`−${h.dmg}`, p.x, p.y - 84 - k * 50);
        ctx.globalAlpha = 1;
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [alive, arena, g, myPos, send, sword]);

  const origin = useRef<{ x: number; y: number; id: number } | null>(null);
  const down = (e: ReactPointerEvent<HTMLDivElement>) => {
    if ((e.target as HTMLElement).closest('button')) return;
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    origin.current = { x: e.clientX, y: e.clientY, id: e.pointerId };
    setStick({ x: e.clientX, y: e.clientY, dx: 0, dy: 0 });
  };
  const move = (e: ReactPointerEvent<HTMLDivElement>) => {
    const o = origin.current;
    if (!o || o.id !== e.pointerId) return;
    const R = 54;
    let dx = e.clientX - o.x;
    let dy = e.clientY - o.y;
    const d = Math.hypot(dx, dy);
    if (d > R) {
      dx = (dx / d) * R;
      dy = (dy / d) * R;
    }
    setStick({ x: o.x, y: o.y, dx, dy });
    input.current = { x: dx / R, y: dy / R };
  };
  const up = (e: ReactPointerEvent<HTMLDivElement>) => {
    if (origin.current?.id !== e.pointerId) return;
    origin.current = null;
    setStick(null);
    input.current = { x: 0, y: 0 };
  };
  useEffect(() => {
    const keys = new Set<string>();
    const steer = () => {
      input.current = {
        x: (keys.has('KeyD') || keys.has('ArrowRight') ? 1 : 0) - (keys.has('KeyA') || keys.has('ArrowLeft') ? 1 : 0),
        y: (keys.has('KeyS') || keys.has('ArrowDown') ? 1 : 0) - (keys.has('KeyW') || keys.has('ArrowUp') ? 1 : 0),
      };
    };
    const kd = (e: KeyboardEvent) => {
      if (e.code === 'Space') {
        e.preventDefault();
        hit();
        return;
      }
      keys.add(e.code);
      steer();
    };
    const ku = (e: KeyboardEvent) => {
      keys.delete(e.code);
      steer();
    };
    window.addEventListener('keydown', kd);
    window.addEventListener('keyup', ku);
    return () => {
      window.removeEventListener('keydown', kd);
      window.removeEventListener('keyup', ku);
    };
  });
  function hit() {
    if (!alive || Date.now() - hitAt.current < NIGHT_COOLDOWN_MS) return;
    hitAt.current = Date.now();
    g.swings.set(g.me, Date.now());
    send({ t: 'hit' });
    sfx.whoosh();
    haptic('tap');
  }
  const meHp = g.night.get(g.me)?.hp ?? NIGHT_HP;
  return (
    <div className="squid-night" onPointerDown={down} onPointerMove={move} onPointerUp={up} onPointerCancel={up}>
      <div className="squid-night__stage">
        <canvas ref={canvas} className="squid-night__canvas" />
        {alive && (
          <span className="squid-night__hp">
            HP <b>{Math.max(0, meHp)}</b>
          </span>
        )}
      </div>
      {alive && (
        <>
          <button type="button" className="squid-hit" onPointerDown={hit}>
            ⚔️ Удар
          </button>
        </>
      )}
      {stick && (
        <span className="squid-stick" style={{ left: stick.x, top: stick.y }} aria-hidden="true">
          <span className="squid-stick__knob" style={{ transform: `translate(${stick.dx}px, ${stick.dy}px)` }} />
        </span>
      )}
      <p className="squid-hint">Веди пальцем — двигаешься, «Удар» — меч (ПК: WASD и пробел)</p>
    </div>
  );
}

// ---------- Stage 3 ----------

function CookieStage({ g, alive, send, stageStart, skew }: { g: Game; alive: boolean; send: (m: unknown) => void; stageStart: number; skew: number }) {
  const canvas = useRef<HTMLCanvasElement>(null);
  const path = useRef<[number, number][][]>([]);
  const pending = useRef<[number, number, number][]>([]);
  const lastPt = useRef<[number, number, number] | null>(null);
  // A stroke only cuts once the needle is on the line (a stray touch elsewhere doesn't crack the candy).
  const cutting = useRef(false);
  const [fast, setFast] = useState(false);
  const img = useMemo(() => {
    const i = new Image();
    i.src = '/squid/cookie.webp';
    return i;
  }, []);
  const shape = g.cookie.shape;
  const outline = useMemo(() => (shape ? cookieOutline(shape) : []), [shape]);
  const cracked = !alive && g.out.get(g.me) !== undefined && (g.out.get(g.me) === 'off' || g.out.get(g.me) === 'fast');

  useEffect(() => {
    const t = setInterval(() => {
      if (!pending.current.length) return;
      send({ t: 'tr', pts: pending.current.splice(0, 60) });
    }, 150);
    return () => clearInterval(t);
  }, [send]);

  useEffect(() => {
    const el = canvas.current!;
    const ctx = el.getContext('2d')!;
    let raf = 0;
    const draw = () => {
      const r = el.getBoundingClientRect();
      const dpr = Math.min(2, devicePixelRatio || 1);
      if (el.width !== Math.round(r.width * dpr)) {
        el.width = Math.round(r.width * dpr);
        el.height = Math.round(r.height * dpr);
      }
      const R = el.width / 2;
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      ctx.clearRect(0, 0, el.width, el.height);
      if (img.complete && img.naturalWidth) ctx.drawImage(img, 0, 0, el.width, el.height);
      ctx.setTransform(R * 0.93, 0, 0, R * 0.93, R, R);
      if (outline.length) {
        ctx.beginPath();
        outline.forEach(([x, y], i) => (i ? ctx.lineTo(x, y) : ctx.moveTo(x, y)));
        ctx.closePath();
        ctx.strokeStyle = 'rgba(110,60,10,0.75)';
        ctx.lineWidth = 0.05;
        ctx.stroke();
        ctx.strokeStyle = 'rgba(255,230,170,0.35)';
        ctx.lineWidth = 0.018;
        ctx.stroke();
      }
      ctx.strokeStyle = g.cookie.done ? '#4ade80' : '#fff7d6';
      ctx.lineWidth = 0.03;
      ctx.lineCap = 'round';
      for (const stroke of path.current) {
        ctx.beginPath();
        stroke.forEach(([x, y], i) => (i ? ctx.lineTo(x, y) : ctx.moveTo(x, y)));
        ctx.stroke();
      }
      if (cracked) {
        ctx.strokeStyle = 'rgba(60,25,5,0.85)';
        ctx.lineWidth = 0.025;
        for (let i = 0; i < 7; i++) {
          const a = (i / 7) * Math.PI * 2 + 0.3;
          ctx.beginPath();
          ctx.moveTo(0, 0);
          ctx.lineTo(Math.cos(a) * 0.5, Math.sin(a) * 0.5);
          ctx.lineTo(Math.cos(a + 0.2) * 0.95, Math.sin(a + 0.2) * 0.95);
          ctx.stroke();
        }
      }
      raf = requestAnimationFrame(draw);
    };
    raf = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(raf);
  }, [cracked, g.cookie, img, outline]);

  const toShape = (e: ReactPointerEvent<HTMLCanvasElement>): [number, number] => {
    const r = (e.currentTarget as HTMLElement).getBoundingClientRect();
    const R = (r.width / 2) * 0.93;
    return [(e.clientX - r.left - r.width / 2) / R, (e.clientY - r.top - r.height / 2) / R];
  };
  const stamp = () => Date.now() + skew - stageStart;
  const add = (e: ReactPointerEvent<HTMLCanvasElement>) => {
    if (!alive || g.cookie.done || !shape) return;
    const [x, y] = toShape(e);
    if (!cutting.current) {
      if (outlineDistance(outline, x, y) > COOKIE_TOLERANCE * 0.8) return;
      cutting.current = true;
    }
    path.current.at(-1)?.push([x, y]);
    // The room judges the speed between the points it gets: one every 50 ms or more, so finger jitter between two
    // touch events (a few pixels in 8 ms) never reads as «too fast».
    const t = stamp();
    const prev = lastPt.current;
    if (prev && t - prev[2] < 50) return;
    if (prev && t - prev[2] < 250) setFast(Math.hypot(x - prev[0], y - prev[1]) / ((t - prev[2]) / 1000) > COOKIE_MAX_SPEED * 0.7);
    lastPt.current = [x, y, t];
    pending.current.push([Math.round(x * 1000) / 1000, Math.round(y * 1000) / 1000, Math.round(t)]);
  };
  return (
    <div className="squid-cookie">
      <p className="squid-cookie__shape">
        {shape ? `Твоя фигура: ${COOKIE_SHAPE_NAME[shape]}` : 'Раздаём соты…'} · вырезано <b>{Math.round(g.cookie.cover * 100)}%</b>
      </p>
      <canvas
        ref={canvas}
        className={cx('squid-cookie__canvas', cracked && 'is-cracked', g.cookie.done && 'is-done')}
        onPointerDown={(e) => {
          (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
          path.current.push([]);
          lastPt.current = null;
          cutting.current = false;
          add(e);
        }}
        onPointerMove={(e) => e.buttons && add(e)}
        onPointerUp={() => setFast(false)}
      />
      <p className={cx('squid-cookie__tip', fast && 'is-fast')}>
        {g.cookie.done
          ? 'Вырезал! Ждём остальных.'
          : cracked
            ? 'Соты треснули…'
            : fast
              ? 'Медленнее — треснет!'
              : 'Поставь палец на линию и веди точно по ней, не спеши. Палец можно отпускать.'}
      </p>
    </div>
  );
}

// ---------- Stage 4 ----------

function BridgeStage({ g, send, now }: { g: Game; send: (m: unknown) => void; now: number }) {
  const b = g.bridge;
  const track = useRef<HTMLDivElement>(null);
  // Keep the span being walked in the middle of the track.
  useEffect(() => {
    const el = track.current;
    const here = el?.querySelector<HTMLElement>('.squid-span.is-here');
    if (el && here) el.scrollTo({ top: here.offsetTop - el.clientHeight / 2 + here.clientHeight / 2, behavior: 'smooth' });
  }, [b?.at, b?.walker]);
  if (!b) return <p className="squid-wait">Строим мост…</p>;
  const myTurn = b.walker === g.me;
  const queuePos = b.order.indexOf(g.me) - b.turn;
  const spans = Array.from({ length: b.known.length }, (_, i) => b.known.length - 1 - i);
  const walkerName = b.walker !== null ? (g.players.get(b.walker)?.name ?? 'Игрок') : '';
  return (
    <div className="squid-bridge">
      <p className="squid-bridge__who">
        {myTurn ? (
          <b>Твой ход — выбирай стекло! {clock(b.ends - now)}</b>
        ) : b.walker ? (
          <>
            Идёт <b>{walkerName}</b> · {clock(b.ends - now)}
            {queuePos > 0 && ` · ты ${queuePos + 1}-й в очереди`}
          </>
        ) : (
          'Все прошли'
        )}
      </p>
      <div className="squid-bridge__track" ref={track}>
        <span className="squid-bridge__end">ФИНИШ</span>
        {spans.map((i) => {
          const known = b.known[i];
          const broken = g.broken.get(i);
          const here = i === b.at;
          return (
            <div key={i} className={cx('squid-span', here && 'is-here')}>
              {(['l', 'r'] as const).map((side) => (
                <span
                  key={side}
                  className={cx('squid-glass', known === side && 'is-safe', broken === side && 'is-broken', known && known !== side && !broken && 'is-dim')}
                />
              ))}
              {here && b.walker !== null && <span className={cx('squid-walker', myTurn && 'is-me')}>{walkerName.slice(0, 1)}</span>}
              <span className="squid-span__no">{i + 1}</span>
            </div>
          );
        })}
        <span className="squid-bridge__end">СТАРТ</span>
      </div>
      {myTurn && (
        <div className="squid-bridge__pick">
          <button type="button" className="btn btn--primary btn--lg" onClick={() => send({ t: 'ch', side: 'l' })}>
            ◀ Левое
          </button>
          <button type="button" className="btn btn--primary btn--lg" onClick={() => send({ t: 'ch', side: 'r' })}>
            Правое ▶
          </button>
        </div>
      )}
      {g.places.length > 0 && (
        <p className="squid-bridge__places">Перешли: {g.places.map((id, i) => `${i + 1}. ${g.players.get(id)?.name ?? 'Игрок'}`).join(' · ')}</p>
      )}
    </div>
  );
}

// ---------- Results ----------

function Done({ g, prizes }: { g: Game; prizes: SquidPrize[] }) {
  const catalog = useCatalog();
  const mine = g.places.indexOf(g.me);
  return (
    <div className="squid-done">
      <img src="/squid/watcher-back.webp" alt="" />
      <h2>{mine >= 0 ? `Ты прошёл! ${mine + 1}-е место` : 'Игра окончена'}</h2>
      {g.places.length ? (
        <ol className="squid-done__places">
          {g.places.map((id, i) => {
            const p = prizes[i];
            const b = p?.type === 'brainrot' ? catalog.byId.get(p.brainrotId) : null;
            return (
              <li key={id} className={cx(id === g.me && 'is-me')}>
                <span>{i + 1}</span>
                <b>{g.players.get(id)?.name ?? 'Игрок'}</b>
                {b ? <BrainrotThumb brainrot={b} size={28} /> : p?.type === 'coins' ? <em>{formatCoins(p.amount)} B</em> : null}
              </li>
            );
          })}
        </ol>
      ) : (
        <p>Никто не перешёл мост.</p>
      )}
      <p className="squid-done__note">Призы приходят сами в течение минуты (админы мест не занимают — приз уходит следующему).</p>
    </div>
  );
}
