import { SQUID_BREAK_MS, SQUID_LOBBY_MS, SQUID_MAX_PLACES, SQUID_STAGE, SQUID_STAGE_CAP_MS, SQUID_STAGES, type SquidPrize } from '../shared/squid';
import type { Viewer } from './auth';
import { ensureSchema } from './autoMigrate';
import { bumpCatalogVersion, publicName } from './catalog';
import { num, one, q, tx, type Queryable } from './db';
import { addCoins, addItemWager, addWager, giveItems } from './economy';
import { bad } from './errors';
import { afterResponse, broadcast } from './live';
import { escapeHtml, notify } from './telegram';
import { queueBroadcast } from './notifications';
import { roomCall, roomTicket } from './rooms/bridge';
import { getSettings, setSetting } from './settings';
import { notStaff } from './staff';
import { bool, int, str, type Body } from './validate';

/**
 * «Игра Кальмара» (iteration 35, rules in shared/squid.ts). An admin starts a game with prizes for the first places;
 * the `squid` setting carries it to every open app (an invite with the lobby's countdown) and the bot tells everyone.
 * The game runs in its room (server/rooms/squid.ts, the referee); once the room says it is over, the first call to
 * `settleSquid` (the players' apps, the minute tick) records every player's result and pays the places — once, under
 * the game's row lock. Staff play but never take a place's prize (as in the giveaways).
 */

export const squidRoom = (gameId: number) => `squid:${gameId}`;

/** The longest a game can take (lobby, breaks, every stage at full length) plus slack: past it, it is abandoned. */
const MAX_GAME_MS = SQUID_LOBBY_MS + SQUID_STAGES.length * SQUID_BREAK_MS + SQUID_STAGES.reduce((s, k) => s + (SQUID_STAGE[k].ms ?? SQUID_STAGE_CAP_MS), 0) + 10 * 60_000;

async function hasDeposited(c: Queryable, userId: number) {
  const { rows } = await c.query(
    `SELECT 1 FROM star_payments WHERE user_id = $1 UNION ALL SELECT 1 FROM item_deposits WHERE user_id = $1 AND status = 'credited' LIMIT 1`,
    [userId],
  );
  return rows.length > 0;
}

/** The game in progress, whether this player may play, and a pass into its room (to play in the lobby, else to watch). */
export async function squidState(v: Viewer) {
  await ensureSchema();
  const settings = await getSettings();
  const game = settings.squid;
  if (!game) return { game: null };
  const lobby = Date.now() < game.lobbyUntil;
  const block = !v.termsOk
    ? 'Подтверди, что тебе есть 18, и прими соглашение'
    : v.frozen
      ? 'Аккаунт заморожен'
      : game.needDeposit && !v.isAdmin && !(await tx((c) => hasDeposited(c, v.id)))
        ? 'Играют игроки с пополнением — пополни баланс, чтобы участвовать'
        : null;
  let ticket: string | null = null;
  // While the lobby is open only those who may play get in; afterwards anyone can watch.
  if (!block || !lobby) {
    const u = await one<{ first_name: string; last_name: string | null }>('SELECT first_name, last_name FROM users WHERE id = $1', [v.id]);
    ticket = roomTicket({
      userId: v.id,
      name: publicName(u ?? { first_name: 'Игрок', last_name: null }),
      room: squidRoom(game.gameId),
      // An admin's immortality for trailers (iteration 37).
      god: v.isAdmin && settings.immortal.includes(v.id),
    });
  }
  return { game, block, ticket, serverNow: Date.now() };
}

interface Results {
  done: boolean;
  places: number[];
  out: [number, string][];
  players: number[];
}

/** Records the results and pays the places once the room says the game is over. Safe to call any number of times. */
export async function settleSquid(): Promise<{ settled: boolean; places?: number[] }> {
  await ensureSchema();
  const game = (await getSettings()).squid;
  if (!game) return { settled: false };
  // Once the lobby is closed the bot's invite has nothing left to offer: stop it (it goes out 40 messages a minute).
  if (Date.now() > game.lobbyUntil) await q(`UPDATE broadcasts SET finished_at = now() WHERE kind = 'squid' AND finished_at IS NULL`);
  const results = await roomCall<Results>(squidRoom(game.gameId), 'results');
  const stale = Date.now() > game.lobbyUntil + MAX_GAME_MS;
  if (!results?.done && !stale) return { settled: false };
  const paid = await tx(async (c) => {
    const row = (await c.query<{ status: string; prizes: SquidPrize[] }>('SELECT status, prizes FROM squid_games WHERE id = $1 FOR UPDATE', [game.gameId]))
      .rows[0];
    if (!row || row.status !== 'live') return null;
    if (!results?.done) {
      // The room is gone (nobody stayed connected) and the game ran out of time: closed without prizes.
      await c.query(`UPDATE squid_games SET status = 'abandoned', settled_at = now() WHERE id = $1`, [game.gameId]);
      await setSetting(c, 'squid', null);
      return [];
    }
    const outOf = new Map(results.out);
    // Places go to players only: staff cross the bridge too, but the prize goes to the next player in line.
    const ids = [...new Set([...results.players, ...results.places])];
    const players = ids.length
      ? (await c.query<{ id: string }>(`SELECT id FROM users u WHERE u.id = ANY($1::bigint[]) AND ${notStaff('u.id')}`, [ids])).rows.map((r) => num(r.id))
      : [];
    const eligible = results.places.filter((id) => players.includes(id));
    const prizes = row.prizes ?? [];
    const winners: { userId: number; place: number; prize: SquidPrize }[] = [];
    for (const id of ids) {
      const place = results.places.indexOf(id);
      const prizeAt = eligible.indexOf(id);
      const prize = prizeAt >= 0 ? (prizes[prizeAt] ?? null) : null;
      await c.query(`INSERT INTO squid_players (game_id, user_id, place, out_stage, prize) VALUES ($1, $2, $3, $4, $5::jsonb) ON CONFLICT DO NOTHING`, [
        game.gameId,
        id,
        place >= 0 ? place + 1 : null,
        outOf.get(id) ?? null,
        prize ? JSON.stringify(prize) : null,
      ]);
      if (!prize) continue;
      if (prize.type === 'brainrot') {
        await giveItems(c, id, prize.brainrotId, 'squid');
        await addItemWager(c, id, prize.brainrotId);
      } else {
        await addCoins(c, id, prize.amount);
        await addWager(c, id, prize.amount, 'bonus');
      }
      winners.push({ userId: id, place: prizeAt + 1, prize });
    }
    await c.query(`UPDATE squid_games SET status = 'done', settled_at = now(), results = $2::jsonb WHERE id = $1`, [game.gameId, JSON.stringify(results)]);
    await setSetting(c, 'squid', null);
    return winners;
  });
  if (paid === null) return { settled: false };
  await bumpCatalogVersion();
  broadcast('catalog');
  if (paid.length) {
    const names = new Map(
      (
        await q<{ id: string; name: string | null }>('SELECT id, name FROM brainrots WHERE id = ANY($1::text[])', [
          paid.flatMap((w) => (w.prize.type === 'brainrot' ? [w.prize.brainrotId] : [])),
        ])
      ).map((r) => [r.id, r.name ?? r.id]),
    );
    for (const w of paid) {
      const what = w.prize.type === 'brainrot' ? (names.get(w.prize.brainrotId) ?? 'брейнрот') : `${w.prize.amount.toLocaleString('ru-RU')} B`;
      await afterResponse(() =>
        notify(w.userId, `🦑 <b>Игра Кальмара</b>: ты прошёл стеклянный мост и занял <b>${w.place}-е место</b>! Приз — ${escapeHtml(what)}, уже у тебя.`),
      );
    }
  }
  return { settled: true, places: results?.places ?? [] };
}

// ---------- Admin ----------

function prizesOf(raw: unknown): SquidPrize[] {
  if (!Array.isArray(raw) || !raw.length) throw bad('invalid', 'Добавь хотя бы один приз');
  if (raw.length > SQUID_MAX_PLACES) throw bad('invalid', `Призовых мест — не больше ${SQUID_MAX_PLACES}`);
  return raw.map((p, i) => {
    const o = (p ?? {}) as Body;
    if (o.type === 'coins') return { type: 'coins', amount: int(o.amount, `монеты за ${i + 1}-е место`, 1, 1_000_000) };
    return { type: 'brainrot', brainrotId: str(o.brainrotId, `брейнрот за ${i + 1}-е место`, 1, 80) };
  });
}

export async function adminSquid() {
  await ensureSchema();
  const game = (await getSettings()).squid;
  const [room, last] = await Promise.all([
    game ? roomCall<{ phase: string; ends: number | null; players: number; alive: number }>(squidRoom(game.gameId), 'stats') : null,
    q<{ id: string; status: string; created_at: string; places: string; players: string }>(
      `SELECT g.id, g.status, g.created_at,
         (SELECT count(*) FROM squid_players p WHERE p.game_id = g.id AND p.place IS NOT NULL) AS places,
         (SELECT count(*) FROM squid_players p WHERE p.game_id = g.id) AS players
       FROM squid_games g ORDER BY g.id DESC LIMIT 5`,
    ),
  ]);
  return {
    game,
    room,
    last: last.map((g) => ({ id: num(g.id), status: g.status, at: new Date(g.created_at).getTime(), places: num(g.places), players: num(g.players) })),
  };
}

export async function adminSquidStart(admin: Viewer, body: Body) {
  await ensureSchema();
  if ((await getSettings()).squid) throw bad('running', 'Игра уже идёт — дождись конца или отмени её');
  const prizes = prizesOf(body.prizes);
  const needDeposit = body.needDeposit === undefined ? true : bool(body.needDeposit);
  const announce = body.notify === undefined ? true : bool(body.notify);
  const lobbyUntil = Date.now() + SQUID_LOBBY_MS;
  const gameId = await tx(async (c) => {
    for (const p of prizes) {
      if (p.type !== 'brainrot') continue;
      const ok = (await c.query(`SELECT 1 FROM brainrots WHERE id = $1 AND status <> 'deleted' AND kind = 'brainrot'`, [p.brainrotId])).rows.length;
      if (!ok) throw bad('invalid', 'Одного из призовых брейнротов нет в каталоге');
    }
    const { rows } = await c.query<{ id: string }>(
      `INSERT INTO squid_games (lobby_until, need_deposit, prizes, created_by) VALUES ($1, $2, $3::jsonb, $4) RETURNING id`,
      [new Date(lobbyUntil), needDeposit, JSON.stringify(prizes), admin.id],
    );
    const id = num(rows[0]!.id);
    await setSetting(c, 'squid', { gameId: id, lobbyUntil, needDeposit, prizes });
    await c.query('INSERT INTO admin_log (admin_id, action, target_user, details) VALUES ($1, $2, NULL, $3::jsonb)', [
      admin.id,
      'squid_start',
      JSON.stringify({ gameId: id, prizes }),
    ]);
    if (announce) {
      await queueBroadcast(c, admin.id, 'squid', {
        html: '🦑 <b>Игра Кальмара</b> начинается! Вход открыт 2 минуты — 4 испытания, призы за первые места. Успей зайти!',
        button: { text: '🦑 Участвовать', open: 'squid' },
      });
    }
    return id;
  });
  await roomCall(squidRoom(gameId), 'init', { lobbyUntil });
  return { gameId, lobbyUntil };
}

export async function adminSquidCancel(admin: Viewer) {
  const game = (await getSettings()).squid;
  if (!game) throw bad('none', 'Игра не идёт');
  await tx(async (c) => {
    await c.query(`UPDATE squid_games SET status = 'cancelled', settled_at = now() WHERE id = $1 AND status = 'live'`, [game.gameId]);
    await setSetting(c, 'squid', null);
    await c.query('INSERT INTO admin_log (admin_id, action, target_user, details) VALUES ($1, $2, NULL, $3::jsonb)', [
      admin.id,
      'squid_cancel',
      JSON.stringify({ gameId: game.gameId }),
    ]);
  });
  await roomCall(squidRoom(game.gameId), 'close');
  return adminSquid();
}

/** The player's own past result in the last game (shown on the page after it). */
export async function squidMine(v: Viewer) {
  const row = await one<{ game_id: string; place: number | null; out_stage: string | null; prize: SquidPrize | null }>(
    'SELECT game_id, place, out_stage, prize FROM squid_players WHERE user_id = $1 ORDER BY game_id DESC LIMIT 1',
    [v.id],
  );
  return row ? { gameId: num(row.game_id), place: row.place, outStage: row.out_stage, prize: row.prize } : null;
}
