-- Iteration 38 (the owner, urgent): the referral case once per account, and the окуп chance of paid cases ×0.5 for a
-- while. Applied by the Worker (server/autoMigrate.ts) — safe to run twice.

-- Unopened referral openings beyond the one an account may ever have (an account that already opened one keeps none)
-- go away; what each account had is kept here, so it can be given back if the owner ever wants to.
CREATE TABLE IF NOT EXISTS ref_case_trim (
  user_id BIGINT PRIMARY KEY REFERENCES users (id),
  had INT NOT NULL,
  kept INT NOT NULL,
  opened INT NOT NULL,
  at TIMESTAMPTZ NOT NULL DEFAULT now()
);

WITH k AS (
  SELECT ck.user_id, ck.count,
         (SELECT count(*) FROM drops d WHERE d.user_id = ck.user_id AND d.game = 'case' AND d.meta->>'caseId' = 'referral')::int AS opened
  FROM case_keys ck
  WHERE ck.case_id = 'referral' AND ck.count > 0
), t AS (
  SELECT user_id, count, opened, greatest(0, 1 - opened) AS keep FROM k WHERE count > greatest(0, 1 - opened)
), saved AS (
  INSERT INTO ref_case_trim (user_id, had, kept, opened)
  SELECT user_id, count, keep, opened FROM t
  ON CONFLICT (user_id) DO NOTHING
  RETURNING user_id
)
UPDATE case_keys ck SET count = t.keep, demo_count = least(ck.demo_count, t.keep)
FROM t WHERE ck.user_id = t.user_id AND ck.case_id = 'referral';

-- «Окуп в кейсах»: ×0.5 from now on, until an owner switches it back (admin «Ивенты»).
INSERT INTO settings (key, value) VALUES ('okup_cut', '{"factor": 0.5, "until": null}'::jsonb) ON CONFLICT (key) DO NOTHING;
