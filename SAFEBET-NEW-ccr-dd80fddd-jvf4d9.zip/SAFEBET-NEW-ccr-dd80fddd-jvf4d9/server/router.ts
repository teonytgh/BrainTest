import { deleteCaseConfig, listCaseConfigs, loadCaseConfig, saveCaseConfig } from './caseConfigs';
import { ACTION_LIMIT, rateLimit } from './rateLimit';
import { ensureSchema } from './autoMigrate';
import * as pass from './pass';
import { checkDepositPromo } from './depositPromo';
import * as admin from './admin';
import * as cryptoPay from './crypto';
import * as audit from './audit';
import { authenticate, type Viewer } from './auth';
import { allBrainrots, allCases, bumpCatalogVersion, cachedCatalog, caseSections, topDrop24h } from './catalog';
import { cashOutCrash, startCrash, waitCrash } from './crash';
import { fuseState, runFuse } from './fuse';
import * as tacos from './tacos';
import { cashoutRoad, roadState, startRoad, stepRoad } from './road';
import { cashoutMines, minesState, pickMines, startMines } from './mines';
import { acceptTerms, createSource, economyReport, finishOnboarding, listSources, setPartner, shareWin } from './growth';
import { claimQuest, questsState } from './quests';
import { claimRankGift, rankState } from './ranks';
import * as giveaways from './giveaways';
import { env } from './env';
import { eventsOf, getSettings } from './settings';
import { HttpError, forbidden } from './errors';
import * as bonuses from './bonuses';
import * as freeGate from './freeGate';
import * as games from './games';
import { broadcast, liveTicket, markViewer } from './live';
import { buildMe } from './me';
import { recentDrops } from './liveDrops';
import { publicProfile, searchPlayers } from './players';
import * as battles from './battles';
import * as danger from './danger';
import * as depositList from './depositList';
import * as deposits from './itemDeposits';
import * as referrals from './referrals';
import * as stars from './stars';
import * as withdrawals from './withdrawals';
import { serveUpload } from './storage';
import type { Body } from './validate';
import * as sky from './sky';
import * as squid from './squid';

type Access = 'user' | 'admin';

interface Route {
  method: 'GET' | 'POST' | 'PATCH' | 'DELETE';
  path: string;
  access: Access;
  /** Return the fresh player state alongside the result so the client can update in one round trip. */
  withMe?: boolean;
  handler: (ctx: { v: Viewer; body: Body; params: Record<string, string>; url: URL }) => Promise<unknown>;
}

const routes: Route[] = [
  { method: 'GET', path: '/api/me', access: 'user', handler: ({ v }) => buildMe(v) },
  // A pass for the live-updates WebSocket (/api/live, served by the Worker).
  { method: 'GET', path: '/api/live/ticket', access: 'user', handler: async ({ v }) => {
    // Only the Cloudflare Worker serves the socket; elsewhere (local dev) the app keeps polling.
    return { ticket: env('LIVE_UPDATES') === '1' ? liveTicket(v.id) : null };
  } },
  {
    method: 'GET',
    path: '/api/catalog',
    access: 'user',
    handler: () =>
      cachedCatalog(async () => {
        // In parallel: every await here is a round trip to the database.
        const [settings, brainrots, cases, sections, topDrop] = await Promise.all([getSettings(), allBrainrots(), allCases(false), caseSections(), topDrop24h()]);
        return {
          brainrots,
          cases,
          sections,
          topDrop,
          // Admin «Приём пополнений», the global announcement, the events and «Щелчок» ride with the catalog, so a
          // change reaches every open app at once. All are admin writes: they bump the catalog version and bust this
          // cache. (An event's end is a time: the app compares it with its clock.)
          depositOpen: settings.depositOpen,
          announcement: settings.announcement,
          events: eventsOf(settings),
          snap: settings.snap,
          // «Небо Meowl» while it runs (its seed draws the map and the coins in the app).
          sky: settings.sky.run,
          // «Игра Кальмара» from its start until it is settled (the invite in every open app).
          squid: settings.squid,
          // «Анонс в игре»: every open app shows a fresh one on top.
          shout: settings.shout,
        };
      }),
  },
  { method: 'GET', path: '/api/history', access: 'user', handler: ({ v }) => games.history(v) },
  { method: 'GET', path: '/api/withdrawals', access: 'user', handler: ({ v }) => withdrawals.myWithdrawals(v) },
  { method: 'POST', path: '/api/withdrawals', access: 'user', withMe: true, handler: ({ v, body }) => withdrawals.createWithdrawal(v, body) },
  { method: 'GET', path: '/api/withdrawals/current', access: 'user', handler: ({ v }) => withdrawals.currentWithdrawal(v) },
  { method: 'POST', path: '/api/withdrawals/exchange', access: 'user', withMe: true, handler: ({ v, body }) => withdrawals.exchangeItems(v, body) },
  { method: 'POST', path: '/api/withdrawals/:id/cancel', access: 'user', withMe: true, handler: ({ v, params }) => withdrawals.cancelWithdrawal(v, params.id!) },
  { method: 'POST', path: '/api/shop/buy', access: 'user', withMe: true, handler: ({ v, body }) => games.buy(v, body) },
  { method: 'POST', path: '/api/inventory/sell', access: 'user', withMe: true, handler: ({ v, body }) => games.sell(v, body) },
  { method: 'POST', path: '/api/upgrade', access: 'user', withMe: true, handler: ({ v, body }) => games.upgrade(v, body) },
  { method: 'POST', path: '/api/dice', access: 'user', withMe: true, handler: ({ v, body }) => games.dice(v, body) },
  { method: 'GET', path: '/api/drops/live', access: 'user', handler: () => recentDrops() },
  { method: 'POST', path: '/api/case/open', access: 'user', withMe: true, handler: ({ v, body }) => games.openCase(v, body) },
  { method: 'GET', path: '/api/case/opened/:requestId', access: 'user', withMe: true, handler: ({ v, params }) => games.openedCase(v, params.requestId!) },
  { method: 'POST', path: '/api/crash/start', access: 'user', withMe: true, handler: ({ v, body }) => startCrash(v, body) },
  { method: 'POST', path: '/api/crash/wait', access: 'user', withMe: true, handler: ({ v, body }) => waitCrash(v, body) },
  { method: 'POST', path: '/api/crash/cashout', access: 'user', withMe: true, handler: ({ v, body }) => cashOutCrash(v, body) },
  { method: 'GET', path: '/api/tacos', access: 'user', handler: ({ v }) => tacos.tacosState(v) },
  { method: 'POST', path: '/api/tacos/catch', access: 'user', withMe: true, handler: ({ v }) => tacos.catchTaco(v) },
  { method: 'GET', path: '/api/squid', access: 'user', handler: ({ v }) => squid.squidState(v) },
  { method: 'GET', path: '/api/squid/mine', access: 'user', handler: ({ v }) => squid.squidMine(v) },
  { method: 'POST', path: '/api/squid/settle', access: 'user', handler: () => squid.settleSquid() },
  { method: 'GET', path: '/api/sky', access: 'user', handler: ({ v }) => sky.skyState(v) },
  { method: 'POST', path: '/api/sky/join', access: 'user', handler: ({ v }) => sky.joinSky(v) },
  { method: 'GET', path: '/api/sky/ticket', access: 'user', handler: ({ v }) => sky.skyTicket(v) },
  { method: 'POST', path: '/api/sky/pick', access: 'user', handler: ({ v, body }) => sky.skyPick(v, body) },
  { method: 'GET', path: '/api/fuse', access: 'user', handler: ({ v }) => fuseState(v) },
  { method: 'POST', path: '/api/fuse', access: 'user', withMe: true, handler: ({ v, body }) => runFuse(v, body) },
  { method: 'GET', path: '/api/road', access: 'user', handler: ({ v }) => roadState(v) },
  { method: 'POST', path: '/api/road/start', access: 'user', withMe: true, handler: ({ v, body }) => startRoad(v, body) },
  { method: 'POST', path: '/api/road/step', access: 'user', withMe: true, handler: ({ v }) => stepRoad(v) },
  { method: 'POST', path: '/api/road/cashout', access: 'user', withMe: true, handler: ({ v }) => cashoutRoad(v) },
  { method: 'POST', path: '/api/legal/accept', access: 'user', withMe: true, handler: ({ v, body }) => acceptTerms(v, body) },
  { method: 'POST', path: '/api/onboarding', access: 'user', withMe: true, handler: ({ v }) => finishOnboarding(v) },
  { method: 'GET', path: '/api/ranks', access: 'user', handler: ({ v }) => rankState(v) },
  { method: 'POST', path: '/api/ranks/:level/claim', access: 'user', withMe: true, handler: ({ v, params }) => claimRankGift(v, params.level) },
  { method: 'GET', path: '/api/quests', access: 'user', handler: ({ v }) => questsState(v) },
  { method: 'POST', path: '/api/quests/:id/claim', access: 'user', withMe: true, handler: ({ v, params }) => claimQuest(v, params.id!) },
  { method: 'POST', path: '/api/share/win', access: 'user', handler: ({ v }) => shareWin(v) },
  { method: 'GET', path: '/api/mines', access: 'user', handler: ({ v }) => minesState(v) },
  { method: 'POST', path: '/api/mines/start', access: 'user', withMe: true, handler: ({ v, body }) => startMines(v, body) },
  { method: 'POST', path: '/api/mines/pick', access: 'user', withMe: true, handler: ({ v, body }) => pickMines(v, body) },
  { method: 'POST', path: '/api/mines/cashout', access: 'user', withMe: true, handler: ({ v }) => cashoutMines(v) },
  { method: 'GET', path: '/api/giveaways', access: 'user', handler: () => giveaways.listGiveaways() },
  { method: 'GET', path: '/api/giveaways/:id', access: 'user', handler: ({ v, params }) => giveaways.giveawayDetail(v, params.id!) },
  { method: 'POST', path: '/api/giveaways/:id/join', access: 'user', handler: ({ v, params }) => giveaways.joinGiveaway(v, params.id!) },
  { method: 'POST', path: '/api/promo', access: 'user', withMe: true, handler: ({ v, body }) => games.activatePromo(v, body) },
  { method: 'POST', path: '/api/stars/invoice', access: 'user', handler: ({ v, body }) => stars.createInvoice(v, body) },
  {
    method: 'GET',
    path: '/api/deposit-promo',
    access: 'user',
    handler: ({ v, url }) => checkDepositPromo(v.id, url.searchParams.get('code'), url.searchParams.get('via')),
  },
  { method: 'GET', path: '/api/stars/orders/:id', access: 'user', handler: ({ v, params }) => stars.orderStatus(v, params.id!) },
  // Crypto deposits through @CryptoBot (iteration 38).
  { method: 'GET', path: '/api/crypto', access: 'user', handler: () => cryptoPay.cryptoInfo() },
  { method: 'POST', path: '/api/crypto/invoice', access: 'user', handler: ({ v, body }) => cryptoPay.createCryptoInvoice(v, body) },
  { method: 'GET', path: '/api/crypto/orders/:id', access: 'user', handler: ({ v, params }) => cryptoPay.cryptoOrderStatus(v, params.id!) },
  // Before /:publicId: «search» would match it too.
  { method: 'GET', path: '/api/players/search', access: 'user', handler: ({ v, url }) => searchPlayers(v, url.searchParams.get('q')) },
  { method: 'GET', path: '/api/players/:publicId', access: 'user', handler: ({ params }) => publicProfile(params.publicId!) },
  { method: 'POST', path: '/api/item-deposits', access: 'user', handler: ({ v, body }) => deposits.createItemDeposit(v, body) },
  { method: 'GET', path: '/api/item-deposits/current', access: 'user', handler: ({ v }) => deposits.currentItemDeposit(v) },
  { method: 'GET', path: '/api/item-deposits/catalog', access: 'user', handler: () => depositList.depositCatalog() },
  { method: 'GET', path: '/api/bonuses', access: 'user', handler: ({ v }) => bonuses.bonusSummary(v) },
  { method: 'POST', path: '/api/bonuses/cashback', access: 'user', withMe: true, handler: ({ v }) => bonuses.claimCashback(v) },
  { method: 'POST', path: '/api/consolations/:id/open', access: 'user', withMe: true, handler: ({ v, params }) => bonuses.openConsolation(v, params.id!) },
  { method: 'GET', path: '/api/referrals', access: 'user', handler: ({ v }) => referrals.referralSummary(v) },
  { method: 'GET', path: '/api/referrals/friends', access: 'user', handler: ({ v }) => referrals.referralFriends(v) },
  { method: 'POST', path: '/api/referrals/transfer', access: 'user', withMe: true, handler: ({ v }) => referrals.transferRefBalance(v) },
  { method: 'POST', path: '/api/referrals/code', access: 'user', handler: ({ v, body }) => referrals.setRefCode(v, body) },
  { method: 'GET', path: '/api/referrals/promos', access: 'user', handler: ({ v }) => referrals.userPromos(v) },
  { method: 'POST', path: '/api/referrals/promos', access: 'user', withMe: true, handler: ({ v, body }) => referrals.createUserPromo(v, body) },
  { method: 'DELETE', path: '/api/referrals/promos/:id', access: 'user', withMe: true, handler: ({ v, params }) => referrals.deleteUserPromo(v, params.id!) },
  { method: 'GET', path: '/api/free-case/gate', access: 'user', handler: ({ v }) => freeGate.freeGateState(v) },
  { method: 'POST', path: '/api/free-case/share', access: 'user', handler: ({ v }) => freeGate.prepareShare(v) },
  { method: 'POST', path: '/api/free-case/share/confirm', access: 'user', handler: ({ v, body }) => freeGate.confirmShare(v, body) },
  { method: 'POST', path: '/api/item-deposits/:id/cancel', access: 'user', handler: ({ v, params }) => deposits.cancelItemDeposit(v, params.id!) },
  { method: 'GET', path: '/api/battles', access: 'user', handler: ({ v }) => battles.listBattles(v) },
  { method: 'POST', path: '/api/battles', access: 'user', withMe: true, handler: ({ v, body }) => battles.createBattle(v, body) },
  { method: 'GET', path: '/api/battles/:id', access: 'user', handler: ({ v, params }) => battles.getBattle(v, params.id!) },
  { method: 'POST', path: '/api/battles/:id/join', access: 'user', withMe: true, handler: ({ v, params }) => battles.joinBattle(v, params.id!) },
  { method: 'POST', path: '/api/battles/:id/cancel', access: 'user', withMe: true, handler: ({ v, params }) => battles.cancelBattle(v, params.id!) },

  { method: 'GET', path: '/api/admin/stats', access: 'admin', handler: () => admin.stats() },
  { method: 'GET', path: '/api/admin/users', access: 'admin', handler: ({ url }) => admin.searchUsers(url.searchParams.get('q')) },
  { method: 'GET', path: '/api/admin/users/:id', access: 'admin', handler: ({ params }) => admin.userDetail(params.id!) },
  { method: 'GET', path: '/api/admin/users/:id/audit', access: 'admin', handler: ({ v, params }) => audit.playerAudit(v, params.id!) },
  { method: 'POST', path: '/api/admin/give', access: 'admin', handler: ({ v, body }) => admin.give(v, body) },
  { method: 'POST', path: '/api/admin/users/:id/partner', access: 'admin', handler: ({ v, params, body }) => setPartner(v, params.id!, body) },
  { method: 'GET', path: '/api/pass', access: 'user', handler: ({ v }) => pass.passState(v) },
  { method: 'POST', path: '/api/pass/claim', access: 'user', withMe: true, handler: ({ v, body }) => pass.claimPass(v, body) },
  { method: 'POST', path: '/api/pass/buy', access: 'user', handler: ({ v }) => pass.buyPlus(v) },
  { method: 'GET', path: '/api/pass/orders/:id', access: 'user', handler: ({ v, params }) => pass.passOrderStatus(v, params.id!) },
  { method: 'POST', path: '/api/admin/shout', access: 'admin', handler: ({ v, body }) => admin.shout(v, body) },
  { method: 'POST', path: '/api/admin/okup-cut', access: 'admin', handler: ({ v, body }) => admin.setOkupCut(v, body) },
  { method: 'POST', path: '/api/admin/top-drop/reset', access: 'admin', handler: ({ v }) => admin.resetTopDrop(v) },
  { method: 'POST', path: '/api/admin/immortal', access: 'admin', handler: ({ v, body }) => admin.setImmortal(v, body) },
  { method: 'POST', path: '/api/admin/users/:id/wager/clear', access: 'admin', handler: ({ v, params }) => admin.clearWager(v, params.id!) },
  { method: 'GET', path: '/api/admin/economy', access: 'admin', handler: ({ v }) => economyReport(v) },
  { method: 'GET', path: '/api/admin/sources', access: 'admin', handler: ({ v }) => listSources(v) },
  { method: 'POST', path: '/api/admin/sources', access: 'admin', handler: ({ v, body }) => createSource(v, body) },
  { method: 'POST', path: '/api/admin/take', access: 'admin', handler: ({ v, body }) => admin.take(v, body) },
  { method: 'POST', path: '/api/admin/punish', access: 'admin', handler: ({ v, body }) => admin.punish(v, body) },
  { method: 'GET', path: '/api/admin/punishments', access: 'admin', handler: () => admin.punishments() },
  { method: 'POST', path: '/api/admin/punishments/:id/revoke', access: 'admin', handler: ({ v, params }) => admin.revokePunishment(v, params.id!) },
  { method: 'GET', path: '/api/admin/promos', access: 'admin', handler: () => admin.promos() },
  { method: 'POST', path: '/api/admin/promos', access: 'admin', handler: ({ v, body }) => admin.createPromo(v, body) },
  { method: 'DELETE', path: '/api/admin/promos/:id', access: 'admin', handler: ({ v, params }) => admin.deletePromo(v, params.id!) },
  { method: 'GET', path: '/api/admin/media', access: 'admin', handler: () => admin.mediaList() },
  { method: 'POST', path: '/api/admin/media', access: 'admin', handler: ({ v, body }) => admin.setMedia(v, body) },
  { method: 'DELETE', path: '/api/admin/media/:id', access: 'admin', handler: ({ v, params }) => admin.removeMedia(v, params.id!) },
  { method: 'GET', path: '/api/admin/settings', access: 'admin', handler: () => admin.readSettings() },
  { method: 'GET', path: '/api/admin/sky', access: 'admin', handler: () => sky.adminSky() },
  { method: 'GET', path: '/api/admin/squid', access: 'admin', handler: () => squid.adminSquid() },
  { method: 'POST', path: '/api/admin/squid/start', access: 'admin', handler: ({ v, body }) => squid.adminSquidStart(v, body) },
  { method: 'POST', path: '/api/admin/squid/cancel', access: 'admin', handler: ({ v }) => squid.adminSquidCancel(v) },
  { method: 'POST', path: '/api/admin/sky/start', access: 'admin', handler: ({ v, body }) => sky.adminSkyStart(v, body) },
  { method: 'POST', path: '/api/admin/sky/config', access: 'admin', handler: ({ v, body }) => sky.adminSkyConfig(v, body) },
  { method: 'POST', path: '/api/admin/sky/stop', access: 'admin', handler: ({ v }) => sky.adminSkyStop(v) },
  { method: 'POST', path: '/api/admin/sky/eggs', access: 'admin', handler: ({ v, body }) => sky.adminSkyEggs(v, body) },
  { method: 'POST', path: '/api/admin/settings', access: 'admin', handler: ({ v, body }) => admin.updateSettings(v, body) },
  { method: 'GET', path: '/api/admin/brainrots', access: 'admin', handler: () => admin.adminBrainrots() },
  { method: 'POST', path: '/api/admin/brainrots', access: 'admin', handler: ({ v, body }) => admin.createBrainrot(v, body) },
  { method: 'PATCH', path: '/api/admin/brainrots/:id', access: 'admin', handler: ({ v, params, body }) => admin.updateBrainrot(v, params.id!, body) },
  { method: 'DELETE', path: '/api/admin/brainrots/:id', access: 'admin', handler: ({ v, params }) => admin.deleteBrainrot(v, params.id!) },
  { method: 'POST', path: '/api/admin/upload', access: 'admin', handler: ({ v, body }) => admin.upload(v, body) },
  { method: 'GET', path: '/api/admin/titles', access: 'admin', handler: () => admin.titles() },
  { method: 'POST', path: '/api/admin/titles', access: 'admin', handler: ({ v, body }) => admin.createTitle(v, body) },
  { method: 'PATCH', path: '/api/admin/titles/:id', access: 'admin', handler: ({ v, params, body }) => admin.updateTitle(v, params.id!, body) },
  { method: 'DELETE', path: '/api/admin/titles/:id', access: 'admin', handler: ({ v, params }) => admin.deleteTitle(v, params.id!) },
  { method: 'GET', path: '/api/admin/titles/:id/holders', access: 'admin', handler: ({ params }) => admin.titleHolders(params.id!) },
  { method: 'POST', path: '/api/admin/titles/:id/grant', access: 'admin', handler: ({ v, params, body }) => admin.grantTitle(v, params.id!, body) },
  { method: 'POST', path: '/api/admin/titles/:id/revoke', access: 'admin', handler: ({ v, params, body }) => admin.revokeTitle(v, params.id!, body) },
  { method: 'GET', path: '/api/admin/cases', access: 'admin', handler: () => admin.adminCases() },
  { method: 'POST', path: '/api/admin/cases', access: 'admin', handler: ({ v, body }) => admin.createCase(v, body) },
  { method: 'PATCH', path: '/api/admin/cases/:id', access: 'admin', handler: ({ v, params, body }) => admin.updateCase(v, params.id!, body) },
  { method: 'DELETE', path: '/api/admin/cases/:id', access: 'admin', handler: ({ v, params }) => admin.deleteCase(v, params.id!) },
  { method: 'POST', path: '/api/admin/cases/:id/recompose', access: 'admin', handler: ({ v, params }) => admin.recomposeCase(v, params.id!) },
  { method: 'GET', path: '/api/admin/case-configs', access: 'admin', handler: () => listCaseConfigs() },
  { method: 'POST', path: '/api/admin/case-configs', access: 'admin', handler: ({ v, body }) => saveCaseConfig(v, body) },
  { method: 'POST', path: '/api/admin/case-configs/:id/load', access: 'admin', handler: ({ v, params, body }) => loadCaseConfig(v, params.id!, body) },
  { method: 'DELETE', path: '/api/admin/case-configs/:id', access: 'admin', handler: ({ v, params }) => deleteCaseConfig(v, params.id!) },
  { method: 'GET', path: '/api/admin/sections', access: 'admin', handler: () => admin.adminSections() },
  { method: 'POST', path: '/api/admin/sections', access: 'admin', handler: ({ v, body }) => admin.createSection(v, body) },
  { method: 'PATCH', path: '/api/admin/sections/:id', access: 'admin', handler: ({ v, params, body }) => admin.updateSection(v, params.id!, body) },
  { method: 'DELETE', path: '/api/admin/sections/:id', access: 'admin', handler: ({ v, params }) => admin.deleteSection(v, params.id!) },
  { method: 'GET', path: '/api/admin/withdrawals', access: 'admin', handler: ({ url }) => withdrawals.adminWithdrawals(url.searchParams.get('status')) },
  { method: 'POST', path: '/api/admin/withdrawals/:id', access: 'admin', handler: ({ v, params, body }) => withdrawals.adminWithdrawalAction(v, params.id!, body) },
  { method: 'GET', path: '/api/admin/admins', access: 'admin', handler: () => admin.admins() },
  { method: 'POST', path: '/api/admin/admins', access: 'admin', handler: ({ v, body }) => admin.addAdmin(v, body) },
  { method: 'DELETE', path: '/api/admin/admins/:id', access: 'admin', handler: ({ v, params }) => admin.removeAdmin(v, params.id!) },
  { method: 'GET', path: '/api/admin/logs', access: 'admin', handler: () => admin.logs() },
  { method: 'GET', path: '/api/admin/payments', access: 'admin', handler: () => stars.adminPayments() },
  { method: 'GET', path: '/api/admin/crypto', access: 'admin', handler: () => cryptoPay.adminCryptoPayments() },
  { method: 'GET', path: '/api/admin/item-deposits', access: 'admin', handler: ({ url }) => deposits.adminItemDeposits(url.searchParams.get('status')) },
  { method: 'POST', path: '/api/admin/item-deposits/:id', access: 'admin', handler: ({ v, params, body }) => deposits.adminItemDepositAction(v, params.id!, body) },
  { method: 'GET', path: '/api/admin/broadcasts', access: 'admin', handler: () => admin.broadcasts() },
  { method: 'POST', path: '/api/admin/announce', access: 'admin', handler: ({ v, body }) => admin.announce(v, body) },
  { method: 'POST', path: '/api/admin/broadcasts/:id/stop', access: 'admin', handler: ({ v, params }) => admin.stopAnnounce(v, params.id!) },
  { method: 'GET', path: '/api/admin/danger', access: 'admin', handler: ({ v }) => danger.dangerInfo(v) },
  { method: 'POST', path: '/api/admin/danger/reset', access: 'admin', handler: ({ v, body }) => danger.resetPlayer(v, body) },
  { method: 'POST', path: '/api/admin/danger/wipe', access: 'admin', handler: ({ v, body }) => danger.wipeAllPlayers(v, body) },
  { method: 'POST', path: '/api/admin/danger/reset-eggs', access: 'admin', handler: ({ v, body }) => danger.resetEggPlayers(v, body) },
  { method: 'GET', path: '/api/admin/free-gate', access: 'admin', handler: () => freeGate.adminFreeGate() },
  { method: 'GET', path: '/api/admin/giveaways', access: 'admin', handler: () => giveaways.adminGiveaways() },
  { method: 'POST', path: '/api/admin/giveaways', access: 'admin', handler: ({ v, body }) => giveaways.createGiveaway(v, body) },
  { method: 'PATCH', path: '/api/admin/giveaways/:id', access: 'admin', handler: ({ v, params, body }) => giveaways.updateGiveaway(v, params.id!, body) },
  { method: 'POST', path: '/api/admin/giveaways/:id/settle', access: 'admin', handler: ({ v, params }) => giveaways.settleGiveawayNow(v, params.id!) },
  { method: 'POST', path: '/api/admin/giveaways/:id/cancel', access: 'admin', handler: ({ v, params }) => giveaways.cancelGiveaway(v, params.id!) },
  { method: 'GET', path: '/api/admin/deposit-items', access: 'admin', handler: () => depositList.adminDepositItems() },
  { method: 'POST', path: '/api/admin/deposit-items', access: 'admin', handler: ({ v, body }) => depositList.addDepositItem(v, body) },
  { method: 'PATCH', path: '/api/admin/deposit-items/:id', access: 'admin', handler: ({ v, params, body }) => depositList.updateDepositItem(v, params.id!, body) },
  { method: 'DELETE', path: '/api/admin/deposit-items/:id', access: 'admin', handler: ({ v, params }) => depositList.removeDepositItem(v, params.id!) },
];

const compiled = routes.map((r) => ({
  ...r,
  regex: new RegExp(`^${r.path.replace(/:(\w+)/g, '(?<$1>[^/]+)')}$`),
}));

const json = (data: unknown, status = 200) =>
  new Response(JSON.stringify(data), { status, headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' } });

const MAX_BODY = 2_500_000;

export async function handle(req: Request): Promise<Response> {
  const url = new URL(req.url);
  // The Worker's own migrations before anything reads their tables (one query per isolate, then a flag). A failure
  // is logged, not answered: routes that don't touch the new tables keep working.
  await ensureSchema().catch((e) => console.error('auto-migrate', e));
  const img = /^\/api\/img\/([^/]+)$/.exec(url.pathname);
  if (img && req.method === 'GET') return serveUpload(img[1]!);
  // CryptoBot's invoice updates: authenticated by their HMAC signature (server/crypto.ts), not by initData.
  if (url.pathname === '/api/crypto/webhook' && req.method === 'POST') {
    try {
      return await cryptoPay.cryptoWebhook(req);
    } catch (e) {
      console.error('crypto webhook error', e);
      return json({ error: 'server_error' }, 500);
    }
  }
  // Telegram's own calls: authenticated by the webhook secret header, not by initData.
  if (url.pathname === '/api/telegram/webhook' && req.method === 'POST') {
    try {
      return await stars.handleWebhook(req);
    } catch (e) {
      console.error('webhook error', e);
      return json({ error: 'server_error' }, 500);
    }
  }

  const pathMatches = compiled.filter((r) => r.regex.test(url.pathname));
  if (!pathMatches.length) return json({ error: 'not_found', message: 'Нет такого адреса' }, 404);
  const route = pathMatches.find((r) => r.method === req.method);
  if (!route) return json({ error: 'method_not_allowed', message: 'Метод не поддерживается' }, 405);
  const params = { ...(route.regex.exec(url.pathname)?.groups ?? {}) };

  try {
    let body: Body = {};
    if (req.method !== 'GET') {
      const text = await req.text();
      if (text.length > MAX_BODY) throw new HttpError(413, 'too_large', 'Слишком большой запрос');
      if (text) {
        try {
          body = JSON.parse(text) as Body;
        } catch {
          throw new HttpError(400, 'bad_json', 'Неверный формат запроса');
        }
        if (!body || typeof body !== 'object' || Array.isArray(body)) throw new HttpError(400, 'bad_json', 'Неверный формат запроса');
      }
    }
    const v = await authenticate(req, { refreshProfile: url.pathname === '/api/me' });
    markViewer(v.id);
    // Anti-spam: every action (not a read) counts against the player's per-second budget.
    if (req.method !== 'GET') rateLimit(`act:${v.id}`, ACTION_LIMIT);
    if (route.access === 'admin' && !v.isAdmin) throw forbidden();
    // A frozen admin keeps the account but not the panel (owners can't be punished).
    if (route.access === 'admin' && v.frozen && !v.isOwner) throw forbidden('Аккаунт заморожен — админка недоступна');
    const result = await route.handler({ v, body, params, url });
    // Any admin edit can change what players see (names, prices, chances, cases, themes): refresh every open app.
    if (route.access === 'admin' && req.method !== 'GET') {
      await bumpCatalogVersion();
      broadcast('catalog');
    }
    if (route.withMe) return json({ result, me: await buildMe(v) });
    return json(result);
  } catch (e) {
    if (e instanceof HttpError) return json({ error: e.code, message: e.message, ...e.data }, e.status);
    console.error('api error', url.pathname, e);
    return json({ error: 'server_error', message: 'Ошибка сервера, попробуй ещё раз' }, 500);
  }
}
