import { ms, num, one, q } from './db';
import { notFound } from './errors';
import { publicName } from './catalog';
import { userTitles } from './me';
import type { UserRow } from './users';
import type { Viewer } from './auth';
import { SEARCH_LIMIT, rateLimit } from './rateLimit';
import { notStaff } from './staff';

/** What any player may see about another one: no balance, no Telegram ID. */
export async function publicProfile(publicId: string) {
  if (!/^[A-Z2-9]{10}$/.test(publicId)) throw notFound('Игрок не найден');
  const user = await one<UserRow>('SELECT * FROM users WHERE public_id = $1', [publicId]);
  if (!user) throw notFound('Игрок не найден');
  const id = num(user.id);
  const [titles, best, inventory] = await Promise.all([
    userTitles(id),
    one<{ brainrot_id: string; created_at: string }>(
      `SELECT d.brainrot_id, d.created_at FROM drops d JOIN brainrots b ON b.id = d.brainrot_id
       WHERE d.user_id = $1 AND d.result = 'win' AND NOT d.demo ORDER BY b.price DESC, d.created_at DESC LIMIT 1`,
      [id],
    ),
    q<{ brainrot_id: string; count: string; demo: string }>(
      `SELECT i.brainrot_id, count(*) AS count, count(*) FILTER (WHERE i.demo) AS demo FROM inventory i JOIN brainrots b ON b.id = i.brainrot_id
       WHERE i.user_id = $1 GROUP BY i.brainrot_id, b.price ORDER BY b.price DESC LIMIT 60`,
      [id],
    ),
  ]);
  return {
    publicId: user.public_id,
    // Other players never get the @username — only the name the player set in Telegram.
    name: publicName(user),
    photoUrl: user.photo_url,
    media: user.media_platform,
    titles,
    joinedAt: ms(user.created_at)!,
    bestDrop: best ? { brainrotId: best.brainrot_id, at: ms(best.created_at)! } : null,
    stats: {
      casesOpened: user.cases_opened,
      upgrades: user.upgrades,
      diceRolls: user.dice_rolls,
      crashRounds: user.crash_rounds,
      withdrawn: num(user.withdrawn_value),
    },
    // `demo`: how many of them are «ДЕМО» (an admin's gift or won with one) — viewers see what isn't really theirs.
    inventory: inventory.map((i) => ({ brainrotId: i.brainrot_id, count: num(i.count), demo: num(i.demo) })),
  };
}

export type PublicProfile = Awaited<ReturnType<typeof publicProfile>>;

/**
 * «Найти игрока» in the profile: by the Telegram name (part of it), the profile ID or the exact @username — the
 * username only finds, it is never sent back (others see the name, photo and profile ID, as the privacy policy says).
 * Staff aren't players, so they never show up. 10 searches per 10 seconds per player.
 */
export async function searchPlayers(v: Viewer, raw: string | null) {
  rateLimit(`search:${v.id}`, SEARCH_LIMIT);
  const s = (raw ?? '').trim().replace(/^@/, '').slice(0, 40);
  if (s.length < 2) return [];
  const like = `%${s.toLowerCase().replace(/[\\%_]/g, (c) => `\\${c}`)}%`;
  const rows = await q<{ public_id: string; first_name: string; last_name: string | null; photo_url: string | null }>(
    `SELECT u.public_id, u.first_name, u.last_name, u.photo_url FROM users u
     WHERE ${notStaff('u.id')} AND (
       u.public_id = upper($1) OR u.username_lc = lower($1)
       OR lower(u.first_name || ' ' || coalesce(u.last_name, '')) LIKE $2)
     ORDER BY (u.public_id = upper($1) OR u.username_lc = lower($1)) DESC, u.last_seen_at DESC NULLS LAST
     LIMIT 10`,
    [s, like],
  );
  return rows.map((r) => ({ publicId: r.public_id, name: publicName(r), photoUrl: r.photo_url }));
}
