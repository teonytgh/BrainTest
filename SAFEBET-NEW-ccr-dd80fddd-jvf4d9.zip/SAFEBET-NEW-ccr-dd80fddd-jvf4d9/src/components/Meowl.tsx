import type { CSSProperties } from 'react';
import { cx } from '../lib/format';
import layout from '../lib/meowl-layout.json';

const pct = (v: number) => `${((v / layout.size) * 100).toFixed(2)}%`;
const WING_L: CSSProperties = { transformOrigin: `${pct(layout.pivots['wing-l'].x)} ${pct(layout.pivots['wing-l'].y)}` };
const WING_R: CSSProperties = { transformOrigin: `${pct(layout.pivots['wing-r'].x)} ${pct(layout.pivots['wing-r'].y)}` };

/**
 * Meowl, the guide of the first-visit tour: the Blender layers of scripts/blender/meowl.py (public/meowl) stacked on
 * one square and brought to life in CSS (src/styles/meowl.css) — he breathes, sways, flaps his wings around the
 * shoulders, blinks now and then and moves his mouth while `talking`. Transform/opacity only; still with reduced motion.
 */
export function Meowl({ size = 120, talking = false, className }: { size?: number; talking?: boolean; className?: string }) {
  return (
    <span className={cx('meowl', talking && 'is-talking', className)} style={{ width: size, height: size }} aria-hidden="true">
      <span className="meowl__shadow" />
      <span className="meowl__rig">
        <img className="meowl__wing meowl__wing--l" src="/meowl/wing-l.webp" alt="" style={WING_L} draggable={false} />
        <img className="meowl__wing meowl__wing--r" src="/meowl/wing-r.webp" alt="" style={WING_R} draggable={false} />
        <img className="meowl__body" src="/meowl/body.webp" alt="" draggable={false} />
        <img className="meowl__blink" src="/meowl/blink.webp" alt="" draggable={false} />
        <img className="meowl__talk" src="/meowl/talk.webp" alt="" draggable={false} />
      </span>
    </span>
  );
}
