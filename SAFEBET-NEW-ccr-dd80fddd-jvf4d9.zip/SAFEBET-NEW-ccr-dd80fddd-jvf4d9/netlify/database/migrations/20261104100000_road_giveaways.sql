-- Iteration 27: «Дорога» (a Chicken Road-like crossing on brainrot stakes), admin-made giveaways and the
-- «Крупные приглашения» milestones.

-- Every player's next road key: its sha256 is shown before the stake, the key itself when the run ends. Lane k is a
-- crash when the first 32 bits of sha256('road:' || seed || ':' || k) / 2^32 fall below the level's risk.
CREATE TABLE road_seeds (
  user_id BIGINT PRIMARY KEY REFERENCES users (id),
  seed TEXT NOT NULL,
  hash TEXT NOT NULL,
  nonce INT NOT NULL DEFAULT 0
);

-- One run per stake; the stake brainrots are out of the inventory while it is active.
CREATE TABLE road_runs (
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT NOT NULL REFERENCES users (id),
  level TEXT NOT NULL CHECK (level IN ('easy', 'medium', 'hard', 'hardcore')),
  stake_value NUMERIC(16, 2) NOT NULL CHECK (stake_value > 0),
  stake JSONB NOT NULL,
  seed TEXT NOT NULL,
  hash TEXT NOT NULL,
  step INT NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'cashed', 'crashed', 'refunded')),
  payout JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  finished_at TIMESTAMPTZ
);
CREATE UNIQUE INDEX road_runs_one_active ON road_runs (user_id) WHERE status = 'active';
CREATE INDEX road_runs_stale ON road_runs (updated_at) WHERE status = 'active';
CREATE INDEX drops_road_top ON drops (payout_value DESC) WHERE game = 'road';

-- Giveaways made by admins: a deposit race, an invite race or a plain draw; prizes are catalog brainrots per place.
CREATE TABLE giveaways (
  id BIGSERIAL PRIMARY KEY,
  kind TEXT NOT NULL CHECK (kind IN ('deposit_race', 'referral_race', 'draw')),
  title TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  conditions TEXT NOT NULL DEFAULT '',
  banner TEXT,
  starts_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  ends_at TIMESTAMPTZ NOT NULL,
  -- Races: the friend's net deposits in the period an invite needs to count; draw: the player's own.
  min_deposit NUMERIC(16, 2) NOT NULL DEFAULT 0 CHECK (min_deposit >= 0),
  need_channel BOOLEAN NOT NULL DEFAULT false,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'finished', 'cancelled')),
  created_by BIGINT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  settled_at TIMESTAMPTZ,
  CHECK (ends_at > starts_at)
);
CREATE INDEX giveaways_due ON giveaways (ends_at) WHERE status = 'active';

CREATE TABLE giveaway_prizes (
  giveaway_id BIGINT NOT NULL REFERENCES giveaways (id) ON DELETE CASCADE,
  place INT NOT NULL CHECK (place BETWEEN 1 AND 10),
  brainrot_id TEXT NOT NULL REFERENCES brainrots (id),
  PRIMARY KEY (giveaway_id, place)
);

CREATE TABLE giveaway_entries (
  giveaway_id BIGINT NOT NULL REFERENCES giveaways (id) ON DELETE CASCADE,
  user_id BIGINT NOT NULL REFERENCES users (id),
  joined_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (giveaway_id, user_id)
);

CREATE TABLE giveaway_winners (
  giveaway_id BIGINT NOT NULL REFERENCES giveaways (id) ON DELETE CASCADE,
  place INT NOT NULL,
  user_id BIGINT NOT NULL REFERENCES users (id),
  brainrot_id TEXT NOT NULL,
  item_id BIGINT,
  score NUMERIC(16, 2),
  PRIMARY KEY (giveaway_id, place)
);

-- «Крупные приглашения»: a referrer is paid once per friend per threshold of the friend's net deposits.
CREATE TABLE ref_milestones (
  referral_id BIGINT NOT NULL REFERENCES users (id),
  step INT NOT NULL,
  referrer_id BIGINT NOT NULL REFERENCES users (id),
  amount NUMERIC(16, 2) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (referral_id, step)
);
ALTER TABLE ref_payouts DROP CONSTRAINT IF EXISTS ref_payouts_kind_check;
ALTER TABLE ref_payouts ADD CONSTRAINT ref_payouts_kind_check CHECK (kind IN ('revshare', 'deposit_bonus', 'milestone'));

-- Net-deposit sums per player and period (races, milestones).
CREATE INDEX IF NOT EXISTS star_payments_user ON star_payments (user_id, created_at);
CREATE INDEX IF NOT EXISTS item_deposits_credited ON item_deposits (user_id, updated_at) WHERE status = 'credited';
CREATE INDEX IF NOT EXISTS withdrawals_done ON withdrawals (user_id, processed_at) WHERE status = 'done';

DO $$
DECLARE t TEXT;
BEGIN
  FOREACH t IN ARRAY ARRAY['road_seeds', 'road_runs', 'giveaways', 'giveaway_prizes', 'giveaway_entries', 'giveaway_winners', 'ref_milestones'] LOOP
    EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', t);
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'anon') THEN
      EXECUTE format('REVOKE ALL ON %I FROM anon, authenticated', t);
    END IF;
  END LOOP;
END $$;
