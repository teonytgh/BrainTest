import type { Viewer } from './auth';
import { num, one, q, tx, type Queryable } from './db';
import { bad, notFound } from './errors';
import { money, oneOf, str, type Body } from './validate';
import { DEPOSIT_SECTIONS, DEPOSIT_SECTION_LABEL, type DepositSection } from '../shared/deposit';
import type { Brainrot, BrainrotStatus } from '../shared/types';

/** Brainrots that may be deposited: active or hidden in the catalog (hidden ones stay out of cases and the shop). */
const LISTED = `FROM deposit_items d JOIN brainrots b ON b.id = d.brainrot_id WHERE b.status IN ('active', 'hidden')`;

interface ListedRow {
  id: string;
  name: string;
  image: string;
  status: BrainrotStatus;
  catalog_price: string;
  override: string | null;
  section: DepositSection;
}

const COLUMNS = 'b.id, b.name, b.image, b.status, b.price AS catalog_price, d.price AS override, d.section';
const effective = (r: ListedRow) => num(r.override ?? r.catalog_price);

/** What the deposit picker shows: the admin's list with deposit prices (an override or the catalog price) and tabs. */
export async function depositCatalog(): Promise<(Brainrot & { section: DepositSection })[]> {
  const rows = await q<ListedRow>(`SELECT ${COLUMNS} ${LISTED}`);
  return rows
    .map((r) => ({ id: r.id, name: r.name, image: r.image, status: r.status, price: effective(r), withdrawable: true, kind: 'brainrot' as const, section: r.section }))
    .sort((a, b) => b.price - a.price || a.name.localeCompare(b.name));
}

/** Prices for a basket; ids missing from the list are simply absent from the map. */
export async function depositPrices(ids: string[]): Promise<Map<string, { name: string; price: number; section: DepositSection }>> {
  const rows = await q<ListedRow>(`SELECT ${COLUMNS} ${LISTED} AND d.brainrot_id = ANY($1::text[])`, [ids]);
  return new Map(rows.map((r) => [r.id, { name: r.name, price: effective(r), section: r.section }]));
}

// ---------- Admin ----------

export async function adminDepositItems() {
  const rows = await q<ListedRow>(`SELECT ${COLUMNS} ${LISTED}`);
  return rows
    .map((r) => ({
      brainrotId: r.id,
      name: r.name,
      image: r.image,
      catalogPrice: num(r.catalog_price),
      price: r.override === null ? null : num(r.override),
      effective: effective(r),
      section: r.section,
    }))
    .sort((a, b) => b.effective - a.effective || a.name.localeCompare(b.name));
}

async function log(c: Queryable, admin: Viewer, action: string, details: Record<string, unknown>) {
  await c.query('INSERT INTO admin_log (admin_id, action, target_user, details) VALUES ($1, $2, NULL, $3::jsonb)', [admin.id, action, JSON.stringify(details)]);
}

/** An empty price means «as in the catalog». */
const priceOrNull = (v: unknown) => (v === null || v === undefined || v === '' ? null : money(v, 'цена пополнения'));

export async function addDepositItem(admin: Viewer, body: Body) {
  const brainrotId = str(body.brainrotId, 'брейнрот', 1, 80);
  const price = priceOrNull(body.price);
  const section = body.section === undefined ? 'brainrots' : oneOf(body.section, 'раздел', DEPOSIT_SECTIONS);
  const b = await one<{ name: string }>(`SELECT name FROM brainrots WHERE id = $1 AND status IN ('active', 'hidden') AND kind = 'brainrot'`, [brainrotId]);
  if (!b) throw notFound('Брейнрот не найден в каталоге');
  await tx(async (c) => {
    const { rows } = await c.query('INSERT INTO deposit_items (brainrot_id, price, section) VALUES ($1, $2, $3) ON CONFLICT DO NOTHING RETURNING 1', [brainrotId, price, section]);
    if (!rows[0]) throw bad('exists', `${b.name} уже в списке пополнения`);
    await log(c, admin, 'deposit_item_add', { id: brainrotId, name: b.name, price, section });
  });
  return { ok: true };
}

/** A new deposit price (`price`, empty = as in the catalog) and/or a move to another tab (`section`). */
export async function updateDepositItem(admin: Viewer, idParam: string, body: Body) {
  const sets: string[] = [];
  const params: unknown[] = [idParam];
  if (body.price !== undefined) {
    params.push(priceOrNull(body.price));
    sets.push(`price = $${params.length}`);
  }
  const section = body.section === undefined ? null : oneOf(body.section, 'раздел', DEPOSIT_SECTIONS);
  if (section) {
    params.push(section);
    sets.push(`section = $${params.length}`);
  }
  if (!sets.length) throw bad('invalid', 'Нечего менять');
  await tx(async (c) => {
    const { rows } = await c.query<{ name: string }>(
      `UPDATE deposit_items d SET ${sets.join(', ')} FROM brainrots b WHERE d.brainrot_id = $1 AND b.id = d.brainrot_id RETURNING b.name`,
      params,
    );
    if (!rows[0]) throw notFound('Этого брейнрота нет в списке пополнения');
    if (body.price !== undefined) await log(c, admin, 'deposit_item_price', { id: idParam, name: rows[0].name, price: params[1] ?? 'как в каталоге' });
    if (section) await log(c, admin, 'deposit_item_section', { id: idParam, name: rows[0].name, section: DEPOSIT_SECTION_LABEL[section] });
  });
  return { ok: true };
}

export async function removeDepositItem(admin: Viewer, idParam: string) {
  await tx(async (c) => {
    const { rows } = await c.query<{ name: string }>(
      `DELETE FROM deposit_items d USING brainrots b WHERE d.brainrot_id = $1 AND b.id = d.brainrot_id RETURNING b.name`,
      [idParam],
    );
    if (!rows[0]) throw notFound('Этого брейнрота нет в списке пополнения');
    await log(c, admin, 'deposit_item_remove', { id: idParam, name: rows[0].name });
  });
  return { ok: true };
}
