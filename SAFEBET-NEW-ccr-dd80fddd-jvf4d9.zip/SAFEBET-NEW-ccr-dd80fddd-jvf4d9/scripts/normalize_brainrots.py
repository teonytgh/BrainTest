"""Puts every brainrot on the same square stage so tall and wide ones read at a similar size.

Usage: python3 scripts/normalize_brainrots.py [public/brainrots]
Each image is trimmed to its visible pixels and centred on a 480×480 transparent canvas. Tall figures are
scaled down a little more the longer they are (they used to fill the whole card height and look oversized);
wide groups keep most of the width. Already normalised files (square, with a margin) are skipped.
"""
import os
import sys

from PIL import Image

SIZE = 480


def fit_share(aspect: float) -> float:
    """Share of the canvas the longest side may take."""
    if aspect >= 1:
        return 0.94
    elongation = 1 / aspect
    return max(0.8, 0.94 - 0.1 * max(0.0, elongation - 1.15))


def normalized(im: Image.Image) -> bool:
    if im.size != (SIZE, SIZE):
        return False
    box = im.getchannel('A').point(lambda v: 255 if v > 16 else 0).getbbox()
    return bool(box) and box[0] > 2 and box[1] > 2 and box[2] < SIZE - 2 and box[3] < SIZE - 2


def normalize(path: str) -> bool:
    im = Image.open(path).convert('RGBA')
    if normalized(im):
        return False
    box = im.getchannel('A').point(lambda v: 255 if v > 16 else 0).getbbox()
    if box:
        im = im.crop(box)
    w, h = im.size
    share = fit_share(w / h)
    scale = share * SIZE / max(w, h)
    im = im.resize((max(1, round(w * scale)), max(1, round(h * scale))), Image.LANCZOS)
    canvas = Image.new('RGBA', (SIZE, SIZE), (0, 0, 0, 0))
    canvas.paste(im, ((SIZE - im.width) // 2, (SIZE - im.height) // 2), im)
    canvas.save(path, 'WEBP', quality=84, method=5)
    return True


def main():
    folder = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'public', 'brainrots')
    changed = [f for f in sorted(os.listdir(folder)) if f.endswith('.webp') and normalize(os.path.join(folder, f))]
    print(f'{len(changed)} normalised in {folder}')


main()
