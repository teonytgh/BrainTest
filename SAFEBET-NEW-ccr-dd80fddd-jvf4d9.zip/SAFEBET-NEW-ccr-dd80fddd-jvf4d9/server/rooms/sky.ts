import { SKY_HIT, SKY_HIT_COOLDOWN_MS, SKY_HIT_REACH, SKY_HP, SKY_ROOM_LIMIT, skyFight } from '../../shared/sky';
import type { JoinOpts, RoomLogic, RoomSocket } from './types';

export type { RoomSocket };

/**
 * One «Небо Meowl» run's room: who is flying and where. Pure logic over abstract sockets — the Durable Object
 * (worker/index.ts) and the local dev server only wire real WebSockets and a 250 ms timer to it.
 *
 * Players send `{t:'p', x, y, h}` (position, heading) at most ~4 times a second while they move; the room sends
 * everyone one snapshot of what moved every `flush()` (`{t:'s', p:[[id, x, y, h], …]}`), joins (`{t:'j'}`) and leaves
 * (`{t:'l'}`), and whatever the API broadcasts (a coin taken, an egg dropped, the run's end). Positions here are only
 * for drawing other players, placing eggs next to them and the sword's reach; picks are checked by the API.
 *
 * Fights (iteration 37): the last 30 s of every 3 minutes of the wall clock (`skyFight`, the same in the app). At the
 * start everyone has 100 HP (`{t:'f', on:true, until}`); `{t:'hit'}` swings the sword — the nearest flyer within reach
 * loses 20 HP (`{t:'hit', from, to, hp}`), at 0 they are knocked out (`{t:'ko', id}`) and frozen until the fight ends
 * (`{t:'f', on:false, next}`). For fun only: no coins change hands. An immortal admin (trailers) takes no damage.
 */
interface Player {
  id: number;
  name: string;
  x: number;
  y: number;
  h: number;
  sock: RoomSocket;
  dirty: boolean;
  lastMsgAt: number;
  seenAt: number;
  /** An admin's immortality for trailers (iteration 37). */
  god: boolean;
  hp: number;
  ko: boolean;
  hitAt: number;
}

/** Faster position messages than this are dropped (the client sends ~4 a second). */
const MIN_MSG_MS = 180;
const LIMIT = 1e7;
/** Positions here lag the screen by up to a message: the sword gets that much slack. */
const REACH_SLACK = 50;

export class SkyRoom implements RoomLogic {
  readonly tickMs = 250;
  private players = new Map<number, Player>();
  private fighting = false;

  constructor(private now: () => number = Date.now) {}

  get size() {
    return this.players.size;
  }

  join(id: number, name: string, sock: RoomSocket, opts: JoinOpts = {}): boolean {
    const old = this.players.get(id);
    if (!old && this.players.size >= SKY_ROOM_LIMIT) {
      sock.send(JSON.stringify({ t: 'full' }));
      sock.close(4001, 'full');
      return false;
    }
    if (old && old.sock !== sock) {
      try {
        old.sock.close(4000, 'replaced');
      } catch {
        // Already gone.
      }
    }
    const p: Player = {
      id,
      name,
      x: old?.x ?? 0,
      y: old?.y ?? 0,
      h: old?.h ?? 0,
      sock,
      dirty: false,
      lastMsgAt: 0,
      seenAt: this.now(),
      god: opts.god === true,
      hp: old?.hp ?? SKY_HP,
      ko: old?.ko ?? false,
      hitAt: 0,
    };
    this.players.set(id, p);
    const fight = skyFight(this.now());
    sock.send(
      JSON.stringify({
        t: 'w',
        you: id,
        players: [...this.players.values()].map((q) => [q.id, q.name, q.x, q.y, q.h]),
        fight: { on: this.fighting && fight.on, until: fight.until, next: fight.next },
        hp: [...this.players.values()].map((q) => [q.id, q.hp, q.ko ? 1 : 0]),
      }),
    );
    this.broadcast({ t: 'j', id, n: name, x: p.x, y: p.y }, id);
    return true;
  }

  message(id: number, sock: RoomSocket, raw: string) {
    const p = this.players.get(id);
    if (!p || p.sock !== sock || raw.length > 200) return;
    if (raw === 'ping') return sock.send('pong');
    let m: { t?: unknown; x?: unknown; y?: unknown; h?: unknown };
    try {
      m = JSON.parse(raw);
    } catch {
      return;
    }
    if (m.t === 'hit') return this.hit(p);
    if (m.t !== 'p') return;
    // Knocked out: they lie where they fell until the fight is over.
    if (p.ko) return;
    const now = this.now();
    if (now - p.lastMsgAt < MIN_MSG_MS) return;
    const x = Number(m.x);
    const y = Number(m.y);
    const h = Number(m.h);
    if (![x, y, h].every(Number.isFinite) || Math.abs(x) > LIMIT || Math.abs(y) > LIMIT) return;
    p.x = Math.round(x);
    p.y = Math.round(y);
    p.h = Math.round(h * 100) / 100;
    p.dirty = true;
    p.lastMsgAt = now;
    p.seenAt = now;
  }

  leave(id: number, sock: RoomSocket) {
    const p = this.players.get(id);
    if (!p || p.sock !== sock) return;
    this.players.delete(id);
    this.broadcast({ t: 'l', id });
  }

  tick() {
    this.fightTick();
    this.flush();
  }

  /** Starts and ends the fights on the wall clock's schedule. */
  fightTick() {
    const f = skyFight(this.now());
    if (f.on === this.fighting) return;
    this.fighting = f.on;
    for (const p of this.players.values()) {
      p.hp = SKY_HP;
      p.ko = false;
      p.hitAt = 0;
    }
    this.broadcast(f.on ? { t: 'f', on: true, until: f.until } : { t: 'f', on: false, next: f.next });
  }

  private hit(p: Player) {
    const now = this.now();
    if (!this.fighting || p.ko || now - p.hitAt < SKY_HIT_COOLDOWN_MS) return;
    p.hitAt = now;
    let target: Player | null = null;
    let best = SKY_HIT_REACH + REACH_SLACK;
    for (const q of this.players.values()) {
      if (q === p || q.ko) continue;
      const d = Math.hypot(q.x - p.x, q.y - p.y);
      if (d <= best) {
        best = d;
        target = q;
      }
    }
    this.broadcast({ t: 'sw', id: p.id });
    if (!target) return;
    if (!target.god) target.hp = Math.max(0, target.hp - SKY_HIT);
    this.broadcast({ t: 'hit', from: p.id, to: target.id, hp: target.hp });
    if (target.hp <= 0) {
      target.ko = true;
      this.broadcast({ t: 'ko', id: target.id, by: p.id });
    }
  }

  /** One snapshot of everyone who moved since the last one; returns whether anything was sent. */
  flush(): boolean {
    const moved = [...this.players.values()].filter((p) => p.dirty);
    if (!moved.length) return false;
    for (const p of moved) p.dirty = false;
    this.broadcast({ t: 's', p: moved.map((p) => [p.id, p.x, p.y, p.h]) });
    return true;
  }

  broadcast(msg: unknown, except?: number) {
    const data = JSON.stringify(msg);
    for (const p of this.players.values()) {
      if (p.id === except) continue;
      try {
        p.sock.send(data);
      } catch {
        // A socket that is closing; its close event removes it.
      }
    }
  }

  /** Where the players are now: for eggs next to everyone or to N random players. */
  targets(mode: 'all' | 'random', count = 1): { userId: number; x: number; y: number }[] {
    const live = [...this.players.values()].map((p) => ({ userId: p.id, x: p.x, y: p.y }));
    if (mode === 'all') return live;
    for (let i = live.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [live[i], live[j]] = [live[j]!, live[i]!];
    }
    return live.slice(0, Math.max(0, count));
  }

  /** Closes every socket (the run is over). */
  closeAll(reason = 'over') {
    for (const p of this.players.values()) {
      try {
        p.sock.close(1000, reason);
      } catch {
        // Gone.
      }
    }
    this.players.clear();
  }

  /** The API's calls (through the bridge). */
  call(op: string, arg: unknown): unknown {
    if (op === 'targets') {
      const a = (arg ?? {}) as { mode?: unknown; count?: unknown };
      return this.targets(a.mode === 'random' ? 'random' : 'all', Number(a.count) || 1);
    }
    if (op === 'stats') return { online: this.size };
    if (op === 'close') {
      this.broadcast({ t: 'end' });
      this.closeAll();
      return true;
    }
    return null;
  }
}
