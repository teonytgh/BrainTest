"""Haunted Fuse: the fuse machine as a voxel haunted house, rendered in layers for the Fuse page.

    blender -b --factory-startup --python scripts/blender/haunted_fuse.py -- public/fuse src/lib/fuse-layout.json [--quick]

The house's windows are its eyes and its garage door is a mouth with teeth, lava and a long tongue inside. The page
brings it to life with CSS (breathing, blinking, looking around, licking, swallowing). Layers (WebP, alpha):
  house.webp   everything but the door, the eyes and the tongue: the mouth is open, the windows show shut lids
  door.webp    the garage door alone (the page slides it up and down inside the mouth)
  mouth.webp   teeth, frame and lanterns, drawn over the door so it slides behind them
  eyes.webp    the glowing eye windows (the page blinks them shut by wiping over the lids)
  pupils.webp  the slit pupils alone (the page moves them around inside the windows)
  tongue.webp  the tongue stretched out of the mouth onto the slime pad (the page shoots it out and pulls it back)
  card.webp    the closed house, small, for the home page card
and the layout JSON (second argument): where the mouth, the eye windows, the tongue, the chimney and the slime pad are,
in % of the picture.
"""
import json
import math
import os
import random
import sys

import bpy
from bpy_extras.object_utils import world_to_camera_view
from mathutils import Vector

ARGS = sys.argv[sys.argv.index('--') + 1:] if '--' in sys.argv else []
POSITIONAL = [a for a in ARGS if not a.startswith('--')]
OUT = os.path.abspath(POSITIONAL[0] if POSITIONAL else 'public/fuse')
LAYOUT = os.path.abspath(POSITIONAL[1] if len(POSITIONAL) > 1 else os.path.join(OUT, 'layout.json'))
QUICK = '--quick' in ARGS
SIZE = 360 if QUICK else 768
SAMPLES = 24 if QUICK else 128
random.seed(13)


def lin(c):
    """sRGB 0–255 → linear 0–1."""
    def ch(v):
        v /= 255
        return v / 12.92 if v <= 0.04045 else ((v + 0.055) / 1.055) ** 2.4
    return (ch(c[0]), ch(c[1]), ch(c[2]), 1.0)


# name: (sRGB colour, emission strength, shade jitter)
PALETTE = {
    'wall': ((214, 180, 70), 0, 0.10),
    'wall2': ((186, 154, 58), 0, 0.10),
    'plank': ((110, 64, 34), 0, 0.10),
    'trim': ((78, 44, 26), 0, 0.12),
    'wood': ((128, 74, 38), 0, 0.10),
    'wood2': ((96, 54, 28), 0, 0.08),
    'iron': ((44, 40, 52), 0, 0.06),
    'roof': ((88, 44, 120), 0, 0.12),
    'roof2': ((58, 28, 84), 0, 0.10),
    'spire': ((34, 24, 44), 0, 0.08),
    'brick': ((112, 44, 34), 0, 0.12),
    'stone': ((120, 118, 132), 0, 0.10),
    'stone2': ((160, 158, 172), 0, 0.08),
    'bone': ((244, 236, 214), 0, 0.04),
    'lava': ((255, 96, 10), 2.4, 0.14),
    'lava2': ((230, 46, 6), 1.6, 0.12),
    'lava3': ((255, 200, 60), 3.2, 0.08),
    'glass': ((255, 176, 30), 2.2, 0.06),
    'glass2': ((255, 150, 40), 1.4, 0.06),
    'pupil': ((20, 12, 16), 0, 0.0),
    'lid': ((70, 36, 84), 0, 0.10),
    'lid2': ((52, 26, 64), 0, 0.10),
    'tongue': ((214, 66, 104), 0.05, 0.08),
    'tongue2': ((168, 40, 78), 0, 0.08),
    'tongue3': ((238, 112, 140), 0.08, 0.06),
    'lamp': ((255, 160, 40), 3.0, 0.0),
    'slime': ((120, 240, 70), 1.2, 0.12),
    'slime2': ((40, 110, 30), 0.2, 0.08),
}

# Which object each material belongs to (the layers are rendered per object).
GROUP = {k: 'house' for k in PALETTE}
GROUP.update({'wood': 'door', 'wood2': 'door', 'iron': 'door', 'bone': 'mouth', 'lamp': 'mouth', 'glass': 'eyes', 'pupil': 'pupils'})
GROUP.update({'tongue': 'tongue', 'tongue2': 'tongue', 'tongue3': 'tongue'})

grid = {}


def put(x, y, z, key):
    grid[(x, y, z)] = key


def box(x0, x1, y0, y1, z0, z1, key):
    for x in range(x0, x1):
        for y in range(y0, y1):
            for z in range(z0, z1):
                put(x, y, z, key)


def clear(x0, x1, y0, y1, z0, z1):
    for x in range(x0, x1):
        for y in range(y0, y1):
            for z in range(z0, z1):
                grid.pop((x, y, z), None)


# ---------- The model (x right, y back, z up; the front face is y = 0) ----------

# Stone base and the slime pad in front of the mouth.
box(-3, 44, -4, 26, 0, 2, 'stone')
for x in range(-3, 44):
    for y in range(-4, 26):
        if x in (-3, 43) or y in (-4, 25):
            put(x, y, 1, 'stone2')
box(12, 36, -15, -4, 0, 1, 'slime2')
box(13, 35, -14, -5, 0, 1, 'slime')

# Main body.
box(8, 40, 0, 22, 2, 31, 'wall')
for x in (8, 39):
    box(x, x + 1, -1, 1, 2, 31, 'trim')
    box(x, x + 1, 21, 22, 2, 31, 'trim')
box(8, 40, -1, 0, 17, 18, 'trim')
box(8, 40, -1, 0, 30, 31, 'trim')

# The mouth: an opening with a lava cavity, teeth top and bottom, a wooden frame and two lanterns.
clear(13, 35, 0, 6, 3, 14)
box(13, 35, 6, 7, 3, 14, 'lava')
for _ in range(26):  # hot bubbles in the back wall
    put(random.randrange(13, 35), 6, random.randrange(3, 14), 'lava3')
box(13, 35, 1, 6, 2, 3, 'lava2')
box(12, 13, 1, 6, 3, 14, 'lava2')
box(35, 36, 1, 6, 3, 14, 'lava2')
box(13, 35, 1, 6, 14, 15, 'lava2')
for x in range(13, 35):
    k = (x - 13) % 4
    put(x, 0, 13, 'bone')
    if k in (1, 2):
        put(x, 0, 12, 'bone')
    if k == 1:
        put(x, 0, 11, 'bone')
    put(x, 0, 3, 'bone')
    if k in (3, 0):
        put(x, 0, 4, 'bone')
    if k == 3:
        put(x, 0, 5, 'bone')
box(12, 13, -1, 0, 2, 15, 'bone')
box(35, 36, -1, 0, 2, 15, 'bone')
box(11, 37, -1, 0, 14, 16, 'trim')
box(11, 12, -1, 0, 2, 14, 'trim')
box(36, 37, -1, 0, 2, 14, 'trim')
box(9, 11, -2, -1, 8, 10, 'lamp')
box(37, 39, -2, -1, 8, 10, 'lamp')

# The garage door (its own layer), just behind the teeth.
for z in range(3, 14):
    for x in range(13, 35):
        key = 'wood2' if z % 2 == 0 else 'wood'
        if z in (6, 10) or x in (13, 34):
            key = 'iron'
        put(x, 1, z, key)

# The tongue (its own layer): off the mouth floor, over the lower teeth, down onto the slime pad, the tip curled up.
TONGUE_TOP = {5: 5, 4: 5, 3: 5, 2: 6, 1: 7, 0: 8, -1: 8, -2: 7, -3: 6, -4: 5, -5: 4, -16: 4}
TONGUE_CURL = {-17: (3, 7), -18: (5, 9), -19: (7, 10)}  # the tip rises like a hook, ready to grab
for y in range(-19, 6):
    z0, zt = TONGUE_CURL.get(y, (TONGUE_TOP.get(y, 3) - 2, TONGUE_TOP.get(y, 3)))
    half = 6 if y > -8 else 5 if y > -14 else 4 if y > -17 else 3
    for x in range(24 - half, 24 + half):
        for z in range(z0, zt):
            top = z == zt - 1
            if y <= -15:
                key = 'tongue3' if top or y < -16 else 'tongue'  # the wet tip
            elif top and x in (23, 24):
                key = 'tongue2'  # the groove down the middle
            else:
                key = 'tongue' if top else 'tongue2'
            put(x, y, z, key)

# Eyes: two tall glowing windows cut on a slant at the top inner corner (an angry look), slit pupils, heavy brows.
EYE_POLYS = []
for x0, inner in ((13, 1), (28, -1)):
    w, z0, z1 = 7, 19, 28
    # The window outline on the glass face (y = 1), the slanted corner towards the nose included.
    if inner > 0:
        EYE_POLYS.append([(x0, 1, z0), (x0 + w, 1, z0), (x0 + w, 1, z1 - 4), (x0 + 1, 1, z1), (x0, 1, z1)])
    else:
        EYE_POLYS.append([(x0, 1, z0), (x0 + w, 1, z0), (x0 + w, 1, z1), (x0 + w - 1, 1, z1), (x0, 1, z1 - 4)])
    clear(x0, x0 + w, 0, 2, z0, z1)
    for z in range(z0, z1):
        cut = max(0, z - (z1 - 4))  # rows from the top get shorter towards the nose
        for x in range(x0, x0 + w):
            k = x - x0 if inner < 0 else x0 + w - 1 - x
            if k < cut * 2:
                put(x, 0, z, 'wall')
                put(x, 1, z, 'wall')
            else:
                put(x, 1, z, 'glass')
    # Shut lids one voxel behind the glass: what the window shows while the page blinks the glow away.
    for z in range(z0, z1):
        box(x0, x0 + w, 2, 3, z, z + 1, 'lid' if z % 2 else 'lid2')
    p = x0 + 3
    box(p, p + 1, 0, 1, z0 + 1, z1 - 3, 'pupil')
    box(x0 - 1, x0 + w + 1, -1, 0, z0 - 1, z0, 'trim')
for i in range(9):
    put(12 + i, -1, 29 - i // 3, 'trim')
    put(12 + i, -1, 28 - i // 3, 'trim')
    put(35 - i, -1, 29 - i // 3, 'trim')
    put(35 - i, -1, 28 - i // 3, 'trim')

# Witch-hat roof with a curled tip, eaves and an attic window.
box(5, 43, -4, 26, 31, 32, 'roof2')
for z in range(32, 56):
    t = z - 32
    half_w = 18 - t * 0.78
    half_d = 13 - t * 0.55
    if half_w < 1 or half_d < 1:
        break
    cx = 24 + (max(0, z - 46) ** 1.6) * 0.55
    cy = 11
    for x in range(int(cx - half_w), int(cx + half_w) + 1):
        for y in range(int(cy - half_d), int(cy + half_d) + 1):
            put(x, y, z, 'roof' if (x + z) % 7 else 'roof2')
for z in range(36, 41):
    t = z - 32
    yf = int(11 - (13 - t * 0.55))
    for x in range(22, 27):
        put(x, yf, z, 'glass2')

# Chimney (the page puffs smoke from its top).
box(10, 13, 13, 16, 30, 47, 'brick')
box(9, 14, 12, 17, 46, 48, 'trim')

# Left wing: a lower block with a lean-to roof, a warm window, steps and two spiky spires.
box(-1, 8, 3, 21, 2, 21, 'wall2')
box(-1, 0, 2, 4, 2, 21, 'trim')
for x in range(-3, 9):
    zt = 21 + int((x + 3) * 0.45)
    for y in range(1, 23):
        put(x, y, zt, 'roof2' if y in (1, 22) else 'roof')
clear(1, 6, 3, 5, 8, 15)
box(1, 6, 4, 5, 8, 15, 'glass2')
box(0, 7, 2, 3, 15, 16, 'trim')
for i in range(5):
    box(0, 7, -3 + i, 3, 2, 3 + i, 'trim' if i % 2 else 'plank')
for sx, sy, top in ((0, 9, 36), (5, 15, 33)):
    box(sx, sx + 2, sy, sy + 2, 21, top, 'spire')
    for k in range(4):
        put(sx + (k % 2), sy, top + k, 'spire')

# ---------- Mesh ----------

FACES = [
    ((1, 0, 0), [(1, 0, 0), (1, 1, 0), (1, 1, 1), (1, 0, 1)]),
    ((-1, 0, 0), [(0, 0, 0), (0, 0, 1), (0, 1, 1), (0, 1, 0)]),
    ((0, 1, 0), [(0, 1, 0), (0, 1, 1), (1, 1, 1), (1, 1, 0)]),
    ((0, -1, 0), [(0, 0, 0), (1, 0, 0), (1, 0, 1), (0, 0, 1)]),
    ((0, 0, 1), [(0, 0, 1), (1, 0, 1), (1, 1, 1), (0, 1, 1)]),
    ((0, 0, -1), [(0, 0, 0), (0, 1, 0), (1, 1, 0), (1, 0, 0)]),
]
SHADES = 3


def make_material(name, key, shade):
    rgb, strength, jitter = PALETTE[key]
    f = 1 + jitter * (shade - 1)
    col = lin([min(255, v * f) for v in rgb])
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    bsdf = m.node_tree.nodes['Principled BSDF']
    bsdf.inputs['Base Color'].default_value = col
    bsdf.inputs['Roughness'].default_value = 0.85
    if strength:
        bsdf.inputs['Emission Color'].default_value = col
        bsdf.inputs['Emission Strength'].default_value = strength
    return m


def build(group):
    keys = [k for k in PALETTE if GROUP[k] == group]
    mats = [(k, s) for k in keys for s in range(SHADES)]
    index = {ks: i for i, ks in enumerate(mats)}
    verts, faces, mat_ids, vmap = [], [], [], {}
    cells = {p: k for p, k in grid.items() if GROUP[k] == group}

    def v(p):
        if p not in vmap:
            vmap[p] = len(verts)
            verts.append(p)
        return vmap[p]

    for (x, y, z), key in cells.items():
        shade = random.randrange(SHADES)
        for (dx, dy, dz), quad in FACES:
            if (x + dx, y + dy, z + dz) in cells:
                continue
            faces.append([v((x + a, y + b, z + c)) for a, b, c in quad])
            mat_ids.append(index[(key, shade)])
    mesh = bpy.data.meshes.new(group)
    mesh.from_pydata(verts, [], faces)
    for k, s in mats:
        mesh.materials.append(make_material(f'{k}.{s}', k, s))
    for poly, mid in zip(mesh.polygons, mat_ids):
        poly.material_index = mid
    obj = bpy.data.objects.new(group, mesh)
    bpy.context.scene.collection.objects.link(obj)
    return obj


for o in list(bpy.data.objects):
    bpy.data.objects.remove(o)
OBJ = {g: build(g) for g in ('house', 'door', 'mouth', 'eyes', 'pupils', 'tongue')}

# ---------- Camera, lights, render ----------

scene = bpy.context.scene
target = Vector((19.5, 6, 26))
cam_data = bpy.data.cameras.new('cam')
cam_data.type = 'ORTHO'
cam_data.ortho_scale = 74
cam = bpy.data.objects.new('cam', cam_data)
scene.collection.objects.link(cam)
yaw, pitch = math.radians(-24), math.radians(20)
direction = Vector((math.sin(yaw) * math.cos(pitch), -math.cos(yaw) * math.cos(pitch), math.sin(pitch)))
cam.location = target + direction * 120
cam.rotation_euler = (-direction).to_track_quat('-Z', 'Y').to_euler()
scene.camera = cam

moon = bpy.data.objects.new('moon', bpy.data.lights.new('moon', 'SUN'))
moon.data.energy = 2.6
moon.data.color = (0.78, 0.8, 1.0)
moon.data.angle = math.radians(8)
moon.rotation_euler = (math.radians(52), 0, math.radians(-38))
scene.collection.objects.link(moon)
rim = bpy.data.objects.new('rim', bpy.data.lights.new('rim', 'AREA'))
rim.data.energy = 60000
rim.data.size = 40
rim.data.color = (0.66, 0.4, 1.0)
rim.location = (60, 70, 60)
rim.rotation_euler = (Vector((20, 10, 25)) - rim.location).to_track_quat('-Z', 'Y').to_euler()
scene.collection.objects.link(rim)
for name, x in (('lamp_l', 10), ('lamp_r', 38)):
    lamp = bpy.data.objects.new(name, bpy.data.lights.new(name, 'POINT'))
    lamp.data.energy = 900
    lamp.data.color = (1.0, 0.62, 0.25)
    lamp.data.shadow_soft_size = 1.5
    lamp.location = (x, -4, 9)
    scene.collection.objects.link(lamp)
world = bpy.data.worlds.new('night')
world.use_nodes = True
world.node_tree.nodes['Background'].inputs['Color'].default_value = (0.045, 0.03, 0.08, 1)
world.node_tree.nodes['Background'].inputs['Strength'].default_value = 1.0
scene.world = world

scene.render.engine = 'CYCLES'
scene.cycles.device = 'CPU'
scene.cycles.samples = SAMPLES
scene.cycles.use_denoising = True
scene.render.film_transparent = True
scene.render.resolution_x = scene.render.resolution_y = SIZE
scene.render.resolution_percentage = 100
scene.render.image_settings.file_format = 'WEBP'
scene.render.image_settings.color_mode = 'RGBA'
scene.render.image_settings.quality = 86
try:
    scene.view_settings.view_transform = 'AgX'
    scene.view_settings.look = 'AgX - Punchy'
except TypeError:
    pass
os.makedirs(OUT, exist_ok=True)


def layer(name, show=(), holdout=(), camera_off=(), size=SIZE):
    """One pass: `show` as is, `holdout` cut out of the picture, `camera_off` only lights and shadows; the rest hidden."""
    for g, o in OBJ.items():
        o.hide_render = g not in show and g not in holdout and g not in camera_off
        o.is_holdout = g in holdout
        o.visible_camera = g not in camera_off
    scene.render.resolution_x = scene.render.resolution_y = size
    scene.render.filepath = os.path.join(OUT, name)
    bpy.ops.render.render(write_still=True)
    print('wrote', name)


layer('house.webp', show={'house', 'mouth'})
layer('mouth.webp', show={'mouth'}, holdout={'house'})
layer('eyes.webp', show={'eyes'}, holdout={'house', 'mouth'})
layer('pupils.webp', show={'pupils'}, holdout={'house', 'mouth'})
layer('door.webp', show={'door'}, camera_off={'house', 'mouth', 'eyes'})
layer('tongue.webp', show={'tongue'}, camera_off={'house', 'mouth', 'door'})
layer('card.webp', show={'house', 'mouth', 'eyes', 'pupils', 'door'}, size=min(SIZE, 400))


# ---------- Where things are, in % of the picture ----------

def at(p):
    c = world_to_camera_view(scene, cam, Vector(p))
    return [round(c.x * 100, 2), round((1 - c.y) * 100, 2)]


layout = {
    'mouth': [at((13, 1, 14)), at((35, 1, 14)), at((35, 1, 3)), at((13, 1, 3))],
    'mouthCenter': at((24, 1, 8.5)),
    'eyes': [at((16.5, 1, 23)), at((31.5, 1, 23))],
    'eyePolys': [[at(p) for p in poly] for poly in EYE_POLYS],
    'tongueRoot': at((24, 0, 8)),
    'tongueTip': at((24, -15, 3)),
    'chimney': at((11.5, 14.5, 48)),
    'pad': at((24, -9.5, 1)),
}
with open(LAYOUT, 'w') as f:
    json.dump(layout, f, indent=2)
    f.write('\n')
print('layout', json.dumps(layout))
