import type { ReactNode } from 'react';

const PATHS = {
  menu: <path d="M4 7h16M4 12h16M4 17h10" />,
  close: <path d="M6 6l12 12M18 6L6 18" />,
  play: <path d="M7 4.5l12 7.5-12 7.5z" />,
  volume: (
    <>
      <path d="M4 9v6h4l5 4V5L8 9z" />
      <path d="M16.5 8.5a5 5 0 0 1 0 7M18.8 6.2a8.5 8.5 0 0 1 0 11.6" />
    </>
  ),
  volumeOff: (
    <>
      <path d="M4 9v6h4l5 4V5L8 9z" />
      <path d="M17 9.5l4 5M21 9.5l-4 5" />
    </>
  ),
  settings: (
    <>
      <circle cx="12" cy="12" r="5.6" />
      <circle cx="12" cy="12" r="2.2" />
      <path
        strokeWidth="3"
        strokeLinecap="butt"
        d="M17.6 12H21M15.96 15.96l2.4 2.4M12 17.6V21M8.04 15.96l-2.4 2.4M6.4 12H3M8.04 8.04l-2.4-2.4M12 6.4V3M15.96 8.04l2.4-2.4"
      />
    </>
  ),
  home: <path d="M4 11l8-7 8 7M6 9.5V20h12V9.5M10 20v-5h4v5" />,
  gauge: (
    <>
      <path d="M4.5 16.5a7.5 7.5 0 1 1 15 0" />
      <path d="M12 16.5l3.6-4.6" />
      <circle cx="12" cy="16.5" r="1.3" fill="currentColor" stroke="none" />
    </>
  ),
  shield: (
    <>
      <path d="M12 3.5l7 2.8v5.2c0 4.3-2.9 7.7-7 9.3-4.1-1.6-7-5-7-9.3V6.3z" />
      <path d="M9.6 9.6l4.8 4.8M14.4 9.6l-4.8 4.8" />
    </>
  ),
  dice: (
    <>
      <rect x="4" y="4" width="16" height="16" rx="3.5" />
      <circle cx="9" cy="9" r="1.4" fill="currentColor" stroke="none" />
      <circle cx="15" cy="9" r="1.4" fill="currentColor" stroke="none" />
      <circle cx="9" cy="15" r="1.4" fill="currentColor" stroke="none" />
      <circle cx="15" cy="15" r="1.4" fill="currentColor" stroke="none" />
    </>
  ),
  rocket: (
    <>
      <path d="M12 3c3 2.2 4.4 5.2 4.4 8.6L14.6 16H9.4l-1.8-4.4C7.6 8.2 9 5.2 12 3z" />
      <circle cx="12" cy="9.6" r="1.6" />
      <path d="M7.7 11.8L5.2 14.3l2.6 1.9M16.3 11.8l2.5 2.5-2.6 1.9M10.6 18.6L12 21l1.4-2.4" />
    </>
  ),
  quests: <path d="M4 6.5l1.6 1.6L8.6 5M11 6.5h9M4 12.5l1.6 1.6 3-3.1M11 12.5h9M4.6 18.5h3M11 18.5h9" />,
  trophy: (
    <>
      <path d="M8 4h8v5a4 4 0 0 1-8 0z" />
      <path d="M8 6H5.2v1.2A3.3 3.3 0 0 0 8 10.5M16 6h2.8v1.2a3.3 3.3 0 0 1-2.8 3.3M12 13v3.5M8.5 20h7M10 16.5h4V20h-4z" />
    </>
  ),
  // A coin-like token (crypto deposits, iteration 38).
  crypto: (
    <>
      <path d="M12 2.6l8.1 4.7v9.4L12 21.4l-8.1-4.7V7.3z" />
      <path d="M12 7.2l3.3 4.8L12 16.8 8.7 12z" />
    </>
  ),
  chat: (
    <>
      <path d="M5.5 5h13a2 2 0 0 1 2 2v8.2a2 2 0 0 1-2 2H11l-4.2 3.3v-3.3H5.5a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2z" />
      <circle cx="8.6" cy="11.1" r="0.9" fill="currentColor" stroke="none" />
      <circle cx="12" cy="11.1" r="0.9" fill="currentColor" stroke="none" />
      <circle cx="15.4" cy="11.1" r="0.9" fill="currentColor" stroke="none" />
    </>
  ),
  help: (
    <>
      <circle cx="12" cy="12" r="8.6" />
      <path d="M9.6 9.5a2.5 2.5 0 0 1 4.9.8c0 1.8-2.5 2.2-2.5 3.8" />
      <circle cx="12" cy="17" r="1" fill="currentColor" stroke="none" />
    </>
  ),
  gift: (
    <>
      <rect x="4" y="8.5" width="16" height="4" rx="1" />
      <path d="M5.5 12.5V20h13v-7.5M12 8.5V20" />
      <path d="M12 8.5C10.6 5.4 7.3 5 7.3 7c0 1.3 1.9 1.5 4.7 1.5zM12 8.5c1.4-3.1 4.7-3.5 4.7-1.5 0 1.3-1.9 1.5-4.7 1.5z" />
    </>
  ),
  bolt: <path d="M13.2 3L5.5 13.4h5.7L10.6 21l7.9-10.5h-5.8z" fill="currentColor" stroke="none" />,
  plus: <path d="M12 5.5v13M5.5 12h13" />,
  arrowRight: <path d="M5 12h14M13 6l6 6-6 6" />,
  arrowDown: <path d="M12 5v14M6 13l6 6 6-6" />,
  arrowUp: <path d="M12 19V5M6 11l6-6 6 6" />,
  info: (
    <>
      <circle cx="12" cy="12" r="8.6" />
      <path d="M12 11v5.5M12 7.6v.2" />
    </>
  ),
  bot: (
    <>
      <rect x="5" y="8" width="14" height="11" rx="3" />
      <path d="M12 8V5M9.5 13v.5M14.5 13v.5M9.5 16.5h5" />
    </>
  ),
  chevronRight: <path d="M9.5 6l6 6-6 6" />,
  chevronLeft: <path d="M14.5 6l-6 6 6 6" />,
  chevronDown: <path d="M6 9.5l6 6 6-6" />,
  chevronUp: <path d="M6 14.5l6-6 6 6" />,
  trash: <path d="M5 7h14M10 7V5h4v2M7 7l1 12h8l1-12M10.5 10.5v5.5M13.5 10.5v5.5" />,
  copy: (
    <>
      <rect x="8.5" y="8.5" width="11.5" height="11.5" rx="2.2" />
      <path d="M15.5 8.5V6.2A2.2 2.2 0 0 0 13.3 4H6.2A2.2 2.2 0 0 0 4 6.2v7.1a2.2 2.2 0 0 0 2.2 2.2h2.3" />
    </>
  ),
  check: <path d="M5 12.5l4.5 4.5L19 7.5" />,
  pumpkin: (
    <>
      <path d="M12 7.2c-1.3-.9-3.1-1.1-4.6-.4C4.8 8 3.6 10.6 4 13.5c.5 3.4 3 6 5.9 6 .8 0 1.5-.2 2.1-.6.6.4 1.3.6 2.1.6 2.9 0 5.4-2.6 5.9-6 .4-2.9-.8-5.5-3.4-6.7-1.5-.7-3.3-.5-4.6.4z" />
      <path d="M12 7.2c0-1.6.6-2.9 2.1-3.7M9.6 7c-.6 2.5-.6 8.4.4 12.3M14.4 7c.6 2.5.6 8.4-.4 12.3" />
    </>
  ),
  fuse: (
    <>
      <path d="M3.5 11.5L12 4l8.5 7.5M6 9.6V20h12V9.6" />
      <path d="M12.9 10.4l-2.6 4h3.4l-2.6 4" />
    </>
  ),
  star: <path fill="currentColor" d="M12 3.2l2.6 5.5 6 .8-4.4 4.2 1.1 6-5.3-2.9-5.3 2.9 1.1-6-4.4-4.2 6-.8z" />,
  tag: (
    <>
      <path d="M3.8 12.2V4.8a1 1 0 0 1 1-1h7.4l8 8a1.5 1.5 0 0 1 0 2.1l-6.1 6.1a1.5 1.5 0 0 1-2.1 0z" />
      <circle cx="8.3" cy="8.3" r="1.4" />
    </>
  ),
  bag: <path d="M5.5 8.5h13L17.4 20H6.6zM9 8.5V7a3 3 0 0 1 6 0v1.5" />,
  box: <path d="M4 8l8-4 8 4v8.5l-8 4-8-4zM4 8l8 4 8-4M12 12v8.5" />,
  sparkle: <path d="M12 3.5l1.9 5.1 5.1 1.9-5.1 1.9L12 17.5l-1.9-5.1L5 10.5l5.1-1.9z" />,
  reset: <path d="M4.5 12a7.5 7.5 0 1 0 2.3-5.4M4.5 4.5v4h4" />,
  users: (
    <>
      <circle cx="9" cy="8.5" r="3.2" />
      <path d="M3.5 19c.6-3.2 2.8-5 5.5-5s4.9 1.8 5.5 5" />
      <path d="M15.5 5.6a3 3 0 0 1 0 5.8M17.2 14.3c1.8.6 3 2.2 3.3 4.7" />
    </>
  ),
  user: (
    <>
      <circle cx="12" cy="8.2" r="3.7" />
      <path d="M4.8 20c.8-3.8 3.6-6 7.2-6s6.4 2.2 7.2 6" />
    </>
  ),
  bomb: (
    <>
      <circle cx="11" cy="14" r="6.5" />
      <path d="m15.5 9.5 2-2M17.5 7.5c1-1.2 2.4-1.6 3.5-1" />
    </>
  ),
  road: (
    <>
      <path d="M8 3.5 5 20.5M16 3.5l3 17" />
      <path d="M12 4.5v2.5M12 10.5v3M12 17v3" />
    </>
  ),
  clock: (
    <>
      <circle cx="12" cy="12" r="8.6" />
      <path d="M12 7.5V12l3 2" />
    </>
  ),
  send: <path d="M20.5 3.5 3.5 10.6l6.6 2.8 2.8 6.6zM10.1 13.4l4.6-4.6" />,
  lock: (
    <>
      <rect x="5" y="10.5" width="14" height="10" rx="2.5" />
      <path d="M8 10.5V8a4 4 0 0 1 8 0v2.5" />
    </>
  ),
} satisfies Record<string, ReactNode>;

export type IconName = keyof typeof PATHS;

export function Icon({ name, size = 22, className }: { name: IconName; size?: number; className?: string }) {
  return (
    <svg
      className={className}
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      focusable="false"
    >
      {PATHS[name]}
    </svg>
  );
}
