import { useQuery } from '@tanstack/react-query';
import { useEffect, useMemo, useRef, useState } from 'react';
import { Coin } from '../components/Coin';
import { Icon } from '../components/Icon';
import { Ticket } from '../components/Ticket';
import { api, errorMessage } from '../api/client';
import { act, setMe, useCatalog } from '../api/queries';
import type { PassState } from '../../server/pass';
import { PASS_LEVELS, PASS_QUEST_XP, passCaseFor, type PassReward, type PassTrack } from '../../shared/pass';
import { payoutFor } from '../../shared/payout';
import { cx, formatCoins } from '../lib/format';
import { sfx } from '../lib/sound';
import { haptic, openInvoice } from '../lib/telegram';
import { useNow } from '../lib/useNow';
import { toast } from '../store/toast';
import '../styles/pass.css';

const PASS_KEY = ['pass'] as const;

const daysLeft = (ms: number) => {
  const d = Math.max(0, Math.ceil(ms / 86_400_000));
  return d === 1 ? 'последний день' : `ещё ${d} ${d % 10 === 1 && d % 100 !== 11 ? 'день' : d % 10 >= 2 && d % 10 <= 4 && (d % 100 < 12 || d % 100 > 14) ? 'дня' : 'дней'}`;
};

/**
 * «Батл пасс» (iteration 37, BPlus reworked in 39): the season's 30 levels with two tracks — FREE on top for everybody,
 * BPlus below (299 ⭐: coins, tickets and case openings worth 1.5× its price). Experience comes from real stakes and claimed quests; every reached reward is
 * claimed with a tap (or all at once).
 */
export function Pass() {
  const now = useNow(60_000);
  const state = useQuery({ queryKey: PASS_KEY, queryFn: () => api<PassState>('/api/pass'), staleTime: 15_000 });
  const [busy, setBusy] = useState<string | null>(null);
  const [waiting, setWaiting] = useState<number | null>(null);
  const s = state.data;

  // After paying, the bot's webhook opens BPlus a moment later: poll the order until it is paid.
  useEffect(() => {
    if (waiting === null) return;
    let stop = false;
    const started = Date.now();
    const poll = async () => {
      while (!stop && Date.now() - started < 90_000) {
        try {
          const o = await api<{ status: string }>(`/api/pass/orders/${waiting}`);
          if (o.status === 'paid') {
            sfx.bigWin();
            haptic('success');
            toast('BPlus открыт — забирай награды!', 'success');
            await state.refetch();
            break;
          }
        } catch {
          // Try again.
        }
        await new Promise((r) => setTimeout(r, 2000));
      }
      if (!stop) setWaiting(null);
    };
    void poll();
    return () => {
      stop = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [waiting]);

  async function claim(level?: number, track?: PassTrack) {
    const key = level ? `${track}:${level}` : 'all';
    setBusy(key);
    try {
      const r = await act<{ rewards: unknown[]; total: number }>('/api/pass/claim', level ? { level, track } : {});
      setMe(r.me);
      sfx.win();
      haptic('success');
      toast(`Получено наград: ${r.result.rewards.length} · ≈ ${formatCoins(r.result.total)} B`, 'success');
      await state.refetch();
    } catch (e) {
      sfx.error();
      toast(errorMessage(e), 'error');
    } finally {
      setBusy(null);
    }
  }

  async function buy() {
    setBusy('buy');
    try {
      const inv = await api<{ orderId: number; link: string }>('/api/pass/buy', { method: 'POST' });
      haptic('tap');
      const status = await openInvoice(inv.link);
      if (status === 'paid' || status === 'pending') setWaiting(inv.orderId);
      else if (status === 'failed') toast('Оплата не прошла — попробуй ещё раз', 'error');
      else toast('Оплата отменена');
    } catch (e) {
      sfx.error();
      toast(errorMessage(e), 'error');
    } finally {
      setBusy(null);
    }
  }

  if (!s) return <div className="page-loading" aria-busy="true" />;
  const claimed = new Set(s.claimed);
  const claimable = Array.from({ length: s.level }, (_, i) => i + 1).reduce(
    (n, level) => n + (s.free[level - 1] && !claimed.has(`free:${level}`) ? 1 : 0) + (s.plus && s.plusTrack[level - 1] && !claimed.has(`plus:${level}`) ? 1 : 0),
    0,
  );
  const pct = s.level >= PASS_LEVELS ? 100 : Math.round((s.into / Math.max(1, s.need)) * 100);

  return (
    <div className="pass-page">
      <section className="pass-hero">
        <div className="pass-hero__top">
          <div>
            <p className="pass-hero__kicker">Сезон «{s.season.name}» · {daysLeft(s.season.endsAt - now)}</p>
            <h1 className="pass-hero__title">Батл пасс</h1>
          </div>
          <span className="pass-level" aria-label={`Уровень ${s.level}`}>
            <small>ур.</small>
            {s.level}
          </span>
        </div>
        <div className="pass-xp" role="progressbar" aria-valuemin={0} aria-valuemax={100} aria-valuenow={pct} aria-label="Опыт до следующего уровня">
          <span style={{ transform: `scaleX(${pct / 100})` }} />
        </div>
        <p className="pass-hero__meta">
          {s.level >= PASS_LEVELS ? 'Все 30 уровней пройдены!' : `До уровня ${s.level + 1}: ${formatCoins(s.into)} / ${formatCoins(s.need)} опыта`}
          <span>
            {formatCoins(s.fromPlay)} за ставки · {formatCoins(s.fromQuests)} за задания
          </span>
        </p>
        {claimable > 0 && (
          <button type="button" className="btn btn--primary btn--lg btn--block" disabled={busy !== null} onClick={() => void claim()}>
            <Icon name="gift" size={18} /> Забрать всё ({claimable})
          </button>
        )}
      </section>

      {s.plus ? (
        <p className="pass-plus-on">
          <b>BPlus</b> активен — награды нижней дорожки твои.
        </p>
      ) : (
        <section className="pass-plus">
          <div>
            <p className="pass-plus__name">BPlus</p>
            <p className="pass-plus__text">
              Монеты, тикеты и бесплатные открытия кейсов на всех 30 уровнях — <b>≈ {formatCoins(s.plusValue)} B</b>, в 1,5 раза больше цены (
              {formatCoins(s.plusPrice)} B по курсу звёзд). Открывается сразу за все пройденные уровни.
            </p>
          </div>
          <button type="button" className="btn btn--primary btn--block" disabled={busy !== null || waiting !== null} onClick={() => void buy()}>
            {waiting !== null ? 'Ждём оплату…' : `Купить за ${s.plusStars} ⭐`}
          </button>
        </section>
      )}

      <Track state={s} claimed={claimed} busy={busy} onClaim={(level, track) => void claim(level, track)} />

      <div className="panel pass-rules">
        <h2 className="panel__title">Как получать опыт</h2>
        <ul>
          <li>1 опыт за каждую 1 B ставок в кейсах, батлах, апгрейде, FUSE и дайсах; 0,5 — в минах, дороге и краше.</li>
          <li>
            +{PASS_QUEST_XP.daily} за дневное задание, +{PASS_QUEST_XP.weekly} за недельное.
          </li>
          <li>Сезон — календарный месяц. Что не забрал до конца сезона — сгорает, опыт начинается заново.</li>
          <li>BPlus: монеты на каждом уровне, тикеты на каждом третьем, открытие кейса на каждом пятом — кейс берётся самый дорогой, что влезает в награду, остаток приходит монетами.</li>
          <li>Награды — бонус: монеты и то, что выпадет из кейсов, перед выводом нужно отыграть, как любой бонус.</li>
        </ul>
      </div>
    </div>
  );
}

function Track({ state: s, claimed, busy, onClaim }: { state: PassState; claimed: Set<string>; busy: string | null; onClaim: (level: number, track: PassTrack) => void }) {
  const ref = useRef<HTMLDivElement>(null);
  // Scroll so the current level is in view.
  useEffect(() => {
    const el = ref.current?.querySelector<HTMLElement>('.pass-col.is-next') ?? ref.current?.querySelector<HTMLElement>('.pass-col:last-child');
    el?.scrollIntoView({ inline: 'center', block: 'nearest' });
  }, []);
  return (
    <div className="pass-track" ref={ref}>
      <div className="pass-col pass-col--labels" aria-hidden="true">
        <span className="pass-label">FREE</span>
        <span className="pass-node pass-node--blank" />
        <span className="pass-label pass-label--plus">BPlus</span>
      </div>
      {Array.from({ length: PASS_LEVELS }, (_, i) => {
        const level = i + 1;
        const reached = level <= s.level;
        return (
          <div key={level} className={cx('pass-col', reached && 'is-reached', level === s.level + 1 && 'is-next')}>
            <Reward
              reward={s.free[i] ?? null}
              state={claimed.has(`free:${level}`) ? 'claimed' : reached ? 'ready' : 'locked'}
              busy={busy === `free:${level}`}
              onClaim={() => onClaim(level, 'free')}
            />
            <span className="pass-node">{level}</span>
            <Reward
              reward={s.plusTrack[i] ?? null}
              plus
              state={!s.plus ? 'plus' : claimed.has(`plus:${level}`) ? 'claimed' : reached ? 'ready' : 'locked'}
              busy={busy === `plus:${level}`}
              onClaim={() => onClaim(level, 'plus')}
            />
          </div>
        );
      })}
    </div>
  );
}

function Reward({ reward, state, plus, busy, onClaim }: { reward: PassReward | null; state: 'claimed' | 'ready' | 'locked' | 'plus'; plus?: boolean; busy: boolean; onClaim: () => void }) {
  const catalog = useCatalog();
  // What it would be right now: the brainrot or the case that fits the value (the rest comes as coins).
  const preview = useMemo(() => {
    if (reward?.kind === 'brainrot') return payoutFor(reward.value, catalog.active).brainrot;
    if (reward?.kind === 'case') return passCaseFor(reward.value, catalog.cases).case;
    return null;
  }, [reward, catalog.active, catalog.cases]);
  // A FREE level without a reward: an empty slot keeps the track's rhythm.
  if (!reward) return <span className={cx('pass-cell', 'pass-cell--empty', plus && 'pass-cell--plus')} aria-hidden="true" />;
  const ready = state === 'ready';
  const label =
    reward.kind === 'tickets'
      ? `${reward.amount} тикетов`
      : reward.kind === 'coins'
        ? `${reward.amount} B монетами`
        : reward.kind === 'case'
          ? `Открытие кейса ${preview ? `«${preview.name}»` : ''} на ${reward.value} B`
          : `Брейнрот на ${reward.value} B`;
  return (
    <button type="button" className={cx('pass-cell', plus && 'pass-cell--plus', reward.kind === 'case' && 'pass-cell--case', `is-${state}`)} disabled={!ready || busy} onClick={onClaim} aria-label={label} title={label}>
      <span className="pass-cell__art">
        {reward.kind === 'tickets' ? <Ticket size={30} /> : preview ? <img src={preview.image} alt="" /> : <Coin size={30} />}
      </span>
      <span className="pass-cell__value">
        {reward.kind === 'tickets' ? (
          `×${reward.amount}`
        ) : reward.kind === 'coins' ? (
          <>
            +{formatCoins(reward.amount)} <Coin size={11} />
          </>
        ) : (
          <>
            {formatCoins(reward.value)} <Coin size={11} />
          </>
        )}
      </span>
      {reward.kind === 'case' && <span className="pass-cell__tag">кейс</span>}
      {state === 'claimed' && (
        <span className="pass-cell__badge">
          <Icon name="check" size={12} />
        </span>
      )}
      {state === 'plus' && (
        <span className="pass-cell__badge pass-cell__badge--lock">
          <Icon name="lock" size={12} />
        </span>
      )}
    </button>
  );
}
