-- Iteration 36: «отыгрыш» (wagering) before a withdrawal. Applied by the Worker (server/autoMigrate.ts), so every
-- statement is safe to run twice.
--
-- Deposits and everything free (bonus cases, cashback, promo codes, prizes, admin gifts…) must be played through
-- × the multiplier of `withdraw_rules` (wagerDeposit / wagerBonus, default 1.25) before a withdrawal: every real stake
-- in any game counts. Winnings of the player's own stakes add nothing (each stake returns 0.88 on average — adding
-- 1.25 × that would make the requirement grow faster than it is played).

-- What is still to be played, and the whole of the current round (for the progress bar). Old players start at zero.
ALTER TABLE users ADD COLUMN IF NOT EXISTS wager_left NUMERIC(16, 2) NOT NULL DEFAULT 0;
ALTER TABLE users ADD COLUMN IF NOT EXISTS wager_total NUMERIC(16, 2) NOT NULL DEFAULT 0;

-- The admin's multiplier for 'deposit' or 'bonus' (0…10), 1.25 when unset (= DEFAULT_WITHDRAW_RULES in shared/withdraw.ts).
CREATE OR REPLACE FUNCTION wager_rate(kind TEXT) RETURNS NUMERIC LANGUAGE sql STABLE AS $$
  SELECT coalesce(
    (SELECT least(greatest((value ->> CASE WHEN kind = 'deposit' THEN 'wagerDeposit' ELSE 'wagerBonus' END)::numeric, 0), 10)
       FROM settings
      WHERE key = 'withdraw_rules'
        AND jsonb_typeof(value -> CASE WHEN kind = 'deposit' THEN 'wagerDeposit' ELSE 'wagerBonus' END) = 'number'),
    1.25)
$$;

-- Adds `amount` × the multiplier to the player's requirement; a new round starts when the last one was played out.
CREATE OR REPLACE FUNCTION wager_add(uid BIGINT, amount NUMERIC, kind TEXT) RETURNS NUMERIC LANGUAGE plpgsql AS $$
DECLARE
  need NUMERIC := round(greatest(coalesce(amount, 0), 0) * wager_rate(kind), 2);
BEGIN
  IF need > 0 THEN
    UPDATE users
       SET wager_total = CASE WHEN wager_left > 0 THEN wager_total ELSE 0 END + need,
           wager_left = wager_left + need
     WHERE id = uid;
  END IF;
  RETURN need;
END $$;

-- Every game ends in `drops`, so one trigger sees them all: a real stake plays the requirement down; a drop with no
-- stake (free, bonus, gift and ticket cases) is free value and adds to it. Demo games touch nothing.
CREATE OR REPLACE FUNCTION drops_wager() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.demo THEN
    RETURN NULL;
  END IF;
  IF NEW.stake_value > 0 THEN
    UPDATE users SET wager_left = greatest(wager_left - NEW.stake_value, 0) WHERE id = NEW.user_id AND wager_left > 0;
  ELSIF coalesce(NEW.payout_value, 0) > 0 THEN
    PERFORM wager_add(NEW.user_id, NEW.payout_value, 'bonus');
  END IF;
  RETURN NULL;
END $$;
DROP TRIGGER IF EXISTS drops_wager ON drops;
CREATE TRIGGER drops_wager AFTER INSERT ON drops FOR EACH ROW EXECUTE FUNCTION drops_wager();
