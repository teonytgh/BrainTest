import type { CSSProperties } from 'react';

/**
 * The gold BC coin (public/coin.webp, a bigger copy for large sizes; scripts/blender/brand.py). Its size is inline so that `img` rules of the
 * cards it sits in (brainrot pictures: width %, float animations) never stretch it.
 */
export function Coin({ size = 18, className }: { size?: number; className?: string }) {
  const style: CSSProperties = { width: size, height: size, minWidth: size, maxWidth: size, flex: 'none', position: 'static', animation: 'none', transform: 'none', margin: 0 };
  return (
    <img
      className={className ? `coin ${className}` : 'coin'}
      src={size > 48 ? '/coin-256.webp' : '/coin.webp'}
      width={size}
      height={size}
      style={style}
      alt=""
      aria-hidden="true"
      draggable={false}
      decoding="async"
    />
  );
}
