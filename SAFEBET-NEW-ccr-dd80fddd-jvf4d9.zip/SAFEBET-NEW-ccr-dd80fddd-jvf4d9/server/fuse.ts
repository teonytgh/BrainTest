import { createHash, randomBytes } from 'node:crypto';
import { MAX_FUSE_ITEMS, MIN_FUSE_ITEMS, fuseMessage, fuseOutcome, fuseTable, pickFuse, type FuseResult, type FuseState } from '../shared/fuse';
import { round2 } from '../shared/money';
import { assertActive, type Viewer } from './auth';
import { activeBrainrots, publicName } from './catalog';
import { ms, num, q, tx, type Queryable } from './db';
import { giveItems, recordDrop, stakeDemo, takeItem } from './economy';
import { bad } from './errors';
import { ids, type Body } from './validate';

const sha256 = (s: string) => createHash('sha256').update(s).digest('hex');

function newSeed() {
  const seed = randomBytes(32).toString('hex');
  return { seed, hash: sha256(seed) };
}

/** The player's next fuse key, created on first use; locked by a fuse so that it is used exactly once. */
async function seedRow(c: Queryable, userId: number, lock: boolean) {
  const s = newSeed();
  await c.query('INSERT INTO fuse_seeds (user_id, seed, hash) VALUES ($1, $2, $3) ON CONFLICT (user_id) DO NOTHING', [userId, s.seed, s.hash]);
  const { rows } = await c.query<{ seed: string; hash: string }>(`SELECT seed, hash FROM fuse_seeds WHERE user_id = $1${lock ? ' FOR UPDATE' : ''}`, [userId]);
  return rows[0]!;
}

interface DropRow {
  stake_value: string;
  payout_value: string | null;
  brainrot_id: string;
  meta: { from?: string[] } | null;
  created_at: string;
}

export async function fuseState(v: Viewer): Promise<FuseState> {
  const [seed, mine, top] = await Promise.all([
    tx((c) => seedRow(c, v.id, false)),
    q<DropRow>(`SELECT stake_value, payout_value, brainrot_id, meta, created_at FROM drops WHERE user_id = $1 AND game = 'fuse' ORDER BY id DESC LIMIT 12`, [v.id]),
    q<DropRow & { first_name: string; last_name: string | null }>(
      `SELECT d.stake_value, d.payout_value, d.brainrot_id, d.meta, d.created_at, u.first_name, u.last_name
       FROM drops d JOIN users u ON u.id = d.user_id
       WHERE d.game = 'fuse' AND d.payout_value > d.stake_value AND NOT d.demo
       ORDER BY d.payout_value DESC, d.id LIMIT 10`,
    ),
  ]);
  return {
    nextHash: seed.hash,
    mine: mine.map((d) => ({ from: d.meta?.from ?? [], brainrotId: d.brainrot_id, stakeValue: num(d.stake_value), value: num(d.payout_value), at: ms(d.created_at)! })),
    top: top.map((d) => ({
      name: publicName(d),
      brainrotId: d.brainrot_id,
      stakeValue: num(d.stake_value),
      value: num(d.payout_value),
      multiplier: fuseOutcome(num(d.stake_value), num(d.payout_value)).multiplier,
      at: ms(d.created_at)!,
    })),
  };
}

/** One fuse: 3–4 brainrots go in, one random brainrot comes out (see shared/fuse.ts for the odds). */
export async function runFuse(v: Viewer, body: Body): Promise<FuseResult> {
  assertActive(v);
  if (body.coins) throw bad('items_only', 'Ставка — только брейнроты');
  const raw = body.itemIds;
  if (!Array.isArray(raw) || raw.length < MIN_FUSE_ITEMS || raw.length > MAX_FUSE_ITEMS) throw bad('invalid', `Положи от ${MIN_FUSE_ITEMS} до ${MAX_FUSE_ITEMS} брейнротов`);
  const itemIds = ids(raw, 'брейнроты', MAX_FUSE_ITEMS);
  if (itemIds.length < MIN_FUSE_ITEMS) throw bad('invalid', `Положи от ${MIN_FUSE_ITEMS} до ${MAX_FUSE_ITEMS} брейнротов`);
  return tx(async (c) => {
    const key = await seedRow(c, v.id, true);
    const stakes = [];
    for (const id of itemIds) stakes.push(await takeItem(c, v.id, id));
    const demo = stakeDemo(stakes);
    const stakeValue = round2(stakes.reduce((s, x) => s + x.price, 0));
    const table = fuseTable(stakeValue, await activeBrainrots(c));
    if (!table) throw bad('stake_too_big', 'Слишком дорогой набор — машине нечем ответить. Убери что-нибудь');
    const won = pickFuse(table, sha256(fuseMessage(key.seed)));
    const [itemId] = await giveItems(c, v.id, won.id, 'fuse', 1, demo);
    const next = newSeed();
    await c.query('UPDATE fuse_seeds SET seed = $2, hash = $3, nonce = nonce + 1 WHERE user_id = $1', [v.id, next.seed, next.hash]);
    const { multiplier } = fuseOutcome(stakeValue, won.price);
    await recordDrop(c, {
      userId: v.id,
      game: 'fuse',
      win: won.price >= stakeValue,
      stakeValue,
      brainrotId: won.id,
      payoutValue: won.price,
      meta: { from: stakes.map((x) => x.brainrotId), multiplier, hash: key.hash, seed: key.seed },
      demo,
    });
    return { stakeValue, brainrotId: won.id, itemId: itemId!, value: won.price, multiplier, seed: key.seed, hash: key.hash, nextHash: next.hash };
  });
}
