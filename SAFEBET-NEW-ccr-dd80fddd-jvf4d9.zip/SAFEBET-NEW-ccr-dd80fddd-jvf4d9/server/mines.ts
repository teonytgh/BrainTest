import { createHash, randomBytes } from 'node:crypto';
import { round2 } from '../shared/money';
import { payoutFor } from '../shared/payout';
import {
  MAX_MINES,
  MAX_MINES_ITEMS,
  MAX_MINES_PAYOUT,
  MINES_TILES,
  MIN_MINES,
  MIN_MINES_STAKE,
  minesFromDigests,
  minesMessage,
  minesMultiplier,
  nextPickProblem,
  type MinesRun,
  type MinesState,
} from '../shared/mines';
import { assertActive, type Viewer } from './auth';
import { activeBrainrots, publicName } from './catalog';
import { ms, num, q, tx, type Queryable } from './db';
import { giveItems, payOut, recordDrop, stakeDemo, takeItem } from './economy';
import { bad } from './errors';
import { afterResponse } from './live';
import { notify } from './telegram';
import { ids, int, type Body } from './validate';

const sha256 = (s: string) => createHash('sha256').update(s).digest('hex');

/** A round nobody touched for this long is closed by the tick: the win is taken for the player, or the stake returned. */
export const MINES_IDLE_MS = 30 * 60 * 1000;

function newSeed() {
  const seed = randomBytes(32).toString('hex');
  return { seed, hash: sha256(seed) };
}

/** The player's next mines key, created on first use; locked by a start so that it is used exactly once. */
async function seedRow(c: Queryable, userId: number, lock: boolean) {
  const s = newSeed();
  await c.query('INSERT INTO mines_seeds (user_id, seed, hash) VALUES ($1, $2, $3) ON CONFLICT (user_id) DO NOTHING', [userId, s.seed, s.hash]);
  const { rows } = await c.query<{ seed: string; hash: string }>(`SELECT seed, hash FROM mines_seeds WHERE user_id = $1${lock ? ' FOR UPDATE' : ''}`, [userId]);
  return rows[0]!;
}

interface RunRow {
  id: string;
  user_id: string;
  mines: number;
  stake_value: string;
  stake: string[];
  seed: string;
  hash: string;
  mines_at: number[];
  picks: number[];
  bust: number | null;
  status: MinesRun['status'];
  payout: MinesRun['payout'];
  /** Played with demo brainrots (iteration 35): the win or the refund is demo. */
  demo: boolean;
}

function runView(r: RunRow): MinesRun {
  const stakeValue = num(r.stake_value);
  const over = r.status !== 'active';
  const opened = r.picks.length;
  return {
    id: num(r.id),
    mines: r.mines,
    picks: r.picks,
    status: r.status,
    bust: r.bust,
    stakeValue,
    stake: r.stake,
    multiplier: minesMultiplier(r.mines, opened),
    next: { multiplier: minesMultiplier(r.mines, opened + 1), problem: nextPickProblem(r.mines, opened, stakeValue) },
    hash: r.hash,
    // The field stays secret while the round runs.
    seed: over ? r.seed : null,
    minesAt: over ? r.mines_at : null,
    payout: r.payout,
  };
}

const activeRun = async (c: Queryable, userId: number) =>
  (await c.query<RunRow>(`SELECT * FROM mines_runs WHERE user_id = $1 AND status = 'active' FOR UPDATE`, [userId])).rows[0];

interface DropRow {
  result: 'win' | 'lose';
  stake_value: string;
  payout_value: string | null;
  brainrot_id: string | null;
  meta: { mines?: number; picks?: number; multiplier?: number } | null;
  created_at: string;
}

export async function minesState(v: Viewer): Promise<MinesState> {
  const [seed, run, mine, top] = await Promise.all([
    tx((c) => seedRow(c, v.id, false)),
    q<RunRow>(`SELECT * FROM mines_runs WHERE user_id = $1 AND status = 'active'`, [v.id]),
    q<DropRow>(`SELECT result, stake_value, payout_value, brainrot_id, meta, created_at FROM drops WHERE user_id = $1 AND game = 'mines' ORDER BY id DESC LIMIT 12`, [v.id]),
    q<DropRow & { first_name: string; last_name: string | null }>(
      `SELECT d.result, d.stake_value, d.payout_value, d.brainrot_id, d.meta, d.created_at, u.first_name, u.last_name
       FROM drops d JOIN users u ON u.id = d.user_id
       WHERE d.game = 'mines' AND d.result = 'win' AND NOT d.demo
       ORDER BY d.payout_value DESC, d.id LIMIT 10`,
    ),
  ]);
  return {
    nextHash: seed.hash,
    run: run[0] ? runView(run[0]) : null,
    mine: mine.map((d) => ({
      mines: d.meta?.mines ?? 0,
      picks: d.meta?.picks ?? 0,
      won: Number(d.meta?.multiplier ?? 0) > 0,
      multiplier: Number(d.meta?.multiplier ?? 0),
      value: num(d.payout_value),
      stakeValue: num(d.stake_value),
      at: ms(d.created_at)!,
    })),
    top: top.map((d) => ({
      name: publicName(d),
      mines: d.meta?.mines ?? 0,
      picks: d.meta?.picks ?? 0,
      multiplier: Number(d.meta?.multiplier ?? 0),
      value: num(d.payout_value),
      brainrotId: d.brainrot_id,
      at: ms(d.created_at)!,
    })),
  };
}

/** The stake goes in and the field is laid from the key whose hash the player saw. */
export async function startMines(v: Viewer, body: Body): Promise<{ run: MinesRun; nextHash: string }> {
  assertActive(v);
  const mines = int(body.mines, 'мины', MIN_MINES, MAX_MINES);
  if (body.coins) throw bad('items_only', 'Ставка — только брейнроты');
  const raw = body.itemIds ?? [];
  if (Array.isArray(raw) && raw.length === 0) throw bad('invalid', 'Поставь брейнротов');
  const itemIds = ids(raw, 'брейнроты', MAX_MINES_ITEMS);
  return tx(async (c) => {
    // The key row lock serialises the player's starts: the active-round check below can't race.
    const key = await seedRow(c, v.id, true);
    if (await activeRun(c, v.id)) throw bad('run_active', 'Сначала закончи раунд');
    const stakes = [];
    for (const id of itemIds) stakes.push(await takeItem(c, v.id, id));
    const demo = stakeDemo(stakes);
    const stakeValue = round2(stakes.reduce((s, x) => s + x.price, 0));
    if (stakeValue < MIN_MINES_STAKE) throw bad('stake_too_small', `Ставка — от ${MIN_MINES_STAKE} B`);
    if (nextPickProblem(mines, 0, stakeValue)) throw bad('limit', `Слишком большая ставка: выигрыш больше ${MAX_MINES_PAYOUT.toLocaleString('ru-RU')} B`);
    const minesAt = minesFromDigests(
      mines,
      Array.from({ length: mines }, (_, i) => sha256(minesMessage(key.seed, i))),
    );
    const { rows } = await c.query<RunRow>(
      `INSERT INTO mines_runs (user_id, mines, stake_value, stake, seed, hash, mines_at, demo) VALUES ($1, $2, $3, $4::jsonb, $5, $6, $7, $8) RETURNING *`,
      [v.id, mines, stakeValue, JSON.stringify(stakes.map((x) => x.brainrotId)), key.seed, key.hash, minesAt, demo],
    );
    const next = newSeed();
    await c.query('UPDATE mines_seeds SET seed = $2, hash = $3, nonce = nonce + 1 WHERE user_id = $1', [v.id, next.seed, next.hash]);
    return { run: runView(rows[0]!), nextHash: next.hash };
  });
}

/** Takes the current win: a catalog brainrot + change in coins. */
async function cashOut(c: Queryable, r: RunRow): Promise<RunRow> {
  const userId = num(r.user_id);
  const stakeValue = num(r.stake_value);
  const multiplier = minesMultiplier(r.mines, r.picks.length);
  const payout = payoutFor(stakeValue * multiplier, await activeBrainrots(c));
  const itemId = await payOut(c, userId, payout, 'mines', r.demo);
  const paid = { brainrotId: payout.brainrot?.id ?? null, coins: payout.coins, itemId, value: payout.value };
  const { rows } = await c.query<RunRow>(
    `UPDATE mines_runs SET status = 'cashed', payout = $2::jsonb, updated_at = now(), finished_at = now() WHERE id = $1 RETURNING *`,
    [r.id, JSON.stringify(paid)],
  );
  await recordDrop(c, {
    userId,
    game: 'mines',
    // Leaving below x1 gives part of the stake back: taken, but no win (and no LIVE tile).
    win: multiplier >= 1,
    stakeValue,
    brainrotId: paid.brainrotId,
    coins: paid.coins,
    payoutValue: paid.value,
    meta: { mines: r.mines, picks: r.picks.length, multiplier, hash: r.hash, seed: r.seed, from: r.stake },
    demo: r.demo,
  });
  return rows[0]!;
}

/** One tile: a mine burns the stake; when nothing more can be opened the win is taken at once. */
export async function pickMines(v: Viewer, body: Body): Promise<{ run: MinesRun; busted: boolean }> {
  assertActive(v);
  const tile = int(body.tile, 'клетка', 0, MINES_TILES - 1);
  return tx(async (c) => {
    const r = await activeRun(c, v.id);
    if (!r) throw bad('no_run', 'Раунд не начат');
    if (r.picks.includes(tile)) throw bad('taken', 'Эта клетка уже открыта');
    const stakeValue = num(r.stake_value);
    if (nextPickProblem(r.mines, r.picks.length, stakeValue)) throw bad('limit', 'Дальше открывать нельзя — забирай выигрыш');
    if (r.mines_at.includes(tile)) {
      const { rows } = await c.query<RunRow>(
        `UPDATE mines_runs SET status = 'busted', bust = $2, updated_at = now(), finished_at = now() WHERE id = $1 RETURNING *`,
        [r.id, tile],
      );
      await recordDrop(c, {
        userId: v.id,
        game: 'mines',
        win: false,
        stakeValue,
        payoutValue: 0,
        meta: { mines: r.mines, picks: r.picks.length, bust: tile, multiplier: 0, hash: r.hash, seed: r.seed, from: r.stake },
        demo: r.demo,
      });
      return { run: runView(rows[0]!), busted: true };
    }
    const { rows } = await c.query<RunRow>(`UPDATE mines_runs SET picks = array_append(picks, $2), updated_at = now() WHERE id = $1 RETURNING *`, [r.id, tile]);
    const moved = rows[0]!;
    const done = nextPickProblem(r.mines, moved.picks.length, stakeValue) ? await cashOut(c, moved) : moved;
    return { run: runView(done), busted: false };
  });
}

export async function cashoutMines(v: Viewer): Promise<{ run: MinesRun }> {
  assertActive(v);
  return tx(async (c) => {
    const r = await activeRun(c, v.id);
    if (!r) throw bad('no_run', 'Раунд не начат');
    if (r.picks.length < 1) throw bad('no_step', 'Открой хотя бы одну клетку');
    return { run: runView(await cashOut(c, r)) };
  });
}

/**
 * The tick closes rounds left alone for MINES_IDLE_MS: after a clear tile the win is taken for the player, before
 * one the same brainrots go back.
 */
export async function closeIdleMines(now = Date.now()) {
  const cutoff = new Date(now - MINES_IDLE_MS);
  const stale = await q<{ id: string }>(`SELECT id FROM mines_runs WHERE status = 'active' AND updated_at < $1 ORDER BY updated_at LIMIT 20`, [cutoff]);
  let closed = 0;
  for (const { id } of stale) {
    const done = await tx(async (c) => {
      const r = (await c.query<RunRow>(`SELECT * FROM mines_runs WHERE id = $1 AND status = 'active' AND updated_at < $2 FOR UPDATE`, [id, cutoff])).rows[0];
      if (!r) return null;
      if (r.picks.length >= 1) return cashOut(c, r);
      for (const brainrotId of r.stake) await giveItems(c, num(r.user_id), brainrotId, 'mines_refund', 1, r.demo);
      return (
        await c.query<RunRow>(`UPDATE mines_runs SET status = 'refunded', updated_at = now(), finished_at = now() WHERE id = $1 RETURNING *`, [r.id])
      ).rows[0]!;
    });
    if (!done) continue;
    closed++;
    const value = done.payout?.value ?? 0;
    await afterResponse(() =>
      notify(
        num(done.user_id),
        done.status === 'refunded'
          ? '💣 Раунд в «Минах» простоял 30 минут без хода — ставка вернулась в инвентарь.'
          : `💣 Ты оставил раунд в «Минах» после ${done.picks.length} клеток — выигрыш <b>${value.toLocaleString('ru-RU')} B</b> уже в инвентаре.`,
      ),
    );
  }
  return closed;
}
