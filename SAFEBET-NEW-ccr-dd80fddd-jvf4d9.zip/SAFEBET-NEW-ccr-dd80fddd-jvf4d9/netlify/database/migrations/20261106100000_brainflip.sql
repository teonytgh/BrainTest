-- Iteration 30: «BrainFlip» — CoinFlip on brainrot stakes (shared/flip.ts). Applied on production by the Worker itself
-- (server/autoMigrate.ts), so every statement must be safe to run twice.

-- One flip: the creator's brainrots (out of the inventory while it is open), the joiner's or the bot's, the key whose
-- sha256 was shown when it opened, and the side the coin showed.
CREATE TABLE IF NOT EXISTS flips (
  id BIGSERIAL PRIMARY KEY,
  creator_id BIGINT NOT NULL REFERENCES users (id),
  side TEXT NOT NULL CHECK (side IN ('b', 'c')),
  creator_items JSONB NOT NULL,
  creator_value NUMERIC(16, 2) NOT NULL CHECK (creator_value > 0),
  joiner_id BIGINT REFERENCES users (id),
  bot BOOLEAN NOT NULL DEFAULT false,
  joiner_items JSONB,
  joiner_value NUMERIC(16, 2),
  seed TEXT NOT NULL,
  hash TEXT NOT NULL,
  result TEXT CHECK (result IN ('b', 'c')),
  status TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'done', 'cancelled')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  finished_at TIMESTAMPTZ
);
CREATE UNIQUE INDEX IF NOT EXISTS flips_one_open ON flips (creator_id) WHERE status = 'open';
CREATE INDEX IF NOT EXISTS flips_open ON flips (created_at DESC) WHERE status = 'open';
CREATE INDEX IF NOT EXISTS flips_done ON flips (finished_at DESC) WHERE status = 'done';

DO $$
BEGIN
  ALTER TABLE flips ENABLE ROW LEVEL SECURITY;
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'anon') THEN
    REVOKE ALL ON flips FROM anon, authenticated;
  END IF;
END $$;
