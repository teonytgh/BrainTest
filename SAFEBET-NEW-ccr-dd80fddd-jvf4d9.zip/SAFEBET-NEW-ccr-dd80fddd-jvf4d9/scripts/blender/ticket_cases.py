"""Art for the ticket cases «Затмение» and «Кенди» and the floating-price «Биткоин» (iteration 35), in the style of
the production case art: an open neon-trimmed voxel chest seen from above at three quarters, its name glowing on the
front.

    blender -b -y --factory-startup --python scripts/blender/ticket_cases.py -- OUT_DIR [--preview] [--only=bitcoin]

«Биткоин»: a graphite chest in bitcoin orange, a glowing ₿ inside the lid, orange coins and a green chart arrow
shooting up out of the chest (its price jumps between 99 and 10 000 B).

«Затмение»: a black-violet chest, the eclipse — a black sun in a gold corona — inside the lid, gold coins in the chest
(it drops coins and cheap brainrots, so no expensive brainrot is drawn in it). «Кенди»: a pink-and-mint chest with candy
stripes, a swirl lollipop inside the lid, wrapped sweets and lollipops in the chest. Each goes to OUT_DIR/<id>.png
(512 × 512, transparent); `cwebp -q 88` → public/cases/<id>.webp.
"""
import math
import os
import sys

import bpy
from mathutils import Vector

ARGS = sys.argv[sys.argv.index('--') + 1:] if '--' in sys.argv else []
POSITIONAL = [a for a in ARGS if not a.startswith('--')]
OUT = os.path.abspath(POSITIONAL[0] if POSITIONAL else 'ticket_cases')
PREVIEW = '--preview' in ARGS
ONLY = next((a.split('=', 1)[1].split(',') for a in ARGS if a.startswith('--only=')), None)
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
# RobotoCondensed has Cyrillic; the repo's Unbounded is a Latin-only subset.
FONT = os.path.join(ROOT, 'scripts', 'blender', 'fonts', 'RobotoCondensed-Bold.ttf')
os.makedirs(OUT, exist_ok=True)
scene = bpy.context.scene


def lin(c):
    def ch(v):
        v /= 255
        return v / 12.92 if v <= 0.04045 else ((v + 0.055) / 1.055) ** 2.4
    return (ch(c[0]), ch(c[1]), ch(c[2]), 1.0)


def clear():
    for o in list(bpy.data.objects):
        bpy.data.objects.remove(o, do_unlink=True)
    for m in list(bpy.data.materials):
        bpy.data.materials.remove(m)


def mat(name, rgb, rough=0.5, metal=0.0, emit=None, strength=0.0, checker=None):
    """A principled material; `checker` = (rgb2, scale) gives the voxel-tile look of the production art."""
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    nt = m.node_tree
    b = nt.nodes['Principled BSDF']
    b.inputs['Base Color'].default_value = lin(rgb)
    b.inputs['Roughness'].default_value = rough
    b.inputs['Metallic'].default_value = metal
    if emit:
        b.inputs['Emission Color'].default_value = lin(emit)
        b.inputs['Emission Strength'].default_value = strength
    if checker:
        tex = nt.nodes.new('ShaderNodeTexChecker')
        tex.inputs['Color1'].default_value = lin(rgb)
        tex.inputs['Color2'].default_value = lin(checker[0])
        tex.inputs['Scale'].default_value = checker[1]
        coord = nt.nodes.new('ShaderNodeTexCoord')
        nt.links.new(coord.outputs['Object'], tex.inputs['Vector'])
        nt.links.new(tex.outputs['Color'], b.inputs['Base Color'])
    return m


def box(name, size, loc, material, parent=None, bevel=0.0, rot=(0, 0, 0)):
    bpy.ops.mesh.primitive_cube_add(size=1, location=loc, rotation=rot)
    o = bpy.context.active_object
    o.name = name
    o.scale = size
    bpy.ops.object.transform_apply(scale=True)
    if bevel:
        mod = o.modifiers.new('bevel', 'BEVEL')
        mod.width = bevel
        mod.segments = 2
    o.data.materials.append(material)
    if parent:
        o.parent = parent
    return o


def cylinder(name, r, depth, loc, material, rot=(0, 0, 0), verts=32, parent=None):
    bpy.ops.mesh.primitive_cylinder_add(vertices=verts, radius=r, depth=depth, location=loc, rotation=rot)
    o = bpy.context.active_object
    o.name = name
    o.data.materials.append(material)
    if parent:
        o.parent = parent
    return o


def sphere(name, r, loc, material, scale=(1, 1, 1), parent=None):
    bpy.ops.mesh.primitive_uv_sphere_add(radius=r, location=loc, segments=24, ring_count=12)
    o = bpy.context.active_object
    o.name = name
    o.scale = scale
    o.data.materials.append(material)
    bpy.ops.object.shade_smooth()
    if parent:
        o.parent = parent
    return o


def torus(name, major, minor, loc, material, rot=(0, 0, 0), parent=None):
    bpy.ops.mesh.primitive_torus_add(major_radius=major, minor_radius=minor, location=loc, rotation=rot, major_segments=48, minor_segments=12)
    o = bpy.context.active_object
    o.name = name
    o.data.materials.append(material)
    bpy.ops.object.shade_smooth()
    if parent:
        o.parent = parent
    return o


def text(body, size, loc, material, outline):
    """Extruded glowing letters with a darker, fatter copy behind them as the outline."""
    font = bpy.data.fonts.load(FONT, check_existing=True)
    made = []
    for k, (m, ext, off, grow) in enumerate(((outline, 0.03, 0.035, 0.04), (material, 0.05, 0.0, 0.0))):
        cu = bpy.data.curves.new(f'txt{k}', 'FONT')
        cu.body = body
        cu.font = font
        cu.size = size
        cu.align_x = 'CENTER'
        cu.align_y = 'CENTER'
        cu.extrude = ext
        cu.offset = grow
        o = bpy.data.objects.new(f'txt{k}', cu)
        scene.collection.objects.link(o)
        o.location = (loc[0], loc[1] + off, loc[2])
        o.rotation_euler = (math.radians(90), 0, 0)
        o.data.materials.append(m)
        made.append(o)
    return made


def chest(theme):
    """The open chest at the origin: base 2.6 × 1.6 × 1.25, the lid swung back."""
    W, D, H = 2.6, 1.6, 1.25
    body_m = mat('body', theme['body'], 0.65, checker=(theme['body2'], 9.0))
    trim_m = mat('trim', theme['trim'], 0.3, emit=theme['trim'], strength=theme['trim_glow'])
    metal_m = mat('metal', theme['metal'], 0.35, 0.8)
    inner_m = mat('inner', theme['inner'], 0.8, checker=(theme['inner2'], 12.0))
    root = bpy.data.objects.new('chest', None)
    scene.collection.objects.link(root)
    # Base: walls around a dark inside.
    box('floor', (W, D, 0.12), (0, 0, 0.06), body_m, root)
    for name, size, loc in (
        ('front', (W, 0.14, H), (0, -D / 2 + 0.07, H / 2)),
        ('back', (W, 0.14, H), (0, D / 2 - 0.07, H / 2)),
        ('left', (0.14, D, H), (-W / 2 + 0.07, 0, H / 2)),
        ('right', (0.14, D, H), (W / 2 - 0.07, 0, H / 2)),
    ):
        box(name, size, loc, body_m, root, bevel=0.01)
    box('inside', (W - 0.28, D - 0.28, 0.02), (0, 0, 0.13), inner_m, root)
    # Neon trims along the base's edges and corner plates.
    t = 0.08
    for z in (0.04, H - 0.04):
        box('trim-f', (W + 0.02, t, t), (0, -D / 2 - 0.01, z), trim_m, root)
        box('trim-b', (W + 0.02, t, t), (0, D / 2 + 0.01, z), trim_m, root)
        box('trim-l', (t, D + 0.02, t), (-W / 2 - 0.01, 0, z), trim_m, root)
        box('trim-r', (t, D + 0.02, t), (W / 2 + 0.01, 0, z), trim_m, root)
    for x in (-W / 2, W / 2):
        for y in (-D / 2, D / 2):
            box('post', (t, t, H), (x + (0.01 if x > 0 else -0.01), y + (0.01 if y > 0 else -0.01), H / 2), trim_m, root)
            box('plate', (0.26, 0.26, 0.26), (x, y, H - 0.13), metal_m, root, bevel=0.02)
            box('plate-low', (0.26, 0.26, 0.22), (x, y, 0.11), metal_m, root, bevel=0.02)
    # Handles on the sides.
    for x in (-W / 2 - 0.06, W / 2 + 0.06):
        box('handle', (0.06, 0.5, 0.08), (x, 0, H * 0.62), metal_m, root)
        box('handle-l', (0.06, 0.08, 0.22), (x, -0.21, H * 0.62 - 0.07), metal_m, root)
        box('handle-r', (0.06, 0.08, 0.22), (x, 0.21, H * 0.62 - 0.07), metal_m, root)
    # Lid: hinged at the back top edge, opened back past upright.
    hinge = bpy.data.objects.new('hinge', None)
    scene.collection.objects.link(hinge)
    hinge.location = (0, D / 2, H)
    LD = 1.55
    box('lid', (W, LD, 0.16), (0, -LD / 2, 0.08), body_m, hinge, bevel=0.01)
    box('lid-inner', (W - 0.3, LD - 0.3, 0.02), (0, -LD / 2, -0.005), inner_m, hinge)
    for y in (-LD + 0.04, -0.04):
        box('lid-trim', (W + 0.02, t, t), (0, y, 0.16), trim_m, hinge)
    for x in (-W / 2 - 0.01, W / 2 + 0.01):
        box('lid-trim-s', (t, LD, t), (x, -LD / 2, 0.16), trim_m, hinge)
        box('lid-plate', (0.26, 0.26, 0.24), (x, -LD + 0.13, 0.08), metal_m, hinge, bevel=0.02)
    hinge.rotation_euler = (math.radians(-118), 0, 0)
    return root, hinge, (W, D, H, LD)


def scene_setup(theme):
    cam_d = bpy.data.cameras.new('cam')
    cam_d.lens = 63
    cam = bpy.data.objects.new('cam', cam_d)
    scene.collection.objects.link(cam)
    cam.location = (3.9, -6.6, 4.7)
    direction = Vector((0.0, 0.25, 1.05)) - cam.location
    cam.rotation_euler = direction.to_track_quat('-Z', 'Y').to_euler()
    scene.camera = cam
    # Soft lights only: the neon trims, the lid art and the glowing contents carry the picture (the production
    # art is mostly emission). Lights stay invisible to the camera.
    for name, loc, energy, color, size in (
        ('key', (-3.5, -5.0, 6.5), 110, (1, 0.97, 0.94), 4.0),
        ('fill', (5.5, -3.0, 2.5), 30, theme['fill'], 4.0),
        ('rim', (-1.0, 5.0, 4.0), 90, theme['rim'], 3.0),
    ):
        d = bpy.data.lights.new(name, 'AREA')
        d.energy = energy
        d.color = color
        d.size = size
        o = bpy.data.objects.new(name, d)
        o.location = loc
        o.visible_camera = False
        scene.collection.objects.link(o)
        o.rotation_euler = (Vector((0, 0, 0.8)) - Vector(loc)).to_track_quat('-Z', 'Y').to_euler()
    world = bpy.data.worlds.new('w')
    world.use_nodes = True
    world.node_tree.nodes['Background'].inputs['Color'].default_value = (0.02, 0.02, 0.03, 1)
    world.node_tree.nodes['Background'].inputs['Strength'].default_value = 0.3
    scene.world = world
    scene.render.engine = 'CYCLES'
    scene.cycles.device = 'CPU'
    scene.cycles.samples = 32 if PREVIEW else 128
    scene.cycles.use_denoising = True
    scene.render.film_transparent = True
    scene.render.resolution_x = scene.render.resolution_y = 256 if PREVIEW else 512
    scene.render.image_settings.file_format = 'PNG'
    scene.render.image_settings.color_mode = 'RGBA'
    scene.view_settings.view_transform = 'Standard'


def lid_art(hinge, dims, theme, kind):
    """The lid's inside: the eclipse or the lollipop swirl, glowing, plus little sparkles."""
    W, D, H, LD = dims
    zc = -0.03
    if kind == 'eclipse':
        corona = mat('corona', (255, 190, 70), 0.3, emit=(255, 170, 50), strength=9.0)
        moon = mat('moon', (10, 8, 16), 0.4)
        torus('corona', 0.42, 0.06, (0, -LD / 2, zc), corona, parent=hinge)
        for k in range(16):
            a = k * math.tau / 16
            ln = 0.16 if k % 2 else 0.26
            box('ray', (0.05, ln, 0.02), (math.cos(a) * (0.52 + ln / 2), -LD / 2 + math.sin(a) * (0.52 + ln / 2), zc), corona, hinge, rot=(0, 0, a - math.pi / 2))
        cylinder('moon', 0.39, 0.04, (0, -LD / 2, zc - 0.02), moon, parent=hinge)
    elif kind == 'bitcoin':
        # ₿: a fat glowing B with the two strokes through its top and bottom, in a ring.
        orange = mat('btc', (247, 147, 26), 0.3, emit=(255, 150, 30), strength=8.0)
        ring_m = mat('btc-ring', (255, 200, 90), 0.3, emit=(255, 180, 60), strength=5.0)
        torus('btc-ring', 0.5, 0.045, (0, -LD / 2, zc), ring_m, parent=hinge)
        font = bpy.data.fonts.load(FONT, check_existing=True)
        cu = bpy.data.curves.new('btc-b', 'FONT')
        cu.body = 'B'
        cu.font = font
        cu.size = 0.78
        cu.align_x = 'CENTER'
        cu.align_y = 'CENTER'
        cu.extrude = 0.03
        b = bpy.data.objects.new('btc-b', cu)
        scene.collection.objects.link(b)
        b.data.materials.append(orange)
        b.parent = hinge
        b.location = (0.02, -LD / 2, zc - 0.03)
        # The lid's inside faces local -Z with its free edge (the picture's top) towards -Y: flipped over X it reads.
        b.rotation_euler = (math.radians(180), 0, 0)
        # The two strokes of ₿ through the top and the bottom of the B's stem.
        for dx in (-0.13, 0.0):
            for dy in (0.36, -0.36):
                box('btc-bar', (0.055, 0.16, 0.03), (dx, -LD / 2 + dy, zc - 0.02), orange, hinge)
    else:
        stripes = [mat('pink', (255, 95, 170), 0.35, emit=(255, 80, 160), strength=2.2), mat('white', (255, 245, 250), 0.35, emit=(255, 240, 250), strength=1.2)]
        for k in range(8):
            r = 0.5 - k * 0.06
            cylinder(f'swirl{k}', r, 0.03, (0, -LD / 2, zc - 0.01 - k * 0.004), stripes[k % 2], parent=hinge)
        stick = mat('stick', (250, 245, 235), 0.6)
        box('stick', (0.07, 0.6, 0.05), (0, -LD / 2 + 0.75, zc), stick, hinge)
    spark = mat('spark', theme['trim'], 0.3, emit=theme['trim'], strength=6.0)
    for x, y in ((-0.95, -0.35), (0.95, -1.15), (-0.85, -1.2), (0.9, -0.4)):
        box('spark-h', (0.16, 0.04, 0.02), (x, y, zc), spark, hinge)
        box('spark-v', (0.04, 0.16, 0.02), (x, y, zc), spark, hinge)


def contents(dims, theme, kind):
    """What can come out of the case: coins for «Затмение», sweets for «Кенди»."""
    W, D, H, _ = dims
    if kind == 'eclipse':
        gold = mat('gold', (255, 196, 60), 0.25, 1.0, emit=(255, 170, 40), strength=0.6)
        spots = [(-0.7, -0.2), (-0.35, 0.15), (0.0, -0.1), (0.4, 0.2), (0.75, -0.15), (-0.1, 0.35), (0.3, -0.35), (-0.55, 0.4), (0.6, 0.45)]
        for k, (x, y) in enumerate(spots):
            for j in range(3 + k % 3):
                cylinder('coin', 0.2, 0.06, (x + 0.02 * j, y, H - 0.05 + j * 0.065), gold, rot=(math.radians(8 * ((k + j) % 3 - 1)), math.radians(6 * (j % 2)), 0))
    elif kind == 'bitcoin':
        coin_m = mat('btc-coin', (247, 147, 26), 0.25, 1.0, emit=(255, 140, 20), strength=0.8)
        rim_m = mat('btc-rim', (255, 205, 110), 0.25, 1.0, emit=(255, 190, 80), strength=0.6)
        spots = [(-0.75, -0.15), (-0.35, 0.2), (0.05, -0.2), (0.45, 0.15), (0.8, -0.1), (-0.15, 0.4), (0.25, -0.4)]
        for k, (x, y) in enumerate(spots):
            for j in range(2 + k % 3):
                tilt = (math.radians(10 * ((k + j) % 3 - 1)), math.radians(8 * (j % 2)), 0)
                cylinder('btc-c', 0.21, 0.06, (x, y, H - 0.04 + j * 0.065), coin_m, rot=tilt)
                torus('btc-cr', 0.19, 0.018, (x, y, H - 0.005 + j * 0.065), rim_m, rot=tilt)
        # The chart: green steps rising out of the chest, an arrowhead on top.
        green = mat('chart', (40, 210, 70), 0.3, emit=(30, 220, 60), strength=3.5)
        # To the right of the lid's ₿, so the chart never covers it.
        pts = [(0.15, -0.35, H + 0.12), (0.5, -0.35, H + 0.5), (0.78, -0.35, H + 0.32), (1.12, -0.35, H + 0.88), (1.42, -0.35, H + 1.3)]
        for (x0, y0, z0), (x1, y1, z1) in zip(pts, pts[1:]):
            mid = ((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2)
            length = math.dist((x0, y0, z0), (x1, y1, z1))
            ang = math.atan2(z1 - z0, x1 - x0)
            box('chart-seg', (length + 0.05, 0.11, 0.11), mid, green, rot=(0, -ang, 0))
        bpy.ops.mesh.primitive_cone_add(vertices=4, radius1=0.24, radius2=0.0, depth=0.38, location=(1.53, -0.35, H + 1.45), rotation=(0, math.radians(38), 0))
        bpy.context.active_object.data.materials.append(green)
    else:
        wraps = [((255, 95, 170), (-0.7, -0.15)), ((90, 220, 190), (-0.2, 0.2)), ((255, 210, 80), (0.35, -0.15)), ((160, 120, 255), (0.75, 0.2)), ((255, 120, 120), (0.05, -0.35))]
        for col, (x, y) in wraps:
            m = mat('wrap', col, 0.25, emit=col, strength=0.5)
            sphere('candy', 0.2, (x, y, H + 0.05), m, scale=(1.25, 1, 0.9))
            for s in (-1, 1):
                bpy.ops.mesh.primitive_cone_add(vertices=12, radius1=0.12, radius2=0.0, depth=0.22, location=(x + s * 0.3, y, H + 0.05), rotation=(0, math.radians(90 * s), 0))
                bpy.context.active_object.data.materials.append(m)
        for (x, y), col in (((-0.45, 0.45), (255, 95, 170)), ((0.5, 0.5), (90, 220, 190))):
            stick = mat('stick2', (250, 245, 235), 0.6)
            box('pop-stick', (0.05, 0.05, 0.9), (x, y, H + 0.2), stick)
            m1 = mat('pop', col, 0.3, emit=col, strength=1.5)
            cylinder('pop', 0.28, 0.08, (x, y, H + 0.72), m1, rot=(math.radians(80), 0, math.radians(20)))
            torus('pop-ring', 0.17, 0.035, (x, y - 0.03, H + 0.72), mat('pop-w', (255, 250, 250), 0.3, emit=(255, 255, 255), strength=1.0), rot=(math.radians(80), 0, math.radians(20)))


THEMES = {
    'bitcoin': {
        'title': 'БИТКОИН',
        'body': (40, 42, 52), 'body2': (30, 32, 40), 'inner': (18, 16, 20), 'inner2': (26, 22, 24),
        'trim': (247, 147, 26), 'trim_glow': 7.0, 'metal': (120, 110, 100),
        'fill': (1.0, 0.75, 0.45), 'rim': (0.5, 1.0, 0.65), 'glow': (247, 147, 26),
        'text': (255, 190, 70), 'outline': (70, 35, 5),
    },
    'eclipse': {
        'title': 'ЗАТМЕНИЕ',
        'body': (34, 22, 58), 'body2': (26, 16, 44), 'inner': (16, 10, 30), 'inner2': (22, 14, 40),
        'trim': (176, 92, 255), 'trim_glow': 7.0, 'metal': (70, 60, 90),
        'fill': (0.7, 0.55, 1.0), 'rim': (1.0, 0.7, 0.3), 'glow': (190, 120, 255),
        'text': (255, 205, 90), 'outline': (60, 20, 90),
    },
    'candy': {
        'title': 'КЕНДИ',
        'body': (250, 120, 185), 'body2': (255, 236, 246), 'inner': (90, 40, 80), 'inner2': (110, 50, 95),
        'trim': (90, 235, 200), 'trim_glow': 6.0, 'metal': (255, 255, 255),
        'fill': (1.0, 0.75, 0.9), 'rim': (0.5, 1.0, 0.9), 'glow': (255, 120, 200),
        'text': (255, 250, 255), 'outline': (200, 40, 130),
    },
}

for case_id, theme in THEMES.items():
    if ONLY and case_id not in ONLY:
        continue
    clear()
    root, hinge, dims = chest(theme)
    lid_art(hinge, dims, theme, case_id)
    contents(dims, theme, case_id)
    W, D, H, _ = dims
    text_m = mat('text', theme['text'], 0.3, emit=theme['text'], strength=4.0)
    out_m = mat('outline', theme['outline'], 0.5)
    size = 0.56 if len(theme['title']) > 6 else 0.78
    text(theme['title'], size, (0, -D / 2 - 0.09, H * 0.5), text_m, out_m)
    scene_setup(theme)
    scene.render.filepath = os.path.join(OUT, f'{case_id}.png')
    bpy.ops.render.render(write_still=True)
    print('rendered', case_id)
