import { useId } from 'react';
import { cx } from '../lib/format';

interface TabsProps<T extends string> {
  value: T;
  onChange: (value: T) => void;
  options: { value: T; label: string }[];
  label: string;
}

export function Tabs<T extends string>({ value, onChange, options, label }: TabsProps<T>) {
  const id = useId();
  return (
    <div className="tabs" role="tablist" aria-label={label}>
      {options.map((o) => (
        <button
          key={o.value}
          id={`${id}-${o.value}`}
          type="button"
          role="tab"
          aria-selected={value === o.value}
          className={cx('tabs__tab', value === o.value && 'is-active')}
          onClick={() => onChange(o.value)}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}
