"""Share cards for «Поделиться выигрышем» (server/growth.ts#shareWin): Telegram's prepared photo messages take JPEG only,
so every catalog brainrot (public/brainrots/*.webp) gets an 800×800 card in public/share/brainrots/<id>.jpg — the brand
night, a gold glow and the brainrot in the middle, the BrainrotCrash mark in the corner.

    python3 scripts/gen_share_cards.py
"""
import os

from PIL import Image, ImageDraw, ImageFilter

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
SRC = os.path.join(ROOT, 'public', 'brainrots')
OUT = os.path.join(ROOT, 'public', 'share', 'brainrots')
LOGO = os.path.join(ROOT, 'public', 'logo-bc.webp')
SIZE = 800


def background() -> Image.Image:
    bg = Image.new('RGB', (SIZE, SIZE), (7, 11, 21))
    glow = Image.new('L', (SIZE, SIZE), 0)
    d = ImageDraw.Draw(glow)
    d.ellipse((140, 120, 660, 640), fill=255)
    glow = glow.filter(ImageFilter.GaussianBlur(120))
    gold = Image.new('RGB', (SIZE, SIZE), (120, 84, 18))
    bg.paste(gold, (0, 0), glow.point(lambda v: int(v * 0.55)))
    floor = Image.new('L', (SIZE, SIZE), 0)
    ImageDraw.Draw(floor).ellipse((220, 640, 580, 700), fill=180)
    floor = floor.filter(ImageFilter.GaussianBlur(24))
    bg.paste((0, 0, 0), (0, 0), floor)
    return bg


def main():
    os.makedirs(OUT, exist_ok=True)
    base = background()
    logo = Image.open(LOGO).convert('RGBA')
    logo.thumbnail((150, 150))
    made = 0
    for name in sorted(os.listdir(SRC)):
        if not name.endswith('.webp') or name == 'no-image.webp':
            continue
        art = Image.open(os.path.join(SRC, name)).convert('RGBA')
        art.thumbnail((560, 560))
        card = base.copy()
        card.paste(art, ((SIZE - art.width) // 2, 70 + (560 - art.height) // 2), art)
        card.paste(logo, (SIZE - logo.width - 28, SIZE - logo.height - 22), logo)
        card.save(os.path.join(OUT, name[:-5] + '.jpg'), 'JPEG', quality=82, optimize=True, progressive=True)
        made += 1
    print('cards', made)


if __name__ == '__main__':
    main()
