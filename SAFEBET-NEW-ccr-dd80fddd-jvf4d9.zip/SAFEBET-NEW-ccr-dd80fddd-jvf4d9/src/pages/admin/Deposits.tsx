import { useState, type FormEvent } from 'react';
import { BrainrotThumb } from '../../components/BrainrotCard';
import { Coin } from '../../components/Coin';
import { Icon, type IconName } from '../../components/Icon';
import { useCatalog } from '../../api/queries';
import { cx, formatCoins, formatCountdown } from '../../lib/format';
import { useNow } from '../../lib/useNow';
import { toast } from '../../store/toast';
import type * as DepositsApi from '../../../server/itemDeposits';
import type * as DepositListApi from '../../../server/depositList';
import { DEPOSIT_SECTIONS, DEPOSIT_SECTION_LABEL, MAX_DEPOSIT_ITEMS, type DepositSection } from '../../../shared/deposit';
import { Switch } from '../../components/Toggle';
import { BrainrotPicker, Card, ConfirmButton, Empty, Segmented, adminApi, formatWhen, useAdminAction, useAdminQuery, type AdminApi, type Data } from './ui';

type DepositRow = Data<typeof DepositsApi.adminItemDeposits>[number];
type ListRow = Data<typeof DepositListApi.adminDepositItems>[number];
type SettingsData = Data<typeof AdminApi.readSettings>;
type Tab = 'queue' | 'list' | 'bots' | 'history';

const DEP_LABEL: Record<string, string> = {
  searching: '⏳ ждёт бота',
  trading: '🤝 трейд',
  expired: '⌛ время вышло',
  credited: '✅ зачислено',
  rejected: '❌ отклонено',
  cancelled: 'отменена игроком',
};

const TABS: { id: Tab; label: string; icon: IconName }[] = [
  { id: 'queue', label: 'Очередь', icon: 'clock' },
  { id: 'list', label: 'Список', icon: 'box' },
  { id: 'bots', label: 'Боты', icon: 'settings' },
  { id: 'history', label: 'История', icon: 'quests' },
];

/** «Пополнения»: the request queue, the list of accepted brainrots, trade bot nicks and history — tabs at the bottom. */
export function ItemDeposits() {
  const [tab, setTab] = useState<Tab>('queue');
  const open = useAdminQuery<DepositRow[]>(['item-deposits', 'open'], '/item-deposits?status=open');
  const waiting = (open.data ?? []).filter((d) => d.status !== 'expired').length;
  return (
    <div className="adeps">
      <div className="adeps__body" key={tab}>
        {tab === 'queue' && (
          <>
            <DepositIntake />
            <Queue rows={open.data} pending={open.isPending} />
          </>
        )}
        {tab === 'list' && <DepositList />}
        {tab === 'bots' && <Bots />}
        {tab === 'history' && <History />}
      </div>
      <nav className="adep-tabs" aria-label="Разделы пополнений">
        {TABS.map((t) => (
          <button key={t.id} type="button" className={cx('adep-tabs__btn', tab === t.id && 'is-on')} aria-current={tab === t.id ? 'page' : undefined} onClick={() => setTab(t.id)}>
            <span className="adep-tabs__icon">
              <Icon name={t.icon} size={20} />
              {t.id === 'queue' && waiting > 0 && <span className="adep-tabs__badge">{waiting}</span>}
            </span>
            {t.label}
          </button>
        ))}
      </nav>
    </div>
  );
}

// ---------- Intake ----------

/** «Приём пополнений»: open or close the «Брейнроты» and «Гирсы» tabs for new requests; open ones carry on. */
function DepositIntake() {
  const settings = useAdminQuery<SettingsData>(['settings'], '/settings');
  const save = useAdminAction((depositOpen: Partial<Record<DepositSection, boolean>>) => adminApi<SettingsData>('/settings', 'POST', { depositOpen }), {
    success: 'Сохранено — игроки видят сразу',
  });
  const open = settings.data?.depositOpen;
  return (
    <Card title="Приём пополнений">
      <p className="acard__text">Закрытая вкладка не принимает новые заявки — игрок видит «Пополнение закрыто». Уже открытые заявки доводятся до конца.</p>
      {DEPOSIT_SECTIONS.map((section) => (
        <div className="arow" key={section}>
          <div>
            <p className="arow__title">{DEPOSIT_SECTION_LABEL[section]}</p>
            <p className="acard__text">{open ? (open[section] ? '✅ Открыто' : '⛔ Закрыто') : '…'}</p>
          </div>
          <Switch on={!!open?.[section]} onChange={(on) => save.mutate({ [section]: on })} label={`Приём: ${DEPOSIT_SECTION_LABEL[section]}`} disabled={!open || save.isPending} />
        </div>
      ))}
    </Card>
  );
}

// ---------- Queue ----------

function Queue({ rows, pending }: { rows: DepositRow[] | undefined; pending: boolean }) {
  const settings = useAdminQuery<SettingsData>(['settings'], '/settings');
  const bots = settings.data?.tradeBots ?? [];
  return (
    <Card title={`Очередь${rows?.length ? ` · ${rows.length}` : ''}`}>
      <p className="acard__text">Новые заявки приходят и в бот — там те же кнопки. Что нажмёшь здесь или в боте, игрок сразу увидит в приложении.</p>
      {pending && <Empty>Загружаем…</Empty>}
      {rows?.length === 0 && <Empty>Очередь пуста — новых заявок нет</Empty>}
      <ul className="aqueue">
        {(rows ?? []).map((d) => (
          <QueueCard key={d.id} d={d} bots={bots} />
        ))}
      </ul>
    </Card>
  );
}

function QueueCard({ d, bots }: { d: DepositRow; bots: string[] }) {
  const catalog = useCatalog();
  const now = useNow(1000);
  const act = useAdminAction(({ action, nick }: { action: 'bot' | 'credit' | 'reject'; nick?: string }) => adminApi(`/item-deposits/${d.id}`, 'POST', { action, nick }), {
    success: 'Готово — игрок увидит это в приложении',
  });
  const left = d.status === 'trading' && d.deadline ? Math.max(0, d.deadline - now) : null;
  return (
    <li className={cx('aqueue__card', `is-${d.status}`)}>
      <header className="aqueue__head">
        <strong>#{d.id}</strong>
        <span className="pill">{DEP_LABEL[d.status]}</span>
        <time>{formatWhen(d.createdAt)}</time>
      </header>
      <p className="aqueue__who">
        {d.user} · Roblox <code>{d.robloxNick}</code>
      </p>
      <ul className="aqueue__items">
        {d.items.map((i) => {
          const b = catalog.byId.get(i.brainrotId);
          return (
            <li key={i.brainrotId} title={i.name}>
              {b ? <BrainrotThumb brainrot={b} size={40} /> : <span className="aqueue__noimg">{i.name.slice(0, 2)}</span>}
              {i.count > 1 && <b>×{i.count}</b>}
            </li>
          );
        })}
      </ul>
      <p className="aqueue__sum">
        <Coin size={16} /> {formatCoins(d.total)}
        {d.bonusPercent ? <small> с бонусом {d.bonusPercent}%</small> : null}
      </p>
      {left !== null && (
        <p className={cx('aqueue__timer', left < 60_000 && 'is-hot')}>
          Трейд на <code>{d.botNick}</code> · {formatCountdown(left)}
        </p>
      )}
      <div className="aqueue__bots" role="group" aria-label="Куда отправлять трейд">
        <span>Бот для трейда:</span>
        {bots.map((b) => (
          <button key={b} type="button" className={cx('chip aqueue__bot', d.botNick === b && d.status === 'trading' && 'is-active')} disabled={act.isPending} onClick={() => act.mutate({ action: 'bot', nick: b })}>
            🤖 {b}
          </button>
        ))}
        {!bots.length && <small>добавь ник во вкладке «Боты»</small>}
      </div>
      <div className="aqueue__actions">
        <ConfirmButton className="btn btn--ghost" disabled={act.isPending} onConfirm={() => act.mutate({ action: 'reject' })} confirmText="Точно отклонить?">
          Отклонить
        </ConfirmButton>
        <ConfirmButton className="btn btn--green" disabled={act.isPending} onConfirm={() => act.mutate({ action: 'credit' })} confirmText={`Зачислить ${formatCoins(d.total)} B?`}>
          Зачислить
        </ConfirmButton>
      </div>
    </li>
  );
}

// ---------- Accepted brainrots ----------

function DepositList() {
  const list = useAdminQuery<ListRow[]>(['deposit-items'], '/deposit-items');
  const [q, setQ] = useState('');
  const [section, setSection] = useState<DepositSection>('brainrots');
  const add = useAdminAction((brainrotId: string) => adminApi('/deposit-items', 'POST', { brainrotId, section }), {
    success: `Добавлен в «${DEPOSIT_SECTION_LABEL[section]}»`,
  });
  const inSection = (list.data ?? []).filter((r) => r.section === section);
  const rows = inSection.filter((r) => !q || r.name.toLowerCase().includes(q.toLowerCase()));
  const listed = new Set((list.data ?? []).map((r) => r.brainrotId));
  const count = (s: DepositSection) => (list.data ?? []).filter((r) => r.section === s).length;
  return (
    <Card title={`Список пополнения · ${list.data?.length ?? 0}`}>
      <p className="acard__text">
        Только эти брейнроты можно внести через «Пополнение → Брейнроты». У игрока две вкладки — «Брейнроты» и «Гирсы»; переноси позиции кнопкой у строки. Цена —
        сколько монет получит игрок за одного; пустое поле — цена из каталога. За одно пополнение — до {MAX_DEPOSIT_ITEMS} штук.
      </p>
      <Segmented
        label="Вкладка пополнения"
        value={section}
        onChange={setSection}
        options={(['brainrots', 'gears'] as const).map((s) => ({ value: s, label: `${DEPOSIT_SECTION_LABEL[s]} · ${count(s)}` }))}
      />
      <BrainrotPicker label={`Добавить в «${DEPOSIT_SECTION_LABEL[section]}»`} value={null} exclude={listed} onChange={(id) => add.mutate(id)} />
      <p className="acard__text">Нужного нет в каталоге? Создай его в «Каталог» — можно скрытым, тогда он не попадёт в кейсы.</p>
      <span className="ainput ainput--icon">
        <Icon name="sparkle" size={16} />
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Поиск в списке" aria-label="Поиск в списке" />
      </span>
      {list.isPending && <Empty>Загружаем…</Empty>}
      {list.data?.length === 0 && <Empty>Список пуст — пополнение брейнротами закрыто для игроков</Empty>}
      {!!list.data?.length && !inSection.length && <Empty>Во вкладке «{DEPOSIT_SECTION_LABEL[section]}» пока пусто — добавь сюда или перенеси из другой вкладки.</Empty>}
      <ul className="adlist">
        {rows.map((r) => (
          <DepositListRow key={r.brainrotId} row={r} />
        ))}
      </ul>
    </Card>
  );
}

function DepositListRow({ row }: { row: ListRow }) {
  const catalog = useCatalog();
  const b = catalog.byId.get(row.brainrotId);
  const [price, setPrice] = useState(row.price === null ? '' : String(row.price));
  const save = useAdminAction((value: string) => adminApi(`/deposit-items/${row.brainrotId}`, 'PATCH', { price: value === '' ? null : value.replace(',', '.') }), {
    success: 'Цена пополнения сохранена',
  });
  const remove = useAdminAction(() => adminApi(`/deposit-items/${row.brainrotId}`, 'DELETE'), { success: `${row.name} убран из пополнения` });
  const other: DepositSection = row.section === 'gears' ? 'brainrots' : 'gears';
  const move = useAdminAction(() => adminApi(`/deposit-items/${row.brainrotId}`, 'PATCH', { section: other }), {
    success: `${row.name} → «${DEPOSIT_SECTION_LABEL[other]}»`,
  });
  const dirty = price !== (row.price === null ? '' : String(row.price));

  function submit(e?: FormEvent) {
    e?.preventDefault();
    if (!dirty || save.isPending) return;
    if (price !== '' && !(Number(price.replace(',', '.')) > 0)) return toast('Цена — число больше нуля', 'error');
    save.mutate(price);
  }

  return (
    <li className="adlist__row">
      {b && <BrainrotThumb brainrot={b} size={40} />}
      <span className="adlist__name">
        {row.name}
        <small>в каталоге {formatCoins(row.catalogPrice)} B</small>
        <button type="button" className="adlist__move" disabled={move.isPending} onClick={() => move.mutate(undefined)}>
          В «{DEPOSIT_SECTION_LABEL[other]}» →
        </button>
      </span>
      <form className="adlist__price" onSubmit={submit}>
        <span className={cx('ainput ainput--short', row.price !== null && 'is-custom')}>
          <Coin size={14} />
          <input
            inputMode="decimal"
            value={price}
            placeholder={String(row.catalogPrice)}
            aria-label={`Цена пополнения ${row.name}`}
            onChange={(e) => setPrice(e.target.value.replace(/[^\d.,]/g, '').slice(0, 12))}
            onBlur={() => submit()}
          />
        </span>
      </form>
      <ConfirmButton className="icon-btn icon-btn--ghost" disabled={remove.isPending} onConfirm={() => remove.mutate(undefined)} confirmText="✕?">
        <Icon name="close" size={16} />
      </ConfirmButton>
    </li>
  );
}

// ---------- Trade bots ----------

function Bots() {
  const settings = useAdminQuery<SettingsData>(['settings'], '/settings');
  const [nick, setNick] = useState('');
  // One nick at a time against the server's list: a nick added from the bot meanwhile stays.
  const saveBots = useAdminAction((op: { tradeBotAdd?: string; tradeBotRemove?: string }) => adminApi<SettingsData>('/settings', 'POST', op), { success: 'Список ботов сохранён' });
  const bots = settings.data?.tradeBots ?? [];
  return (
    <Card title="Ники ботов для трейдов">
      <p className="acard__text">На эти Roblox-аккаунты игроки отправляют трейды. Новый ник можно добавить и прямо из бота — кнопкой «➕ Новый ник бота».</p>
      <ul className="abots">
        {bots.map((b) => (
          <li key={b}>
            <code>{b}</code>
            <button type="button" className="icon-btn icon-btn--ghost" aria-label={`Удалить ${b}`} onClick={() => saveBots.mutate({ tradeBotRemove: b })}>
              <Icon name="close" size={16} />
            </button>
          </li>
        ))}
        {!bots.length && <Empty>Пока ни одного</Empty>}
      </ul>
      <form
        className="aform aform--row"
        onSubmit={(e) => {
          e.preventDefault();
          if (!/^[A-Za-z0-9_]{3,20}$/.test(nick)) return toast('Ник: латиница, цифры и _ (3–20)', 'error');
          saveBots.mutate({ tradeBotAdd: nick }, { onSuccess: () => setNick('') });
        }}
      >
        <span className="ainput">
          <input value={nick} maxLength={20} placeholder="RobloxBotNick" onChange={(e) => setNick(e.target.value.trim())} aria-label="Новый ник бота" />
        </span>
        <button type="submit" className="btn btn--primary btn--sm" disabled={!nick || saveBots.isPending}>
          Добавить
        </button>
      </form>
    </Card>
  );
}

// ---------- History ----------

function History() {
  const list = useAdminQuery<DepositRow[]>(['item-deposits', 'closed'], '/item-deposits?status=closed');
  return (
    <Card title="История заявок">
      {list.isPending && <Empty>Загружаем…</Empty>}
      {list.data?.length === 0 && <Empty>Пока пусто</Empty>}
      <ul className="alist">
        {(list.data ?? []).map((d) => (
          <li key={d.id} className="alist__row adep">
            <p className="adep__head">
              <strong>#{d.id}</strong> {d.user}
              <span className="pill">{DEP_LABEL[d.status]}</span>
            </p>
            <p className="alist__meta">
              {d.items.map((i) => (i.count > 1 ? `${i.name} ×${i.count}` : i.name)).join(', ')} — <b>{formatCoins(d.credited ?? d.total)} B</b> · Roblox <code>{d.robloxNick}</code> · {formatWhen(d.createdAt)}
            </p>
          </li>
        ))}
      </ul>
    </Card>
  );
}
