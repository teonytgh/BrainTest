import { useQuery } from '@tanstack/react-query';
import { useState, type ReactNode } from 'react';
import { CaseArt } from '../components/CaseArt';
import { Coin } from '../components/Coin';
import { ConsolationSheet } from '../components/ConsolationSheet';
import { Icon } from '../components/Icon';
import { PromoForm } from '../components/PromoForm';
import { RankBadge } from '../components/RankBadge';
import { api, errorMessage } from '../api/client';
import { act, queryClient, setMe, useCatalog, useMe } from '../api/queries';
import type { bonusSummary } from '../../server/bonuses';
import { NICK_TAG, REF_LEVELS } from '../../shared/bonuses';
import { RANKS } from '../../shared/ranks';
import { FREE_CASE_COOLDOWN_MS, type CaseDef } from '../../shared/types';
import { cx, formatCoins, formatCountdown } from '../lib/format';
import { routeHref } from '../lib/router';
import { sfx } from '../lib/sound';
import { haptic } from '../lib/telegram';
import { useNow } from '../lib/useNow';
import { toast } from '../store/toast';

type Summary = Awaited<ReturnType<typeof bonusSummary>>;

const TOP_REVSHARE = REF_LEVELS[REF_LEVELS.length - 1]!.percent;

/** «Бонусы»: a bonus code, three free cases with their own rules, weekly cashback and the referral programme. */
export function Bonuses() {
  const me = useMe();
  const catalog = useCatalog();
  const now = useNow(1000);
  const summary = useQuery({ queryKey: ['bonuses'], queryFn: () => api<Summary>('/api/bonuses'), staleTime: 10_000 });
  const [consolation, setConsolation] = useState<number | null>(null);
  const s = summary.data;
  const art = (id: string) => catalog.byId.get(id)?.image;
  const kase = (id: string) => catalog.caseById.get(id);

  const freeAt = me.user.freeCaseAt ? me.user.freeCaseAt + FREE_CASE_COOLDOWN_MS : 0;
  const nickAt = s?.nick.readyAt ?? 0;
  const referralKeys = me.caseKeys.referral ?? 0;
  const pendingConsolations = s?.consolations ?? me.consolations.map((id) => ({ id, stake: 0 }));

  return (
    <section className="bonuses" aria-labelledby="bonuses-title">
      <header className="bonuses__head">
        <h1 id="bonuses-title" className="page-title">
          Бонусы
        </h1>
        <p className="bonuses__lead">Бесплатные кейсы, кэшбэк и награды за друзей — всё в одном месте.</p>
      </header>

      {pendingConsolations.length > 0 && (
        <button type="button" className="bonus-alert" onClick={() => setConsolation(pendingConsolations[0]!.id)}>
          <span className="bonus-alert__icon" aria-hidden="true">
            <Icon name="gift" size={22} />
          </span>
          <span className="bonus-alert__text">
            <b>Утешительный кейс{pendingConsolations.length > 1 ? ` ×${pendingConsolations.length}` : ''}</b>
            <small>За крупный проигрыш в апгрейдере · монеты 1–30 B</small>
          </span>
          <Icon name="chevronRight" size={20} />
        </button>
      )}

      <nav className="bn-links" aria-label="Ранги и задания">
        <a className="bn-link" href={routeHref('ranks')}>
          <RankBadge rank={RANKS[me.user.rank] ?? RANKS[0]!} size={40} />
          <span>
            <b>Ранг: {(RANKS[me.user.rank] ?? RANKS[0]!).name}</b>
            <small>кэшбэк {(RANKS[me.user.rank] ?? RANKS[0]!).cashback}% · подарки</small>
          </span>
        </a>
        <a className="bn-link" href={routeHref('quests')}>
          <span className="bn-link__icon" aria-hidden="true">
            <Icon name="quests" size={22} />
          </span>
          <span>
            <b>Задания</b>
            <small>тикеты на бесплатные кейсы</small>
          </span>
        </a>
      </nav>

      <article className="bnc bnc--code">
        <div className="bnc__copy">
          <p className="bnc__kicker">Бонус-код</p>
          <h2 className="bnc__title">Есть код? Вводи</h2>
          <p className="bnc__text">Коды из канала, от партнёров и друзей. Код друга сделает тебя его рефералом — и даст реферальный кейс, если он у тебя ещё не был.</p>
        </div>
        {art('los-hackers') && <img className="bnc__art bnc__art--code" src={art('los-hackers')} alt="" />}
        <PromoForm inline cta="Применить" placeholder="Бонус-код" onDone={() => void queryClient.invalidateQueries({ queryKey: ['bonuses'] })} />
      </article>

      <div className="bcases">
        <BonusCase
          kase={kase('free')}
          title="Бесплатный"
          tone="green"
          status={freeAt > now ? `через ${formatCountdown(freeAt - now)}` : 'готов к открытию'}
          ready={freeAt <= now}
          rule="Подписка на канал + «Поделиться с другом»"
          action={freeAt > now ? 'Ждёт таймера' : 'Открыть'}
        />
        <BonusCase
          kase={kase('nick')}
          title="За ник"
          tone="purple"
          status={nickAt > now ? `через ${formatCountdown(nickAt - now)}` : s?.nick.tagged ? 'тег на месте' : 'нужен тег в имени'}
          ready={nickAt <= now}
          rule={
            <>
              Допиши <NickTag tag={s?.nick.tag ?? NICK_TAG} /> в конец имени в Telegram — открывай каждые 12 часов
            </>
          }
          action={nickAt > now ? 'Ждёт таймера' : 'Открыть'}
        />
        <BonusCase
          kase={kase('referral')}
          title="Реферальный"
          tone="orange"
          wide
          status={referralKeys > 0 ? `открытий: ${referralKeys}` : s?.referralHad ? 'уже получен' : 'приведи друга'}
          ready={referralKeys > 0}
          rule="Один раз на аккаунт: за вход по ссылке друга или за первого друга по твоей ссылке"
          action={referralKeys > 0 ? `Открыть ×${referralKeys}` : 'Пригласить друга'}
          href={referralKeys > 0 ? undefined : routeHref('referrals')}
        />
      </div>

      <Cashback data={s?.cashback} art={art('arco-dragon')} />

      <a className="binvite" href={routeHref('referrals')}>
        <span className="binvite__copy">
          <span className="bnc__kicker">Рефералы</span>
          <b>Приглашай друзей</b>
          <small>До {TOP_REVSHARE}% с каждого их пополнения и кейс вам обоим</small>
        </span>
        {art('los-amigos') && <img className="binvite__art" src={art('los-amigos')} alt="" />}
        <Icon name="chevronRight" size={22} className="binvite__go" />
      </a>

      <ConsolationSheet
        id={consolation}
        onClose={() => {
          setConsolation(null);
          void queryClient.invalidateQueries({ queryKey: ['bonuses'] });
        }}
      />
    </section>
  );
}

function NickTag({ tag }: { tag: string }) {
  return (
    <button
      type="button"
      className="nick-tag"
      onClick={(e) => {
        e.preventDefault();
        e.stopPropagation();
        void navigator.clipboard?.writeText(` ${tag}`).then(
          () => toast(`«${tag}» скопирован — вставь в конец имени`, 'success'),
          () => toast(tag),
        );
      }}
    >
      {tag} <Icon name="copy" size={12} />
    </button>
  );
}

function BonusCase({
  kase,
  title,
  tone,
  status,
  ready,
  rule,
  action,
  href,
  wide,
}: {
  kase: CaseDef | undefined;
  title: string;
  tone: 'green' | 'purple' | 'orange';
  status: string;
  ready: boolean;
  rule: ReactNode;
  action: string;
  href?: string;
  wide?: boolean;
}) {
  if (!kase) return null;
  return (
    <article className={cx('bcase', `bcase--${tone}`, wide && 'bcase--wide', ready && 'is-ready')} data-tour={kase.kind === 'free' ? 'free-case' : undefined}>
      <span className="bcase__art" aria-hidden="true">
        <CaseArt kase={kase} lazy />
      </span>
      <div className="bcase__body">
        <h2 className="bcase__title">{title}</h2>
        <p className={cx('bcase__status', ready && 'is-ready')}>{status}</p>
        <p className="bcase__rule">{rule}</p>
        <a className="bcase__cta" href={href ?? routeHref('case', kase.id)}>
          {action} <Icon name="chevronRight" size={16} />
        </a>
      </div>
    </article>
  );
}

function Cashback({ data, art }: { data: Summary['cashback'] | undefined; art: string | undefined }) {
  const now = useNow(60_000);
  const [busy, setBusy] = useState(false);
  const available = data?.available ?? 0;

  async function claim() {
    setBusy(true);
    try {
      const r = await act<{ amount: number }>('/api/bonuses/cashback');
      setMe(r.me);
      sfx.win();
      haptic('success');
      toast(`Кэшбэк +${formatCoins(r.result.amount)} B на баланс`, 'success');
      await queryClient.invalidateQueries({ queryKey: ['bonuses'] });
    } catch (e) {
      sfx.error();
      toast(errorMessage(e), 'error');
    } finally {
      setBusy(false);
    }
  }

  const percent = data?.percent ?? 3;
  const today = !!data?.today;
  // This week's cashback is collected on the first Friday after it ends.
  const thisWeekDay = data ? data.weekEndsAt + 4 * 86_400_000 : 0;
  const date = (at: number) => new Date(at).toLocaleDateString('ru-RU', { day: 'numeric', month: 'long', timeZone: 'Europe/Moscow' });
  return (
    <article className="bnc bnc--cash">
      {art && <img className="bnc__art bnc__art--cash" src={art} alt="" />}
      <div className="bnc__copy">
        <p className="bnc__kicker">Кэшбэк {percent}%</p>
        <h2 className="bnc__title">Возвращаем часть проигрыша</h2>
        <p className="bnc__text">
          {percent}% от того, что ушло в минус на платных кейсах и батлах за неделю (пн–вс, МСК). Забрать можно <b>только по пятницам</b> — сразу за все прошлые недели.
        </p>
      </div>
      <div className="bcash">
        <div className="bcash__now">
          <span>{today ? 'Можно забрать сегодня' : 'Ждёт пятницы'}</span>
          <strong>
            {formatCoins(available)} <Coin size={20} />
          </strong>
        </div>
        <button type="button" className="btn btn--green" onClick={() => void claim()} disabled={busy || !today || available <= 0}>
          {today ? 'Забрать' : data ? `В пятницу, ${date(data.nextDayAt)}` : 'В пятницу'}
        </button>
      </div>
      <p className="bcash__next">
        Копится за эту неделю: <b>{formatCoins(data?.accruing ?? 0)} B</b>
        {data && now < thisWeekDay ? ` · заберёшь ${date(thisWeekDay)}` : ''}
      </p>
    </article>
  );
}
