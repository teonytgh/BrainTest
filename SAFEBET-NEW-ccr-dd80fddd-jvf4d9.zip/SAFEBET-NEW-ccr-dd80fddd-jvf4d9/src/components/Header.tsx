import { Avatar } from './Avatar';
import { Coin } from './Coin';
import { Icon } from './Icon';
import { Logo } from './Logo';
import { useMe } from '../api/queries';
import { formatCoins, formatCompactCoins } from '../lib/format';
import { routeHref } from '../lib/router';
import { openMenu, openSheet } from '../store/ui';

export function Header() {
  const { user, maintenance } = useMe();
  return (
    <header className="topbar">
      <div className="topbar__inner">
        {/* Phones have «Ещё» in the bottom bar; only the PC layout on a narrow window shows this. */}
        <button type="button" className="icon-btn topbar__menu" aria-label="Открыть меню" onClick={openMenu}>
          <Icon name="menu" />
        </button>
        <a href="#/" className="topbar__logo" aria-label="BrainrotCrash — на главную">
          <Logo />
        </a>
        <button
          type="button"
          className="balance-chip"
          data-tour="balance"
          aria-label={`Баланс ${formatCoins(user.balance)} монет. Пополнить`}
          onClick={() => openSheet('deposit')}
        >
          <Coin size={18} />
          <span key={user.balance} className="balance-chip__value">
            {formatCompactCoins(user.balance)}
          </span>
          <span className="balance-chip__plus">
            <Icon name="plus" size={14} />
          </span>
        </button>
        <a href={routeHref('profile')} className="topbar__me" aria-label="Профиль и инвентарь">
          <Avatar user={user} size={36} />
        </a>
      </div>
      {maintenance.enabled && (
        <a className="topbar__notice" href="#/admin/maintenance">
          Тех. работы включены — игроки видят заглушку
        </a>
      )}
      {user.frozen && (
        <div className="topbar__notice topbar__notice--frozen" role="status">
          Аккаунт заморожен — можно только смотреть
        </div>
      )}
    </header>
  );
}
