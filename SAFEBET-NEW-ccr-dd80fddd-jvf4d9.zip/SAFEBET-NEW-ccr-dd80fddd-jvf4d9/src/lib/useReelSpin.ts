import { useEffect, useRef, type RefObject } from 'react';
import { sfx } from './sound';
import { haptic } from './telegram';

interface Options {
  viewport: RefObject<HTMLElement | null>;
  track: RefObject<HTMLElement | null>;
  /** Gets `--tease`: the tier colour of the card under the marker, so the light shifts as the reel slows. */
  stage?: RefObject<HTMLElement | null>;
  marker?: RefObject<HTMLElement | null>;
  winIndex: number;
  /** Card width plus the gap. */
  step: number;
  durationMs: number;
  running: boolean;
  /** Land at once (skip): no flight, no sounds. */
  instant?: boolean;
  /** Only one of several simultaneous reels should click. */
  ticks?: boolean;
  onLanded: () => void;
}

const easeOutQuart = (k: number) => 1 - (1 - k) ** 4;
const easeOutCubic = (k: number) => 1 - (1 - k) ** 3;
const easeInOutCubic = (k: number) => (k < 0.5 ? 4 * k ** 3 : 1 - (-2 * k + 2) ** 3 / 2);

/** A short pull back, the long flight with a slow, tense finish, a little overshoot and the settle. */
function reelX(t: number, end: number, overshoot: number, wind: number) {
  const pre = 0.045;
  const settle = 0.1;
  if (t < pre) return wind * easeOutCubic(t / pre);
  if (t < 1 - settle) return wind + (end - overshoot - wind) * easeOutQuart((t - pre) / (1 - pre - settle));
  return end - overshoot + overshoot * easeInOutCubic((t - (1 - settle)) / settle);
}

const reducedMotion = () => typeof matchMedia === 'function' && matchMedia('(prefers-reduced-motion: reduce)').matches;

/** The light and the lifted card follow the marker only once the reel slows down: at full speed they would repaint
 * the reel's glow and a card's shadow a dozen times a second for nothing anyone can see. */
const TEASE_BELOW = 0.45;

/**
 * Drives a case reel frame by frame (not a CSS transition, so it knows its speed): lands card `winIndex`
 * somewhere under the marker, clicks once per card with a pitch that follows the speed, lights up the
 * card under the marker and gives a haptic tick per card near the end. Only `transform` moves per frame (no
 * blur or other filters), so it stays smooth on weak phones.
 */
export function useReelSpin({ viewport, track, stage, marker, winIndex, step, durationMs, running, instant, ticks = true, onLanded }: Options) {
  const landed = useRef(onLanded);
  landed.current = onLanded;
  const jitter = useRef((Math.random() - 0.5) * (step - 40));

  useEffect(() => {
    const el = track.current;
    const view = viewport.current;
    if (!running || !el || !view) return;
    const width = view.clientWidth;
    const end = -(winIndex * step + step / 2 - width / 2 + jitter.current);
    const cards = Array.from(el.children) as HTMLElement[];
    const calm = reducedMotion();
    const overshoot = calm || instant ? 0 : step * (0.16 + Math.random() * 0.12);
    const wind = calm || instant ? 0 : step * 0.22;
    let center = -1;
    let frame = 0;
    let finished = false;

    const place = (x: number, speed: number, sound: boolean) => {
      el.style.transform = `translate3d(${x}px, 0, 0)`;
      const index = Math.floor((-x + width / 2) / step);
      if (index !== center && cards[index]) {
        cards[center]?.classList.remove('is-center');
        const slow = !sound || speed < TEASE_BELOW;
        if (slow) cards[index].classList.add('is-center');
        const tier = cards[index].dataset.tier;
        if (tier && slow) stage?.current?.style.setProperty('--tease', `var(--tier-${tier})`);
        if (sound && center !== -1) {
          if (ticks) sfx.reelTick(speed);
          marker?.current?.animate([{ transform: 'translateX(-50%) scaleY(1.12)' }, { transform: 'translateX(-50%) scaleY(1)' }], { duration: 140 });
          if (ticks && speed < 0.18) haptic('select');
        }
        center = index;
      }
    };

    const finish = () => {
      if (finished) return;
      finished = true;
      cancelAnimationFrame(frame);
      place(end, 0, false);
      landed.current();
    };

    if (instant || durationMs <= 0) {
      frame = requestAnimationFrame(finish);
      return () => cancelAnimationFrame(frame);
    }

    // Top speed is at the start of the flight: normalise against it.
    const flight = durationMs * (1 - 0.045 - 0.1);
    const topSpeed = (4 * Math.abs(end - overshoot - wind)) / flight;
    const started = performance.now();
    let lastX = 0;
    let lastT = started;
    const loop = (now: number) => {
      const t = Math.min(1, (now - started) / durationMs);
      const x = reelX(t, end, overshoot, wind);
      const speed = Math.abs(x - lastX) / Math.max(1, now - lastT) / topSpeed;
      lastX = x;
      lastT = now;
      place(x, speed, true);
      if (t >= 1) finish();
      else frame = requestAnimationFrame(loop);
    };
    frame = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(frame);
  }, [running, instant, viewport, track, stage, marker, winIndex, step, durationMs, ticks]);
}
