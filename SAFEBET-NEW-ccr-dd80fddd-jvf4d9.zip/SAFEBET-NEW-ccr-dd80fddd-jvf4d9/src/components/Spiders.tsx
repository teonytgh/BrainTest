import { useEffect, useRef, useState, type CSSProperties } from 'react';
import { halloweenSeason, halloweenSkin } from './HalloweenArt';
import { sfx } from '../lib/sound';
import { haptic } from '../lib/telegram';

/**
 * Little spiders living on the screen while the Halloween skin (or the Halloween season) is on: one drops on a thread from the top and
 * dangles a while, two crawl along the screen edges with pauses. A tap scares one off (it bolts away and comes
 * back much later). Plain DOM + CSS transitions on a few tiny elements, so weak phones don't notice them.
 */
export function Spiders() {
  const [on] = useState(() => (halloweenSkin() || halloweenSeason()) && !window.matchMedia?.('(prefers-reduced-motion: reduce)').matches);
  if (!on) return null;
  return (
    <div className="spiders" aria-hidden="true">
      <Dangler />
      <Crawler side="left" firstDelay={9000} />
      <Crawler side="right" firstDelay={26000} />
    </div>
  );
}

function SpiderArt() {
  // Head up (−y); legs in two sets that step in turn.
  const leg = (side: 1 | -1, i: number) => `M${side * 4} ${-5 + i * 3.2}L${side * 13} ${-13 + i * 6.2}L${side * 20} ${-15 + i * 10.5}`;
  return (
    <svg className="spider__art" viewBox="-24 -24 48 48">
      <g className="spider__legs spider__legs--a">
        <path d={leg(-1, 0)} />
        <path d={leg(-1, 2)} />
        <path d={leg(1, 1)} />
        <path d={leg(1, 3)} />
      </g>
      <g className="spider__legs spider__legs--b">
        <path d={leg(1, 0)} />
        <path d={leg(1, 2)} />
        <path d={leg(-1, 1)} />
        <path d={leg(-1, 3)} />
      </g>
      <ellipse className="spider__body" cx="0" cy="7" rx="7.5" ry="9" />
      <path className="spider__mark" d="M-2.5 3.5h5l-2.5 4 2.5 4h-5l2.5-4z" />
      <circle className="spider__body" cx="0" cy="-6" r="5" />
      <circle className="spider__eye" cx="-2" cy="-7.6" r="1.25" />
      <circle className="spider__eye" cx="2" cy="-7.6" r="1.25" />
      <circle className="spider__eye spider__eye--small" cx="-3.6" cy="-5.4" r="0.7" />
      <circle className="spider__eye spider__eye--small" cx="3.6" cy="-5.4" r="0.7" />
    </svg>
  );
}

const rand = (a: number, b: number) => a + Math.random() * (b - a);
/** Runs `fn` after `ms`, but never while the app is in the background (it simply waits for the next try). */
function later(fn: () => void, ms: number, timers: number[]) {
  const id = window.setTimeout(() => (document.hidden ? later(fn, 4000, timers) : fn()), ms);
  timers.push(id);
}

function scared() {
  sfx.scurry();
  haptic('tap');
}

type DangleState = 'up' | 'down' | 'flee';

/** Drops on a silk thread from under the top bar, sways, twitches, climbs back up; somewhere new each time. */
function Dangler() {
  const [state, setState] = useState<DangleState>('up');
  const [spot, setSpot] = useState({ x: 80, depth: 180 });
  const timers = useRef<number[]>([]);

  useEffect(() => {
    const t = timers.current;
    const drop = () => {
      const w = window.innerWidth;
      // Near the sides, where it covers less of the page.
      const x = Math.random() < 0.5 ? rand(18, Math.min(110, w * 0.25)) : rand(Math.max(w - 110, w * 0.75), w - 34);
      setSpot({ x, depth: rand(120, Math.min(300, window.innerHeight * 0.4)) });
      setState('down');
      later(() => setState('up'), rand(7000, 12000), t);
      later(drop, rand(30000, 55000), t);
    };
    later(drop, rand(3500, 7000), t);
    return () => t.forEach(clearTimeout);
  }, []);

  function tap() {
    if (state !== 'down') return;
    scared();
    setState('flee');
  }

  return (
    <div className={`dangler is-${state}`} style={{ '--x': `${spot.x}px`, '--depth': `${spot.depth}px` } as CSSProperties}>
      <span className="dangler__thread" />
      <span className="dangler__spider spider" onPointerDown={tap}>
        <SpiderArt />
      </span>
    </div>
  );
}

/** Crawls in from off the screen along one edge, wanders up and down with pauses, then leaves. */
function Crawler({ side, firstDelay }: { side: 'left' | 'right'; firstDelay: number }) {
  const el = useRef<HTMLSpanElement>(null);
  const timers = useRef<number[]>([]);
  const fleeing = useRef(false);
  const [walking, setWalking] = useState(false);

  useEffect(() => {
    const t = timers.current;
    const node = el.current!;
    let pos = { x: 0, y: -60 };
    let angle = 180;

    const edgeX = () => (side === 'left' ? rand(4, 22) : window.innerWidth - 32 - rand(4, 22));
    const place = (p: { x: number; y: number }, ms: number) => {
      const dx = p.x - pos.x;
      const dy = p.y - pos.y;
      angle = (Math.atan2(dy, dx) * 180) / Math.PI + 90;
      node.style.transition = `transform ${ms}ms linear`;
      node.style.setProperty('--turn', `${angle}deg`);
      node.style.transform = `translate(${p.x}px, ${p.y}px)`;
      pos = p;
    };
    const jump = (p: { x: number; y: number }) => {
      node.style.transition = 'none';
      node.style.transform = `translate(${p.x}px, ${p.y}px)`;
      void node.offsetWidth; // commit the jump before the next transition starts
      pos = p;
    };
    const walkTo = (p: { x: number; y: number }, speed: number, then: () => void) => {
      const ms = (Math.hypot(p.x - pos.x, p.y - pos.y) / speed) * 1000;
      setWalking(true);
      place(p, ms);
      later(
        () => {
          setWalking(false);
          then();
        },
        ms,
        t,
      );
    };

    const visit = () => {
      fleeing.current = false;
      const fromTop = Math.random() < 0.5;
      const h = window.innerHeight;
      jump({ x: edgeX(), y: fromTop ? -50 : h + 20 });
      let steps = Math.round(rand(3, 6));
      const wander = () => {
        if (fleeing.current) return;
        if (steps-- <= 0) {
          walkTo({ x: pos.x, y: Math.random() < 0.5 ? -60 : h + 30 }, 70, () => later(visit, rand(25000, 60000), t));
          return;
        }
        const target = { x: edgeX(), y: rand(90, h - 130) };
        walkTo(target, Math.random() < 0.25 ? 140 : rand(35, 60), () => later(wander, rand(900, 4200), t));
      };
      wander();
    };
    later(visit, firstDelay, t);

    // A tap: bolt off the nearest end of the edge, come back much later.
    const flee = () => {
      if (fleeing.current) return;
      fleeing.current = true;
      t.forEach(clearTimeout);
      t.length = 0;
      scared();
      const away = {
        x: pos.x,
        y: pos.y < window.innerHeight / 2 ? -70 : window.innerHeight + 40,
      };
      walkTo(away, 520, () => later(visit, rand(45000, 90000), t));
    };
    node.addEventListener('pointerdown', flee);
    return () => {
      node.removeEventListener('pointerdown', flee);
      t.forEach(clearTimeout);
    };
  }, [side, firstDelay]);

  return (
    <span ref={el} className={`crawler spider${walking ? ' is-walking' : ''}`}>
      <SpiderArt />
    </span>
  );
}
