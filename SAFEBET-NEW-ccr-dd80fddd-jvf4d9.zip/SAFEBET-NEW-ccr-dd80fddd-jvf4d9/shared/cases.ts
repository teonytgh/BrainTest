import type { CaseItem } from './types';
import { secureRandom, type Rng } from './random';

export function totalWeight(items: readonly CaseItem[]): number {
  return items.reduce((s, i) => s + i.weight, 0);
}

export function pickWeighted<T extends { weight: number }>(items: readonly T[], rng: Rng = secureRandom): T {
  const total = items.reduce((s, i) => s + i.weight, 0);
  let r = rng() * total;
  for (const item of items) {
    r -= item.weight;
    if (r < 0) return item;
  }
  return items[items.length - 1]!;
}

export function expectedValue(items: readonly CaseItem[], priceOf: (id: string) => number): number {
  const total = totalWeight(items);
  return total ? items.reduce((s, i) => s + priceOf(i.brainrotId) * i.weight, 0) / total : 0;
}

/** Average drop as a share of the case price. */
export const CASE_RTP = 0.88;
/** When the catalog has no items near the price the average may fall to this; below it the case needs a fix. */
export const MIN_RTP = 0.7;
/** Never more than this on average — the project must not run at a loss. */
export const MAX_RTP = 0.9;
/** Total chance of a drop worth more than the case («окуп»). */
export const PROFIT_SHARE = 0.02;
/** The free case has no price; its average drop is fixed instead. */
export const FREE_CASE_EV = 34;
/** Among the profitable items the cheaper ones are likelier: weights ∝ price^-PROFIT_EXP. */
const PROFIT_EXP = 1.5;
/** No single item may take more than this — otherwise the reel is one brainrot over and over. */
const MAX_ITEM_SHARE = 0.6;
const A_MIN = -8;
const A_MAX = 8;

function powerLaw(prices: readonly number[], a: number): number[] {
  const top = Math.max(...prices);
  const w = prices.map((p) => (p / top) ** -a);
  const s = w.reduce((x, y) => x + y, 0);
  return w.map((x) => x / s);
}

const mean = (prices: readonly number[], probs: readonly number[]) => prices.reduce((s, p, i) => s + p * probs[i]!, 0);

/** Bisection for a decreasing function f on [lo, hi]: f(x) ≈ target. */
function solveDecreasing(f: (x: number) => number, target: number, lo: number, hi: number): number {
  for (let i = 0; i < 60; i++) {
    const mid = (lo + hi) / 2;
    if (f(mid) > target) lo = mid;
    else hi = mid;
  }
  return (lo + hi) / 2;
}

/** The exponent range in which no single item exceeds MAX_ITEM_SHARE (a = 0 is the flattest spread). */
function readableRange(prices: readonly number[]): [number, number] {
  const top = (a: number) => Math.max(...powerLaw(prices, a));
  if (top(0) > MAX_ITEM_SHARE) return [0, 0];
  // top(a) falls towards a = 0 from below and rises after it, so each side is a monotone bisection.
  const lo = top(A_MIN) <= MAX_ITEM_SHARE ? A_MIN : solveDecreasing(top, MAX_ITEM_SHARE, A_MIN, 0);
  const hi = top(A_MAX) <= MAX_ITEM_SHARE ? A_MAX : solveDecreasing((x) => -top(x), -MAX_ITEM_SHARE, 0, A_MAX);
  return [lo, hi];
}

export interface ChanceSolution {
  /** Probabilities in item order. */
  probs: number[];
  /** Average drop and spread are within bounds; false means the case needs a new composition or price. */
  ok: boolean;
  ev: number;
  /** Average drop as a share of the target price (the free case compares with FREE_CASE_EV). */
  rtp: number;
  /** Total chance of a drop worth more than the case. */
  profit: number;
}

/**
 * Drop chances from current prices, so catalog price edits re-balance every case at once.
 * Items worth more than the case share PROFIT_SHARE in total (×`luck` during the x2 luck event); the rest
 * follow weights ∝ price^-a with a solved so the average drop is CASE_RTP of the price — luck makes the cheap
 * drops cheaper rather than the case richer. When the catalog has nothing close to the price the average
 * comes out lower; it never goes above the target.
 */
export function solveChances(prices: readonly number[], casePrice: number, luck = 1): ChanceSolution {
  const n = prices.length;
  if (n === 0) return { probs: [], ok: false, ev: 0, rtp: 0, profit: 0 };
  const ps = prices.map((p) => Math.max(p, 0.01));
  const free = casePrice <= 0;
  const base = free ? FREE_CASE_EV : casePrice;
  const target = free ? FREE_CASE_EV : casePrice * CASE_RTP;
  const isProfit = ps.map((p) => !free && p > casePrice);
  const L = ps.filter((_, i) => !isProfit[i]);
  const P = ps.filter((_, i) => isProfit[i]);
  const wantedProfit = free ? 0 : Math.min(0.5, PROFIT_SHARE * luck);
  const finish = (probs: number[], enoughItems: boolean): ChanceSolution => {
    const ev = mean(ps, probs);
    const rtp = ev / base;
    const profit = probs.reduce((s, x, i) => s + (isProfit[i] ? x : 0), 0);
    // A paid case must really offer its окуп chance (or x2 luck would promise nothing).
    const profitOk = free || profit >= wantedProfit * 0.75;
    const ok = enoughItems && profitOk && rtp >= MIN_RTP - 1e-6 && rtp <= (free ? 1.1 : MAX_RTP) + 1e-6;
    return { probs, ok, ev, rtp, profit };
  };
  if (!L.length) return finish(powerLaw(ps, A_MAX), false);

  const pp = P.length ? powerLaw(P, PROFIT_EXP) : [];
  const mP = P.length ? mean(P, pp) : 0;
  let q = P.length ? wantedProfit : 0;
  // What the cheaper items must average for the whole case to average `target`.
  const needL = (target - q * mP) / (1 - q);
  const [aLo, aHi] = readableRange(L);
  const meanAt = (a: number) => mean(L, powerLaw(L, a));
  let a: number;
  if (meanAt(aLo) <= needL) a = aLo; // nothing pricey enough below the price: pay less
  else if (meanAt(aHi) >= needL) a = aHi; // cheap end already too rich: handled below
  else a = solveDecreasing(meanAt, needL, aLo, aHi);
  const mL = meanAt(a);
  // Never overpay: if even the cheapest readable spread averages too much, profits get rarer (down to none).
  if (P.length && (1 - q) * mL + q * mP > target) q = Math.max(0, Math.min(q, (target - mL) / (mP - mL)));
  const pl = powerLaw(L, a);
  let li = 0;
  let pi = 0;
  return finish(
    isProfit.map((p) => (p ? q * pp[pi++]! : (1 - q) * pl[li++]!)),
    L.length >= 3,
  );
}

/** «Открыть сразу несколько»: how many paid openings one press may buy (gift, free and bonus cases open one at a time). */
export const OPEN_COUNTS = [1, 3, 5] as const;
export const MAX_OPEN_COUNT = 5;

/** Smallest chance the admin can set by hand (0.0001 %); 0 means «Невозможно». */
export const MIN_FIXED_CHANCE = 0.000001;

/**
 * Chances with the admin's hand-set ones (`fixed[i]`, 0…1; null = automatic). Fixed items get exactly their
 * chance; the automatic ones share what is left, in the proportions solveChances gives them. Without
 * automatic items (or when the fixed ones take everything) the fixed chances are scaled to 100 %. A case
 * with any fixed chance is the admin's call: `ok` only says whether it can drop anything at all. `cut` < 1 is the
 * temporary «Окуп ×0.5» on top (cutOkup).
 */
export function solveCaseChances(prices: readonly number[], fixed: readonly (number | null)[], casePrice: number, luck = 1, cut = 1): ChanceSolution & { manual: boolean } {
  const s = solveCaseChancesAt(prices, fixed, casePrice, luck);
  if (!(cut < 1) || casePrice <= 0) return s;
  const probs = cutOkup(s.probs, prices, casePrice, cut);
  const ps = prices.map((p) => Math.max(p, 0.01));
  const ev = mean(ps, probs);
  return { ...s, probs, ev, rtp: ev / casePrice, profit: probs.reduce((sum, x, i) => sum + (ps[i]! > casePrice ? x : 0), 0) };
}

/** The choices of «Окуп в кейсах» (admin «Ивенты»): 1 = as usual, 0 = no drop dearer than the case at all. */
export const OKUP_CUTS = [1, 0.75, 0.5, 0.25, 0.1, 0] as const;

/**
 * «Окуп ×0.5» (iteration 38, the owner, for a while): every drop dearer than a paid case gets `factor` of its chance
 * — the hand-set ones too — and the freed chance goes to the cheaper drops in their own proportions, so the case pays
 * less on average. Free and bonus cases (no price) stay as they are.
 */
export function cutOkup(probs: readonly number[], prices: readonly number[], casePrice: number, factor: number): number[] {
  if (!(factor < 1) || casePrice <= 0) return [...probs];
  const f = Math.max(0, factor);
  const dear = prices.map((p) => Math.max(p, 0.01) > casePrice);
  const dearSum = probs.reduce((s, x, i) => s + (dear[i] ? x : 0), 0);
  const cheapSum = probs.reduce((s, x, i) => s + (dear[i] ? 0 : x), 0);
  // Nothing dear to cut, or nothing cheaper to give the chance to: as it is.
  if (dearSum <= 0 || cheapSum <= 0) return [...probs];
  const grow = 1 + (dearSum * (1 - f)) / cheapSum;
  return probs.map((x, i) => (dear[i] ? x * f : x * grow));
}

function solveCaseChancesAt(prices: readonly number[], fixed: readonly (number | null)[], casePrice: number, luck: number): ChanceSolution & { manual: boolean } {
  const manual = fixed.some((f) => f !== null && f !== undefined);
  if (!manual) return { ...solveChances(prices, casePrice, luck), manual };
  const n = prices.length;
  const ps = prices.map((p) => Math.max(p, 0.01));
  const fx = fixed.map((f) => (f === null || f === undefined ? null : Math.min(1, Math.max(0, f))));
  const auto = fx.map((f, i) => (f === null ? i : -1)).filter((i) => i >= 0);
  const fixedSum = fx.reduce<number>((s, f) => s + (f ?? 0), 0);
  const probs = new Array<number>(n).fill(0);
  if (auto.length && fixedSum < 1) {
    const sub = solveChances(
      auto.map((i) => ps[i]!),
      casePrice,
      luck,
    ).probs;
    auto.forEach((i, k) => (probs[i] = sub[k]! * (1 - fixedSum)));
    fx.forEach((f, i) => f !== null && (probs[i] = f));
  } else if (fixedSum > 0) {
    fx.forEach((f, i) => (probs[i] = (f ?? 0) / fixedSum));
  }
  const ev = mean(ps, probs);
  const base = casePrice > 0 ? casePrice : FREE_CASE_EV;
  const profit = casePrice > 0 ? probs.reduce((s, x, i) => s + (ps[i]! > casePrice ? x : 0), 0) : 0;
  return { probs, ok: probs.some((p) => p > 0), ev, rtp: ev / base, profit, manual };
}

export function autoChances(prices: readonly number[], casePrice: number, luck = 1): number[] {
  return solveChances(prices, casePrice, luck).probs;
}

export interface PricedItem {
  id: string;
  price: number;
}

/** Picks k items spread evenly over the price range (input sorted by price). */
function spread<T>(sorted: readonly T[], k: number): T[] {
  if (k <= 0) return [];
  if (sorted.length <= k) return [...sorted];
  if (k === 1) return [sorted[sorted.length - 1]!];
  const picked = new Set<number>();
  for (let i = 0; i < k; i++) picked.add(Math.round((i * (sorted.length - 1)) / (k - 1)));
  return [...picked].map((i) => sorted[i]!);
}

const LOSS_SLOTS = 9;
const PROFIT_SLOTS = 4;

/**
 * Drop table for a case at current prices: ~9 items between 0.35× and 1× the price (most drops land a bit
 * under the price) and up to 4 rarer ones worth more. Items already in the case are kept when they fit, so a
 * hand-made theme survives a re-price. Returns item ids sorted by price; `ok` says whether the result hits
 * the targets (it may not when the catalog simply has nothing around that price).
 */
export function composeCase(catalog: readonly PricedItem[], casePrice: number, keep: readonly string[] = []): { ids: string[]; ok: boolean } {
  const anchor = casePrice > 0 ? casePrice : FREE_CASE_EV * 1.6;
  const byId = new Map(catalog.map((b) => [b.id, b]));
  const sorted = [...catalog].sort((x, y) => x.price - y.price || x.id.localeCompare(y.id));
  const attempt = (lossLo: number, profitHi: number, kept: readonly string[]) => {
    const inLoss = (b: PricedItem) => b.price >= anchor * lossLo && b.price <= anchor;
    const inProfit = (b: PricedItem) => b.price > anchor && b.price <= anchor * profitHi;
    const keptItems = kept.flatMap((id) => (byId.has(id) ? [byId.get(id)!] : [])).sort((x, y) => x.price - y.price);
    const loss = spread(keptItems.filter(inLoss), LOSS_SLOTS);
    const profit = spread(keptItems.filter(inProfit), PROFIT_SLOTS);
    const taken = new Set([...loss, ...profit].map((b) => b.id));
    // Fill the gaps evenly across each band; the top of the loss band matters most for the average.
    const fill = (band: PricedItem[], have: PricedItem[], slots: number) => {
      const free = band.filter((b) => !taken.has(b.id));
      const add = spread(free, slots - have.length);
      add.forEach((b) => taken.add(b.id));
      return [...have, ...add];
    };
    const lossAll = fill(sorted.filter(inLoss), loss, LOSS_SLOTS);
    const profitAll = fill(sorted.filter(inProfit), profit, PROFIT_SLOTS);
    const items = [...lossAll, ...profitAll].sort((x, y) => x.price - y.price);
    const prices = items.map((b) => b.price);
    return { ids: items.map((b) => b.id), ok: solveChances(prices, casePrice).ok, miss: caseMiss(prices, casePrice) };
  };
  const tries: [number, number, readonly string[]][] = [
    [0.35, 10, keep],
    [0.35, 10, []],
    [0.2, 15, []],
    [0.1, 30, []],
  ];
  let best: { ids: string[]; ok: boolean; miss: number } | null = null;
  for (const [lossLo, profitHi, kept] of tries) {
    const next = attempt(lossLo, profitHi, kept);
    if (next.ok) return { ids: next.ids, ok: true };
    if (!best || next.miss < best.miss) best = next;
  }
  return { ids: best!.ids, ok: false };
}

/** How far a case is from its target average (0 = on target, +1 when out of bounds); compares two tables. */
export function caseMiss(prices: readonly number[], casePrice: number): number {
  const s = solveChances(prices, casePrice);
  if (!s.probs.length) return 100;
  const profitGap = casePrice > 0 ? Math.abs(s.profit - PROFIT_SHARE) * 8 : 0;
  return Math.abs(s.rtp - (casePrice > 0 ? CASE_RTP : 1)) + profitGap + (s.ok ? 0 : 1) + (s.rtp > (casePrice > 0 ? MAX_RTP : 1.1) ? 10 : 0);
}

const nicePrice = (x: number) => {
  if (x < 100) return Math.max(1, Math.round(x) - (x >= 20 ? 1 : 0));
  const step = 10 ** (Math.floor(Math.log10(x)) - 1);
  return Math.round(x / step) * step - (x >= 1000 ? 10 : 1);
};

/** A nearby case price at which the current catalog gives a healthy case, or null if the price already works. */
export function suggestCasePrice(catalog: readonly PricedItem[], casePrice: number): number | null {
  if (casePrice <= 0 || composeCase(catalog, casePrice).ok) return null;
  let best: number | null = null;
  for (let i = 1; i <= 40; i++) {
    for (const f of [1 / (1 + i * 0.025), 1 + i * 0.025]) {
      const x = nicePrice(casePrice * f);
      if (composeCase(catalog, x).ok) best ??= x;
    }
    if (best !== null) return best;
  }
  return null;
}
