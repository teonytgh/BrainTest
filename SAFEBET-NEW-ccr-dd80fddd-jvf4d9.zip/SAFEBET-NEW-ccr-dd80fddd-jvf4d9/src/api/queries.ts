import { QueryClient, queryOptions, useQuery } from '@tanstack/react-query';
import type { Me } from '../../server/me';
import type { Announcement } from '../../server/settings';
import type { Brainrot, CaseDef, CaseSection } from '../../shared/types';
import type { DepositOpen } from '../../shared/deposit';
import type { EventsState, Snap } from '../../shared/events';
import type { SkyRun } from '../../shared/sky';
import type { SquidGameView } from '../../shared/squid';
import type { Shout } from '../../shared/shout';
import { ApiError, api } from './client';
import { liveSocketOpen } from '../lib/socketState';

export type { Me };

export interface CatalogResponse {
  brainrots: Brainrot[];
  cases: CaseDef[];
  sections: CaseSection[];
  topDrop: { brainrotId: string; player: string; playerId: string; photo?: string | null; at: number } | null;
  /** Deposit tabs taking new requests (admin «Приём пополнений»). */
  depositOpen?: DepositOpen;
  /** A site-wide message from an owner, shown as a banner (null = none). */
  announcement?: Announcement | null;
  /** Each event's end while it runs (cases x2 luck, FUSE, upgrader, Raining Tacos). */
  events?: EventsState;
  /** The last «Щелчок» while its events run. */
  snap?: Snap | null;
  /** «Небо Meowl» while it runs (its seed draws the map). */
  sky?: SkyRun | null;
  /** «Игра Кальмара» from its start until it is settled (the invite shows while its lobby is open). */
  squid?: SquidGameView | null;
  /** «Анонс в игре» (iteration 37): the latest admin shout; shown on top while fresh. */
  shout?: Shout | null;
}

export interface CatalogView extends CatalogResponse {
  byId: Map<string, Brainrot>;
  active: Brainrot[];
  caseById: Map<string, CaseDef>;
}

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 30_000,
      refetchOnWindowFocus: false,
      retry: (count, e) => !(e instanceof ApiError && e.status > 0 && e.status < 500) && count < 2,
    },
    mutations: { retry: 0 },
  },
});

/** The newer of two profiles (by the database read time): a late answer read before the last action never wins. */
const newest = (next: Me, cur: Me | undefined): Me => (cur && next.rev < cur.rev ? cur : next);

export const meQuery = queryOptions({
  queryKey: ['me'],
  queryFn: async () => newest(await api<Me>('/api/me'), queryClient.getQueryData<Me>(['me'])),
  // Changes made elsewhere arrive over the live socket (src/lib/live.ts); this poll is only the safety net, and a
  // slow one while the socket is up. A running game animation holds it (below) so the balance can't jump early.
  refetchInterval: () => (meHeld ? false : liveSocketOpen() ? 120_000 : 45_000),
});

/**
 * While a game plays its win/lose animation, the result is already committed on the server but must not show on
 * screen yet (a balance jump in the top bar would spoil it). The game holds `me` for the length of the animation;
 * the poll pauses and live `me` refreshes are deferred (src/lib/live.ts), and releasing catches up at once.
 */
let meHeld = false;
export function holdMe(on: boolean) {
  meHeld = on;
  if (!on) void queryClient.invalidateQueries({ queryKey: meQuery.queryKey });
}
export function meIsHeld() {
  return meHeld;
}

function buildCatalog(c: CatalogResponse): CatalogView {
  return {
    ...c,
    byId: new Map(c.brainrots.map((b) => [b.id, b])),
    // Coin prizes only drop from cases: never a shop item, an upgrade target or a payout.
    active: c.brainrots.filter((b) => b.status === 'active' && b.kind !== 'coins'),
    caseById: new Map(c.cases.map((k) => [k.id, k])),
  };
}

export const catalogQuery = queryOptions({
  queryKey: ['catalog'],
  queryFn: () => api<CatalogResponse>('/api/catalog'),
  staleTime: 60_000,
  refetchInterval: 120_000,
});

/** Only rendered below the app gate, so the data is always present. */
export function useMe(): Me {
  const { data } = useQuery(meQuery);
  if (!data) throw new Error('useMe used before the profile loaded');
  return data;
}

export function useCatalog(): CatalogView {
  const { data } = useQuery({ ...catalogQuery, select: buildCatalog });
  if (!data) throw new Error('useCatalog used before the catalog loaded');
  return data;
}

/**
 * Server time minus this phone's clock, measured when the profile arrived: phones' clocks drift, and `me` itself
 * may be tens of seconds old, so `me.serverNow - Date.now()` would be off by its age.
 */
export function serverOffset(): number {
  const state = queryClient.getQueryState<Me>(meQuery.queryKey);
  return state?.data && state.dataUpdatedAt ? state.data.serverNow - state.dataUpdatedAt : 0;
}

export function setMe(me: Me) {
  queryClient.setQueryData<Me>(meQuery.queryKey, (cur) => newest(me, cur));
}

/** A game/economy action: the server answers with the result and the fresh player state. */
export function act<T>(path: string, body: unknown = {}) {
  return api<{ result: T; me: Me }>(path, { body });
}

export function refreshCatalog() {
  return queryClient.invalidateQueries({ queryKey: catalogQuery.queryKey });
}
