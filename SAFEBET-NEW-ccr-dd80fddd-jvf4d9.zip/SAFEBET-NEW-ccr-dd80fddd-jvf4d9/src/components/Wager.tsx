import { Coin } from './Coin';
import { Icon } from './Icon';
import { formatCoins } from '../lib/format';
import { wagerProgress, type Wager, type WithdrawRules } from '../../shared/withdraw';

const times = (x: number) => `×${x.toLocaleString('ru-RU', { maximumFractionDigits: 2 })}`;

/** The rule in words (the withdraw sheet, the deposit sheet): the same numbers the server uses. */
export function wagerRule(rules: WithdrawRules): string {
  return `Перед выводом пополнения отыгрываются ${times(rules.wagerDeposit)}, бонусы и призы — ${times(rules.wagerBonus)}: поставь эту сумму в любых играх. Каждая ставка засчитывается целиком, выигрыши со своих ставок отыгрывать не нужно.`;
}

/**
 * «Отыгрыш» (iteration 36): how much is left to play before a withdrawal opens, as a bar of the current round. Nothing
 * when it is played out.
 */
export function WagerMeter({ wager, rules, onPlay }: { wager: Wager; rules: WithdrawRules; onPlay?: () => void }) {
  if (wager.left <= 0) return null;
  const pct = Math.round(wagerProgress(wager) * 100);
  const played = Math.max(0, Math.round((wager.total - wager.left) * 100) / 100);
  return (
    <section className="wager" aria-label="Отыгрыш перед выводом">
      <div className="wager__head">
        <span className="wager__title">
          <Icon name="dice" size={15} /> Отыгрыш
        </span>
        <span className="wager__left" data-private="money">
          осталось <b>{formatCoins(wager.left)}</b> <Coin size={13} />
        </span>
      </div>
      <div className="wager__bar" role="progressbar" aria-valuemin={0} aria-valuemax={100} aria-valuenow={pct} aria-label={`Отыграно ${pct}%`}>
        <span style={{ transform: `scaleX(${pct / 100})` }} />
      </div>
      <p className="wager__meta" data-private="money">
        Отыграно {formatCoins(played)} из {formatCoins(wager.total)} B · {pct}%
      </p>
      <p className="wager__rule">{wagerRule(rules)}</p>
      {onPlay && (
        <button type="button" className="btn btn--ghost btn--sm wager__play" onClick={onPlay}>
          <Icon name="play" size={15} /> Отыграть в играх
        </button>
      )}
    </section>
  );
}

/** One line under a deposit form: the deposit is played through before a withdrawal (said before paying). */
export function DepositWagerNote({ rules }: { rules: WithdrawRules }) {
  if (rules.wagerDeposit <= 0) return null;
  return (
    <p className="dep-wager">
      <Icon name="info" size={14} />
      <span>
        Перед выводом пополнение нужно отыграть {times(rules.wagerDeposit)} — поставить в любых играх. Выигрыши со своих ставок отыгрывать не нужно.
      </span>
    </p>
  );
}

/** The profile's short line next to «Вывод»: how much is left to play. */
export function WagerChip({ wager }: { wager: Wager }) {
  if (wager.left <= 0) return null;
  return (
    <p className="wager-chip" data-private="money">
      <Icon name="dice" size={13} /> Отыгрыш: осталось {formatCoins(wager.left)} <Coin size={12} />
    </p>
  );
}
