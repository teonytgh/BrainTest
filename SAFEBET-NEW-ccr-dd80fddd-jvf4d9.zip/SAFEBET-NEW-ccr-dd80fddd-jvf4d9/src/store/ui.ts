import { createStore, useStore } from './createStore';

export type SheetId = 'deposit' | 'promo' | 'settings';

interface UiState {
  menuOpen: boolean;
  sheet: SheetId | null;
  /** Public id of the player whose profile sheet is open. */
  player: string | null;
  /** The withdrawal sheet; `preselect` is the inventory item it starts with. */
  withdraw: { open: boolean; preselect: number | null };
}

const ui = createStore<UiState>({ menuOpen: false, sheet: null, player: null, withdraw: { open: false, preselect: null } });

export const useUi = () => useStore(ui);

export function openMenu() {
  ui.set((s) => ({ ...s, menuOpen: true }));
}

export function closeMenu() {
  ui.set((s) => (s.menuOpen ? { ...s, menuOpen: false } : s));
}

export function openSheet(sheet: SheetId) {
  ui.set((s) => ({ ...s, menuOpen: false, sheet, player: null }));
}

export function openPlayer(publicId: string) {
  ui.set((s) => ({ ...s, menuOpen: false, sheet: null, player: publicId }));
}

export function openWithdraw(preselect: number | null = null) {
  ui.set((s) => ({ ...s, menuOpen: false, withdraw: { open: true, preselect } }));
}

export function closeWithdraw() {
  ui.set((s) => (s.withdraw.open ? { ...s, withdraw: { open: false, preselect: null } } : s));
}

export function closePlayer() {
  ui.set((s) => (s.player ? { ...s, player: null } : s));
}

export function closeSheet() {
  ui.set((s) => (s.sheet ? { ...s, sheet: null } : s));
}
