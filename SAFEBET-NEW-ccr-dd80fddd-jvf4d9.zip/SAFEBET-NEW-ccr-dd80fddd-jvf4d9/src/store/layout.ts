import { createStore, useStore } from './createStore';

/** «Вид» in settings: auto picks the PC layout on wide windows (Telegram Desktop, web, tablets in landscape). */
export type LayoutPref = 'auto' | 'phone' | 'pc';
export type LayoutMode = 'phone' | 'pc';

const KEY = 'brainrotcrash:layout';
const PC_MIN_WIDTH = 900;

function readPref(): LayoutPref {
  try {
    const v = localStorage.getItem(KEY);
    return v === 'phone' || v === 'pc' ? v : 'auto';
  } catch {
    return 'auto';
  }
}

function modeFor(pref: LayoutPref): LayoutMode {
  if (pref !== 'auto') return pref;
  return window.innerWidth >= PC_MIN_WIDTH ? 'pc' : 'phone';
}

const initial = readPref();
const layout = createStore<{ pref: LayoutPref; mode: LayoutMode }>({ pref: initial, mode: modeFor(initial) });

function apply() {
  document.documentElement.dataset.layout = layout.get().mode;
}

export function initLayout() {
  apply();
  window.addEventListener('resize', () => {
    layout.set((s) => {
      const mode = modeFor(s.pref);
      return mode === s.mode ? s : { ...s, mode };
    });
    apply();
  });
}

export function setLayoutPref(pref: LayoutPref) {
  try {
    if (pref === 'auto') localStorage.removeItem(KEY);
    else localStorage.setItem(KEY, pref);
  } catch {
    // The choice just won't survive a restart.
  }
  layout.set(() => ({ pref, mode: modeFor(pref) }));
  apply();
}

export const useLayout = () => useStore(layout);
