import { floor2, round2 } from './money';
import type { Brainrot } from './types';

export interface Payout {
  brainrot: Brainrot | null;
  coins: number;
  value: number;
}

/** Most expensive brainrot that fits into the value; the remainder is paid in coins. */
export function payoutFor(value: number, catalog: readonly Brainrot[]): Payout {
  const total = Math.max(0, floor2(value));
  let best: Brainrot | null = null;
  for (const b of catalog) {
    if (b.status !== 'active') continue;
    if (b.price <= total && (!best || b.price > best.price)) best = b;
  }
  return { brainrot: best, coins: round2(total - (best?.price ?? 0)), value: total };
}
