import { assertActive, type Viewer } from './auth';
import { db, num, one, q } from './db';
import { ensureRefCode, refLink } from './referrals';
import { env, promo, siteUrl } from './env';
import { HttpError, bad } from './errors';
import { appLink } from './notifications';
import { getSettings, type FreeGate } from './settings';
import { BotRefusal, botCall } from './telegram';
import { int, type Body } from './validate';

/**
 * Conditions of the daily free case: a subscription to the channel (checked on every opening, so a player
 * who unsubscribes is asked again) and a fresh «share with a friend» before each opening.
 */

type ChannelStatus = 'ok' | 'missing' | 'unverifiable';

const SHARE_LIMIT = 10; // prepared messages per 10 minutes

/** getChatMember works for channels only when the bot is an admin there; otherwise we cannot tell. */
export async function channelStatus(channel: string, userId: number): Promise<ChannelStatus> {
  const r = await botCall<{ status: string; is_member?: boolean }>('getChatMember', { chat_id: channel, user_id: userId });
  if (r instanceof BotRefusal) return /user not found|participant_id_invalid/i.test(r.description) ? 'missing' : 'unverifiable';
  if (!r) return 'unverifiable';
  if (['creator', 'administrator', 'member'].includes(r.status) || (r.status === 'restricted' && r.is_member)) return 'ok';
  return 'missing';
}

export const channelUrl = (channel: string) => `https://t.me/${channel.replace(/^@/, '')}`;

async function sharedSinceLastOpen(userId: number): Promise<boolean> {
  const u = await one<{ ok: boolean }>('SELECT free_share_at IS NOT NULL AND (free_case_at IS NULL OR free_share_at > free_case_at) AS ok FROM users WHERE id = $1', [userId]);
  return !!u?.ok;
}

async function state(userId: number, gate: FreeGate) {
  const [channel, shared] = await Promise.all([gate.channel ? channelStatus(gate.channel, userId) : Promise.resolve<ChannelStatus>('ok'), sharedSinceLastOpen(userId)]);
  return {
    channel: gate.channel ? { username: gate.channel, url: channelUrl(gate.channel), status: channel } : null,
    share: gate.share ? { done: shared } : null,
    ready: channel !== 'missing' && (!gate.share || shared),
  };
}

export async function freeGateState(v: Viewer) {
  return state(v.id, (await getSettings()).freeGate);
}

/** Called before a free opening; throws the step the player still has to do. */
export async function assertFreeGate(userId: number) {
  const { freeGate } = await getSettings();
  const s = await state(userId, freeGate);
  if (s.channel?.status === 'missing') {
    throw bad('need_channel', `Подпишись на канал ${s.channel.username}, чтобы открыть бесплатный кейс`, { channel: s.channel.username, url: s.channel.url });
  }
  if (s.share && !s.share.done) throw bad('need_share', 'Поделись BrainrotCrash с другом, чтобы открыть бесплатный кейс');
}

const CAPTIONS = [
  '🎁 <b>Бесплатный кейс каждый день!</b>\nЯ уже кручу кейсы с брейнротами в BrainrotCrash — заходи по моей ссылке, нам обоим дадут реферальный кейс 👇',
  '🔥 <b>Нашёл, где брейнроты падают бесплатно</b>\nКейсы, апгрейды и батлы прямо в Telegram. Забирай свой бесплатный кейс 👇',
  '😱 <b>Мне сейчас выпал брейнрот из бесплатного кейса!</b>\nПопробуй тоже — BrainrotCrash, бесплатный кейс каждые 12 часов 👇',
  '🎰 <b>Го батл в BrainrotCrash?</b>\nСначала забери бесплатный кейс — а потом посмотрим, кому повезёт больше 😏',
];

/** How long a prepared, not yet confirmed message is handed out again (the app prepares it before the tap). */
const REUSE_MINUTES = 30;

/**
 * A ready-made message (photo, text, «Забрать» button) the Mini App hands to Telegram's chat picker via
 * WebApp.shareMessage. Text changes from one share to the next. The app asks for it as soon as the share step shows,
 * so a tap opens the picker at once: until it is confirmed, the same message comes back (no new bot call, and the
 * 10-per-10-minutes limit only counts new ones).
 */
export async function prepareShare(v: Viewer) {
  assertActive(v);
  const reuse = await one<{ id: string; prepared_id: string }>(
    `SELECT id, prepared_id FROM free_shares
     WHERE user_id = $1 AND confirmed_at IS NULL AND prepared_id IS NOT NULL AND created_at > now() - interval '${REUSE_MINUTES} minutes'
     ORDER BY id DESC LIMIT 1`,
    [v.id],
  );
  if (reuse) return shareView(num(reuse.id), reuse.prepared_id, refLink(await ensureRefCode(db, v.id)));
  const recent = await one<{ n: string }>(`SELECT count(*) AS n FROM free_shares WHERE user_id = $1 AND created_at > now() - interval '10 minutes'`, [v.id]);
  if (num(recent?.n) >= SHARE_LIMIT) throw new HttpError(429, 'too_many', 'Слишком часто — подожди пару минут');
  const row = (await q<{ id: string }>('INSERT INTO free_shares (user_id) VALUES ($1) RETURNING id', [v.id]))[0]!;
  const caption = captionOf(num(row.id));
  // The friend lands on the sharer's referral link: both get a referral case.
  const link = refLink(await ensureRefCode(db, v.id));
  const prepared = await botCall<{ id: string }>('savePreparedInlineMessage', {
    user_id: v.id,
    result: {
      type: 'photo',
      id: `share-${row.id}`,
      photo_url: `${siteUrl()}${promo('share.jpg')}`,
      thumbnail_url: `${siteUrl()}${promo('share-thumb.jpg')}`,
      photo_width: 1280,
      photo_height: 720,
      caption,
      parse_mode: 'HTML',
      reply_markup: { inline_keyboard: [[{ text: '🎁 Забрать бесплатный кейс', url: link }]] },
    },
    allow_user_chats: true,
    allow_group_chats: true,
    allow_channel_chats: true,
  });
  const preparedId = prepared && !(prepared instanceof BotRefusal) ? prepared.id : null;
  if (preparedId) await q('UPDATE free_shares SET prepared_id = $2 WHERE id = $1', [row.id, preparedId]);
  return shareView(num(row.id), preparedId, link);
}

const captionOf = (shareId: number) => CAPTIONS[shareId % CAPTIONS.length]!;

function shareView(shareId: number, preparedId: string | null, url: string) {
  // Plain text for the t.me/share fallback (older Telegram clients, outside Telegram).
  const text = captionOf(shareId).replace(/<[^>]+>/g, '').replace(/\s*👇$/, '');
  return { shareId, preparedId, text, url };
}

/**
 * The client reports Telegram's «sent». Telegram does not tell the bot about it, so this is trusted — the
 * share is a growth step, not a payment.
 */
export async function confirmShare(v: Viewer, body: Body) {
  assertActive(v);
  const id = int(body.shareId, 'share', 1);
  // Each prepared message counts once: a confirmation can't be replayed for the next opening.
  const row = await one(
    `UPDATE free_shares SET confirmed_at = now() WHERE id = $1 AND user_id = $2 AND confirmed_at IS NULL AND created_at > now() - interval '1 hour' RETURNING id`,
    [id, v.id],
  );
  if (!row) throw bad('share_expired', 'Попробуй поделиться ещё раз');
  await q('UPDATE users SET free_share_at = now() WHERE id = $1', [v.id]);
  return freeGateState(v);
}

/** Admin check: does the bot see the channel's members (it must be an admin there)? */
export async function adminFreeGate() {
  const { freeGate } = await getSettings();
  let botIsAdmin: boolean | null = null;
  if (freeGate.channel) {
    const botId = Number((env('BOT_TOKEN') ?? '').split(':')[0]);
    const r = botId ? await botCall<{ status: string }>('getChatMember', { chat_id: freeGate.channel, user_id: botId }) : null;
    botIsAdmin = r instanceof BotRefusal ? false : r ? r.status === 'administrator' || r.status === 'creator' : null;
  }
  return { ...freeGate, botIsAdmin, appLink: appLink('case/free') };
}
