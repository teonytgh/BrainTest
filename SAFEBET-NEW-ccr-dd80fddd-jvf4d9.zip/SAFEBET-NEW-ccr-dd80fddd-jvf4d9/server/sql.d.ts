/** Migration files bundled as text (wrangler `rules` Text, the `sql-text` plugin in vite.config.ts). */
declare module '*.sql' {
  const sql: string;
  export default sql;
}
