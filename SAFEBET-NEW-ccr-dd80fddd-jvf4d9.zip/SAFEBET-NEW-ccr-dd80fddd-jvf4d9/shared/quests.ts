/**
 * «Задания» (iteration 32): every MSK day 3 new daily quests, every week (from Monday) 4 weekly ones — the same for
 * every player, built from templates by the day's / week's number and kept in `quest_sets`, so a catalog edit never
 * changes them halfway. They pay **tickets**, a currency of their own, spent on the ticket cases («Затмение» 119,
 * «Кенди» 240). Progress is read from the game history: only paid stakes count.
 *
 * Never in the red: a ticket costs the house ≈ TICKET_VALUE B (what the ticket cases drop on average per ticket), and a
 * quest pays 30 % of what the house keeps on average on the turnover it asks for — 0.3 ticket per 1 B in the games that
 * keep 12 % (cases, battles, the upgrader, FUSE, dice), 0.15 in those that keep 6 % (mines, the road). The deposit
 * quest counts NET deposits of the week (deposits − withdrawals): bringing brainrots in and taking them out again is 0.
 */
export type QuestKind = 'daily' | 'weekly';
export type QuestGame = 'case' | 'battle' | 'upgrade' | 'fuse' | 'dice' | 'mines' | 'road';
/**
 * case_open — open the case `caseId` `target` times; turnover — `target` B of paid stakes in `game`; plays — `target`
 * paid games in `game` with a stake of at least `minStake` B each; deposit — `target` B of net deposits this week;
 * friend — friends who played FRIEND_QUEST_TURNOVER B in cases and battles this week; days — days of this week with a
 * daily quest claimed.
 */
export type QuestType = 'case_open' | 'turnover' | 'plays' | 'deposit' | 'friend' | 'days';

export interface Quest {
  /** d0…d2 / w0…w3: unique within its period. */
  id: string;
  kind: QuestKind;
  type: QuestType;
  game?: QuestGame;
  caseId?: string;
  caseName?: string;
  minStake?: number;
  target: number;
  /** Tickets. */
  reward: number;
  name: string;
  text: string;
  /** The picture on the card: the case's art or a brainrot. */
  image: string;
}

export interface QuestView extends Quest {
  progress: number;
  claimed: boolean;
  /** When the period (and the quest) resets. */
  endsAt: number;
}

/** A case a quest can name: paid, active. */
export interface QuestCase {
  id: string;
  name: string;
  price: number;
  image: string;
}

/** What one ticket costs the house on average (the ticket cases' average drop ÷ their price in tickets). */
export const TICKET_VALUE = 0.12;
/** Tickets per 1 B of turnover: 30 % of the house's 12 % (or 6 %) edge, in tickets. */
export const TICKETS_PER_B: Record<QuestGame, number> = { case: 0.3, battle: 0.3, upgrade: 0.3, fuse: 0.3, dice: 0.3, mines: 0.15, road: 0.15 };
export const FRIEND_QUEST_TURNOVER = 300;
export const DEPOSIT_QUEST = { target: 1_000, reward: 70 };
export const FRIEND_QUEST_REWARD = 60;
export const DAYS_QUEST = { target: 5, reward: 40 };
export const DAILY_COUNT = 3;
export const WEEKLY_COUNT = 4;

const DAY = 86_400_000;
const MSK = 3 * 3_600_000;

/** MSK day number and its start (UTC ms). */
export const dayIndex = (ms: number) => Math.floor((ms + MSK) / DAY);
export const dayStart = (d: number) => d * DAY - MSK;

/** A small seeded generator (mulberry32): the same day always gives the same quests. */
function rng(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4_294_967_296;
  };
}

function shuffle<T>(items: readonly T[], next: () => number): T[] {
  const out = [...items];
  for (let i = out.length - 1; i > 0; i--) {
    const j = Math.floor(next() * (i + 1));
    [out[i], out[j]] = [out[j]!, out[i]!];
  }
  return out;
}

const tickets = (game: QuestGame, turnover: number) => Math.max(3, Math.round(TICKETS_PER_B[game] * turnover));

const opens = (n: number) => (n === 1 ? 'один раз' : n === 2 ? 'два раза' : n === 3 ? 'три раза' : `${n} раз`);

/** Picks a case whose price lies in [lo, hi] (the nearest to that range when none does), not one of `taken`. */
function pickCase(cases: readonly QuestCase[], lo: number, hi: number, next: () => number, taken: Set<string>) {
  const free = cases.filter((c) => !taken.has(c.id));
  if (!free.length) return null;
  const inside = free.filter((c) => c.price >= lo && c.price <= hi);
  const pool = inside.length ? inside : [...free].sort((a, b) => Math.min(Math.abs(a.price - lo), Math.abs(a.price - hi)) - Math.min(Math.abs(b.price - lo), Math.abs(b.price - hi))).slice(0, 2);
  const c = pool[Math.floor(next() * pool.length)]!;
  taken.add(c.id);
  return c;
}

function caseQuest(id: string, kind: QuestKind, c: QuestCase, n: number): Quest {
  return {
    id,
    kind,
    type: 'case_open',
    game: 'case',
    caseId: c.id,
    caseName: c.name,
    target: n,
    reward: tickets('case', c.price * n),
    name: n === 1 ? `Открой «${c.name}»` : `Открой «${c.name}» ${n} раза`,
    text: kind === 'daily' ? `Открой кейс «${c.name}» ${opens(n)} за день.` : `Открой кейс «${c.name}» ${opens(n)} за неделю.`,
    image: c.image,
  };
}

type Template = (id: string, kind: QuestKind) => Quest;

const turnover = (game: QuestGame, target: number, name: string, text: string, image: string): Template => (id, kind) => ({
  id,
  kind,
  type: 'turnover',
  game,
  target,
  reward: tickets(game, target),
  name,
  text,
  image,
});

const plays = (game: QuestGame, n: number, minStake: number, name: string, text: string, image: string): Template => (id, kind) => ({
  id,
  kind,
  type: 'plays',
  game,
  minStake,
  target: n,
  reward: tickets(game, n * minStake),
  name,
  text,
  image,
});

const B = (n: number) => n.toLocaleString('ru-RU');

/** The daily non-case quests: two of them a day. */
const DAILY: readonly Template[] = [
  plays('upgrade', 1, 20, 'Сыграй в апгрейдер', 'Сделай один апгрейд со ставкой от 20 B.', '/brainrots/tralaledon.webp'),
  plays('upgrade', 3, 20, 'Тройной апгрейд', 'Сделай 3 апгрейда со ставкой от 20 B каждый.', '/brainrots/nuclearo-dinossauro.webp'),
  turnover('upgrade', 100, 'Апгрейд Тралаледона', `Сыграй в апгрейдере на ${B(100)} B.`, '/brainrots/tralaledon.webp'),
  turnover('battle', 100, 'Батл Лос Хакерс', `Сыграй в батлах на ${B(100)} B.`, '/brainrots/los-hackers.webp'),
  turnover('case', 150, 'Разминка Гарамы', `Открой любые платные кейсы на ${B(150)} B.`, '/brainrots/garama-and-madundung.webp'),
  turnover('mines', 100, 'Сапёр', `Сыграй в «Мины» на ${B(100)} B.`, '/brainrots/los-tictacs.webp'),
  turnover('road', 100, 'Перейди дорогу', `Сыграй в «Дорогу» на ${B(100)} B.`, '/brainrots/wave-rider.webp'),
  plays('fuse', 1, 50, 'Покорми дом', 'Сделай FUSE со ставкой от 50 B.', '/brainrots/la-grande-combinasion.webp'),
  plays('dice', 3, 10, 'Брось кубики', 'Сыграй в колор-дайс 3 раза со ставкой от 10 B.', '/brainrots/money-money-puggy.webp'),
];

/** The fourth weekly quest, one of these. */
const WEEKLY_EXTRA: readonly Template[] = [
  (id, kind) => ({
    id,
    kind,
    type: 'friend',
    target: 1,
    reward: FRIEND_QUEST_REWARD,
    name: 'Лос Амигос',
    text: `Позови друга — он сыграет в кейсах и батлах на ${FRIEND_QUEST_TURNOVER} B за неделю.`,
    image: '/brainrots/los-amigos.webp',
  }),
  (id, kind) => ({
    id,
    kind,
    type: 'days',
    target: DAYS_QUEST.target,
    reward: DAYS_QUEST.reward,
    name: 'Мани-мани неделя',
    text: `Выполняй хотя бы одно дневное задание ${DAYS_QUEST.target} дней за неделю.`,
    image: '/brainrots/money-money-bros.webp',
  }),
  turnover('upgrade', 500, 'Ядерный апгрейд', `Сыграй в апгрейдере на ${B(500)} B за неделю.`, '/brainrots/nuclearo-dinossauro.webp'),
  turnover('battle', 500, 'Король батлов', `Сыграй в батлах на ${B(500)} B за неделю.`, '/brainrots/los-hackers.webp'),
];

/**
 * The quests of one period. `cases` = the paid cases that may be named (any order: they are sorted here, so the
 * result depends only on the period and the catalog at the time).
 */
export function buildQuestSet(kind: QuestKind, index: number, cases: readonly QuestCase[]): Quest[] {
  const next = rng((kind === 'daily' ? 0x9e3779b1 : 0x85ebca6b) ^ (index * 2_654_435_761));
  const sorted = [...cases].sort((a, b) => a.id.localeCompare(b.id));
  const taken = new Set<string>();
  const out: Quest[] = [];
  if (kind === 'daily') {
    const c = pickCase(sorted, 15, 150, next, taken);
    if (c) out.push(caseQuest('d0', kind, c, 1));
    for (const t of shuffle(DAILY, next)) {
      if (out.length >= DAILY_COUNT) break;
      const q = t(`d${out.length}`, kind);
      // Never two quests on the same game on one day.
      if (out.some((o) => o.game === q.game)) continue;
      out.push(q);
    }
    return out;
  }
  const a = pickCase(sorted, 40, 200, next, taken);
  if (a) out.push(caseQuest(`w${out.length}`, kind, a, 3));
  const b = pickCase(sorted, 80, 600, next, taken);
  if (b) out.push(caseQuest(`w${out.length}`, kind, b, 2));
  out.push({
    id: `w${out.length}`,
    kind,
    type: 'deposit',
    target: DEPOSIT_QUEST.target,
    reward: DEPOSIT_QUEST.reward,
    name: `Задепай ${B(DEPOSIT_QUEST.target)} B`,
    text: `Пополни баланс любым способом на ${B(DEPOSIT_QUEST.target)} B за неделю (пополнения минус выводы).`,
    image: '/coin.webp',
  });
  for (const t of shuffle(WEEKLY_EXTRA, next)) {
    if (out.length >= WEEKLY_COUNT) break;
    out.push(t(`w${out.length}`, kind));
  }
  return out;
}
