import { num, q, type Queryable } from './db';
import { promo, siteUrl } from './env';
import { getSettings, luckState } from './settings';
import { BotRefusal, botCall, escapeHtml } from './telegram';

/**
 * Bot messages nobody asked for in the moment: the x2 luck broadcast, «free case is ready» reminders and the
 * «where did you go?» nudge. All of them run from the scheduled tick in small batches, skip players who
 * blocked the bot, and the reminders respect quiet hours.
 */

/**
 * Messages per tick across all jobs: every message is a subrequest, and a Worker on the free plan gets 50 per
 * invocation (the tick's other jobs need a few). Well under Telegram's ~30/s too.
 */
const TICK_BUDGET = 40;
const CHUNK = 8;
const CHUNK_PAUSE_MS = 300;
/** No reminders 23:00–09:00 Moscow time (the audience is mostly there). */
const QUIET_FROM = 23;
const QUIET_TO = 9;
/** Away this long → one «where did you go?» message; reminders stop until they come back. */
const AWAY_DAYS = 3;

export interface Outgoing {
  html: string;
  /** Path under the site (e.g. /promo/free-case.jpg) or an absolute URL. */
  photo?: string | null;
  button?: { text: string; open?: string } | null;
}

/** Deep links ride in the query string: Telegram keeps the hash for its own launch data. */
export const appLink = (open?: string) => `${siteUrl()}/${open ? `?open=${open}` : ''}`;
const absolute = (path: string) => (/^https?:\/\//.test(path) ? path : `${siteUrl()}${path}`);

export function isQuietHours(now = new Date()): boolean {
  const hour = Number(new Intl.DateTimeFormat('en-GB', { timeZone: 'Europe/Moscow', hour: '2-digit', hourCycle: 'h23' }).format(now));
  return hour >= QUIET_FROM || hour < QUIET_TO;
}

type Delivery = 'sent' | 'blocked' | 'failed' | 'throttled';

export async function deliver(userId: number, m: Outgoing): Promise<Delivery> {
  const reply_markup = m.button ? { inline_keyboard: [[{ text: m.button.text, web_app: { url: appLink(m.button.open) } }]] } : undefined;
  const r = m.photo
    ? await botCall('sendPhoto', { chat_id: userId, photo: absolute(m.photo), caption: m.html, parse_mode: 'HTML', reply_markup })
    : await botCall('sendMessage', { chat_id: userId, text: m.html, parse_mode: 'HTML', reply_markup, disable_web_page_preview: true });
  if (r instanceof BotRefusal) {
    if (r.code === 429) return 'throttled';
    if (r.unreachable) {
      await q('UPDATE users SET bot_blocked_at = now() WHERE id = $1', [userId]);
      return 'blocked';
    }
    return 'failed';
  }
  // No answer at all (Telegram down, or the Worker's subrequests are spent): try this player again next tick.
  return r ? 'sent' : 'throttled';
}

const pause = (ms: number) => new Promise((r) => setTimeout(r, ms));

interface Chunk {
  sent: number;
  failed: number;
  throttled: boolean;
  /** How many targets from the start of the batch are settled (everything before the first throttled one). */
  done: number;
}

/** Sends one small batch at once; Telegram's «slow down» stops the whole run. */
async function sendChunk(targets: { id: number; message: Outgoing }[]): Promise<Chunk> {
  const results = await Promise.all(targets.map((t) => deliver(t.id, t.message)));
  const first = results.indexOf('throttled');
  const settled = first < 0 ? results : results.slice(0, first);
  return { sent: settled.filter((r) => r === 'sent').length, failed: settled.filter((r) => r !== 'sent').length, throttled: first >= 0, done: settled.length };
}

// ---------- Broadcasts ----------

/**
 * Queues a message for every player. A newer broadcast of the same kind replaces an unfinished older one, unless
 * `replace` is off (admin announcements wait for each other).
 */
export async function queueBroadcast(c: Queryable, by: number, kind: string, m: Outgoing, replace = true) {
  if (replace) await c.query('UPDATE broadcasts SET finished_at = now() WHERE kind = $1 AND finished_at IS NULL', [kind]);
  await c.query('INSERT INTO broadcasts (kind, text, photo, button, created_by) VALUES ($1, $2, $3, $4::jsonb, $5)', [kind, m.html, m.photo ?? null, JSON.stringify(m.button ?? null), by]);
}

interface BroadcastRow {
  id: string;
  kind: string;
  text: string;
  photo: string | null;
  button: Outgoing['button'];
  last_user_id: string;
  sent: number;
  failed: number;
  created_at: string;
  finished_at: string | null;
}

/**
 * Continues the oldest unfinished broadcast in small batches, saving progress after each one (a killed run
 * repeats at most one batch). A lease keeps two overlapping ticks from sending the same batch.
 */
async function runBroadcast(budget: number, deadline: number): Promise<number> {
  const [b] = await q<BroadcastRow>(
    `UPDATE broadcasts SET lease_until = now() + interval '50 seconds'
     WHERE id = (SELECT id FROM broadcasts WHERE finished_at IS NULL AND (lease_until IS NULL OR lease_until < now()) ORDER BY id LIMIT 1 FOR UPDATE SKIP LOCKED)
     RETURNING *`,
  );
  if (!b) return 0;
  // «luck is on» must not reach anyone after the event ended or was switched off.
  if (b.kind === 'luck' && !luckState(await getSettings())) {
    await q('UPDATE broadcasts SET finished_at = now(), lease_until = NULL WHERE id = $1', [b.id]);
    return 0;
  }
  const message: Outgoing = { html: b.text, photo: b.photo, button: b.button };
  let cursor = num(b.last_user_id);
  let used = 0;
  try {
    while (used < budget && Date.now() < deadline) {
      const users = await q<{ id: string }>('SELECT id FROM users WHERE id > $1 AND bot_blocked_at IS NULL ORDER BY id LIMIT $2', [cursor, Math.min(CHUNK, budget - used)]);
      if (!users.length) {
        await q('UPDATE broadcasts SET finished_at = now() WHERE id = $1', [b.id]);
        break;
      }
      const r = await sendChunk(users.map((u) => ({ id: num(u.id), message })));
      used += users.length;
      // A throttled player is retried next tick: the cursor stops right before them.
      if (r.done) cursor = num(users[r.done - 1]!.id);
      await q('UPDATE broadcasts SET last_user_id = $2, sent = sent + $3, failed = failed + $4 WHERE id = $1', [b.id, cursor, r.sent, r.failed]);
      if (r.throttled) break;
      await pause(CHUNK_PAUSE_MS);
    }
  } finally {
    await q('UPDATE broadcasts SET lease_until = NULL WHERE id = $1', [b.id]);
  }
  return used;
}

export async function recentBroadcasts() {
  const [rows, total] = await Promise.all([
    q<BroadcastRow>('SELECT * FROM broadcasts ORDER BY id DESC LIMIT 8'),
    q<{ n: string }>('SELECT count(*) AS n FROM users WHERE bot_blocked_at IS NULL'),
  ]);
  return {
    reachable: num(total[0]?.n),
    /** Messages a minute: what the tick sends at most. */
    perMinute: TICK_BUDGET,
    list: rows.map((r) => ({
      id: num(r.id),
      kind: r.kind,
      text: r.text
        .replace(/<[^>]+>/g, '')
        .replace(/&lt;/g, '<')
        .replace(/&gt;/g, '>')
        .replace(/&quot;/g, '"')
        .replace(/&amp;/g, '&')
        .slice(0, 140),
      photo: r.photo,
      sent: r.sent,
      failed: r.failed,
      done: !!r.finished_at,
      at: new Date(r.created_at).getTime(),
    })),
  };
}

/** Stops an unfinished broadcast where it is (players already reached keep their message). */
export async function stopBroadcast(id: number): Promise<boolean> {
  const rows = await q('UPDATE broadcasts SET finished_at = now() WHERE id = $1 AND finished_at IS NULL RETURNING id', [id]);
  return rows.length > 0;
}

// ---------- Admin announcements ----------

/** Where an announcement button may open the app (deep links of src/lib/router.ts; '' is the home page). */
export const ANNOUNCE_OPEN = ['', 'case/free', 'giveaways', 'mines', 'road', 'fuse', 'upgrader', 'battle', 'bonuses', 'quests', 'ranks', 'referrals', 'profile'] as const;
/** Telegram's limits: a photo caption and a plain message. */
export const CAPTION_MAX = 1024;
export const MESSAGE_MAX = 4096;

/** The admin's plain text as Telegram HTML: everything escaped, **bold**, __italic__ and ||spoiler|| kept. */
export function announceHtml(text: string): string {
  return escapeHtml(text.trim())
    .replace(/\*\*([^*]+?)\*\*/g, '<b>$1</b>')
    .replace(/__([^_]+?)__/g, '<i>$1</i>')
    .replace(/\|\|([^|]+?)\|\|/g, '<tg-spoiler>$1</tg-spoiler>');
}

// ---------- Reminders ----------

const pick = <T>(list: readonly T[], seed: number) => list[Math.abs(seed) % list.length]!;
const dayNumber = () => Math.floor(Date.now() / 86_400_000);

/** The «free case ready» message: the owner's banner (public/promo/free-case.jpg) and the same words as on it. */
const FREE_TEXT =
  '🎁 <b>{name}, бесплатный кейс готов!</b>\nЗабирай брейнрота — открытие ничего не стоит.\nНовый бесплатный кейс — каждые 12 часов ⏰';
const FREE_PHOTO = promo('free-case.jpg');

const COMEBACK_TEXTS = [
  '😢 <b>{name}, ты куда пропал?</b>\nБрейнроты без тебя скучают, а бесплатный кейс пылится уже который день…',
  '🥺 <b>Мы тут, вообще-то, ждём.</b>\nТри дня без тебя — кейсы грустят, батлы без соперника. Вернёшься?',
  '💔 <b>Ну и ладно… мы не обиделись. Почти.</b>\n{name}, бесплатный кейс всё ещё твой — заходи, пока не передумали 😏',
];

const firstName = (name: string) => escapeHtml((name || 'Игрок').split(/\s+/)[0]!.slice(0, 32));

type Claim = (limit: number) => Promise<{ id: string; first_name: string }[]>;

/**
 * Claims a few players at a time (marking them first, so overlapping ticks never double-send), messages
 * them, and repeats until the budget or the deadline runs out.
 */
async function remind(claim: Claim, message: (row: { id: string; first_name: string }) => Outgoing, budget: number, deadline: number): Promise<number> {
  let reached = 0;
  while (reached < budget && Date.now() < deadline) {
    const rows = await claim(Math.min(CHUNK, budget - reached));
    if (!rows.length) break;
    const r = await sendChunk(rows.map((row) => ({ id: num(row.id), message: message(row) })));
    reached += rows.length;
    if (r.throttled) break;
    await pause(CHUNK_PAUSE_MS);
  }
  return reached;
}

/** «Бесплатный кейс готов»: once when the cooldown resets, then at most once a day while it stays unopened. */
const claimFreeReady: Claim = (limit) =>
  q(
    `UPDATE users SET free_notified_at = now() WHERE id IN (
       SELECT id FROM users
       WHERE bot_blocked_at IS NULL
         AND last_seen_at > now() - interval '${AWAY_DAYS} days'
         AND last_seen_at < now() - interval '15 minutes'
         AND (free_case_at IS NULL OR free_case_at <= now() - interval '12 hours')
         AND (free_notified_at IS NULL OR free_notified_at < now() - interval '24 hours'
              OR (free_case_at IS NOT NULL AND free_notified_at < free_case_at + interval '12 hours'))
       ORDER BY id LIMIT $1 FOR UPDATE SKIP LOCKED)
     RETURNING id, first_name`,
    [limit],
  );

/** Three days away → one teasing «where did you go?»; nothing more until they open the app again. */
const claimComeback: Claim = (limit) =>
  q(
    `UPDATE users SET comeback_sent_at = now() WHERE id IN (
       SELECT id FROM users
       WHERE bot_blocked_at IS NULL
         AND last_seen_at < now() - interval '${AWAY_DAYS} days'
         AND last_seen_at > now() - interval '30 days'
         AND (comeback_sent_at IS NULL OR comeback_sent_at < last_seen_at)
       ORDER BY id LIMIT $1 FOR UPDATE SKIP LOCKED)
     RETURNING id, first_name`,
    [limit],
  );

/** One tick of all bot notifications; returns how many players each job reached. */
export async function runNotifications(now = new Date(), deadline = Date.now() + 20_000) {
  const broadcast = await runBroadcast(TICK_BUDGET, deadline);
  if (isQuietHours(now)) return { broadcast, free: 0, comeback: 0, quiet: true };
  const day = dayNumber();
  const left = TICK_BUDGET - broadcast;
  const comeback = await remind(
    claimComeback,
    (r) => ({
      html: pick(COMEBACK_TEXTS, num(r.id) + day).replace('{name}', firstName(r.first_name)),
      photo: promo('comeback.jpg'),
      button: { text: '🙏 Ладно, вернусь', open: 'case/free' },
    }),
    Math.min(60, left),
    deadline,
  );
  const free = await remind(
    claimFreeReady,
    (r) => ({
      html: FREE_TEXT.replace('{name}', firstName(r.first_name)),
      photo: FREE_PHOTO,
      button: { text: '🎁 Открыть бесплатный кейс', open: 'case/free' },
    }),
    left - comeback,
    deadline,
  );
  return { broadcast, free, comeback, quiet: false };
}

// ---------- x2 luck ----------

const duration = (minutes: number) => {
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  return [h && `${h} ч`, m && `${m} мин`].filter(Boolean).join(' ');
};

export const luckBroadcast = (minutes: number, x = 2): Outgoing => ({
  html: `🍀 <b>x${x} УДАЧА ВКЛЮЧЕНА!</b>\nСледующие ${duration(minutes)} шанс окупа во всех кейсах и батлах ${x === 2 ? 'удвоен' : `×${x}`}.\nУспей открыть кейсы, пока горит таймер ⏳`,
  photo: promo('luck.jpg'),
  button: { text: `🍀 Крутить с x${x} удачей` },
});
