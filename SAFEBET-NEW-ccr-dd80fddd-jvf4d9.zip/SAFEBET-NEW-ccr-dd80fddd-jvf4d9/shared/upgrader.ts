import type { Brainrot } from './types';
import { secureRandom, type Rng } from './random';

/** The smallest stake an upgrade takes, in B (the owner: «апгрейдить от 10»). */
export const MIN_UPGRADE_STAKE = 10;

/**
 * The best chance an upgrade may have: the target costs at least stake × UPGRADE_RTP / 0.75 (the owner took it down to
 * 50 % in iteration 38 and back to 75 % the same day; the 20 % commission stayed).
 */
export const MAX_UPGRADE_CHANCE = 0.75;

/**
 * What an upgrade pays back on average: its chance is the stake/target price ratio times this, so the house keeps
 * 20 % (iteration 38; 12 % before). The chance on the ring IS the chance the server rolls — the commission makes the
 * green sector smaller, it is never a hidden number.
 */
export const UPGRADE_RTP = 0.8;

export function upgradeChance(inputPrice: number, targetPrice: number): number {
  if (targetPrice <= 0) return 0;
  return Math.min(1, (inputPrice / targetPrice) * UPGRADE_RTP);
}

/** Brainrots an upgrade of `inputPrice` may aim at: dear enough for a chance of at most MAX_UPGRADE_CHANCE. */
export function upgradeTargets(inputPrice: number, catalog: readonly Brainrot[]): Brainrot[] {
  return catalog.filter((b) => b.status === 'active' && b.price > inputPrice && upgradeChance(inputPrice, b.price) <= MAX_UPGRADE_CHANCE).sort((a, b) => a.price - b.price);
}

/** Target whose price is closest (by ratio) to the desired price. */
export function closestTarget(inputPrice: number, desiredPrice: number, catalog: readonly Brainrot[]): Brainrot | null {
  let best: Brainrot | null = null;
  let bestDiff = Infinity;
  for (const b of upgradeTargets(inputPrice, catalog)) {
    const diff = Math.abs(Math.log(b.price / desiredPrice));
    if (diff < bestDiff) {
      best = b;
      bestDiff = diff;
    }
  }
  return best;
}

export function targetForMultiplier(inputPrice: number, multiplier: number, catalog: readonly Brainrot[]) {
  return closestTarget(inputPrice, inputPrice * multiplier, catalog);
}

export function targetForChance(inputPrice: number, chance: number, catalog: readonly Brainrot[]) {
  return closestTarget(inputPrice, (inputPrice * UPGRADE_RTP) / chance, catalog);
}

export function rollUpgrade(chance: number, rng: Rng = secureRandom): { roll: number; win: boolean } {
  const roll = rng();
  return { roll, win: roll < chance };
}

/** Pointer angle (0° = top, clockwise) for a roll, kept off the exact win/lose boundary so the result reads clearly. */
export function pointerAngle(roll: number, chance: number): number {
  const pad = 2;
  const edge = chance * 360;
  const angle = roll * 360;
  if (roll < chance) {
    return clamp(angle, Math.min(pad, edge / 2), Math.max(edge - pad, edge / 2));
  }
  return clamp(angle, Math.min(edge + pad, (edge + 360) / 2), Math.max(360 - pad, (edge + 360) / 2));
}

function clamp(v: number, min: number, max: number) {
  return Math.min(max, Math.max(min, v));
}
