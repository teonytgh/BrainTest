import { useQuery } from '@tanstack/react-query';
import { useEffect, useRef, useState } from 'react';
import { BrainrotThumb } from '../components/BrainrotCard';
import { Coin } from '../components/Coin';
import { Burst, Confetti, CountUp } from '../components/Fx';
import { Icon } from '../components/Icon';
import type { InventoryItem } from '../components/InventoryGrid';
import { StakeSheet } from '../components/StakeSheet';
import { ApiError, api, errorMessage } from '../api/client';
import { act, queryClient, setMe, useCatalog, useMe, type Me } from '../api/queries';
import { floor2, round2 } from '../../shared/money';
import {
  MAX_MINES,
  MAX_MINES_ITEMS,
  MAX_MINES_MULT,
  MAX_MINES_PAYOUT,
  MINES_PRESETS,
  MINES_TILES,
  MIN_MINES,
  MIN_MINES_STAKE,
  minesFromDigests,
  minesMessage,
  minesMultiplier,
  nextPickProblem,
  type MinesRun,
  type MinesState,
} from '../../shared/mines';
import { cx, formatCoins } from '../lib/format';
import { sha256Hex } from '../lib/halloween';
import { sfx } from '../lib/sound';
import { haptic } from '../lib/telegram';
import { tierOf } from '../lib/tier';
import { toast } from '../store/toast';
import { MIXED_DEMO, mixesDemo } from '../lib/demo';

const STATE_KEY = ['mines'] as const;
const MEDALS = ['🥇', '🥈', '🥉'];
const mult = (x: number) => `x${x.toFixed(2)}`;
const TILES = Array.from({ length: MINES_TILES }, (_, i) => i);

type Fx = { kind: 'boom' | 'win'; key: number } | null;

/** A cartoon bomb, coloured by the palette. */
function Bomb() {
  return (
    <svg className="mn-bomb" viewBox="0 0 48 48" aria-hidden="true">
      <circle cx="22" cy="28" r="14" />
      <rect x="27" y="10" width="8" height="8" rx="2" transform="rotate(35 31 14)" />
      <path className="mn-bomb__fuse" d="M33 11c2-4 6-6 9-4" />
      <circle className="mn-bomb__spark" cx="42" cy="7" r="3" />
      <circle className="mn-bomb__shine" cx="16" cy="22" r="3.5" />
    </svg>
  );
}

/** «Мины»: a 5×5 field on brainrot stakes — open clear tiles to raise the multiplier, a mine burns the stake. */
export function Mines() {
  const me = useMe();
  const catalog = useCatalog();
  const state = useQuery({ queryKey: STATE_KEY, queryFn: () => api<MinesState>('/api/mines'), staleTime: 30_000 });
  const [mines, setMines] = useState(3);
  const [picked, setPicked] = useState<number[]>([]);
  const [sheet, setSheet] = useState(false);
  const [pending, setPending] = useState<number | 'start' | 'cash' | null>(null);
  /** The round on screen: the active one, or the one that just ended (until «Новый раунд»). */
  const [run, setRun] = useState<MinesRun | null>(null);
  const [fx, setFx] = useState<Fx>(null);
  const [verified, setVerified] = useState<boolean | null>(null);
  const unapplied = useRef<Me | null>(null);

  useEffect(
    () => () => {
      if (unapplied.current) setMe(unapplied.current);
    },
    [],
  );

  // A round left open (another device, a closed app) comes back as it was.
  const serverRun = state.data?.run ?? null;
  useEffect(() => {
    if (serverRun && (!run || run.id !== serverRun.id)) {
      setRun(serverRun);
      setMines(serverRun.mines);
    }
  }, [serverRun]); // eslint-disable-line react-hooks/exhaustive-deps

  // Provably fair: the revealed key hashes to what was shown, and the mines follow from it.
  useEffect(() => {
    if (!run?.seed || !run.minesAt) return;
    let alive = true;
    const { seed, minesAt, hash } = run;
    Promise.all([sha256Hex(seed), ...Array.from({ length: run.mines }, (_, i) => sha256Hex(minesMessage(seed, i)))])
      .then(([h, ...digests]) => {
        const field = minesFromDigests(run.mines, digests);
        if (alive) setVerified(h === hash && field.length === minesAt.length && field.every((t, i) => t === minesAt[i]));
      })
      .catch(() => {});
    return () => {
      alive = false;
    };
  }, [run]);

  const frozen = !!me.user.frozen;
  const active = run?.status === 'active';
  const over = !!run && !active;
  const busy = pending !== null;
  const count = run?.mines ?? mines;
  const pickedItems = picked.flatMap((id) => {
    const item = me.inventory.find((i) => i.id === id && !i.withdrawalId);
    const b = item ? catalog.byId.get(item.brainrotId) : undefined;
    return item && b ? [{ item, b }] : [];
  });
  const stakeValue = run ? run.stakeValue : round2(pickedItems.reduce((s, p) => s + p.b.price, 0));
  const opened = run?.picks.length ?? 0;
  const nowWin = floor2(stakeValue * minesMultiplier(count, opened));
  const nextMult = minesMultiplier(count, opened + 1);
  const problem = active ? run.next.problem : null;
  const nextRisk = count / (MINES_TILES - opened);

  const startProblem = frozen
    ? 'Аккаунт заморожен — играть нельзя'
    : stakeValue < MIN_MINES_STAKE
      ? 'Выбери брейнротов в ставку'
      : nextPickProblem(count, 0, stakeValue)
        ? `Ставка слишком большая: выигрыш до ${formatCoins(MAX_MINES_PAYOUT)} B`
        : null;

  function toggle(item: InventoryItem) {
    if (picked.includes(item.id)) {
      sfx.tap();
      setPicked((list) => list.filter((id) => id !== item.id));
      return;
    }
    if (mixesDemo(pickedItems.map((p) => p.item), item)) {
      sfx.error();
      toast(MIXED_DEMO);
      return;
    }
    if (pickedItems.length >= MAX_MINES_ITEMS) {
      sfx.error();
      toast(`В ставку — до ${MAX_MINES_ITEMS} брейнротов`);
      return;
    }
    sfx.tap();
    setPicked((list) => [...list.filter((id) => pickedItems.some((p) => p.item.id === id)), item.id]);
  }

  function setCount(n: number) {
    if (active || busy) return;
    if (over) reset();
    sfx.tap();
    setMines(Math.max(MIN_MINES, Math.min(MAX_MINES, n)));
  }

  function reset() {
    setRun(null);
    setFx(null);
    setVerified(null);
  }

  function onError(e: unknown) {
    sfx.error();
    toast(errorMessage(e), 'error');
    if (e instanceof ApiError && ['no_run', 'run_active', 'limit', 'taken'].includes(e.code)) void queryClient.invalidateQueries({ queryKey: STATE_KEY });
  }

  async function start() {
    if (busy || startProblem || active) return;
    setPending('start');
    try {
      const r = await act<{ run: MinesRun; nextHash: string }>('/api/mines/start', { mines, itemIds: pickedItems.map((p) => p.item.id) });
      setMe(r.me);
      setPicked([]);
      setFx(null);
      setVerified(null);
      setRun(r.result.run);
      sfx.press();
      haptic('tap');
      queryClient.setQueryData<MinesState>(STATE_KEY, (old) => (old ? { ...old, nextHash: r.result.nextHash, run: r.result.run } : old));
    } catch (e) {
      onError(e);
    } finally {
      setPending(null);
    }
  }

  async function pick(tile: number) {
    if (busy || !active || problem || run.picks.includes(tile)) return;
    setPending(tile);
    sfx.tap();
    try {
      const r = await act<{ run: MinesRun; busted: boolean }>('/api/mines/pick', { tile });
      const next = r.result.run;
      setRun(next);
      if (r.result.busted) {
        setFx({ kind: 'boom', key: Date.now() });
        sfx.boom();
        sfx.lose();
        haptic('error');
        setMe(r.me);
        finish(next);
      } else if (next.status === 'cashed') {
        // Nothing more to open (or the limit): the win is taken by itself.
        won(next, r.me);
      } else {
        sfx.coin();
        haptic('tap');
        setMe(r.me);
      }
    } catch (e) {
      onError(e);
    } finally {
      setPending(null);
    }
  }

  function pickRandom() {
    if (!active) return;
    const free = TILES.filter((t) => !run.picks.includes(t));
    void pick(free[Math.floor(Math.random() * free.length)]!);
  }

  async function cashout() {
    if (busy || !active || opened < 1) return;
    setPending('cash');
    try {
      const r = await act<{ run: MinesRun }>('/api/mines/cashout');
      won(r.result.run, r.me);
    } catch (e) {
      onError(e);
    } finally {
      setPending(null);
    }
  }

  function won(r: MinesRun, fresh: Me) {
    setRun(r);
    setMe(fresh);
    setFx({ kind: 'win', key: Date.now() });
    const prize = r.payout?.brainrotId ? catalog.byId.get(r.payout.brainrotId) : null;
    if (r.multiplier >= 10 || (prize && ['legendary', 'secret'].includes(tierOf(prize.price)))) sfx.bigWin();
    else sfx.cashout();
    haptic('success');
    finish(r);
  }

  function finish(r: MinesRun) {
    queryClient.setQueryData<MinesState>(STATE_KEY, (old) =>
      old
        ? {
            ...old,
            run: null,
            mine: [
              { mines: r.mines, picks: r.picks.length, won: r.status === 'cashed', multiplier: r.status === 'cashed' ? r.multiplier : 0, value: r.payout?.value ?? 0, stakeValue: r.stakeValue, at: Date.now() },
              ...old.mine,
            ].slice(0, 12),
          }
        : old,
    );
    if (r.status === 'cashed') void queryClient.invalidateQueries({ queryKey: STATE_KEY });
  }

  const prize = over && run.payout?.brainrotId ? catalog.byId.get(run.payout.brainrotId) ?? null : null;
  const big = over && run.status === 'cashed' && (run.multiplier >= 10 || (!!prize && ['legendary', 'secret'].includes(tierOf(prize.price))));
  const top = state.data?.top ?? [];
  const mine = state.data?.mine ?? [];

  return (
    <section className="game mn" aria-labelledby="mn-title">
      <div className="road-head">
        <h1 id="mn-title" className="page-title">
          Мины
        </h1>
        <span className="road-head__tag">
          <Icon name="bolt" size={14} /> 5×5 · до x{MAX_MINES_MULT}
        </span>
      </div>

      <div className="mn-count" role="group" aria-label="Сколько мин">
        <div className="segmented mn-count__presets">
          {MINES_PRESETS.map((n) => (
            <button key={n} type="button" className={cx('segmented__opt', count === n && 'is-on')} onClick={() => setCount(n)} disabled={active || busy} aria-pressed={count === n}>
              {n}
            </button>
          ))}
        </div>
        <div className="mn-count__step">
          <button type="button" className="icon-btn" onClick={() => setCount(count - 1)} disabled={active || busy || count <= MIN_MINES} aria-label="Меньше мин">
            −
          </button>
          <span>
            <b>{count}</b> {count === 1 ? 'мина' : count < 5 ? 'мины' : 'мин'}
          </span>
          <button type="button" className="icon-btn" onClick={() => setCount(count + 1)} disabled={active || busy || count >= MAX_MINES} aria-label="Больше мин">
            +
          </button>
        </div>
      </div>

      <div className={cx('mn-field', active && 'is-live', fx?.kind === 'boom' && 'is-boom', over && run.status === 'cashed' && 'is-won')} key={fx?.kind === 'boom' ? fx.key : 'field'}>
        <div className="mn-grid" role="grid" aria-label="Поле">
          {TILES.map((t) => {
            const open = !!run?.picks.includes(t);
            const isMine = !!run?.minesAt?.includes(t);
            const bust = run?.bust === t;
            const shown = open || (over && run.minesAt !== null);
            return (
              <button
                key={t}
                type="button"
                role="gridcell"
                className={cx('mn-tile', open && 'is-open', shown && !open && 'is-revealed', isMine && 'is-mine', bust && 'is-bust', pending === t && 'is-pending')}
                onClick={() => void pick(t)}
                disabled={!active || open || busy || !!problem}
                aria-label={open ? 'Открыто: чисто' : bust ? 'Мина' : shown ? (isMine ? 'Мина' : 'Чисто') : `Клетка ${t + 1}`}
              >
                {shown && (isMine ? <Bomb /> : <img className="mn-gem coin" src="/coin-256.webp" alt="" draggable={false} />)}
                {bust && fx?.kind === 'boom' && <span key={fx.key} className="mn-blast" aria-hidden="true" />}
              </button>
            );
          })}
        </div>

        {over && run.status === 'cashed' && (
          <button type="button" className="road-result is-won" onClick={reset}>
            {fx?.kind === 'win' && <Burst key={fx.key} count={26} spread={0.8} />}
            <span className="road-result__title">Забрал {mult(run.multiplier)}</span>
            {prize && <img className="road-result__img" src={prize.image} alt="" />}
            <span className="road-result__name">{prize?.name ?? 'Монеты'}</span>
            {(run.payout?.coins ?? 0) > 0 && (
              <span className="road-result__coins">
                +<CountUp to={run.payout!.coins} format={formatCoins} /> <Coin size={16} />
              </span>
            )}
            <span className="road-result__hint">Нажми — новый раунд</span>
          </button>
        )}
      </div>

      <dl className="up-summary road-summary">
        <div>
          <dt>Сейчас</dt>
          <dd className="is-green">
            {active && opened > 0 ? (
              <>
                <Coin size={12} /> {formatCoins(nowWin)}
              </>
            ) : (
              '—'
            )}
          </dd>
        </div>
        <div>
          <dt>Дальше</dt>
          <dd className="is-gold">{!over && opened < MINES_TILES - count ? mult(nextMult) : '—'}</dd>
        </div>
        <div>
          <dt>Мина в клетке</dt>
          <dd className="is-red">{!over ? `${Math.round(nextRisk * 100)}%` : '—'}</dd>
        </div>
      </dl>

      <div className="bet-panel road-panel">
        {active ? (
          <div className="road-actions">
            <button type="button" className="btn btn--lg road-cash mn-cash" disabled={busy || opened < 1} onClick={cashout}>
              <span>
                Забрать
                <small>{opened < 1 ? 'после 1-й клетки' : `${formatCoins(nowWin)} B · ${mult(minesMultiplier(count, opened))}`}</small>
              </span>
            </button>
            <button type="button" className="btn btn--ghost btn--lg" disabled={busy || !!problem} onClick={pickRandom}>
              <span>
                Случайная
                <small>{problem === 'limit' ? 'лимит' : `→ ${mult(nextMult)}`}</small>
              </span>
            </button>
          </div>
        ) : (
          <>
            <button type="button" className="select select--wide hw-stake" onClick={() => setSheet(true)} disabled={busy || frozen}>
              {pickedItems.length ? (
                <>
                  <span className="hw-stake__thumbs">
                    {pickedItems.map((p) => (
                      <BrainrotThumb key={p.item.id} brainrot={p.b} size={30} />
                    ))}
                  </span>
                  <span className="select__text">{pickedItems.length === 1 ? pickedItems[0]!.b.name : `${pickedItems.length} брейнрота`}</span>
                  <span className="select__price">
                    <Coin size={13} /> {formatCoins(stakeValue)}
                  </span>
                </>
              ) : (
                <span className="select__text">Брейнроты в ставку (до {MAX_MINES_ITEMS})</span>
              )}
              <Icon name="chevronDown" size={18} />
            </button>
            {over ? (
              <button type="button" className="btn btn--primary btn--lg btn--block" onClick={reset}>
                <Icon name="reset" size={20} /> Новый раунд
              </button>
            ) : (
              <button type="button" className="btn btn--primary btn--lg btn--block" disabled={!!startProblem || busy} onClick={start}>
                {pending === 'start' ? 'Секунду…' : (startProblem ?? `Играть · ${formatCoins(stakeValue)} B`)}
              </button>
            )}
          </>
        )}
        <p className="hint hint--left">
          Выбери, сколько мин спрятано на поле 5×5, и открывай клетки. Каждая чистая клетка поднимает множитель, мина — ставка сгорает. Забрать
          выигрыш можно после любой клетки: самый дорогой брейнрот, который влезает в ставку × множитель, и сдача монетами. Больше мин — быстрее
          растёт множитель. Ставка — только брейнроты (до {MAX_MINES_ITEMS}), выигрыш — до {formatCoins(MAX_MINES_PAYOUT)} B, множитель — до x
          {MAX_MINES_MULT}. Брошенный раунд через 30 минут закрывается сам.
        </p>
      </div>

      <p className="road-fair">
        <Icon name="shield" size={14} /> Честная игра ·{' '}
        {active ? (
          <>
            ключ раунда: хэш <code>{run.hash.slice(0, 12)}…</code>
          </>
        ) : (
          <>
            следующий раунд: хэш <code>{(state.data?.nextHash ?? '').slice(0, 12)}…</code>
          </>
        )}
        {over && run.seed && (
          <>
            {' '}
            · ключ прошлого <code>{run.seed.slice(0, 8)}…</code> {verified === true && <span className="road-fair__ok">совпадает ✓</span>}
            {verified === false && <span className="road-fair__bad">не совпадает</span>}
          </>
        )}
      </p>

      {mine.length > 0 && (
        <div className="history" aria-label="Мои раунды">
          {mine.map((m, i) => (
            <span key={`${m.at}-${i}`} className={cx('history__chip', m.multiplier >= 1 ? 'is-high' : 'is-low')} title={`${m.mines} мин · ${m.picks} клеток`}>
              {m.won ? mult(m.multiplier) : '💥'}
            </span>
          ))}
        </div>
      )}

      <section className="panel hw-top" aria-labelledby="mn-top-title">
        <h2 id="mn-top-title" className="panel__title">
          Лучшие раунды
        </h2>
        {top.length === 0 ? (
          <p className="hint hint--left">Пока никто не забрал выигрыш. Будь первым!</p>
        ) : (
          <ol className="hw-top__list">
            {top.map((t, i) => {
              const b = t.brainrotId ? catalog.byId.get(t.brainrotId) : null;
              return (
                <li key={`${t.at}-${i}`} className={cx('hw-top__row', i < 3 && 'is-podium')}>
                  <span className="hw-top__rank">{MEDALS[i] ?? i + 1}</span>
                  <span className="hw-top__who">
                    <b>{t.name}</b>
                    <small>
                      {t.mines} мин · {t.picks} клеток · {mult(t.multiplier)}
                    </small>
                  </span>
                  {b && <BrainrotThumb brainrot={b} size={30} />}
                  <span className="hw-top__value">
                    <Coin size={13} /> {formatCoins(t.value)}
                  </span>
                </li>
              );
            })}
          </ol>
        )}
      </section>

      <StakeSheet open={sheet} onClose={() => setSheet(false)} picked={pickedItems.map((p) => p.item.id)} max={MAX_MINES_ITEMS} onToggle={toggle} />
      {big && fx && <Confetti key={fx.key} count={70} />}
    </section>
  );
}
