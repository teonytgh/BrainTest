import { useEffect, useMemo, useState, type CSSProperties } from 'react';
import { cx } from '../lib/format';

const rand = (min: number, max: number) => min + Math.random() * (max - min);

/** Sparks flying out of a point (the parent positions it); they fade by themselves. */
export function Burst({ count = 26, className, spread = 1 }: { count?: number; className?: string; spread?: number }) {
  const sparks = useMemo(
    () =>
      Array.from({ length: count }, (_, i) => ({
        '--a': `${(360 / count) * i + rand(-8, 8)}deg`,
        '--d': `${rand(70, 170) * spread}px`,
        '--s': `${rand(4, 10)}px`,
        '--delay': `${rand(0, 90)}ms`,
        '--dur': `${rand(550, 950)}ms`,
      })),
    [count, spread],
  );
  return (
    <span className={cx('fx-burst', className)} aria-hidden="true">
      {sparks.map((s, i) => (
        <i key={i} style={s as CSSProperties} />
      ))}
    </span>
  );
}

/** Confetti over the whole screen for the big drops. */
export function Confetti({ count = 42 }: { count?: number }) {
  const [alive, setAlive] = useState(true);
  const pieces = useMemo(
    () =>
      Array.from({ length: count }, () => ({
        '--x': `${rand(0, 100)}vw`,
        '--drift': `${rand(-18, 18)}vw`,
        '--r': `${rand(360, 1080) * (Math.random() < 0.5 ? -1 : 1)}deg`,
        '--delay': `${rand(0, 600)}ms`,
        '--dur': `${rand(1800, 3000)}ms`,
        '--hue': `${Math.floor(rand(0, 6))}`,
      })),
    [count],
  );
  useEffect(() => {
    const t = setTimeout(() => setAlive(false), 3800);
    return () => clearTimeout(t);
  }, []);
  if (!alive) return null;
  return (
    <span className="fx-confetti" aria-hidden="true">
      {pieces.map((p, i) => (
        <i key={i} style={p as CSSProperties} />
      ))}
    </span>
  );
}

/** Little four-point stars twinkling around something precious. */
export function Twinkles({ count = 10 }: { count?: number }) {
  const stars = useMemo(
    () =>
      Array.from({ length: count }, () => ({
        '--x': `${rand(4, 96)}%`,
        '--y': `${rand(4, 90)}%`,
        '--s': `${rand(8, 16)}px`,
        '--delay': `${rand(0, 2400)}ms`,
      })),
    [count],
  );
  return (
    <span className="fx-twinkles" aria-hidden="true">
      {stars.map((s, i) => (
        <i key={i} style={s as CSSProperties} />
      ))}
    </span>
  );
}

/** A number that counts up to `to` (prices on the win card). */
export function CountUp({ to, ms = 700, format }: { to: number; ms?: number; format: (n: number) => string }) {
  const [value, setValue] = useState(0);
  useEffect(() => {
    let frame = 0;
    const start = performance.now();
    const loop = (now: number) => {
      const k = Math.min(1, (now - start) / ms);
      setValue(to * (1 - (1 - k) ** 3));
      if (k < 1) frame = requestAnimationFrame(loop);
    };
    frame = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(frame);
  }, [to, ms]);
  return <>{format(Math.round(value * 100) / 100)}</>;
}

/**
 * Cracked glass: jagged lines from the centre that draw themselves (a lost upgrade, a broken stake).
 * `seed` keeps the same pattern for the same thing.
 */
export function Crack({ seed = 1, className }: { seed?: number; className?: string }) {
  const paths = useMemo(() => {
    let x = seed * 9301 + 49297;
    const r = () => ((x = (x * 9301 + 49297) % 233280) / 233280);
    return Array.from({ length: 7 }, (_, i) => {
      const a0 = (Math.PI * 2 * i) / 7 + r() * 0.6;
      let px = 50;
      let py = 50;
      let d = `M50 50`;
      let a = a0;
      for (let k = 0; k < 4; k++) {
        const len = 9 + r() * 9;
        a += (r() - 0.5) * 0.9;
        px += Math.cos(a) * len;
        py += Math.sin(a) * len;
        d += ` L${px.toFixed(1)} ${py.toFixed(1)}`;
      }
      return d;
    });
  }, [seed]);
  return (
    <svg className={cx('fx-crack', className)} viewBox="0 0 100 100" aria-hidden="true" preserveAspectRatio="none">
      <circle cx="50" cy="50" r="6" />
      {paths.map((d, i) => (
        <path key={i} d={d} pathLength={1} style={{ '--i': i } as CSSProperties} />
      ))}
    </svg>
  );
}
