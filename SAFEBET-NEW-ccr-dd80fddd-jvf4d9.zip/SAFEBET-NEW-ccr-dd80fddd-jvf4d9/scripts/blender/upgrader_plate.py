"""The Halloween upgrader: a stone ritual circle under the chance ring and a witch's wand for the needle.

    blender -b --factory-startup --python scripts/blender/upgrader_plate.py -- public/upgrader [--quick]

Top-down orthographic renders (WebP, alpha), so the circles line up with the CSS ring:
  plate.webp  the stone circle filling the ring's box: a groove for the chance arc (radius 0.60–0.86 of the half
              size), glowing runes on the rim, a cauldron of green potion in the middle, jack-o'-lanterns and
              candles in the corners
  wand.webp   the needle: a crooked wand pointing up with a glowing crystal at the tip
"""
import math
import os
import random
import sys

import bpy
from mathutils import Euler, Vector

ARGS = sys.argv[sys.argv.index('--') + 1:] if '--' in sys.argv else []
POSITIONAL = [a for a in ARGS if not a.startswith('--')]
OUT = os.path.abspath(POSITIONAL[0] if POSITIONAL else 'public/upgrader')
QUICK = '--quick' in ARGS
SIZE = 360 if QUICK else 768
SAMPLES = 24 if QUICK else 128
random.seed(31)


def lin(c):
    def ch(v):
        v /= 255
        return v / 12.92 if v <= 0.04045 else ((v + 0.055) / 1.055) ** 2.4
    return (ch(c[0]), ch(c[1]), ch(c[2]), 1.0)


def material(name, rgb, emission=0.0, roughness=0.8, noise=0.0, metallic=0.0):
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    nt = m.node_tree
    bsdf = nt.nodes['Principled BSDF']
    bsdf.inputs['Base Color'].default_value = lin(rgb)
    bsdf.inputs['Roughness'].default_value = roughness
    bsdf.inputs['Metallic'].default_value = metallic
    if emission:
        bsdf.inputs['Emission Color'].default_value = lin(rgb)
        bsdf.inputs['Emission Strength'].default_value = emission
    if noise:
        # Rough stone: a noise texture drives a bump and darkens the base colour in the cracks.
        tex = nt.nodes.new('ShaderNodeTexNoise')
        tex.inputs['Scale'].default_value = 18
        tex.inputs['Detail'].default_value = 8
        bump = nt.nodes.new('ShaderNodeBump')
        bump.inputs['Strength'].default_value = noise
        nt.links.new(tex.outputs['Fac'], bump.inputs['Height'])
        nt.links.new(bump.outputs['Normal'], bsdf.inputs['Normal'])
        mix = nt.nodes.new('ShaderNodeMix')
        mix.data_type = 'RGBA'
        mix.inputs['A'].default_value = lin([v * 0.55 for v in rgb])
        mix.inputs['B'].default_value = lin(rgb)
        ramp = nt.nodes.new('ShaderNodeMapRange')
        ramp.inputs['From Min'].default_value = 0.35
        ramp.inputs['From Max'].default_value = 0.6
        nt.links.new(tex.outputs['Fac'], ramp.inputs['Value'])
        nt.links.new(ramp.outputs['Result'], mix.inputs['Factor'])
        nt.links.new(mix.outputs['Result'], bsdf.inputs['Base Color'])
    return m


def link(obj, mat=None):
    bpy.context.scene.collection.objects.link(obj)
    if mat:
        obj.data.materials.append(mat)
    return obj


def annulus(name, r_in, r_out, z0, z1, mat, segments=192):
    """A flat ring (a disc when r_in is 0) from z0 to z1."""
    verts, faces = [], []
    for k in range(segments):
        a = 2 * math.pi * k / segments
        c, s = math.cos(a), math.sin(a)
        verts += [(r_out * c, r_out * s, z0), (r_out * c, r_out * s, z1), (r_in * c, r_in * s, z1), (r_in * c, r_in * s, z0)]
    for k in range(segments):
        i, j = 4 * k, 4 * ((k + 1) % segments)
        faces += [(i, j, j + 1, i + 1), (i + 1, j + 1, j + 2, i + 2), (i + 2, j + 2, j + 3, i + 3), (i + 3, j + 3, j, i)]
    mesh = bpy.data.meshes.new(name)
    mesh.from_pydata(verts, [], faces)
    mesh.validate()
    for p in mesh.polygons:
        p.use_smooth = False
    return link(bpy.data.objects.new(name, mesh), mat)


def sphere(name, loc, scale, mat, segments=24, rings=16, rot=(0, 0, 0)):
    bpy.ops.mesh.primitive_uv_sphere_add(segments=segments, ring_count=rings, location=loc, rotation=rot)
    o = bpy.context.object
    o.name = name
    o.scale = scale
    bpy.ops.object.shade_smooth()
    o.data.materials.append(mat)
    return o


def cylinder(name, loc, radius, depth, mat, rot=(0, 0, 0), verts=24):
    bpy.ops.mesh.primitive_cylinder_add(vertices=verts, radius=radius, depth=depth, location=loc, rotation=rot)
    o = bpy.context.object
    o.name = name
    o.data.materials.append(mat)
    return o


for o in list(bpy.data.objects):
    bpy.data.objects.remove(o)
scene = bpy.context.scene

STONE = material('stone', (78, 70, 96), roughness=0.9, noise=0.35)
RIM = material('rim', (112, 102, 132), roughness=0.85, noise=0.3)
GROOVE = material('groove', (26, 20, 34), roughness=0.95, noise=0.15)
RUNE = material('rune', (190, 120, 255), emission=4.0)
IRON = material('iron', (40, 38, 46), roughness=0.45, metallic=0.8)
POTION = material('potion', (52, 150, 40), emission=0.45, roughness=0.2)
BUBBLE = material('bubble', (120, 230, 80), emission=1.0, roughness=0.1)
PUMPKIN = material('pumpkin', (238, 120, 24), roughness=0.55)
STEM = material('stem', (70, 96, 40), roughness=0.8)
FACE = material('face', (255, 190, 60), emission=6.0)
WAX = material('wax', (236, 226, 200), roughness=0.6)
FLAME = material('flame', (255, 170, 60), emission=12.0)

# ---------- The stone circle (R = 1 is the half size of the picture) ----------

annulus('rim', 0.86, 0.985, 0, 0.12, RIM)
annulus('groove', 0.60, 0.86, 0, 0.05, GROOVE)
annulus('inner', 0.0, 0.60, 0, 0.12, STONE)
annulus('lip', 0.975, 1.0, 0, 0.14, STONE)

# Runes on the rim between the CSS marks (0 / 25 / 50 / 75 sit at 0°, 90°, 180°, 270°).
for k in range(24):
    deg = k * 15
    if deg % 90 == 0:
        continue
    a = math.radians(90 - deg)
    r = 0.922
    x, y = r * math.cos(a), r * math.sin(a)
    if k % 2:
        sphere(f'rune{k}', (x, y, 0.125), (0.014, 0.014, 0.006), RUNE, 12, 8)
    else:
        bpy.ops.mesh.primitive_cube_add(size=1, location=(x, y, 0.125), rotation=(0, 0, a))
        o = bpy.context.object
        o.scale = (0.045, 0.01, 0.006)
        o.data.materials.append(RUNE)

# The cauldron: an iron lip around a pool of glowing potion with bubbles.
bpy.ops.mesh.primitive_torus_add(major_radius=0.5, minor_radius=0.055, major_segments=96, minor_segments=16, location=(0, 0, 0.16))
cauldron = bpy.context.object
bpy.ops.object.shade_smooth()
cauldron.data.materials.append(IRON)
cylinder('potion', (0, 0, 0.15), 0.47, 0.02, POTION, verts=96)
for _ in range(16):
    r = 0.42 * math.sqrt(random.random())
    a = random.random() * 2 * math.pi
    s = 0.012 + random.random() * 0.03
    sphere('bubble', (r * math.cos(a), r * math.sin(a), 0.165), (s, s, s * 0.6), BUBBLE, 16, 10)

# Jack-o'-lanterns in the corners, tilted to look at the circle, each with two candles.
def pumpkin(cx, cy):
    face_dir = Vector((-cx, -cy, 0)).normalized()
    tilt = Euler((0, 0, math.atan2(face_dir.y, face_dir.x) - math.pi / 2))
    for k in range(8):
        a = k * math.pi / 4
        off = Vector((math.cos(a) * 0.045, math.sin(a) * 0.045, 0))
        sphere('lobe', (cx + off.x, cy + off.y, 0.1), (0.075, 0.075, 0.085), PUMPKIN, 20, 12)
    cylinder('stem', (cx, cy, 0.2), 0.014, 0.05, STEM, rot=(0.3, 0.2, 0))
    # Carved face on the side that looks at the circle: two triangle eyes and a grin, glowing.
    for side in (-1, 1):
        p = Vector((cx, cy, 0.13)) + face_dir * 0.1 + Vector((-face_dir.y, face_dir.x, 0)) * 0.035 * side
        bpy.ops.mesh.primitive_cone_add(vertices=3, radius1=0.018, depth=0.01, location=p, rotation=(math.pi / 2, 0, tilt.z))
        bpy.context.object.data.materials.append(FACE)
    p = Vector((cx, cy, 0.085)) + face_dir * 0.105
    bpy.ops.mesh.primitive_cube_add(size=1, location=p, rotation=(0, 0, tilt.z))
    grin = bpy.context.object
    grin.scale = (0.07, 0.012, 0.016)
    grin.data.materials.append(FACE)
    side = Vector((-face_dir.y, face_dir.x, 0))
    for k, sgn in enumerate((-1, 1)):
        base = Vector((cx, cy, 0)) + side * 0.15 * sgn - face_dir * 0.02
        h = 0.07 + 0.03 * k
        cylinder('candle', (base.x, base.y, h / 2), 0.018, h, WAX, verts=16)
        sphere('flame', (base.x, base.y, h + 0.02), (0.012, 0.012, 0.024), FLAME, 12, 8)
        light = bpy.data.objects.new('candle_light', bpy.data.lights.new('candle_light', 'POINT'))
        light.data.energy = 6
        light.data.color = (1.0, 0.6, 0.25)
        light.data.shadow_soft_size = 0.02
        light.location = (base.x, base.y, h + 0.06)
        link(light)


for sx in (-1, 1):
    for sy in (-1, 1):
        pumpkin(0.83 * sx, 0.83 * sy)

# ---------- Camera, lights, render ----------

cam = bpy.data.objects.new('cam', bpy.data.cameras.new('cam'))
cam.data.type = 'ORTHO'
cam.data.ortho_scale = 2.0
cam.location = (0, 0, 5)
link(cam)
scene.camera = cam

moon = bpy.data.objects.new('moon', bpy.data.lights.new('moon', 'SUN'))
moon.data.energy = 2.2
moon.data.color = (0.78, 0.8, 1.0)
moon.rotation_euler = (math.radians(38), 0, math.radians(-40))
link(moon)
glow = bpy.data.objects.new('potion_light', bpy.data.lights.new('potion_light', 'POINT'))
glow.data.energy = 8
glow.data.color = (0.5, 1.0, 0.35)
glow.location = (0, 0, 0.35)
link(glow)
world = bpy.data.worlds.new('night')
world.use_nodes = True
world.node_tree.nodes['Background'].inputs['Color'].default_value = (0.04, 0.03, 0.07, 1)
scene.world = world

scene.render.engine = 'CYCLES'
scene.cycles.device = 'CPU'
scene.cycles.samples = SAMPLES
scene.cycles.use_denoising = True
scene.render.film_transparent = True
scene.render.resolution_x = scene.render.resolution_y = SIZE
scene.render.image_settings.file_format = 'WEBP'
scene.render.image_settings.color_mode = 'RGBA'
scene.render.image_settings.quality = 86
try:
    scene.view_settings.view_transform = 'AgX'
    scene.view_settings.look = 'AgX - Punchy'
except TypeError:
    pass
os.makedirs(OUT, exist_ok=True)
scene.render.filepath = os.path.join(OUT, 'plate.webp')
bpy.ops.render.render(write_still=True)
print('wrote plate.webp')

# ---------- The wand (a separate scene of its own) ----------

for o in list(bpy.data.objects):
    if o.type != 'CAMERA':
        bpy.data.objects.remove(o)
WOOD = material('wand_wood', (92, 52, 30), roughness=0.6, noise=0.2)
CRYSTAL = material('crystal', (255, 140, 30), emission=2.6, roughness=0.1)
curve = bpy.data.curves.new('wand', 'CURVE')
curve.dimensions = '3D'
curve.bevel_depth = 0.13
curve.bevel_resolution = 4
spline = curve.splines.new('BEZIER')
points = [(0, -1.55, 0), (0.06, -0.8, 0), (-0.05, 0.1, 0), (0.04, 0.95, 0), (0, 1.45, 0)]
spline.bezier_points.add(len(points) - 1)
for bp, p in zip(spline.bezier_points, points):
    bp.co = p
    bp.handle_left_type = bp.handle_right_type = 'AUTO'
for i, bp in enumerate(spline.bezier_points):
    bp.radius = 1.25 - 0.6 * i / (len(points) - 1)
wand = link(bpy.data.objects.new('wand', curve), WOOD)
for y in (-1.2, -1.05, -0.9):
    bpy.ops.mesh.primitive_torus_add(major_radius=0.07, minor_radius=0.018, location=(0.03, y, 0), rotation=(math.pi / 2, 0, 0))
    bpy.context.object.data.materials.append(IRON)
bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=1, radius=0.21, location=(0, 1.6, 0))
gem = bpy.context.object
gem.scale = (0.9, 1.5, 0.9)
gem.data.materials.append(CRYSTAL)
key = bpy.data.objects.new('key', bpy.data.lights.new('key', 'SUN'))
key.data.energy = 3
key.rotation_euler = (math.radians(30), 0, math.radians(30))
link(key)
cam.data.ortho_scale = 3.6
cam.location = (0, 0.05, 5)
scene.render.resolution_x = SIZE // 6
scene.render.resolution_y = SIZE
scene.render.filepath = os.path.join(OUT, 'wand.webp')
bpy.ops.render.render(write_still=True)
print('wrote wand.webp')
