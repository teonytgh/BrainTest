import type { Rank } from '../../shared/ranks';
import { cx } from '../lib/format';

/** A rank's badge: its brainrot in a ring of the rarity's colour. */
export function RankBadge({ rank, size = 56 }: { rank: Rank; size?: number }) {
  return (
    <span className={cx('rank-badge', `rank-badge--${rank.tier}`)} style={{ width: size, height: size }} title={`Ранг: ${rank.name}`}>
      <img src={`/brainrots/${rank.mascot}.webp`} alt="" loading="lazy" />
    </span>
  );
}
