import { useQuery } from '@tanstack/react-query';
import { useState, type CSSProperties, type FormEvent } from 'react';
import { Avatar } from '../components/Avatar';
import { CaseArt } from '../components/CaseArt';
import { Coin } from '../components/Coin';
import { Icon } from '../components/Icon';
import { Tabs } from '../components/Tabs';
import { PromoAnnounce, promoAnnouncement, promoRewardText } from '../components/PromoAnnounce';
import { api, errorMessage } from '../api/client';
import { act, queryClient, setMe, useCatalog, useMe, type Me } from '../api/queries';
import type { referralFriends, referralSummary, userPromos } from '../../server/referrals';
import { PARTNER_DEPOSIT_PERCENT, REF_DEPOSIT_MIN, REF_LEVELS, REF_MILESTONE_TURNOVER, REF_MILESTONES } from '../../shared/bonuses';
import type { GiveawayCard } from '../../shared/giveaways';
import { round2 } from '../../shared/money';
import { cx, formatCoins } from '../lib/format';
import { routeHref } from '../lib/router';
import { sfx } from '../lib/sound';
import { haptic, share } from '../lib/telegram';
import { toast } from '../store/toast';

type Summary = Awaited<ReturnType<typeof referralSummary>>;
type Friend = Awaited<ReturnType<typeof referralFriends>>[number];
type MyPromo = Awaited<ReturnType<typeof userPromos>>[number];
type Tab = 'stats' | 'friends' | 'promos';

const day = new Intl.DateTimeFormat('ru-RU', { day: 'numeric', month: 'short', year: 'numeric' });

const SUMMARY_KEY = ['referrals'] as const;

function copy(text: string, what: string) {
  void navigator.clipboard?.writeText(text).then(
    () => toast(`${what} скопирован`, 'success'),
    () => toast(text),
  );
  haptic('tap');
}

/** «Рефералы»: your link and code, level (your % of friends' deposits) and wallet, stats, friends and your own promo codes. */
export function Referrals() {
  const summary = useQuery({ queryKey: SUMMARY_KEY, queryFn: () => api<Summary>('/api/referrals'), staleTime: 15_000 });
  const [tab, setTab] = useState<Tab>('stats');
  const s = summary.data;

  return (
    <section className="refs" aria-labelledby="refs-title">
      <a className="back-link" href={routeHref('bonuses')}>
        <Icon name="chevronRight" size={18} className="back-link__icon" /> Бонусы
      </a>
      <h1 id="refs-title" className="page-title">
        Рефералы
      </h1>
      {!s ? (
        <p className="hint">{summary.isError ? errorMessage(summary.error) : 'Загружаем…'}</p>
      ) : (
        <>
          <Level s={s} />
          <LinkCard s={s} />
          <Wallet s={s} />
          <BigInvites s={s} />
          <Tabs<Tab>
            label="Разделы рефералов"
            value={tab}
            onChange={setTab}
            options={[
              { value: 'stats', label: 'Статистика' },
              { value: 'friends', label: `Друзья${s.invited ? ` · ${s.invited}` : ''}` },
              { value: 'promos', label: 'Промокоды' },
            ]}
          />
          <div className="refs__panel" key={tab}>
            {tab === 'stats' && <Stats s={s} />}
            {tab === 'friends' && <Friends />}
            {tab === 'promos' && <Promos />}
          </div>
        </>
      )}
    </section>
  );
}

function Level({ s }: { s: Summary }) {
  const progress = s.next ? Math.min(1, s.active / s.next.from) : 1;
  return (
    <div className="refs-level" data-tour="refs">
      <div className="refs-level__ring" style={{ '--p': `${progress * 360}deg` } as CSSProperties}>
        <span>
          <b>{s.percent}%</b>
          <small>с пополнений</small>
        </span>
      </div>
      <div className="refs-level__copy">
        <p className="refs-level__title">Уровень {s.level}</p>
        <p className="refs-level__text">
          {s.next ? (
            <>
              Ещё <b>{s.next.from - s.active}</b> друзей с пополнением до <b>{s.next.percent}%</b>
            </>
          ) : (
            'Максимальный уровень — ты легенда'
          )}
        </p>
        <p className="refs-level__hint">
          Получаешь {s.percent}% с каждого пополнения приглашённых друзей — сразу на реферальный баланс — а за первого друга реферальный кейс (он даётся один раз на аккаунт). Со ставок
          ничего не начисляется. Уровень растёт с числом активных друзей: тех, кто пополнил баланс от {REF_DEPOSIT_MIN} B.
        </p>
      </div>
    </div>
  );
}

function LinkCard({ s }: { s: Summary }) {
  const [editing, setEditing] = useState(false);
  const [code, setCode] = useState(s.code);
  const [busy, setBusy] = useState(false);

  async function save(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      await api('/api/referrals/code', { body: { code } });
      sfx.coin();
      toast('Код сохранён — ссылка обновилась', 'success');
      setEditing(false);
      await queryClient.invalidateQueries({ queryKey: SUMMARY_KEY });
    } catch (err) {
      sfx.error();
      toast(errorMessage(err), 'error');
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="refs-link">
      <span className="refs-link__label">Твоя ссылка</span>
      <div className="refs-link__row">
        <code className="refs-link__url">{s.link.replace('https://', '')}</code>
        <button type="button" className="icon-btn" aria-label="Скопировать ссылку" onClick={() => copy(s.link, 'Ссылка')}>
          <Icon name="copy" size={18} />
        </button>
      </div>
      <span className="refs-link__label">Партнёрский код — друг вводит его в «Бонус-код». Менять можно раз в сутки, старые ссылки продолжают работать</span>
      {editing ? (
        <form className="refs-link__row" onSubmit={save}>
          <span className="field__control refs-link__input">
            <input value={code} maxLength={16} autoFocus autoCapitalize="characters" spellCheck={false} aria-label="Новый код" onChange={(e) => setCode(e.target.value.replace(/[^A-Za-z0-9_]/g, ''))} />
          </span>
          <button type="submit" className="btn btn--primary btn--sm" disabled={busy || code.length < 4}>
            Сохранить
          </button>
        </form>
      ) : (
        <div className="refs-link__row">
          <code className="refs-link__code">{s.code}</code>
          <button type="button" className="icon-btn" aria-label="Изменить код" onClick={() => setEditing(true)}>
            <Icon name="tag" size={18} />
          </button>
          <button type="button" className="icon-btn" aria-label="Скопировать код" onClick={() => copy(s.code, 'Код')}>
            <Icon name="copy" size={18} />
          </button>
        </div>
      )}
      <p className="refs-link__hint">
        Это и код партнёра: друг вводит его при пополнении звёздами — получает <b>+{PARTNER_DEPOSIT_PERCENT}%</b> к депозиту, а ты свой процент.
      </p>
      <button
        type="button"
        className="btn btn--primary btn--lg btn--block"
        onClick={() => share('🎁 Залетай в BrainrotCrash: бесплатный кейс каждые 12 часов, а по моей ссылке — ещё и реферальный кейс!', s.link)}
      >
        <Icon name="arrowRight" size={18} /> Отправить друзьям
      </button>
    </div>
  );
}

function Wallet({ s }: { s: Summary }) {
  const [busy, setBusy] = useState(false);
  async function transfer() {
    setBusy(true);
    try {
      const r = await act<{ moved: number }>('/api/referrals/transfer');
      setMe(r.me);
      sfx.win();
      haptic('success');
      toast(`+${formatCoins(r.result.moved)} B на основной баланс`, 'success');
      await queryClient.invalidateQueries({ queryKey: SUMMARY_KEY });
    } catch (e) {
      sfx.error();
      toast(errorMessage(e), 'error');
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="refs-wallet" data-private="balance">
      <div className="refs-wallet__cell">
        <span>Реферальный баланс</span>
        <strong>
          {formatCoins(s.balance)} <Coin size={20} />
        </strong>
        <button type="button" className="btn btn--green btn--sm" disabled={busy || s.balance <= 0} onClick={() => void transfer()}>
          На баланс
        </button>
      </div>
      <div className="refs-wallet__cell refs-wallet__cell--soon">
        <span>Твой процент</span>
        <strong>{s.percent}%</strong>
        <small>с каждого пополнения друга — сразу</small>
      </div>
    </div>
  );
}

/**
 * «Крупные приглашения»: a friend whose net deposits pass a threshold pays the referrer once per threshold, on top of
 * the share of every deposit; running invite races are one tap away.
 */
function BigInvites({ s }: { s: Summary }) {
  const races = useQuery({ queryKey: ['giveaways'], queryFn: () => api<{ active: GiveawayCard[]; finished: GiveawayCard[] }>('/api/giveaways'), staleTime: 30_000 });
  const running = (races.data?.active ?? []).filter((g) => g.kind === 'referral_race');
  return (
    <section className="refs-big" aria-labelledby="refs-big-title">
      <div className="refs-big__head">
        <h2 id="refs-big-title" className="section-title">
          Крупные приглашения
        </h2>
        {s.milestones > 0 && (
          <span className="refs-big__earned">
            +{formatCoins(s.milestones)} <Coin size={13} />
          </span>
        )}
      </div>
      <p className="refs-big__text">
        Друг пополнил на {formatCoins(REF_MILESTONES[0].from)} — тебе +{formatCoins(REF_MILESTONES[0].reward)} B, на {formatCoins(REF_MILESTONES[1].from)} — ещё +
        {formatCoins(REF_MILESTONES[1].reward)} B, и так дальше. Это сверх процента с каждого пополнения.
      </p>
      <ol className="refs-big__ladder">
        {REF_MILESTONES.map((m) => (
          <li key={m.step} className="refs-big__step">
            <span>
              +{formatCoins(m.reward)} <Coin size={16} />
            </span>
            <b>{formatCoins(m.from)} B</b>
            <small>пополнил друг</small>
          </li>
        ))}
      </ol>
      <p className="refs-big__rule">
        <Icon name="info" size={14} />
        <span>
          Каждый порог — один раз за друга. Считаются пополнения минус выводы, и друг должен сыграть в кейсах и батлах на
          сумму в {REF_MILESTONE_TURNOVER} раза больше порога — так бонус не накрутить.
        </span>
      </p>
      {running.map((g) => (
        <a key={g.id} className="refs-big__race" href={routeHref('giveaways', String(g.id))}>
          <Icon name="trophy" size={18} />
          <span>
            <b>{g.title}</b>
            <small>Гонка приглашений идёт — приводи друзей и забирай призы</small>
          </span>
          <Icon name="chevronRight" size={16} />
        </a>
      ))}
    </section>
  );
}

function Stats({ s }: { s: Summary }) {
  const tiles: [string, number, boolean, string?][] = [
    ['Переходы', s.clicks, false],
    ['Друзей', s.invited, false, `с пополнением: ${s.active}`],
    ['Пополнили', s.deposits, true],
    ['Вывели', s.withdrawals, true],
    ['Твой доход', s.earned, true],
  ];
  return (
    <>
      <div className="refs-stats">
        {tiles.map(([label, value, coins, note]) => (
          <div key={label} className="refs-stat">
            <span>{label}</span>
            <strong>
              {formatCoins(value)}
              {coins && <Coin size={16} />}
            </strong>
            {note && <small>{note}</small>}
          </div>
        ))}
      </div>
      <h2 className="section-title">Уровни</h2>
      <ol className="refs-levels">
        {REF_LEVELS.map((l) => (
          <li key={l.level} className={cx('refs-levels__item', l.level === s.level && 'is-current', l.level < s.level && 'is-done')}>
            <span className="refs-levels__n">{l.level}</span>
            <b>{l.percent}%</b>
            <small>{l.from ? `от ${l.from} активных` : 'сразу'}</small>
          </li>
        ))}
      </ol>
    </>
  );
}

function Friends() {
  const list = useQuery({ queryKey: ['referrals', 'friends'], queryFn: () => api<Friend[]>('/api/referrals/friends'), staleTime: 30_000 });
  if (list.isPending) return <p className="hint">Загружаем…</p>;
  if (!list.data?.length) return <p className="hint">Пока никого. Отправь ссылку — друг получит реферальный кейс, и ты тоже, если он у тебя ещё не был: один на аккаунт.</p>;
  return (
    <ul className="refs-friends">
      {list.data.map((f, i) => (
        <li key={i} className="refs-friend">
          <Avatar user={{ name: f.name, photoUrl: f.photo, username: f.name.startsWith('@') ? f.name.slice(1) : null }} size={42} />
          <span className="refs-friend__who">
            <b>{f.name}</b>
            <small>
              с {f.since ? day.format(f.since) : '—'} · пополнил {formatCoins(f.deposits)}
            </small>
            {f.nextMilestone && (
              <span className="refs-friend__goal" title="До следующего бонуса за крупное приглашение">
                <span className="refs-friend__bar">
                  <i style={{ transform: `scaleX(${Math.min(1, f.net / f.nextMilestone.from, f.played / f.nextMilestone.turnover)})` }} />
                </span>
                <small>
                  пополнил {formatCoins(Math.min(f.net, f.nextMilestone.from))} / {formatCoins(f.nextMilestone.from)} · сыграл{' '}
                  {formatCoins(Math.min(f.played, f.nextMilestone.turnover))} / {formatCoins(f.nextMilestone.turnover)} → +
                  {formatCoins(f.nextMilestone.reward)} B
                </small>
              </span>
            )}
          </span>
          <span className={cx('refs-friend__brought', f.brought > 0 && 'is-plus')}>
            +{formatCoins(f.brought)}
            <small>принёс</small>
          </span>
        </li>
      ))}
    </ul>
  );
}

function Promos() {
  const me = useMe();
  const catalog = useCatalog();
  const list = useQuery({ queryKey: ['referrals', 'promos'], queryFn: () => api<MyPromo[]>('/api/referrals/promos'), staleTime: 15_000 });
  const [type, setType] = useState<'coins' | 'case'>('coins');
  const [amount, setAmount] = useState('10');
  const [uses, setUses] = useState('10');
  const [caseId, setCaseId] = useState<string | null>(null);
  const [code, setCode] = useState('');
  const [busy, setBusy] = useState(false);
  const [removing, setRemoving] = useState<number | null>(null);
  const [made, setMade] = useState<string | null>(null);
  const paid = catalog.cases.filter((c) => c.kind === 'paid');
  const usesN = Math.max(0, Math.floor(Number(uses) || 0));
  const unit = type === 'coins' ? Math.floor(Number(amount) || 0) : (catalog.caseById.get(caseId ?? '')?.price ?? 0);
  const cost = round2(unit * usesN);
  // Own coins only (iteration 35): demo coins never turn into codes other players can use.
  const own = round2(me.user.balance - me.user.demoBalance);

  async function create(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      const r = await act<{ code: string; cost: number }>('/api/referrals/promos', { type, amount: Number(amount) || 0, uses: usesN, caseId, code: code || undefined });
      setMe(r.me);
      sfx.coin();
      toast(`Промокод ${r.result.code} создан — списано ${formatCoins(r.result.cost)} B`, 'success');
      setCode('');
      setMade(promoAnnouncement(r.result.code, usesN, promoRewardText({ type, amount: type === 'coins' ? Math.floor(Number(amount) || 0) : 1, name: catalog.caseById.get(caseId ?? '')?.name })));
      await queryClient.invalidateQueries({ queryKey: ['referrals'] });
    } catch (err) {
      sfx.error();
      toast(errorMessage(err), 'error');
    } finally {
      setBusy(false);
    }
  }

  async function remove(p: MyPromo) {
    if (removing !== null) return;
    setRemoving(p.id);
    try {
      const r = await api<{ result: { refund: number }; me: Me }>(`/api/referrals/promos/${p.id}`, { method: 'DELETE' });
      setMe(r.me);
      toast(r.result.refund ? `Удалён — вернули ${formatCoins(r.result.refund)} B` : 'Промокод удалён', 'success');
      await queryClient.invalidateQueries({ queryKey: ['referrals'] });
    } catch (err) {
      toast(errorMessage(err), 'error');
    } finally {
      setRemoving(null);
    }
  }

  return (
    <>
      <form className="refs-promo" onSubmit={create}>
        <p className="refs-promo__title">Свой промокод для друзей</p>
        <p className="refs-promo__text">Оплачиваешь из своего баланса сразу, доступно после первого пополнения. Кто активирует и ещё ни к кому не привязан — станет твоим рефералом.</p>
        <div className="segmented" role="radiogroup" aria-label="Награда">
          {(['coins', 'case'] as const).map((t) => (
            <button key={t} type="button" role="radio" aria-checked={type === t} className={cx('segmented__opt', type === t && 'is-on')} onClick={() => setType(t)}>
              {t === 'coins' ? 'Монеты' : 'Открытие кейса'}
            </button>
          ))}
        </div>
        {type === 'coins' ? (
          <label className="field">
            <span className="field__label">Монет за одну активацию</span>
            <span className="field__control">
              <Coin size={18} />
              <input inputMode="numeric" value={amount} onChange={(e) => setAmount(e.target.value.replace(/\D/g, '').slice(0, 5))} />
            </span>
          </label>
        ) : (
          <div className="field">
            <span className="field__label">Кейс</span>
            <div className="refs-promo__cases" role="radiogroup" aria-label="Кейс">
              {paid.map((c) => (
                <button key={c.id} type="button" role="radio" aria-checked={caseId === c.id} className={cx('refs-promo__case', caseId === c.id && 'is-on')} onClick={() => setCaseId(c.id)}>
                  <CaseArt kase={c} lazy />
                  <span>{c.name}</span>
                  <small>{formatCoins(c.price)} B</small>
                </button>
              ))}
            </div>
          </div>
        )}
        <div className="refs-promo__row">
          <label className="field">
            <span className="field__label">Активаций</span>
            <span className="field__control">
              <input inputMode="numeric" value={uses} onChange={(e) => setUses(e.target.value.replace(/\D/g, '').slice(0, 3))} />
            </span>
          </label>
          <label className="field">
            <span className="field__label">
              Код <span className="field__optional">(пусто — придумаем)</span>
            </span>
            <span className="field__control">
              <input value={code} maxLength={24} autoCapitalize="characters" spellCheck={false} placeholder="MYCODE" onChange={(e) => setCode(e.target.value.replace(/[^A-Za-z0-9_]/g, ''))} />
            </span>
          </label>
        </div>
        <p className="refs-promo__cost">
          Спишется: <b>{formatCoins(cost)} B</b> · своих монет {formatCoins(own)}
          {me.user.demoBalance > 0 && ' (демо-монеты на промокоды не идут)'}
        </p>
        <button type="submit" className="btn btn--primary btn--lg btn--block" disabled={busy || cost <= 0 || cost > own || (type === 'case' && !caseId)}>
          {cost > own ? 'Не хватает монет' : 'Создать промокод'}
        </button>
      </form>
      {made && <PromoAnnounce text={made} onClose={() => setMade(null)} />}
      {!!list.data?.length && (
        <ul className="refs-mypromos">
          {list.data.map((p) => (
            <li key={p.id} className="refs-mypromo">
              <button type="button" className="refs-mypromo__code" onClick={() => copy(p.code, 'Промокод')}>
                {p.code} <Icon name="copy" size={14} />
              </button>
              <span className="refs-mypromo__what">
                {p.type === 'coins' ? `${formatCoins(p.amount)} B` : `кейс «${catalog.caseById.get(p.caseId ?? '')?.name ?? p.caseId}»`} · {p.uses}/{p.maxUses}
              </span>
              <button type="button" className="icon-btn icon-btn--ghost" aria-label={`Удалить ${p.code}`} onClick={() => void remove(p)} disabled={removing !== null}>
                <Icon name="close" size={16} />
              </button>
            </li>
          ))}
        </ul>
      )}
    </>
  );
}
