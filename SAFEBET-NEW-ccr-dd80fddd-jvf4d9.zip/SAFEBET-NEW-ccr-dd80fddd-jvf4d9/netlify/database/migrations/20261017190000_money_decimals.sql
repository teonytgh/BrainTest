-- Coins and prices carry kopecks now (e.g. 824.60 B): two decimal places everywhere money is stored.
ALTER TABLE users ALTER COLUMN balance TYPE NUMERIC(16, 2), ALTER COLUMN withdrawn_value TYPE NUMERIC(16, 2);
ALTER TABLE brainrots ALTER COLUMN price TYPE NUMERIC(16, 2);
ALTER TABLE cases ALTER COLUMN price TYPE NUMERIC(16, 2);
ALTER TABLE drops ALTER COLUMN stake_value TYPE NUMERIC(16, 2), ALTER COLUMN coins TYPE NUMERIC(16, 2);
ALTER TABLE crash_rounds ALTER COLUMN stake_value TYPE NUMERIC(16, 2);
ALTER TABLE withdrawals ALTER COLUMN value TYPE NUMERIC(16, 2);
ALTER TABLE star_payments ALTER COLUMN credited TYPE NUMERIC(16, 2);
