"""The BrainrotCrash upgrader: a vault dial under the chance ring and a gold crash arrow for the needle.

    blender -b --factory-startup --python scripts/blender/upgrader_dial.py -- public/upgrader [--quick]

Top-down orthographic renders (WebP, alpha), shown only with <html data-palette="crash">; R = 1 is half the picture,
and the rings line up with the CSS ring (UpgradeRing.tsx):
  dial.webp   a gold knurled bezel (0.90–1.0, like a safe's dial), a graphite band of engraved ticks with gold majors at
              0 / 25 / 50 / 75 (0.86–0.90), a deep groove for the CSS chance arc (0.60–0.86, the arc covers 0.63–0.83),
              a thin gold lip and a brushed graphite face under the chance in the middle
  arrow.webp  the needle: the logo's gold crash arrow pointing up, outlined in ink so it reads on the arc
"""
import math
import os
import sys

import bpy
from mathutils import Vector

ARGS = sys.argv[sys.argv.index('--') + 1:] if '--' in sys.argv else []
POSITIONAL = [a for a in ARGS if not a.startswith('--')]
OUT = os.path.abspath(POSITIONAL[0] if POSITIONAL else 'public/upgrader')
QUICK = '--quick' in ARGS
SIZE = 384 if QUICK else 768
SAMPLES = 32 if QUICK else 192


def lin(c):
    def ch(v):
        v /= 255
        return v / 12.92 if v <= 0.04045 else ((v + 0.055) / 1.055) ** 2.4
    return (ch(c[0]), ch(c[1]), ch(c[2]), 1.0)


def material(name, rgb, roughness=0.4, metallic=0.0, emission=0.0, brushed=0.0):
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    nt = m.node_tree
    bsdf = nt.nodes['Principled BSDF']
    bsdf.inputs['Base Color'].default_value = lin(rgb)
    bsdf.inputs['Roughness'].default_value = roughness
    bsdf.inputs['Metallic'].default_value = metallic
    if emission:
        bsdf.inputs['Emission Color'].default_value = lin(rgb)
        bsdf.inputs['Emission Strength'].default_value = emission
    if brushed:
        # Circular brushing: a noise stretched along the rings drives the roughness and a faint bump.
        coord = nt.nodes.new('ShaderNodeTexCoord')
        sep = nt.nodes.new('ShaderNodeSeparateXYZ')
        nt.links.new(coord.outputs['Object'], sep.inputs['Vector'])
        length = nt.nodes.new('ShaderNodeVectorMath')
        length.operation = 'LENGTH'
        comb = nt.nodes.new('ShaderNodeCombineXYZ')
        nt.links.new(sep.outputs['X'], comb.inputs['X'])
        nt.links.new(sep.outputs['Y'], comb.inputs['Y'])
        nt.links.new(comb.outputs['Vector'], length.inputs[0])
        noise = nt.nodes.new('ShaderNodeTexNoise')
        noise.inputs['Scale'].default_value = 900
        noise.inputs['Detail'].default_value = 4
        nt.links.new(length.outputs['Value'], noise.inputs['Vector'])
        rng = nt.nodes.new('ShaderNodeMapRange')
        rng.inputs['To Min'].default_value = roughness * 0.7
        rng.inputs['To Max'].default_value = roughness * 1.4
        nt.links.new(noise.outputs['Fac'], rng.inputs['Value'])
        nt.links.new(rng.outputs['Result'], bsdf.inputs['Roughness'])
        bump = nt.nodes.new('ShaderNodeBump')
        bump.inputs['Strength'].default_value = brushed
        nt.links.new(noise.outputs['Fac'], bump.inputs['Height'])
        nt.links.new(bump.outputs['Normal'], bsdf.inputs['Normal'])
    return m


def link(obj, mat=None):
    bpy.context.scene.collection.objects.link(obj)
    if mat:
        obj.data.materials.append(mat)
    return obj


def annulus(name, r_in, r_out, z0, z1, mat, segments=256, smooth=True):
    """A flat ring (a disc when r_in is 0) from z0 to z1."""
    verts, faces = [], []
    for k in range(segments):
        a = 2 * math.pi * k / segments
        c, s = math.cos(a), math.sin(a)
        verts += [(r_out * c, r_out * s, z0), (r_out * c, r_out * s, z1), (r_in * c, r_in * s, z1), (r_in * c, r_in * s, z0)]
    for k in range(segments):
        i, j = 4 * k, 4 * ((k + 1) % segments)
        faces += [(i, j, j + 1, i + 1), (i + 1, j + 1, j + 2, i + 2), (i + 2, j + 2, j + 3, i + 3), (i + 3, j + 3, j, i)]
    mesh = bpy.data.meshes.new(name)
    mesh.from_pydata(verts, [], faces)
    mesh.validate()
    for p in mesh.polygons:
        p.use_smooth = smooth
    obj = link(bpy.data.objects.new(name, mesh), mat)
    bev = obj.modifiers.new('bevel', 'BEVEL')
    bev.width = min(0.006, (z1 - z0) / 3)
    bev.segments = 3
    bev.limit_method = 'ANGLE'
    return obj


def box(name, loc, size, angle, mat):
    bpy.ops.mesh.primitive_cube_add(size=1, location=loc, rotation=(0, 0, angle))
    o = bpy.context.object
    o.name = name
    o.scale = size
    o.data.materials.append(mat)
    bev = o.modifiers.new('bevel', 'BEVEL')
    bev.width = min(size) * 0.25
    bev.segments = 2
    return o


def setup(scene, width, height):
    scene.render.engine = 'CYCLES'
    scene.cycles.device = 'CPU'
    scene.cycles.samples = SAMPLES
    scene.cycles.use_denoising = True
    scene.render.film_transparent = True
    scene.render.resolution_x, scene.render.resolution_y = width, height
    scene.render.image_settings.file_format = 'WEBP'
    scene.render.image_settings.color_mode = 'RGBA'
    scene.render.image_settings.quality = 88
    # Standard, not AgX: AgX drains the gold.
    scene.view_settings.view_transform = 'Standard'
    scene.view_settings.look = 'None'
    world = bpy.data.worlds.new('studio')
    world.use_nodes = True
    world.node_tree.nodes['Background'].inputs['Color'].default_value = (0.35, 0.35, 0.4, 1)
    world.node_tree.nodes['Background'].inputs['Strength'].default_value = 0.12
    scene.world = world


def softbox(name, loc, size, energy, color=(1, 1, 1)):
    light = bpy.data.objects.new(name, bpy.data.lights.new(name, 'AREA'))
    light.data.shape = 'RECTANGLE'
    light.data.size, light.data.size_y = size
    light.data.energy = energy
    light.data.color = color
    light.location = loc
    light.rotation_euler = (Vector((0, 0, 0)) - Vector(loc)).to_track_quat('-Z', 'Y').to_euler()
    return link(light)


def camera(scene, scale, loc=(0, 0, 5)):
    cam = bpy.data.objects.new('cam', bpy.data.cameras.new('cam'))
    cam.data.type = 'ORTHO'
    cam.data.ortho_scale = scale
    cam.location = loc
    link(cam)
    scene.camera = cam


def clear():
    for o in list(bpy.data.objects):
        bpy.data.objects.remove(o, do_unlink=True)


os.makedirs(OUT, exist_ok=True)
scene = bpy.context.scene
clear()
setup(scene, SIZE, SIZE)

GOLD = material('gold', (250, 172, 48), roughness=0.26, metallic=1.0)
GOLD_DARK = material('gold_dark', (176, 104, 22), roughness=0.4, metallic=1.0)
GRAPHITE = material('graphite', (46, 52, 68), roughness=0.38, metallic=0.85, brushed=0.04)
FACE = material('face', (30, 34, 46), roughness=0.32, metallic=0.8, brushed=0.05)
GROOVE = material('groove', (10, 12, 20), roughness=0.85)
STEEL = material('steel', (190, 196, 210), roughness=0.28, metallic=1.0)

# ---------- The dial (R = 1 is half the picture) ----------

annulus('bezel', 0.90, 0.985, 0.0, 0.16, GOLD_DARK)
annulus('bezel_lip', 0.975, 1.0, 0.0, 0.12, GOLD_DARK)
# Knurling: 90 ridges across the bezel, like the grip of a safe's dial.
for k in range(90):
    a = 2 * math.pi * k / 90
    r = 0.9425
    box(f'knurl{k}', (r * math.cos(a), r * math.sin(a), 0.17), (0.07, 0.014, 0.03), a, GOLD)
annulus('ticks_band', 0.86, 0.90, 0.0, 0.12, GRAPHITE)
# Engraved ticks every 7.5° (as the CSS ticks were), gold majors at 0 / 25 / 50 / 75 (12, 3, 6, 9 o'clock).
for k in range(48):
    deg = k * 7.5
    a = math.radians(90 - deg)
    major = deg % 90 == 0
    mid = deg % 45 == 0
    length = 0.034 if major else 0.024 if mid else 0.014
    r = 0.88
    box(f'tick{k}', (r * math.cos(a), r * math.sin(a), 0.122), (length, 0.008 if major else 0.005, 0.006), a, GOLD if major else STEEL)
annulus('groove', 0.60, 0.86, 0.0, 0.03, GROOVE)
annulus('lip', 0.585, 0.605, 0.0, 0.13, GOLD)
annulus('face', 0.0, 0.585, 0.0, 0.11, FACE)
annulus('face_ring', 0.44, 0.452, 0.0, 0.115, GOLD_DARK)

softbox('key', (-2.5, 3, 4), (3, 3), 170)
softbox('front', (0, 0, 7), (2, 2), 45, (1.0, 0.97, 0.92))
softbox('rim', (3, -2.5, 2.5), (5, 1), 120, (0.75, 0.82, 1.0))
camera(scene, 2.0)
scene.render.filepath = os.path.join(OUT, 'dial.webp')
bpy.ops.render.render(write_still=True)
print('wrote dial.webp')

# ---------- The arrow (pointing up: tip at the top) ----------

clear()
setup(scene, SIZE // 4, SIZE)


def flat_shape(name, outline, depth, bevel, mat, z=0.0):
    cu = bpy.data.curves.new(name, 'CURVE')
    cu.dimensions = '2D'
    cu.fill_mode = 'BOTH'
    cu.extrude = depth
    cu.bevel_depth = bevel
    cu.bevel_resolution = 4
    sp = cu.splines.new('POLY')
    sp.points.add(len(outline) - 1)
    for p, (x, y) in zip(sp.points, outline):
        p.co = (x, y, 0, 1)
    sp.use_cyclic_u = True
    o = link(bpy.data.objects.new(name, cu), mat)
    o.location.z = z
    return o


def arrow(half_shaft, half_head, head_len, top=1.0, bottom=-1.0, notch=0.06):
    """Up-pointing arrow outline: a shaft with a notched tail and a wide head."""
    base = top - head_len
    return [
        (0, top),
        (half_head, base),
        (half_shaft, base + 0.02),
        (half_shaft, bottom),
        (0, bottom + notch),
        (-half_shaft, bottom),
        (-half_shaft, base + 0.02),
        (-half_head, base),
    ]


INK = material('ink', (12, 14, 24), roughness=0.5)
SHINE = material('shine', (255, 182, 52), roughness=0.22, metallic=1.0)
flat_shape('arrow_ink', arrow(0.09, 0.225, 0.38, top=1.04, bottom=-1.04), 0.03, 0.0, INK, z=-0.06)
flat_shape('arrow', arrow(0.05, 0.165, 0.31), 0.06, 0.03, SHINE)

softbox('key', (-1.5, 2, 3), (2, 2), 120)
softbox('front', (0, 0, 6), (1, 3), 35, (1.0, 0.96, 0.9))
softbox('rim', (1.5, -1.5, 2), (3, 1), 60, (0.75, 0.82, 1.0))
camera(scene, 2.2)
scene.render.filepath = os.path.join(OUT, 'arrow.webp')
bpy.ops.render.render(write_still=True)
print('wrote arrow.webp')
