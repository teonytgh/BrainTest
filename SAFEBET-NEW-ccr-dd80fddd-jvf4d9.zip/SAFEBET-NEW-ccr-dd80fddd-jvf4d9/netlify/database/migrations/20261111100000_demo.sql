-- Iteration 35 (part 2): demo grants. Applied by the Worker (server/autoMigrate.ts), so every statement is safe to run
-- twice.
--
-- An admin can give coins, brainrots and case keys «для демо»: they play like any other, but they never leave the
-- game — no withdrawal, no exchange, no battles, no own promo codes — and everything won with them is demo too.

-- The demo part of `balance` (spent first). The trigger keeps it between 0 and the balance whatever path changes it.
ALTER TABLE users ADD COLUMN IF NOT EXISTS demo_balance NUMERIC(16, 2) NOT NULL DEFAULT 0;
ALTER TABLE inventory ADD COLUMN IF NOT EXISTS demo BOOLEAN NOT NULL DEFAULT false;
-- A game played with demo coins or brainrots: kept in the player's own history, out of quests, cashback, ranks,
-- referral milestones, LIVE, the top drop and «Экономика».
ALTER TABLE drops ADD COLUMN IF NOT EXISTS demo BOOLEAN NOT NULL DEFAULT false;
-- How many of the gift openings are demo (used first).
ALTER TABLE case_keys ADD COLUMN IF NOT EXISTS demo_count INT NOT NULL DEFAULT 0;
-- Rounds that hold a stake until they end: the stake's demo mark goes to whatever comes back.
ALTER TABLE crash_rounds ADD COLUMN IF NOT EXISTS demo BOOLEAN NOT NULL DEFAULT false;
ALTER TABLE mines_runs ADD COLUMN IF NOT EXISTS demo BOOLEAN NOT NULL DEFAULT false;
ALTER TABLE road_runs ADD COLUMN IF NOT EXISTS demo BOOLEAN NOT NULL DEFAULT false;

CREATE OR REPLACE FUNCTION users_demo_clamp() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  NEW.demo_balance := least(greatest(NEW.demo_balance, 0), greatest(NEW.balance, 0));
  RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS users_demo_clamp ON users;
CREATE TRIGGER users_demo_clamp BEFORE UPDATE OF balance, demo_balance ON users
  FOR EACH ROW EXECUTE FUNCTION users_demo_clamp();

CREATE OR REPLACE FUNCTION case_keys_demo_clamp() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  NEW.demo_count := least(greatest(NEW.demo_count, 0), greatest(NEW.count, 0));
  RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS case_keys_demo_clamp ON case_keys;
CREATE TRIGGER case_keys_demo_clamp BEFORE INSERT OR UPDATE ON case_keys
  FOR EACH ROW EXECUTE FUNCTION case_keys_demo_clamp();
