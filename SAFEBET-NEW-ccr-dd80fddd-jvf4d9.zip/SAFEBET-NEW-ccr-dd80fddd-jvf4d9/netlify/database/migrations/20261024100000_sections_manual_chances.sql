-- Iteration 11: case sections on the home page, manual drop chances, John Pork.

-- «Junk Pork» was the same brainrot as John Pork (same picture): the owner renamed it and set its price.
UPDATE brainrots SET name = 'John Pork', price = 14500, updated_at = now() WHERE id = 'junk-pork';
-- It was the cheapest brainrot (38): the cheapest now cost 45, so the cheapest cases move up to keep 88 % and
-- the 2 % окуп chance (the healer re-composes them on the next tick).
UPDATE cases SET price = v.price FROM (VALUES ('noobini', 55), ('lucky', 57), ('petrosyan', 59), ('random', 61)) AS v (id, price)
WHERE cases.id = v.id AND cases.price < v.price;

-- Sections («темы») of the home case grid; the owner adds more and moves cases between them.
CREATE TABLE case_sections (
  id BIGSERIAL PRIMARY KEY,
  title TEXT NOT NULL CHECK (char_length(title) BETWEEN 1 AND 40),
  sort INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
INSERT INTO case_sections (title, sort) VALUES ('Кейсы', 0);
ALTER TABLE cases ADD COLUMN section_id BIGINT REFERENCES case_sections (id) ON DELETE SET NULL;
UPDATE cases SET section_id = (SELECT min(id) FROM case_sections) WHERE kind = 'paid';

-- A drop chance the admin set by hand (0…1; 0 = «Невозможно»). NULL = derived from prices as before.
ALTER TABLE case_items ADD COLUMN fixed_chance NUMERIC(12, 10) CHECK (fixed_chance IS NULL OR fixed_chance BETWEEN 0 AND 1);

-- Supabase serves the public schema over its REST API: same lock as 20261022100000 for the new table.
ALTER TABLE case_sections ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'anon') THEN
    EXECUTE 'REVOKE ALL ON case_sections FROM anon, authenticated';
    EXECUTE 'REVOKE ALL ON SEQUENCE case_sections_id_seq FROM anon, authenticated';
  END IF;
END $$;
