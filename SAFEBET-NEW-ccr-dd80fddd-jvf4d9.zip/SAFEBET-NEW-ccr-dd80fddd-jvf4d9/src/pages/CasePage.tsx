import { useMemo, useState } from 'react';
import { BrainrotCard } from '../components/BrainrotCard';
import { CaseArt } from '../components/CaseArt';
import { CaseOpening, type CaseWin, type OpenMode } from '../components/CaseOpening';
import { Coin } from '../components/Coin';
import { Ticket } from '../components/Ticket';
import { FreeGate, freeGateReady, onlyShareLeft, refreshFreeGate, useFreeGate, useFreeShare } from '../components/FreeGate';
import { Icon } from '../components/Icon';
import { ApiError, api, errorMessage } from '../api/client';
import { act, catalogQuery, queryClient, refreshCatalog, setMe, useCatalog, useMe, type Me } from '../api/queries';
import { FREE_CASE_COOLDOWN_MS } from '../../shared/types';
import { NICK_CASE_COOLDOWN_MS, NICK_TAG } from '../../shared/bonuses';
import { OPEN_COUNTS } from '../../shared/cases';
import { round2 } from '../../shared/money';
import { cx, formatCoins, formatCountdown, plural } from '../lib/format';
import { routeHref } from '../lib/router';
import { sfx } from '../lib/sound';
import { tierOf } from '../lib/tier';
import { luckIcon } from '../lib/luck';
import { PriceChart, PriceTrend } from '../components/PriceChart';
import { useNow } from '../lib/useNow';
import { toast } from '../store/toast';
import { openSheet } from '../store/ui';
import { copyText } from '../lib/copy';
import { DemoTag } from '../components/DemoTag';

const MODE_KEY = 'brainrotcrash:caseMode';
const MODES: { value: OpenMode; label: string }[] = [
  { value: 'slow', label: 'Медленно' },
  { value: 'fast', label: 'Быстро' },
  { value: 'skip', label: 'Пропустить' },
];

/** How many paid cases one press opens. */
const COUNT_KEY = 'brainrotcrash:caseCount';

function readMode(): OpenMode {
  try {
    const v = localStorage.getItem(MODE_KEY);
    return v === 'fast' || v === 'skip' ? v : 'slow';
  } catch {
    return 'slow';
  }
}

function readCount(): number {
  try {
    const v = Number(localStorage.getItem(COUNT_KEY));
    return (OPEN_COUNTS as readonly number[]).includes(v) ? v : 1;
  } catch {
    return 1;
  }
}

interface Opening {
  wins: CaseWin[];
  /** Paid with demo coins or a demo key: the drops are «ДЕМО». */
  demo: boolean;
  /** How many cases this press opened: «Крутить ещё» opens as many. */
  count: number;
  me: Me;
  key: number;
}

type CaseDrop = { brainrotId: string; itemId: number | null; coins: number; demo?: boolean };

const newRequestId = () =>
  typeof crypto.randomUUID === 'function' ? crypto.randomUUID() : `r${Date.now().toString(36)}${Math.random().toString(36).slice(2, 12)}`;

/** No answer at all (network, a proxy or Cloudflare error page): the opening may still have happened. */
const lostAnswer = (e: unknown) => e instanceof ApiError && (e.status === 0 || e.status >= 500 || e.code === 'error');

/**
 * Asks the server what press `requestId` gave: the spin plays as if the answer had come. A 404 means the opening
 * never happened (nothing was charged); null when the server can't be asked either.
 */
async function findOpening(requestId: string): Promise<{ result: CaseDrop & { drops?: CaseDrop[] }; me: Me } | null> {
  for (let attempt = 1; attempt <= 3; attempt++) {
    await new Promise((ok) => setTimeout(ok, 700 * attempt));
    try {
      return await api<{ result: CaseDrop & { drops?: CaseDrop[] }; me: Me }>(`/api/case/opened/${requestId}`);
    } catch (e) {
      if (e instanceof ApiError && e.status === 404) throw new ApiError(404, 'not_opened', 'Открытие не прошло — монеты не списаны, попробуй ещё раз', {});
    }
  }
  return null;
}

export function CasePage({ id }: { id: string }) {
  const me = useMe();
  const catalog = useCatalog();
  const now = useNow(1000);
  const [mode, setMode] = useState<OpenMode>(readMode);
  const [count, setCount] = useState(readCount);
  const [opening, setOpening] = useState<Opening | null>(null);
  const [busy, setBusy] = useState(false);
  const kase = catalog.caseById.get(id);
  const freeReady = kase?.kind === 'free' && !(me.user.freeCaseAt && me.user.freeCaseAt + FREE_CASE_COOLDOWN_MS > now);
  const gate = useFreeGate(freeReady);
  const shareLeft = freeReady && onlyShareLeft(gate.data);
  const freeShare = useFreeShare(shareLeft);

  const pool = useMemo(() => {
    if (!kase) return [];
    return kase.items.flatMap((i) => {
      const brainrot = catalog.byId.get(i.brainrotId);
      return brainrot ? [{ brainrot, weight: i.weight }] : [];
    });
  }, [kase, catalog.byId]);
  const prizes = [...pool].sort((a, b) => b.brainrot.price - a.brainrot.price);

  if (!kase) {
    return (
      <section className="soon">
        <h1 className="page-title page-title--center">Кейс не найден</h1>
        <a className="btn btn--ghost" href="#/">
          На главную
        </a>
      </section>
    );
  }

  const free = kase.kind === 'free';
  const nick = kase.bonus === 'nick';
  const referral = kase.bonus === 'referral';
  const costless = kase.kind !== 'paid';
  // Ticket cases cost quest tickets, never coins.
  const ticketPrice = kase.kind === 'tickets' ? (kase.ticketPrice ?? 0) : 0;
  const ticketShort = ticketPrice ? Math.max(0, ticketPrice - me.user.tickets) : 0;
  const readyAt = free && me.user.freeCaseAt ? me.user.freeCaseAt + FREE_CASE_COOLDOWN_MS : nick && me.user.nickCaseAt ? me.user.nickCaseAt + NICK_CASE_COOLDOWN_MS : 0;
  const cooling = (free || nick) && readyAt > now;
  // Several at once only for paid cases; gift, free and bonus openings go one by one.
  const n = costless ? 1 : count;
  const total = round2(kase.price * n);
  // Demo and own coins never mix in one payment (iteration 35): the bigger of the two pays.
  const spendable = Math.max(me.user.demoBalance, round2(me.user.balance - me.user.demoBalance));
  const missing = costless ? 0 : round2(total - spendable);
  const short = missing > 0;
  const frozen = !!me.user.frozen;
  const keys = me.caseKeys[kase.id] ?? 0;
  const gated = free && !cooling && !freeGateReady(gate.data);
  // Only the share left: the big button shares and opens in one tap.
  const shareAndOpen = gated && shareLeft;

  // "Крутить ещё" calls this with the result card still on screen. The server takes one payment for all `times`.
  async function open(useKey: boolean, times = 1) {
    if (busy || !kase) return;
    setBusy(true);
    // One id per press: a retry never opens twice, and an answer lost on the way can be looked up.
    const requestId = newRequestId();
    try {
      let r: { result: CaseDrop & { drops?: CaseDrop[] }; me: Me };
      try {
        r = await act<CaseDrop & { drops?: CaseDrop[] }>('/api/case/open', {
          caseId: kase.id,
          useKey,
          count: useKey ? 1 : times,
          requestId,
          // The price on screen: a floating price («Биткоин») may have moved, and then nothing is charged.
          expectedPrice: kase.price,
        });
      } catch (e) {
        const found = lostAnswer(e) ? await findOpening(requestId) : null;
        if (!found) throw e;
        r = found;
      }
      const got = r.result.drops ?? [r.result];
      // Paid and delivered already: a drop this app doesn't know yet (just added by an admin) means a stale
      // catalog, never a failed opening.
      let byId = catalog.byId;
      if (got.some((d) => !byId.has(d.brainrotId))) {
        const fresh = await queryClient.fetchQuery({ ...catalogQuery, staleTime: 0 });
        byId = new Map(fresh.brainrots.map((b) => [b.id, b]));
      }
      if (got.some((d) => !byId.has(d.brainrotId))) {
        setMe(r.me);
        toast('Дроп уже в инвентаре — обнови приложение, чтобы увидеть его', 'success');
        return;
      }
      const wins = got.map((d) => ({ won: byId.get(d.brainrotId)!, itemId: d.itemId }));
      sfx.open();
      setOpening({ wins, demo: r.result.demo === true, count: wins.length, me: r.me, key: Date.now() });
      // The next free opening asks for a new share.
      if (kase.kind === 'free' && !useKey) void refreshFreeGate();
    } catch (e) {
      sfx.error();
      toast(errorMessage(e), 'error');
      if (e instanceof ApiError && (e.code === 'need_channel' || e.code === 'need_share')) void refreshFreeGate();
      if (e instanceof ApiError && e.code === 'price_changed') void refreshCatalog();
    } finally {
      setBusy(false);
    }
  }

  // «Поделиться и открыть»: the case opens as soon as the share counts.
  async function shareThenOpen() {
    if (await freeShare.run()) await open(false);
  }

  function chooseCount(c: number) {
    setCount(c);
    try {
      localStorage.setItem(COUNT_KEY, String(c));
    } catch {
      // Preference just won't persist.
    }
  }

  function chooseMode(m: OpenMode) {
    setMode(m);
    try {
      localStorage.setItem(MODE_KEY, m);
    } catch {
      // Preference just won't persist.
    }
  }

  const label = ticketPrice
    ? `Открыть за ${formatCoins(ticketPrice)}`
    : costless
    ? cooling
      ? `Через ${formatCountdown(readyAt - now)}`
      : 'Открыть бесплатно'
    : n > 1
      ? `Открыть ${n} ${plural(n, 'кейс', 'кейса', 'кейсов')} за ${formatCoins(total)}`
      : `Открыть за ${formatCoins(kase.price)}`;
  // «Крутить ещё» after the result: a single paid opening spends a gift first, several open as many again.
  const againKey = !!opening && opening.count === 1 && keys > 0;
  const againCount = opening && !againKey ? opening.count : 1;
  const againTotal = againKey ? 0 : round2(kase.price * againCount);
  const againShort = costless || againKey ? 0 : round2(againTotal - spendable);

  return (
    <section className="case-page" aria-labelledby="case-title">
      <a className="back-link" href={routeHref('home')}>
        <Icon name="chevronRight" size={18} className="back-link__icon" /> Назад
      </a>
      <h1 id="case-title" className="page-title page-title--center">
        {kase.name}
      </h1>

      {me.luck && me.luck.until > now && !costless && (
        <p className="luck-pill">
          <img src={luckIcon(me.luck.x)} alt="" /> x{me.luck.x} удача · ещё {formatCountdown(me.luck.until - now)}
        </p>
      )}
      <div className="case-hero">
        {kase.badge && <span className={cx('case-hero__badge', `case-hero__badge--${kase.badge}`)}>{kase.badge === 'new' ? 'Новый кейс' : 'Редизайн'}</span>}
        <CaseArt kase={kase} />
      </div>
      {kase.priceCycle && (
        <div className="float-price" role="note">
          {kase.priceHistory && kase.priceHistory.length > 1 && <PriceChart prices={kase.priceHistory} className="float-price__chart" />}
          <p className="float-price__now">
            Сейчас <Coin size={16} /> <b>{formatCoins(kase.price)}</b>
            {kase.priceHistory && <PriceTrend prices={kase.priceHistory} />}
          </p>
          <p className="float-price__text">
            Цена меняется каждые 5–10 минут: {[...kase.priceCycle].sort((a, b) => b - a).map(formatCoins).join(' / ')} B. Шансы считаются от текущей цены, в среднем
            кейс отдаёт меньше, чем стоит.
          </p>
        </div>
      )}

      <div className="case-strip" aria-hidden="true">
        <div className="case-strip__track">
          {[...pool, ...pool].map((p, i) => (
            <span key={i} className={cx('case-strip__item', `tier-${tierOf(p.brainrot.price)}`)}>
              <img src={p.brainrot.image} alt="" />
            </span>
          ))}
        </div>
      </div>

      {!costless && (
        <div className="segmented segmented--count" role="radiogroup" aria-label="Сколько кейсов открыть за раз">
          {OPEN_COUNTS.map((c) => (
            <button key={c} type="button" role="radio" aria-checked={count === c} className={cx('segmented__opt', count === c && 'is-on')} onClick={() => chooseCount(c)}>
              x{c}
            </button>
          ))}
        </div>
      )}

      <div className="segmented" role="radiogroup" aria-label="Скорость открытия">
        {MODES.map((m) => (
          <button key={m.value} type="button" role="radio" aria-checked={mode === m.value} className={cx('segmented__opt', mode === m.value && 'is-on')} onClick={() => chooseMode(m.value)}>
            {m.value === 'slow' && <Icon name="clock" size={16} />}
            {m.value === 'fast' && <Icon name="bolt" size={16} />}
            {m.value === 'skip' && <Icon name="arrowRight" size={16} />}
            {m.label}
          </button>
        ))}
      </div>

      {keys > 0 && (
        <button type="button" className="btn btn--gift btn--lg btn--block case-page__gift" onClick={() => void open(true)} disabled={busy || frozen}>
          <Icon name="gift" size={20} /> {referral ? `Открыть · за друзей ×${keys}` : `Открыть бесплатно · подарок ×${keys}`}
          {(me.demoKeys?.[kase.id] ?? 0) > 0 && <DemoTag className="case-page__key-demo" />}
        </button>
      )}
      {nick && !cooling && (
        <div className="nick-gate">
          <p>
            Имя в Telegram должно заканчиваться на <b>{NICK_TAG}</b> — например, «{me.user.name.replace(new RegExp(`\\s*${NICK_TAG}$`, 'i'), '') || 'Игрок'} {NICK_TAG}».
            Проверяем при каждом открытии.
          </p>
          <button
            type="button"
            className="btn btn--ghost btn--sm"
            onClick={() => copyText(` ${NICK_TAG}`, `«${NICK_TAG}» скопирован`)}
          >
            <Icon name="copy" size={16} /> Скопировать тег
          </button>
        </div>
      )}
      {free && !cooling && gate.data && <FreeGate gate={gate.data} share={freeShare} />}
      {free && !cooling && gate.isError && !gate.data && (
        <p className="hint" role="alert">
          Не удалось проверить условия бесплатного кейса.{' '}
          <button type="button" className="link-btn" onClick={() => void gate.refetch()}>
            Повторить
          </button>
        </p>
      )}
      {referral && keys === 0 ? (
        <a className="btn btn--primary btn--lg btn--block" href={routeHref('referrals')}>
          <Icon name="users" size={20} /> Пригласить друга
        </a>
      ) : referral ? null : ticketShort > 0 && keys === 0 ? (
        <a className="btn btn--primary btn--lg btn--block case-page__short" href={routeHref('quests')}>
          <span>
            Не хватает {formatCoins(ticketShort)} <Ticket size={18} />
          </span>
          <small>Выполняй задания — за них дают тикеты</small>
        </a>
      ) : ticketShort > 0 ? null : short ? (
        <button type="button" className="btn btn--primary btn--lg btn--block case-page__short" onClick={() => openSheet('deposit')}>
          <span>
            Не хватает {formatCoins(missing)} <Coin size={18} />
          </span>
          <small>
            {me.user.demoBalance > 0 && me.user.balance >= total
              ? 'Демо-монеты и свои не складываются'
              : `Пополнить${n > 1 ? ` · ${n} ${plural(n, 'кейс', 'кейса', 'кейсов')} за ${formatCoins(total)}` : ''}`}
          </small>
        </button>
      ) : (
        <button
          type="button"
          className={cx('btn btn--lg btn--block case-page__open', keys > 0 ? 'btn--ghost' : 'btn--primary')}
          onClick={() => void (shareAndOpen ? shareThenOpen() : open(false, n))}
          disabled={busy || cooling || frozen || (gated && !shareAndOpen) || freeShare.sharing}
          data-tour={free ? 'free-open' : undefined}
        >
          {shareAndOpen ? (
            <>
              <Icon name="send" size={18} /> {freeShare.sharing ? 'Отправляем…' : 'Поделиться и открыть'}
            </>
          ) : (
            <>
              {label} {ticketPrice ? <Ticket size={18} /> : !costless && <Coin size={18} />}
            </>
          )}
        </button>
      )}
      <p className="hint">
        {frozen
          ? 'Аккаунт заморожен — открывать кейсы нельзя'
          : free
            ? shareAndOpen
              ? 'Отправь BrainrotCrash в любой чат — и кейс сразу откроется'
              : gated && !cooling
              ? 'Выполни условия выше — и кейс твой'
              : 'Бесплатный кейс можно открывать раз в 12 часов'
            : nick
              ? 'Кейс за ник открывается раз в 12 часов'
              : referral
                ? 'Один раз на аккаунт: когда приходишь по ссылке друга или когда к тебе приходит первый друг'
                : ticketPrice
                  ? `Открывается только за тикеты из заданий · у тебя ${formatCoins(me.user.tickets)}`
                : n > 1
                  ? `${pool.length} предметов внутри · у каждого из ${n} кейсов свой дроп`
                  : `${pool.length} предметов внутри`}
        {kase.mystery && ' · мистери: дроп скрыт до остановки'}
      </p>

      <h2 className="section-title">Возможные призы</h2>
      <div className="grid">
        {prizes.map((p) => (
          <BrainrotCard key={p.brainrot.id} brainrot={p.brainrot} />
        ))}
      </div>

      {opening && (
        <CaseOpening
          key={opening.key}
          kase={kase}
          pool={pool}
          wins={opening.wins}
          demo={opening.demo}
          me={opening.me}
          mode={mode}
          again={frozen ? 'none' : againKey ? 'spin' : costless ? 'none' : againShort > 0 ? 'deposit' : 'spin'}
          againPrice={againTotal}
          againCount={againCount}
          againShort={againShort}
          againBusy={busy}
          onClose={() => setOpening(null)}
          onAgain={() => void open(againKey, againCount)}
          onDeposit={() => {
            setOpening(null);
            openSheet('deposit');
          }}
        />
      )}
    </section>
  );
}
