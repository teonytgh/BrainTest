/** A stake is all demo or all the player's own (the server refuses a mix: `mixed_demo`). */
export const MIXED_DEMO = 'Демо-брейнроты ставятся только вместе с демо — убери свои или демо';

/** Would adding `item` mix demo and real brainrots in one stake? */
export function mixesDemo(picked: readonly { demo?: boolean }[], item: { demo?: boolean }): boolean {
  return picked.some((p) => !!p.demo !== !!item.demo);
}
