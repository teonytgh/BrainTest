export type BrainrotStatus = 'active' | 'hidden' | 'disabled' | 'deleted';

export interface Brainrot {
  id: string;
  name: string;
  price: number;
  image: string;
  status: BrainrotStatus;
  /** Admins can keep a brainrot in the catalog but out of withdrawals. */
  withdrawable: boolean;
  /** 'coins': a coin prize — drops from cases like a brainrot, but its price goes straight to the balance. */
  kind: 'brainrot' | 'coins';
}

export interface CaseItem {
  brainrotId: string;
  weight: number;
  /** Admin only: the hand-set chance (0…1, 0 = «Невозможно»); null = from prices. */
  fixed?: number | null;
}

/** A group of cases on the home page («тема»). */
export interface CaseSection {
  id: number;
  title: string;
  sort: number;
}

export interface CaseDef {
  id: string;
  name: string;
  price: number;
  image: string;
  /** bonus = opened from «Бонусы» only (not on the home grid, not in battles); tickets = opened for quest tickets only. */
  kind: 'paid' | 'free' | 'bonus' | 'tickets';
  /** The price in tickets of a `tickets` case (null for the others). */
  ticketPrice: number | null;
  /** Which bonus rule opens it: referral → keys for invited friends, nick → the name tag every 12 hours. */
  bonus: 'referral' | 'nick' | null;
  status: 'active' | 'hidden';
  sort: number;
  /** Mystery cases hide the reel until the drop lands. */
  mystery: boolean;
  /** Home page section; null = the first one. */
  sectionId: number | null;
  /** The «НОВЫЙ» / «РЕДИЗАЙН» ribbon while it lasts (its end for admins only). */
  badge: 'new' | 'redesign' | null;
  badgeUntil: number | null;
  /** A floating price («Биткоин»): the prices it moves between every 5–10 minutes, and its last ones (oldest first). */
  priceCycle: number[] | null;
  priceHistory: number[] | null;
  /** weight = drop probability, derived from current prices. */
  items: CaseItem[];
}

export type MediaPlatform = 'tiktok' | 'youtube' | 'twitch';

export const MEDIA_PLATFORMS: readonly MediaPlatform[] = ['tiktok', 'youtube', 'twitch'];

export const FREE_CASE_COOLDOWN_MS = 12 * 60 * 60 * 1000;
