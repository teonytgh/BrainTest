CREATE TABLE star_orders (
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT NOT NULL REFERENCES users (id),
  stars INT NOT NULL CHECK (stars > 0),
  coins BIGINT NOT NULL CHECK (coins > 0),
  bonus BIGINT NOT NULL DEFAULT 0 CHECK (bonus >= 0),
  bonus_percent INT NOT NULL DEFAULT 0,
  promo_code TEXT,
  promo_window BIGINT,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'paid')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  paid_at TIMESTAMPTZ
);
CREATE INDEX star_orders_user ON star_orders (user_id, created_at DESC);

-- One row per Telegram charge: redelivered webhooks hit the primary key and are credited once.
CREATE TABLE star_payments (
  charge_id TEXT PRIMARY KEY,
  order_id BIGINT NOT NULL REFERENCES star_orders (id),
  user_id BIGINT NOT NULL REFERENCES users (id),
  stars INT NOT NULL,
  credited BIGINT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX star_payments_created ON star_payments (created_at DESC);

ALTER TABLE users ADD COLUMN support_at TIMESTAMPTZ;

INSERT INTO settings (key, value) VALUES ('stars', '{"rate": 1.35}') ON CONFLICT (key) DO NOTHING;
