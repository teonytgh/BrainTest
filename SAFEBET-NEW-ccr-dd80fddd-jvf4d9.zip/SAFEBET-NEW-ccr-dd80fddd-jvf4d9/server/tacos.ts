import { assertActive, type Viewer } from './auth';
import { ms, one, tx } from './db';
import { addCoins, addWager } from './economy';
import { bad } from './errors';
import { getSettings } from './settings';
import { secureRandom } from '../shared/random';
import {
  TACO_CATCHES_PER_DAY,
  TACO_CATCH_COOLDOWN_MS,
  TACO_COIN_AMOUNT,
  TACO_COIN_CHANCE,
  tacoDay,
  tacosActive,
} from '../shared/tacos';

interface TacoRow {
  taco_catch_at: string | null;
  taco_catches: number;
  taco_day: string | null;
}

export interface TacosState {
  /** The party is live (null = not running). */
  endsAt: number | null;
  caughtToday: number;
  capPerDay: number;
  cooldownMs: number;
  /** Earliest the next catch is allowed (ms since epoch). */
  nextAt: number;
  coinChance: number;
  coinAmount: number;
}

/** How many of today's catches a player has used, and when the next one is allowed. */
async function catchProgress(userId: number, now: number): Promise<{ caughtToday: number; nextAt: number }> {
  const row = await one<TacoRow>('SELECT taco_catch_at, taco_catches, taco_day FROM users WHERE id = $1', [userId]);
  const today = tacoDay(now);
  const caughtToday = row && row.taco_day === today ? row.taco_catches : 0;
  const last = (row?.taco_catch_at ? ms(row.taco_catch_at) : 0) ?? 0;
  return { caughtToday, nextAt: last + TACO_CATCH_COOLDOWN_MS };
}

export async function tacosState(v: Viewer): Promise<TacosState> {
  const { tacos } = await getSettings();
  const now = Date.now();
  const { caughtToday, nextAt } = await catchProgress(v.id, now);
  return {
    endsAt: tacosActive(tacos, now) ? tacos.endsAt : null,
    caughtToday,
    capPerDay: TACO_CATCHES_PER_DAY,
    cooldownMs: TACO_CATCH_COOLDOWN_MS,
    nextAt,
    coinChance: TACO_COIN_CHANCE,
    coinAmount: TACO_COIN_AMOUNT,
  };
}

export interface CaughtTaco {
  coins: number;
  caughtToday: number;
  capPerDay: number;
  nextAt: number;
}

/**
 * Catch one coin-taco. The event must be live; a player gets one catch per cooldown and at most the daily cap,
 * and each catch pays `TACO_COIN_AMOUNT` with chance `TACO_COIN_CHANCE` (otherwise it is just a tasty taco). The
 * row is locked so two taps in flight can't both score.
 */
export async function catchTaco(v: Viewer): Promise<CaughtTaco> {
  assertActive(v);
  const { tacos } = await getSettings();
  const now = Date.now();
  if (!tacosActive(tacos, now)) throw bad('tacos_off', 'Вечеринка Raining Tacos сейчас не идёт');
  return tx(async (c) => {
    const row = (await c.query<TacoRow>('SELECT taco_catch_at, taco_catches, taco_day FROM users WHERE id = $1 FOR UPDATE', [v.id])).rows[0];
    const today = tacoDay(now);
    const caughtToday = row && row.taco_day === today ? row.taco_catches : 0;
    const last = (row?.taco_catch_at ? ms(row.taco_catch_at) : 0) ?? 0;
    if (now < last + TACO_CATCH_COOLDOWN_MS) throw bad('cooldown', 'Лови тако чуть помедленнее 🌮');
    if (caughtToday >= TACO_CATCHES_PER_DAY) throw bad('taco_cap', 'На сегодня тако наловил вдоволь — заходи завтра');
    const coins = secureRandom() < TACO_COIN_CHANCE ? TACO_COIN_AMOUNT : 0;
    const caught = caughtToday + 1;
    await c.query('UPDATE users SET taco_catch_at = now(), taco_catches = $2, taco_day = $3 WHERE id = $1', [v.id, caught, today]);
    if (coins) {
      await addCoins(c, v.id, coins);
      await addWager(c, v.id, coins, 'bonus');
    }
    return { coins, caughtToday: caught, capPerDay: TACO_CATCHES_PER_DAY, nextAt: now + TACO_CATCH_COOLDOWN_MS };
  });
}
