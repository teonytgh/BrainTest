export type Tier = 'common' | 'rare' | 'epic' | 'legendary' | 'secret';

export function tierOf(price: number): Tier {
  if (price < 50) return 'common';
  if (price < 300) return 'rare';
  if (price < 2000) return 'epic';
  if (price < 10000) return 'legendary';
  return 'secret';
}

export const TIER_LABEL: Record<Tier, string> = {
  common: 'Обычный',
  rare: 'Редкий',
  epic: 'Эпический',
  legendary: 'Легендарный',
  secret: 'Секретный',
};
