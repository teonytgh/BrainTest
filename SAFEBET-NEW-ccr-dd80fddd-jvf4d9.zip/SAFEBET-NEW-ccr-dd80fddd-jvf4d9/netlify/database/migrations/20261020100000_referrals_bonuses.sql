-- Iteration 6: referral system, bonus cases (referral / nick), weekly cashback, consolation case.

ALTER TABLE users
  ADD COLUMN ref_code TEXT,
  ADD COLUMN referred_by BIGINT REFERENCES users (id),
  ADD COLUMN referred_at TIMESTAMPTZ,
  ADD COLUMN ref_balance NUMERIC(16, 2) NOT NULL DEFAULT 0 CHECK (ref_balance >= 0),
  ADD COLUMN ref_bonus_paid BOOLEAN NOT NULL DEFAULT false,
  -- RevShare carries a losing week (the friends won) into the next ones: only the net house result is shared.
  ADD COLUMN ref_carry NUMERIC(16, 2) NOT NULL DEFAULT 0 CHECK (ref_carry <= 0),
  ADD COLUMN ref_code_changed_at TIMESTAMPTZ,
  ADD COLUMN nick_case_at TIMESTAMPTZ;
CREATE UNIQUE INDEX users_ref_code ON users (lower(ref_code));
CREATE INDEX users_referred_by ON users (referred_by) WHERE referred_by IS NOT NULL;

-- Codes a player used before: they keep pointing at their owner, so a changed code can't be taken over
-- (every link shared earlier still binds to the right person).
CREATE TABLE ref_code_history (
  code_lc TEXT PRIMARY KEY,
  user_id BIGINT NOT NULL REFERENCES users (id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- One row per person who opened someone's link (the «Переходы» counter).
CREATE TABLE ref_clicks (
  referrer_id BIGINT NOT NULL REFERENCES users (id) ON DELETE CASCADE,
  visitor_id BIGINT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (referrer_id, visitor_id)
);

-- Money a referrer earned: weekly RevShare per referral, or the first-deposit bonus.
CREATE TABLE ref_payouts (
  id BIGSERIAL PRIMARY KEY,
  referrer_id BIGINT NOT NULL REFERENCES users (id),
  referral_id BIGINT REFERENCES users (id),
  kind TEXT NOT NULL CHECK (kind IN ('revshare', 'deposit_bonus')),
  amount NUMERIC(16, 2) NOT NULL CHECK (amount > 0),
  period_end TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ref_payouts_referrer ON ref_payouts (referrer_id, created_at DESC);

-- What a bet paid back (item value + coins). NULL on older rows: they stay out of RevShare and cashback.
ALTER TABLE drops ADD COLUMN payout_value NUMERIC(16, 2);
CREATE INDEX drops_user_paid ON drops (user_id, created_at) WHERE payout_value IS NOT NULL AND stake_value > 0 AND game IN ('case', 'battle');

-- Bonus cases live outside the home grid and battles.
ALTER TABLE cases DROP CONSTRAINT cases_kind_check;
ALTER TABLE cases ADD CONSTRAINT cases_kind_check CHECK (kind IN ('paid', 'free', 'bonus'));
ALTER TABLE cases ADD COLUMN bonus TEXT CHECK (bonus IN ('referral', 'nick'));
INSERT INTO cases (id, name, price, image, kind, status, sort, bonus) VALUES
  ('referral', 'Реферальный', 0, '/cases/referral.svg', 'bonus', 'active', 900, 'referral'),
  ('nick', 'За ник', 0, '/cases/nick.svg', 'bonus', 'active', 901, 'nick')
ON CONFLICT (id) DO NOTHING;
-- Start from the free case's contents; the healer re-composes them for the current prices on the next tick.
INSERT INTO case_items (case_id, brainrot_id, weight)
SELECT c.id, ci.brainrot_id, 1 FROM case_items ci CROSS JOIN (VALUES ('referral'), ('nick')) AS c (id)
WHERE ci.case_id = 'free'
ON CONFLICT DO NOTHING;

-- Players' own promo codes (paid from their balance up front) and case rewards.
ALTER TABLE promo_codes
  ADD COLUMN owner_id BIGINT REFERENCES users (id),
  ADD COLUMN reward_case_id TEXT REFERENCES cases (id) ON DELETE SET NULL,
  ADD COLUMN unit_cost NUMERIC(16, 2);
ALTER TABLE promo_codes DROP CONSTRAINT promo_codes_reward_type_check;
ALTER TABLE promo_codes ADD CONSTRAINT promo_codes_reward_type_check CHECK (reward_type IN ('coins', 'brainrot', 'case'));
CREATE INDEX promo_codes_owner ON promo_codes (owner_id) WHERE owner_id IS NOT NULL;

-- Weekly cashback claims (week = Monday 00:00 MSK index).
CREATE TABLE cashback_claims (
  user_id BIGINT NOT NULL REFERENCES users (id),
  week BIGINT NOT NULL,
  amount NUMERIC(16, 2) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, week)
);

-- A free consolation spin after losing a big upgrade.
CREATE TABLE consolations (
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT NOT NULL REFERENCES users (id),
  stake_value NUMERIC(16, 2) NOT NULL,
  coins NUMERIC(16, 2),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  opened_at TIMESTAMPTZ
);
CREATE INDEX consolations_user ON consolations (user_id, created_at DESC);
