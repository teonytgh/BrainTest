import oklab from '@csstools/postcss-oklab-function';

// Emits rgb() fallbacks next to every oklch() so older Telegram WebViews still get the palette.
export default {
  plugins: [oklab({ preserve: true })],
};
