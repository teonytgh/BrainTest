import { HOUSE_GAMES, weekIndex, weekStart } from '../shared/bonuses';
import { round2 } from '../shared/money';
import { FRIEND_QUEST_TURNOVER, buildQuestSet, dayIndex, dayStart, type Quest, type QuestCase, type QuestKind, type QuestView } from '../shared/quests';
import { assertActive, type Viewer } from './auth';
import { ensureSchema } from './autoMigrate';
import { num, tx, type Queryable } from './db';
import { bad, notFound } from './errors';
import { str } from './validate';

const HOUSE = HOUSE_GAMES.map((g) => `'${g}'`).join(', ');

/** The current period of a kind of quest: its key (for the once-only claim and the stored set), number, start, end. */
function periodOf(kind: QuestKind, now: number) {
  if (kind === 'daily') {
    const d = dayIndex(now);
    return { key: `d${d}`, index: d, from: dayStart(d), to: dayStart(d + 1) };
  }
  const w = weekIndex(now);
  return { key: `w${w}`, index: w, from: weekStart(w), to: weekStart(w + 1) };
}

type Period = ReturnType<typeof periodOf>;

/**
 * The period's quests: built once from the paid cases on the catalog and stored, so they stay the same all day / week
 * whatever admins change (two requests at once: one insert wins, both read it back).
 */
async function questSet(c: Queryable, kind: QuestKind, p: Period): Promise<Quest[]> {
  const read = async () => (await c.query<{ quests: Quest[] }>('SELECT quests FROM quest_sets WHERE period = $1', [p.key])).rows[0]?.quests;
  const stored = await read();
  if (stored) return stored;
  const cases = (
    await c.query<{ id: string; name: string; price: string; image: string }>(
      `SELECT id, name, price, image FROM cases WHERE status = 'active' AND kind = 'paid' AND bonus IS NULL AND price > 0`,
    )
  ).rows.map((r): QuestCase => ({ id: r.id, name: r.name, price: num(r.price), image: r.image }));
  const built = buildQuestSet(kind, p.index, cases);
  await c.query('INSERT INTO quest_sets (period, quests) VALUES ($1, $2::jsonb) ON CONFLICT DO NOTHING', [p.key, JSON.stringify(built)]);
  return (await read()) ?? built;
}

/**
 * One SQL expression per quest (its progress), with its parameters appended to `params`. $1 = the player; game names
 * come from the fixed list in shared/quests.ts, case ids and times are parameters.
 */
function progressSql(q: Quest, p: Period, params: unknown[]): string {
  const arg = (v: unknown) => {
    params.push(v);
    return `$${params.length}`;
  };
  const from = arg(new Date(p.from));
  const to = arg(new Date(p.to));
  // Demo games (iteration 35) never count.
  const paid = `user_id = $1 AND stake_value > 0 AND NOT demo AND created_at >= ${from} AND created_at < ${to}`;
  switch (q.type) {
    case 'case_open':
      return `(SELECT count(*) FROM drops WHERE ${paid} AND game = 'case' AND meta->>'caseId' = ${arg(q.caseId)})`;
    case 'turnover':
      return `(SELECT coalesce(sum(stake_value), 0) FROM drops WHERE ${paid} AND game = ${arg(q.game)})`;
    case 'plays':
      return `(SELECT count(*) FROM drops WHERE ${paid} AND game = ${arg(q.game)} AND stake_value >= ${arg(q.minStake ?? 0)})`;
    case 'deposit':
      // Net: what came in this week minus what went out (a deposit taken straight back out counts for nothing).
      return `((SELECT coalesce(sum(credited), 0) FROM star_payments WHERE user_id = $1 AND created_at >= ${from} AND created_at < ${to})
        + (SELECT coalesce(sum(credited), 0) FROM item_deposits WHERE user_id = $1 AND status = 'credited' AND updated_at >= ${from} AND updated_at < ${to})
        - (SELECT coalesce(sum(value), 0) FROM withdrawals WHERE user_id = $1 AND status = 'done' AND processed_at >= ${from} AND processed_at < ${to}))`;
    case 'friend':
      return `(SELECT count(*) FROM users f WHERE f.referred_by = $1 AND
        (SELECT coalesce(sum(d.stake_value), 0) FROM drops d WHERE d.user_id = f.id AND d.game IN (${HOUSE}) AND d.stake_value > 0 AND NOT d.demo
           AND d.created_at >= ${from} AND d.created_at < ${to}) >= ${arg(FRIEND_QUEST_TURNOVER)})`;
    case 'days':
      return `(SELECT count(DISTINCT period) FROM quest_claims WHERE user_id = $1 AND currency = 'tickets' AND period LIKE 'd%'
        AND created_at >= ${from} AND created_at < ${to})`;
  }
}

/** Everything the page needs in one round trip after the sets: every quest's progress, the claims, the tickets. */
async function questsOf(c: Queryable, userId: number, now: number) {
  const day = periodOf('daily', now);
  const week = periodOf('weekly', now);
  const [daily, weekly] = [await questSet(c, 'daily', day), await questSet(c, 'weekly', week)];
  const all = [...daily.map((q) => ({ q, p: day })), ...weekly.map((q) => ({ q, p: week }))];
  const params: unknown[] = [userId];
  const cols = all.map(({ q, p }, i) => `${progressSql(q, p, params)} AS q${i}`);
  params.push([day.key, week.key]);
  const { rows } = await c.query<Record<string, string> & { tickets: number; claims: string[] | null }>(
    `SELECT ${cols.join(', ')},
       (SELECT tickets FROM users WHERE id = $1) AS tickets,
       (SELECT json_agg(quest || ':' || period) FROM quest_claims WHERE user_id = $1 AND period = ANY($${params.length})) AS claims`,
    params,
  );
  const r = rows[0]!;
  const claimed = new Set(r.claims ?? []);
  const quests = all.map(({ q, p }, i): QuestView => ({ ...q, progress: round2(num(r[`q${i}`])), claimed: claimed.has(`${q.id}:${p.key}`), endsAt: p.to }));
  return { tickets: num(r.tickets), quests };
}

export async function questsState(v: Viewer) {
  await ensureSchema();
  return tx((c) => questsOf(c, v.id, Date.now()));
}

/** Takes a finished quest's tickets, once per period (the primary key settles double taps). */
export async function claimQuest(v: Viewer, idParam: string) {
  assertActive(v);
  await ensureSchema();
  const id = str(idParam, 'задание', 1, 8);
  if (!/^[dw]\d$/.test(id)) throw notFound('Такого задания нет');
  return tx(async (c) => {
    const now = Date.now();
    const state = await questsOf(c, v.id, now);
    const quest = state.quests.find((q) => q.id === id);
    if (!quest) throw notFound('Такого задания нет');
    if (quest.claimed) throw bad('claimed', 'Награда за это задание уже получена');
    if (quest.progress < quest.target) throw bad('not_done', 'Задание ещё не выполнено');
    const period = periodOf(quest.kind, now).key;
    const ins = await c.query(
      `INSERT INTO quest_claims (user_id, quest, period, reward, currency) VALUES ($1, $2, $3, $4, 'tickets') ON CONFLICT DO NOTHING RETURNING 1`,
      [v.id, quest.id, period, quest.reward],
    );
    if (!ins.rows.length) throw bad('claimed', 'Награда за это задание уже получена');
    await c.query('UPDATE users SET tickets = tickets + $2 WHERE id = $1', [v.id, quest.reward]);
    return { reward: quest.reward, ...(await questsOf(c, v.id, now)) };
  });
}
