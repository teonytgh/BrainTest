import { Icon, type IconName } from './Icon';
import { routeHref, useRoute, type RouteName } from '../lib/router';
import { openMenu, useUi } from '../store/ui';

/**
 * The phone's main sections within the thumb's reach (the owner's pick): Главная · Колор дайс · the upgrader — his
 * main game — raised in the middle · Профиль · Ещё (the full menu: every other game, bonuses, settings). The PC
 * layout has the sidebar instead.
 */
interface Tab {
  route: RouteName;
  label: string;
  icon: IconName;
  /** Other routes that light this tab up (a case page belongs to Главная). */
  also?: RouteName[];
}

const LEFT: Tab[] = [
  { route: 'home', label: 'Главная', icon: 'home', also: ['case'] },
  { route: 'dice', label: 'Дайсы', icon: 'dice' },
];
const RIGHT: Tab[] = [{ route: 'profile', label: 'Профиль', icon: 'user' }];

export function BottomNav() {
  const route = useRoute();
  const { menuOpen } = useUi();

  const link = (t: Tab) => (
    <a
      key={t.route}
      href={routeHref(t.route)}
      className="tabbar__item"
      aria-current={route.name === t.route || t.also?.includes(route.name) ? 'page' : undefined}
    >
      <Icon name={t.icon} size={22} />
      <span>{t.label}</span>
    </a>
  );

  return (
    <nav className="tabbar" aria-label="Основные разделы">
      {LEFT.map(link)}
      <a href={routeHref('upgrader')} data-tour="nav-upgrader" className="tabbar__item tabbar__item--main" aria-current={route.name === 'upgrader' ? 'page' : undefined}>
        <span className="tabbar__disc" aria-hidden="true">
          <Icon name="gauge" size={26} />
        </span>
        <span>Апгрейд</span>
      </a>
      {RIGHT.map(link)}
      <button type="button" className="tabbar__item" onClick={openMenu} aria-expanded={menuOpen} aria-haspopup="dialog">
        <Icon name="menu" size={22} />
        <span>Ещё</span>
      </button>
    </nav>
  );
}
