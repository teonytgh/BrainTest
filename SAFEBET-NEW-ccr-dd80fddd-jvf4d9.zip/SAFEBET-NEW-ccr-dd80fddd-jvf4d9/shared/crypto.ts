/**
 * Crypto deposits (iteration 38) through Crypto Pay (@CryptoBot): the player picks an amount in roubles, the invoice
 * is priced in RUB and paid in any of the accepted coins at CryptoBot's rate; we credit `rub × rate` coins (the owner:
 * «100 ₽ — 140 монет»). Like Stars: a deposit — wagered, counted for ranks, races and the referrer's share.
 */

export const CRYPTO_FIAT = 'RUB';
/** Coins a player can pay with (Crypto Pay asset codes). */
export const CRYPTO_ASSETS = ['USDT', 'TON', 'BTC', 'ETH', 'LTC', 'TRX', 'USDC', 'SOL'] as const;
/** Iteration 39 (the owner: «от 0,1 $ — то есть от 10 ₽»): small packs first. */
export const CRYPTO_RUB_PRESETS = [10, 50, 100, 500, 1000, 5000];
export const CRYPTO_RUB_MIN = 10;
export const CRYPTO_RUB_MAX = 200_000;
/** Coins per rouble by default (the owner's «100 ₽ — 140 монет»); owners change it in «Платежи». */
export const DEFAULT_CRYPTO_RATE = 1.4;
export const CRYPTO_RATE_MIN = 0.01;
export const CRYPTO_RATE_MAX = 100;

/** Integer maths in hundredths, like starsToCoins: 100 ₽ × 1.4 is 140, not 139.99… */
export function rubToCoins(rub: number, rate: number): number {
  return Math.floor((rub * Math.round(rate * 100)) / 100);
}
