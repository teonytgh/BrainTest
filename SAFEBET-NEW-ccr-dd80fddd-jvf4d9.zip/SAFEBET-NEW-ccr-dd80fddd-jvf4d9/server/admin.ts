import { AUTO_PROMO_WORDS, currentPromo } from '../shared/promo';
import { MIN_FIXED_CHANCE, OKUP_CUTS } from '../shared/cases';
import { STAR_RATE_MAX, STAR_RATE_MIN } from '../shared/stars';
import { CRYPTO_RATE_MAX, CRYPTO_RATE_MIN } from '../shared/crypto';
import { MEDIA_PLATFORMS, type MediaPlatform } from '../shared/types';
import type { Viewer } from './auth';
import { allBrainrots, allCases, caseSections } from './catalog';
import { ensureSchema } from './autoMigrate';
import { caseReport, healCases, SYSTEM_ADMIN_ID } from './caseHealth';
import { priceCycleOf, setPriceCycle } from './floatingPrice';
import { ANNOUNCE_OPEN, CAPTION_MAX, MESSAGE_MAX, announceHtml, deliver, luckBroadcast, queueBroadcast, recentBroadcasts, stopBroadcast, type Outgoing } from './notifications';
import { ms, num, one, q, tx, type Queryable } from './db';
import { addCoins, addWager, giveItems } from './economy';
import { OWNER_IDS, isOwnerId } from './env';
import { HttpError, bad, forbidden, notFound } from './errors';
import { promoKey } from './games';
import { touch } from './live';
import { codeTaken } from './referrals';
import { notStaff } from './staff';
import { getSettings, luckMultiplier, setSetting } from './settings';
import { EVENT_IDS, MAX_EVENT_MINUTES, MAX_SNAP_MINUTES, SNAP_DEFAULT_EVENTS, type EventId } from '../shared/events';
import { tacosActive } from '../shared/tacos';
import { MAX_WAGER_MULTIPLIER } from '../shared/withdraw';
import { SHOUT_COLORS, SHOUT_COOLDOWN_MS, SHOUT_MAX, type Shout } from '../shared/shout';
import { rankOf } from '../shared/ranks';
import { isImageUrl, saveUpload } from './storage';
import { escapeHtml, notify } from './telegram';
import { displayName, getUser, resolveUser, type UserRow } from './users';
import { bool, ids, int, money, oneOf, optStr, robloxNick, str, type Body } from './validate';

const ACTIVE = `p.revoked_at IS NULL AND (p.until IS NULL OR p.until > now())`;

async function log(c: Queryable, admin: Viewer, action: string, target: number | null, details: Record<string, unknown> = {}) {
  await c.query('INSERT INTO admin_log (admin_id, action, target_user, details) VALUES ($1, $2, $3, $4::jsonb)', [
    admin.id,
    action,
    target,
    JSON.stringify(details),
  ]);
}

const userBrief = (u: UserRow) => ({
  id: num(u.id),
  publicId: u.public_id,
  username: u.username,
  name: [u.first_name, u.last_name].filter(Boolean).join(' '),
  photoUrl: u.photo_url,
  balance: num(u.balance),
  media: u.media_platform,
  lastSeen: ms(u.last_seen_at),
  display: displayName(u),
});

const mskDate = new Intl.DateTimeFormat('ru-RU', { timeZone: 'Europe/Moscow', dateStyle: 'long', timeStyle: 'short' });
const untilText = (until: number | null) => (until === null ? 'навсегда' : `до ${mskDate.format(until)} (МСК)`);

function assertCanPunish(admin: Viewer, target: UserRow, isTargetAdmin: boolean) {
  const id = num(target.id);
  if (isOwnerId(id)) throw forbidden('Владельца нельзя наказать');
  if (id === admin.id) throw forbidden('Нельзя наказать самого себя');
  if (isTargetAdmin && !admin.isOwner) throw forbidden('Админа может наказать только владелец');
}

async function isAdminId(id: number) {
  return isOwnerId(id) || !!(await one('SELECT 1 FROM admins WHERE user_id = $1', [id]));
}

// ---------- Overview ----------

export async function stats() {
  const r = await one<Record<string, string>>(
    `SELECT
       (SELECT count(*) FROM users u WHERE ${notStaff('u.id')}) AS users,
       (SELECT count(*) FROM users u WHERE last_seen_at > now() - interval '24 hours' AND ${notStaff('u.id')}) AS active24,
       (SELECT coalesce(sum(balance), 0) FROM users u WHERE ${notStaff('u.id')}) AS coins,
       (SELECT count(*) FROM inventory) AS items,
       (SELECT count(*) FROM drops WHERE created_at > now() - interval '24 hours') AS games24,
       (SELECT count(*) FROM drops WHERE game = 'case') AS cases_total,
       (SELECT count(*) FROM withdrawals WHERE status IN ('pending', 'scheduled', 'trading', 'expired')) AS withdrawals,
       (SELECT count(*) FROM punishments p WHERE p.kind = 'ban' AND ${ACTIVE}) AS bans,
       (SELECT count(*) FROM punishments p WHERE p.kind = 'freeze' AND ${ACTIVE}) AS freezes,
       (SELECT coalesce(sum(stars), 0) FROM star_payments) AS stars,
       (SELECT coalesce(sum(stars), 0) FROM star_payments WHERE created_at > now() - interval '24 hours') AS stars24`,
  );
  return Object.fromEntries(Object.entries(r ?? {}).map(([k, v]) => [k, num(v)]));
}

// ---------- Users ----------

export async function searchUsers(query: string | null) {
  const s = (query ?? '').trim().replace(/^@/, '');
  let rows: UserRow[];
  if (!s) rows = await q<UserRow>('SELECT * FROM users ORDER BY last_seen_at DESC LIMIT 30');
  else if (/^\d+$/.test(s)) rows = await q<UserRow>('SELECT * FROM users WHERE id::text LIKE $1 ORDER BY last_seen_at DESC LIMIT 30', [`${s}%`]);
  else
    rows = await q<UserRow>(
      `SELECT * FROM users WHERE username_lc LIKE $1 OR lower(first_name) LIKE $1 OR public_id = upper($2)
       ORDER BY last_seen_at DESC LIMIT 30`,
      [`${s.toLowerCase().replace(/[%_]/g, '')}%`, s],
    );
  return rows.map(userBrief);
}

export async function userDetail(idParam: string) {
  const id = int(idParam, 'ID');
  await ensureSchema();
  const user = await getUser(id);
  if (!user) throw notFound('Пользователь не найден');
  const [inventory, punishments, titles, withdrawals, admin] = await Promise.all([
    q<{ id: string; brainrot_id: string; source: string; created_at: string; demo: boolean }>(
      'SELECT id, brainrot_id, source, created_at, demo FROM inventory WHERE user_id = $1 ORDER BY id DESC',
      [id],
    ),
    q<{ id: string; kind: string; until: string | null; reason: string | null; created_at: string; revoked_at: string | null; active: boolean }>(
      `SELECT p.*, (${ACTIVE}) AS active FROM punishments p WHERE p.user_id = $1 ORDER BY p.id DESC LIMIT 20`,
      [id],
    ),
    q<{ id: string; name: string }>('SELECT t.id, t.name FROM user_titles ut JOIN titles t ON t.id = ut.title_id WHERE ut.user_id = $1', [id]),
    q<{ id: string; brainrot_id: string; status: string; value: string; created_at: string }>(
      'SELECT id, brainrot_id, status, value, created_at FROM withdrawals WHERE user_id = $1 ORDER BY id DESC LIMIT 20',
      [id],
    ),
    isAdminId(id),
  ]);
  const growth = await one<{ deposited: string; source: string | null }>(
    `SELECT (SELECT coalesce(sum(p.credited), 0) FROM star_payments p WHERE p.user_id = $1)
       + (SELECT coalesce(sum(d.credited), 0) FROM item_deposits d WHERE d.user_id = $1 AND d.status = 'credited') AS deposited,
       (SELECT source FROM users WHERE id = $1) AS source`,
    [id],
  );
  const deposited = num(growth?.deposited);
  return {
    user: {
      ...userBrief(user),
      isAdmin: admin,
      isOwner: isOwnerId(id),
      stats: { cases: user.cases_opened, upgrades: user.upgrades, dice: user.dice_rolls, crash: user.crash_rounds, withdrawn: num(user.withdrawn_value) },
      deposited,
      rank: rankOf(deposited).level,
      /** The traffic source's tag (owner «Источники») this player came with. */
      source: growth?.source ?? null,
      /** The partner's own referral percent (owners set it), null = the usual levels. */
      refPercent: user.ref_percent == null ? null : num(user.ref_percent),
      /** The demo part of the balance (iteration 35: «для демо» gifts and what demo games paid in coins). */
      demoBalance: num(user.demo_balance ?? 0),
      /** «Отыгрыш» (iteration 36): left to play before a withdrawal, of the current round. */
      wager: { left: num(user.wager_left ?? 0), total: num(user.wager_total ?? 0) },
    },
    inventory: inventory.map((i) => ({ id: num(i.id), brainrotId: i.brainrot_id, source: i.source, at: ms(i.created_at), demo: i.demo === true })),
    punishments: punishments.map((p) => ({ id: num(p.id), kind: p.kind, until: ms(p.until), reason: p.reason, at: ms(p.created_at), revokedAt: ms(p.revoked_at), active: p.active })),
    titles: titles.map((t) => ({ id: num(t.id), name: t.name })),
    withdrawals: withdrawals.map((w) => ({ id: num(w.id), brainrotId: w.brainrot_id, status: w.status, value: num(w.value), at: ms(w.created_at) })),
  };
}

export async function give(admin: Viewer, body: Body) {
  const user = await resolveUser(body.user);
  const uid = num(user.id);
  const type = oneOf(body.type, 'тип', ['coins', 'brainrot', 'case'] as const);
  // «Для демо» (iteration 35): the gift plays like any other but never leaves the game, nor does what it wins.
  const demo = body.demo === true;
  // A real gift is free value: played through ×wagerBonus before a withdrawal, unless the admin says it is owed
  // (a compensation, a prize handed out by hand) — «без отыгрыша». Gift keys count through their drops.
  // Only an owner gives without it: an admin could otherwise hand out coins that leave at once.
  if (body.noWager === true && !admin.isOwner) throw forbidden('«Без отыгрыша» выдаёт только владелец');
  const wager = !demo && body.noWager !== true;
  const mark = demo ? ' (демо)' : '';
  let text: string;
  if (type === 'coins') {
    const amount = money(body.amount, 'количество монет');
    await tx(async (c) => {
      await addCoins(c, uid, amount, demo);
      if (wager) await addWager(c, uid, amount, 'bonus');
      await log(c, admin, 'give_coins', uid, { amount, demo: demo || undefined, noWager: (!demo && !wager) || undefined });
    });
    text = `${amount} B${mark}`;
  } else if (type === 'case') {
    const count = int(body.amount, 'количество', 1, 100);
    const k = await one<{ id: string; name: string }>('SELECT id, name FROM cases WHERE id = $1', [str(body.caseId, 'кейс', 1, 80)]);
    if (!k) throw notFound('Кейс не найден');
    await tx(async (c) => {
      await c.query(
        `INSERT INTO case_keys (user_id, case_id, count, demo_count) VALUES ($1, $2, $3, $4)
         ON CONFLICT (user_id, case_id) DO UPDATE SET count = case_keys.count + EXCLUDED.count, demo_count = case_keys.demo_count + EXCLUDED.demo_count`,
        [uid, k.id, count, demo ? count : 0],
      );
      await log(c, admin, 'give_case', uid, { id: k.id, count, demo: demo || undefined });
    });
    text = `кейс «${k.name}»${count > 1 ? ` ×${count}` : ''}${mark} — открытие бесплатно`;
  } else {
    const count = int(body.amount, 'количество', 1, 100);
    const b = await one<{ id: string; name: string; price: string }>(
      `SELECT id, name, price FROM brainrots WHERE id = $1 AND status <> 'deleted' AND kind = 'brainrot'`,
      [str(body.brainrotId, 'брейнрот', 1, 80)],
    );
    if (!b) throw notFound('Брейнрот не найден');
    await tx(async (c) => {
      await giveItems(c, uid, b.id, 'admin', count, demo);
      if (wager) await addWager(c, uid, num(b.price) * count, 'bonus');
      await log(c, admin, 'give_brainrot', uid, { brainrotId: b.id, count, demo: demo || undefined, noWager: (!demo && !wager) || undefined });
    });
    text = (count > 1 ? `${b.name} ×${count}` : b.name) + mark;
  }
  const notified = await notify(
    uid,
    `🎁 Тебе выдано: <b>${escapeHtml(text)}</b>\n${demo ? 'Это демо: играть можно, вывести — нет.\n' : ''}Загляни в профиль BrainrotCrash.`,
  );
  return { user: userBrief(user), given: text, notified, demo };
}

/**
 * «Анонс в игре» (iteration 37): every open app shows the line on top with this admin's photo, name and a sound
 * (it rides with the catalog — this admin write broadcasts it). One at a time: SHOUT_COOLDOWN_MS between two.
 */
export async function shout(admin: Viewer, body: Body) {
  const text = str(body.text, 'текст анонса', 1, SHOUT_MAX).replace(/\s+/g, ' ').trim();
  const color = body.color === undefined ? 'accent' : oneOf(body.color, 'цвет', SHOUT_COLORS);
  return tx(async (c) => {
    // Two admins at once: the lock makes the cooldown hold.
    await c.query(`SELECT pg_advisory_xact_lock(hashtext('shout'))`);
    const { shout: last } = await getSettings(c);
    const now = Date.now();
    if (last && now - last.at < SHOUT_COOLDOWN_MS) {
      throw bad('too_soon', `Предыдущий анонс ещё на экране — подожди ${Math.ceil((SHOUT_COOLDOWN_MS - (now - last.at)) / 1000)} с`);
    }
    const prof = (await c.query<{ first_name: string; last_name: string | null; photo_url: string | null }>('SELECT first_name, last_name, photo_url FROM users WHERE id = $1', [admin.id])).rows[0];
    const value: Shout = {
      text,
      color,
      authorName: [prof?.first_name, prof?.last_name].filter(Boolean).join(' ') || 'BrainrotCrash',
      authorPhoto: prof?.photo_url ?? null,
      at: now,
    };
    await setSetting(c, 'shout', value);
    await log(c, admin, 'shout', null, { text, color });
    return { shout: value };
  });
}

/** Immortality for trailers (iteration 37): this admin's own switch; the next room pass carries it. */
/** «Очистить топ дроп дня» (iteration 41): the top drop of the day counts from now on; nothing is deleted. */
export async function resetTopDrop(admin: Viewer) {
  await tx(async (c) => {
    await setSetting(c, 'top_drop_since', Date.now());
    await log(c, admin, 'top_drop_reset', null, {});
  });
  return { ok: true };
}

export async function setImmortal(admin: Viewer, body: Body) {
  const on = bool(body.on);
  return tx(async (c) => {
    await c.query(`SELECT pg_advisory_xact_lock(hashtext('immortal'))`);
    const { immortal } = await getSettings(c);
    const next = on ? [...new Set([...immortal, admin.id])] : immortal.filter((id) => id !== admin.id);
    await setSetting(c, 'immortal', next);
    await log(c, admin, on ? 'immortal_on' : 'immortal_off', admin.id, {});
    return { on };
  });
}

/**
 * «Окуп в кейсах» (iteration 38, owners): every drop dearer than a paid case — hand-set chances too — × factor, for N
 * hours or until switched back (0 h). The freed chance goes to the cheaper drops, so cases pay less on average.
 */
export async function setOkupCut(admin: Viewer, body: Body) {
  if (!admin.isOwner) throw forbidden('Шанс окупа меняет только владелец');
  const factor = Number(body.factor);
  if (!(OKUP_CUTS as readonly number[]).includes(factor)) throw bad('invalid', 'Выбери множитель окупа');
  const hours = body.hours === undefined || body.hours === null ? 0 : int(body.hours, 'часы', 0, 720);
  const value = factor >= 1 ? { factor: 1, until: null } : { factor, until: hours ? Date.now() + hours * 3_600_000 : null };
  await tx(async (c) => {
    // «Без окупа» while a luck event promises a doubled окуп chance would make that promise false.
    const s = await getSettings(c);
    if (factor === 0 && luckMultiplier(s) > 1) throw bad('luck_running', 'Сейчас идёт удача — «Без окупа» можно включить после неё');
    await setSetting(c, 'okup_cut', value);
    await log(c, admin, 'okup_cut', null, value);
  });
  return { okupCut: value };
}

/** «Снять отыгрыш» (owners only): the player may withdraw at once; written to the log with what was left. */
export async function clearWager(admin: Viewer, idParam: string) {
  if (!admin.isOwner) throw forbidden('Снять отыгрыш может только владелец');
  const id = int(idParam, 'игрок');
  await ensureSchema();
  const left = await tx(async (c) => {
    const { rows } = await c.query<{ left: string }>(
      `UPDATE users u SET wager_left = 0, wager_total = 0 FROM (SELECT wager_left FROM users WHERE id = $1 FOR UPDATE) o
       WHERE u.id = $1 RETURNING o.wager_left AS left`,
      [id],
    );
    if (!rows[0]) throw notFound('Игрок не найден');
    await log(c, admin, 'wager_clear', id, { left: num(rows[0].left) });
    return num(rows[0].left);
  });
  touch(id, 'me');
  return { cleared: left };
}

export async function take(admin: Viewer, body: Body) {
  const uid = int(body.userId, 'пользователь');
  const coins = body.coins === undefined || body.coins === null || body.coins === '' ? 0 : money(body.coins, 'монеты');
  const itemIds = Array.isArray(body.itemIds) && body.itemIds.length ? ids(body.itemIds, 'предметы') : [];
  if (!coins && !itemIds.length) throw bad('invalid', 'Укажи монеты или предметы');
  // The same protection as punishments: owners are untouchable, admins answer only to an owner.
  if (isOwnerId(uid) && uid !== admin.id) throw forbidden('У владельца забирать нельзя');
  if (!admin.isOwner && uid !== admin.id && (await isAdminId(uid))) throw forbidden('У админа забирает только владелец');
  const result = await tx(async (c) => {
    let taken = 0;
    if (coins) {
      // What was really taken: the balance never goes below zero. Demo coins go first (usually what is taken back).
      const { rows } = await c.query<{ taken: string }>(
        `UPDATE users u SET balance = greatest(u.balance - $2, 0), demo_balance = greatest(u.demo_balance - $2, 0)
         FROM users o WHERE u.id = $1 AND o.id = u.id RETURNING least(o.balance, $2) AS taken`,
        [uid, coins],
      );
      taken = num(rows[0]?.taken);
    }
    const removed = itemIds.length
      ? (await c.query('DELETE FROM inventory WHERE user_id = $1 AND id = ANY($2::bigint[]) AND withdrawal_id IS NULL RETURNING id', [uid, itemIds])).rows.length
      : 0;
    await log(c, admin, 'take', uid, { coins: taken, items: removed });
    return { coins: taken, items: removed };
  });
  touch(uid, 'me');
  return result;
}

// ---------- Punishments ----------

function untilFrom(unit: 'day' | 'month' | 'year' | 'forever', amount: number): Date | null {
  if (unit === 'forever') return null;
  const d = new Date();
  if (unit === 'day') d.setUTCDate(d.getUTCDate() + amount);
  if (unit === 'month') d.setUTCMonth(d.getUTCMonth() + amount);
  if (unit === 'year') d.setUTCFullYear(d.getUTCFullYear() + amount);
  return d;
}

export async function punish(admin: Viewer, body: Body) {
  const kind = oneOf(body.kind, 'наказание', ['ban', 'freeze'] as const);
  const unit = oneOf(body.unit, 'срок', ['day', 'month', 'year', 'forever'] as const);
  const amount = unit === 'forever' ? 0 : int(body.amount, 'срок', 1, 1000);
  const reason = optStr(body.reason, 'причина', 200);
  const user = await resolveUser(body.user, { createById: true });
  const uid = num(user.id);
  assertCanPunish(admin, user, await isAdminId(uid));
  const until = untilFrom(unit, amount);
  const row = await tx(async (c) => {
    const { rows } = await c.query<{ id: string }>(
      'INSERT INTO punishments (user_id, kind, until, reason, created_by) VALUES ($1, $2, $3, $4, $5) RETURNING id',
      [uid, kind, until, reason, admin.id],
    );
    await log(c, admin, kind, uid, { until: until?.getTime() ?? null, reason });
    return rows[0]!;
  });
  const untilMs = until?.getTime() ?? null;
  const why = reason ? `\nПричина: ${escapeHtml(reason)}` : '';
  const text =
    kind === 'ban'
      ? `⛔️ Твой аккаунт в BrainrotCrash заблокирован ${untilText(untilMs)}.${why}\nМини-приложение недоступно до окончания блокировки.`
      : `❄️ Твой аккаунт в BrainrotCrash заморожен ${untilText(untilMs)}.${why}\nМожно заходить и смотреть, но играть, продавать и выводить нельзя.`;
  const notified = await notify(uid, text);
  return { id: num(row.id), user: userBrief(user), until: untilMs, notified };
}

export async function revokePunishment(admin: Viewer, idParam: string) {
  const id = int(idParam, 'ID');
  const target = await one<{ user_id: string }>('SELECT user_id FROM punishments WHERE id = $1', [id]);
  if (!target) throw notFound('Наказание не найдено');
  // Same rule as punishing: nobody lifts their own, and only an owner lifts one an admin is under.
  if (num(target.user_id) === admin.id) throw forbidden('Нельзя снять наказание с самого себя');
  if (!admin.isOwner && (await isAdminId(num(target.user_id)))) throw forbidden('С админа наказание снимает только владелец');
  const p = await tx(async (c) => {
    const { rows } = await c.query<{ user_id: string; kind: 'ban' | 'freeze' }>(
      'UPDATE punishments SET revoked_at = now(), revoked_by = $2 WHERE id = $1 AND revoked_at IS NULL RETURNING user_id, kind',
      [id, admin.id],
    );
    if (!rows[0]) throw notFound('Наказание уже снято');
    await log(c, admin, rows[0].kind === 'ban' ? 'unban' : 'unfreeze', num(rows[0].user_id), { punishmentId: id });
    return rows[0];
  });
  const notified = await notify(
    num(p.user_id),
    p.kind === 'ban' ? '✅ Блокировка аккаунта BrainrotCrash снята. Добро пожаловать обратно!' : '✅ Твой аккаунт BrainrotCrash разморожен — снова можно играть.',
  );
  return { ok: true, notified };
}

export async function punishments() {
  const rows = await q<UserRow & { pid: string; kind: string; until: string | null; reason: string | null; p_created: string; revoked_at: string | null; active: boolean; by_name: string | null }>(
    `SELECT u.*, p.id AS pid, p.kind, p.until, p.reason, p.created_at AS p_created, p.revoked_at, (${ACTIVE}) AS active,
       (SELECT coalesce('@' || a.username, a.first_name) FROM users a WHERE a.id = p.created_by) AS by_name
     FROM punishments p JOIN users u ON u.id = p.user_id ORDER BY (${ACTIVE}) DESC, p.id DESC LIMIT 200`,
  );
  return rows.map((r) => ({
    id: num(r.pid),
    kind: r.kind,
    until: ms(r.until),
    reason: r.reason,
    at: ms(r.p_created),
    revokedAt: ms(r.revoked_at),
    active: r.active,
    by: r.by_name,
    user: userBrief(r),
  }));
}

// ---------- Promo codes ----------

export async function promos() {
  const rows = await q<{ id: string; code: string; max_uses: number; uses: number; reward_type: string; reward_brainrot_id: string | null; reward_amount: string; created_at: string; by_name: string | null }>(
    `SELECT p.*, (SELECT coalesce('@' || a.username, a.first_name) FROM users a WHERE a.id = p.created_by) AS by_name
     FROM promo_codes p ORDER BY p.id DESC LIMIT 200`,
  );
  const auto = currentPromo();
  return {
    auto: { code: auto.code, percent: auto.percent, endsAt: auto.endsAt },
    codes: rows.map((r) => ({
      id: num(r.id),
      code: r.code,
      maxUses: r.max_uses,
      uses: r.uses,
      rewardType: r.reward_type,
      brainrotId: r.reward_brainrot_id,
      amount: num(r.reward_amount),
      at: ms(r.created_at),
      by: r.by_name,
    })),
  };
}

export async function createPromo(admin: Viewer, body: Body) {
  const code = str(body.code, 'название', 2, 40).replace(/\s+/g, ' ');
  if (!/^[\p{L}\p{N} _\-!.]+$/u.test(code)) throw bad('invalid', 'Название: буквы (рус/англ), цифры, пробел, - _ ! .');
  const key = promoKey(code);
  if (AUTO_PROMO_WORDS.some((w) => w.toLowerCase() === key)) throw bad('invalid', 'Это слово занято авто-промокодами');
  const maxUses = int(body.maxUses, 'активации', 1, 1_000_000);
  const rewardType = oneOf(body.rewardType, 'награда', ['coins', 'brainrot'] as const);
  const amount = int(body.amount, 'количество', 1, rewardType === 'coins' ? 100_000_000 : 100);
  let brainrotId: string | null = null;
  if (rewardType === 'brainrot') {
    const b = await one<{ id: string }>(`SELECT id FROM brainrots WHERE id = $1 AND status <> 'deleted' AND kind = 'brainrot'`, [str(body.brainrotId, 'брейнрот', 1, 80)]);
    if (!b) throw notFound('Брейнрот не найден');
    brainrotId = b.id;
  }
  try {
    return await tx(async (c) => {
      // Promo codes and players' partner codes share one namespace: never shadow somebody's referral code.
      if (await codeTaken(c, key)) throw new HttpError(409, 'exists', 'Такой код уже занят (промокод или код игрока)');
      const { rows } = await c.query<{ id: string }>(
        `INSERT INTO promo_codes (code, code_key, max_uses, reward_type, reward_brainrot_id, reward_amount, created_by)
         VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING id`,
        [code, key, maxUses, rewardType, brainrotId, amount, admin.id],
      );
      await log(c, admin, 'promo_create', null, { code, maxUses, rewardType, brainrotId, amount });
      return { id: num(rows[0]!.id) };
    });
  } catch (e) {
    if ((e as { code?: string }).code === '23505') throw new HttpError(409, 'exists', 'Такой промокод уже есть');
    throw e;
  }
}

export async function deletePromo(admin: Viewer, idParam: string) {
  const id = int(idParam, 'ID');
  await tx(async (c) => {
    const { rows } = await c.query<{ code: string }>('DELETE FROM promo_codes WHERE id = $1 RETURNING code', [id]);
    if (!rows[0]) throw notFound('Промокод не найден');
    await log(c, admin, 'promo_delete', null, { code: rows[0].code });
  });
  return { ok: true };
}

// ---------- Media partners ----------

export async function mediaList() {
  return (await q<UserRow>('SELECT * FROM users WHERE media_platform IS NOT NULL ORDER BY username_lc')).map(userBrief);
}

const PLATFORM_NAME: Record<MediaPlatform, string> = { tiktok: 'TikTok', youtube: 'YouTube', twitch: 'Twitch' };

export async function setMedia(admin: Viewer, body: Body) {
  const user = await resolveUser(body.user);
  const platform = oneOf(body.platform, 'платформа', MEDIA_PLATFORMS);
  await tx(async (c) => {
    await c.query('UPDATE users SET media_platform = $2 WHERE id = $1', [user.id, platform]);
    await log(c, admin, 'media_grant', num(user.id), { platform });
  });
  const notified = await notify(num(user.id), `🎬 Тебе выдан статус «Партнёр ${PLATFORM_NAME[platform]}» в BrainrotCrash!`);
  return { user: userBrief({ ...user, media_platform: platform }), notified };
}

export async function removeMedia(admin: Viewer, idParam: string) {
  const id = int(idParam, 'ID');
  await tx(async (c) => {
    await c.query('UPDATE users SET media_platform = NULL WHERE id = $1', [id]);
    await log(c, admin, 'media_revoke', id);
  });
  return { ok: true };
}

// ---------- Settings / maintenance ----------

export const readSettings = getSettings;

export const broadcasts = recentBroadcasts;

/**
 * «Рассылка»: a photo, text and an optional button to the app, sent by the bot to every player who has not
 * blocked it (in batches from the minute tick). `test: true` sends it to the admin only, right away.
 */
export async function announce(admin: Viewer, body: Body) {
  if (!admin.isOwner) throw forbidden('Рассылку по всем игрокам отправляют только владельцы');
  const text = str(body.text, 'текст', 1, MESSAGE_MAX);
  const photo = body.photo === undefined || body.photo === null || body.photo === '' ? null : body.photo;
  if (photo !== null && !isImageUrl(photo)) throw bad('invalid', 'Загрузи картинку заново');
  const html = announceHtml(text);
  if (html.length > (photo ? CAPTION_MAX : MESSAGE_MAX)) {
    throw bad('too_long', photo ? `С фото текст — до ${CAPTION_MAX} символов (так считает Telegram)` : `Текст — до ${MESSAGE_MAX} символов`);
  }
  let button: Outgoing['button'] = null;
  if (body.button && typeof body.button === 'object') {
    const b = body.button as Body;
    const open = oneOf(b.open ?? '', 'раздел', ANNOUNCE_OPEN);
    button = { text: str(b.text, 'текст кнопки', 1, 40), ...(open ? { open } : {}) };
  }
  const message: Outgoing = { html, photo, button };
  if (body.test === true) return { test: await deliver(admin.id, message) };
  await tx(async (c) => {
    await queueBroadcast(c, admin.id, 'announce', message, false);
    await log(c, admin, 'announce', null, { text: text.slice(0, 200), photo: !!photo, button: button?.text ?? null });
  });
  return recentBroadcasts();
}

export async function stopAnnounce(admin: Viewer, idParam: string) {
  if (!admin.isOwner) throw forbidden('Рассылку останавливают только владельцы');
  const id = int(idParam, 'рассылка');
  if (!(await stopBroadcast(id))) throw notFound('Рассылка уже закончилась');
  await tx((c) => log(c, admin, 'announce_stop', null, { id }));
  return recentBroadcasts();
}

export async function updateSettings(admin: Viewer, body: Body) {
  await tx(async (c) => {
    if (body.maintenance && typeof body.maintenance === 'object') {
      const m = body.maintenance as Body;
      const value = { enabled: bool(m.enabled), message: optStr(m.message, 'текст', 500) ?? '' };
      await setSetting(c, 'maintenance', value);
      await log(c, admin, value.enabled ? 'maintenance_on' : 'maintenance_off', null, value);
    }
    if (body.starRate !== undefined) {
      const rate = Number(body.starRate);
      if (!Number.isFinite(rate) || rate < STAR_RATE_MIN || rate > STAR_RATE_MAX || Math.abs(Math.round(rate * 100) - rate * 100) > 1e-6) {
        throw bad('invalid', `Курс: число от ${STAR_RATE_MIN} до ${STAR_RATE_MAX}, не больше двух знаков после запятой`);
      }
      await setSetting(c, 'stars', { rate });
      await log(c, admin, 'star_rate', null, { rate });
    }
    if (body.cryptoRate !== undefined) {
      if (!admin.isOwner) throw forbidden('Курс крипты меняют только владельцы');
      const rate = Number(body.cryptoRate);
      if (!Number.isFinite(rate) || rate < CRYPTO_RATE_MIN || rate > CRYPTO_RATE_MAX || Math.abs(Math.round(rate * 100) - rate * 100) > 1e-6) {
        throw bad('invalid', `Курс: число от ${CRYPTO_RATE_MIN} до ${CRYPTO_RATE_MAX}, не больше двух знаков после запятой`);
      }
      await setSetting(c, 'crypto', { rate });
      await log(c, admin, 'crypto_rate', null, { rate });
    }
    // x2 / x4 / x8 luck (`x`, default 2): each is its own event; the strongest running one counts.
    if (body.luck && typeof body.luck === 'object') {
      const luck = body.luck as Body;
      const x = luck.x === undefined ? 2 : Number(oneOf(String(luck.x), 'удача', ['2', '4', '8'] as const));
      const key = x === 8 ? 'luck8' : x === 4 ? 'luck4' : 'luck';
      const minutes = luck.minutes === 0 || luck.minutes === null ? 0 : int(luck.minutes, 'длительность', 1, 7 * 24 * 60);
      const until = minutes ? Date.now() + minutes * 60_000 : null;
      const before = await getSettings(c);
      // Luck multiplies the окуп chance: with «Без окупа» there is nothing to multiply — the banner would lie.
      if (minutes && before.okupCut.factor === 0) throw bad('okup_zero', 'Включён «Без окупа» — удача ничего не даст. Сначала верни окуп в «Окуп в кейсах»');
      const wasOn = !!(x === 8 ? before.luck8Until : x === 4 ? before.luck4Until : before.luckUntil);
      await setSetting(c, key, { until });
      await log(c, admin, until ? `${key}_on` : `${key}_off`, null, until ? { minutes } : {});
      // Switching it on (not extending) tells every player in the bot; the tick sends it in batches.
      if (until && !wasOn && luck.notify !== false) await queueBroadcast(c, admin.id, 'luck', luckBroadcast(minutes, x));
    }
    // The FUSE and upgrader events: the look only (the owner's call) — nothing about chances changes.
    for (const [field, setting, action] of [
      ['fuseEvent', 'fuse_event', 'fuse_event'],
      ['upgradeEvent', 'upgrade_event', 'upgrade_event'],
    ] as const) {
      const e = body[field];
      if (!e || typeof e !== 'object') continue;
      const minutes = (e as Body).minutes === 0 || (e as Body).minutes === null ? 0 : int((e as Body).minutes, 'длительность', 1, MAX_EVENT_MINUTES);
      const until = minutes ? Date.now() + minutes * 60_000 : null;
      await setSetting(c, setting, { until });
      await log(c, admin, until ? `${action}_on` : `${action}_off`, null, until ? { minutes } : {});
    }
    // «Щелчок»: every chosen event runs until the same moment (none ends earlier than it was going to), and every
    // open app plays the cutscene once.
    if (body.snap && typeof body.snap === 'object') {
      const b = body.snap as Body;
      const minutes = int(b.minutes, 'длительность', 1, MAX_SNAP_MINUTES);
      const events = Array.isArray(b.events) && b.events.length ? [...new Set(b.events.map((e) => oneOf<EventId>(e, 'ивент', EVENT_IDS)))] : [...SNAP_DEFAULT_EVENTS];
      const now = Date.now();
      const endsAt = now + minutes * 60_000;
      const current = await getSettings(c);
      if (current.okupCut.factor === 0 && events.some((e) => e === 'cases' || e === 'luck4' || e === 'luck8')) {
        throw bad('okup_zero', 'Включён «Без окупа» — удача ничего не даст. Убери удачу из щелчка или верни окуп');
      }
      const later = (until: number | null) => Math.max(until ?? 0, endsAt);
      if (events.includes('cases')) await setSetting(c, 'luck', { until: later(current.luckUntil) });
      if (events.includes('luck4')) await setSetting(c, 'luck4', { until: later(current.luck4Until) });
      if (events.includes('luck8')) await setSetting(c, 'luck8', { until: later(current.luck8Until) });
      if (events.includes('fuse')) await setSetting(c, 'fuse_event', { until: later(current.fuseEventUntil) });
      if (events.includes('upgrade')) await setSetting(c, 'upgrade_event', { until: later(current.upgradeEventUntil) });
      if (events.includes('tacos')) {
        await setSetting(c, 'tacos', { enabled: true, endsAt: tacosActive(current.tacos, now) ? later(current.tacos.endsAt) : endsAt });
      }
      await setSetting(c, 'snap', { at: now, endsAt, events });
      await log(c, admin, 'snap', null, { minutes, events });
    }
    if (body.freeGate && typeof body.freeGate === 'object') {
      const g = body.freeGate as Body;
      const raw = typeof g.channel === 'string' ? g.channel.trim().replace(/^https?:\/\/t\.me\//, '@') : '';
      const channel = raw ? (raw.startsWith('@') ? raw : `@${raw}`) : null;
      if (channel && !/^@[A-Za-z][A-Za-z0-9_]{3,31}$/.test(channel)) throw bad('invalid', 'Канал: @username публичного канала');
      const value = { channel, share: g.share !== false };
      await setSetting(c, 'free_case_gate', value);
      await log(c, admin, 'free_gate', null, value);
    }
    if (body.depositOpen && typeof body.depositOpen === 'object') {
      const d = body.depositOpen as Body;
      const { depositOpen } = await getSettings(c);
      const value = { brainrots: d.brainrots === undefined ? depositOpen.brainrots : bool(d.brainrots), gears: d.gears === undefined ? depositOpen.gears : bool(d.gears) };
      await setSetting(c, 'deposit_open', value);
      await log(c, admin, 'deposit_open', null, value);
    }
    if (body.withdrawRules && typeof body.withdrawRules === 'object') {
      const r = body.withdrawRules as Body;
      const { withdrawRules: was } = await getSettings(c);
      const value = {
        minValue: money(r.minValue, 'минимальная сумма вывода', 0, 1_000_000),
        minItems: int(r.minItems, 'минимум брейнротов', 1, 20),
        minItemPrice: money(r.minItemPrice, 'порог хлама', 0, 1_000_000),
        // Older admin pages send only the first three: the multipliers stay as they were.
        wagerDeposit: r.wagerDeposit === undefined ? was.wagerDeposit : money(r.wagerDeposit, 'отыгрыш пополнений', 0, MAX_WAGER_MULTIPLIER),
        wagerBonus: r.wagerBonus === undefined ? was.wagerBonus : money(r.wagerBonus, 'отыгрыш бонусов', 0, MAX_WAGER_MULTIPLIER),
      };
      await setSetting(c, 'withdraw_rules', value);
      await log(c, admin, 'withdraw_rules', null, value);
    }
    if (body.tacos && typeof body.tacos === 'object') {
      const t = body.tacos as Body;
      const endsAt = Number(t.endsAt);
      if (!Number.isFinite(endsAt) || endsAt < Date.UTC(2020, 0, 1) || endsAt > Date.now() + 366 * 24 * 3600_000) throw bad('invalid', 'Дата окончания ивента: не дальше чем через год');
      const value = { enabled: bool(t.enabled), endsAt: Math.round(endsAt) };
      await setSetting(c, 'tacos', value);
      await log(c, admin, value.enabled ? 'tacos_on' : 'tacos_off', null, value);
    }
    // A site-wide message with the owner's profile. Owner-only, like «Рассылка»; empty text clears it.
    if (body.announcement !== undefined && typeof body.announcement === 'object' && body.announcement !== null) {
      if (!admin.isOwner) throw forbidden('Глобальное сообщение публикуют только владельцы');
      const a = body.announcement as Body;
      const text = optStr(a.text, 'текст', 500)?.trim() ?? '';
      if (!text) {
        await setSetting(c, 'announcement', {});
        await log(c, admin, 'announce_site_clear', null, {});
      } else {
        const prof = (await c.query<{ first_name: string; last_name: string | null; photo_url: string | null }>('SELECT first_name, last_name, photo_url FROM users WHERE id = $1', [admin.id])).rows[0];
        const value = {
          text,
          authorName: [prof?.first_name, prof?.last_name].filter(Boolean).join(' ') || 'BrainrotCrash',
          authorPhoto: prof?.photo_url ?? null,
          at: Date.now(),
        };
        await setSetting(c, 'announcement', value);
        await log(c, admin, 'announce_site', null, { len: text.length });
      }
    }
    if (Array.isArray(body.tradeBots)) {
      const bots = [...new Set(body.tradeBots.map((b) => robloxNick(b)))].slice(0, 10);
      await setSetting(c, 'trade_bots', bots);
      await log(c, admin, 'trade_bots', null, { count: bots.length });
    }
    // One nick added or removed against the stored list, so a nick added from the bot meanwhile isn't lost.
    if (body.tradeBotAdd !== undefined || body.tradeBotRemove !== undefined) {
      const { tradeBots } = await getSettings(c);
      let bots = tradeBots;
      if (body.tradeBotRemove !== undefined) bots = bots.filter((b) => b !== robloxNick(body.tradeBotRemove));
      if (body.tradeBotAdd !== undefined) {
        const nick = robloxNick(body.tradeBotAdd);
        if (!bots.includes(nick)) bots = [...bots.slice(0, 9), nick];
      }
      await setSetting(c, 'trade_bots', bots);
      await log(c, admin, 'trade_bots', null, { count: bots.length });
    }
  });
  return getSettings();
}

// ---------- Catalog ----------

export async function adminBrainrots() {
  // Counted once per table (not per catalog row): the inventory grows with every player.
  const usage = await q<{ id: string; owned: string; in_cases: string }>(
    `SELECT b.id, coalesce(i.n, 0) AS owned, coalesce(ci.n, 0) AS in_cases
     FROM brainrots b
     LEFT JOIN (SELECT brainrot_id, count(*) AS n FROM inventory GROUP BY brainrot_id) i ON i.brainrot_id = b.id
     LEFT JOIN (SELECT brainrot_id, count(*) AS n FROM case_items GROUP BY brainrot_id) ci ON ci.brainrot_id = b.id`,
  );
  const map = new Map(usage.map((u) => [u.id, u]));
  return (await allBrainrots())
    .filter((b) => b.status !== 'deleted')
    .map((b) => ({ ...b, owned: num(map.get(b.id)?.owned), inCases: num(map.get(b.id)?.in_cases) }));
}

function slugify(name: string): string {
  const base = name
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 40);
  return base || 'brainrot';
}

/** The picture a coin prize gets when the admin uploads none. */
export const COIN_PRIZE_IMAGE = '/brainrots/coin-prize.webp';

/**
 * A catalog row. `kind: 'coins'` makes a coin prize: it goes into cases with chances like a brainrot, but a win
 * credits its price (the amount) to the balance; it is never withdrawable and never sold, upgraded or paid out.
 */
export async function createBrainrot(admin: Viewer, body: Body) {
  const kind = body.kind === undefined ? 'brainrot' : oneOf(body.kind, 'тип', ['brainrot', 'coins'] as const);
  const price = money(body.price, kind === 'coins' ? 'сумма' : 'цена');
  const name = kind === 'coins' && (body.name === undefined || body.name === '') ? `${formatAmount(price)} B` : str(body.name, 'название', 2, 60);
  const image = kind === 'coins' && (body.image === undefined || body.image === '') ? COIN_PRIZE_IMAGE : body.image;
  if (!isImageUrl(image)) throw bad('invalid', 'Загрузи картинку');
  let id = kind === 'coins' ? `coins-${slugify(String(price))}` : slugify(name);
  if (await one('SELECT 1 FROM brainrots WHERE id = $1', [id])) id = `${id}-${Date.now().toString(36)}`;
  await tx(async (c) => {
    await c.query('INSERT INTO brainrots (id, name, price, image, withdrawable, kind) VALUES ($1, $2, $3, $4, $5, $6)', [
      id,
      name,
      price,
      image,
      kind === 'brainrot' && body.withdrawable !== false,
      kind,
    ]);
    await log(c, admin, 'brainrot_create', null, { id, name, price, kind });
  });
  return { id };
}

function formatAmount(n: number): string {
  return Number.isInteger(n) ? String(n) : n.toFixed(2);
}

export async function updateBrainrot(admin: Viewer, idParam: string, body: Body) {
  const sets: string[] = [];
  const params: unknown[] = [idParam];
  const changes: Record<string, unknown> = {};
  const add = (col: string, value: unknown) => {
    params.push(value);
    sets.push(`${col} = $${params.length}`);
    changes[col] = value;
  };
  if (body.name !== undefined) add('name', str(body.name, 'название', 2, 60));
  if (body.price !== undefined) add('price', money(body.price, 'цена'));
  if (body.image !== undefined) {
    if (!isImageUrl(body.image)) throw bad('invalid', 'Неверная картинка');
    add('image', body.image);
  }
  if (body.status !== undefined) add('status', oneOf(body.status, 'статус', ['active', 'hidden', 'disabled'] as const));
  if (body.withdrawable !== undefined) {
    add('withdrawable', bool(body.withdrawable));
    // A coin prize never becomes withdrawable.
    sets[sets.length - 1] += ` AND kind = 'brainrot'`;
  }
  if (!sets.length) throw bad('invalid', 'Нечего менять');
  await tx(async (c) => {
    const { rows } = await c.query(`UPDATE brainrots SET ${sets.join(', ')}, updated_at = now() WHERE id = $1 AND status <> 'deleted' RETURNING id`, params);
    if (!rows[0]) throw notFound('Брейнрот не найден');
    await log(c, admin, 'brainrot_update', null, { id: idParam, ...changes });
  });
  // A new price can leave a case without anything cheaper than itself; fix those right away.
  const healed = changes.price !== undefined || changes.status !== undefined ? await healCases({ adminId: admin.id }) : [];
  return { ok: true, healed };
}

/** Kept as a soft delete: players may still own copies, and drop history points at it. */
export async function deleteBrainrot(admin: Viewer, idParam: string) {
  await tx(async (c) => {
    const { rows } = await c.query(`UPDATE brainrots SET status = 'deleted', updated_at = now() WHERE id = $1 AND status <> 'deleted' RETURNING id`, [idParam]);
    if (!rows[0]) throw notFound('Брейнрот не найден');
    await c.query('DELETE FROM case_items WHERE brainrot_id = $1', [idParam]);
    await log(c, admin, 'brainrot_delete', null, { id: idParam });
  });
  return { ok: true };
}

export async function upload(_admin: Viewer, body: Body) {
  const url = await saveUpload(body.dataUrl);
  return { url };
}

// ---------- Titles ----------

const HEX = /^#[0-9a-f]{6}$/i;

export async function titles() {
  const rows = await q<{ id: string; name: string; description: string; icon: string; color: string; created_at: string; holders: string }>(
    `SELECT t.*, (SELECT count(*) FROM user_titles ut WHERE ut.title_id = t.id) AS holders FROM titles t ORDER BY t.id DESC`,
  );
  return rows.map((r) => ({ id: num(r.id), name: r.name, description: r.description, icon: r.icon, color: r.color, at: ms(r.created_at), holders: num(r.holders) }));
}

function titleFields(body: Body, partial: boolean) {
  const out: Record<string, string> = {};
  if (!partial || body.name !== undefined) out.name = str(body.name, 'название', 2, 40);
  if (!partial || body.description !== undefined) out.description = optStr(body.description, 'описание', 240) ?? '';
  if (!partial || body.icon !== undefined) {
    if (!isImageUrl(body.icon)) throw bad('invalid', 'Выбери иконку');
    out.icon = body.icon;
  }
  if (!partial || body.color !== undefined) {
    if (typeof body.color !== 'string' || !HEX.test(body.color)) throw bad('invalid', 'Цвет в формате #rrggbb');
    out.color = body.color;
  }
  return out;
}

export async function createTitle(admin: Viewer, body: Body) {
  const f = titleFields(body, false);
  return tx(async (c) => {
    const { rows } = await c.query<{ id: string }>('INSERT INTO titles (name, description, icon, color, created_by) VALUES ($1, $2, $3, $4, $5) RETURNING id', [
      f.name,
      f.description,
      f.icon,
      f.color,
      admin.id,
    ]);
    await log(c, admin, 'title_create', null, { id: num(rows[0]!.id), name: f.name });
    return { id: num(rows[0]!.id) };
  });
}

export async function updateTitle(admin: Viewer, idParam: string, body: Body) {
  const id = int(idParam, 'ID');
  const f = titleFields(body, true);
  const keys = Object.keys(f);
  if (!keys.length) throw bad('invalid', 'Нечего менять');
  await tx(async (c) => {
    const { rows } = await c.query(`UPDATE titles SET ${keys.map((k, i) => `${k} = $${i + 2}`).join(', ')} WHERE id = $1 RETURNING id`, [id, ...keys.map((k) => f[k])]);
    if (!rows[0]) throw notFound('Титул не найден');
    await log(c, admin, 'title_update', null, { id, ...f });
  });
  return { ok: true };
}

export async function deleteTitle(admin: Viewer, idParam: string) {
  const id = int(idParam, 'ID');
  await tx(async (c) => {
    const { rows } = await c.query<{ name: string }>('DELETE FROM titles WHERE id = $1 RETURNING name', [id]);
    if (!rows[0]) throw notFound('Титул не найден');
    await log(c, admin, 'title_delete', null, { id, name: rows[0].name });
  });
  return { ok: true };
}

export async function titleHolders(idParam: string) {
  const id = int(idParam, 'ID');
  return (await q<UserRow & { granted: string }>('SELECT u.*, ut.created_at AS granted FROM user_titles ut JOIN users u ON u.id = ut.user_id WHERE ut.title_id = $1 ORDER BY ut.created_at DESC', [id])).map(
    (u) => ({ ...userBrief(u), grantedAt: ms(u.granted) }),
  );
}

export async function grantTitle(admin: Viewer, idParam: string, body: Body) {
  const id = int(idParam, 'ID');
  const title = await one<{ name: string }>('SELECT name FROM titles WHERE id = $1', [id]);
  if (!title) throw notFound('Титул не найден');
  const user = await resolveUser(body.user);
  const added = await tx(async (c) => {
    const { rows } = await c.query('INSERT INTO user_titles (user_id, title_id, granted_by) VALUES ($1, $2, $3) ON CONFLICT DO NOTHING RETURNING 1', [user.id, id, admin.id]);
    if (rows[0]) await log(c, admin, 'title_grant', num(user.id), { titleId: id, name: title.name });
    return !!rows[0];
  });
  if (!added) throw bad('exists', 'У игрока уже есть этот титул');
  const notified = await notify(num(user.id), `🏅 Тебе выдан титул «${escapeHtml(title.name)}» в BrainrotCrash!`);
  return { user: userBrief(user), notified };
}

export async function revokeTitle(admin: Viewer, idParam: string, body: Body) {
  const id = int(idParam, 'ID');
  const userId = int(body.userId, 'пользователь');
  await tx(async (c) => {
    const { rows } = await c.query('DELETE FROM user_titles WHERE title_id = $1 AND user_id = $2 RETURNING 1', [id, userId]);
    if (!rows[0]) throw notFound('У игрока нет этого титула');
    await log(c, admin, 'title_revoke', userId, { titleId: id });
  });
  return { ok: true };
}

// ---------- Cases ----------

export async function adminCases() {
  const [cases, health] = await Promise.all([allCases(true), caseReport()]);
  return cases.map((c) => ({ ...c, health: health[c.id] ?? null }));
}

/**
 * Items with an optional hand-set chance: `chance` is 0…1 (0 = «Невозможно», from 0.0001 % up) or null/absent
 * for «Авто» (from prices). A weight sent by an old client is ignored.
 */
function caseItems(v: unknown) {
  if (!Array.isArray(v) || v.length < 2 || v.length > 60) throw bad('invalid', 'В кейсе должно быть от 2 до 60 предметов');
  const seen = new Set<string>();
  const items = v.map((raw) => {
    const item = raw as Body;
    const brainrotId = str(item.brainrotId, 'предмет', 1, 80);
    if (seen.has(brainrotId)) throw bad('invalid', 'Предмет повторяется');
    seen.add(brainrotId);
    let chance: number | null = null;
    if (item.chance !== null && item.chance !== undefined && item.chance !== '') {
      chance = Number(item.chance);
      if (!Number.isFinite(chance) || chance < 0 || chance > 1) throw bad('invalid', 'Шанс — от 0 до 100%');
      if (chance > 0 && chance < MIN_FIXED_CHANCE) throw bad('invalid', 'Минимальный шанс — 0,0001%');
      chance = Math.round(chance * 1e10) / 1e10;
    }
    return { brainrotId, chance };
  });
  const fixedSum = items.reduce((s, i) => s + (i.chance ?? 0), 0);
  if (fixedSum > 1 + 1e-9) throw bad('invalid', 'Ручные шансы в сумме больше 100%');
  if (items.every((i) => i.chance !== null) && fixedSum <= 0) throw bad('invalid', 'Хотя бы один предмет должен выпадать');
  return items;
}

async function writeCaseItems(c: Queryable, caseId: string, items: { brainrotId: string; chance: number | null }[]) {
  const known = (await c.query<{ id: string }>(`SELECT id FROM brainrots WHERE id = ANY($1::text[]) AND status <> 'deleted'`, [items.map((i) => i.brainrotId)])).rows;
  if (known.length !== items.length) throw bad('invalid', 'В списке есть удалённый или неизвестный брейнрот');
  // The editor only sees brainrots that are on (active or hidden): rows of switched-off ones it didn't send stay,
  // so turning such a brainrot back on puts it back into the case with its chance.
  await c.query(
    `DELETE FROM case_items ci USING brainrots b
     WHERE ci.case_id = $1 AND b.id = ci.brainrot_id AND (b.status IN ('active', 'hidden') OR ci.brainrot_id = ANY($2::text[]))`,
    [caseId, items.map((i) => i.brainrotId)],
  );
  await c.query(
    `INSERT INTO case_items (case_id, brainrot_id, weight, fixed_chance)
     SELECT $1, i.id, 1, i.chance FROM unnest($2::text[], $3::numeric[]) AS i (id, chance)`,
    [caseId, items.map((i) => i.brainrotId), items.map((i) => i.chance)],
  );
}

/** How long the automatic «НОВЫЙ» / «РЕДИЗАЙН» ribbon stays on a case card. */
const BADGE_DAYS = 3;

/** The editor's ribbon field: 'auto' (or absent) = the server decides; 'none', 'new', 'redesign' = the admin's pick. */
const badgeChoice = (v: unknown) => (v === undefined || v === null || v === '' ? 'auto' : oneOf(v, 'ленточка', ['auto', 'none', 'new', 'redesign'] as const));

async function setBadge(c: Queryable, caseId: string, badge: 'new' | 'redesign' | null) {
  await c.query(`UPDATE cases SET badge = $2, badge_until = CASE WHEN $2::text IS NULL THEN NULL ELSE now() + make_interval(days => $3) END WHERE id = $1`, [
    caseId,
    badge,
    BADGE_DAYS,
  ]);
}

async function sectionOr(c: Queryable, v: unknown): Promise<number | null> {
  if (v === null || v === undefined || v === '') return null;
  const id = int(v, 'тема');
  if (!(await c.query('SELECT 1 FROM case_sections WHERE id = $1', [id])).rows[0]) throw notFound('Тема не найдена');
  return id;
}

export async function createCase(admin: Viewer, body: Body) {
  await ensureSchema();
  const name = str(body.name, 'название', 2, 40);
  const kind = oneOf(body.kind ?? 'paid', 'тип', ['paid', 'free', 'tickets'] as const);
  const price = kind === 'paid' ? money(body.price, 'цена') : 0;
  const ticketPrice = kind === 'tickets' ? int(body.ticketPrice, 'цена в тикетах', 1, 100_000) : null;
  if (!isImageUrl(body.image)) throw bad('invalid', 'Загрузи картинку кейса');
  const items = caseItems(body.items);
  let id = slugify(name);
  if (id === 'brainrot' || (await one('SELECT 1 FROM cases WHERE id = $1', [id]))) id = `case-${Date.now().toString(36)}`;
  await tx(async (c) => {
    const { rows } = await c.query<{ sort: number }>('SELECT coalesce(max(sort), 0) + 1 AS sort FROM cases');
    const section = kind !== 'free' ? ((await sectionOr(c, body.sectionId)) ?? num((await c.query<{ id: string }>('SELECT min(id) AS id FROM case_sections')).rows[0]?.id) ?? null) : null;
    await c.query('INSERT INTO cases (id, name, price, image, kind, sort, mystery, section_id, ticket_price) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)', [
      id,
      name,
      price,
      body.image,
      kind,
      rows[0]!.sort,
      bool(body.mystery),
      section || null,
      ticketPrice,
    ]);
    await writeCaseItems(c, id, items);
    // A new case wears «НОВЫЙ» for a few days unless the admin says otherwise.
    const badge = badgeChoice(body.badge);
    await setBadge(c, id, badge === 'none' ? null : badge === 'redesign' ? 'redesign' : 'new');
    if (kind === 'paid') await setPriceCycle(c, id, priceCycleOf(body.priceCycle));
    await log(c, admin, 'case_create', null, { id, name, price });
  });
  return { id, healed: await healCases({ caseId: id, adminId: admin.id }) };
}

export async function updateCase(admin: Viewer, idParam: string, body: Body) {
  await ensureSchema();
  await tx(async (c) => {
    const { rows } = await c.query<{ kind: string }>('SELECT kind FROM cases WHERE id = $1 FOR UPDATE', [idParam]);
    if (!rows[0]) throw notFound('Кейс не найден');
    const changes: Record<string, unknown> = {};
    if (body.name !== undefined) changes.name = str(body.name, 'название', 2, 40);
    // Free and bonus cases have no price; their average drop is fixed instead.
    if (body.price !== undefined && rows[0].kind === 'paid') changes.price = money(body.price, 'цена');
    if (body.status !== undefined) changes.status = oneOf(body.status, 'статус', ['active', 'hidden'] as const);
    if (body.sort !== undefined) changes.sort = int(body.sort, 'порядок', 0, 10_000);
    if (typeof body.mystery === 'boolean') changes.mystery = body.mystery;
    if (body.sectionId !== undefined && (rows[0].kind === 'paid' || rows[0].kind === 'tickets')) changes.section_id = await sectionOr(c, body.sectionId);
    if (body.ticketPrice !== undefined && rows[0].kind === 'tickets') changes.ticket_price = int(body.ticketPrice, 'цена в тикетах', 1, 100_000);
    if (body.image !== undefined) {
      if (!isImageUrl(body.image)) throw bad('invalid', 'Неверная картинка');
      changes.image = body.image;
    }
    const keys = Object.keys(changes);
    if (keys.length) await c.query(`UPDATE cases SET ${keys.map((k, i) => `${k} = $${i + 2}`).join(', ')} WHERE id = $1`, [idParam, ...keys.map((k) => changes[k])]);
    if (body.items !== undefined) await writeCaseItems(c, idParam, caseItems(body.items));
    if (body.priceCycle !== undefined && rows[0].kind === 'paid') await setPriceCycle(c, idParam, priceCycleOf(body.priceCycle));
    // The ribbon: the admin's pick, or — on a new picture, name or composition — «РЕДИЗАЙН» (a fresh «НОВЫЙ» stays).
    const badge = badgeChoice(body.badge);
    if (badge === 'none') await setBadge(c, idParam, null);
    else if (badge !== 'auto') await setBadge(c, idParam, badge);
    else if (changes.image !== undefined || changes.name !== undefined || body.items !== undefined) {
      const { rows: cur } = await c.query<{ fresh: boolean }>(`SELECT badge = 'new' AND badge_until > now() AS fresh FROM cases WHERE id = $1`, [idParam]);
      if (!cur[0]?.fresh) await setBadge(c, idParam, 'redesign');
    }
    await log(c, admin, 'case_update', null, { id: idParam, ...changes, items: body.items ? 'updated' : undefined, badge: badge === 'auto' ? undefined : badge });
  });
  return { ok: true, healed: await healCases({ caseId: idParam, adminId: admin.id }) };
}

/** «Пересобрать состав»: a fresh drop table for the case from the current catalog. */
export async function recomposeCase(admin: Viewer, idParam: string) {
  if (!(await one('SELECT 1 FROM cases WHERE id = $1', [idParam]))) throw notFound('Кейс не найден');
  const [healed] = await healCases({ caseId: idParam, force: true, adminId: admin.id });
  if (!healed) throw bad('busy', 'Не пересобралось: под эту цену в каталоге нет 2 подходящих брейнротов (или состав уже пересобирается — попробуй через пару секунд)');
  return healed;
}

export async function deleteCase(admin: Viewer, idParam: string) {
  await tx(async (c) => {
    const { rows } = await c.query('DELETE FROM cases WHERE id = $1 RETURNING id', [idParam]);
    if (!rows[0]) throw notFound('Кейс не найден');
    await log(c, admin, 'case_delete', null, { id: idParam });
  });
  return { ok: true };
}

// ---------- Case sections («темы» on the home page) ----------

export async function adminSections() {
  const [sections, counts] = await Promise.all([
    caseSections(),
    q<{ section_id: string; n: string }>(`SELECT section_id, count(*) AS n FROM cases WHERE section_id IS NOT NULL GROUP BY section_id`),
  ]);
  return sections.map((s) => ({ ...s, cases: num(counts.find((c) => num(c.section_id) === s.id)?.n) }));
}

export async function createSection(admin: Viewer, body: Body) {
  const title = str(body.title, 'название темы', 1, 40).trim();
  return tx(async (c) => {
    const { rows } = await c.query<{ id: string }>(
      'INSERT INTO case_sections (title, sort) SELECT $1, coalesce(max(sort), 0) + 1 FROM case_sections RETURNING id',
      [title],
    );
    await log(c, admin, 'section_create', null, { id: num(rows[0]!.id), title });
    return { id: num(rows[0]!.id) };
  });
}

/** Rename, or move up/down (`move`: -1 / 1) by swapping places with the neighbour. */
export async function updateSection(admin: Viewer, idParam: string, body: Body) {
  const id = int(idParam, 'тема');
  return tx(async (c) => {
    const { rows } = await c.query<{ id: string; sort: number }>('SELECT id, sort FROM case_sections ORDER BY sort, id FOR UPDATE');
    const at = rows.findIndex((r) => num(r.id) === id);
    if (at < 0) throw notFound('Тема не найдена');
    if (body.title !== undefined) await c.query('UPDATE case_sections SET title = $2 WHERE id = $1', [id, str(body.title, 'название темы', 1, 40).trim()]);
    if (body.move === 1 || body.move === -1) {
      const order = rows.map((r) => num(r.id));
      const to = at + (body.move as number);
      if (to >= 0 && to < order.length) [order[at], order[to]] = [order[to]!, order[at]!];
      for (const [i, sid] of order.entries()) await c.query('UPDATE case_sections SET sort = $2 WHERE id = $1', [sid, i]);
    }
    await log(c, admin, 'section_update', null, { id, title: body.title, move: body.move });
    return { ok: true };
  });
}

/** Its cases move to the first remaining theme (or show under «Кейсы» when none is left). */
export async function deleteSection(admin: Viewer, idParam: string) {
  const id = int(idParam, 'тема');
  return tx(async (c) => {
    const { rows } = await c.query('DELETE FROM case_sections WHERE id = $1 RETURNING id', [id]);
    if (!rows[0]) throw notFound('Тема не найдена');
    await c.query('UPDATE cases SET section_id = (SELECT id FROM case_sections ORDER BY sort, id LIMIT 1) WHERE section_id IS NULL AND kind = $1', ['paid']);
    await log(c, admin, 'section_delete', null, { id });
    return { ok: true };
  });
}

// ---------- Admins ----------

export async function admins() {
  const extra = await q<UserRow & { added: string }>('SELECT u.*, a.created_at AS added FROM admins a JOIN users u ON u.id = a.user_id ORDER BY a.created_at');
  const owners = await Promise.all(OWNER_IDS.map(async (id) => ({ id, user: await getUser(id) })));
  return {
    owners: owners.map((o) => (o.user ? { ...userBrief(o.user), owner: true } : { id: o.id, display: `ID ${o.id}`, owner: true })),
    admins: extra.filter((u) => !isOwnerId(num(u.id))).map((u) => ({ ...userBrief(u), owner: false, addedAt: ms(u.added) })),
  };
}

export async function addAdmin(admin: Viewer, body: Body) {
  if (!admin.isOwner) throw forbidden('Добавлять админов может только владелец');
  const user = await resolveUser(body.user);
  await tx(async (c) => {
    await c.query('INSERT INTO admins (user_id, added_by) VALUES ($1, $2) ON CONFLICT DO NOTHING', [user.id, admin.id]);
    await log(c, admin, 'admin_add', num(user.id));
  });
  const notified = await notify(num(user.id), '🛡 Тебе выдан доступ к админ-панели BrainrotCrash.');
  return { user: userBrief(user), notified };
}

export async function removeAdmin(admin: Viewer, idParam: string) {
  if (!admin.isOwner) throw forbidden('Снимать админов может только владелец');
  const id = int(idParam, 'ID');
  if (isOwnerId(id)) throw forbidden('Владельца снять нельзя');
  await tx(async (c) => {
    await c.query('DELETE FROM admins WHERE user_id = $1', [id]);
    await log(c, admin, 'admin_remove', id);
  });
  return { ok: true };
}

// ---------- Log ----------

export async function logs() {
  const rows = await q<{ id: string; admin_id: string; action: string; target_user: string | null; details: unknown; created_at: string; admin_name: string | null; target_name: string | null }>(
    `SELECT l.*, (SELECT coalesce('@' || u.username, u.first_name) FROM users u WHERE u.id = l.admin_id) AS admin_name,
       (SELECT coalesce('@' || u.username, u.first_name) FROM users u WHERE u.id = l.target_user) AS target_name
     FROM admin_log l ORDER BY l.id DESC LIMIT 150`,
  );
  return rows.map((r) => ({
    id: num(r.id),
    admin: num(r.admin_id) === SYSTEM_ADMIN_ID ? 'Система' : r.admin_name || `ID ${r.admin_id}`,
    action: r.action,
    target: r.target_user ? r.target_name || `ID ${r.target_user}` : null,
    details: r.details,
    at: ms(r.created_at),
  }));
}
