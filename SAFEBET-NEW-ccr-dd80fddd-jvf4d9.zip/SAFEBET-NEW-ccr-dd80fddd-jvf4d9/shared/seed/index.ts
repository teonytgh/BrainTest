import data from './catalog.json';
import type { Brainrot } from '../types';

/** The initial catalog shipped in the seed migration; tests use it as a realistic fixture. */
export const SEED_BRAINROTS: readonly Brainrot[] = data.brainrots.map((b) => ({ ...b, status: 'active' as const, withdrawable: true, kind: 'brainrot' as const }));

export function seedBrainrot(id: string): Brainrot {
  const b = SEED_BRAINROTS.find((x) => x.id === id);
  if (!b) throw new Error(`Unknown seed brainrot ${id}`);
  return b;
}
