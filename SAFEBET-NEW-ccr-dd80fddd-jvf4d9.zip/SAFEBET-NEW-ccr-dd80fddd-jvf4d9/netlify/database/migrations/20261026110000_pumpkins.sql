-- «Тыквенная ночь»: one round per row. `cells` (the ghosts) and `seed` stay on the server until the round is
-- over; `hash` = sha256("<cells sorted, comma separated>:<seed>") is shown at the start (provably fair).
CREATE TABLE pumpkin_rounds (
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT NOT NULL REFERENCES users (id),
  stake JSONB NOT NULL,
  stake_value NUMERIC(16, 2) NOT NULL CHECK (stake_value > 0),
  ghosts INT NOT NULL CHECK (ghosts BETWEEN 1 AND 24),
  cells INT[] NOT NULL,
  seed TEXT NOT NULL,
  hash TEXT NOT NULL,
  picks INT[] NOT NULL DEFAULT '{}',
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'lost', 'cashed')),
  multiplier NUMERIC(12, 2) NOT NULL DEFAULT 1,
  payout_value NUMERIC(16, 2),
  payout JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  finished_at TIMESTAMPTZ
);
CREATE UNIQUE INDEX pumpkin_one_active ON pumpkin_rounds (user_id) WHERE status = 'active';
CREATE INDEX pumpkin_rounds_user ON pumpkin_rounds (user_id, created_at DESC);

ALTER TABLE pumpkin_rounds ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'anon') THEN
    EXECUTE 'REVOKE ALL ON pumpkin_rounds FROM anon, authenticated';
    EXECUTE 'REVOKE ALL ON SEQUENCE pumpkin_rounds_id_seq FROM anon, authenticated';
  END IF;
END $$;
