import { useQuery } from '@tanstack/react-query';
import { Avatar } from './Avatar';
import { BrainrotThumb } from './BrainrotCard';
import { Coin } from './Coin';
import { MediaBadge } from './MediaBadge';
import { Sheet } from './Sheet';
import { TitleBadges } from './TitleBadge';
import { api, errorMessage } from '../api/client';
import { useCatalog } from '../api/queries';
import type { PublicProfile } from '../../server/players';
import { cx, formatCoins } from '../lib/format';
import { tierOf } from '../lib/tier';
import { closePlayer, useUi } from '../store/ui';
import { DemoTag } from './DemoTag';

const joined = new Intl.DateTimeFormat('ru-RU', { day: 'numeric', month: 'long', year: 'numeric' });

/** Another player's profile, opened from the top drop: stats, best drop and what they hold — never their balance. */
export function PlayerSheet() {
  const { player } = useUi();
  const catalog = useCatalog();
  const profile = useQuery({
    queryKey: ['player', player],
    queryFn: () => api<PublicProfile>(`/api/players/${player}`),
    enabled: !!player,
    staleTime: 20_000,
  });
  const p = profile.data;
  // Only the Telegram name: other players never see the @username.
  const display = p?.name ?? '';
  const best = p?.bestDrop ? catalog.byId.get(p.bestDrop.brainrotId) : null;
  const items = (p?.inventory ?? []).flatMap((i) => {
    const b = catalog.byId.get(i.brainrotId);
    return b ? [{ b, count: i.count, demo: i.demo ?? 0 }] : [];
  });
  const total = items.reduce((s, i) => s + i.b.price * i.count, 0);

  return (
    <Sheet open={!!player} onClose={closePlayer} title="Профиль игрока">
      {profile.isPending && <p className="hint">Загружаем профиль…</p>}
      {profile.isError && <p className="hint">{errorMessage(profile.error)}</p>}
      {p && (
        <div className="player">
          <div className="player__head">
            <Avatar user={p} size={64} />
            <div className="player__who">
              <span className="pcard__name">
                {display}
                <TitleBadges titles={p.titles} owner={display} />
              </span>
              {p.media && <MediaBadge platform={p.media} />}
              <span className="player__since">В игре с {joined.format(p.joinedAt)}</span>
            </div>
          </div>

          {best && (
            <div className={cx('best-drop', `tier-${tierOf(best.price)}`)}>
              <img src={best.image} alt="" />
              <div>
                <p className="player__label">Лучший дроп</p>
                <p className="best-drop__name">{best.name}</p>
                <p className="best-drop__price">
                  {formatCoins(best.price)} <Coin size={18} />
                </p>
              </div>
            </div>
          )}

          <dl className="stats">
            <div>
              <dt>Кейсов открыто</dt>
              <dd>{formatCoins(p.stats.casesOpened)}</dd>
            </div>
            <div>
              <dt>Апгрейдов</dt>
              <dd>{formatCoins(p.stats.upgrades)}</dd>
            </div>
            <div>
              <dt>Бросков дайса</dt>
              <dd>{formatCoins(p.stats.diceRolls)}</dd>
            </div>
            <div>
              <dt>Раундов краша</dt>
              <dd>{formatCoins(p.stats.crashRounds)}</dd>
            </div>
          </dl>

          <div className="player__inv">
            <p className="player__label">
              Инвентарь · {formatCoins(items.reduce((s, i) => s + i.count, 0))} шт. · {formatCoins(total)} <Coin size={13} />
            </p>
            {items.length ? (
              <>
                <div className="player__items">
                  {items.map(({ b, count, demo }) => (
                    <span key={b.id} className={cx('player__item', demo > 0 && 'is-demo')} title={demo ? `${b.name} — из них демо: ${demo}` : b.name}>
                      <BrainrotThumb brainrot={b} size={56} />
                      {count > 1 && <span className="player__count">×{count}</span>}
                      {demo > 0 && <DemoTag corner />}
                    </span>
                  ))}
                </div>
                {items.some((i) => i.demo > 0) && <p className="hint hint--left">«ДЕМО» — выдано игроку для демо: играть можно, вывести нельзя.</p>}
              </>
            ) : (
              <p className="hint hint--left">Пусто — всё продано или выведено.</p>
            )}
          </div>
        </div>
      )}
    </Sheet>
  );
}
