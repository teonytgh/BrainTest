import { createHash, createHmac } from 'node:crypto';
import { CRYPTO_ASSETS, CRYPTO_FIAT, CRYPTO_RUB_MAX, CRYPTO_RUB_MIN, CRYPTO_RUB_PRESETS, rubToCoins } from '../shared/crypto';
import { assertActive, type Viewer } from './auth';
import { ensureSchema } from './autoMigrate';
import { ms, num, one, q, tx } from './db';
import { addCoins, addWager } from './economy';
import { OWNER_IDS, env, siteUrl } from './env';
import { HttpError, bad, notFound } from './errors';
import { afterResponse } from './live';
import { markActiveReferral, notifyActiveFriend, notifyDepositShare, notifyMilestones, payDepositShare, payMilestones } from './referrals';
import { getSettings } from './settings';
import { escapeHtml, notify, safeEqual } from './telegram';
import { int, type Body } from './validate';

/**
 * Crypto deposits (iteration 38) through Crypto Pay — @CryptoBot's merchant API. The player picks roubles, we open an
 * invoice priced in RUB that takes any of CRYPTO_ASSETS, and credit the coins fixed on the order once CryptoBot says it
 * is paid: by its webhook (`/api/crypto/webhook`, signed with the app token) or, if that never comes, by asking it —
 * when the app polls the order and from the minute tick. A paid invoice is credited once (row lock + the
 * `crypto:<invoice>` row in star_payments), like a Stars payment: coins, wagering, the referrer's share, milestones.
 * The token lives only in the Worker secret CRYPTO_PAY_TOKEN; CRYPTO_PAY_NET=testnet uses CryptoBot's test network.
 */

const PAYLOAD = /^bc:(\d{1,18})$/;
/** An invoice stays payable for an hour. */
const INVOICE_TTL_S = 3600;
/** The app polls an order; CryptoBot is asked about it at most this often. */
const RECHECK_MS = 4000;

export interface CryptoInvoice {
  invoice_id: number;
  status: 'active' | 'paid' | 'expired';
  currency_type?: string;
  fiat?: string;
  amount: string;
  paid_asset?: string;
  paid_amount?: string;
  payload?: string;
  bot_invoice_url?: string;
  mini_app_invoice_url?: string;
  web_app_invoice_url?: string;
}

type Transport = (method: string, params: Record<string, string>) => Promise<unknown>;

let transport: Transport | null = null;
/** Tests swap the HTTP call for a fake CryptoBot. */
export function useCryptoApi(fn: Transport | null) {
  transport = fn;
}

const token = () => env('CRYPTO_PAY_TOKEN') || '';
export const cryptoEnabled = () => !!token();

async function cryptoApi<T>(method: string, params: Record<string, string>): Promise<T> {
  if (transport) return (await transport(method, params)) as T;
  const base = env('CRYPTO_PAY_NET') === 'testnet' ? 'https://testnet-pay.crypt.bot/api' : 'https://pay.crypt.bot/api';
  const res = await fetch(`${base}/${method}?${new URLSearchParams(params)}`, { headers: { 'Crypto-Pay-API-Token': token() } });
  const body = (await res.json().catch(() => null)) as { ok?: boolean; result?: T; error?: { name?: string } } | null;
  if (!body?.ok) {
    console.error('crypto pay', method, res.status, body?.error);
    // CryptoBot's own floor for the coin the invoice is priced in (it may be above our 10 ₽).
    if (/AMOUNT_TOO_SMALL/i.test(body?.error?.name ?? '')) throw new HttpError(400, 'crypto_too_small', 'CryptoBot не принимает такую маленькую сумму — попробуй чуть больше');
    throw new HttpError(502, 'crypto_error', 'CryptoBot не ответил — попробуй ещё раз через минуту');
  }
  return body.result as T;
}

/** What the deposit sheet needs: whether crypto is on, the rate and the packs. */
export async function cryptoInfo() {
  const { cryptoRate } = await getSettings();
  return {
    enabled: cryptoEnabled(),
    rate: cryptoRate,
    fiat: CRYPTO_FIAT,
    min: CRYPTO_RUB_MIN,
    max: CRYPTO_RUB_MAX,
    assets: [...CRYPTO_ASSETS],
    packs: CRYPTO_RUB_PRESETS.map((rub) => ({ rub, coins: rubToCoins(rub, cryptoRate) })),
  };
}

export async function createCryptoInvoice(v: Viewer, body: Body) {
  assertActive(v);
  if (!cryptoEnabled()) throw new HttpError(503, 'crypto_off', 'Оплата криптой пока не подключена');
  await ensureSchema();
  const rub = int(body.rub, 'сумма', CRYPTO_RUB_MIN, CRYPTO_RUB_MAX);
  const recent = await one<{ n: string }>(`SELECT count(*) AS n FROM crypto_orders WHERE user_id = $1 AND created_at > now() - interval '10 minutes'`, [v.id]);
  if (num(recent?.n) >= 6) throw new HttpError(429, 'too_many', 'Слишком много счетов подряд — подожди пару минут');
  const { cryptoRate } = await getSettings();
  const coins = rubToCoins(rub, cryptoRate);
  if (coins <= 0) throw bad('invalid', 'Слишком маленькая сумма');
  const order = await one<{ id: string }>('INSERT INTO crypto_orders (user_id, rub, coins, rate) VALUES ($1, $2, $3, $4) RETURNING id', [v.id, rub, coins, cryptoRate]);
  const orderId = num(order!.id);
  const inv = await cryptoApi<CryptoInvoice>('createInvoice', {
    currency_type: 'fiat',
    fiat: CRYPTO_FIAT,
    accepted_assets: CRYPTO_ASSETS.join(','),
    amount: String(rub),
    description: `BrainrotCrash: пополнение на ${coins.toLocaleString('ru-RU')} B`,
    payload: `bc:${orderId}`,
    expires_in: String(INVOICE_TTL_S),
    paid_btn_name: 'openBot',
    paid_btn_url: 'https://t.me/braincrashbot',
    allow_comments: 'false',
  });
  const url = inv.mini_app_invoice_url || inv.bot_invoice_url || inv.web_app_invoice_url || '';
  await q('UPDATE crypto_orders SET invoice_id = $2, pay_url = $3 WHERE id = $1', [orderId, inv.invoice_id, url]);
  return { orderId, url, rub, coins };
}

/** The app polls its order; a pending one is checked with CryptoBot now and then, so the webhook isn't a must. */
export async function cryptoOrderStatus(v: Viewer, idParam: string) {
  const id = int(idParam, 'счёт');
  let o = await one<{ id: string; status: string; rub: string; coins: string; invoice_id: string | null; checked_at: string | null }>(
    'SELECT id, status, rub, coins, invoice_id, checked_at FROM crypto_orders WHERE id = $1 AND user_id = $2',
    [id, v.id],
  );
  if (!o) throw notFound('Счёт не найден');
  if (o.status === 'pending' && o.invoice_id && cryptoEnabled() && Date.now() - (ms(o.checked_at) ?? 0) > RECHECK_MS) {
    await q('UPDATE crypto_orders SET checked_at = now() WHERE id = $1', [id]);
    const found = await cryptoApi<{ items?: CryptoInvoice[] }>('getInvoices', { invoice_ids: o.invoice_id }).catch(() => null);
    const inv = found?.items?.[0];
    if (inv) await settleInvoice(inv);
    o = (await one<typeof o>('SELECT id, status, rub, coins, invoice_id, checked_at FROM crypto_orders WHERE id = $1', [id]))!;
  }
  return { orderId: id, status: o.status as 'pending' | 'paid' | 'expired', rub: num(o.rub), coins: num(o.coins) };
}

/** CryptoBot's webhook: the body is signed with HMAC-SHA256 keyed by SHA-256 of the app token. */
export async function cryptoWebhook(req: Request): Promise<Response> {
  const raw = await req.text();
  const secret = token();
  if (!secret) return new Response('off', { status: 503 });
  const sign = (text: string) => createHmac('sha256', createHash('sha256').update(secret).digest()).update(text).digest('hex');
  const given = req.headers.get('crypto-pay-api-signature') ?? '';
  let update: { update_type?: string; payload?: CryptoInvoice } | null = null;
  try {
    update = JSON.parse(raw);
  } catch {
    return new Response('bad json', { status: 400 });
  }
  // Signed as sent; CryptoBot's own libraries re-serialise the JSON, so that form is accepted too.
  if (!given || !(safeEqual(given, sign(raw)) || safeEqual(given, sign(JSON.stringify(update))))) return new Response('bad signature', { status: 401 });
  if (update?.update_type === 'invoice_paid' && update.payload) {
    await ensureSchema();
    await settleInvoice(update.payload);
  }
  return new Response('ok');
}

/** The minute tick: pending invoices of the last two hours, asked about in one call (paid ones credited, old ones closed). */
export async function checkCryptoOrders() {
  if (!cryptoEnabled()) return 0;
  const pending = await q<{ invoice_id: string }>(
    `SELECT invoice_id FROM crypto_orders WHERE status = 'pending' AND invoice_id IS NOT NULL AND created_at > now() - interval '2 hours' ORDER BY id DESC LIMIT 100`,
  );
  await q(`UPDATE crypto_orders SET status = 'expired' WHERE status = 'pending' AND created_at < now() - interval '2 hours'`);
  if (!pending.length) return 0;
  const found = await cryptoApi<{ items?: CryptoInvoice[] }>('getInvoices', { invoice_ids: pending.map((p) => p.invoice_id).join(','), count: '100' });
  let paid = 0;
  for (const inv of found.items ?? []) if (inv.status === 'paid' && (await settleInvoice(inv)) === 'credited') paid++;
  return paid;
}

/** Credits a paid invoice once; marks an expired one. */
async function settleInvoice(inv: CryptoInvoice): Promise<'credited' | 'duplicate' | 'expired' | 'unknown' | 'pending'> {
  if (inv.status === 'expired') {
    await q(`UPDATE crypto_orders SET status = 'expired' WHERE invoice_id = $1 AND status = 'pending'`, [inv.invoice_id]);
    return 'expired';
  }
  if (inv.status !== 'paid') return 'pending';
  const m = PAYLOAD.exec(inv.payload ?? '');
  const r = await tx(async (c) => {
    const { rows } = await c.query<{ id: string; user_id: string; rub: string; coins: string; status: string }>(
      'SELECT id, user_id, rub, coins, status FROM crypto_orders WHERE invoice_id = $1 AND ($2::bigint IS NULL OR id = $2) FOR UPDATE',
      [inv.invoice_id, m ? m[1] : null],
    );
    const o = rows[0];
    if (!o) return { unknown: true as const };
    if (o.status === 'paid') return { duplicate: true as const };
    const userId = num(o.user_id);
    const coins = num(o.coins);
    const ins = await c.query(
      `INSERT INTO star_payments (charge_id, order_id, user_id, stars, credited) VALUES ($1, NULL, $2, 0, $3) ON CONFLICT (charge_id) DO NOTHING RETURNING 1`,
      [`crypto:${inv.invoice_id}`, userId, coins],
    );
    if (!ins.rows.length) return { duplicate: true as const };
    await c.query(`UPDATE crypto_orders SET status = 'paid', paid_at = now(), paid_asset = $2, paid_amount = $3 WHERE id = $1`, [
      o.id,
      inv.paid_asset ?? null,
      inv.paid_amount ?? null,
    ]);
    await addCoins(c, userId, coins);
    // A deposit: played through before a withdrawal, counts for the referrer and the big-invite ladder.
    await addWager(c, userId, coins, 'deposit');
    const referrer = await markActiveReferral(c, userId, coins);
    const share = await payDepositShare(c, userId, coins);
    const milestones = await payMilestones(c, userId);
    const mismatch = (inv.fiat && inv.fiat !== CRYPTO_FIAT) || Math.abs(Number(inv.amount) - num(o.rub)) > 0.001;
    return { userId, coins, rub: num(o.rub), referrer, share, milestones, mismatch };
  });
  if ('unknown' in r) {
    await afterResponse(() => alertOwners(`⚠️ Крипто-оплата по неизвестному счёту CryptoBot #${inv.invoice_id}: ${escapeHtml(inv.amount)} ${escapeHtml(inv.fiat ?? '')}`));
    return 'unknown';
  }
  if ('duplicate' in r) return 'duplicate';
  if (r.share) await afterResponse(() => notifyDepositShare(r.share!, r.referrer !== null));
  else if (r.referrer !== null) await afterResponse(() => notifyActiveFriend(r.referrer!));
  if (r.milestones.length) await afterResponse(() => notifyMilestones(r.milestones));
  if (r.mismatch) await afterResponse(() => alertOwners(`⚠️ Крипто-счёт #${inv.invoice_id}: оплачено ${escapeHtml(inv.amount)} ${escapeHtml(inv.fiat ?? '')}, заказ был на ${r.rub} ₽`));
  await afterResponse(() =>
    notify(
      r.userId,
      `✅ Баланс пополнен на <b>${r.coins.toLocaleString('ru-RU')} B</b> (крипта, ${r.rub.toLocaleString('ru-RU')} ₽${inv.paid_asset ? ` в ${escapeHtml(inv.paid_asset)}` : ''})`,
    ),
  );
  return 'credited';
}

function alertOwners(html: string) {
  return Promise.all(OWNER_IDS.map((id) => notify(id, html)));
}

// ---------- Admin ----------

export async function adminCryptoPayments() {
  await ensureSchema();
  const [rows, totals] = await Promise.all([
    q<{ id: string; user_id: string; rub: string; coins: string; paid_asset: string | null; paid_amount: string | null; paid_at: string; username: string | null; first_name: string }>(
      `SELECT o.id, o.user_id, o.rub, o.coins, o.paid_asset, o.paid_amount, o.paid_at, u.username, u.first_name
       FROM crypto_orders o JOIN users u ON u.id = o.user_id WHERE o.status = 'paid' ORDER BY o.paid_at DESC LIMIT 100`,
    ),
    one<{ rub: string; coins: string; count: string; rub24: string }>(
      `SELECT coalesce(sum(rub), 0) AS rub, coalesce(sum(coins), 0) AS coins, count(*) AS count,
         coalesce(sum(rub) FILTER (WHERE paid_at > now() - interval '24 hours'), 0) AS rub24
       FROM crypto_orders WHERE status = 'paid'`,
    ),
  ]);
  return {
    enabled: cryptoEnabled(),
    webhook: `${siteUrl()}/api/crypto/webhook`,
    totals: { rub: num(totals?.rub), coins: num(totals?.coins), count: num(totals?.count), rub24: num(totals?.rub24) },
    payments: rows.map((r) => ({
      id: num(r.id),
      userId: num(r.user_id),
      user: r.username ? `@${r.username}` : r.first_name,
      rub: num(r.rub),
      coins: num(r.coins),
      asset: r.paid_asset,
      amount: r.paid_amount === null ? null : Number(r.paid_amount),
      at: ms(r.paid_at)!,
    })),
  };
}
