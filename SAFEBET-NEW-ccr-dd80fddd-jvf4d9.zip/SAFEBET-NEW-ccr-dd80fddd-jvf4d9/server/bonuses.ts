import { pickWeighted } from '../shared/cases';
import {
  CASHBACK_WEEKS_BACK,
  CONSOLATION_COOLDOWN_MS,
  CONSOLATION_MIN_STAKE,
  CONSOLATION_PRIZES,
  HOUSE_GAMES,
  NICK_CASE_COOLDOWN_MS,
  NICK_TAG,
  cashbackDayStart,
  hasNickTag,
  isCashbackDay,
  weekIndex,
  weekStart,
} from '../shared/bonuses';
import { round2 } from '../shared/money';
import { FREE_CASE_COOLDOWN_MS } from '../shared/types';
import { assertActive, type Viewer } from './auth';
import { db, ms, num, one, q, tx, type Queryable } from './db';
import { addCoins, addWager } from './economy';
import { cashbackPercent } from './ranks';
import { bad, notFound } from './errors';
import { BotRefusal, botCall } from './telegram';
import { int } from './validate';

const MSK_MS = 3 * 3_600_000;

/** The «Бонусы» section: nick case, weekly cashback, consolation spins and a summary for the page. */

// ---------- Кейс за ник ----------

/**
 * The name as Telegram shows it right now (getChat works for anyone who started the bot); the name from the
 * last app launch is the fallback.
 */
export async function nickTagOk(userId: number): Promise<boolean> {
  const chat = await botCall<{ first_name?: string; last_name?: string }>('getChat', { chat_id: userId });
  if (chat && !(chat instanceof BotRefusal) && typeof chat === 'object' && chat.first_name !== undefined) return hasNickTag(chat.first_name, chat.last_name);
  const u = await one<{ first_name: string; last_name: string | null }>('SELECT first_name, last_name FROM users WHERE id = $1', [userId]);
  return !!u && hasNickTag(u.first_name, u.last_name);
}

export const needNickTag = () => bad('need_nick', `Добавь «${NICK_TAG}» в конец своего имени в Telegram — и кейс откроется`, { tag: NICK_TAG });

/**
 * Inside the opening transaction: the 12-hour cooldown of the nick case, then the tag (checked with Telegram
 * before the transaction, on every attempt).
 */
export async function takeNickCase(c: Queryable, userId: number, tagged: boolean) {
  const { rows } = await c.query<{ nick_case_at: string | null }>('SELECT nick_case_at FROM users WHERE id = $1 FOR UPDATE', [userId]);
  const last = ms(rows[0]?.nick_case_at);
  if (last && Date.now() - last < NICK_CASE_COOLDOWN_MS) throw bad('cooldown', 'Кейс за ник ещё перезаряжается', { nextAt: last + NICK_CASE_COOLDOWN_MS });
  if (!tagged) throw needNickTag();
  await c.query('UPDATE users SET nick_case_at = now() WHERE id = $1', [userId]);
}

// ---------- Cashback ----------

/** Net loss on paid cases and battles per week (positive = the player lost), from week `from` on. */
async function weekLosses(userId: number, from: number): Promise<Map<number, number>> {
  const rows = await q<{ week: number; loss: string }>(
    `SELECT floor((floor((extract(epoch FROM created_at) * 1000 + $4) / 86400000) + 3) / 7)::int AS week, sum(stake_value - payout_value) AS loss
     FROM drops
     WHERE user_id = $1 AND game = ANY($3::text[]) AND payout_value IS NOT NULL AND stake_value > 0 AND NOT demo AND created_at >= $2
     GROUP BY 1`,
    [userId, new Date(weekStart(from)), HOUSE_GAMES, MSK_MS],
  );
  return new Map(rows.map((r) => [Number(r.week), Math.max(0, num(r.loss))]));
}

/** The rank's share of a week's net loss (3–8 %, shared/ranks.ts): never more than what was lost. */
const cashbackOf = (loss: number, percent: number) => round2((loss * percent) / 100);

/** Finished weeks not collected yet (up to CASHBACK_WEEKS_BACK back) and what each of them gives. */
async function uncollected(userId: number, now: number) {
  const week = weekIndex(now);
  const from = week - CASHBACK_WEEKS_BACK;
  const [losses, claims, percent] = await Promise.all([
    weekLosses(userId, from),
    q<{ week: number }>('SELECT week FROM cashback_claims WHERE user_id = $1 AND week >= $2', [userId, from]),
    cashbackPercent(db, userId),
  ]);
  const claimed = new Set(claims.map((c) => Number(c.week)));
  const weeks: { week: number; amount: number }[] = [];
  for (let w = from; w < week; w++) {
    const amount = cashbackOf(losses.get(w) ?? 0, percent);
    if (amount > 0 && !claimed.has(w)) weeks.push({ week: w, amount });
  }
  return { weeks, accruing: cashbackOf(losses.get(week) ?? 0, percent), percent };
}

/** Finished weeks are collected on Fridays; this week's cashback keeps growing until Sunday. */
export async function cashbackState(userId: number) {
  const now = Date.now();
  const { weeks, accruing, percent } = await uncollected(userId, now);
  return {
    percent,
    available: round2(weeks.reduce((s, w) => s + w.amount, 0)),
    accruing,
    today: isCashbackDay(now),
    nextDayAt: cashbackDayStart(now),
    weekEndsAt: weekStart(weekIndex(now) + 1),
  };
}

export async function claimCashback(v: Viewer) {
  assertActive(v);
  const now = Date.now();
  if (!isCashbackDay(now)) throw bad('not_friday', 'Кэшбэк выдаётся по пятницам', { nextAt: cashbackDayStart(now) });
  const { weeks } = await uncollected(v.id, now);
  if (!weeks.length) throw bad('empty', 'Кэшбэка пока нет — он копится с проигрышей в кейсах и батлах');
  return tx(async (c) => {
    let amount = 0;
    for (const w of weeks) {
      // One row per week: a second tap (or a second device) can't collect the same week twice.
      const { rows } = await c.query('INSERT INTO cashback_claims (user_id, week, amount) VALUES ($1, $2, $3) ON CONFLICT DO NOTHING RETURNING 1', [v.id, w.week, w.amount]);
      if (rows[0]) amount += w.amount;
    }
    if (amount <= 0) throw bad('claimed', 'Кэшбэк уже получен');
    await addCoins(c, v.id, round2(amount));
    await addWager(c, v.id, round2(amount), 'bonus');
    return { amount: round2(amount) };
  });
}

// ---------- Consolation spin ----------

/**
 * Called from the upgrade transaction when a big stake was lost. Once a day: the upgrader has no house edge,
 * so an unlimited spin would be free money.
 */
export async function grantConsolation(c: Queryable, userId: number, stake: number): Promise<number | null> {
  if (stake < CONSOLATION_MIN_STAKE) return null;
  // Two upgrades lost at the same moment still make one spin.
  await c.query('SELECT 1 FROM users WHERE id = $1 FOR UPDATE', [userId]);
  const { rows } = await c.query<{ id: string }>(
    `INSERT INTO consolations (user_id, stake_value)
     SELECT $1, $2 WHERE NOT EXISTS (SELECT 1 FROM consolations WHERE user_id = $1 AND created_at > now() - make_interval(secs => $3))
     RETURNING id`,
    [userId, stake, CONSOLATION_COOLDOWN_MS / 1000],
  );
  return rows[0] ? num(rows[0].id) : null;
}

export async function openConsolation(v: Viewer, idParam: string) {
  assertActive(v);
  const id = int(idParam, 'кейс');
  return tx(async (c) => {
    const prize = pickWeighted(CONSOLATION_PRIZES.map((p) => ({ ...p })));
    const { rows } = await c.query('UPDATE consolations SET opened_at = now(), coins = $3 WHERE id = $1 AND user_id = $2 AND opened_at IS NULL RETURNING id', [id, v.id, prize.coins]);
    if (!rows[0]) throw notFound('Утешительный кейс уже открыт');
    await addCoins(c, v.id, prize.coins);
    await addWager(c, v.id, prize.coins, 'bonus');
    return { coins: prize.coins };
  });
}

// ---------- Page summary ----------

export async function bonusSummary(v: Viewer) {
  const [u, keys, consolations, cashback] = await Promise.all([
    one<{ free_case_at: string | null; nick_case_at: string | null; first_name: string; last_name: string | null; ref_had: boolean }>(
      `SELECT free_case_at, nick_case_at, first_name, last_name,
              (referred_by IS NOT NULL OR EXISTS (SELECT 1 FROM users f WHERE f.referred_by = users.id)) AS ref_had
       FROM users WHERE id = $1`,
      [v.id],
    ),
    q<{ case_id: string; count: number }>('SELECT case_id, count FROM case_keys WHERE user_id = $1 AND count > 0', [v.id]),
    q<{ id: string; stake_value: string }>('SELECT id, stake_value FROM consolations WHERE user_id = $1 AND opened_at IS NULL ORDER BY id LIMIT 10', [v.id]),
    cashbackState(v.id),
  ]);
  const freeAt = ms(u?.free_case_at);
  const nickAt = ms(u?.nick_case_at);
  return {
    free: { readyAt: freeAt ? freeAt + FREE_CASE_COOLDOWN_MS : null },
    nick: { readyAt: nickAt ? nickAt + NICK_CASE_COOLDOWN_MS : null, tag: NICK_TAG, tagged: !!u && hasNickTag(u.first_name, u.last_name) },
    referralKeys: keys.find((k) => k.case_id === 'referral')?.count ?? 0,
    /** The referral case comes once per account (iteration 38): true once this account has had it. */
    referralHad: !!u?.ref_had,
    cashback,
    consolations: consolations.map((c) => ({ id: num(c.id), stake: num(c.stake_value) })),
  };
}
