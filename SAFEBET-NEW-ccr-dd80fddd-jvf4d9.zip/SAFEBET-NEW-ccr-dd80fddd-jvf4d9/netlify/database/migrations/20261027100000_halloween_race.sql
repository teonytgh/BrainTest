-- Хэллоуин-ивент «Ночной забег» replaces «Тыквенная ночь» (no round was left open; the history stays in drops).
DROP TABLE IF EXISTS pumpkin_rounds;

-- Every player's next race key: its sha256 is shown before the race, the key itself right after; then a new one.
-- The lineup and form come from sha256('race:lineup:' || seed), the finish order from sha256('race:result:' || seed).
CREATE TABLE halloween_seeds (
  user_id BIGINT PRIMARY KEY REFERENCES users (id),
  seed TEXT NOT NULL,
  hash TEXT NOT NULL,
  nonce INT NOT NULL DEFAULT 0
);

CREATE INDEX drops_halloween_top ON drops (payout_value DESC) WHERE game = 'halloween';

INSERT INTO settings (key, value) VALUES ('halloween', '{"enabled": true, "endsAt": 1793480400000}'::jsonb)
ON CONFLICT (key) DO NOTHING;

ALTER TABLE halloween_seeds ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'anon') THEN
    EXECUTE 'REVOKE ALL ON halloween_seeds FROM anon, authenticated';
  END IF;
END $$;
