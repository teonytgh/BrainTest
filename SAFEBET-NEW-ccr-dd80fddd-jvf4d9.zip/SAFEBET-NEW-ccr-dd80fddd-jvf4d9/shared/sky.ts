/**
 * «Небо Meowl» (iteration 35): an event in which every player flies Meowl with a joystick over an endless map and
 * collects coins of 0.5 B, up to the run's cap per player and the run's pool for everybody (iteration 37: 100 players
 * must share a pool, not take 20 B each). Coins lie one at a time in different places; natural eggs are close to
 * unfindable. Every 3 minutes (a wall-clock schedule, the same in every room and app) the sky turns into a 30-second
 * fight: everyone against everyone with swords, for fun — no coins change hands. The world is drawn from the run's
 * seed, chunk by chunk; the coins and the rare natural eggs come from the seed alone (a hash, no terrain), so the
 * server places them exactly where the app draws them and checks every pick against that. A coin is shared: the first
 * player to take it gets it and it vanishes for everyone. Eggs are worth 10 B over the cap: a few hide in the map by
 * themselves, and an admin can drop one next to everyone online or N random players.
 */

/** One chunk of the map, in world units (1 unit = 1 css px at zoom 1). */
export const SKY_CHUNK = 512;
export const SKY_COIN_VALUE = 0.5;
export const SKY_EGG_VALUE = 10;
export const SKY_DEFAULT_MAX = 10;
export const SKY_MAX_CAP = 500;
/** The run's coin pool for everybody (iteration 37), B; the admin sets it. */
export const SKY_DEFAULT_POOL = 100;
export const SKY_MAX_POOL = 100_000;
/** A chunk holds one coin this often (iteration 37: single coins in different places, not trails). */
export const SKY_COIN_CHANCE = 0.18;
export const SKY_MAX_MINUTES = 180;
export const SKY_MAX_REPEAT_HOURS = 48;
/** Meowl's cruising speed (units per second). */
export const SKY_SPEED = 260;
/** How close Meowl's centre must come to a coin to take it. */
export const SKY_PICK_RADIUS = 44;
/** New players start somewhere in this ring around the map's origin (not all on one spot). */
export const SKY_SPAWN_RADIUS = 1400;
/** Natural eggs: about one chunk in this many hides one — close to unfindable (iteration 37). */
export const SKY_EGG_CHUNKS = 4000;
/** A spawned egg lands this far from its player. */
export const SKY_EGG_NEAR = [180, 340] as const;
/** The room's player cap (free-plan request budget: see docs/SPEC.md, iteration 35). */
export const SKY_ROOM_LIMIT = 150;

export interface SkyRun {
  runId: number;
  seed: number;
  startedAt: number;
  endsAt: number;
  /** The coin cap per player for this run, B (eggs come on top). */
  max: number;
  /** Only players with a real deposit play (multi-accounts don't farm). */
  needDeposit: boolean;
  /** The coins of the whole run for everybody, B (iteration 37); null for older runs (no pool). */
  pool?: number | null;
}

export interface SkyPoint {
  x: number;
  y: number;
}

export interface SkyCoin extends SkyPoint {
  key: string;
}

/** A 32-bit integer hash of a few integers (deterministic on the server and in the app). */
export function hashInts(...v: number[]): number {
  let h = 0x811c9dc5 ^ v.length;
  for (const n of v) {
    h = Math.imul(h ^ (n | 0), 0x01000193);
    h ^= h >>> 15;
    h = Math.imul(h, 0x2c1b3c6d);
    h ^= h >>> 12;
    h = Math.imul(h, 0x297a2d39);
    h ^= h >>> 15;
  }
  return h >>> 0;
}

/** A number in [0, 1) from the seed and a few integers. */
export const rand01 = (...v: number[]) => hashInts(...v) / 4294967296;

/** The coin of one chunk, if it has one (SKY_COIN_CHANCE): a single coin somewhere in it, key `c:<cx>:<cy>:0`. */
export function chunkCoins(seed: number, cx: number, cy: number): SkyCoin[] {
  const r = (salt: number) => rand01(seed, cx, cy, salt);
  if (r(1) >= SKY_COIN_CHANCE) return [];
  return [{ key: `c:${cx}:${cy}:0`, x: Math.round(cx * SKY_CHUNK + 60 + r(2) * (SKY_CHUNK - 120)), y: Math.round(cy * SKY_CHUNK + 60 + r(3) * (SKY_CHUNK - 120)) }];
}

/** A natural egg hidden in this chunk (about one chunk in SKY_EGG_CHUNKS), key `n:<cx>:<cy>`. */
export function naturalEgg(seed: number, cx: number, cy: number): SkyCoin | null {
  if (rand01(seed, cx, cy, 777) * SKY_EGG_CHUNKS >= 1) return null;
  return {
    key: `n:${cx}:${cy}`,
    x: Math.round(cx * SKY_CHUNK + 120 + rand01(seed, cx, cy, 778) * (SKY_CHUNK - 240)),
    y: Math.round(cy * SKY_CHUNK + 120 + rand01(seed, cx, cy, 779) * (SKY_CHUNK - 240)),
  };
}

export const chunkOf = (v: number) => Math.floor(v / SKY_CHUNK);

/** A coin or natural egg by its key, or null if the run's map has no such thing. */
export function skyThing(seed: number, key: string): (SkyCoin & { kind: 'coin' | 'egg' }) | null {
  const coin = /^c:(-?\d{1,6}):(-?\d{1,6}):(\d{1,2})$/.exec(key);
  if (coin) {
    const found = chunkCoins(seed, Number(coin[1]), Number(coin[2])).find((c) => c.key === key);
    return found ? { ...found, kind: 'coin' } : null;
  }
  const egg = /^n:(-?\d{1,6}):(-?\d{1,6})$/.exec(key);
  if (egg) {
    const found = naturalEgg(seed, Number(egg[1]), Number(egg[2]));
    return found ? { ...found, kind: 'egg' } : null;
  }
  return null;
}

/** Where a new player starts: a point in the spawn ring, from the seed and the player. */
export function spawnPoint(seed: number, userId: number): SkyPoint {
  const a = rand01(seed, userId, 901) * Math.PI * 2;
  const d = Math.sqrt(rand01(seed, userId, 902)) * SKY_SPAWN_RADIUS;
  return { x: Math.round(Math.cos(a) * d), y: Math.round(Math.sin(a) * d) };
}

/**
 * Could Meowl have flown from `from` (at `fromAt`, ms) to within reach of `to` by `at`? A third over the top speed and
 * a little slack for lag — enough for any honest flight, nowhere near a teleport.
 */
export function canReach(from: SkyPoint, fromAt: number, to: SkyPoint, at: number): boolean {
  const dt = Math.max(0, at - fromAt) / 1000;
  return Math.hypot(to.x - from.x, to.y - from.y) <= SKY_SPEED * 1.35 * dt + SKY_PICK_RADIUS + 160;
}

/** «7 мин» / «1 ч 20 мин» for the event's time left. */
export const skyLeft = (ms: number) => {
  const m = Math.max(0, Math.ceil(ms / 60000));
  return m >= 60 ? `${Math.floor(m / 60)} ч ${m % 60} мин` : `${m} мин`;
};

// ---------- Fights (iteration 37) ----------

/** Every 3 minutes of the wall clock the last 30 seconds are a fight. */
export const SKY_FIGHT_EVERY_MS = 180_000;
export const SKY_FIGHT_MS = 30_000;
export const SKY_HP = 100;
export const SKY_HIT = 20;
/** A sword reaches this far (world units) from Meowl's centre. */
export const SKY_HIT_REACH = 110;
export const SKY_HIT_COOLDOWN_MS = 600;

/** The fight on the wall clock: is one on, when it ends, when the next starts. */
export function skyFight(now: number): { on: boolean; until: number; next: number } {
  const start = Math.floor(now / SKY_FIGHT_EVERY_MS) * SKY_FIGHT_EVERY_MS;
  const fightAt = start + SKY_FIGHT_EVERY_MS - SKY_FIGHT_MS;
  const end = start + SKY_FIGHT_EVERY_MS;
  return now >= fightAt ? { on: true, until: end, next: fightAt + SKY_FIGHT_EVERY_MS } : { on: false, until: fightAt, next: fightAt };
}
