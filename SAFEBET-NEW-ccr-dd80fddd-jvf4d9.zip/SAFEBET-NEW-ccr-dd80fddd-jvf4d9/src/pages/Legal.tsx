import { LegalText } from '../components/Consent';
import { PRIVACY, TERMS } from '../lib/legalDocs';

/** #/terms and #/privacy: the documents the player accepted, readable any time (and from the bot's /terms). */
export function Legal({ which }: { which: 'terms' | 'privacy' }) {
  const doc = which === 'terms' ? TERMS : PRIVACY;
  return (
    <section className="legal-page" aria-labelledby="legal-title">
      <h1 id="legal-title" className="page-title">
        {doc.title}
      </h1>
      <LegalText doc={doc} />
    </section>
  );
}
