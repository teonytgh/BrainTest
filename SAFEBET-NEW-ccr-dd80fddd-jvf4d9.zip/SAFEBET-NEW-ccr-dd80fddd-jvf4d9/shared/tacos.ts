/**
 * «Raining Tacos» — a timed party event. While it runs the app shows a disco page where tacos rain from the
 * clouds to the song, and now and then a golden coin-taco falls: catching it has a small chance to pay a few
 * coins. The payout is server-authoritative and capped per player per day so the free coins stay a promo, not a
 * faucet (coins are bought with Stars). Admins switch it on with an end time.
 */
export interface TacosEvent {
  enabled: boolean;
  /** When the party ends (ms since epoch). */
  endsAt: number;
}

export const DEFAULT_TACOS: TacosEvent = { enabled: false, endsAt: 0 };

export const tacosActive = (e: TacosEvent, now: number = Date.now()): boolean => e.enabled && e.endsAt > now;

/** Catching a coin-taco: chance it pays, how much, the pause between catches and the daily cap. */
export const TACO_COIN_CHANCE = 0.05; // 5 % of catches pay…
export const TACO_COIN_AMOUNT = 5; // …and pay 5 B.
export const TACO_CATCH_COOLDOWN_MS = 12_000;
export const TACO_CATCHES_PER_DAY = 20;

/** The daily cap resets at Moscow midnight (UTC+3), like the cashback week. */
export function tacoDay(now: number = Date.now()): string {
  return new Date(now + 3 * 3600_000).toISOString().slice(0, 10);
}
