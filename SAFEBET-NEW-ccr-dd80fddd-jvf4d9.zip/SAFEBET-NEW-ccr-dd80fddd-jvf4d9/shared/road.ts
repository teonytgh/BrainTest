import { floor2 } from './money';

/**
 * «Дорога» — our take on Chicken Road: a brainrot crosses a road lane by lane. Every lane can end in a crash (its
 * level's chance), a safe lane raises the multiplier, and the player takes the win after any step. A crash burns the
 * stake (brainrots only, 1–5).
 *
 * Lane k pays floor2(ROAD_RTP / (1 − p)^k): whatever lane the player leaves on, the house keeps 6 %. Lanes above
 * x50 are not offered, and a step whose win would pass MAX_ROAD_PAYOUT is refused («лимит — забирай»).
 *
 * The lanes come from the run's key, committed before the stake (its sha256 is shown first): lane k is a crash when
 * the first 32 bits of sha256("road:" + key + ":" + k) / 2^32 fall below p. The key is revealed when the run ends.
 */
export const ROAD_LEVELS = [
  { id: 'easy', name: 'Лёгкий', risk: 0.04, lanes: 24 },
  { id: 'medium', name: 'Средний', risk: 0.12, lanes: 22 },
  { id: 'hard', name: 'Сложный', risk: 0.2, lanes: 17 },
  { id: 'hardcore', name: 'Хардкор', risk: 0.3, lanes: 11 },
] as const;

export type RoadLevel = (typeof ROAD_LEVELS)[number]['id'];
export const ROAD_LEVEL_IDS = ROAD_LEVELS.map((l) => l.id) as RoadLevel[];

export const ROAD_RTP = 0.94;
export const MAX_ROAD_MULT = 50;
export const MAX_ROAD_PAYOUT = 25_000;
export const MAX_ROAD_ITEMS = 5;
export const MIN_ROAD_STAKE = 1;

export const roadLevel = (id: string) => ROAD_LEVELS.find((l) => l.id === id);

/** What lane k (1-based) pays; 0 for lane 0 (nothing crossed yet). */
export function laneMultiplier(level: RoadLevel, k: number): number {
  const risk = roadLevel(level)?.risk ?? 1;
  return k > 0 ? floor2(ROAD_RTP / (1 - risk) ** k) : 0;
}

/** Every lane the level offers, in order (as many as Chicken Road's): its multiplier never passes MAX_ROAD_MULT. */
export function roadLanes(level: RoadLevel): number[] {
  const out: number[] = [];
  for (let k = 1; k <= (roadLevel(level)?.lanes ?? 0); k++) {
    const m = laneMultiplier(level, k);
    if (m > MAX_ROAD_MULT) break;
    out.push(m);
  }
  return out;
}

export const roadMessage = (seed: string, lane: number) => `road:${seed}:${lane}`;

/** Is lane k a crash, given the sha256 hex of roadMessage(seed, k)? */
export const laneCrashes = (level: RoadLevel, hex: string) => parseInt(hex.slice(0, 8), 16) / 2 ** 32 < (roadLevel(level)?.risk ?? 1);

/** Can the run take one more lane? Not past the road's end, not past the payout limit. */
export function nextLaneProblem(level: RoadLevel, step: number, stakeValue: number): 'end' | 'limit' | null {
  const lanes = roadLanes(level);
  if (step >= lanes.length) return 'end';
  if (stakeValue * lanes[step]! > MAX_ROAD_PAYOUT) return 'limit';
  return null;
}

export interface RoadRun {
  id: number;
  level: RoadLevel;
  step: number;
  status: 'active' | 'cashed' | 'crashed' | 'refunded';
  stakeValue: number;
  stake: string[];
  /** What leaving now pays (0 before the first step). */
  multiplier: number;
  next: { multiplier: number; problem: 'end' | 'limit' | null };
  hash: string;
  /** Revealed when the run is over. */
  seed: string | null;
  payout: { brainrotId: string | null; coins: number; itemId: number | null; value: number } | null;
}

export interface RoadState {
  nextHash: string;
  run: RoadRun | null;
  mine: { level: RoadLevel; step: number; won: boolean; multiplier: number; value: number; stakeValue: number; at: number }[];
  top: { name: string; level: RoadLevel; step: number; multiplier: number; value: number; brainrotId: string | null; at: number }[];
}
