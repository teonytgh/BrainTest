/** Telegram Stars deposits: one invoice buys `stars × rate` coins, plus the auto-promo bonus. */
export const STARS_MIN = 10;
export const STARS_MAX = 10_000;
export const DEFAULT_STAR_RATE = 1.35;
export const STAR_RATE_MIN = 0.01;
export const STAR_RATE_MAX = 1000;

/** Integer maths in hundredths, so 100 ⭐ × 1.15 is 115 and not 114.999… */
export function starsToCoins(stars: number, rate: number): number {
  return Math.floor((stars * Math.round(rate * 100)) / 100);
}

export function depositBonus(coins: number, percent: number): number {
  return Math.floor((coins * percent) / 100);
}
