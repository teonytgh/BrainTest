import { num, q } from './db';
import { publicName } from './catalog';
import { notStaff } from './staff';

/**
 * «LIVE» on the home page: the newest winning drops of all players, right under the top drop. New ones are pushed
 * to every open app over the live socket as they happen (worker/index.ts → LiveHub.publishDrops); this list is
 * what an app starts from (and the fallback when it has no socket).
 */
export interface LiveDrop {
  id: number;
  brainrotId: string;
  game: string;
  at: number;
  /** Shown like the top drop: Telegram name and photo only; publicId opens the public profile. */
  player: { publicId: string; name: string; photo: string | null };
}

export const LIVE_DROPS = 20;

interface Row {
  id: string;
  brainrot_id: string;
  game: string;
  created_at: string;
  public_id: string;
  first_name: string;
  last_name: string | null;
  photo_url: string | null;
}

// Staff aren't players: their test drops never reach the feed.
const SELECT = () => `SELECT d.id, d.brainrot_id, d.game, d.created_at, u.public_id, u.first_name, u.last_name, u.photo_url
  FROM drops d JOIN users u ON u.id = d.user_id
  WHERE d.result = 'win' AND d.brainrot_id IS NOT NULL AND NOT d.demo AND ${notStaff('d.user_id')}`;

const toDrop = (r: Row): LiveDrop => ({
  id: num(r.id),
  brainrotId: r.brainrot_id,
  game: r.game,
  at: new Date(r.created_at).getTime(),
  player: { publicId: r.public_id, name: publicName(r), photo: r.photo_url },
});

export async function recentDrops(): Promise<LiveDrop[]> {
  const rows = await q<Row>(`${SELECT()} ORDER BY d.id DESC LIMIT ${LIVE_DROPS}`);
  return rows.map(toDrop);
}

/** The drops a request recorded, read after it committed (a rolled-back drop simply isn't found). */
export async function dropsByIds(ids: number[]): Promise<LiveDrop[]> {
  if (!ids.length) return [];
  const rows = await q<Row>(`${SELECT()} AND d.id = ANY($1::bigint[]) ORDER BY d.id`, [ids]);
  return rows.map(toDrop);
}
