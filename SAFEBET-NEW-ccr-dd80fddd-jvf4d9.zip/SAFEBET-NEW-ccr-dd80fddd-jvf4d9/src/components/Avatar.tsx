import { cx } from '../lib/format';

interface AvatarUser {
  photoUrl: string | null;
  name: string;
  username?: string | null;
}

export function Avatar({ user, size = 48, className }: { user: AvatarUser; size?: number; className?: string }) {
  if (user.photoUrl) {
    return <img className={cx('avatar', className)} src={user.photoUrl} alt="" width={size} height={size} style={{ width: size, height: size }} />;
  }
  const letter = (user.username ?? user.name ?? '?').slice(0, 1).toUpperCase() || '?';
  return (
    <span className={cx('avatar avatar--initial', className)} aria-hidden="true" style={{ width: size, height: size, fontSize: size * 0.4 }}>
      {letter}
    </span>
  );
}
