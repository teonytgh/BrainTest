"""«Щелчок» — the 10-second cutscene every open app plays when an admin snaps the events on.

    blender -b -y --factory-startup --python scripts/blender/snap_cutscene.py -- OUT_DIR [--preview] [--frames 1,90,181]

Our take on Sammy's Snap from Steal a Brainrot: a dark arena with a red carpet; Sammyni Fatini (red top hat, red suit)
and the owner's sleepy white Roblox avatar walk down the carpet side by side, Sammyni's red aura and the avatar's
dream-blue one growing at every step, while the crowd of brainrots dances on both sides (hops, headbangs, sways,
spins, shuffles) and turns to watch them pass; they stop, a voxel hand snaps its fingers in close-up — white flash,
a gold shockwave, coins burst, tacos rain, everyone goes wild, Dragon Cannelloni flies over — and the picture fades
to gold for the app's «ИВЕНТЫ ВКЛЮЧЕНЫ» card.

Every brainrot is a voxel model built from its sprite in public/brainrots (a pixel → a column of cubes, thicker
towards the middle), so the cast matches the app's art. Portrait 9:16, 24 fps, 240 frames; PNG frames go to OUT_DIR
(ffmpeg turns them into public/events/snap.mp4 / snap.webm, see the end of this file). The snap lands on SNAP_FRAME:
the app plays its snap sound at SNAP_FRAME / FPS seconds.
"""
import math
import os
import sys

import bpy
import numpy as np
from mathutils import Vector

ARGS = sys.argv[sys.argv.index('--') + 1:] if '--' in sys.argv else []
POSITIONAL = [a for a in ARGS if not a.startswith('--')]
OUT = os.path.abspath(POSITIONAL[0] if POSITIONAL else 'snap_frames')
PREVIEW = '--preview' in ARGS
ONLY = [int(x) for x in ARGS[ARGS.index('--frames') + 1].split(',')] if '--frames' in ARGS else None
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
SPRITES = os.path.join(ROOT, 'public', 'brainrots')

FPS = 24
FRAMES = 240
SNAP_FRAME = 181
WALK = (24, 150)  # the host walks down the carpet
HOST_FROM, HOST_TO = 30.0, 9.0  # y along the carpet

scene = bpy.context.scene
for o in list(bpy.data.objects):
    bpy.data.objects.remove(o, do_unlink=True)
prefs = bpy.context.preferences.edit


def lin(c):
    def ch(v):
        v /= 255
        return v / 12.92 if v <= 0.04045 else ((v + 0.055) / 1.055) ** 2.4
    return (ch(c[0]), ch(c[1]), ch(c[2]), 1.0)


def link(obj, mat=None):
    scene.collection.objects.link(obj)
    if mat:
        obj.data.materials.append(mat)
    return obj


def key(target, path, frame, value=None, interp='BEZIER'):
    """A keyframe with the interpolation of our choice (set through the preference, so no fcurve plumbing)."""
    prefs.keyframe_new_interpolation_type = interp
    if value is not None:
        if isinstance(path, str) and '.' not in path and hasattr(target, path):
            setattr(target, path, value)
    target.keyframe_insert(path, frame=frame)


def keys(target, path, frames_values, interp='BEZIER'):
    for f, v in frames_values:
        setattr(target, path, v)
        key(target, path, f, interp=interp)


def socket_keys(sock, frames_values, interp='BEZIER'):
    prefs.keyframe_new_interpolation_type = interp
    for f, v in frames_values:
        sock.default_value = v
        sock.keyframe_insert('default_value', frame=f)


# ---------- Materials ----------

def principled(name, rgb, roughness=0.5, metallic=0.0, emission=None, strength=0.0):
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    b = m.node_tree.nodes['Principled BSDF']
    b.inputs['Base Color'].default_value = lin(rgb)
    b.inputs['Roughness'].default_value = roughness
    b.inputs['Metallic'].default_value = metallic
    if emission:
        b.inputs['Emission Color'].default_value = lin(emission)
        b.inputs['Emission Strength'].default_value = strength
    return m


def voxel_material(name='voxel'):
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    nt = m.node_tree
    b = nt.nodes['Principled BSDF']
    attr = nt.nodes.new('ShaderNodeAttribute')
    attr.attribute_name = 'Col'
    nt.links.new(attr.outputs['Color'], b.inputs['Base Color'])
    b.inputs['Roughness'].default_value = 0.55
    return m


def glow_material(name, rgb, strength, gradient=None):
    """Emission mixed with transparency; `gradient` = 'radial' (a soft disc) or 'beam' (fades along the cone)."""
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    m.blend_method = 'BLEND' if hasattr(m, 'blend_method') else None
    nt = m.node_tree
    nt.nodes.remove(nt.nodes['Principled BSDF'])
    out = nt.nodes['Material Output']
    em = nt.nodes.new('ShaderNodeEmission')
    em.inputs['Color'].default_value = lin(rgb)
    em.inputs['Strength'].default_value = strength
    tr = nt.nodes.new('ShaderNodeBsdfTransparent')
    mix = nt.nodes.new('ShaderNodeMixShader')
    nt.links.new(tr.outputs[0], mix.inputs[1])
    nt.links.new(em.outputs[0], mix.inputs[2])
    nt.links.new(mix.outputs[0], out.inputs['Surface'])
    if gradient:
        coord = nt.nodes.new('ShaderNodeTexCoord')
        grad = nt.nodes.new('ShaderNodeTexGradient')
        ramp = nt.nodes.new('ShaderNodeValToRGB')
        if gradient == 'radial':
            # Object coordinates of a unit plane run ±0.5: doubled, the sphere reaches 0 at the edge.
            grad.gradient_type = 'SPHERICAL'
            scale = nt.nodes.new('ShaderNodeVectorMath')
            scale.operation = 'SCALE'
            scale.inputs['Scale'].default_value = 2.0
            nt.links.new(coord.outputs['Object'], scale.inputs[0])
            nt.links.new(scale.outputs['Vector'], grad.inputs['Vector'])
        else:
            # Beam: brightest at the lamp (object z = 0), gone at the far end (z = -1 after scaling).
            sep = nt.nodes.new('ShaderNodeSeparateXYZ')
            nt.links.new(coord.outputs['Generated'], sep.inputs['Vector'])
            nt.links.new(sep.outputs['Z'], grad.inputs['Vector'])
        ramp.color_ramp.elements[0].color = (0, 0, 0, 1)
        ramp.color_ramp.elements[1].color = (1, 1, 1, 1)
        # Fall off fast: most of the shape stays clear, only its core glows.
        ramp.color_ramp.elements[0].position = 0.35 if gradient == 'beam' else 0.0
        ramp.color_ramp.interpolation = 'EASE'
        nt.links.new(grad.outputs['Fac'], ramp.inputs['Fac'])
        nt.links.new(ramp.outputs['Color'], mix.inputs['Fac'])
    else:
        mix.inputs['Fac'].default_value = 1.0
    return m, em, mix


# ---------- Voxel models from sprites ----------

VOXEL = voxel_material()


def load_pixels(path):
    img = bpy.data.images.load(path, check_existing=True)
    w, h = img.size
    px = np.array(img.pixels[:], dtype=np.float32).reshape(h, w, 4)[::-1]  # top row first
    return px


def voxelize(sprite, name, height, grid=44, depth=7, crop=None, legs=None):
    """A sprite as cubes: one column per opaque cell, thicker away from the outline. Origin at the feet.

    `legs` = (hip, gap): cells below `hip` (a share of the height from the top) and left / right of `gap` (a share of
    the width) become two more objects, each pivoting at the hip, so the model can walk. Returns (body, left, right)."""
    px = load_pixels(os.path.join(SPRITES, sprite + '.webp'))
    if crop:
        h, w = px.shape[:2]
        x0, y0, x1, y1 = crop
        px = px[int(y0 * h):int(y1 * h), int(x0 * w):int(x1 * w)]
    a = px[:, :, 3]
    ys, xs = np.where(a > 0.35)
    px = px[ys.min():ys.max() + 1, xs.min():xs.max() + 1]
    H, W = px.shape[:2]
    cell = max(H, W) / grid
    gh, gw = max(1, int(math.ceil(H / cell))), max(1, int(math.ceil(W / cell)))
    color = np.zeros((gh, gw, 3), dtype=np.float32)
    solid = np.zeros((gh, gw), dtype=bool)
    for r in range(gh):
        for c in range(gw):
            blk = px[int(r * cell):max(int(r * cell) + 1, int((r + 1) * cell)), int(c * cell):max(int(c * cell) + 1, int((c + 1) * cell))]
            al = blk[:, :, 3]
            if al.mean() > 0.45:
                solid[r, c] = True
                wgt = al[..., None]
                color[r, c] = (blk[:, :, :3] * wgt).sum(axis=(0, 1)) / max(1e-6, wgt.sum())
    # Distance to the outline (in cells), for the thickness.
    dist = np.where(solid, 99, 0).astype(np.float32)
    for _ in range(2):
        for r in range(gh):
            for c in range(gw):
                if not solid[r, c]:
                    continue
                best = dist[r, c]
                for dr, dc in ((-1, 0), (1, 0), (0, -1), (0, 1)):
                    rr, cc = r + dr, c + dc
                    nb = dist[rr, cc] if 0 <= rr < gh and 0 <= cc < gw else 0
                    best = min(best, nb + 1)
                dist[r, c] = best
        for r in range(gh - 1, -1, -1):
            for c in range(gw - 1, -1, -1):
                if not solid[r, c]:
                    continue
                best = dist[r, c]
                for dr, dc in ((-1, 0), (1, 0), (0, -1), (0, 1)):
                    rr, cc = r + dr, c + dc
                    nb = dist[rr, cc] if 0 <= rr < gh and 0 <= cc < gw else 0
                    best = min(best, nb + 1)
                dist[r, c] = best
    s = height / gh
    hip_r = int(gh * legs[0]) if legs else gh
    gap_c = int(gw * legs[1]) if legs else 0
    hip_z = (gh - hip_r) * s
    parts = {'body': ([], [], []), 'left': ([], [], []), 'right': ([], [], [])}
    for r in range(gh):
        for c in range(gw):
            if not solid[r, c]:
                continue
            part = 'body' if r < hip_r else 'left' if c < gap_c else 'right'
            verts, faces, cols = parts[part]
            t = min(depth, 1 + 0.75 * (dist[r, c] - 1))
            x0, x1 = (c - gw / 2) * s, (c + 1 - gw / 2) * s
            z0, z1 = (gh - r - 1) * s, (gh - r) * s
            if part != 'body':
                z0, z1 = z0 - hip_z, z1 - hip_z  # legs pivot at the hip
            y0, y1 = -t * s / 2, t * s / 2
            b = len(verts)
            verts += [(x0, y0, z0), (x1, y0, z0), (x1, y1, z0), (x0, y1, z0), (x0, y0, z1), (x1, y0, z1), (x1, y1, z1), (x0, y1, z1)]
            for f in ((0, 1, 5, 4), (1, 2, 6, 5), (2, 3, 7, 6), (3, 0, 4, 7), (4, 5, 6, 7), (3, 2, 1, 0)):
                faces.append(tuple(b + i for i in f))
                # Side faces a touch darker, so the cubes read as cubes.
                shade = 1.0 if f[0] == 0 else 0.82 if f[0] in (1, 3) else 0.9
                cols.append(tuple(float(min(1, v * shade)) for v in color[r, c]))

    def build(part_name, verts, faces, cols):
        mesh = bpy.data.meshes.new(part_name)
        mesh.from_pydata(verts, [], faces)
        attr = mesh.color_attributes.new('Col', 'BYTE_COLOR', 'CORNER')
        for poly, col in zip(mesh.polygons, cols):
            for li in poly.loop_indices:
                attr.data[li].color_srgb = (*col, 1.0)
        return link(bpy.data.objects.new(part_name, mesh), VOXEL)

    body = build(name, *parts['body'])
    if not legs:
        return body
    left = build(name + '-legL', *parts['left'])
    right = build(name + '-legR', *parts['right'])
    for leg in (left, right):
        leg.parent = body
        leg.location = (0, 0, hip_z)
    return body, left, right


def block(name, size, loc, mat, parent=None):
    bpy.ops.mesh.primitive_cube_add(size=1, location=(0, 0, 0))
    o = bpy.context.object
    o.name = name
    o.scale = size
    bpy.ops.object.transform_apply(scale=True)
    o.location = loc
    o.data.materials.append(mat)
    bev = o.modifiers.new('bevel', 'BEVEL')
    bev.width = 0.035
    bev.segments = 2
    if parent:
        o.parent = parent
    return o


# ---------- Render setup ----------

scene.render.engine = 'CYCLES'
scene.cycles.device = 'CPU'
scene.cycles.samples = 8 if PREVIEW else 20
scene.cycles.use_denoising = True
scene.cycles.max_bounces = 4
scene.cycles.diffuse_bounces = 2
scene.cycles.glossy_bounces = 2
scene.cycles.transparent_max_bounces = 12
scene.cycles.caustics_reflective = False
scene.cycles.caustics_refractive = False
scene.cycles.sample_clamp_indirect = 6
scene.render.resolution_x, scene.render.resolution_y = (270, 480) if PREVIEW else (540, 960)
scene.render.fps = FPS
scene.frame_start, scene.frame_end = 1, FRAMES
scene.render.image_settings.file_format = 'PNG'
scene.view_settings.view_transform = 'AgX'
scene.view_settings.look = 'AgX - Punchy' if 'AgX - Punchy' in [i.identifier for i in bpy.types.ColorManagedViewSettings.bl_rna.properties['look'].enum_items] else 'None'
world = bpy.data.worlds.new('night')
world.use_nodes = True
world.node_tree.nodes['Background'].inputs['Color'].default_value = (0.004, 0.006, 0.02, 1)
world.node_tree.nodes['Background'].inputs['Strength'].default_value = 1.0
scene.world = world

# Bloom so the aura, neon and flash glow.
comp = bpy.data.node_groups.new('snap-comp', 'CompositorNodeTree')
comp.interface.new_socket('Image', in_out='OUTPUT', socket_type='NodeSocketColor')
rl = comp.nodes.new('CompositorNodeRLayers')
glare = comp.nodes.new('CompositorNodeGlare')
glare.inputs['Type'].default_value = 'Bloom'
glare.inputs['Threshold'].default_value = 0.9
glare.inputs['Strength'].default_value = 0.55
glare.inputs['Size'].default_value = 0.6
gout = comp.nodes.new('NodeGroupOutput')
comp.links.new(rl.outputs['Image'], glare.inputs['Image'])
comp.links.new(glare.outputs[0], gout.inputs[0])
scene.compositing_node_group = comp

# ---------- The arena ----------

FLOOR = principled('floor', (16, 19, 30), roughness=0.22, metallic=0.2)
CARPET = principled('carpet', (150, 12, 24), roughness=0.85)
GOLD = principled('gold', (250, 176, 52), roughness=0.25, metallic=1.0)
STEP = principled('step', (28, 32, 46), roughness=0.4)

bpy.ops.mesh.primitive_plane_add(size=120, location=(0, 20, 0))
bpy.context.object.data.materials.append(FLOOR)
bpy.ops.mesh.primitive_cube_add(location=(0, 16, 0.02))
carpet = bpy.context.object
carpet.scale = (1.35, 19, 0.02)
carpet.data.materials.append(CARPET)
for x in (-1.42, 1.42):
    bpy.ops.mesh.primitive_cube_add(location=(x, 16, 0.03))
    trim = bpy.context.object
    trim.scale = (0.07, 19, 0.03)
    trim.data.materials.append(GOLD)
# Stands for the crowd on both sides.
for x in (-4.4, 4.4):
    bpy.ops.mesh.primitive_cube_add(location=(x, 18, 0.25))
    st = bpy.context.object
    st.scale = (1.6, 16, 0.25)
    st.data.materials.append(STEP)

# The stage at the far end: an arch of neon in the brand colours and the BC mark.
NEON_GOLD, _, _ = glow_material('neon-gold', (255, 190, 60), 18)
NEON_RED, _, _ = glow_material('neon-red', (255, 50, 60), 14)
NEON_BLUE, _, _ = glow_material('neon-blue', (60, 130, 255), 14)
for i, (mat, w, h) in enumerate(((NEON_GOLD, 7.0, 7.5), (NEON_RED, 8.0, 8.4), (NEON_BLUE, 9.0, 9.3))):
    y = 36 + i * 0.6
    for (x, z, sx, sz) in ((-w / 2, h / 2, 0.08, h / 2), (w / 2, h / 2, 0.08, h / 2), (0, h, w / 2 + 0.08, 0.08)):
        bpy.ops.mesh.primitive_cube_add(location=(x, y, z))
        n = bpy.context.object
        n.scale = (sx, 0.08, sz)
        n.data.materials.append(mat)
logo_img = bpy.data.images.load(os.path.join(ROOT, 'public', 'logo-bc.webp'))
logo = bpy.data.materials.new('logo')
logo.use_nodes = True
nt = logo.node_tree
nt.nodes.remove(nt.nodes['Principled BSDF'])
tex = nt.nodes.new('ShaderNodeTexImage')
tex.image = logo_img
em = nt.nodes.new('ShaderNodeEmission')
em.inputs['Strength'].default_value = 4.0
tr = nt.nodes.new('ShaderNodeBsdfTransparent')
mix = nt.nodes.new('ShaderNodeMixShader')
nt.links.new(tex.outputs['Color'], em.inputs['Color'])
nt.links.new(tex.outputs['Alpha'], mix.inputs['Fac'])
nt.links.new(tr.outputs[0], mix.inputs[1])
nt.links.new(em.outputs[0], mix.inputs[2])
nt.links.new(mix.outputs[0], nt.nodes['Material Output'].inputs['Surface'])
bpy.ops.mesh.primitive_plane_add(size=1, location=(0, 35.6, 4.6), rotation=(math.pi / 2, 0, 0))
lp = bpy.context.object
lp.scale = (5.4, 2.96, 1)
lp.data.materials.append(logo)

# ---------- Lights ----------

def light(name, kind, loc, energy, color=(1, 1, 1), size=1.0, spot=None, target=None):
    data = bpy.data.lights.new(name, kind)
    data.energy = energy
    data.color = color
    if kind == 'AREA':
        data.size = size
    if kind == 'SPOT':
        data.spot_size = spot or math.radians(30)
        data.spot_blend = 0.4
    if kind in ('POINT', 'SPOT'):
        data.shadow_soft_size = size
    obj = link(bpy.data.objects.new(name, data))
    obj.location = loc
    if target is not None:
        obj.rotation_euler = (Vector(target) - Vector(loc)).to_track_quat('-Z', 'Y').to_euler()
    return obj


key_light = light('key', 'AREA', (0, 2, 9), 900, (1, 0.95, 0.9), size=6, target=(0, 12, 0))
fill = light('fill', 'AREA', (0, 30, 8), 500, (0.6, 0.7, 1.0), size=8, target=(0, 18, 0))
for x in (-4.2, 4.2):
    light(f'stands{x}', 'AREA', (x, 16, 6), 700, (1, 0.9, 0.8), size=5, target=(x, 16, 0))
SPOTS = []
for i, (x, y, col) in enumerate(((-6, 8, (1, 0.85, 0.6)), (6, 14, (1, 0.85, 0.6)), (-6, 20, (1, 0.3, 0.3)), (6, 26, (0.4, 0.6, 1)))):
    s = light(f'spot{i}', 'SPOT', (x, y, 9), 2500, col, size=0.3, spot=math.radians(26), target=(0, y + 2, 0))
    SPOTS.append(s)
    # A fake light shaft: a soft cone that fades away from the lamp.
    shaft_mat, shaft_em, _ = glow_material(f'shaft{i}', tuple(int(c * 255) for c in col), 0.12, gradient='beam')
    bpy.ops.mesh.primitive_cone_add(vertices=24, radius1=0.0, radius2=2.2, depth=10, location=(0, 0, -5))
    cone = bpy.context.object
    bpy.ops.object.transform_apply(location=True)
    cone.data.materials.append(shaft_mat)
    cone.parent = s
    # Sway the lamps slowly; all of them flare on the snap.
    base = s.rotation_euler.copy()
    for f, d in ((1, 0), (60, 0.25), (120, -0.2), (181, 0.1), (240, -0.15)):
        s.rotation_euler = (base.x, base.y + d * (1 if i % 2 else -1), base.z)
        key(s, 'rotation_euler', f)
    for f, e in ((1, 2500), (178, 2500), (182, 9000), (200, 4000), (240, 4000)):
        s.data.energy = e
        key(s.data, 'energy', f)

# ---------- The host: Sammyni Fatini ----------

HOST_X = -0.5  # Sammyni on the left of the carpet, the owner's avatar on the right
AVATAR_X = 0.95
# One step every 7.5 frames; the feet land on frames 24, 31.5, 39… so every other step meets an aura pulse (every 15
# frames). The app plays its footsteps on the same frames (STEP_FRAMES in src/components/Events.tsx).
STRIDE = 'sin((frame-20.25)*0.4189)'
host, host_l, host_r = voxelize('sammyni-fatini', 'host', 2.5, grid=56, depth=9, legs=(0.79, 0.63))
host.rotation_euler = (0, 0, 0)
host['amp'] = 0.0
for f, y in ((1, HOST_FROM), (WALK[0], HOST_FROM), (WALK[1], HOST_TO), (FRAMES, HOST_TO)):
    host.location = (HOST_X, y, 0)
    key(host, 'location', f, interp='LINEAR')
# Walking (drivers on top of the keyed path: delta transforms); after the snap he dances.
for f, a in ((1, 0.0), (WALK[0], 0.0), (WALK[0] + 4, 1.0), (WALK[1] - 4, 1.0), (WALK[1], 0.0), (FRAMES, 0.0)):
    host['amp'] = a
    host.keyframe_insert('["amp"]', frame=f)
host['party'] = 0.0
for f, a in ((1, 0.0), (SNAP_FRAME + 4, 0.0), (SNAP_FRAME + 12, 1.0), (FRAMES, 1.0)):
    host['party'] = a
    host.keyframe_insert('["party"]', frame=f)


def drive(obj, path, index, expr, amp_owner=None, props=('amp',), extra=None):
    """A scripted driver; `amp_owner`'s custom props (amp, party…) and `extra` {name: (object, data path)} as variables."""
    fc = obj.driver_add(path, index)
    drv = fc.driver
    drv.type = 'SCRIPTED'
    if amp_owner is not None:
        for name in props:
            v = drv.variables.new()
            v.name = name
            v.type = 'SINGLE_PROP'
            v.targets[0].id = amp_owner
            v.targets[0].data_path = f'["{name}"]'
    for name, (target, data_path) in (extra or {}).items():
        v = drv.variables.new()
        v.name = name
        v.type = 'SINGLE_PROP'
        v.targets[0].id = target
        v.targets[0].data_path = data_path
    drv.expression = expr


HOST_PROPS = ('amp', 'party')
drive(host, 'delta_location', 2, f'abs(cos((frame-20.25)*0.4189))*0.16*amp + abs(sin(frame*0.33))*0.55*party', host, HOST_PROPS)
drive(host, 'delta_rotation_euler', 1, f'{STRIDE}*0.06*amp + sin(frame*0.2)*0.12*party', host, HOST_PROPS)
drive(host, 'delta_rotation_euler', 2, 'sin(frame*0.11)*0.35*party', host, HOST_PROPS)
drive(host_l, 'rotation_euler', 0, f'{STRIDE}*0.5*amp + sin(frame*0.66)*0.25*party', host, HOST_PROPS)
drive(host_r, 'rotation_euler', 0, f'-{STRIDE}*0.5*amp - sin(frame*0.66)*0.25*party', host, HOST_PROPS)

# ---------- The second hero: the owner's Roblox avatar ----------
# A classic R6 body (legs, torso, arms 2 units tall, the head 1.2) in white: sleepy face, a «Zzz...» sleep mask on the
# forehead, spiky white hair, the «i love sleep» tee and grey plaid pyjama pants (textures in scripts/blender/avatar,
# made from his screenshots). He walks beside Sammyni, little Zs float up from his head until the snap wakes him up,
# then he jumps with both arms in the air.

AVATAR = os.path.join(os.path.dirname(__file__), 'avatar')
U = 0.44  # one Roblox unit


def textured(name, file, roughness=0.6, box=None):
    """A material from an image: on a plane's own UVs, or projected on all sides of a box (`box` = repeat scale)."""
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    nt = m.node_tree
    b = nt.nodes['Principled BSDF']
    b.inputs['Roughness'].default_value = roughness
    tex = nt.nodes.new('ShaderNodeTexImage')
    tex.image = bpy.data.images.load(os.path.join(AVATAR, file), check_existing=True)
    if box:
        tex.projection = 'BOX'
        tex.projection_blend = 0.2
        coord = nt.nodes.new('ShaderNodeTexCoord')
        scale = nt.nodes.new('ShaderNodeVectorMath')
        scale.operation = 'SCALE'
        scale.inputs['Scale'].default_value = box
        nt.links.new(coord.outputs['Object'], scale.inputs[0])
        nt.links.new(scale.outputs['Vector'], tex.inputs['Vector'])
    nt.links.new(tex.outputs['Color'], b.inputs['Base Color'])
    return m


AV_SKIN = principled('av-skin', (240, 240, 243), roughness=0.55)
AV_SHIRT = principled('av-shirt', (232, 232, 237), roughness=0.7)
AV_HAIR = principled('av-hair', (246, 246, 250), roughness=0.45)
AV_FACE = textured('av-face', 'face_tex.png', 0.55)
AV_TEE = textured('av-tee', 'shirt_tex.png', 0.7)
AV_MASK = textured('av-mask', 'mask_tex.png', 0.6)
AV_PANTS = textured('av-pants', 'plaid.png', 0.75, box=1.6)


def box(name, size, loc, mat, parent, bevel=0.02):
    o = block(name, size, loc, mat, parent)
    o.modifiers['bevel'].width = bevel
    return o


def decal(name, size, loc, mat, parent):
    """A textured plane facing the camera side (-Y), just in front of a box."""
    bpy.ops.mesh.primitive_plane_add(size=1, rotation=(math.pi / 2, 0, 0))
    o = bpy.context.object
    o.name = name
    o.scale = (size[0], size[1], 1)
    bpy.ops.object.transform_apply(rotation=True, scale=True)
    o.location = loc
    o.data.materials.append(mat)
    o.parent = parent
    return o


def pivot(name, loc, parent):
    e = bpy.data.objects.new(name, None)
    link(e)
    e.parent = parent
    e.location = loc
    return e


avatar = bpy.data.objects.new('avatar', None)
link(avatar)
avatar['amp'] = 0.0
avatar['party'] = 0.0
avatar['sleepy'] = 1.0
for f, y in ((1, HOST_FROM + 0.4), (WALK[0], HOST_FROM + 0.4), (WALK[1], HOST_TO + 0.4), (FRAMES, HOST_TO + 0.4)):
    avatar.location = (AVATAR_X, y, 0)
    key(avatar, 'location', f, interp='LINEAR')
for prop, frames_values in (
    ('amp', ((1, 0.0), (WALK[0], 0.0), (WALK[0] + 4, 1.0), (WALK[1] - 4, 1.0), (WALK[1], 0.0), (FRAMES, 0.0))),
    ('party', ((1, 0.0), (SNAP_FRAME + 2, 0.0), (SNAP_FRAME + 8, 1.0), (FRAMES, 1.0))),
    ('sleepy', ((1, 1.0), (SNAP_FRAME - 1, 1.0), (SNAP_FRAME + 1, 0.0), (FRAMES, 0.0))),
):
    for f, a in frames_values:
        avatar[prop] = a
        avatar.keyframe_insert(f'["{prop}"]', frame=f)
AV_PROPS = ('amp', 'party')
AV_STRIDE = 'sin((frame-20.25)*0.4189)'
drive(avatar, 'delta_location', 2, 'abs(cos((frame-20.25)*0.4189))*0.1*amp + abs(sin(frame*0.36+0.8))*0.7*party', avatar, AV_PROPS)
drive(avatar, 'delta_rotation_euler', 2, f'{AV_STRIDE}*0.05*amp + sin(frame*0.18)*0.25*party', avatar, AV_PROPS)

torso = box('av-torso', (2 * U, 1 * U, 2 * U), (0, 0, 3 * U), AV_SHIRT, avatar)
decal('av-tee', (1.9 * U, 1.9 * U), (0, -0.5 * U - 0.004, 3 * U), AV_TEE, avatar)
neck = pivot('av-neck', (0, 0, 4 * U), avatar)
drive(neck, 'rotation_euler', 0, '0.18*sleepy + sin(frame*0.36)*0.12*party', avatar, ('sleepy', 'party'))
head = box('av-head', (1.25 * U, 1.15 * U, 1.2 * U), (0, 0, 0.62 * U), AV_SKIN, neck, bevel=0.06)
decal('av-face', (1.15 * U, 1.1 * U), (0, -0.575 * U - 0.004, 0.55 * U), AV_FACE, neck)
decal('av-mask', (1.2 * U, 0.38 * U), (0, -0.575 * U - 0.008, 1.02 * U), AV_MASK, neck)
# Spiky hair: low pyramids fanned over the top and the back.
for i, (x, y, z, rx, ry, h) in enumerate((
    (0.0, 0.0, 1.25, 0, 0, 0.55), (-0.35, -0.15, 1.2, -0.3, -0.55, 0.5), (0.35, -0.15, 1.2, -0.3, 0.55, 0.5),
    (-0.2, 0.3, 1.2, 0.5, -0.3, 0.55), (0.2, 0.3, 1.2, 0.5, 0.3, 0.55), (0.0, -0.4, 1.18, -0.75, 0, 0.42),
    (-0.5, 0.15, 1.05, 0.2, -1.0, 0.45), (0.5, 0.15, 1.05, 0.2, 1.0, 0.45), (0.0, 0.5, 1.0, 1.1, 0, 0.5),
)):
    bpy.ops.mesh.primitive_cone_add(vertices=4, radius1=0.32 * U, radius2=0.0, depth=h * U, location=(0, 0, h * U / 2))
    spike = bpy.context.object
    spike.name = f'av-hair{i}'
    bpy.ops.object.transform_apply(location=True)
    spike.location = (x * U, y * U, z * U)
    spike.rotation_euler = (rx, ry, math.radians(45))
    spike.data.materials.append(AV_HAIR)
    spike.parent = neck
bpy.ops.mesh.primitive_cube_add(size=1, location=(0, 0.05 * U, 1.22 * U))
cap = bpy.context.object
cap.name = 'av-hair-cap'
cap.scale = (1.32 * U, 1.25 * U, 0.28 * U)
cap.data.materials.append(AV_HAIR)
cap.parent = neck

LIMBS = {}
for side, sx in (('L', -1), ('R', 1)):
    sh = pivot(f'av-shoulder{side}', (sx * 1.5 * U, 0, 3.8 * U), avatar)
    box(f'av-arm{side}', (1 * U, 1 * U, 2 * U), (0, 0, -0.8 * U), AV_SKIN, sh)
    hip = pivot(f'av-hip{side}', (sx * 0.5 * U, 0, 2 * U), avatar)
    box(f'av-leg{side}', (0.98 * U, 0.98 * U, 2 * U), (0, 0, -1 * U), AV_PANTS, hip)
    LIMBS[side] = (sh, hip)
    sign = 1 if side == 'L' else -1
    # Walk: legs and the opposite arms swing; party: arms up in a V, waving, legs kick.
    drive(hip, 'rotation_euler', 0, f'{sign}*{AV_STRIDE}*0.55*amp + {sign}*sin(frame*0.72)*0.2*party', avatar, AV_PROPS)
    drive(sh, 'rotation_euler', 0, f'{-sign}*{AV_STRIDE}*0.5*amp', avatar, AV_PROPS)
    drive(sh, 'rotation_euler', 1, f'{-sx}*(2.55 + sin(frame*0.5+{sign})*0.25)*party', avatar, AV_PROPS)

# Little Zs float up from his head while he sleepwalks; the snap wakes him (they pop).
Z_MAT, _, _ = glow_material('zzz', (190, 215, 255), 6)
for i in range(3):
    zc = bpy.data.curves.new(f'z{i}', 'FONT')
    zc.body = 'Z' if i == 0 else 'z'
    zc.align_x = 'CENTER'
    zc.extrude = 0.02
    zo = link(bpy.data.objects.new(f'z{i}', zc), Z_MAT)
    zo.parent = avatar
    zo.rotation_euler = (math.pi / 2, 0, 0)
    ph = f'((frame*0.022 + {i / 3:.3f}) % 1.0)'
    drive(zo, 'location', 0, f'0.35 + {ph}*0.5 + sin(frame*0.1+{i})*0.06')
    drive(zo, 'location', 2, f'{4.6 * U + 0.35:.3f} + {ph}*0.9')
    for axis in range(3):
        drive(zo, 'scale', axis, f'sin({ph}*3.1416)*0.32*sleepy', avatar, ('sleepy',))

# His own aura: a cool dream-blue halo that grows with Sammyni's red one.
dream_mat, dream_em, _ = glow_material('dream', (110, 160, 255), 0.0, gradient='radial')
bpy.ops.mesh.primitive_plane_add(size=1, rotation=(math.pi / 2, 0, 0))
dream = bpy.context.object
dream.scale = (3.4, 3.8, 1)
dream.location = (0, 0.6, 1.25)
dream.data.materials.append(dream_mat)
dream.parent = avatar

# The aura: a red halo behind him, a red light and sparks — all growing step by step.
halo_mat, halo_em, _ = glow_material('aura', (255, 30, 40), 0.0, gradient='radial')
bpy.ops.mesh.primitive_plane_add(size=1, rotation=(math.pi / 2, 0, 0))
halo = bpy.context.object
halo.scale = (4.2, 4.6, 1)
halo.location = (0, 0.6, 1.3)
halo.data.materials.append(halo_mat)
halo.parent = host
steps = list(range(WALK[0], WALK[1] + 1, 15))
aura = [(1, 0.0), (WALK[0], 0.4)]
for i, f in enumerate(steps):
    aura.append((f, 0.6 + i * 0.9))
    aura.append((f + 3, 1.1 + i * 0.9))
aura = [(f, v * 0.25) for f, v in aura] + [(170, 2.3), (181, 4.5), (190, 1.2), (FRAMES, 1.2)]
socket_keys(halo_em.inputs['Strength'], aura)
socket_keys(dream_em.inputs['Strength'], [(f, v * 0.6) for f, v in aura])
red_light = light('aura-light', 'POINT', (-0.3, 0.9, 1.8), 0, (1, 0.12, 0.1), size=0.6)
red_light.parent = host
keys(red_light.data, 'energy', [(1, 0), (WALK[0], 60), (WALK[1], 600), (178, 900), (182, 2200), (200, 600), (FRAMES, 600)])

SPARK_MAT, _, _ = glow_material('spark', (255, 60, 50), 12)
bpy.ops.mesh.primitive_cube_add(size=0.05)
spark = bpy.context.object
spark.data.materials.append(SPARK_MAT)
spark.location = (0, -100, 0)
bpy.ops.mesh.primitive_cylinder_add(radius=0.7, depth=0.1, location=(0, 0, 0.05))
spark_src = bpy.context.object
spark_src.parent = host
spark_src.show_instancer_for_render = False  # the emitter stays unseen, its particles render
mod = spark_src.modifiers.new('sparks', 'PARTICLE_SYSTEM')
ps = spark_src.particle_systems[0].settings
ps.count = 260 if PREVIEW else 700
ps.frame_start, ps.frame_end = WALK[0], 185
ps.lifetime = 30
ps.lifetime_random = 0.5
ps.emit_from = 'FACE'
ps.normal_factor = 1.2
ps.factor_random = 0.8
ps.effector_weights.gravity = -0.12
ps.render_type = 'OBJECT'
ps.instance_object = spark
ps.particle_size = 1.0
ps.size_random = 0.7
ps.use_rotations = True
ps.rotation_factor_random = 1.0

# ---------- The crowd ----------

CROWD = [
    ('los-tacoritas', -3.7, 7.5, 1.4, 'hop'), ('skibidi-toilet', 3.7, 8.5, 1.9, 'headbang'),
    ('john-pork', -3.6, 11.5, 2.0, 'sway'), ('meowl', 3.6, 12.5, 1.8, 'spin'),
    ('strawberry-elephant', -3.8, 16.0, 2.0, 'bounce'), ('garama-and-madundung', 3.7, 17.0, 2.1, 'shuffle'),
    ('los-admins', -3.7, 20.5, 1.8, 'headbang'), ('chillin-chili', 3.6, 21.5, 1.7, 'hop'),
    ('tralaledon', -3.9, 25.5, 1.6, 'spin'), ('capitano-moby', 3.8, 26.0, 2.0, 'sway'),
]
for i, (sprite, x, y, h, style) in enumerate(CROWD):
    o = voxelize(sprite, f'crowd{i}', h, grid=38, depth=6)
    o.location = (x, y, 0.5)
    o.rotation_euler = (0, 0, math.radians(-28 if x < 0 else 28))
    o['amp'] = 0.0
    # Lively from the start, wild after the snap.
    for f, a in ((1, 0.3), (150, 0.4), (179, 0.2), (182, 1.0), (FRAMES, 0.8)):
        o['amp'] = a
        o.keyframe_insert('["amp"]', frame=f)
    w = 0.3 + (i % 4) * 0.05
    ph = i * 1.3
    side = -1 if x < 0 else 1
    # Heads turn after the heroes as they pass (host y from the keyed walk), until the snap.
    look = f'max(-0.6, min(0.6, (hy-{y})*0.09))*{side}*(frame<181)'
    hy = {'hy': (host, 'location[1]')}
    jump = f'abs(sin(frame*{w:.2f}+{ph:.1f}))'
    if style == 'hop':
        drive(o, 'delta_location', 2, f'{jump}*1.2*amp', o)
        drive(o, 'delta_scale', 2, f'1 - (1-{jump})*0.28*amp', o)
        drive(o, 'delta_scale', 0, f'1 + (1-{jump})*0.16*amp', o)
        drive(o, 'delta_rotation_euler', 2, look, o, extra=hy)
    elif style == 'headbang':
        drive(o, 'delta_location', 2, f'{jump}*0.35*amp', o)
        drive(o, 'delta_rotation_euler', 0, f'sin(frame*0.62+{ph:.1f})*0.45*amp', o)
        drive(o, 'delta_rotation_euler', 2, look, o, extra=hy)
    elif style == 'sway':
        drive(o, 'delta_location', 2, f'{jump}*0.3*amp', o)
        drive(o, 'delta_rotation_euler', 1, f'sin(frame*0.19+{ph:.1f})*0.42*amp', o)
        drive(o, 'delta_rotation_euler', 2, look, o, extra=hy)
    elif style == 'spin':
        drive(o, 'delta_location', 2, f'{jump}*0.6*amp', o)
        drive(o, 'delta_rotation_euler', 2, f'{look} + sin(frame*0.15+{ph:.1f})*0.2*amp*(frame<181) + (frame>=181)*(frame-181)*0.32', o, extra=hy)
    elif style == 'shuffle':
        drive(o, 'delta_location', 0, f'sin(frame*0.24+{ph:.1f})*0.45*amp', o)
        drive(o, 'delta_location', 2, f'{jump}*0.4*amp', o)
        drive(o, 'delta_rotation_euler', 2, f'{look} + sin(frame*0.48)*0.18*amp', o, extra=hy)
    else:  # bounce
        drive(o, 'delta_location', 2, f'{jump}*amp', o)
        drive(o, 'delta_rotation_euler', 2, f'{look} + sin(frame*0.12+{ph:.1f})*0.12*amp', o, extra=hy)

# Dragon Cannelloni flies over after the snap.
dragon = voxelize('dragon-cannelloni', 'dragon', 3.2, grid=40, depth=5)
dragon.rotation_euler = (0, 0, math.radians(-90))
for f, (x, z) in ((1, (-30, 9)), (186, (-30, 9)), (240, (26, 7.5))):
    dragon.location = (x, 17, z)
    key(dragon, 'location', f, interp='LINEAR')
drive(dragon, 'delta_location', 2, 'sin(frame*0.3)*0.4')

# ---------- The snap: a voxel hand in close-up ----------

SKIN = principled('skin', (247, 196, 40), roughness=0.45)
CUFF = principled('cuff', (200, 18, 30), roughness=0.6)
WHITE = principled('white', (240, 240, 245), roughness=0.5)


hand = bpy.data.objects.new('hand', None)
link(hand)
block('palm', (0.9, 0.42, 0.95), (0, 0, 0), SKIN, hand)
block('cuff', (1.08, 0.6, 0.45), (0, 0, -0.68), CUFF, hand)
block('cuff-trim', (1.12, 0.64, 0.08), (0, 0, -0.44), WHITE, hand)

# Hand space: the palm is X wide (index at -X), Y thick (the palm faces +Y), fingers point up +Z. A negative
# rotation around X curls a segment towards the palm.


def finger(name, x, lengths, base=(0.0, 0.0, 0.5), parent=None):
    """A chain of segments, each pivoting at its base."""
    joints = []
    parent = parent or hand
    for i, ln in enumerate(lengths):
        j = bpy.data.objects.new(f'{name}{i}', None)
        link(j)
        j.parent = parent
        j.location = (x, base[1], base[2]) if i == 0 else (0, 0, lengths[i - 1])
        block(f'{name}{i}-bone', (0.21, 0.26, ln), (0, 0, ln / 2), SKIN, j)
        joints.append(j)
        parent, x = j, 0
    return joints


def tip(x, base_z, lengths, angles):
    """Where a finger's tip is in hand space for these joint angles (degrees, around X)."""
    p = Vector((x, 0, base_z))
    a = 0.0
    for ln, ang in zip(lengths, angles):
        a += math.radians(ang)
        p += Vector((0, -math.sin(a), math.cos(a))) * ln
    return p


def pose(chain, angles, frame):
    for j, ang in zip(chain, angles):
        j.rotation_euler = (math.radians(ang), 0, 0)
        key(j, 'rotation_euler', frame)


MID = (0.4, 0.32, 0.24)
index = finger('index', -0.33, (0.36, 0.28, 0.22))
middle = finger('middle', -0.11, MID)
ring = finger('ring', 0.11, (0.36, 0.28, 0.22))
pinky = finger('pinky', 0.33, (0.3, 0.24, 0.18))
PRESS = (-48, -28, -14)  # middle finger resting on the thumb
SNAPPED = (-100, -85, -55)  # …and slammed into the palm
for f in (1, FRAMES):
    pose(ring, (-95, -90, -70), f)
    pose(pinky, (-95, -90, -70), f)
    pose(index, (-8, -12, -6), f)
pose(middle, PRESS, 1)
pose(middle, PRESS, SNAP_FRAME - 2)
pose(middle, (-40, -22, -10), SNAP_FRAME - 1)  # the last squeeze
pose(middle, SNAPPED, SNAP_FRAME + 1)
pose(middle, SNAPPED, FRAMES)

# The thumb is aimed so its tip meets the middle fingertip exactly, then flicks up when the finger snaps off it.
thumb_root = bpy.data.objects.new('thumb', None)
link(thumb_root)
thumb_root.parent = hand
root = Vector((-0.47, 0.16, 0.12))
thumb_root.location = root
target = tip(-0.11, 0.5, MID, PRESS) + Vector((0, 0.02, -0.06))
reach = (target - root).length
thumb = finger('thumbseg', 0, (reach * 0.55, reach * 0.45), base=(0, 0, 0), parent=thumb_root)
aim_dir = (target - root).normalized()
flick = (aim_dir + Vector((0.1, -0.15, 0.55))).normalized()
up = Vector((0, 0, 1))
for f, d in ((1, aim_dir), (SNAP_FRAME - 1, aim_dir), (SNAP_FRAME + 1, flick), (FRAMES, flick)):
    thumb_root.rotation_mode = 'QUATERNION'
    thumb_root.rotation_quaternion = up.rotation_difference(d)
    key(thumb_root, 'rotation_quaternion', f)

# It rises into the close-up, trembles with tension, snaps, and drops away as the camera pulls back.
HX = HOST_X + 0.25  # in front of Sammyni
HAND_AT = Vector((HX, HOST_TO - 1.6, 1.2))
hand.location = HAND_AT
# Palm towards the camera (turned 140°): the thumb crossing to the middle finger reads as a snap.
hand.rotation_euler = (math.radians(6), 0, math.radians(140))
for f, z in ((150, 1.2), (160, 2.35), (178, 2.45), (SNAP_FRAME, 2.42), (SNAP_FRAME + 3, 2.58), (192, 2.5), (199, 1.4)):
    hand.location.z = z
    key(hand, 'location', f)
drive(hand, 'delta_location', 0, '(sin(frame*2.7)*0.012) * (frame > 166 and frame < 180)')
HAND_PARTS = [o for o in bpy.data.objects if o.type == 'MESH' and o.name.startswith(('palm', 'cuff', 'index', 'middle', 'ring', 'pinky', 'thumbseg'))]
for o in HAND_PARTS:
    for f, hidden in ((1, True), (151, False), (199, True)):
        o.hide_render = hidden
        key(o, 'hide_render', f, interp='CONSTANT')

# ---------- After the snap: shockwave, coins, tacos ----------

WAVE_MAT, wave_em, _ = glow_material('wave', (255, 200, 80), 0.0)
bpy.ops.mesh.primitive_torus_add(major_radius=1, minor_radius=0.05, location=(HOST_X, HOST_TO, 0.15))
wave = bpy.context.object
wave.data.materials.append(WAVE_MAT)
keys(wave, 'scale', [(1, (0.01, 0.01, 0.01)), (SNAP_FRAME, (0.2, 0.2, 0.6)), (SNAP_FRAME + 16, (26, 26, 3))])
socket_keys(wave_em.inputs['Strength'], [(1, 0), (SNAP_FRAME - 1, 0), (SNAP_FRAME, 60), (SNAP_FRAME + 16, 0)])
for f, hidden in ((1, True), (SNAP_FRAME, False), (SNAP_FRAME + 17, True)):
    wave.hide_render = hidden
    key(wave, 'hide_render', f, interp='CONSTANT')

COIN = principled('coin', (255, 184, 40), roughness=0.2, metallic=1.0, emission=(255, 170, 40), strength=1.2)
bpy.ops.mesh.primitive_cylinder_add(vertices=20, radius=0.11, depth=0.03, location=(0, -100, 0), rotation=(math.pi / 2, 0, 0))
coin = bpy.context.object
coin.data.materials.append(COIN)
bpy.ops.mesh.primitive_uv_sphere_add(radius=0.25, location=(HX - 0.1, HOST_TO - 1.3, 3.1))
burst = bpy.context.object
burst.show_instancer_for_render = False  # the emitter stays unseen, its particles render
burst.modifiers.new('coins', 'PARTICLE_SYSTEM')
cs = burst.particle_systems[0].settings
cs.count = 120 if PREVIEW else 300
cs.frame_start, cs.frame_end = SNAP_FRAME, SNAP_FRAME + 4
cs.lifetime = 120
cs.emit_from = 'FACE'
cs.normal_factor = 6
cs.factor_random = 2.5
cs.render_type = 'OBJECT'
cs.instance_object = coin
cs.particle_size = 1.0
cs.size_random = 0.4
cs.use_rotations = True
cs.rotation_factor_random = 1.0
cs.angular_velocity_mode = 'RAND'
cs.angular_velocity_factor = 8

taco = voxelize('los-tacoritas', 'taco', 0.7, grid=20, depth=4, crop=(0.32, 0.0, 0.68, 1.0))
taco.location = (0, -100, 0)
bpy.ops.mesh.primitive_plane_add(size=1, location=(0, 13, 9.5))
rain = bpy.context.object
rain.scale = (12, 18, 1)
rain.show_instancer_for_render = False  # the emitter stays unseen, its particles render
rain.modifiers.new('tacos', 'PARTICLE_SYSTEM')
ts = rain.particle_systems[0].settings
ts.count = 120 if PREVIEW else 320
ts.frame_start, ts.frame_end = SNAP_FRAME + 1, FRAMES
ts.lifetime = 70
ts.emit_from = 'FACE'
ts.normal_factor = -2
ts.factor_random = 1
ts.render_type = 'OBJECT'
ts.instance_object = taco
ts.particle_size = 1.0
ts.size_random = 0.5
ts.use_rotations = True
ts.rotation_factor_random = 1.0
ts.angular_velocity_mode = 'RAND'
ts.angular_velocity_factor = 3

# ---------- Camera ----------

cam_data = bpy.data.cameras.new('cam')
cam_data.lens = 30
cam = link(bpy.data.objects.new('cam', cam_data))
scene.camera = cam
aim = bpy.data.objects.new('aim', None)
link(aim)
track = cam.constraints.new('TRACK_TO')
track.target = aim
track.track_axis = 'TRACK_NEGATIVE_Z'
track.up_axis = 'UP_Y'
cam_data.dof.use_dof = True
cam_data.dof.focus_object = aim

SHOTS = [
    # frame, camera, aim, f-stop
    (1, (0.0, -6.0, 6.2), (0.0, 24.0, 1.2), 22),
    (40, (0.0, -2.0, 4.6), (0.0, 22.0, 1.4), 22),
    (100, (-1.2, 1.5, 3.2), (0.0, 16.0, 1.5), 22),
    (150, (-1.0, 3.6, 2.2), (0.0, HOST_TO, 1.5), 16),
    # Close-up on the hand (it rises in from below between 150 and 160).
    (151, (HX - 0.3, HOST_TO - 4.1, 2.75), (HX, HOST_TO - 1.6, 2.6), 2.8),
    (178, (HX - 0.15, HOST_TO - 3.8, 2.8), (HX, HOST_TO - 1.6, 2.65), 2.8),
    (SNAP_FRAME + 2, (HX - 0.13, HOST_TO - 3.95, 2.85), (HX, HOST_TO - 1.6, 2.7), 2.8),
    (196, (0.0, HOST_TO - 4.6, 3.0), (0.15, HOST_TO, 2.0), 5.6),
    (FRAMES, (0.0, -4.5, 6.8), (0.0, 14.0, 2.5), 22),
]
for i, (f, c, a, fstop) in enumerate(SHOTS):
    # A hard cut into the close-up: constant interpolation on the frame before it.
    interp = 'CONSTANT' if f == 150 else 'BEZIER'
    cam.location = c
    key(cam, 'location', f, interp=interp)
    aim.location = a
    key(aim, 'location', f, interp=interp)
    cam_data.dof.aperture_fstop = fstop
    key(cam_data.dof, 'aperture_fstop', f, interp=interp)
# Camera shake on the snap.
drive(cam, 'delta_location', 0, '(sin(frame*5.1)*0.06+sin(frame*3.3)*0.04) * max(0, 1 - abs(frame-183)/9)')
drive(cam, 'delta_location', 2, '(sin(frame*4.3)*0.05) * max(0, 1 - abs(frame-183)/9)')

# The flash in front of the lens: white on the snap, gold at the very end (the app's card comes up on it).
flash_mat, flash_em, flash_mix = glow_material('flash', (255, 255, 255), 3.0)
bpy.ops.mesh.primitive_plane_add(size=1)
flash = bpy.context.object
flash.data.materials.append(flash_mat)
flash.parent = cam
flash.location = (0, 0, -0.2)
socket_keys(flash_mix.inputs['Fac'], [(1, 0.0), (SNAP_FRAME - 1, 0.0), (SNAP_FRAME, 1.0), (SNAP_FRAME + 6, 0.0), (FRAMES - 16, 0.0), (FRAMES, 0.92)])
socket_keys(flash_em.inputs['Color'], [(SNAP_FRAME, lin((255, 255, 255))), (FRAMES - 16, lin((255, 196, 70))), (FRAMES, lin((255, 196, 70)))])
# Fade in from black at the start.
fade_mat, fade_em, fade_mix = glow_material('fade', (0, 0, 0), 0.0)
bpy.ops.mesh.primitive_plane_add(size=1)
fade = bpy.context.object
fade.data.materials.append(fade_mat)
fade.parent = cam
fade.location = (0, 0, -0.19)
socket_keys(fade_mix.inputs['Fac'], [(1, 1.0), (14, 0.0)])

# ---------- Render ----------

os.makedirs(OUT, exist_ok=True)
for o in bpy.data.objects:
    if o.particle_systems:
        o.particle_systems[0].point_cache.frame_end = FRAMES
frames = ONLY or list(range(1, FRAMES + 1))
if ONLY:
    # Particles need every frame before the one rendered.
    for f in range(1, max(frames) + 1):
        scene.frame_set(f)
        if f in frames:
            scene.render.filepath = os.path.join(OUT, f'{f:04d}.png')
            bpy.ops.render.render(write_still=True)
else:
    scene.render.filepath = os.path.join(OUT, '')
    bpy.ops.render.render(animation=True)
print('SNAP DONE', OUT)

# Encode (from the repo root):
#   ffmpeg -y -framerate 24 -i OUT/%04d.png -c:v libx264 -pix_fmt yuv420p -crf 23 -preset slow -movflags +faststart public/events/snap.mp4
#   ffmpeg -y -framerate 24 -i OUT/%04d.png -c:v libvpx-vp9 -pix_fmt yuv420p -crf 34 -b:v 0 public/events/snap.webm
