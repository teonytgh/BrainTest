import { useCallback, useEffect, useRef, useState } from 'react';
import { BrainrotThumb } from '../components/BrainrotCard';
import { Coin } from '../components/Coin';
import { CrashStage, type CrashPhase } from '../components/CrashStage';
import { Icon } from '../components/Icon';
import { InventoryPicker } from '../components/InventoryPicker';
import { Switch } from '../components/Toggle';
import { ApiError, errorMessage } from '../api/client';
import { act, serverOffset, setMe, useCatalog, useMe, type Me } from '../api/queries';
import type { CrashResult } from '../../server/crash';
import type { Brainrot } from '../../shared/types';
import { AUTO_MIN, CRASH_MAX, floor2, multiplierAt, parseAutoCashout } from '../../shared/crash';
import { payoutFor } from '../../shared/payout';
import { cx, formatCoins, formatMultiplier, sleep } from '../lib/format';
import { sfx, startEngine } from '../lib/sound';
import { haptic } from '../lib/telegram';
import { toast } from '../store/toast';

interface Round {
  roundId: number;
  startedAt: number;
  /** server clock minus client clock */
  offset: number;
  auto: number | null;
  brainrot: Brainrot;
}

interface Outcome {
  status: 'crashed' | 'cashed';
  crashPoint: number;
  cashedAt?: number;
  payout?: CrashResult['payout'];
}

export function Crash() {
  const me = useMe();
  const catalog = useCatalog();
  const [stakeUid, setStakeUid] = useState<number | null>(null);
  const [pickerOpen, setPickerOpen] = useState(false);
  const [autoOn, setAutoOn] = useState(true);
  const [autoText, setAutoText] = useState('2.00');
  const [autoError, setAutoError] = useState<string | null>(null);
  const [phase, setPhase] = useState<CrashPhase>('idle');
  const [multiplier, setMultiplier] = useState(1);
  const [round, setRound] = useState<Round | null>(null);
  const [outcome, setOutcome] = useState<Outcome | null>(null);
  const [history, setHistory] = useState<number[]>([]);
  const [busy, setBusy] = useState(false);
  const active = useRef<number | null>(null);
  const engine = useRef<ReturnType<typeof startEngine> | null>(null);

  const flying = phase === 'flying';
  const frozen = !!me.user.frozen;
  const stakeItem = me.inventory.find((i) => i.id === stakeUid) ?? null;
  const stake = flying && round ? round.brainrot : stakeItem ? catalog.byId.get(stakeItem.brainrotId) ?? null : null;
  const auto = autoOn ? parseAutoCashout(autoText) : null;

  const finish = useCallback((r: { result: CrashResult; me: Me }) => {
    if (active.current !== r.result.roundId || r.result.status === 'flying') return;
    active.current = null;
    engine.current?.stop();
    engine.current = null;
    const res = r.result as CrashResult & { status: 'crashed' | 'cashed' };
    setMultiplier(res.status === 'cashed' ? res.cashedAt! : res.crashPoint!);
    setPhase(res.status);
    setOutcome({ status: res.status, crashPoint: res.crashPoint!, cashedAt: res.cashedAt, payout: res.payout });
    setHistory((h) => [res.crashPoint!, ...h].slice(0, 15));
    setMe(r.me);
    if (res.status === 'cashed') {
      sfx.cashout();
      haptic('success');
    } else {
      sfx.boom();
      haptic('error');
    }
  }, []);

  const watch = useCallback(
    async (roundId: number) => {
      let failures = 0;
      while (active.current === roundId) {
        try {
          const r = await act<CrashResult>('/api/crash/wait', { roundId });
          failures = 0;
          if (r.result.status !== 'flying') {
            finish(r);
            return;
          }
        } catch (e) {
          if (e instanceof ApiError && e.status >= 400 && e.status < 500) {
            active.current = null;
            setPhase('idle');
            toast(errorMessage(e), 'error');
            return;
          }
          if (++failures > 5) {
            toast('Связь пропала — результат раунда появится в профиле', 'error');
            return;
          }
          await sleep(1000);
        }
      }
    },
    [finish],
  );

  const begin = useCallback(
    (r: Round) => {
      active.current = r.roundId;
      setRound(r);
      setOutcome(null);
      setMultiplier(1);
      setPhase('flying');
      engine.current?.stop();
      engine.current = startEngine();
      void watch(r.roundId);
    },
    [watch],
  );

  // A round still flying from a previous visit (or an app reload) continues here.
  const resumed = useRef(false);
  useEffect(() => {
    if (resumed.current || !me.crash) return;
    resumed.current = true;
    const b = catalog.byId.get(me.crash.brainrotId);
    if (!b) return;
    begin({ roundId: me.crash.roundId, startedAt: me.crash.startedAt, offset: serverOffset(), auto: me.crash.auto, brainrot: b });
  }, [me.crash, catalog.byId, begin]);

  useEffect(
    () => () => {
      active.current = null;
      engine.current?.stop();
    },
    [],
  );

  useEffect(() => {
    if (phase !== 'flying' || !round) return;
    let frame = 0;
    const tick = () => {
      let m = multiplierAt(Date.now() + round.offset - round.startedAt);
      if (round.auto !== null) m = Math.min(m, round.auto);
      m = Math.min(m, CRASH_MAX);
      setMultiplier(m);
      engine.current?.set(m);
      frame = requestAnimationFrame(tick);
    };
    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  }, [phase, round]);

  async function launch() {
    if (flying || busy || !stakeItem) return;
    if (autoOn && auto === null) {
      setAutoError(`Множитель от ${AUTO_MIN} до ${CRASH_MAX}`);
      return;
    }
    const brainrot = catalog.byId.get(stakeItem.brainrotId)!;
    setBusy(true);
    try {
      const r = await act<{ roundId: number; startedAt: number; serverNow: number; auto: number | null }>('/api/crash/start', { itemId: stakeItem.id, auto });
      setMe(r.me);
      setStakeUid(null);
      haptic('tap');
      sfx.whoosh();
      begin({ roundId: r.result.roundId, startedAt: r.result.startedAt, offset: r.result.serverNow - Date.now(), auto: r.result.auto, brainrot });
    } catch (e) {
      sfx.error();
      toast(errorMessage(e), 'error');
    } finally {
      setBusy(false);
    }
  }

  async function cashOut() {
    if (!round || busy) return;
    setBusy(true);
    try {
      const r = await act<CrashResult>('/api/crash/cashout', { roundId: round.roundId });
      finish(r);
    } catch (e) {
      toast(errorMessage(e), 'error');
    } finally {
      setBusy(false);
    }
  }

  function describe(o: Outcome): string {
    if (o.status === 'crashed') return `Ракета взорвалась на ${formatMultiplier(o.crashPoint)} — ставка сгорела`;
    const name = o.payout?.brainrotId ? catalog.byId.get(o.payout.brainrotId)?.name : null;
    const parts = [name, o.payout?.coins ? `${formatCoins(o.payout.coins)} B` : null].filter(Boolean);
    return `Забрал на ${formatMultiplier(o.cashedAt!)}${parts.length ? `: ${parts.join(' + ')}` : ''}`;
  }

  const preview = stake && auto && !flying ? payoutFor(stake.price * auto, catalog.active) : null;

  return (
    <section className="game crash" aria-labelledby="crash-title">
      <div className="crash__head">
        <h1 id="crash-title" className="page-title">
          Краш
        </h1>
        <span className="badge badge--outline">Шанс x2 ≈ 48%</span>
      </div>

      <CrashStage phase={phase} multiplier={multiplier} />

      <div className="history" aria-label="Последние раунды">
        {history.length === 0 ? (
          <span className="history__empty">Здесь появятся множители твоих раундов</span>
        ) : (
          history.map((m, i) => (
            <span key={i} className={cx('history__chip', m >= 2 ? 'is-high' : 'is-low')}>
              {formatMultiplier(m)}
            </span>
          ))
        )}
      </div>

      <p className={cx('result-line', outcome && (outcome.status === 'cashed' ? 'is-win' : 'is-lose'))} role="status">
        {outcome ? describe(outcome) : ' '}
      </p>

      <div className="bet-panel">
        <button type="button" className="select select--wide" onClick={() => setPickerOpen(true)} disabled={flying}>
          {stake ? (
            <>
              <BrainrotThumb brainrot={stake} size={34} />
              <span className="select__text">{stake.name}</span>
              <span className="select__price">
                <Coin size={13} /> {formatCoins(stake.price)}
              </span>
            </>
          ) : (
            <span className="select__text">Выбери брейнрота</span>
          )}
          <Icon name="chevronDown" size={18} />
        </button>

        <div className={cx('auto', !autoOn && 'is-off')}>
          <Switch on={autoOn} onChange={setAutoOn} label="Авто-вывод" disabled={flying} />
          <label className="auto__label" htmlFor="auto-cashout">
            Авто-вывод на
          </label>
          <span className={cx('auto__control', autoError && 'has-error')}>
            <input
              id="auto-cashout"
              inputMode="decimal"
              autoComplete="off"
              value={autoText}
              disabled={!autoOn || flying}
              aria-invalid={!!autoError}
              aria-describedby={autoError ? 'auto-error' : undefined}
              onChange={(e) => {
                setAutoText(e.target.value.replace(/[^\d.,]/g, '').slice(0, 6));
                setAutoError(null);
              }}
              onBlur={() => {
                const v = parseAutoCashout(autoText);
                if (v === null) setAutoError(`Множитель от ${AUTO_MIN} до ${CRASH_MAX}`);
                else setAutoText(v.toFixed(2));
              }}
            />
            <span aria-hidden="true">x</span>
          </span>
        </div>
        {autoError && (
          <p id="auto-error" className="field__error">
            {autoError}
          </p>
        )}

        {preview && (
          <p className="hint hint--left">
            При {formatMultiplier(auto!)} получишь: <b>{preview.brainrot?.name ?? 'монеты'}</b>
            {preview.coins > 0 && (
              <>
                {' '}+ <Coin size={12} /> {formatCoins(preview.coins)}
              </>
            )}
          </p>
        )}

        {flying ? (
          <button type="button" className="btn btn--green btn--lg btn--block" onClick={cashOut} disabled={busy}>
            Забрать {formatMultiplier(floor2(multiplier))}
          </button>
        ) : (
          <button type="button" className="btn btn--primary btn--lg btn--block" disabled={!stakeItem || busy || frozen} onClick={launch}>
            <Icon name="rocket" size={20} /> Запуск
          </button>
        )}
        {!flying && (frozen || !stakeItem) && <p className="hint">{frozen ? 'Аккаунт заморожен — играть нельзя' : 'Выбери брейнрота для ставки'}</p>}
      </div>

      <InventoryPicker open={pickerOpen} onClose={() => setPickerOpen(false)} onPick={(i) => setStakeUid(i.id)} selectedUid={stakeUid} />
    </section>
  );
}
