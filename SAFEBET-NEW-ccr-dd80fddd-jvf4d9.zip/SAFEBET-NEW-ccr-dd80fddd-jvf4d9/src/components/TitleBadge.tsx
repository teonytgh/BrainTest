import { useEffect, useLayoutEffect, useRef, useState, type CSSProperties } from 'react';
import { createPortal } from 'react-dom';
import { Icon } from './Icon';
import type { Me } from '../api/queries';
import { share } from '../lib/telegram';

type Title = Me['user']['titles'][number];

const date = new Intl.DateTimeFormat('ru-RU', { dateStyle: 'long' });

/** «Есть у 13% игроков» — the share of all players holding the title. */
function rarity(t: Pick<Title, 'holders' | 'percent'>) {
  if (t.holders <= 1) return 'Единственный в игре';
  if (t.percent < 1) return 'Есть меньше чем у 1% игроков';
  return `Есть у ${t.percent.toLocaleString('ru-RU', { maximumFractionDigits: t.percent < 10 ? 1 : 0 })}% игроков`;
}

export function TitleIcon({ title, size = 30 }: { title: Pick<Title, 'icon' | 'color' | 'name'>; size?: number }) {
  return (
    <span className="title-icon" style={{ '--glow': title.color, width: size, height: size } as CSSProperties}>
      <img src={title.icon} alt="" />
    </span>
  );
}

const CARD_W = 340;
const GAP = 12;

/**
 * Small glowing icons next to the name; a tap opens the title's card right under its icon (an arrow points at it):
 * the picture, name, description, when it was received, how rare it is, «Поделиться». A tap elsewhere, Escape or a
 * scroll closes it.
 */
export function TitleBadges({ titles, owner }: { titles: Title[]; owner: string }) {
  const [open, setOpen] = useState<{ title: Title; anchor: DOMRect; host: HTMLElement } | null>(null);
  const card = useRef<HTMLDivElement>(null);
  const [pos, setPos] = useState<{ left: number; top: number; arrow: number } | null>(null);

  // The card goes where the icons live: on the page (body) or inside the public profile's sheet (a modal <dialog> in
  // the top layer, where a card on <body> would hide behind it). A transformed sheet is its own frame for `fixed`.
  useLayoutEffect(() => {
    if (!open) return setPos(null);
    const vw = document.documentElement.clientWidth;
    const width = Math.min(CARD_W, vw - 24);
    const center = open.anchor.left + open.anchor.width / 2;
    const left = Math.max(12, Math.min(vw - width - 12, center - width / 2));
    const framed = open.host !== document.body && getComputedStyle(open.host).transform !== 'none';
    const origin = framed ? open.host.getBoundingClientRect() : { left: 0, top: 0 };
    setPos({ left: left - origin.left, top: open.anchor.bottom + GAP - origin.top, arrow: center - left });
  }, [open]);

  useEffect(() => {
    if (!open) return;
    const close = () => setOpen(null);
    const outside = (e: PointerEvent) => {
      if (!card.current?.contains(e.target as Node) && !(e.target as Element).closest?.('.title-btn')) close();
    };
    const key = (e: KeyboardEvent) => e.key === 'Escape' && close();
    document.addEventListener('pointerdown', outside, true);
    window.addEventListener('keydown', key);
    window.addEventListener('scroll', close, true);
    window.addEventListener('resize', close);
    return () => {
      document.removeEventListener('pointerdown', outside, true);
      window.removeEventListener('keydown', key);
      window.removeEventListener('scroll', close, true);
      window.removeEventListener('resize', close);
    };
  }, [open]);

  if (!titles.length) return null;
  const t = open?.title;
  return (
    <>
      <span className="title-row">
        {titles.map((x) => (
          <button
            key={x.id}
            type="button"
            className="title-btn"
            aria-label={`Титул «${x.name}»`}
            aria-expanded={t?.id === x.id}
            onClick={(e) =>
              setOpen(
                t?.id === x.id
                  ? null
                  : { title: x, anchor: e.currentTarget.getBoundingClientRect(), host: e.currentTarget.closest('dialog') ?? document.body },
              )
            }
          >
            <TitleIcon title={x} />
          </button>
        ))}
      </span>
      {t &&
        pos &&
        open &&
        createPortal(
        <div
          ref={card}
          className="title-pop"
          role="dialog"
          aria-label={`Титул «${t.name}»`}
          style={{ left: pos.left, top: pos.top, width: Math.min(CARD_W, document.documentElement.clientWidth - 24), '--glow': t.color, '--arrow': `${pos.arrow}px` } as CSSProperties}
        >
          <TitleIcon title={t} size={84} />
          <div className="title-pop__body">
            <p className="title-pop__name">{t.name}</p>
            {t.description && <p className="title-pop__text">{t.description}</p>}
            <dl className="title-pop__meta">
              <div>
                <dt>Получен</dt>
                <dd>{date.format(t.grantedAt)}</dd>
              </div>
              <div>
                <dt>Редкость</dt>
                <dd>{rarity(t)}</dd>
              </div>
            </dl>
            <button type="button" className="btn btn--ghost btn--sm title-pop__share" onClick={() => share(`${owner} получил титул «${t.name}» в BrainrotCrash!`)}>
              <Icon name="send" size={16} /> Поделиться
            </button>
          </div>
        </div>,
          open.host,
        )}
    </>
  );
}
