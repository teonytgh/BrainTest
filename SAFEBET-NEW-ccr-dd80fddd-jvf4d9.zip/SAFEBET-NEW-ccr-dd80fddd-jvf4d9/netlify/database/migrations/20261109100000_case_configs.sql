-- Iteration 33: «Конфиги кейсов» — named snapshots of everything about the cases (cases, compositions with hand-set
-- chances, home themes, coin prizes, brainrot prices) that admins save and load back. Applied by the Worker
-- (server/autoMigrate.ts), so it is safe to run twice.
CREATE TABLE IF NOT EXISTS case_configs (
  id BIGSERIAL PRIMARY KEY,
  name TEXT NOT NULL CHECK (char_length(name) BETWEEN 1 AND 60),
  data JSONB NOT NULL,
  -- The copy a load makes of what it is about to replace.
  auto BOOLEAN NOT NULL DEFAULT FALSE,
  created_by BIGINT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS case_configs_time ON case_configs (created_at DESC);

DO $$
BEGIN
  ALTER TABLE case_configs ENABLE ROW LEVEL SECURITY;
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'anon') THEN
    REVOKE ALL ON case_configs FROM anon, authenticated;
  END IF;
END $$;
