-- The project is BrainrotCrash now: bot @braincrashbot, no news channel yet. The free case stops asking for the
-- old @brainzonechannel (an owner sets a channel in admin «Контент» → бесплатный кейс when there is one).
UPDATE settings SET value = jsonb_set(value, '{channel}', 'null')
WHERE key = 'free_case_gate' AND value->>'channel' = '@brainzonechannel';
