"""Meowl — the guide of the first-visit tour, rendered in layers for the app to bring alive in CSS.

    blender -b -y --factory-startup --python scripts/blender/meowl.py -- OUT_DIR [--preview]

A voxel model built from public/brainrots/meowl.webp (one column of cubes per cell, thicker towards the middle, like the
snap cutscene's cast), turned a little to show its depth. The face is redrawn on the sprite before voxelizing: a cat's
«ω» smile with rosy cheeks (the base), closed eyes (blink) and an open mouth (talk). Every layer is rendered on the
same camera with a transparent background:

    body.png        — Meowl without wings, smiling
    blink.png       — only the pixels that differ when the eyes are closed (an overlay on body)
    talk.png        — only the pixels that differ when the mouth is open (an overlay on body)
    wing-l.png      — the left wing alone, wing-r.png — the right one
    layout.json     — the image size and the wings' shoulder pivots in pixels (for CSS transform-origin)

The app (src/components/Meowl.tsx) breathes the body, flaps the wings around their shoulders, blinks by showing
blink.png for a moment and talks by toggling talk.png while a line is typed. Convert with
`cwebp -q 88 -alpha_q 90` into public/meowl/*.webp.
"""
import json
import math
import os
import sys

import bpy
import numpy as np
from bpy_extras.object_utils import world_to_camera_view
from mathutils import Vector

ARGS = sys.argv[sys.argv.index('--') + 1:] if '--' in sys.argv else []
POSITIONAL = [a for a in ARGS if not a.startswith('--')]
OUT = os.path.abspath(POSITIONAL[0] if POSITIONAL else 'meowl_out')
PREVIEW = '--preview' in ARGS
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
SPRITE = os.path.join(ROOT, 'public', 'brainrots', 'meowl.webp')
SIZE = 360 if PREVIEW else 720
GRID = 128  # cells along the model's height: fine enough for the eyes and the smile
TURN = math.radians(-16)  # a three-quarter turn, so the voxels read as 3D

os.makedirs(OUT, exist_ok=True)
scene = bpy.context.scene
for o in list(bpy.data.objects):
    bpy.data.objects.remove(o, do_unlink=True)


def lin(c):
    def ch(v):
        v /= 255
        return v / 12.92 if v <= 0.04045 else ((v + 0.055) / 1.055) ** 2.4
    return (ch(c[0]), ch(c[1]), ch(c[2]), 1.0)


# ---------- The sprite and its face variants (480 × 480, top row first) ----------

def load_sprite():
    img = bpy.data.images.load(SPRITE, check_existing=True)
    w, h = img.size
    return np.array(img.pixels[:], dtype=np.float32).reshape(h, w, 4)[::-1].copy()


YY, XX = np.mgrid[0:480, 0:480]
LEFT_EYE, RIGHT_EYE = (209, 106), (270, 106)
NOSE_X = 238
CREAM = np.array([0.99, 0.92, 0.87, 1.0], dtype=np.float32)
INK = np.array([0.11, 0.07, 0.06, 1.0], dtype=np.float32)


def paint(px, mask, rgba):
    px[mask] = rgba


def arc_mask(cx, cy, r, a0, a1, width):
    """Pixels within width/2 of a circular arc (angles in degrees, 0 = right, 90 = down)."""
    d = np.hypot(XX - cx, YY - cy)
    ang = np.degrees(np.arctan2(YY - cy, XX - cx)) % 360
    inside = (ang >= a0) & (ang <= a1) if a0 <= a1 else (ang >= a0) | (ang <= a1)
    return (np.abs(d - r) <= width / 2) & inside


def ellipse_mask(cx, cy, rx, ry):
    return ((XX - cx) / rx) ** 2 + ((YY - cy) / ry) ** 2 <= 1


def smiling(px):
    """The base face: the «ʌ» mouth becomes a cat's «ω» smile, and the cheeks blush."""
    px = px.copy()
    paint(px, (XX >= 220) & (XX <= 257) & (YY >= 138) & (YY <= 158), CREAM)
    paint(px, (np.abs(XX - NOSE_X) <= 1.6) & (YY >= 136) & (YY <= 145), INK)
    paint(px, arc_mask(NOSE_X - 8, 144, 8, 0, 180, 3.6), INK)
    paint(px, arc_mask(NOSE_X + 8, 144, 8, 0, 180, 3.6), INK)
    for cx in (196, 282):
        m = ellipse_mask(cx, 138, 11, 6) & (px[:, :, 3] > 0.5)
        px[m, :3] = px[m, :3] * 0.45 + np.array([0.98, 0.55, 0.62]) * 0.55
    return px


def blinking(px):
    """Eyes closed: the lids in the fur around each eye, a dark happy line across."""
    px = px.copy()
    for cx, cy in (LEFT_EYE, RIGHT_EYE):
        eye = ellipse_mask(cx, cy, 22, 22)
        ring = ellipse_mask(cx, cy, 30, 30) & ~ellipse_mask(cx, cy, 24, 24) & (px[:, :, 3] > 0.5)
        lid = px[ring].mean(axis=0)
        lid[3] = 1.0
        paint(px, eye & (px[:, :, 3] > 0.3), lid)
        paint(px, arc_mask(cx, cy - 10, 16, 25, 155, 4.2), INK)
    return px


def talking(px):
    """The mouth open in a smile: dark inside, a pink tongue."""
    px = px.copy()
    paint(px, ellipse_mask(NOSE_X, 150, 11, 9) & (YY >= 143), np.array([0.36, 0.06, 0.1, 1.0], dtype=np.float32))
    paint(px, ellipse_mask(NOSE_X, 155, 7, 4), np.array([0.95, 0.45, 0.55, 1.0], dtype=np.float32))
    paint(px, arc_mask(NOSE_X, 141, 12, 20, 160, 3.0) & (YY >= 143), INK)
    return px


def wing_mask():
    """The wings are the feathered sides beside the body (sprite coordinates)."""
    return ((XX < 171) | (XX > 306)) & (YY > 160) & (YY < 352)


# ---------- Voxels ----------

def voxel_material():
    m = bpy.data.materials.new('voxel')
    m.use_nodes = True
    nt = m.node_tree
    b = nt.nodes['Principled BSDF']
    attr = nt.nodes.new('ShaderNodeAttribute')
    attr.attribute_name = 'Col'
    nt.links.new(attr.outputs['Color'], b.inputs['Base Color'])
    b.inputs['Roughness'].default_value = 0.5
    return m


VOXEL = voxel_material()


def cells(px, bbox):
    """Averages the sprite into GRID rows of square cells inside the shared bounding box."""
    y0, y1, x0, x1 = bbox
    px = px[y0:y1, x0:x1]
    H, W = px.shape[:2]
    cell = H / GRID
    gh, gw = GRID, int(math.ceil(W / cell))
    color = np.zeros((gh, gw, 3), dtype=np.float32)
    solid = np.zeros((gh, gw), dtype=bool)
    for r in range(gh):
        for c in range(gw):
            blk = px[int(r * cell):max(int(r * cell) + 1, int((r + 1) * cell)), int(c * cell):max(int(c * cell) + 1, int((c + 1) * cell))]
            if not blk.size:
                continue
            al = blk[:, :, 3]
            if al.mean() > 0.45:
                solid[r, c] = True
                w = al[..., None]
                color[r, c] = (blk[:, :, :3] * w).sum(axis=(0, 1)) / max(1e-6, w.sum())
    return color, solid


def thickness(solid):
    """Distance to the outline in cells (two chamfer passes), for a rounded body."""
    gh, gw = solid.shape
    dist = np.where(solid, 99, 0).astype(np.float32)
    for _ in range(2):
        for rows, cols in ((range(gh), range(gw)), (range(gh - 1, -1, -1), range(gw - 1, -1, -1))):
            for r in rows:
                for c in cols:
                    if not solid[r, c]:
                        continue
                    best = dist[r, c]
                    for dr, dc in ((-1, 0), (1, 0), (0, -1), (0, 1)):
                        rr, cc = r + dr, c + dc
                        nb = dist[rr, cc] if 0 <= rr < gh and 0 <= cc < gw else 0
                        best = min(best, nb + 1)
                    dist[r, c] = best
    return dist


def build(name, color, solid, dist, keep, height=2.0, depth=16):
    """One mesh from the cells where `keep` is true; thickness comes from the whole silhouette."""
    gh, gw = solid.shape
    s = height / gh
    verts, faces, cols = [], [], []
    for r in range(gh):
        for c in range(gw):
            if not (solid[r, c] and keep[r, c]):
                continue
            t = min(depth, 2 + 0.9 * (dist[r, c] - 1))
            x0, x1 = (c - gw / 2) * s, (c + 1 - gw / 2) * s
            z0, z1 = (gh - r - 1) * s, (gh - r) * s
            y0, y1 = -t * s / 2, t * s / 2
            b = len(verts)
            verts += [(x0, y0, z0), (x1, y0, z0), (x1, y1, z0), (x0, y1, z0), (x0, y0, z1), (x1, y0, z1), (x1, y1, z1), (x0, y1, z1)]
            for f in ((0, 1, 5, 4), (1, 2, 6, 5), (2, 3, 7, 6), (3, 0, 4, 7), (4, 5, 6, 7), (3, 2, 1, 0)):
                faces.append(tuple(b + i for i in f))
                shade = 1.0 if f[0] == 0 else 0.84 if f[0] in (1, 3) else 0.92
                cols.append(tuple(float(min(1, v * shade)) for v in color[r, c]))
    mesh = bpy.data.meshes.new(name)
    mesh.from_pydata(verts, [], faces)
    attr = mesh.color_attributes.new('Col', 'BYTE_COLOR', 'CORNER')
    for poly, col in zip(mesh.polygons, cols):
        for li in poly.loop_indices:
            attr.data[li].color_srgb = (*col, 1.0)
    obj = bpy.data.objects.new(name, mesh)
    scene.collection.objects.link(obj)
    obj.data.materials.append(VOXEL)
    obj.rotation_euler = (0, 0, TURN)
    return obj


raw = load_sprite()
a = raw[:, :, 3]
ys, xs = np.where(a > 0.35)
BBOX = (ys.min(), ys.max() + 1, xs.min(), xs.max() + 1)
variants = {'body': smiling(raw)}
variants['blink'] = blinking(variants['body'])
variants['talk'] = talking(variants['body'])
wing_cells = cells(np.where(wing_mask()[..., None], raw, 0), BBOX)[1]
base_color, SOLID = cells(variants['body'], BBOX)
DIST = thickness(SOLID)
gh, gw = SOLID.shape
cols_idx = np.arange(gw)[None, :].repeat(gh, 0)
LEFT_W = wing_cells & (cols_idx < gw / 2)
RIGHT_W = wing_cells & (cols_idx >= gw / 2)
BODY_KEEP = ~wing_cells
objects = {
    'body': build('meowl-body', base_color, SOLID, DIST, BODY_KEEP),
    'blink': build('meowl-blink', cells(variants['blink'], BBOX)[0], SOLID, DIST, BODY_KEEP),
    'talk': build('meowl-talk', cells(variants['talk'], BBOX)[0], SOLID, DIST, BODY_KEEP),
    'wing-l': build('meowl-wing-l', base_color, SOLID, DIST, LEFT_W),
    'wing-r': build('meowl-wing-r', base_color, SOLID, DIST, RIGHT_W),
}

# The shoulders: the top inner corner of each wing, in model space (before the turn).
s = 2.0 / gh


def shoulder(mask, inner_right):
    rows, colsn = np.where(mask)
    top = rows.min()
    near_top = colsn[rows <= top + 6]
    c = near_top.max() + 1 if inner_right else near_top.min()
    return Vector(((c - gw / 2) * s, 0, (gh - top - 4) * s))


PIVOTS = {'wing-l': shoulder(LEFT_W, True), 'wing-r': shoulder(RIGHT_W, False)}

# ---------- Camera, lights, render ----------

cam_data = bpy.data.cameras.new('cam')
cam_data.lens = 118
cam = bpy.data.objects.new('cam', cam_data)
scene.collection.objects.link(cam)
cam.location = (0.0, -8.6, 1.0)
cam.rotation_euler = (math.radians(90), 0, 0)
scene.camera = cam


def light(name, kind, loc, energy, color=(1, 1, 1), size=1.0):
    d = bpy.data.lights.new(name, kind)
    d.energy = energy
    d.color = color
    if kind == 'AREA':
        d.size = size
    o = bpy.data.objects.new(name, d)
    o.location = loc
    scene.collection.objects.link(o)
    direction = Vector((0, 0, 1.0)) - Vector(loc)
    o.rotation_euler = direction.to_track_quat('-Z', 'Y').to_euler()
    return o


light('key', 'AREA', (-3.2, -5.0, 4.2), 420, (1.0, 0.96, 0.9), 3.0)
light('fill', 'AREA', (3.6, -4.0, 1.6), 120, (0.85, 0.9, 1.0), 4.0)
light('rim-gold', 'AREA', (2.6, 3.4, 3.4), 650, (1.0, 0.78, 0.35), 2.0)
light('rim-blue', 'AREA', (-2.8, 3.2, 2.2), 420, (0.45, 0.6, 1.0), 2.0)
world = bpy.data.worlds.new('w')
world.use_nodes = True
world.node_tree.nodes['Background'].inputs['Color'].default_value = (0.03, 0.035, 0.05, 1)
world.node_tree.nodes['Background'].inputs['Strength'].default_value = 0.35
scene.world = world

scene.render.engine = 'CYCLES'
scene.cycles.device = 'CPU'
scene.cycles.samples = 24 if PREVIEW else 96
scene.cycles.use_denoising = True
scene.render.film_transparent = True
scene.render.resolution_x = SIZE
scene.render.resolution_y = SIZE
scene.render.image_settings.file_format = 'PNG'
scene.render.image_settings.color_mode = 'RGBA'
scene.view_settings.view_transform = 'Standard'


def render(name, visible):
    for key, obj in objects.items():
        obj.hide_render = key not in visible
    scene.render.filepath = os.path.join(OUT, f'{name}-full.png')
    bpy.ops.render.render(write_still=True)
    img = bpy.data.images.load(scene.render.filepath, check_existing=False)
    w, h = img.size
    out = np.array(img.pixels[:], dtype=np.float32).reshape(h, w, 4)
    bpy.data.images.remove(img)
    return out


def save(name, px):
    h, w = px.shape[:2]
    img = bpy.data.images.new(name, w, h, alpha=True)
    img.pixels = px.ravel().tolist()
    img.filepath_raw = os.path.join(OUT, f'{name}.png')
    img.file_format = 'PNG'
    img.save()


body = render('body', {'body'})
save('body', body)
for face in ('blink', 'talk'):
    other = render(face, {face})
    changed = np.abs(other - body).max(axis=2) > 0.02
    overlay = np.where(changed[..., None], other, 0.0)
    save(face, overlay.astype(np.float32))
for wing in ('wing-l', 'wing-r'):
    save(wing, render(wing, {wing}))

# Shoulder pivots in image pixels (top-left origin), for CSS transform-origin.
bpy.context.view_layer.update()
layout = {'size': SIZE, 'pivots': {}}
for wing, local in PIVOTS.items():
    world_pt = objects[wing].matrix_world @ local
    p = world_to_camera_view(scene, cam, world_pt)
    layout['pivots'][wing] = {'x': round(p.x * SIZE, 1), 'y': round((1 - p.y) * SIZE, 1)}
for f in os.listdir(OUT):
    if f.endswith('-full.png'):
        os.remove(os.path.join(OUT, f))
with open(os.path.join(OUT, 'layout.json'), 'w') as fh:
    json.dump(layout, fh, indent=2)
print('meowl layers written to', OUT, layout)
