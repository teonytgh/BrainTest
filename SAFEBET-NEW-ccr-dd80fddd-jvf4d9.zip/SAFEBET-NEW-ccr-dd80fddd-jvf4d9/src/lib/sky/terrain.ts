import { SKY_CHUNK, hashInts, rand01 } from '../../../shared/sky';

/**
 * «Небо Meowl»'s endless map, like a physical map seen from the sky: seas and lakes with depth lines, beaches, green
 * lowlands, tan hills, brown mountains with snow, hill shading lit from the north-west, contour lines, rivers, forests
 * (summer and autumn), rocks, villages with fields and paths and a windmill. Everything comes from the run's seed, so
 * every player flies over the same world. One chunk (SKY_CHUNK units) is drawn at RES × RES pixels in a Web Worker
 * (terrain.worker.ts); its objects (trees, houses…) come back as a list the game draws as sprites.
 */
export const RES = 256;
/** Units per field sample: the fields are sampled on a coarse grid and interpolated per pixel. */
const STEP = 4;
const G = SKY_CHUNK / STEP + 3;
export const SEA = 0.41;

export type ThingKind = 'pine' | 'oak' | 'oak-autumn' | 'rock' | 'house-red' | 'house-blue' | 'mill';

export interface Thing {
  k: ThingKind;
  /** Chunk-local units. */
  x: number;
  y: number;
  /** Scale (0.85–1.15). */
  s: number;
}

export interface ChunkPaint {
  cx: number;
  cy: number;
  pixels: Uint8ClampedArray;
  things: Thing[];
}

// ---------- Noise ----------

const fade = (t: number) => t * t * t * (t * (t * 6 - 15) + 10);

function lattice(ix: number, iy: number, seed: number) {
  return (hashInts(seed, ix, iy) / 4294967296) * 2 - 1;
}

export function vnoise(x: number, y: number, seed: number) {
  const ix = Math.floor(x);
  const iy = Math.floor(y);
  const fx = fade(x - ix);
  const fy = fade(y - iy);
  const a = lattice(ix, iy, seed);
  const b = lattice(ix + 1, iy, seed);
  const c = lattice(ix, iy + 1, seed);
  const d = lattice(ix + 1, iy + 1, seed);
  return a + (b - a) * fx + (c - a) * fy + (a - b - c + d) * fx * fy;
}

export function fbm(x: number, y: number, seed: number, octaves: number) {
  let sum = 0;
  let amp = 0.5;
  let f = 1;
  for (let o = 0; o < octaves; o++) {
    sum += amp * vnoise(x * f, y * f, seed + o * 1013);
    f *= 2.03;
    amp *= 0.5;
  }
  return sum;
}

const clamp = (v: number, a = 0, b = 1) => (v < a ? a : v > b ? b : v);
const smooth = (a: number, b: number, v: number) => {
  const t = clamp((v - a) / (b - a));
  return t * t * (3 - 2 * t);
};

/** Height (0 sea floor … 1 peak), moisture, river (0 = in the channel) and forest mask at a world point. */
export function fields(seed: number, x: number, y: number) {
  const s = seed | 0;
  const wx = x + 420 * fbm(x / 1800 + 11.3, y / 1800 - 4.1, s + 1, 3);
  const wy = y + 420 * fbm(x / 1800 - 7.7, y / 1800 + 15.9, s + 2, 3);
  // Continents and seas a few screens across.
  const cont = fbm(wx / 3600, wy / 3600, s + 3, 3);
  const hills = fbm(wx / 1500, wy / 1500, s + 4, 4);
  const ridge = 1 - Math.abs(vnoise(wx / 2100, wy / 2100, s + 5));
  const mountains = smooth(0.08, 0.4, cont + 0.3 * hills);
  const raw = 0.5 + 0.62 * cont + 0.2 * hills + 0.42 * mountains * ridge * ridge - 0.16;
  // Calibrated on a 60 000-unit square: about a third water, half lowland and hills, a few snowy peaks.
  const h0 = clamp(0.47 + (raw - 0.36) * 0.9);
  // The start (around the origin, where players spawn) is land: water there rises to a lowland; hills and mountains
  // stay as they are.
  const home = 0.92 * Math.exp(-(x * x + y * y) / (4600 * 4600));
  const h = h0 < SEA + 0.07 ? h0 + (SEA + 0.07 - h0) * home : h0;
  const m = fbm(x / 3200 + 50, y / 3200 - 20, s + 6, 3);
  const river = Math.abs(fbm(wx / 2600 + 3.3, wy / 2600 - 8.1, s + 7, 3));
  const forest = fbm(x / 900 - 30, y / 900 + 70, s + 8, 2);
  const autumn = fbm(x / 4200 + 9, y / 4200 + 2, s + 9, 2);
  return { h, m, river, forest, autumn };
}

// ---------- Colours ----------

type RGB = [number, number, number];
const hex = (s: string): RGB => [parseInt(s.slice(1, 3), 16), parseInt(s.slice(3, 5), 16), parseInt(s.slice(5, 7), 16)];
const mix = (a: RGB, b: RGB, t: number): RGB => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t];

const DEEP = hex('#1d5a90');
const SHALLOW = hex('#4c95c8');
const COAST = hex('#86c6e6');
const SAND = hex('#ecdfa8');
const DRY = hex('#bccb7c');
const MOIST = hex('#72b462');
const LUSH = hex('#5ca557');
const HILL = hex('#cfc98a');
const HIGH = hex('#c4a06c');
const MOUNT = hex('#9a8476');
const ROCK = hex('#8b8784');
const SNOW = hex('#f3f5f8');
const RIVER = hex('#4f9fd4');
const FIELD_A = hex('#dcc96c');
const FIELD_B = hex('#b9a650');
const FIELD_C = hex('#93b45a');
const PATH = hex('#c9ab7b');
const CONTOUR = hex('#5d4b3b');

function landColor(h: number, m: number): RGB {
  const wet = clamp(m * 1.6 + 0.5);
  if (h < SEA + 0.006) return SAND;
  if (h < 0.53) return mix(mix(DRY, MOIST, wet), LUSH, clamp((wet - 0.7) * 2) * 0.6);
  if (h < 0.63) return mix(mix(DRY, MOIST, wet), HILL, smooth(0.53, 0.63, h));
  if (h < 0.74) return mix(HILL, HIGH, smooth(0.63, 0.74, h));
  if (h < 0.84) return mix(HIGH, MOUNT, smooth(0.74, 0.84, h));
  if (h < 0.88) return mix(ROCK, SNOW, smooth(0.86, 0.88, h));
  return SNOW;
}

function waterColor(h: number): RGB {
  const d = clamp((SEA - h) / 0.2);
  return d < 0.12 ? mix(COAST, SHALLOW, d / 0.12) : mix(SHALLOW, DEEP, (d - 0.12) / 0.88);
}

// ---------- One chunk ----------

interface Village {
  x: number;
  y: number;
  houses: { x: number; y: number }[];
  fields: { x: number; y: number; w: number; h: number; a: number; c: number }[];
  mill: { x: number; y: number } | null;
}

export function paintChunk(seed: number, cx: number, cy: number): ChunkPaint {
  const ox = cx * SKY_CHUNK;
  const oy = cy * SKY_CHUNK;
  // Fields on a coarse grid covering the chunk plus one sample of border on each side.
  const H = new Float32Array(G * G);
  const M = new Float32Array(G * G);
  const R = new Float32Array(G * G);
  const F = new Float32Array(G * G);
  const A = new Float32Array(G * G);
  for (let j = 0; j < G; j++) {
    for (let i = 0; i < G; i++) {
      const f = fields(seed, ox + (i - 1) * STEP, oy + (j - 1) * STEP);
      const k = j * G + i;
      H[k] = f.h;
      M[k] = f.m;
      R[k] = f.river;
      F[k] = f.forest;
      A[k] = f.autumn;
    }
  }
  const at = (arr: Float32Array, lx: number, ly: number) => {
    const gx = clamp(lx / STEP + 1, 0, G - 1.001);
    const gy = clamp(ly / STEP + 1, 0, G - 1.001);
    const i = Math.floor(gx);
    const j = Math.floor(gy);
    const tx = gx - i;
    const ty = gy - j;
    const a = arr[j * G + i]!;
    const b = arr[j * G + i + 1]!;
    const c = arr[(j + 1) * G + i]!;
    const d = arr[(j + 1) * G + i + 1]!;
    return a + (b - a) * tx + (c - a) * ty + (a - b - c + d) * tx * ty;
  };
  // Thin in the hills, wider towards the sea.
  const isRiver = (h: number, r: number) => h > SEA + 0.004 && h < 0.7 && r < 0.0035 + (0.66 - h) * 0.012;

  const village = makeVillage(seed, cx, cy, (lx, ly) => at(H, lx, ly), (lx, ly) => at(R, lx, ly), isRiver);

  const px = new Uint8ClampedArray(RES * RES * 4);
  const U = SKY_CHUNK / RES;
  // Heights per pixel (with a one-pixel border) for shading and contour lines.
  const W = RES + 2;
  const HP = new Float32Array(W * W);
  for (let j = 0; j < W; j++) for (let i = 0; i < W; i++) HP[j * W + i] = at(H, (i - 1 + 0.5) * U, (j - 1 + 0.5) * U);
  const band = (h: number) => (h >= SEA ? Math.floor((h - SEA) / 0.035) : -1 - Math.floor((SEA - h) / 0.05));

  for (let j = 0; j < RES; j++) {
    for (let i = 0; i < RES; i++) {
      const lx = (i + 0.5) * U;
      const ly = (j + 0.5) * U;
      const k = (j + 1) * W + i + 1;
      const h = HP[k]!;
      const water = h < SEA;
      const r = at(R, lx, ly);
      let c: RGB;
      if (water) c = waterColor(h);
      else if (isRiver(h, r)) c = mix(RIVER, hex('#2f78ad'), clamp(1 - r / 0.008) * 0.4);
      else c = landColor(h, at(M, lx, ly));
      // Hill shading: the slope towards the light (north-west) brightens, away from it darkens.
      const dx = (HP[k + 1]! - HP[k - 1]!) / (2 * U);
      const dy = (HP[k + W]! - HP[k - W]!) / (2 * U);
      if (!water) {
        const kz = 260;
        const nx = -dx * kz;
        const ny = -dy * kz;
        const len = Math.hypot(nx, ny, 1);
        const dot = (-0.55 * nx - 0.55 * ny + 0.63) / len;
        const shade = clamp(0.62 + 0.62 * dot, 0.55, 1.22);
        c = [c[0] * shade, c[1] * shade, c[2] * shade];
      }
      // Contour lines (and depth lines in the water), every fifth one a little bolder.
      const b0 = band(h);
      const br = band(HP[k + 1]!);
      const bd = band(HP[k + W]!);
      if (b0 !== br || b0 !== bd) {
        if (water) c = mix(c, hex('#d6efff'), b0 === -1 ? 0.0 : 0.16);
        else if (b0 === 0) c = mix(c, CONTOUR, 0.12);
        else c = mix(c, CONTOUR, Math.max(b0, br, bd) % 5 === 0 ? 0.42 : 0.22);
      }
      // The coastline: a crisp dark edge.
      if (water !== (HP[k + 1]! < SEA) || water !== (HP[k + W]! < SEA)) c = mix(c, hex('#24577e'), 0.55);
      // Little wave dashes on open water.
      if (water && h < SEA - 0.05 && (hashInts(seed, cx * RES + i, cy * RES + j) & 1023) < 3) c = mix(c, hex('#cfeaff'), 0.5);
      const o = (j * RES + i) * 4;
      px[o] = c[0];
      px[o + 1] = c[1];
      px[o + 2] = c[2];
      px[o + 3] = 255;
    }
  }

  const things: Thing[] = [];
  if (village) paintVillage(px, village, U);

  // Trees, rocks: a jittered grid of candidates, each kept or not by the fields at its spot.
  const STEP_T = 30;
  for (let gy = 0; gy < SKY_CHUNK / STEP_T; gy++) {
    for (let gx = 0; gx < SKY_CHUNK / STEP_T; gx++) {
      const r1 = rand01(seed, cx * 64 + gx, cy * 64 + gy, 501);
      const r2 = rand01(seed, cx * 64 + gx, cy * 64 + gy, 502);
      const r3 = rand01(seed, cx * 64 + gx, cy * 64 + gy, 503);
      const lx = (gx + 0.15 + r1 * 0.7) * STEP_T;
      const ly = (gy + 0.15 + r2 * 0.7) * STEP_T;
      if (lx < 20 || ly < 20 || lx > SKY_CHUNK - 20 || ly > SKY_CHUNK - 20) continue;
      const h = at(H, lx, ly);
      if (h < SEA + 0.02 || isRiver(h, at(R, lx, ly)) || isRiver(h, at(R, lx + 8, ly)) || isRiver(h, at(R, lx, ly + 8))) continue;
      if (village && Math.hypot(lx - village.x, ly - village.y) < 178) continue;
      const m = at(M, lx, ly);
      const f = at(F, lx, ly);
      const s = 0.85 + r3 * 0.3;
      if (h > 0.66 && h < 0.85 && r3 < 0.1) {
        things.push({ k: 'rock', x: lx, y: ly, s });
        continue;
      }
      const forest = h < 0.74 && f + m * 0.35 > 0.08;
      // Forests thin enough to see the ground (and to draw quickly on a weak phone).
      const odds = forest ? 0.42 : h < 0.6 ? 0.03 : 0;
      if (r3 >= odds) continue;
      const pine = h > 0.58 || (m > 0.25 && r1 < 0.35);
      const autumn = !pine && at(A, lx, ly) > 0.18;
      things.push({ k: pine ? 'pine' : autumn ? 'oak-autumn' : 'oak', x: lx, y: ly, s });
    }
  }
  if (village) {
    for (const hs of village.houses) things.push({ k: rand01(seed, cx, cy, hs.x | 0) < 0.55 ? 'house-red' : 'house-blue', x: hs.x, y: hs.y, s: 0.95 + rand01(seed, hs.x | 0, hs.y | 0, 7) * 0.15 });
    if (village.mill) things.push({ k: 'mill', x: village.mill.x, y: village.mill.y, s: 1 });
  }
  things.sort((a, b) => a.y - b.y);
  return { cx, cy, pixels: px, things };
}

function makeVillage(
  seed: number,
  cx: number,
  cy: number,
  height: (lx: number, ly: number) => number,
  river: (lx: number, ly: number) => number,
  isRiver: (h: number, r: number) => boolean,
): Village | null {
  if (rand01(seed, cx, cy, 31) > 0.2) return null;
  const vx = 170 + rand01(seed, cx, cy, 32) * (SKY_CHUNK - 340);
  const vy = 170 + rand01(seed, cx, cy, 33) * (SKY_CHUNK - 340);
  const ok = (lx: number, ly: number) => {
    const h = height(lx, ly);
    return h > SEA + 0.03 && h < 0.6 && !isRiver(h, river(lx, ly));
  };
  if (!ok(vx, vy)) return null;
  const houses: Village['houses'] = [];
  const n = 4 + Math.floor(rand01(seed, cx, cy, 34) * 4);
  for (let i = 0; i < n * 3 && houses.length < n; i++) {
    const a = rand01(seed, cx, cy, 40 + i) * Math.PI * 2;
    const d = 26 + rand01(seed, cx, cy, 60 + i) * 70;
    const x = vx + Math.cos(a) * d;
    const y = vy + Math.sin(a) * d * 0.8;
    if (!ok(x, y) || houses.some((o) => Math.hypot(o.x - x, o.y - y) < 34)) continue;
    houses.push({ x, y });
  }
  if (houses.length < 3) return null;
  const fields: Village['fields'] = [];
  for (let i = 0; i < 5; i++) {
    const a = rand01(seed, cx, cy, 80 + i) * Math.PI * 2;
    const d = 115 + rand01(seed, cx, cy, 90 + i) * 40;
    const x = vx + Math.cos(a) * d;
    const y = vy + Math.sin(a) * d;
    if (x < 30 || y < 30 || x > SKY_CHUNK - 30 || y > SKY_CHUNK - 30 || !ok(x, y)) continue;
    fields.push({ x, y, w: 46 + rand01(seed, cx, cy, 100 + i) * 30, h: 30 + rand01(seed, cx, cy, 110 + i) * 22, a: a + Math.PI / 2, c: i % 3 });
  }
  const ma = rand01(seed, cx, cy, 120) * Math.PI * 2;
  const mill = rand01(seed, cx, cy, 121) < 0.6 ? { x: vx + Math.cos(ma) * 100, y: vy + Math.sin(ma) * 80 } : null;
  return { x: vx, y: vy, houses, fields, mill: mill && ok(mill.x, mill.y) ? mill : null };
}

/** Fields (striped crops) and dirt paths from the green to each house, painted into the ground. */
function paintVillage(px: Uint8ClampedArray, v: Village, U: number) {
  const put = (lx: number, ly: number, c: RGB, t = 1) => {
    const i = Math.floor(lx / U);
    const j = Math.floor(ly / U);
    if (i < 0 || j < 0 || i >= RES || j >= RES) return;
    const o = (j * RES + i) * 4;
    px[o] = px[o]! + (c[0] - px[o]!) * t;
    px[o + 1] = px[o + 1]! + (c[1] - px[o + 1]!) * t;
    px[o + 2] = px[o + 2]! + (c[2] - px[o + 2]!) * t;
  };
  for (const f of v.fields) {
    const cos = Math.cos(f.a);
    const sin = Math.sin(f.a);
    const base = f.c === 0 ? FIELD_A : f.c === 1 ? FIELD_C : FIELD_B;
    for (let u = -f.w / 2; u <= f.w / 2; u += U * 0.7) {
      for (let w = -f.h / 2; w <= f.h / 2; w += U * 0.7) {
        const stripe = Math.floor((w + f.h) / 5) % 2 === 0;
        const edge = Math.abs(u) > f.w / 2 - 2 || Math.abs(w) > f.h / 2 - 2;
        put(f.x + u * cos - w * sin, f.y + u * sin + w * cos, edge ? hex('#8a7a45') : stripe ? base : mix(base, hex('#6d6a32'), 0.25), edge ? 0.6 : 0.9);
      }
    }
  }
  const path = (ax: number, ay: number, bx: number, by: number) => {
    const n = Math.ceil(Math.hypot(bx - ax, by - ay) / (U * 0.6));
    for (let i = 0; i <= n; i++) {
      const x = ax + ((bx - ax) * i) / n;
      const y = ay + ((by - ay) * i) / n;
      for (const [ddx, ddy] of [
        [0, 0],
        [U, 0],
        [0, U],
      ] as const)
        put(x + ddx, y + ddy, PATH, 0.85);
    }
  };
  for (const h of v.houses) path(v.x, v.y, h.x, h.y + 10);
  if (v.mill) path(v.x, v.y, v.mill.x, v.mill.y + 10);
  // The village green: a little sandy square in the middle.
  for (let a = -10; a <= 10; a += U * 0.6) for (let b = -8; b <= 8; b += U * 0.6) put(v.x + a, v.y + b, PATH, 0.7);
}
