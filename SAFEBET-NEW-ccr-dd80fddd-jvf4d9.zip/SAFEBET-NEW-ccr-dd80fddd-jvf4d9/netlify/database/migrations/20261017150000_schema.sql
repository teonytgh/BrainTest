CREATE TABLE users (
  id BIGINT PRIMARY KEY,
  public_id TEXT NOT NULL UNIQUE,
  username TEXT,
  username_lc TEXT,
  first_name TEXT NOT NULL DEFAULT '',
  last_name TEXT,
  photo_url TEXT,
  balance BIGINT NOT NULL DEFAULT 0 CHECK (balance >= 0),
  media_platform TEXT CHECK (media_platform IN ('tiktok', 'youtube', 'twitch')),
  free_case_at TIMESTAMPTZ,
  cases_opened INT NOT NULL DEFAULT 0,
  upgrades INT NOT NULL DEFAULT 0,
  dice_rolls INT NOT NULL DEFAULT 0,
  crash_rounds INT NOT NULL DEFAULT 0,
  withdrawn_value BIGINT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  last_seen_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX users_username_lc ON users (username_lc);

CREATE TABLE brainrots (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  price BIGINT NOT NULL CHECK (price > 0),
  image TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'hidden', 'disabled', 'deleted')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE inventory (
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT NOT NULL REFERENCES users (id),
  brainrot_id TEXT NOT NULL REFERENCES brainrots (id),
  source TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX inventory_user ON inventory (user_id);

CREATE TABLE cases (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  price BIGINT NOT NULL CHECK (price >= 0),
  image TEXT NOT NULL,
  kind TEXT NOT NULL DEFAULT 'paid' CHECK (kind IN ('paid', 'free')),
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'hidden')),
  sort INT NOT NULL DEFAULT 0
);

CREATE TABLE case_items (
  case_id TEXT NOT NULL REFERENCES cases (id) ON DELETE CASCADE,
  brainrot_id TEXT NOT NULL REFERENCES brainrots (id),
  weight INT NOT NULL CHECK (weight > 0),
  PRIMARY KEY (case_id, brainrot_id)
);

CREATE TABLE drops (
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT NOT NULL REFERENCES users (id),
  game TEXT NOT NULL,
  result TEXT NOT NULL CHECK (result IN ('win', 'lose')),
  stake_value BIGINT NOT NULL DEFAULT 0,
  brainrot_id TEXT REFERENCES brainrots (id),
  coins BIGINT NOT NULL DEFAULT 0,
  meta JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX drops_created ON drops (created_at DESC);
CREATE INDEX drops_user ON drops (user_id, created_at DESC);

CREATE TABLE crash_rounds (
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT NOT NULL REFERENCES users (id),
  brainrot_id TEXT NOT NULL REFERENCES brainrots (id),
  stake_value BIGINT NOT NULL,
  crash_point NUMERIC(10, 2) NOT NULL,
  auto_cashout NUMERIC(10, 2),
  started_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  status TEXT NOT NULL DEFAULT 'flying' CHECK (status IN ('flying', 'crashed', 'cashed')),
  cashed_at NUMERIC(10, 2),
  finished_at TIMESTAMPTZ
);
CREATE UNIQUE INDEX crash_one_active ON crash_rounds (user_id) WHERE status = 'flying';

CREATE TABLE promo_codes (
  id BIGSERIAL PRIMARY KEY,
  code TEXT NOT NULL,
  code_key TEXT NOT NULL UNIQUE,
  max_uses INT NOT NULL CHECK (max_uses > 0),
  uses INT NOT NULL DEFAULT 0,
  reward_type TEXT NOT NULL CHECK (reward_type IN ('coins', 'brainrot')),
  reward_brainrot_id TEXT REFERENCES brainrots (id),
  reward_amount BIGINT NOT NULL CHECK (reward_amount > 0),
  created_by BIGINT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE promo_activations (
  promo_id BIGINT NOT NULL REFERENCES promo_codes (id) ON DELETE CASCADE,
  user_id BIGINT NOT NULL REFERENCES users (id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (promo_id, user_id)
);

CREATE TABLE auto_promo_uses (
  user_id BIGINT NOT NULL REFERENCES users (id),
  window_index BIGINT NOT NULL,
  percent INT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('active', 'used')),
  PRIMARY KEY (user_id, window_index)
);

CREATE TABLE punishments (
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT NOT NULL REFERENCES users (id),
  kind TEXT NOT NULL CHECK (kind IN ('ban', 'freeze')),
  until TIMESTAMPTZ,
  reason TEXT,
  created_by BIGINT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  revoked_at TIMESTAMPTZ,
  revoked_by BIGINT
);
CREATE INDEX punishments_user ON punishments (user_id) WHERE revoked_at IS NULL;

CREATE TABLE admins (
  user_id BIGINT PRIMARY KEY,
  added_by BIGINT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE titles (
  id BIGSERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  icon TEXT NOT NULL,
  color TEXT NOT NULL DEFAULT '#ffc94d',
  created_by BIGINT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE user_titles (
  user_id BIGINT NOT NULL REFERENCES users (id),
  title_id BIGINT NOT NULL REFERENCES titles (id) ON DELETE CASCADE,
  granted_by BIGINT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, title_id)
);

CREATE TABLE withdrawals (
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT NOT NULL REFERENCES users (id),
  brainrot_id TEXT NOT NULL REFERENCES brainrots (id),
  value BIGINT NOT NULL,
  roblox_nick TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'done', 'rejected')),
  note TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  processed_by BIGINT,
  processed_at TIMESTAMPTZ
);
CREATE INDEX withdrawals_status ON withdrawals (status, created_at);

CREATE TABLE settings (
  key TEXT PRIMARY KEY,
  value JSONB NOT NULL
);

CREATE TABLE admin_log (
  id BIGSERIAL PRIMARY KEY,
  admin_id BIGINT NOT NULL,
  action TEXT NOT NULL,
  target_user BIGINT,
  details JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX admin_log_created ON admin_log (created_at DESC);

INSERT INTO settings (key, value) VALUES
  ('maintenance', '{"enabled": false, "message": ""}'),
  ('demo_deposits', '{"enabled": true}');
