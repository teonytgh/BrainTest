import { Icon } from './Icon';
import { copyText } from '../lib/copy';

const plural = (n: number, one: string, few: string, many: string) =>
  n % 10 === 1 && n % 100 !== 11 ? one : n % 10 >= 2 && n % 10 <= 4 && (n % 100 < 12 || n % 100 > 14) ? few : many;

/** The reward as the announcement says it: «10🪙монет», «Name ×2», «кейс «Name»». */
export function promoRewardText(r: { type: 'coins' | 'brainrot' | 'case'; amount: number; name?: string }): string {
  if (r.type === 'coins') return `${r.amount}🪙${plural(r.amount, 'монета', 'монеты', 'монет')}`;
  if (r.type === 'case') return `кейс «${r.name ?? 'кейс'}»${r.amount > 1 ? ` ×${r.amount}` : ''}`;
  return `${r.name ?? 'брейнрот'}${r.amount > 1 ? ` ×${r.amount}` : ''}`;
}

/** The owner's ready-to-post text for a new promo code (iteration 42). */
export function promoAnnouncement(code: string, uses: number, reward: string): string {
  return [
    '🎉ПРОМОКОД СОЗДАН',
    'Bot: @braincrashbot 🎉',
    '🔥ЗАХОДИМ И ЗАБИРАЕМ! 🔥',
    `👥Промокод: ${code}`,
    `👥Активаций: ${uses}`,
    `💵Награда: ${reward}`,
    '⚡️УСПЕЙ АКТИВИРОВАТЬ, ПОКА ЕСТЬ АКТИВАЦИИ!',
  ].join('\n');
}

/**
 * Shown right after a promo code is made (admin «Промокоды» and a player's own codes in «Рефералы»): the announcement
 * to paste into a channel or chat, with a copy button.
 */
export function PromoAnnounce({ text, onClose }: { text: string; onClose: () => void }) {
  return (
    <div className="promo-announce" role="status">
      <pre className="promo-announce__text">{text}</pre>
      <div className="promo-announce__actions">
        <button type="button" className="btn btn--primary btn--block" onClick={() => copyText(text, 'Текст скопирован')}>
          <Icon name="copy" size={16} /> Скопировать текст
        </button>
        <button type="button" className="btn btn--ghost" onClick={onClose} aria-label="Скрыть">
          <Icon name="close" size={16} />
        </button>
      </div>
    </div>
  );
}
