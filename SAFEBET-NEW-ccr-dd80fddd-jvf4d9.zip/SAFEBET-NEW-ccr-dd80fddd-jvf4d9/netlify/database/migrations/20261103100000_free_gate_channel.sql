-- The free case asks for a subscription to the project's channel @BrainrotCrash (the bot must be its admin to see
-- who is subscribed; until then the check lets everyone through).
UPDATE settings SET value = jsonb_set(value, '{channel}', '"@BrainrotCrash"') WHERE key = 'free_case_gate';
