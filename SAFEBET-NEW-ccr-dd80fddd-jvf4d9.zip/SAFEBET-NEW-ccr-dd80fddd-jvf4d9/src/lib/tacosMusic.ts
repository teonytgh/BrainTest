import { useSyncExternalStore } from 'react';
import { SOUND_EVENT, isMuted as soundsOff } from './sound';

/**
 * The «Raining Tacos» track for the whole app: it plays on every page while the tacos event runs — on its own, nobody
 * has to switch it on (the owner's wish). The «Щелчок» cutscene holds it until its card comes up. Browsers may refuse
 * sound before the player has touched the page; then it starts on the first tap anywhere. Off when the app's sounds
 * are off or the player muted the track (the 🔊 on its event chip), paused while the app is in the background.
 */
const SRC = '/events/raining-tacos.mp3';
const MUTE_KEY = 'brainrotcrash:tacos-muted';

function readMuted(): boolean {
  try {
    return localStorage.getItem(MUTE_KEY) === '1';
  } catch {
    return false;
  }
}

let audio: HTMLAudioElement | null = null;
let wanted = false;
let held = false;
let muted = readMuted();
let playing = false;
let armed = false;
let snapshot = { playing, muted };
const listeners = new Set<() => void>();

function emit() {
  snapshot = { playing, muted };
  listeners.forEach((l) => l());
}

function element(): HTMLAudioElement {
  if (audio) return audio;
  audio = new Audio(SRC);
  audio.loop = true;
  audio.preload = 'auto';
  audio.volume = 0.45;
  audio.addEventListener('playing', () => {
    playing = true;
    emit();
  });
  audio.addEventListener('pause', () => {
    playing = false;
    emit();
  });
  return audio;
}

const GESTURES = ['click', 'touchend', 'keydown'] as const;

/** Autoplay refused: try again inside the next tap (a tap is what browsers want). */
function armGesture() {
  if (armed) return;
  armed = true;
  const go = () => {
    armed = false;
    GESTURES.forEach((g) => window.removeEventListener(g, go, true));
    sync();
  };
  GESTURES.forEach((g) => window.addEventListener(g, go, true));
}

function sync() {
  const should = wanted && !held && !muted && !soundsOff() && document.visibilityState === 'visible';
  if (should) {
    const a = element();
    if (a.paused) a.play().catch(() => armGesture());
  } else if (audio && !audio.paused) {
    audio.pause();
  }
}

if (typeof document !== 'undefined') {
  document.addEventListener('visibilitychange', sync);
  window.addEventListener(SOUND_EVENT, sync);
}

export const tacosMusic = {
  /** The tacos event runs (or has stopped). */
  setWanted(on: boolean) {
    if (wanted === on) return;
    wanted = on;
    if (!on && audio) audio.currentTime = 0;
    sync();
    emit();
  },
  /** The tacos track has the stage (the event runs and it isn't muted): the background music steps aside. */
  audible() {
    return wanted && !muted;
  },
  /** Plain subscription for non-React code (the background music). */
  subscribe(l: () => void) {
    listeners.add(l);
    return () => {
      listeners.delete(l);
    };
  },
  /** The snap cutscene plays: keep quiet until its card. */
  hold(on: boolean) {
    held = on;
    sync();
  },
  /** Call from a tap handler: starts the track right away where the browser allows it. */
  kick() {
    sync();
  },
  toggleMute() {
    muted = !muted;
    try {
      localStorage.setItem(MUTE_KEY, muted ? '1' : '0');
    } catch {
      // Won't persist; fine.
    }
    emit();
    sync();
  },
};

export function useTacosMusic() {
  return useSyncExternalStore(
    (l) => {
      listeners.add(l);
      return () => listeners.delete(l);
    },
    () => snapshot,
  );
}
