/**
 * «Анонс в игре» (iteration 37), like Sammy's messages in Steal a Brainrot: an admin writes a line and every open app
 * shows it at once on top of the screen — the admin's round photo, name, the text, a sound. It rides with the catalog
 * (the `shout` setting); an app opened within SHOUT_FRESH_MS still gets it, later ones don't.
 */
export const SHOUT_COLORS = ['accent', 'red', 'green', 'gold'] as const;
export type ShoutColor = (typeof SHOUT_COLORS)[number];
export const SHOUT_COLOR_LABEL: Record<ShoutColor, string> = { accent: 'Обычный', red: 'Красный', green: 'Зелёный', gold: 'Золотой' };
export const SHOUT_MAX = 200;
/** On screen this long (a tap closes it sooner). */
export const SHOUT_SHOW_MS = 8_000;
/** Apps opened this long after the shout still see it. */
export const SHOUT_FRESH_MS = 120_000;
/** One shout at a time: the next one no sooner than this. */
export const SHOUT_COOLDOWN_MS = 20_000;

export interface Shout {
  text: string;
  color: ShoutColor;
  authorName: string;
  authorPhoto: string | null;
  /** When it was posted (ms): also its id on the device. */
  at: number;
}
