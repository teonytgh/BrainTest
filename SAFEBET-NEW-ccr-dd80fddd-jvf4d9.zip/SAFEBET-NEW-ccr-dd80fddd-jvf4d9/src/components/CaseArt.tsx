import { useCatalog } from '../api/queries';
import type { CaseDef } from '../../shared/types';
import { cx } from '../lib/format';

const OWN_ART = /^\/cases\/[a-z0-9-]+\.svg$/;

/** Our chest with the case's most valuable brainrot peeking out from behind the lid; custom uploads are shown as is. */
export function CaseArt({ kase, className, lazy }: { kase: CaseDef; className?: string; lazy?: boolean }) {
  const catalog = useCatalog();
  const own = OWN_ART.test(kase.image);
  const top = own
    ? kase.items
        .map((i) => catalog.byId.get(i.brainrotId))
        .filter((b) => b && b.status !== 'hidden')
        .sort((a, b) => b!.price - a!.price)[0]
    : null;
  return (
    <span className={cx('case-art', className)}>
      {top && <img className="case-art__item" src={top.image} alt="" loading={lazy ? 'lazy' : undefined} decoding="async" />}
      <img className="case-art__box" src={kase.image} alt="" loading={lazy ? 'lazy' : undefined} decoding="async" />
    </span>
  );
}
