import { useSyncExternalStore } from 'react';
import { useQuery } from '@tanstack/react-query';
import { catalogQuery } from '../api/queries';
import { Icon } from './Icon';
import { sfx } from '../lib/sound';

/** Up to two leading letters of the name, for the photo-less avatar. */
const initials = (name: string) =>
  name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((w) => w[0]!.toUpperCase())
    .join('') || '🎉';

/** Per-device «dismissed» flag, keyed by the announcement's timestamp so a new one shows again. */
const KEY = 'brainrotcrash:announce-seen';

function readSeen(): number {
  try {
    return Number(localStorage.getItem(KEY)) || 0;
  } catch {
    return 0;
  }
}

const listeners = new Set<() => void>();
function dismiss(at: number) {
  try {
    localStorage.setItem(KEY, String(at));
  } catch {
    // Private mode: it just re-shows next time, no harm.
  }
  listeners.forEach((l) => l());
}
function subscribe(cb: () => void) {
  listeners.add(cb);
  return () => listeners.delete(cb);
}

/**
 * A site-wide message an owner posts from the admin panel: their Telegram name and photo plus the text, shown
 * once per device (until a newer one is posted). It rides with the catalog, so it reaches every open app live.
 */
export function AnnouncementBanner() {
  const { data } = useQuery(catalogQuery);
  const seen = useSyncExternalStore(subscribe, readSeen, () => 0);
  const a = data?.announcement ?? null;
  if (!a || seen >= a.at) return null;
  return (
    <div className="announce" role="status">
      <div className="announce__who">
        {a.authorPhoto ? <img src={a.authorPhoto} alt="" className="announce__ava" /> : <span className="announce__ava announce__ava--text">{initials(a.authorName)}</span>}
      </div>
      <div className="announce__body">
        <p className="announce__name">{a.authorName}</p>
        <p className="announce__text">{a.text}</p>
      </div>
      <button
        type="button"
        className="announce__close"
        aria-label="Скрыть сообщение"
        onClick={() => {
          sfx.tap();
          dismiss(a.at);
        }}
      >
        <Icon name="close" size={18} />
      </button>
    </div>
  );
}
