type NetlifyGlobal = { env: { get(key: string): string | undefined } };

// Cloudflare Workers hand vars and secrets to the handler; worker/index.ts passes them here.
let bindings: Record<string, unknown> | null = null;

export function useEnv(vars: Record<string, unknown> | null) {
  bindings = vars;
}

export function env(key: string): string | undefined {
  const bound = bindings?.[key];
  if (typeof bound === 'string') return bound;
  const netlify = (globalThis as { Netlify?: NetlifyGlobal }).Netlify;
  return netlify?.env.get(key) ?? process.env[key];
}

/** The app's public address (the URL var on Cloudflare). */
export const siteUrl = () => (env('URL') ?? 'https://safebet.teonytofficial.workers.dev').replace(/\/$/, '');

/**
 * Telegram caches a sent photo by its URL, so a changed picture in public/promo keeps showing the old one until its
 * URL changes: bump this whenever a promo picture is replaced.
 */
export const PROMO_VERSION = 3;
export const promo = (file: string) => `/promo/${file}?v=${PROMO_VERSION}`;

/** Owners always have admin access and can never be removed, banned or frozen. */
export const OWNER_IDS: readonly number[] = [7263901569, 8044175101, 8621306718];

export function isOwnerId(id: number): boolean {
  return OWNER_IDS.includes(id);
}
