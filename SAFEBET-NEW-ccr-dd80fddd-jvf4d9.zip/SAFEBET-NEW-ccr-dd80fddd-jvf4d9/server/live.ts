import { AsyncLocalStorage } from 'node:async_hooks';
import { createHmac, timingSafeEqual } from 'node:crypto';
import { env } from './env';

/**
 * Live updates. Code that changes a player's state calls touch(userId, topic); when the request (or tick) is
 * over, the Worker tells that player's open app over a WebSocket (see worker/index.ts, LiveHub) to refetch the
 * topic right away instead of waiting for the next poll. The player who made the request already has the
 * fresh state in the response, so they are not pinged back.
 */

/** Client query keys a push can refresh. */
export type LiveTopic = 'me' | 'itemDeposit' | 'withdrawal' | 'battles' | 'bonuses' | 'catalog' | 'giveaways';

interface Scope {
  touched: Map<number, Set<LiveTopic>>;
  /** For every open app (catalog edits: names, prices, chances, sections). */
  everyone: Set<LiveTopic>;
  viewer: number | null;
  background: Promise<unknown>[];
  /** Winning drops recorded here, for the «LIVE» feed of every open app. */
  drops: number[];
}

const scope = new AsyncLocalStorage<Scope>();

export function touch(userId: number, ...topics: LiveTopic[]) {
  const s = scope.getStore();
  if (!s || !userId) return;
  const set = s.touched.get(userId) ?? new Set<LiveTopic>();
  for (const t of topics.length ? topics : (['me'] as const)) set.add(t);
  s.touched.set(userId, set);
}

/** Something every player sees changed (the catalog): all open apps refetch it. */
export function broadcast(...topics: LiveTopic[]) {
  const s = scope.getStore();
  if (s) for (const t of topics) s.everyone.add(t);
}

/** A new winning drop: every open app gets it in its «LIVE» feed once the request is over. */
export function noteDrop(dropId: number) {
  scope.getStore()?.drops.push(dropId);
}

/** The authenticated player of this request (their own changes come back in the response). */
export function markViewer(userId: number) {
  const s = scope.getStore();
  if (s) s.viewer = userId;
}

/**
 * Work that doesn't have to hold the response (bot messages to admins and so on). Inside a live scope it
 * runs after the response is sent; elsewhere (tests, local dev) it is awaited right away.
 */
export async function afterResponse(fn: () => Promise<unknown>): Promise<void> {
  const s = scope.getStore();
  const run = fn().catch((e) => console.error('background task failed', e));
  if (s) s.background.push(run);
  else await run;
}

export interface LivePush {
  /** null = every open app. */
  userId: number | null;
  topics: LiveTopic[];
}

/**
 * Runs one request or tick. pending() lists the players to ping that weren't listed before (so the pings go
 * out right after the answer); settle() waits for the background work and lists what it added.
 */
export async function withLiveScope<T>(fn: () => Promise<T>) {
  const s: Scope = { touched: new Map(), everyone: new Set(), viewer: null, background: [], drops: [] };
  const sent = new Map<number, Set<LiveTopic>>();
  const sentToAll = new Set<LiveTopic>();
  const result = await scope.run(s, fn);
  const pending = (): LivePush[] => {
    const out: LivePush[] = [];
    const all = [...s.everyone].filter((t) => !sentToAll.has(t));
    if (all.length) {
      all.forEach((t) => sentToAll.add(t));
      out.push({ userId: null, topics: all });
    }
    for (const [id, topics] of s.touched) {
      if (id === s.viewer) continue;
      const done = sent.get(id) ?? new Set<LiveTopic>();
      const fresh = [...topics].filter((t) => !done.has(t));
      if (!fresh.length) continue;
      fresh.forEach((t) => done.add(t));
      sent.set(id, done);
      out.push({ userId: id, topics: fresh });
    }
    return out;
  };
  return {
    result,
    pending,
    async settle(): Promise<LivePush[]> {
      while (s.background.length) await Promise.allSettled(s.background.splice(0));
      return pending();
    },
    /** The drop ids recorded so far (each handed out once). */
    takeDrops: (): number[] => s.drops.splice(0),
  };
}

// ---------- WebSocket tickets ----------

const TICKET_TTL_MS = 60_000;

function ticketKey() {
  return createHmac('sha256', env('BOT_TOKEN') ?? '').update('brainrotcrash-live').digest();
}

/** A short-lived pass for the WebSocket (browsers can't send the initData header there). */
export function liveTicket(userId: number, now = Date.now()) {
  const body = `${userId}.${now + TICKET_TTL_MS}`;
  return `${body}.${createHmac('sha256', ticketKey()).update(body).digest('hex')}`;
}

export function verifyLiveTicket(ticket: string, now = Date.now()): number | null {
  const m = /^(\d{1,15})\.(\d{13})\.([a-f0-9]{64})$/.exec(ticket);
  if (!m) return null;
  const sig = createHmac('sha256', ticketKey()).update(`${m[1]}.${m[2]}`).digest('hex');
  if (!timingSafeEqual(Buffer.from(sig), Buffer.from(m[3]!)) || Number(m[2]) < now) return null;
  return Number(m[1]);
}
