import { useQuery } from '@tanstack/react-query';
import { useState } from 'react';
import { Coin } from '../components/Coin';
import { Icon } from '../components/Icon';
import { Ticket } from '../components/Ticket';
import { api, errorMessage } from '../api/client';
import { act, queryClient, setMe, useCatalog, useMe } from '../api/queries';
import type { QuestGame, QuestView } from '../../shared/quests';
import { cx, formatCoins } from '../lib/format';
import { routeHref, type RouteName } from '../lib/router';
import { sfx } from '../lib/sound';
import { haptic } from '../lib/telegram';
import { useNow } from '../lib/useNow';
import { toast } from '../store/toast';
import { openSheet } from '../store/ui';

export const QUESTS_KEY = ['quests'] as const;
type QuestsState = { tickets: number; quests: QuestView[] };

/** Where a quest is played. */
const GAME_ROUTE: Record<QuestGame, RouteName> = {
  case: 'home',
  battle: 'battle',
  upgrade: 'upgrader',
  fuse: 'fuse',
  dice: 'dice',
  mines: 'mines',
  road: 'road',
};

const ticketsWord = (n: number) => {
  const m10 = n % 10;
  const m100 = n % 100;
  if (m10 === 1 && m100 !== 11) return 'тикет';
  if (m10 >= 2 && m10 <= 4 && (m100 < 12 || m100 > 14)) return 'тикета';
  return 'тикетов';
};

/** «Сброс через 11ч 45м»: hours and minutes, days for the weekly ones. */
function resetIn(ms: number) {
  const m = Math.max(0, Math.floor(ms / 60_000));
  const d = Math.floor(m / 1440);
  const h = Math.floor((m % 1440) / 60);
  return d ? `${d}д ${h}ч` : `${h}ч ${m % 60}м`;
}

function progressText(q: QuestView) {
  const p = Math.min(q.progress, q.target);
  if (q.type === 'turnover' || q.type === 'deposit') return `${formatCoins(Math.max(0, p))} / ${formatCoins(q.target)} B`;
  return `${formatCoins(Math.max(0, p))}/${formatCoins(q.target)}`;
}

/**
 * «Задания»: three new daily quests every day and four weekly ones, paid in tickets; tickets open the cases of the
 * «Бесплатные» theme («Затмение», «Кенди»). Daily ones reset at 00:00 MSK, weekly ones on Monday.
 */
export function Quests() {
  const now = useNow(30_000);
  const me = useMe();
  const catalog = useCatalog();
  const list = useQuery({ queryKey: QUESTS_KEY, queryFn: () => api<QuestsState>('/api/quests'), staleTime: 15_000 });
  const [busy, setBusy] = useState<string | null>(null);
  // The profile carries the balance (updated by every claim and every ticket case opening).
  const tickets = me.user.tickets;
  const ticketCases = catalog.cases.filter((c) => c.kind === 'tickets' && c.ticketPrice).sort((a, b) => a.ticketPrice! - b.ticketPrice!);

  async function claim(q: QuestView) {
    if (busy) return;
    setBusy(q.id);
    try {
      const r = await act<QuestsState & { reward: number }>(`/api/quests/${q.id}/claim`);
      setMe(r.me);
      queryClient.setQueryData(QUESTS_KEY, { tickets: r.result.tickets, quests: r.result.quests });
      sfx.cashout();
      haptic('success');
      toast(`Задание выполнено! +${r.result.reward} ${ticketsWord(r.result.reward)}`, 'success');
    } catch (e) {
      sfx.error();
      toast(errorMessage(e), 'error');
      void list.refetch();
    } finally {
      setBusy(null);
    }
  }

  const quests = list.data?.quests ?? [];
  const groups = [
    { kind: 'daily' as const, title: 'Дневные', items: quests.filter((q) => q.kind === 'daily') },
    { kind: 'weekly' as const, title: 'Недельные', items: quests.filter((q) => q.kind === 'weekly') },
  ];

  return (
    <section className="quests" aria-labelledby="quests-title">
      <h1 id="quests-title" className="page-title">
        Задания
      </h1>
      <p className="quests__lead">Каждый день — новые задания. Выполняй их, копи тикеты и открывай за них бесплатные кейсы.</p>
      <a className="quests__pass" href={routeHref('pass')}>
        <Icon name="trophy" size={18} />
        <span>
          <b>Батл пасс</b> — каждое задание даёт ещё и опыт пасса
        </span>
        <Icon name="chevronRight" size={16} />
      </a>

      <div className="tk-wallet" data-tour="tickets">
        <div className="tk-wallet__balance">
          <Ticket size={40} />
          <span>
            <small>Твои тикеты</small>
            <b>{formatCoins(tickets)}</b>
          </span>
        </div>
        <ul className="tk-wallet__cases" aria-label="Кейсы за тикеты">
          {ticketCases.map((c) => {
            const short = c.ticketPrice! - tickets;
            return (
              <li key={c.id}>
                <a className={cx('tk-case', short <= 0 && 'is-ready')} href={routeHref('case', c.id)}>
                  <img src={c.image} alt="" loading="lazy" />
                  <span className="tk-case__name">{c.name}</span>
                  <span className="tk-case__price">
                    {formatCoins(c.ticketPrice!)} <Ticket size={13} />
                  </span>
                  <span className="tk-case__bar" aria-hidden="true">
                    <i style={{ transform: `scaleX(${Math.min(1, tickets / c.ticketPrice!)})` }} />
                  </span>
                  <span className="tk-case__state">{short <= 0 ? 'Можно открыть' : `ещё ${formatCoins(short)}`}</span>
                </a>
              </li>
            );
          })}
        </ul>
      </div>

      {list.isPending && <p className="hint">Загружаем задания…</p>}
      {list.isError && (
        <p className="hint">
          Задания не загрузились.{' '}
          <button type="button" className="link-btn" onClick={() => void list.refetch()}>
            Ещё раз
          </button>
        </p>
      )}
      {groups.map((g) =>
        g.items.length ? (
          <section key={g.kind} className="quests__group" aria-label={g.title}>
            <h2 className="section-title">{g.title}</h2>
            <ul className="quests__list">
              {g.items.map((q) => {
                const done = q.progress >= q.target;
                const share = Math.max(0, Math.min(1, q.progress / q.target));
                return (
                  <li key={q.id} className={cx('quest', done && 'is-done', q.claimed && 'is-claimed', q.type === 'case_open' && 'quest--case')}>
                    <span className="quest__art" aria-hidden="true">
                      <img src={q.image} alt="" loading="lazy" />
                    </span>
                    <div className="quest__body">
                      <b className="quest__name">{q.name}</b>
                      <span className="quest__text">{q.text}</span>
                      {q.caseName && <span className="quest__meta">Кейс: {q.caseName}</span>}
                      <span className="quest__track">
                        <span className="quest__bar" aria-hidden="true">
                          <i style={{ transform: `scaleX(${share})` }} />
                        </span>
                        <span className="quest__progress">{progressText(q)}</span>
                      </span>
                      <span className="quest__reset">
                        <Icon name="clock" size={12} /> Сброс через {resetIn(q.endsAt - now)}
                      </span>
                    </div>
                    <div className="quest__foot">
                      <span className="quest__reward">
                        +{q.reward} <Ticket size={18} />
                      </span>
                      {q.claimed ? (
                        <span className="quest__got">
                          <Icon name="check" size={14} /> Получено
                        </span>
                      ) : done ? (
                        <button type="button" className="btn btn--primary btn--sm" disabled={!!busy} onClick={() => void claim(q)}>
                          {busy === q.id ? '…' : 'Забрать'}
                        </button>
                      ) : q.type === 'deposit' ? (
                        <button type="button" className="btn btn--ghost btn--sm" onClick={() => openSheet('deposit')}>
                          Пополнить
                        </button>
                      ) : q.type === 'friend' ? (
                        <a className="btn btn--ghost btn--sm" href={routeHref('referrals')}>
                          Позвать
                        </a>
                      ) : q.type === 'case_open' && q.caseId ? (
                        <a className="btn btn--ghost btn--sm" href={routeHref('case', q.caseId)}>
                          Открыть
                        </a>
                      ) : q.game ? (
                        <a className="btn btn--ghost btn--sm" href={routeHref(GAME_ROUTE[q.game])}>
                          Играть
                        </a>
                      ) : null}
                    </div>
                  </li>
                );
              })}
            </ul>
          </section>
        ) : null,
      )}
      <p className="hint hint--left">
        Считаются только платные ставки: бесплатные кейсы и подарочные ключи в задания не идут. «Задепай» считает пополнения недели за
        вычетом выводов. Тикеты не сгорают и тратятся только на кейсы за тикеты — монетами их не заменить. Время — московское.
      </p>
      <p className="quests__note">
        <Coin size={14} /> Монеты из тикет-кейсов падают прямо на баланс, брейнроты — в инвентарь.
      </p>
    </section>
  );
}
