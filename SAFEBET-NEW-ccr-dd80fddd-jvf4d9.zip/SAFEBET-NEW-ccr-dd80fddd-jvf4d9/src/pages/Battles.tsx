import { useQuery } from '@tanstack/react-query';
import { useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { Avatar } from '../components/Avatar';
import { BrainrotThumb } from '../components/BrainrotCard';
import { CaseArt } from '../components/CaseArt';
import { Coin } from '../components/Coin';
import { Icon } from '../components/Icon';
import { SpinReel } from '../components/SpinReel';
import { api, errorMessage } from '../api/client';
import { act, queryClient, serverOffset, setMe, useCatalog, useMe } from '../api/queries';
import type { BattleView } from '../../server/battles';
import { round2 } from '../../shared/money';
import { cx, formatCoins, formatCountdown } from '../lib/format';
import { navigate, routeHref } from '../lib/router';
import { sfx } from '../lib/sound';
import { haptic } from '../lib/telegram';
import { useNow } from '../lib/useNow';
import { toast } from '../store/toast';
import { openPlayer, openSheet } from '../store/ui';

const COUNTDOWN_MS = 5000;
const SPIN_MS = 5200;
const REROLL_MS = 2000;
/** More ties than this are skipped straight to the deciding round. */
const SHOWN_REROLLS = 2;

type Player = BattleView['creator'];

const who = (p: Player | null) => (p ? p.name : '—');

export function Battles({ id }: { id: string | null }) {
  return id ? <BattleRoom id={id} /> : <BattleLobby />;
}

// ---------- Lobby ----------

function BattleLobby() {
  const me = useMe();
  const catalog = useCatalog();
  const now = useNow(1000);
  // A floating price («Биткоин») could change between the two players' stakes: never in battles (the server refuses).
  const paid = catalog.cases.filter((c) => c.kind === 'paid' && !c.priceCycle);
  const [caseId, setCaseId] = useState(() => paid[0]?.id ?? null);
  const [busy, setBusy] = useState(false);
  const list = useQuery({
    queryKey: ['battles'],
    queryFn: () => api<{ waiting: BattleView[]; recent: BattleView[]; mine: BattleView[] }>('/api/battles'),
    refetchInterval: 4000,
    staleTime: 0,
  });
  const kase = paid.find((c) => c.id === caseId) ?? null;
  // Battles take the player's own coins only (iteration 35): demo coins don't count here.
  const own = round2(me.user.balance - me.user.demoBalance);
  const short = kase ? own < kase.price : false;
  const frozen = !!me.user.frozen;

  async function create() {
    if (!kase || busy) return;
    setBusy(true);
    try {
      const r = await act<BattleView>('/api/battles', { caseId: kase.id });
      setMe(r.me);
      queryClient.setQueryData(['battle', String(r.result.id)], r.result);
      sfx.coin();
      navigate('battle', String(r.result.id));
    } catch (e) {
      sfx.error();
      toast(errorMessage(e), 'error');
    } finally {
      setBusy(false);
    }
  }

  async function join(b: BattleView) {
    setBusy(true);
    try {
      const r = await act<BattleView>(`/api/battles/${b.id}/join`);
      queryClient.setQueryData(['battle', String(b.id)], r.result);
      // The result lands after the countdown + spin; the balance updates now.
      setMe(r.me);
      navigate('battle', String(b.id));
    } catch (e) {
      sfx.error();
      toast(errorMessage(e), 'error');
      void list.refetch();
    } finally {
      setBusy(false);
    }
  }

  return (
    <section className="battles" aria-labelledby="battles-title">
      <h1 id="battles-title" className="page-title">
        Батлы
      </h1>
      <p className="battles__lead">Ставишь кейс — соперник ставит такой же. Крутятся оба, у кого дроп дороже — забирает оба предмета. Ничья — каждый забирает свой дроп.</p>

      <div className="panel battle-create">
        <h2 className="panel__title">Создать батл</h2>
        <div className="battle-create__cases" role="radiogroup" aria-label="Кейс для батла">
          {paid.map((c) => (
            <button key={c.id} type="button" role="radio" aria-checked={caseId === c.id} className={cx('battle-create__case', caseId === c.id && 'is-on')} onClick={() => (sfx.tap(), setCaseId(c.id))}>
              <CaseArt kase={c} lazy />
              <span>{c.name}</span>
              <b>
                {formatCoins(c.price)} <Coin size={12} />
              </b>
            </button>
          ))}
        </div>
        {short ? (
          <button type="button" className="btn btn--primary btn--lg btn--block" onClick={() => openSheet('deposit')}>
            Пополнить — не хватает {formatCoins(round2(kase!.price - own))} <Coin size={18} />
          </button>
        ) : (
          <button type="button" className="btn btn--primary btn--lg btn--block" disabled={!kase || busy || frozen} onClick={create}>
            <Icon name="shield" size={20} /> Создать батл {kase ? `за ${formatCoins(kase.price)}` : ''} {kase && <Coin size={18} />}
          </button>
        )}
        <p className="hint">Если за 5 минут никто не зайдёт — кейс откроется тебе автоматически.</p>
        {me.user.demoBalance > 0 && <p className="hint">Батлы — только на свои монеты: демо-монеты здесь не тратятся.</p>}
      </div>

      <h2 className="section-title">Открытые батлы</h2>
      {list.isPending && <p className="hint">Загружаем…</p>}
      {list.data?.waiting.length === 0 && <p className="hint">Пока никого — создай первый батл!</p>}
      <div className="battle-list">
        {list.data?.waiting.map((b) => {
          const k = catalog.caseById.get(b.caseId);
          const mine = b.you === 'creator';
          return (
            <div key={b.id} className={cx('battle-row', mine && 'is-mine')}>
              <button type="button" className="battle-row__who" onClick={() => openPlayer(b.creator.publicId)}>
                <Avatar user={b.creator} size={40} />
                <span>
                  <b>{who(b.creator)}</b>
                  <small>ждёт · {formatCountdown(Math.max(0, b.expiresAt - now))}</small>
                </span>
              </button>
              <a className="battle-row__case" href={routeHref('battle', String(b.id))}>
                {k ? <CaseArt kase={k} lazy /> : null}
                <span>
                  {b.caseName}
                  <b>
                    {formatCoins(b.price)} <Coin size={12} />
                  </b>
                </span>
              </a>
              {mine ? (
                <a className="btn btn--ghost btn--sm" href={routeHref('battle', String(b.id))}>
                  Твой
                </a>
              ) : (
                <button type="button" className="btn btn--primary btn--sm" disabled={busy || frozen || own < b.price} onClick={() => join(b)}>
                  Войти
                </button>
              )}
            </div>
          );
        })}
      </div>

      {!!list.data?.mine.length && (
        <>
          <h2 className="section-title">Мои батлы</h2>
          <BattleHistory items={list.data.mine} />
        </>
      )}
      {!!list.data?.recent.length && (
        <>
          <h2 className="section-title">Последние батлы</h2>
          <BattleHistory items={list.data.recent} />
        </>
      )}
    </section>
  );
}

function BattleHistory({ items }: { items: BattleView[] }) {
  const catalog = useCatalog();
  return (
    <div className="battle-history">
      {items.map((b) => {
        const last = b.rounds[b.rounds.length - 1];
        const a = last ? catalog.byId.get(last.creator) : null;
        const o = last?.opponent ? catalog.byId.get(last.opponent) : null;
        const label = b.status === 'solo' ? 'авто' : b.status === 'cancelled' ? 'отменён' : b.you ? (b.winner === b.you ? 'победа' : b.winner ? 'поражение' : 'ничья') : '';
        return (
          <a key={b.id} className={cx('battle-hist', b.you && b.winner === b.you && 'is-win', b.you && b.winner && b.winner !== b.you && 'is-lose')} href={routeHref('battle', String(b.id))}>
            <span className={cx('battle-hist__side', b.winner === 'creator' && 'is-winner')}>
              {a && <BrainrotThumb brainrot={a} size={40} />}
              <small>{who(b.creator)}</small>
            </span>
            <span className="battle-hist__vs">
              {b.caseName}
              {label && <em>{label}</em>}
            </span>
            <span className={cx('battle-hist__side', b.winner === 'opponent' && 'is-winner')}>
              {o && <BrainrotThumb brainrot={o} size={40} />}
              <small>{b.opponent ? who(b.opponent) : '—'}</small>
            </span>
          </a>
        );
      })}
    </div>
  );
}

// ---------- One battle ----------

type Stage = { kind: 'countdown' } | { kind: 'spin'; round: number } | { kind: 'tie'; round: number; ties: number } | { kind: 'done' };

function BattleRoom({ id }: { id: string }) {
  const me = useMe();
  const catalog = useCatalog();
  const now = useNow(250);
  const own = round2(me.user.balance - me.user.demoBalance);
  const [busy, setBusy] = useState(false);
  const battle = useQuery({
    queryKey: ['battle', id],
    queryFn: () => api<BattleView>(`/api/battles/${id}`),
    refetchInterval: (q) => (q.state.data?.status === 'waiting' ? 1500 : false),
    staleTime: 0,
  });
  const b = battle.data;
  const kase = b ? catalog.caseById.get(b.caseId) ?? null : null;
  const pool = useMemo(
    () => (kase ? kase.items.flatMap((i) => (catalog.byId.has(i.brainrotId) ? [{ brainrot: catalog.byId.get(i.brainrotId)!, weight: i.weight }] : [])) : []),
    [kase, catalog.byId],
  );

  // Animate only battles that started moments ago; older ones open on the final result.
  // Server time: a phone whose clock is off would skip the spin or count down for half a minute.
  const offset = serverOffset();
  const fresh = !!b && b.status === 'finished' && !!b.startedAt && now + offset - b.startedAt < COUNTDOWN_MS + 20_000;
  const [stage, setStage] = useState<Stage | null>(null);
  const started = useRef(false);
  useEffect(() => {
    if (!b || started.current || b.status !== 'finished') return;
    started.current = true;
    if (!fresh || !b.startedAt) {
      setStage({ kind: 'done' });
      return;
    }
    const wait = Math.max(0, b.startedAt + COUNTDOWN_MS - (Date.now() + serverOffset()));
    setStage(wait > 0 ? { kind: 'countdown' } : { kind: 'spin', round: 0 });
    if (wait > 0) setTimeout(() => setStage({ kind: 'spin', round: 0 }), wait);
  }, [b, fresh]);

  const countdown = b?.startedAt ? Math.ceil((b.startedAt + COUNTDOWN_MS - (now + offset)) / 1000) : 0;
  const lastBeep = useRef(0);
  useEffect(() => {
    if (stage?.kind === 'countdown' && countdown > 0 && countdown !== lastBeep.current) {
      lastBeep.current = countdown;
      sfx.tick();
      haptic('tap');
    }
  }, [stage, countdown]);

  function landed(round: number) {
    if (!b) return;
    const r = b.rounds[round]!;
    const pa = catalog.byId.get(r.creator)?.price ?? 0;
    const po = r.opponent ? catalog.byId.get(r.opponent)?.price ?? 0 : 0;
    if (pa === po && round < b.rounds.length - 1) {
      sfx.land();
      const last = b.rounds.length - 1;
      // Long tie streaks (one cheap item dominating the case) jump to the deciding round.
      const next = round + 1 >= SHOWN_REROLLS ? last : round + 1;
      setStage({ kind: 'tie', round, ties: next === last ? last : round + 1 });
      setTimeout(() => setStage({ kind: 'spin', round: next }), 1100);
      return;
    }
    setStage({ kind: 'done' });
    if (b.you && b.winner === b.you) {
      sfx.bigWin();
      haptic('success');
    } else if (b.you) {
      sfx.lose();
      haptic('error');
    } else sfx.win();
    void queryClient.invalidateQueries({ queryKey: ['me'] });
    void queryClient.invalidateQueries({ queryKey: ['battles'] });
  }

  async function join() {
    setBusy(true);
    try {
      const r = await act<BattleView>(`/api/battles/${id}/join`);
      setMe(r.me);
      queryClient.setQueryData(['battle', id], r.result);
    } catch (e) {
      sfx.error();
      toast(errorMessage(e), 'error');
      void battle.refetch();
    } finally {
      setBusy(false);
    }
  }

  async function cancel() {
    setBusy(true);
    try {
      const r = await act<BattleView>(`/api/battles/${id}/cancel`);
      setMe(r.me);
      queryClient.setQueryData(['battle', id], r.result);
      toast('Батл отменён — ставка вернулась', 'success');
    } catch (e) {
      toast(errorMessage(e), 'error');
    } finally {
      setBusy(false);
    }
  }

  if (battle.isPending) return <p className="hint">Загружаем батл…</p>;
  if (!b) return <p className="hint">{errorMessage(battle.error)}</p>;

  const round = stage?.kind === 'spin' || stage?.kind === 'tie' ? stage.round : b.rounds.length - 1;
  const r = b.rounds[Math.max(0, round)];
  const done = stage?.kind === 'done' || b.status === 'solo' || b.status === 'cancelled';
  const a = r ? catalog.byId.get(r.creator) : null;
  const o = r?.opponent ? catalog.byId.get(r.opponent) : null;
  const total = round2((a?.price ?? 0) + (o?.price ?? 0));

  return (
    <section className="battle-room" aria-labelledby="battle-title">
      <a className="back-link" href={routeHref('battle')}>
        <Icon name="chevronRight" size={18} className="back-link__icon" /> Все батлы
      </a>
      <h1 id="battle-title" className="page-title page-title--center">
        Батл #{b.id}
      </h1>
      <p className="battle-room__case">
        {kase && <CaseArt kase={kase} />}
        <span>
          {b.caseName} · {formatCoins(b.price)} <Coin size={14} />
        </span>
      </p>

      <Side
        label="Создатель"
        player={b.creator}
        you={b.you === 'creator'}
        winner={done && b.winner === 'creator'}
        loser={done && b.winner === 'opponent'}
        reel={
          r && stage?.kind === 'spin' && kase ? (
            <SpinReel key={`c${round}`} pool={pool} won={a!} durationMs={round ? REROLL_MS : SPIN_MS} mystery={kase.mystery} onLanded={() => landed(round)} />
          ) : null
        }
        drop={(done || stage?.kind === 'tie') && a ? a : null}
      />

      <div className={cx('battle-vs', stage?.kind === 'countdown' && 'is-counting')}>
        {stage?.kind === 'countdown' ? <span className="battle-vs__count">{Math.max(1, countdown)}</span> : stage?.kind === 'tie' ? <span className="battle-vs__tie">Ничья{stage.ties > 1 ? ` ×${stage.ties}` : ''} — реролл!</span> : <span>VS</span>}
      </div>

      {b.status === 'waiting' ? (
        <div className="battle-side battle-side--empty">
          {b.you === 'creator' ? (
            <>
              <span className="bdep-live__spinner" aria-hidden="true" />
              <p className="battle-side__wait">Ждём соперника · {formatCountdown(Math.max(0, b.expiresAt - now))}</p>
              <p className="hint">Не дождёшься — кейс откроется тебе сам. Кинь ссылку другу!</p>
              <button type="button" className="btn btn--ghost btn--block" disabled={busy} onClick={cancel}>
                Отменить и вернуть {formatCoins(b.price)} B
              </button>
            </>
          ) : (
            <>
              <p className="battle-side__wait">Свободное место</p>
              <button type="button" className="btn btn--primary btn--lg btn--block" disabled={busy || !!me.user.frozen || own < b.price} onClick={join}>
                <Icon name="shield" size={20} /> Присоединиться за {formatCoins(b.price)} <Coin size={18} />
              </button>
              {own < b.price && (
                <p className="hint">
                  Не хватает {formatCoins(round2(b.price - own))} B{me.user.demoBalance > 0 ? ' — демо-монеты в батлах не играют' : ''}
                </p>
              )}
            </>
          )}
        </div>
      ) : b.status === 'solo' || b.status === 'cancelled' ? (
        <div className="battle-side battle-side--empty">
          <p className="battle-side__wait">{b.status === 'solo' ? 'Никто не зашёл — кейс открыт автоматически' : 'Батл отменён, ставка вернулась'}</p>
        </div>
      ) : (
        <Side
          label="Соперник"
          player={b.opponent}
          you={b.you === 'opponent'}
          winner={done && b.winner === 'opponent'}
          loser={done && b.winner === 'creator'}
          reel={
            r?.opponent && stage?.kind === 'spin' && kase ? (
              <SpinReel key={`o${round}`} pool={pool} won={o!} durationMs={round ? REROLL_MS : SPIN_MS} mystery={kase.mystery} ticks={false} />
            ) : null
          }
          drop={(done || stage?.kind === 'tie') && o ? o : null}
        />
      )}

      {done && b.status === 'finished' && (
        <div className={cx('battle-result', b.you && (b.winner === b.you ? 'is-win' : 'is-lose'))} role="status">
          <p className="battle-result__title">
            {b.winner === null ? 'Ничья — каждый забрал свой дроп' : b.you ? (b.winner === b.you ? 'Победа! Оба предмета твои' : 'Поражение') : `Победил ${who(b.winner === 'creator' ? b.creator : b.opponent)}`}
          </p>
          <p className="battle-result__sum">
            Банк: {formatCoins(total)} <Coin size={16} />
            {b.rounds.length > 1 && <small> · рероллов: {b.rounds.length - 1}</small>}
          </p>
          <a className="btn btn--primary btn--block" href={routeHref('battle')}>
            Ещё батл
          </a>
        </div>
      )}
    </section>
  );
}

function Side({ label, player, you, winner, loser, reel, drop }: { label: string; player: Player | null; you: boolean; winner: boolean; loser: boolean; reel: ReactNode; drop: { name: string; image: string; price: number } | null }) {
  return (
    <div className={cx('battle-side', winner && 'is-winner', loser && 'is-loser')}>
      <div className="battle-side__head">
        {player && <Avatar user={player} size={36} />}
        <span>
          <small>
            {label}
            {you && ' · ты'}
          </small>
          <b>{who(player)}</b>
        </span>
        {winner && <span className="pill pill--green">Победа</span>}
      </div>
      {reel}
      {!reel && drop && (
        <div className="battle-side__drop">
          <img src={drop.image} alt="" />
          <span>
            {drop.name}
            <b>
              {formatCoins(drop.price)} <Coin size={13} />
            </b>
          </span>
        </div>
      )}
    </div>
  );
}
