-- Iteration 37: «Батл пасс» (shared/pass.ts). Applied by the Worker (server/autoMigrate.ts), so every statement is safe
-- to run twice. Experience is read from drops and quest_claims; these keep only purchases and claims.

-- BPlus bought for a season (299 ⭐ through a Stars invoice `pass:<order>`).
CREATE TABLE IF NOT EXISTS pass_orders (
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT NOT NULL REFERENCES users (id),
  season TEXT NOT NULL,
  stars INT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'paid')),
  charge_id TEXT UNIQUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  paid_at TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS pass_orders_user ON pass_orders (user_id, created_at DESC);

CREATE TABLE IF NOT EXISTS pass_plus (
  user_id BIGINT NOT NULL REFERENCES users (id),
  season TEXT NOT NULL,
  order_id BIGINT REFERENCES pass_orders (id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, season)
);

-- One row per level and track: the primary key is what makes a reward claimable once.
CREATE TABLE IF NOT EXISTS pass_claims (
  user_id BIGINT NOT NULL REFERENCES users (id),
  season TEXT NOT NULL,
  level INT NOT NULL CHECK (level BETWEEN 1 AND 30),
  track TEXT NOT NULL CHECK (track IN ('free', 'plus')),
  reward JSONB NOT NULL,
  value NUMERIC(16, 2) NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, season, level, track)
);
