import { useQuery } from '@tanstack/react-query';
import { useEffect, useMemo, useRef, useState, type CSSProperties } from 'react';
import { BrainrotThumb } from '../components/BrainrotCard';
import { Coin } from '../components/Coin';
import { Burst, Confetti } from '../components/Fx';
import { NightSky } from '../components/HalloweenArt';
import { Icon } from '../components/Icon';
import { EventBanner, useEvents } from '../components/Events';
import { InventoryGrid, type InventoryItem } from '../components/InventoryGrid';
import { Sheet } from '../components/Sheet';
import { FastToggle } from '../components/Toggle';
import { api, errorMessage } from '../api/client';
import { act, queryClient, setMe, useCatalog, useMe, type Me } from '../api/queries';
import { MAX_FUSE_ITEMS, MIN_FUSE_ITEMS, fuseMessage, fuseOutcome, fuseTable, pickFuse, type FuseResult, type FuseState } from '../../shared/fuse';
import { round2 } from '../../shared/money';
import type { Brainrot } from '../../shared/types';
import layout from '../lib/fuse-layout.json';
import { useNow } from '../lib/useNow';
import { cx, formatCoins } from '../lib/format';
import { sha256Hex, sleep } from '../lib/halloween';
import { sfx } from '../lib/sound';
import { haptic } from '../lib/telegram';
import { tierOf } from '../lib/tier';
import { toast } from '../store/toast';
import { MIXED_DEMO, mixesDemo } from '../lib/demo';

const STATE_KEY = ['fuse'] as const;
const pt = (p: number[]) => ({ x: `${p[0]}%`, y: `${p[1]}%` });
const poly = (points: number[][]) => `polygon(${points.map((p) => `${p[0]}% ${p[1]}%`).join(', ')})`;
const MOUTH_CLIP = poly(layout.mouth);
/** The tongue shows inside the mouth and anywhere in front of (below) the lower lip, never over the walls. */
const [MTL, MTR, MBR, MBL] = layout.mouth as [number[], number[], number[], number[]];
const TONGUE_CLIP = poly([MTL, MTR, MBR, [100, MBR[1]!], [100, 100], [0, 100], [0, MBL[1]!], MBL]);
/** Each eye window: its outline (for the clip) and its box (where the lid wipes down to blink). */
const EYES = layout.eyePolys.map((points, i) => {
  const xs = points.map((p) => p[0]!);
  const ys = points.map((p) => p[1]!);
  const [x0, y0] = [Math.min(...xs), Math.min(...ys)];
  return {
    clip: poly(points),
    // Pupils dilate and roll around their own window, not the middle of the picture.
    center: { '--ex': `${layout.eyes[i]![0]}%`, '--ey': `${layout.eyes[i]![1]}%` } as CSSProperties,
    lid: { left: `${x0}%`, top: `${y0}%`, width: `${Math.max(...xs) - x0}%`, height: `${Math.max(...ys) - y0}%` } as CSSProperties,
  };
});
/** How far the door slides up to open the mouth fully, in % of the picture. */
const DOOR_LIFT = Math.max(...layout.mouth.map((p) => p[1]!)) - Math.min(...layout.mouth.map((p) => p[1]!));

type Phase = 'idle' | 'open' | 'grab' | 'feed' | 'gulp' | 'chew' | 'spit' | 'done';

const STATUS: Partial<Record<Phase, string>> = {
  open: 'Дом раскрывает пасть…',
  grab: 'Язык тянется к набору…',
  feed: 'Глотает…',
  gulp: 'Ам!',
  chew: 'Переваривает набор…',
  spit: 'Тьфу! Дроп!',
};

export function Fuse() {
  const me = useMe();
  const catalog = useCatalog();
  const fuseEvent = useEvents(useNow(5000)).some((e) => e.id === 'fuse');
  const state = useQuery({ queryKey: STATE_KEY, queryFn: () => api<FuseState>('/api/fuse'), staleTime: 30_000 });
  const [picked, setPicked] = useState<number[]>([]);
  const [fast, setFast] = useState(false);
  const [pending, setPending] = useState(false);
  const [phase, setPhase] = useState<Phase>('idle');
  const [feeding, setFeeding] = useState<{ key: number; images: string[] } | null>(null);
  const [tongue, setTongue] = useState(false);
  const [poked, setPoked] = useState(false);
  const lastPoke = useRef(0);
  const [drop, setDrop] = useState<{ result: FuseResult; key: number; from: Brainrot[] } | null>(null);
  const [sheet, setSheet] = useState(false);
  const [selling, setSelling] = useState(false);
  const [pace, setPace] = useState(1);
  const [verified, setVerified] = useState<boolean | null>(null);
  const scene = useRef<HTMLDivElement>(null);
  const unapplied = useRef<Me | null>(null);

  useEffect(
    () => () => {
      if (unapplied.current) setMe(unapplied.current);
    },
    [],
  );

  // Provably fair: the revealed key hashes to what was shown and picks this very brainrot from the catalog.
  useEffect(() => {
    if (!drop) return;
    let alive = true;
    const r = drop.result;
    Promise.all([sha256Hex(r.seed), sha256Hex(fuseMessage(r.seed))])
      .then(([h, k]) => {
        const table = fuseTable(r.stakeValue, catalog.active);
        if (alive) setVerified(h === r.hash && !!table && pickFuse(table, k).id === r.brainrotId);
      })
      .catch(() => {});
    return () => {
      alive = false;
    };
  }, [drop, catalog.active]);

  const busy = pending || (phase !== 'idle' && phase !== 'done');
  const frozen = !!me.user.frozen;
  const free = me.inventory.filter((i) => !i.withdrawalId);
  const pickedItems = picked.flatMap((id) => {
    const item = free.find((i) => i.id === id);
    const b = item ? catalog.byId.get(item.brainrotId) : undefined;
    return item && b ? [{ item, b }] : [];
  });
  const stakeValue = round2(pickedItems.reduce((s, p) => s + p.b.price, 0));
  const table = useMemo(() => (stakeValue > 0 ? fuseTable(stakeValue, catalog.active) : null), [stakeValue, catalog.active]);
  const problem = frozen
    ? 'Аккаунт заморожен — играть нельзя'
    : pickedItems.length < MIN_FUSE_ITEMS
      ? `Выбери ещё ${MIN_FUSE_ITEMS - pickedItems.length}`
      : !table
        ? 'Слишком дорогой набор — машине нечем ответить'
        : null;

  function toggle(item: InventoryItem) {
    if (busy) return;
    if (phase === 'done') setPhase('idle');
    if (picked.includes(item.id)) {
      sfx.tap();
      setPicked((list) => list.filter((id) => id !== item.id));
      return;
    }
    if (mixesDemo(pickedItems.map((p) => p.item), item)) {
      sfx.error();
      toast(MIXED_DEMO);
      return;
    }
    if (pickedItems.length >= MAX_FUSE_ITEMS) {
      sfx.error();
      toast(`В фьюз — до ${MAX_FUSE_ITEMS} брейнротов. Нажми на слот, чтобы убрать`);
      return;
    }
    sfx.tap();
    setPicked((list) => [...list.filter((id) => pickedItems.some((p) => p.item.id === id)), item.id]);
  }

  /** «Автоподбор»: the cheapest brainrots fill the free slots — a fuse is a good place for junk. */
  function autoPick(like?: Brainrot[]) {
    if (busy) return;
    const taken = new Set(pickedItems.map((p) => p.item.id));
    const pool = free
      .filter((i) => !taken.has(i.id) && catalog.byId.has(i.brainrotId))
      .map((i) => ({ i, price: catalog.byId.get(i.brainrotId)!.price }));
    const chosen = pickedItems.map((p) => p.item.id);
    if (like?.length) {
      // «Повторить похожий набор»: the closest prices to the last set.
      for (const b of like) {
        const best = pool.filter((x) => !chosen.includes(x.i.id)).sort((a, z) => Math.abs(a.price - b.price) - Math.abs(z.price - b.price))[0];
        if (best && chosen.length < MAX_FUSE_ITEMS) chosen.push(best.i.id);
      }
    } else {
      for (const x of pool.sort((a, z) => a.price - z.price)) if (chosen.length < MAX_FUSE_ITEMS) chosen.push(x.i.id);
    }
    if (chosen.length < MIN_FUSE_ITEMS) {
      sfx.error();
      toast(`Нужно хотя бы ${MIN_FUSE_ITEMS} брейнрота — открой кейс, и они появятся`);
      return;
    }
    sfx.tap();
    if (phase === 'done') setPhase('idle');
    setPicked(chosen);
  }

  function clear() {
    if (busy) return;
    sfx.tap();
    setPicked([]);
  }

  async function go() {
    if (busy || problem) return;
    const from = pickedItems.map((p) => p.b);
    setPending(true);
    let r: { result: FuseResult; me: Me };
    try {
      r = await act<FuseResult>('/api/fuse', { itemIds: pickedItems.map((p) => p.item.id) });
    } catch (e) {
      sfx.error();
      toast(errorMessage(e), 'error');
      setPending(false);
      return;
    }
    const res = r.result;
    unapplied.current = r.me;
    // The set stays on the slime pad (now as the plate being eaten) while the stake slots empty.
    setFeeding({ key: Date.now(), images: from.map((b) => b.image) });
    setPending(false);
    setPicked([]);
    setVerified(null);
    setDrop(null);
    queryClient.setQueryData<FuseState>(STATE_KEY, (old) => (old ? { ...old, nextHash: res.nextHash } : old));
    const top = scene.current?.getBoundingClientRect().top ?? 0;
    if (top < 56 || top > window.innerHeight * 0.4) window.scrollBy({ top: top - 72, behavior: 'smooth' });

    const pace = fast ? 0.45 : 1;
    setPace(pace);
    haptic('tap');
    // The jaw opens, the eyes lock on the set…
    setPhase('open');
    sfx.creak();
    await sleep(460 * pace);
    // …the tongue shoots out under it…
    setPhase('grab');
    setTongue(true);
    sfx.slurp();
    await sleep(440 * pace);
    // …and drags it in.
    setPhase('feed');
    setTongue(false);
    for (let k = 0; k < from.length; k++) setTimeout(() => sfx.absorb(), (180 + k * 90) * pace);
    await sleep((480 + from.length * 90) * pace);
    // Gulp: the jaw slams and the whole house swallows.
    setPhase('gulp');
    setFeeding(null);
    sfx.gulp();
    haptic('error');
    await sleep(620 * pace);
    setPhase('chew');
    sfx.knock();
    setTimeout(() => sfx.ghost(), 260 * pace);
    await sleep(1300 * pace);
    // Spit: the tongue throws the drop out onto the pad.
    setPhase('spit');
    setTongue(true);
    sfx.slurp();
    sfx.flash();
    const won = catalog.byId.get(res.brainrotId);
    const rare = !!won && ['legendary', 'secret'].includes(tierOf(won.price));
    setDrop({ result: res, key: Date.now(), from });
    await sleep(380 * pace);
    setTongue(false);
    if (res.value >= res.stakeValue) {
      if (res.multiplier >= 1.5 || rare) sfx.bigWin();
      else sfx.win();
      haptic('success');
    } else {
      sfx.lose();
      haptic('tap');
    }
    await sleep(650 * pace);
    unapplied.current = null;
    setMe(r.me);
    setPhase('done');
    setSheet(true);
    queryClient.setQueryData<FuseState>(STATE_KEY, (old) =>
      old ? { ...old, mine: [{ from: from.map((b) => b.id), brainrotId: res.brainrotId, stakeValue: res.stakeValue, value: res.value, at: Date.now() }, ...old.mine].slice(0, 12) } : old,
    );
    if (res.value > res.stakeValue) void queryClient.invalidateQueries({ queryKey: STATE_KEY });
  }

  /** Poke the house while it rests: it growls, its eyes flare and it shudders. */
  function poke() {
    if (busy || Date.now() - lastPoke.current < 900) return;
    lastPoke.current = Date.now();
    sfx.growl();
    haptic('tap');
    setPoked(true);
    setTimeout(() => setPoked(false), 650);
  }

  async function sell() {
    if (!drop || selling) return;
    setSelling(true);
    try {
      const r = await act<{ coins: number }>('/api/inventory/sell', { itemIds: [drop.result.itemId] });
      setMe(r.me);
      sfx.coin();
      toast(`Продано за ${formatCoins(r.result.coins)} B`, 'success');
      setSheet(false);
    } catch (e) {
      sfx.error();
      toast(errorMessage(e), 'error');
    } finally {
      setSelling(false);
    }
  }

  function again() {
    setSheet(false);
    if (drop) autoPick(drop.from);
  }

  const r = drop?.result ?? null;
  const prize = r ? catalog.byId.get(r.brainrotId) ?? null : null;
  const outcome = r ? fuseOutcome(r.stakeValue, r.value) : null;
  const profit = !!r && r.value >= r.stakeValue;
  const mine = state.data?.mine ?? [];
  const top = state.data?.top ?? [];
  const slots = Array.from({ length: MAX_FUSE_ITEMS }, (_, k) => pickedItems[k] ?? null);
  // What sits on the slime pad: the set being eaten, or the one being picked (the house stares at it hungrily).
  const plate = feeding?.images ?? (phase === 'idle' || (phase === 'done' && !drop) ? pickedItems.map((p) => p.b.image) : []);

  return (
    <section className={cx('game fuse', fuseEvent && 'is-event')} aria-labelledby="fuse-title">
      <EventBanner id="fuse" />
      <div className="pk-head">
        <div className="fuse-title">
          <span className="fuse-title__new">Новый режим</span>
          <h1 id="fuse-title" className="page-title">
            Haunted Fuse
          </h1>
        </div>
        <FastToggle on={fast} onChange={setFast} disabled={busy} />
      </div>
      <p className="fuse-lead">Положи 3–4 брейнрота — дом проглотит их и выплюнет одного случайного. Чем дороже набор, тем дороже может выпасть.</p>

      <div
        className={cx(
          'pk-scene',
          'fuse-scene',
          `is-${phase}`,
          profit && phase !== 'idle' && 'is-profit',
          (phase === 'idle' || phase === 'done') && pickedItems.length > 0 && 'is-hungry',
          poked && 'is-poked',
        )}
        style={{ '--pace': pace } as CSSProperties}
        ref={scene}
      >
        <NightSky />
        <div
          className="fuse-house"
          onPointerDown={poke}
          style={
            {
              '--mx': pt(layout.mouthCenter).x,
              '--my': pt(layout.mouthCenter).y,
              '--px': pt(layout.pad).x,
              '--py': pt(layout.pad).y,
              '--cx': pt(layout.chimney).x,
              '--cy': pt(layout.chimney).y,
              '--rx': pt(layout.tongueRoot).x,
              '--ry': pt(layout.tongueRoot).y,
              '--tx': `${layout.tongueRoot[0]! - layout.tongueTip[0]!}%`,
              '--ty': `${layout.tongueRoot[1]! - layout.tongueTip[1]!}%`,
              '--tx2': pt(layout.tongueTip).x,
              '--ty2': pt(layout.tongueTip).y,
              '--lift': `${-DOOR_LIFT}%`,
            } as CSSProperties
          }
        >
          <div className="fuse-sway">
            <div className="fuse-rig">
              <img className="fuse-house__body" src="/fuse/house.webp" alt="Живой дом-фьюз: глаза-окна, пасть-ворота и длинный язык" />
              <span className="fuse-house__lava" aria-hidden="true" />
              <span className="fuse-house__door" style={{ clipPath: MOUTH_CLIP }} aria-hidden="true">
                <img src="/fuse/door.webp" alt="" />
              </span>
              <img className="fuse-house__mouth" src="/fuse/mouth.webp" alt="" aria-hidden="true" />
              <span className={cx('fuse-tongue', tongue && 'is-out')} style={{ clipPath: TONGUE_CLIP }} aria-hidden="true">
                <img src="/fuse/tongue.webp" alt="" />
              </span>
              {EYES.map((eye, i) => (
                <span key={i} className={`fuse-eye fuse-eye--${i}`} style={{ clipPath: eye.clip, ...eye.center }} aria-hidden="true">
                  <img className="fuse-eye__glow" src="/fuse/eyes.webp" alt="" />
                  <img className="fuse-eye__pupil" src="/fuse/pupils.webp" alt="" />
                  <span className="fuse-eye__lid" style={eye.lid} />
                </span>
              ))}
              <span className="fuse-smoke" aria-hidden="true">
                <i />
                <i />
                <i />
              </span>
            </div>
          </div>
          {plate.length > 0 && (
            <span key={feeding?.key ?? 'picked'} className={cx('fuse-plate', phase === 'feed' && 'is-pulled', !feeding && 'is-wobble')} aria-hidden="true">
              {plate.map((src, i) => (
                <img key={`${i}-${src}`} src={src} alt="" style={{ '--i': i, '--n': plate.length } as CSSProperties} />
              ))}
            </span>
          )}
          {drop && prize && (phase === 'spit' || phase === 'done') && (
            <span key={drop.key} className={cx('fuse-drop', profit && 'is-profit')} aria-hidden="true">
              <span className="fuse-drop__rays" />
              <img src={prize.image} alt="" />
              <Burst count={profit ? 30 : 14} spread={profit ? 1.2 : 0.8} />
            </span>
          )}
        </div>
        <p className="fuse-status" role="status">
          <span key={phase}>{STATUS[phase] ?? (phase === 'done' && prize ? `${prize.name} · ${formatCoins(r!.value)} B` : 'Haunted Fuse ждёт набор')}</span>
        </p>
        <span className="pk-fog pk-fog--front" />
      </div>

      <div className="panel fuse-stake">
        <div className="fuse-stake__head">
          <span>Ставка</span>
          <b className={cx(pickedItems.length >= MIN_FUSE_ITEMS && 'is-ready')}>
            {pickedItems.length}/{MAX_FUSE_ITEMS}
          </b>
        </div>
        <div className="fuse-slots">
          {slots.map((p, k) =>
            p ? (
              <button key={p.item.id} type="button" className={cx('fuse-slot', 'is-filled', `tier-${tierOf(p.b.price)}`)} onClick={() => toggle(p.item)} disabled={busy} aria-label={`Убрать ${p.b.name}`}>
                <BrainrotThumb brainrot={p.b} size={46} />
                <small>{formatCoins(p.b.price)}</small>
              </button>
            ) : (
              <span key={`empty-${k}`} className="fuse-slot">
                {k + 1}
              </span>
            ),
          )}
        </div>
        <p className="hint">{pickedItems.length ? 'Нажми на слот, чтобы убрать.' : 'Выбери набор ниже или нажми «Автоподбор».'}</p>
        <div className="fuse-tools">
          <button type="button" className="btn btn--ghost fuse-auto" onClick={() => autoPick()} disabled={busy}>
            <Icon name="bolt" size={18} /> Автоподбор
          </button>
          <button type="button" className="btn btn--ghost fuse-clear" onClick={clear} disabled={busy || !pickedItems.length} aria-label="Очистить набор">
            <Icon name="close" size={18} />
          </button>
        </div>
        <dl className="fuse-sum">
          <div>
            <dt>Сумма набора</dt>
            <dd>
              {formatCoins(stakeValue)} <Coin size={14} />
            </dd>
          </div>
          <div>
            <dt>Может выпасть</dt>
            <dd className="is-green">
              {table ? (
                <>
                  {formatCoins(table.min)} – {formatCoins(table.max)} <Coin size={14} />
                </>
              ) : (
                '—'
              )}
            </dd>
          </div>
        </dl>
        <button type="button" className="btn btn--primary btn--lg btn--block fuse-go" disabled={!!problem || busy} onClick={go}>
          {pending ? 'Секунду…' : busy ? 'Фьюзим…' : problem ?? (
            <>
              <Icon name="fuse" size={20} /> Зафьюзить
            </>
          )}
        </button>
      </div>

      <h2 className="section-title">Твои брейнроты</h2>
      <InventoryGrid items={free} selected={pickedItems.map((p) => p.item.id)} disabled={busy} onPick={toggle} sortable />

      <ol className="fuse-steps">
        <li>
          <b>1</b>
          <span>
            <strong>Выбери набор</strong> Любые 3–4 брейнрота из инвентаря. Их суммарная цена и есть ставка.
          </span>
        </li>
        <li>
          <b>2</b>
          <span>
            <strong>Зафьюзь</strong> Дом проглотит набор и выплюнет одного случайного брейнрота — от дешёвого до двух ставок.
          </span>
        </li>
        <li>
          <b>3</b>
          <span>
            <strong>Забери или продай</strong> Дроп сразу в инвентаре: оставь, продай или зафьюзь снова.
          </span>
        </li>
      </ol>

      <p className="pk-fair hw-fair">
        <Icon name="shield" size={14} /> Честная игра · следующий фьюз: хэш <code>{(state.data?.nextHash ?? '').slice(0, 12)}…</code>
        {r && phase === 'done' && (
          <>
            {' '}
            · ключ прошлого <code>{r.seed.slice(0, 8)}…</code> {verified === true && <span className="pk-fair__ok">совпадает ✓</span>}
            {verified === false && <span className="pk-fair__bad">не совпадает</span>}
          </>
        )}
      </p>

      {mine.length > 0 && (
        <div className="history" aria-label="Мои фьюзы">
          {mine.map((m, i) => (
            <span key={`${m.at}-${i}`} className={cx('history__chip', m.value >= m.stakeValue ? 'is-high' : 'is-low')}>
              x{fuseOutcome(m.stakeValue, m.value).multiplier.toFixed(2)}
            </span>
          ))}
        </div>
      )}

      {top.length > 0 && (
        <section className="panel hw-top" aria-labelledby="fuse-top-title">
          <h2 id="fuse-top-title" className="panel__title">
            Лучшие фьюзы
          </h2>
          <ol className="hw-top__list">
            {top.map((t, i) => {
              const b = catalog.byId.get(t.brainrotId);
              return (
                <li key={`${t.at}-${i}`} className={cx('hw-top__row', i < 3 && 'is-podium')}>
                  <span className="hw-top__rank">{i + 1}</span>
                  <span className="hw-top__who">
                    <b>{t.name}</b>
                    <small>
                      {formatCoins(t.stakeValue)} B → x{t.multiplier.toFixed(2)}
                    </small>
                  </span>
                  {b && <BrainrotThumb brainrot={b} size={30} />}
                  <span className="hw-top__value">
                    <Coin size={13} /> {formatCoins(t.value)}
                  </span>
                </li>
              );
            })}
          </ol>
        </section>
      )}

      <Sheet open={sheet && !!r && !!prize} onClose={() => setSheet(false)} title="Твой дроп" className="fuse-result">
        {r && prize && outcome && (
          <div className={cx('fuse-card', `tier-${tierOf(prize.price)}`, profit && 'is-profit')}>
            <span className="fuse-card__rays" aria-hidden="true" />
            <img className="fuse-card__img" src={prize.image} alt="" />
            <p className="fuse-card__name">{prize.name}</p>
            <p className="fuse-card__price">
              {formatCoins(r.value)} <Coin size={22} />
            </p>
            <p className="fuse-card__chips">
              <span className={cx('chip chip--sm', 'fuse-card__x', profit ? 'is-up' : 'is-down')}>x{outcome.multiplier.toFixed(2)}</span>
              <span className="chip chip--sm">
                {outcome.percent >= 0 ? '+' : '−'}
                {Math.abs(Math.round(outcome.percent))}% к ставке
              </span>
              <span className="chip chip--sm">Ставка {formatCoins(r.stakeValue)} B</span>
            </p>
            <div className="fuse-card__actions">
              <button type="button" className="btn btn--primary" onClick={() => setSheet(false)}>
                Забрать
              </button>
              <button type="button" className="btn btn--ghost" onClick={() => void sell()} disabled={selling}>
                Продать за {formatCoins(r.value)} B
              </button>
            </div>
            <button type="button" className="btn btn--ghost btn--block" onClick={again}>
              Повторить похожий набор
            </button>
          </div>
        )}
      </Sheet>
      {profit && outcome && outcome.multiplier >= 1.5 && phase === 'done' && drop && <Confetti key={drop.key} count={56} />}
    </section>
  );
}
