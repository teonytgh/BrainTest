import { useQuery } from '@tanstack/react-query';
import { useEffect, useMemo, useState, type FormEvent } from 'react';
import { BrainrotThumb } from './BrainrotCard';
import { Coin } from './Coin';
import { Icon } from './Icon';
import { api, errorMessage } from '../api/client';
import { queryClient, useCatalog, useMe } from '../api/queries';
import type { ItemDepositView } from '../../server/itemDeposits';
import type { Brainrot } from '../../shared/types';
import { round2 } from '../../shared/money';
import { DEPOSIT_SECTION_LABEL, DEPOSIT_SECTION_OF, MAX_DEPOSIT_ITEMS, type DepositSection } from '../../shared/deposit';
import { cx, formatCoins } from '../lib/format';
import { sfx } from '../lib/sound';
import { haptic } from '../lib/telegram';
import { tierOf } from '../lib/tier';
import { useNow } from '../lib/useNow';
import { toast } from '../store/toast';
import { DepositWagerNote } from './Wager';

const MAX_ITEMS = MAX_DEPOSIT_ITEMS;
const NICK_KEY = 'brainrotcrash:robloxNick';
const SEEN_KEY = 'brainrotcrash:depositSeen';
const OPEN = new Set(['searching', 'trading']);
type Sort = 'desc' | 'asc' | 'name';

function storage(key: string, value?: string): string {
  try {
    if (value === undefined) return localStorage.getItem(key) ?? '';
    localStorage.setItem(key, value);
  } catch {
    // Private mode: the value just isn't remembered.
  }
  return value ?? '';
}


/**
 * «Брейнроты» and «Гирсы» tabs of the deposit sheet: pick up to 5, send them by trade, get coins once an admin
 * accepts. An open request shows on either tab; a tab the admins closed takes no new ones.
 */
export function BrainrotDeposit({ section, onClose }: { section: DepositSection; onClose: () => void }) {
  const catalog = useCatalog();
  // Polls only while the request is open (waiting for a bot or for the trade).
  const current = useQuery({
    queryKey: ['itemDeposit'],
    queryFn: () => api<ItemDepositView | null>('/api/item-deposits/current'),
    staleTime: 0,
    refetchInterval: (q) => (q.state.data && OPEN.has(q.state.data.status) ? 2000 : false),
  });
  const dep = current.data ?? null;
  const [seen, setSeen] = useState(() => storage(SEEN_KEY));
  const [again, setAgain] = useState<ItemDepositView['items'] | null>(null);

  const dismiss = (id: number) => {
    storage(SEEN_KEY, String(id));
    setSeen(String(id));
  };

  useEffect(() => {
    if (dep?.status === 'credited' && seen !== String(dep.id)) {
      sfx.bigWin();
      haptic('success');
      void queryClient.invalidateQueries({ queryKey: ['me'] });
    }
    if (dep?.status === 'trading') {
      sfx.whoosh();
      haptic('success');
    }
  }, [dep?.status, dep?.id, seen]);

  if (current.isPending) return <p className="hint">Загружаем…</p>;
  if (dep && OPEN.has(dep.status)) return <DepositStatus dep={dep} />;
  // Finished requests are shown once (even if the admin acted while the app was closed).
  if (dep && dep.status !== 'cancelled' && seen !== String(dep.id) && Date.now() - dep.createdAt < 24 * 3600_000) {
    return (
      <DepositResult
        dep={dep}
        onDone={() => {
          dismiss(dep.id);
          if (dep.status === 'credited') onClose();
        }}
        onRetry={() => {
          dismiss(dep.id);
          setAgain(dep.items);
        }}
      />
    );
  }
  if (catalog.depositOpen?.[section] === false) {
    return (
      <div className="deposit-state">
        <span className="deposit-state__icon deposit-state__icon--wait">
          <Icon name="clock" size={34} />
        </span>
        <p className="deposit-state__title">Пополнение {DEPOSIT_SECTION_OF[section]} закрыто</p>
        <p className="deposit-state__text">Админы скоро откроют его снова. А пока можно пополнить звёздами.</p>
      </div>
    );
  }
  return <DepositForm key={again ? 'again' : 'new'} initial={again} section={section} />;
}

// ---------- Form: pick → details ----------

/** One entry of the admin-managed deposit list (price = coins credited per piece) and its tab. */
type DepositOffer = Brainrot & { section?: DepositSection };

function DepositForm({ initial, section }: { initial: ItemDepositView['items'] | null; section: DepositSection }) {
  const me = useMe();
  // Which brainrots are accepted, and at what price, is decided by the admins (Админка → Пополнения → Список).
  const offers = useQuery({ queryKey: ['depositCatalog'], queryFn: () => api<DepositOffer[]>('/api/item-deposits/catalog'), staleTime: 60_000 });
  const byId = useMemo(() => new Map((offers.data ?? []).map((o) => [o.id, o])), [offers.data]);
  const [counts, setCounts] = useState<Record<string, number>>(() => Object.fromEntries((initial ?? []).map((i) => [i.brainrotId, i.count])));
  const [step, setStep] = useState<'pick' | 'details'>('pick');
  const [search, setSearch] = useState('');
  const [sort, setSort] = useState<Sort>('desc');
  const [min, setMin] = useState('');
  const [max, setMax] = useState('');
  const [nick, setNick] = useState(() => storage(NICK_KEY));
  const [promo, setPromo] = useState(() => (me.promo.bonus?.status === 'active' ? me.promo.code : ''));
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const picked = Object.entries(counts).filter(([, n]) => n > 0);
  const pieces = picked.reduce((s, [, n]) => s + n, 0);
  const lines = picked
    .map(([id, count]) => ({ b: byId.get(id)!, count }))
    .filter((l) => l.b)
    .sort((a, b) => b.b.price - a.b.price);
  const value = round2(lines.reduce((s, l) => s + l.b.price * l.count, 0));
  const typed = promo.trim().replace(/\s+/g, ' ').toLowerCase();
  const promoOk = typed !== '' && typed === me.promo.code.toLowerCase() && me.promo.bonus?.status !== 'used';
  const bonus = promoOk ? round2((value * me.promo.percent) / 100) : 0;

  const list = useMemo(() => {
    const q = search.trim().toLowerCase();
    const lo = Number(min.replace(',', '.')) || 0;
    const hi = Number(max.replace(',', '.')) || Infinity;
    const items = (offers.data ?? []).filter((b) => (b.section ?? 'brainrots') === section && (!q || b.name.toLowerCase().includes(q)) && b.price >= lo && b.price <= hi);
    return items.sort((a, b) => (sort === 'name' ? a.name.localeCompare(b.name) : sort === 'asc' ? a.price - b.price : b.price - a.price));
  }, [offers.data, search, sort, min, max, section]);
  const inTab = (offers.data ?? []).filter((b) => (b.section ?? 'brainrots') === section).length;

  function add(id: string, delta: number) {
    if (delta > 0 && pieces >= MAX_ITEMS) {
      toast(`Максимум ${MAX_ITEMS} брейнротов за одно пополнение`);
      return;
    }
    sfx.tap();
    setCounts((c) => ({ ...c, [id]: Math.max(0, (c[id] ?? 0) + delta) }));
  }

  async function submit(e: FormEvent) {
    e.preventDefault();
    if (!/^[A-Za-z0-9_]{3,20}$/.test(nick)) {
      setError('Ник в Roblox: латиница, цифры и _ (3–20 символов)');
      return;
    }
    setBusy(true);
    setError(null);
    try {
      await api('/api/item-deposits', {
        body: { items: lines.map((l) => ({ brainrotId: l.b.id, count: l.count })), robloxNick: nick, promo: typed ? promo : undefined },
      });
      storage(NICK_KEY, nick);
      sfx.coin();
      await queryClient.invalidateQueries({ queryKey: ['itemDeposit'] });
    } catch (err) {
      sfx.error();
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  }

  if (step === 'details' && lines.length) {
    return (
      <form className="form bdep" onSubmit={submit} noValidate>
        <button type="button" className="bdep__back" onClick={() => setStep('pick')}>
          <Icon name="chevronRight" size={16} className="back-link__icon" /> Изменить выбор
        </button>
        <ul className="bdep__lines">
          {lines.map(({ b, count }) => (
            <li key={b.id} className="bdep__line">
              <BrainrotThumb brainrot={b} size={46} />
              <span className="bdep__line-name">
                {b.name}
                {count > 1 && <b> ×{count}</b>}
              </span>
              <span className="bdep__line-price">
                <Coin size={14} /> {formatCoins(round2(b.price * count))}
              </span>
              <button type="button" className="bdep__remove" aria-label={`Убрать ${b.name}`} onClick={() => setCounts((c) => ({ ...c, [b.id]: 0 }))}>
                <Icon name="close" size={14} />
              </button>
            </li>
          ))}
        </ul>
        <div className="bdep__total">
          <span>Всего получишь</span>
          <strong>
            <Coin size={22} /> {formatCoins(round2(value + bonus))}
          </strong>
        </div>
        {bonus > 0 && (
          <div className="promo-note promo-note--on" role="status">
            <Icon name="check" size={18} />
            <span>
              Промокод +{me.promo.percent}% — бонус <b>{formatCoins(bonus)}</b> B
            </span>
          </div>
        )}
        <p className="bdep__warn">
          <Icon name="bolt" size={16} /> Максимум {MAX_ITEMS} брейнротов за одно пополнение.
        </p>
        <label className="field">
          <span className="field__label">Твой ник в Roblox</span>
          <span className={cx('field__control', error?.includes('Ник') && 'has-error')}>
            <input autoComplete="off" autoCapitalize="off" spellCheck={false} placeholder="Nickname" value={nick} maxLength={20} onChange={(e) => setNick(e.target.value.trim())} />
          </span>
        </label>
        <label className="field">
          <span className="field__label">
            Промокод <span className="field__optional">(необязательно)</span>
          </span>
          <span className="field__control">
            <Icon name="tag" size={18} />
            <input autoComplete="off" autoCapitalize="characters" spellCheck={false} placeholder="PROMO" value={promo} maxLength={64} onChange={(e) => setPromo(e.target.value)} />
          </span>
        </label>
        {error && (
          <p className="field__error field__error--block" role="alert">
            {error}
          </p>
        )}
        <DepositWagerNote rules={me.withdrawRules} />
        <button type="submit" className="btn btn--primary btn--lg btn--block" disabled={busy || !!me.user.frozen}>
          {busy ? 'Создаём заявку…' : 'Создать заявку'}
        </button>
      </form>
    );
  }

  return (
    <div className="bdep">
      {pieces > 0 && (
        <button type="button" className="bdep__bar" onClick={() => setStep('details')}>
          <span>
            Выбрано: <b>{pieces}</b>/{MAX_ITEMS} · <Coin size={14} /> {formatCoins(value)}
          </span>
          <span>
            Продолжить <Icon name="chevronRight" size={18} />
          </span>
        </button>
      )}
      <div className="bdep__intro">
        <p className="bdep__title">Пополнение {DEPOSIT_SECTION_OF[section]}</p>
        <p className="bdep__text">Выбери одного или сразу несколько — отдашь их одним трейдом в Roblox, стоимость зачислится монетами после приёма.</p>
      </div>
      <label className="search">
        <Icon name="sparkle" size={18} />
        <input type="search" placeholder="Поиск…" value={search} onChange={(e) => setSearch(e.target.value)} aria-label={`Поиск: ${DEPOSIT_SECTION_LABEL[section]}`} />
      </label>
      <div className="bdep__filters">
        <span className="field__control bdep__price">
          <input inputMode="decimal" placeholder="Цена от" value={min} onChange={(e) => setMin(e.target.value.replace(/[^\d.,]/g, ''))} aria-label="Цена от" />
        </span>
        <span className="field__control bdep__price">
          <input inputMode="decimal" placeholder="до" value={max} onChange={(e) => setMax(e.target.value.replace(/[^\d.,]/g, ''))} aria-label="Цена до" />
        </span>
        <button type="button" className="chip is-active bdep__sort" onClick={() => setSort((s) => (s === 'desc' ? 'asc' : s === 'asc' ? 'name' : 'desc'))}>
          {sort === 'desc' ? 'Дороже ↓' : sort === 'asc' ? 'Дешевле ↑' : 'По имени'}
        </button>
      </div>
      <div className="bdep__grid">
        {list.map((b) => {
          const n = counts[b.id] ?? 0;
          return (
            <div key={b.id} className={cx('bdep__card', `tier-${tierOf(b.price)}`, n > 0 && 'is-on')}>
              <button type="button" className="bdep__pick" onClick={() => add(b.id, 1)} aria-label={`Добавить ${b.name}`}>
                <img src={b.image} alt="" loading="lazy" decoding="async" />
                <span className="bdep__name">{b.name}</span>
                <span className="bdep__price-tag">
                  <Coin size={13} /> {formatCoins(b.price)}
                </span>
              </button>
              {n > 0 ? (
                <>
                  <span className="bdep__count">{n}</span>
                  <button type="button" className="bdep__minus" aria-label={`Убрать одного ${b.name}`} onClick={() => add(b.id, -1)}>
                    −
                  </button>
                </>
              ) : (
                <span className="bdep__ring" aria-hidden="true" />
              )}
            </div>
          );
        })}
      </div>
      {offers.isPending ? (
        <p className="hint">Загружаем список…</p>
      ) : (
        !list.length && (
          <p className="hint">
            {!inTab ? `В «${DEPOSIT_SECTION_LABEL[section]}» пока ничего нет` : 'Ничего не нашли'}
          </p>
        )
      )}
    </div>
  );
}

// ---------- Live request ----------

function DepositStatus({ dep }: { dep: ItemDepositView }) {
  const now = useNow(500);
  const [busy, setBusy] = useState(false);

  async function cancel() {
    setBusy(true);
    try {
      await api(`/api/item-deposits/${dep.id}/cancel`, { body: {} });
      await queryClient.invalidateQueries({ queryKey: ['itemDeposit'] });
      toast('Заявка отменена');
    } catch (e) {
      toast(errorMessage(e), 'error');
    } finally {
      setBusy(false);
    }
  }

  if (dep.status === 'trading' && dep.botNick) {
    const left = Math.max(0, (dep.deadline ?? 0) - now);
    const mm = String(Math.floor(left / 60000)).padStart(2, '0');
    const ss = String(Math.floor((left % 60000) / 1000)).padStart(2, '0');
    return (
      <div className="bdep-live bdep-live--trade">
        <span className="bdep-live__badge">Заявка #{dep.id} · твоя очередь</span>
        <p className="bdep-live__label">Отправь трейд на ник</p>
        <p className="bdep-live__nick">{dep.botNick}</p>
        <button
          type="button"
          className="btn btn--primary btn--block"
          onClick={() => {
            void navigator.clipboard?.writeText(dep.botNick!).then(
              () => toast('Ник скопирован', 'success'),
              () => toast(dep.botNick!),
            );
            haptic('tap');
          }}
        >
          <Icon name="copy" size={18} /> Скопировать ник
        </button>
        <p className={cx('bdep-live__timer', left < 60_000 && 'is-hot')} aria-live="polite">
          {mm}:{ss}
        </p>
        <p className="bdep-live__text">Отправь трейд в Roblox на этот ник, чтобы передать брейнротов. Как только админ примет трейд — монеты придут на баланс.</p>
        <DepositItems dep={dep} />
      </div>
    );
  }

  return (
    <div className="bdep-live">
      <span className="bdep-live__badge">Заявка #{dep.id}</span>
      <span className="bdep-live__spinner" aria-hidden="true" />
      <p className="bdep-live__title">Подбираем для вас бота…</p>
      <p className="bdep-live__text">Как только бот будет готов, здесь появится ник для трейда и таймер на 5 минут. Бот тоже напишет в Telegram — окно можно закрыть.</p>
      <DepositItems dep={dep} />
      <button type="button" className="btn btn--ghost btn--block" onClick={cancel} disabled={busy}>
        Отменить заявку
      </button>
    </div>
  );
}

function DepositItems({ dep }: { dep: ItemDepositView }) {
  return (
    <div className="bdep-live__items">
      <span>
        {dep.items.map((i) => (i.count > 1 ? `${i.name} ×${i.count}` : i.name)).join(', ')}
      </span>
      <strong>
        <Coin size={16} /> {formatCoins(dep.total)}
      </strong>
    </div>
  );
}

function DepositResult({ dep, onDone, onRetry }: { dep: ItemDepositView; onDone: () => void; onRetry: () => void }) {
  if (dep.status === 'credited') {
    return (
      <div className="deposit-state deposit-state--done">
        <span className="deposit-state__icon deposit-state__icon--done" aria-hidden="true">
          <Icon name="check" size={38} />
        </span>
        <p className="deposit-state__title">Пополнение зачислено</p>
        <p className="deposit-state__amount">
          +{formatCoins(dep.credited ?? dep.total)} <Coin size={26} />
        </p>
        <p className="deposit-state__text">Заявка #{dep.id} · брейнроты приняты</p>
        <button type="button" className="btn btn--primary btn--lg btn--block" onClick={onDone} autoFocus>
          Отлично
        </button>
      </div>
    );
  }
  const expired = dep.status === 'expired';
  return (
    <div className="deposit-state">
      <span className="deposit-state__icon deposit-state__icon--wait" aria-hidden="true">
        <Icon name={expired ? 'clock' : 'close'} size={34} />
      </span>
      <p className="deposit-state__title">{expired ? 'Время вышло' : 'Заявка отклонена'}</p>
      <p className="deposit-state__text">
        {expired ? 'Трейд не пришёл за 5 минут. Попробуй ещё раз — выбор брейнротов сохранится.' : 'Админ отклонил заявку. Если это ошибка — напиши боту /paysupport.'}
      </p>
      <button type="button" className="btn btn--primary btn--lg btn--block" onClick={expired ? onRetry : onDone}>
        {expired ? 'Попробовать ещё раз' : 'Понятно'}
      </button>
    </div>
  );
}
