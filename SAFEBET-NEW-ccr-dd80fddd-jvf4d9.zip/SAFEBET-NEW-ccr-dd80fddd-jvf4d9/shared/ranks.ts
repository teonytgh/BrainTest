/**
 * «Брейнрот-ранги»: the VIP club for big depositors, its ranks named after Steal a Brainrot's rarities. A rank comes
 * from everything the player has ever deposited (Stars + brainrot deposits, credited coins), never goes down.
 *
 * What a rank gives can't put the house in the red:
 *  - cashback: a share of the week's NET LOSS in cases and battles (3 → 8 %), so at most 8 % of what the player lost;
 *  - a one-time gift — a brainrot worth 2.4–3 % of the rank's threshold — only once the player has also played
 *    RANK_GIFT_TURNOVER × the threshold in cases and battles, where the house keeps 12 % (≈ 24 % of the threshold);
 *  (iteration 32: the owner asked for easier ranks and bigger gifts — thresholds halved or more, gifts up, turnover 3× → 2×)
 *  - the badge, and admins see the rank in the withdrawal queue (big players get their trades first).
 */
export interface Rank {
  level: number;
  name: string;
  /** Total deposits (B) from which the rank holds. */
  from: number;
  /** Weekly cashback, % of the net loss in cases and battles. */
  cashback: number;
  /** One-time gift on reaching the rank (B, paid as a brainrot + change). */
  gift: number;
  /** The brainrot on the rank's badge. */
  mascot: string;
  /** Colour key (rarity) for the badge. */
  tier: 'common' | 'rare' | 'epic' | 'legendary' | 'mythic' | 'god' | 'secret';
}

export const RANKS: readonly Rank[] = [
  { level: 0, name: 'Обычный', from: 0, cashback: 3, gift: 0, mascot: 'burguro-and-fryuro', tier: 'common' },
  { level: 1, name: 'Редкий', from: 500, cashback: 3.5, gift: 15, mascot: 'los-tacoritas', tier: 'rare' },
  { level: 2, name: 'Эпический', from: 2_500, cashback: 4, gift: 60, mascot: 'cloverat-clapat', tier: 'epic' },
  { level: 3, name: 'Легендарный', from: 10_000, cashback: 5, gift: 250, mascot: 'los-dragons', tier: 'legendary' },
  { level: 4, name: 'Мифический', from: 25_000, cashback: 6, gift: 600, mascot: 'dragon-cannelloni', tier: 'mythic' },
  { level: 5, name: 'Brainrot God', from: 75_000, cashback: 7, gift: 1_800, mascot: 'la-grande-combinasion', tier: 'god' },
  { level: 6, name: 'Секретный', from: 250_000, cashback: 8, gift: 6_000, mascot: 'la-secret-combinasion', tier: 'secret' },
];

/** A rank's gift needs this many × its threshold played in cases and battles. */
export const RANK_GIFT_TURNOVER = 2;

export function rankOf(deposited: number): Rank {
  let r = RANKS[0]!;
  for (const x of RANKS) if (deposited >= x.from) r = x;
  return r;
}

export const nextRank = (r: Rank): Rank | null => RANKS[r.level + 1] ?? null;
