import { viewerOf } from './auth';
import { one } from './db';
import { HttpError } from './errors';
import { promo } from './env';
import { activatePromo } from './games';
import { escapeHtml, type TelegramUser } from './telegram';
import { NEWS_URL, SUPPORT_URL } from '../shared/links';

/** The /start welcome: the owner's banner, his words and up to four buttons («Новости» / «Поддержка» only when set). */
export { NEWS_URL, SUPPORT_URL };
const WELCOME_PHOTO = promo('welcome.jpg');
export const CODE_BUTTON = 'code';
/** The bot recognises the player's answer by this prompt (a force-reply). */
export const CODE_PROMPT = '🎟 Введи промокод или код друга — ответом на это сообщение.';

const coins = (n: number) => n.toLocaleString('ru-RU');

const WELCOME = [
  '👋 <b>Добро пожаловать в BrainrotCrash!</b>',
  '',
  '🔥 Твоё место, где решает удача, а каждый дроп может стать легендарным!',
  '',
  '🎁 <b>Что тебя ждёт?</b>',
  '📦 Кейсы с крутыми брейнротами',
  '⚡ Апгрейдер — улучшай и повышай ценность своих брейнротов',
  '📈 Краш — рискни и попробуй забрать больше',
  '🎲 Дайсы — испытай свою удачу!',
  '',
  '🚀 Готов ворваться в игру?',
  '',
  'Жми кнопку «🎮 Играть», открывай приложение и начинай свой путь к топовым дропам!',
  '',
  '💎 <b>BrainrotCrash</b> — твоя удача, твои правила!',
].join('\n');

const links = () => {
  const row = [
    ...(NEWS_URL ? [{ text: '📢 Новости', url: NEWS_URL }] : []),
    ...(SUPPORT_URL ? [{ text: '💬 Поддержка', url: SUPPORT_URL }] : []),
  ];
  return row.length ? [row] : [];
};

/** `intro` goes on top (a friend's invite); `open` deep-links «Играть» (e.g. to the bonuses waiting there). */
export function welcome(chatId: number, origin: string, opts: { intro?: string; open?: string } = {}) {
  return {
    method: 'sendPhoto',
    chat_id: chatId,
    photo: `${origin}${WELCOME_PHOTO}`,
    caption: opts.intro ? `${opts.intro}\n\n${WELCOME}` : WELCOME,
    parse_mode: 'HTML',
    reply_markup: {
      inline_keyboard: [
        ...links(),
        [{ text: '🎮 Играть', web_app: { url: `${origin}/${opts.open ? `?open=${opts.open}` : ''}` } }],
        [{ text: '🎟 Ввести код', callback_data: CODE_BUTTON }],
      ],
    },
  };
}

export const codePrompt = (chatId: number) => ({
  method: 'sendMessage',
  chat_id: chatId,
  text: CODE_PROMPT,
  reply_markup: { force_reply: true, input_field_placeholder: 'Промокод или код друга' },
});

/** The same activation as «Бонус-код» in the app, with the same checks (ban, maintenance, freeze). */
export async function redeemFromBot(from: { id: number; first_name?: string; last_name?: string; username?: string }, code: string, origin: string) {
  const tg: TelegramUser = { id: from.id, first_name: from.first_name ?? '', last_name: from.last_name, username: from.username };
  const play = { inline_keyboard: [[{ text: '🎮 Играть', web_app: { url: `${origin}/?open=bonuses` } }]] };
  const say = (html: string) => ({ method: 'sendMessage', chat_id: from.id, parse_mode: 'HTML', text: html, reply_markup: play });
  const typed = code.trim();
  if (!typed || typed.length > 64) return say('❌ Пришли код одним сообщением — до 64 символов.');
  try {
    // Creates the player if the bot is their first stop; the profile itself is refreshed by the app.
    const v = await viewerOf(tg);
    const r = await activatePromo(v, { code: typed });
    switch (r.type) {
      case 'bonus':
        return say(`✅ Промокод активирован: <b>+${r.percent}%</b> к следующему пополнению.`);
      case 'referral':
        return say('✅ Код друга принят — вам обоим уже лежит <b>реферальный кейс</b> в «Бонусах».');
      case 'coins':
        return say(`✅ <b>+${coins(r.amount)} B</b> уже на балансе.`);
      case 'case': {
        const kase = await one<{ name: string }>('SELECT name FROM cases WHERE id = $1', [r.caseId]);
        return say(`✅ Открытие кейса «${escapeHtml(kase?.name ?? 'кейс')}»${r.amount > 1 ? ` ×${r.amount}` : ''} — уже ждёт тебя в приложении.`);
      }
      default: {
        const b = await one<{ name: string }>('SELECT name FROM brainrots WHERE id = $1', [r.brainrotId]);
        return say(`✅ <b>${escapeHtml(b?.name ?? 'Брейнрот')}</b>${r.amount > 1 ? ` ×${r.amount}` : ''} уже в инвентаре.`);
      }
    }
  } catch (e) {
    if (e instanceof HttpError) return say(`❌ ${escapeHtml(e.message)}`);
    throw e;
  }
}
