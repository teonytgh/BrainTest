import { env } from './env';
import { HttpError } from './errors';

/**
 * Anti-spam (iteration 33): a player who fires more than `limit` actions inside `windowMs` gets «Не спамь — подожди
 * секунду» (429 `too_fast`) instead of the action. Kept per Worker isolate: a burst from one app lands on the same
 * isolate, which is what this is for — row locks already keep money safe under any load. RATE_LIMIT=off switches it
 * off (the API tests fire requests back to back on purpose).
 */
const hits = new Map<string, number[]>();
let sweptAt = 0;

export const ACTION_LIMIT = { limit: 8, windowMs: 1_000 };
export const SEARCH_LIMIT = { limit: 10, windowMs: 10_000 };

export function rateLimit(key: string, { limit, windowMs }: { limit: number; windowMs: number }, now = Date.now()) {
  if (env('RATE_LIMIT') === 'off') return;
  // Now and then drop the keys nobody used for a while, so the map never grows.
  if (now - sweptAt > 60_000) {
    sweptAt = now;
    for (const [k, list] of hits) if (!list.length || now - list[list.length - 1]! > 60_000) hits.delete(k);
  }
  const recent = (hits.get(key) ?? []).filter((t) => now - t < windowMs);
  if (recent.length >= limit) {
    hits.set(key, recent);
    const wait = Math.max(1, Math.ceil((windowMs - (now - recent[0]!)) / 1000));
    throw new HttpError(429, 'too_fast', `Не спамь — подожди ${wait} сек.`, { retryIn: wait });
  }
  recent.push(now);
  hits.set(key, recent);
}
