// Renders the bot's promo photos (comeback, x2 luck, share card) to public/promo/*.jpg. The free case reminder uses
// the owner's own banner, public/promo/free-case.jpg.
// Usage: node scripts/gen_promo.mjs [name…]   (needs Playwright with Chromium; a global install is fine)
import { execSync } from 'node:child_process';
import { mkdirSync, readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const OUT = path.join(ROOT, 'public', 'promo');
const MIME = {
  '.webp': 'image/webp',
  '.svg': 'image/svg+xml',
  '.woff2': 'font/woff2',
  '.jpg': 'image/jpeg',
};
// Inlined as data URLs: a page made with setContent cannot load file:// resources.
const file = (p) => `data:${MIME[path.extname(p)]};base64,${readFileSync(path.join(ROOT, p)).toString('base64')}`;
const brainrot = (id) => file(`public/brainrots/${id}.webp`);

function loadPlaywright() {
  const require = createRequire(import.meta.url);
  try {
    return require('playwright');
  } catch {
    return require(path.join(execSync('npm root -g').toString().trim(), 'playwright'));
  }
}

const FONTS = `
@font-face { font-family: 'Unbounded'; font-weight: 200 900; src: url('${file('node_modules/@fontsource-variable/unbounded/files/unbounded-cyrillic-wght-normal.woff2')}') format('woff2'); unicode-range: U+0400-045F; }
@font-face { font-family: 'Unbounded'; font-weight: 200 900; src: url('${file('node_modules/@fontsource-variable/unbounded/files/unbounded-latin-wght-normal.woff2')}') format('woff2'); unicode-range: U+0000-00FF; }
@font-face { font-family: 'Manrope'; font-weight: 200 800; src: url('${file('node_modules/@fontsource-variable/manrope/files/manrope-cyrillic-wght-normal.woff2')}') format('woff2'); unicode-range: U+0400-045F; }
@font-face { font-family: 'Manrope'; font-weight: 200 800; src: url('${file('node_modules/@fontsource-variable/manrope/files/manrope-latin-wght-normal.woff2')}') format('woff2'); unicode-range: U+0000-00FF; }
`;

// Same palette as src/styles/tokens.css (soft red / blue / white on deep navy).
const CSS = `
${FONTS}
* { box-sizing: border-box; margin: 0; }
body { width: 1280px; height: 720px; overflow: hidden; font-family: 'Manrope', sans-serif; color: oklch(0.96 0.01 250);
  background:
    radial-gradient(60% 80% at 82% 45%, oklch(0.6 0.155 256 / 0.55), transparent 70%),
    radial-gradient(50% 70% at 8% 100%, oklch(0.61 0.18 22 / 0.45), transparent 70%),
    repeating-linear-gradient(135deg, oklch(1 0 0 / 0.025) 0 2px, transparent 2px 22px),
    oklch(0.145 0.03 258); }
.frame { position: relative; width: 100%; height: 100%; padding: 64px 72px; display: grid; grid-template-columns: 1.05fr 1fr; align-items: center; }
.frame::before { content: ''; position: absolute; inset: 0 0 auto; height: 6px;
  background: linear-gradient(90deg, transparent, oklch(0.71 0.165 20) 20%, oklch(0.985 0.006 250) 50%, oklch(0.75 0.12 248) 80%, transparent); }
.copy { display: grid; gap: 22px; align-content: center; z-index: 2; }
.kicker { display: inline-flex; width: fit-content; gap: 10px; align-items: center; padding: 10px 18px; border-radius: 999px;
  font: 800 22px/1 'Manrope'; letter-spacing: 0.06em; text-transform: uppercase; color: oklch(0.75 0.12 248);
  background: oklch(0.62 0.15 255 / 0.16); border: 2px solid oklch(0.7 0.13 252 / 0.45); }
.kicker.red { color: oklch(0.78 0.15 20); background: oklch(0.64 0.18 22 / 0.15); border-color: oklch(0.68 0.17 22 / 0.45); }
.kicker.green { color: oklch(0.82 0.17 152); background: oklch(0.72 0.17 152 / 0.14); border-color: oklch(0.72 0.17 152 / 0.45); }
h1 { font: 900 84px/0.98 'Unbounded'; letter-spacing: -0.02em; text-transform: uppercase; text-wrap: balance; }
h1.s { font-size: 66px; }
h1 em { font-style: normal; background: linear-gradient(100deg, oklch(0.78 0.15 20), oklch(0.985 0.006 250) 55%, oklch(0.78 0.12 248)); -webkit-background-clip: text; color: transparent; }
p.sub { font: 600 32px/1.3 'Manrope'; color: oklch(0.83 0.022 252); max-width: 560px; }
.cta { display: inline-flex; width: fit-content; align-items: center; gap: 12px; padding: 20px 32px; border-radius: 22px;
  font: 800 28px/1 'Manrope'; color: white; background: linear-gradient(100deg, oklch(0.6 0.155 256), oklch(0.61 0.18 22));
  box-shadow: 0 20px 50px -16px oklch(0.6 0.155 256 / 0.8); }
.brand { position: absolute; left: 72px; bottom: 44px; display: flex; gap: 14px; align-items: baseline; font: 900 30px/1 'Unbounded'; letter-spacing: 0.02em; }
.brand strong { font-weight: inherit; }
.brand b { color: oklch(0.75 0.12 248); }
.brand span { font: 700 22px/1 'Manrope'; color: oklch(0.68 0.03 254); }
.stage { position: relative; height: 100%; display: grid; place-items: center; }
.halo { position: absolute; width: 520px; height: 520px; border-radius: 50%;
  background: radial-gradient(circle, oklch(0.75 0.12 248 / 0.45), oklch(0.6 0.155 256 / 0.12) 55%, transparent 70%); }
.chest { position: relative; width: 430px; filter: drop-shadow(0 40px 60px oklch(0.09 0.02 258 / 0.8)); }
.br { position: absolute; width: 210px; height: 210px; object-fit: contain; filter: drop-shadow(0 24px 30px oklch(0.09 0.02 258 / 0.7)); }
.card { position: absolute; width: 230px; height: 290px; border-radius: 30px; display: grid; place-items: center;
  background: linear-gradient(180deg, var(--c, oklch(0.84 0.15 80 / 0.25)), oklch(0.195 0.03 258)); border: 3px solid var(--l, oklch(0.84 0.15 80 / 0.6));
  box-shadow: 0 30px 60px -20px oklch(0.09 0.02 258 / 0.9); }
.card img { width: 190px; height: 190px; object-fit: contain; }
.timer { position: absolute; top: 70px; right: 30px; padding: 14px 22px; border-radius: 20px; font: 900 44px/1 'Unbounded';
  background: oklch(0.125 0.025 258 / 0.92); border: 3px solid oklch(0.72 0.17 152 / 0.6); color: oklch(0.82 0.17 152); }
.q { position: absolute; font: 900 300px/1 'Unbounded'; color: oklch(0.75 0.12 248 / 0.18); right: 40px; top: 40px; }
.sad { filter: grayscale(0.85) brightness(0.8) drop-shadow(0 24px 30px oklch(0.09 0.02 258 / 0.7)); }
.x2 { position: absolute; font: 900 170px/1 'Unbounded'; right: 10px; bottom: 60px; color: oklch(0.82 0.17 152);
  text-shadow: 0 0 60px oklch(0.72 0.17 152 / 0.7); }
`;

const page = (body) =>
  `<!doctype html><html><head><meta charset="utf-8"><style>${CSS}</style></head><body><div class="frame">${body}<div class="brand"><strong>BRAINROT<b>CRASH</b></strong><span>@braincrashbot</span></div></div></body></html>`;

const chest = (style = '') => `<div class="halo"></div><img class="chest" style="${style}" src="${file('public/cases/free.svg')}">`;

const PROMOS = {
  comeback: page(`
    <div class="copy">
      <span class="kicker red">Мы скучаем</span>
      <h1>Ты куда <em>пропал?</em></h1>
      <p class="sub">Брейнроты без тебя грустят, а бесплатный кейс пылится</p>
      <span class="cta">Вернуться →</span>
    </div>
    <div class="stage">
      <span class="q">?</span>
      <div class="halo" style="background: radial-gradient(circle, oklch(0.62 0.18 22 / 0.35), transparent 70%)"></div>
      <img class="br sad" style="left:20px; top:120px; width:300px; height:300px" src="${brainrot('meowl')}">
      <img class="br sad" style="right:0; top:200px; width:240px; height:240px" src="${brainrot('garama-and-madundung')}">
    </div>`),
  luck: page(`
    <div class="copy">
      <span class="kicker green">Ивент</span>
      <h1>x2 <em>удача</em> включена</h1>
      <p class="sub">Шанс окупа во всех кейсах и батлах удвоен — пока горит таймер</p>
      <span class="cta">Крутить с x2 →</span>
    </div>
    <div class="stage">
      <div class="halo" style="background: radial-gradient(circle, oklch(0.72 0.17 152 / 0.5), oklch(0.72 0.17 152 / 0.1) 55%, transparent 70%)"></div>
      <img style="position:relative; width:420px; filter: drop-shadow(0 0 60px oklch(0.72 0.17 152 / 0.6))" src="${file('public/luck-clover.webp')}">
      <span class="x2">x2</span>
    </div>`),
  share: page(`
    <div class="copy">
      <span class="kicker">Брейнроты в Telegram</span>
      <h1 class="s">Бесплатный <em>кейс</em> каждый день</h1>
      <p class="sub">Кейсы, апгрейды и батлы с брейнротами</p>
      <span class="cta">Забрать кейс →</span>
    </div>
    <div class="stage">${chest('width:400px')}
      <img class="br" style="left:-20px; top:30px; transform:rotate(-10deg)" src="${brainrot('strawberry-elephant')}">
      <img class="br" style="right:-30px; top:60px; transform:rotate(12deg)" src="${brainrot('headless-horseman')}">
      <img class="br" style="left:20px; bottom:20px; width:170px" src="${brainrot('meowl')}">
    </div>`),
};

const { chromium } = loadPlaywright();
const browser = await chromium.launch({
  executablePath: process.env.CHROMIUM_PATH || undefined,
});
const page_ = await browser.newPage({ viewport: { width: 1280, height: 720 } });
mkdirSync(OUT, { recursive: true });
const only = process.argv.slice(2);
for (const [name, html] of Object.entries(PROMOS).filter(([n]) => !only.length || only.includes(n))) {
  await page_.setContent(html, { waitUntil: 'load' });
  await page_.evaluate(() => document.fonts.ready);
  await page_.screenshot({
    path: path.join(OUT, `${name}.jpg`),
    type: 'jpeg',
    quality: 86,
  });
  console.log('promo', name);
}
// Inline share results need a small thumbnail too.
if (!only.length || only.includes('share')) {
  const thumb = await browser.newPage({
    viewport: { width: 320, height: 180 },
  });
  await thumb.setContent(`<body style="margin:0"><img src="${file('public/promo/share.jpg')}" style="width:320px;height:180px;display:block"></body>`, {
    waitUntil: 'load',
  });
  await thumb.screenshot({
    path: path.join(OUT, 'share-thumb.jpg'),
    type: 'jpeg',
    quality: 80,
  });
}
await browser.close();
