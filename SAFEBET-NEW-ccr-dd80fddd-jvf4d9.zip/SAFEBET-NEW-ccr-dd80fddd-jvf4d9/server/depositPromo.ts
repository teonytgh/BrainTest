import { PARTNER_DEPOSIT_PERCENT } from '../shared/bonuses';
import { currentPromo } from '../shared/promo';
import { publicName } from './catalog';
import { db, num, one, type Queryable } from './db';
import { bad } from './errors';
import { promoKey } from './games';
import { referrerByCode } from './referrals';

export interface DepositPromo {
  code: string;
  percent: number;
  /** The auto promo's 2-hour window (its bonus is paid once per window); null for a partner code. */
  window: number | null;
  /** A partner code: the partner (the payer is bound to them, or gets bound when the invoice is made). */
  partnerId: number | null;
  partnerName: string | null;
}

/**
 * The deposit field: the 2-hour auto promo (Stars or brainrots, once per window) or a partner's code (Stars only,
 * +PARTNER_DEPOSIT_PERCENT on every deposit — the partner must be the payer's own, or the payer has none yet).
 * Null when the field is empty.
 */
export async function resolveDepositPromo(userId: number, input: unknown, via: 'stars' | 'brainrots'): Promise<DepositPromo | null> {
  const typed = typeof input === 'string' ? input.trim().slice(0, 64) : '';
  if (!typed) return null;
  const auto = currentPromo();
  if (promoKey(typed) === auto.code.toLowerCase()) {
    const use = await one<{ status: string }>('SELECT status FROM auto_promo_uses WHERE user_id = $1 AND window_index = $2', [userId, auto.windowIndex]);
    if (use?.status === 'used') throw bad('promo_used', 'Бонус этого промокода ты уже получил');
    return { code: auto.code, percent: auto.percent, window: auto.windowIndex, partnerId: null, partnerName: null };
  }
  const partnerId = await referrerByCode(db, typed);
  if (partnerId === null) throw bad('promo_invalid', via === 'stars' ? 'Такого промокода нет — проверь буквы' : 'Этот промокод не даёт бонус к пополнению');
  if (via !== 'stars') throw bad('promo_invalid', `Код партнёра даёт +${PARTNER_DEPOSIT_PERCENT}% только к пополнению звёздами`);
  if (partnerId === userId) throw bad('promo_self', 'Свой код партнёра ввести нельзя — его вводят друзья');
  const me = await one<{ referred_by: string | null; partner_code: string | null }>(
    'SELECT u.referred_by, r.ref_code AS partner_code FROM users u LEFT JOIN users r ON r.id = u.referred_by WHERE u.id = $1',
    [userId],
  );
  if (me?.referred_by && num(me.referred_by) !== partnerId) {
    throw bad('promo_other_partner', `У тебя уже есть партнёр — бонус даёт только его код${me.partner_code ? ` ${me.partner_code}` : ''}`);
  }
  const p = await one<{ ref_code: string | null; first_name: string; last_name: string | null }>('SELECT ref_code, first_name, last_name FROM users WHERE id = $1', [partnerId]);
  return { code: p?.ref_code ?? typed.toUpperCase(), percent: PARTNER_DEPOSIT_PERCENT, window: null, partnerId, partnerName: p ? publicName(p) : null };
}

/** The deposit form's live check of the typed code (nothing is bound or spent). */
export async function checkDepositPromo(userId: number, input: unknown, via: unknown) {
  const p = await resolveDepositPromo(userId, input, via === 'brainrots' ? 'brainrots' : 'stars');
  if (!p) throw bad('promo_invalid', 'Введи промокод');
  return { kind: p.partnerId ? ('partner' as const) : ('auto' as const), code: p.code, percent: p.percent, partnerName: p.partnerName };
}

/** A partner order's bonus holds while the payer is still bound to that partner (a binding is forever, so: always). */
export async function partnerStillBound(c: Queryable, userId: number, partnerId: number): Promise<boolean> {
  const { rows } = await c.query<{ ok: boolean }>('SELECT referred_by = $2 AS ok FROM users WHERE id = $1', [userId, partnerId]);
  return !!rows[0]?.ok;
}

/**
 * Claims the window's bonus when a deposit is actually credited. Several deposits may carry the same bonus
 * (made before any was credited): only the first one to claim it gets it — false means pay without the bonus.
 */
export async function spendDepositPromo(c: Queryable, userId: number, window: number, percent: number): Promise<boolean> {
  const { rows } = await c.query(
    `INSERT INTO auto_promo_uses (user_id, window_index, percent, status) VALUES ($1, $2, $3, 'used')
     ON CONFLICT (user_id, window_index) DO UPDATE SET status = 'used' WHERE auto_promo_uses.status <> 'used'
     RETURNING 1`,
    [userId, window, percent],
  );
  return rows.length > 0;
}
