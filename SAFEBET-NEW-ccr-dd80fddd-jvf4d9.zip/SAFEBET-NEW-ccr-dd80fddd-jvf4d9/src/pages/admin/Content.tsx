import type * as ConfigApi from '../../../server/caseConfigs';
import { useMemo, useState, type CSSProperties, type FormEvent } from 'react';
import { PromoAnnounce, promoAnnouncement, promoRewardText } from '../../components/PromoAnnounce';
import { BrainrotThumb } from '../../components/BrainrotCard';
import { Coin } from '../../components/Coin';
import { Ticket } from '../../components/Ticket';
import { Icon } from '../../components/Icon';
import { Sheet } from '../../components/Sheet';
import { TitleIcon } from '../../components/TitleBadge';
import { useCatalog } from '../../api/queries';
import type { BrainrotStatus } from '../../../shared/types';
import type * as FreeGateApi from '../../../server/freeGate';
import { MIN_FIXED_CHANCE, MIN_RTP, PROFIT_SHARE, solveCaseChances } from '../../../shared/cases';
import { Switch } from '../../components/Toggle';
import { cx, formatCoins, formatCountdown } from '../../lib/format';
import { BOT_USERNAME } from '../../lib/telegram';
import { useNow } from '../../lib/useNow';
import {
  BrainrotPicker,
  Card,
  ConfirmButton,
  Empty,
  Field,
  ImageInput,
  Segmented,
  UserField,
  UserLine,
  adminApi,
  formatWhen,
  notifiedText,
  useAdminAction,
  useAdminQuery,
  type AdminApi,
  type Data,
} from './ui';

/** «Окуп в кейсах» (iteration 38): the factor running now — the shown chances must be the real ones. */
function useOkupCut(): number {
  return useAdminQuery<Data<typeof AdminApi.readSettings>>(['settings'], '/settings').data?.okupCut.factor ?? 1;
}

const okupText = (f: number) => (f === 0 ? '«Без окупа»' : `×${String(f).replace('.', ',')}`);

const STATUS_LABEL: Record<Exclude<BrainrotStatus, 'deleted'>, string> = { active: 'Активен', hidden: 'Скрыт', disabled: 'Отключён' };
const STATUS_HINT: Record<Exclude<BrainrotStatus, 'deleted'>, string> = {
  active: 'Есть в апгрейдере, кейсах и выплатах.',
  hidden: 'Не виден в апгрейдере, но выпадает из кейсов.',
  disabled: 'Нигде не выпадает и не продаётся. У кого уже есть — остаётся.',
};

// ---------- Catalog ----------

type AdminBrainrot = Data<typeof AdminApi.adminBrainrots>[number];

type CatalogKind = 'brainrot' | 'coins';

export function Catalog() {
  const list = useAdminQuery<AdminBrainrot[]>(['brainrots'], '/brainrots');
  const [kind, setKind] = useState<CatalogKind>('brainrot');
  const [q, setQ] = useState('');
  const [sort, setSort] = useState<'asc' | 'desc' | 'name'>('asc');
  const [editing, setEditing] = useState<AdminBrainrot | 'new' | null>(null);

  const ofKind = useMemo(() => (list.data ?? []).filter((b) => (b.kind ?? 'brainrot') === kind), [list.data, kind]);
  const rows = useMemo(() => {
    const items = ofKind.filter((b) => !q || b.name.toLowerCase().includes(q.toLowerCase()));
    return items.sort((a, b) => (sort === 'name' ? a.name.localeCompare(b.name) : sort === 'asc' ? a.price - b.price : b.price - a.price));
  }, [ofKind, q, sort]);
  const coins = kind === 'coins';

  return (
    <Card
      title={`${coins ? 'Монеты' : 'Каталог'} · ${ofKind.length}`}
      actions={
        <button type="button" className="btn btn--primary btn--sm" onClick={() => setEditing('new')}>
          <Icon name="plus" size={16} /> {coins ? 'Монеты' : 'Создать'}
        </button>
      }
    >
      <Segmented
        label="Раздел каталога"
        value={kind}
        onChange={(k) => {
          setKind(k);
          setQ('');
        }}
        options={[
          { value: 'brainrot', label: 'Брейнроты' },
          { value: 'coins', label: 'Монеты' },
        ]}
      />
      {coins && (
        <p className="acard__text">
          Монетный приз кладётся в кейс как брейнрот — с шансом от цены или своим шансом. Выпал — сумма сразу на баланс игрока. В апгрейдер, выплаты и вывод
          монеты не попадают. Кейс с монетами автоподбор состава не трогает.
        </p>
      )}
      {coins && !list.isPending && !ofKind.length && <Empty>Монет пока нет — создай первую: например, 25 B для дешёвого кейса.</Empty>}
      <span className="ainput ainput--icon">
        <Icon name="sparkle" size={16} />
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Поиск по названию" aria-label="Поиск" />
      </span>
      <Segmented
        label="Сортировка"
        value={sort}
        onChange={setSort}
        options={[
          { value: 'asc', label: 'Цена ↑' },
          { value: 'desc', label: 'Цена ↓' },
          { value: 'name', label: 'А–Я' },
        ]}
      />
      {list.isPending && <Empty>Загружаем…</Empty>}
      <ul className="alist">
        {rows.map((b) => (
          <li key={b.id}>
            <button type="button" className={cx('alist__btn acat-row', b.status !== 'active' && 'is-dim')} onClick={() => setEditing(b)}>
              <BrainrotThumb brainrot={b} size={44} />
              <span className="acat-row__text">
                <span className="acat-row__name">{b.name}</span>
                <span className="acat-row__meta">{coins ? `в кейсах: ${b.inCases}` : `у игроков: ${b.owned} · в кейсах: ${b.inCases}`}</span>
              </span>
              <span className="acat-row__right">
                <span className="acat-row__price">
                  {formatCoins(b.price)} <Coin size={12} />
                </span>
                {b.status !== 'active' && <span className={cx('pill', b.status === 'disabled' && 'pill--red')}>{STATUS_LABEL[b.status as 'hidden']}</span>}
                {b.withdrawable && <span className="pill pill--green">в наличии</span>}
              </span>
            </button>
          </li>
        ))}
      </ul>
      <BrainrotEditor item={editing} kind={kind} onClose={() => setEditing(null)} />
    </Card>
  );
}

function BrainrotEditor({ item, kind, onClose }: { item: AdminBrainrot | 'new' | null; kind: CatalogKind; onClose: () => void }) {
  const isNew = item === 'new';
  const current = item && item !== 'new' ? item : null;
  const coins = (current?.kind ?? kind) === 'coins';
  return (
    <Sheet open={!!item} onClose={onClose} title={isNew ? (coins ? 'Новые монеты' : 'Новый брейнрот') : 'Редактировать'}>
      {item && (coins ? <CoinPrizeForm key={current?.id ?? 'new'} current={current} onDone={onClose} /> : <BrainrotForm key={current?.id ?? 'new'} current={current} onDone={onClose} />)}
    </Sheet>
  );
}

/** A coin prize: an amount (its price) that drops from cases and goes straight to the balance. */
function CoinPrizeForm({ current, onDone }: { current: AdminBrainrot | null; onDone: () => void }) {
  const [amount, setAmount] = useState(String(current?.price ?? ''));
  const [name, setName] = useState(current?.name ?? '');
  const [image, setImage] = useState<string | null>(current?.image ?? null);
  const [status, setStatus] = useState<Exclude<BrainrotStatus, 'deleted'>>((current?.status as 'active') ?? 'active');
  const save = useAdminAction(
    (body: object) => (current ? adminApi(`/brainrots/${current.id}`, 'PATCH', body) : adminApi('/brainrots', 'POST', body)),
    { success: current ? 'Сохранено — изменения уже везде' : 'Монеты созданы — добавь их в кейс', catalog: true },
  );
  const remove = useAdminAction(() => adminApi(`/brainrots/${current!.id}`, 'DELETE'), { success: 'Удалены из каталога и кейсов', catalog: true });
  const value = amount.replace(',', '.');
  const label = name.trim() || (Number(value) > 0 ? `${formatCoins(Number(value))} B` : 'Монеты');

  function submit(e: FormEvent) {
    e.preventDefault();
    const body = current ? { name: label, price: value, ...(image ? { image } : {}), status } : { kind: 'coins', name: name.trim(), price: value, image: image ?? '' };
    save.mutate(body, { onSuccess: onDone });
  }

  return (
    <form className="aform" onSubmit={submit}>
      <div className="acoin-preview">
        {image ? <img src={image} alt="" /> : <Coin size={96} />}
        <span>{label}</span>
      </div>
      <Field label="Сумма" hint="Столько монет игрок получит на баланс; это же цена приза для шансов кейса">
        <span className="ainput">
          <Coin size={18} />
          <input inputMode="decimal" value={amount} onChange={(e) => setAmount(e.target.value.replace(/[^\d.,]/g, '').slice(0, 12))} placeholder="25" aria-label="Сумма" />
        </span>
      </Field>
      <Field label="Название (необязательно)" hint="Пусто — «сумма B»">
        <span className="ainput">
          <input value={name} maxLength={60} onChange={(e) => setName(e.target.value)} placeholder={label} />
        </span>
      </Field>
      <ImageInput value={image} onChange={setImage} label="Картинка (необязательно — без неё — монета)" />
      {current && (
        <>
          <Segmented label="Статус" value={status} onChange={setStatus} options={(['active', 'hidden', 'disabled'] as const).map((s) => ({ value: s, label: STATUS_LABEL[s] }))} />
          <p className="acard__text">{status === 'disabled' ? 'Не выпадает ни из одного кейса.' : 'Выпадает из кейсов, где он стоит.'}</p>
        </>
      )}
      <button type="submit" className="btn btn--primary btn--lg btn--block" disabled={save.isPending || !(Number(value) > 0) || (!!name && name.trim().length < 2)}>
        {current ? 'Сохранить' : 'Создать'}
      </button>
      {current && (
        <ConfirmButton className="btn btn--danger btn--block" onConfirm={() => remove.mutate(undefined, { onSuccess: onDone })} confirmText="Удалить и убрать из кейсов?">
          Удалить из каталога
        </ConfirmButton>
      )}
    </form>
  );
}

function BrainrotForm({ current, onDone }: { current: AdminBrainrot | null; onDone: () => void }) {
  const [name, setName] = useState(current?.name ?? '');
  const [price, setPrice] = useState(String(current?.price ?? ''));
  const [image, setImage] = useState<string | null>(current?.image ?? null);
  const [status, setStatus] = useState<Exclude<BrainrotStatus, 'deleted'>>((current?.status as 'active') ?? 'active');
  const [withdrawable, setWithdrawable] = useState(current?.withdrawable ?? true);
  const save = useAdminAction(
    (body: object) => (current ? adminApi(`/brainrots/${current.id}`, 'PATCH', body) : adminApi('/brainrots', 'POST', body)),
    { success: (r) => (current ? `Сохранено — изменения уже везде${healedText(r)}` : 'Брейнрот создан'), catalog: true },
  );
  const remove = useAdminAction(() => adminApi(`/brainrots/${current!.id}`, 'DELETE'), { success: 'Удалён из каталога и кейсов', catalog: true });

  function submit(e: FormEvent) {
    e.preventDefault();
    const value = price.replace(',', '.');
    const body = current ? { name, price: value, image, status, withdrawable } : { name, price: value, image, withdrawable };
    save.mutate(body, { onSuccess: onDone });
  }

  return (
    <form className="aform" onSubmit={submit}>
      <ImageInput value={image} onChange={setImage} stage />
      <Field label="Название">
        <span className="ainput">
          <input value={name} maxLength={60} onChange={(e) => setName(e.target.value)} placeholder="Например, Capitano Moby" />
        </span>
      </Field>
      <Field label="Цена" hint="Каталог сортируется по цене автоматически">
        <span className="ainput">
          <Coin size={18} />
          <input inputMode="decimal" value={price} onChange={(e) => setPrice(e.target.value.replace(/[^\d.,]/g, '').slice(0, 12))} />
        </span>
      </Field>
      <div className="arow">
        <div>
          <p className="arow__title">В наличии для вывода</p>
          <p className="acard__text">
            {withdrawable ? 'Игроки выводят его в Roblox и получают его при размене.' : 'Остаётся в каталоге и кейсах; для вывода игрок разменяет его на брейнротов из наличия.'}
          </p>
        </div>
        <Switch on={withdrawable} onChange={setWithdrawable} label="В наличии для вывода" />
      </div>
      {current && (
        <>
          <Segmented label="Статус" value={status} onChange={setStatus} options={(['active', 'hidden', 'disabled'] as const).map((s) => ({ value: s, label: STATUS_LABEL[s] }))} />
          <p className="acard__text">{STATUS_HINT[status]}</p>
        </>
      )}
      <button type="submit" className="btn btn--primary btn--lg btn--block" disabled={save.isPending || !name || !price || !image}>
        {current ? 'Сохранить' : 'Создать'}
      </button>
      {current && (
        <ConfirmButton className="btn btn--danger btn--block" onConfirm={() => remove.mutate(undefined, { onSuccess: onDone })} confirmText="Удалить навсегда?">
          Удалить из каталога
        </ConfirmButton>
      )}
    </form>
  );
}

// ---------- Cases ----------

type AdminCase = Data<typeof AdminApi.adminCases>[number];

/** Server replies to catalog edits with the cases it re-composed to fit the new prices. */
function healedText(r: unknown): string {
  const healed = (r as { healed?: { name: string }[] } | undefined)?.healed ?? [];
  return healed.length ? ` · сервер добавил предметы под цену: ${healed.map((h) => h.name).join(', ')}` : '';
}

const pct = (x: number) => `${(x * 100).toFixed(x < 0.1 ? 1 : 0)}%`;

type GateData = Data<typeof FreeGateApi.adminFreeGate>;

/** Conditions of the daily free case: channel subscription and «share with a friend» before each opening. */
function FreeCaseRules() {
  const gate = useAdminQuery<GateData>(['free-gate'], '/free-gate');
  const [channel, setChannel] = useState<string | null>(null);
  const save = useAdminAction((body: object) => adminApi('/settings', 'POST', { freeGate: body }), { success: 'Условия бесплатного кейса сохранены' });
  const value = channel ?? gate.data?.channel ?? '';
  const share = gate.data?.share ?? true;
  return (
    <Card title="Бесплатный кейс: условия">
      <Field label="Канал для подписки (пусто — без подписки)">
        <span className="ainput">
          <input value={value} maxLength={40} placeholder="@channel" onChange={(e) => setChannel(e.target.value.trim())} aria-label="Канал" />
        </span>
      </Field>
      {gate.data?.channel && gate.data.botIsAdmin === false && (
        <div className="anote anote--warn" role="status">
          <p>
            Бот не видит подписчиков {gate.data.channel}: добавь @{BOT_USERNAME} админом канала (права не нужны). Пока этого нет, подписку засчитываем после перехода
            в канал.
          </p>
        </div>
      )}
      {gate.data?.botIsAdmin && <p className="acard__text">✅ Бот — админ канала, подписка проверяется при каждом открытии.</p>}
      <div className="arow">
        <div>
          <p className="arow__title">«Поделись с другом» перед каждым открытием</p>
          <p className="acard__text">Игрок отправляет в любой чат сообщение с картинкой и кнопкой «Забрать бесплатный кейс».</p>
        </div>
        <Switch on={share} onChange={(on) => save.mutate({ channel: gate.data?.channel ?? '', share: on })} label="Поделиться перед открытием" disabled={save.isPending} />
      </div>
      <button type="button" className="btn btn--primary btn--block" disabled={save.isPending || channel === null} onClick={() => save.mutate({ channel: value, share }, { onSuccess: () => setChannel(null) })}>
        Сохранить канал
      </button>
    </Card>
  );
}

type CaseConfig = Data<typeof ConfigApi.listCaseConfigs>[number];

/**
 * «Конфиги кейсов»: save everything about the cases under a name and load it back whenever («поменял шансы — не
 * зашло — вернул»). A load first saves the current state as an automatic copy (so it can be undone too); cases made
 * after the save are hidden, not deleted; brainrot prices come back only with the box ticked.
 */
function CaseConfigs() {
  const list = useAdminQuery<CaseConfig[]>(['case-configs'], '/case-configs');
  const [name, setName] = useState('');
  const [prices, setPrices] = useState(false);
  const save = useAdminAction((body: { name: string }) => adminApi('/case-configs', 'POST', body), { success: 'Конфиг сохранён' });
  const load = useAdminAction(
    (id: number) => adminApi<{ name: string; cases: number; hidden: number; skipped: number; prices: number; healed: { name: string }[] }>(`/case-configs/${id}/load`, 'POST', { prices }),
    {
      success: (r) =>
        `Загружен «${r.name}»: кейсов ${r.cases}${r.hidden ? `, скрыто новых ${r.hidden}` : ''}${r.skipped ? `, пропущено удалённых брейнротов ${r.skipped}` : ''}${r.prices ? `, цен ${r.prices}` : ''}. Прошлое состояние — в автокопии${healedText(r)}`,
      catalog: true,
    },
  );
  const remove = useAdminAction((id: number) => adminApi(`/case-configs/${id}`, 'DELETE'), { success: 'Конфиг удалён' });
  const busy = save.isPending || load.isPending || remove.isPending;
  const when = new Intl.DateTimeFormat('ru-RU', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
  return (
    <Card title="Конфиги кейсов">
      <p className="acard__text">
        Сохраняет всё про кейсы: цены, цены в тикетах, составы, ручные шансы, темы, монетные призы и цены брейнротов. Загрузить можно в
        любой момент — перед загрузкой текущее состояние само сохранится как автокопия.
      </p>
      <form
        className="aform aform--inline"
        onSubmit={(e) => {
          e.preventDefault();
          if (name.trim()) save.mutate({ name: name.trim() }, { onSuccess: () => setName('') });
        }}
      >
        <span className="ainput">
          <input value={name} maxLength={60} onChange={(e) => setName(e.target.value)} placeholder="Название, например «до x2 удачи»" aria-label="Название конфига" />
        </span>
        <button type="submit" className="btn btn--primary btn--sm" disabled={!name.trim() || busy}>
          Сохранить текущий
        </button>
      </form>
      <label className="acheck">
        <input type="checkbox" checked={prices} onChange={(e) => setPrices(e.target.checked)} />
        <span>При загрузке вернуть и цены брейнротов (меняет апгрейдер, выводы и стоимость инвентарей)</span>
      </label>
      {!list.data ? (
        <Empty>Загружаем…</Empty>
      ) : !list.data.length ? (
        <Empty>Конфигов пока нет. Сохрани текущий — и к нему всегда можно будет вернуться.</Empty>
      ) : (
        <ul className="alist alist--compact">
          {list.data.map((c) => (
            <li key={c.id} className={cx('alist__row acfg', c.auto && 'is-auto')}>
              <span className="acfg__text">
                <b>{c.name}</b>
                <small>
                  {c.auto ? 'автокопия · ' : ''}
                  {c.at ? when.format(c.at) : ''}
                  {c.author ? ` · ${c.author}` : ''} · кейсов {c.cases}, предметов {c.items}
                </small>
              </span>
              <span className="abuttons">
                <ConfirmButton className="btn btn--primary btn--sm" disabled={busy} confirmText="Загрузить?" onConfirm={() => load.mutate(c.id)}>
                  Загрузить
                </ConfirmButton>
                <ConfirmButton className="btn btn--ghost btn--sm" disabled={busy} confirmText="Удалить?" onConfirm={() => remove.mutate(c.id)}>
                  <Icon name="trash" size={16} />
                </ConfirmButton>
              </span>
            </li>
          ))}
        </ul>
      )}
    </Card>
  );
}

export function Cases() {
  const list = useAdminQuery<AdminCase[]>(['cases'], '/cases');
  const sections = useAdminQuery<SectionRow[]>(['sections'], '/sections');
  const [editing, setEditing] = useState<AdminCase | 'new' | null>(null);
  const sectionName = (id: number | null) => sections.data?.find((s) => s.id === id)?.title;
  const catalog = useCatalog();
  const cut = useOkupCut();
  return (
    <>
      <FreeCaseRules />
      <Sections />
      <CaseConfigs />
      <Card
        title={`Кейсы · ${list.data?.length ?? 0}`}
        actions={
          <button type="button" className="btn btn--primary btn--sm" onClick={() => setEditing('new')}>
            <Icon name="plus" size={16} /> Создать
          </button>
        }
      >
        <p className="acard__text">
          По умолчанию шансы считаются сами из цен каталога: средний дроп — 88% цены кейса, окуп (дроп дороже кейса) — {pct(PROFIT_SHARE)}. Любому брейнроту в
          кейсе можно задать свой шанс (от 0,0001%) или «Невозможно» — изменения сразу видят все игроки. Кейс с ручными шансами сервер сам не пересобирает.
        </p>
        {cut < 1 && (
          <div className="anote anote--warn" role="status">
            <p>
              Включён окуп {okupText(cut)} (Ивенты): во всех платных кейсах дропы дороже кейса{' '}
              {cut === 0 ? 'не выпадают совсем' : `выпадают в ${Math.round(1 / cut)} раза реже`}. Ниже — реальные шансы и дроп с учётом этого.
            </p>
          </div>
        )}
        <ul className="alist">
          {(list.data ?? []).map((c) => {
            const h = c.health;
            // A paid case shows what it really pays now (the server's weights carry «Окуп ×…»).
            const real =
              c.price > 0 && c.items.length
                ? c.items.reduce(
                    (acc, i) => {
                      const price = catalog.byId.get(i.brainrotId)?.price ?? 0;
                      return { ev: acc.ev + price * i.weight, profit: acc.profit + (price > c.price ? i.weight : 0) };
                    },
                    { ev: 0, profit: 0 },
                  )
                : null;
            return (
              <li key={c.id}>
                <button type="button" className={cx('alist__btn acat-row', c.status !== 'active' && 'is-dim')} onClick={() => setEditing(c)}>
                  <img className="acase-thumb" src={c.image} alt="" />
                  <span className="acat-row__text">
                    <span className="acat-row__name">{c.name}</span>
                    <span className="acat-row__meta">
                      {c.items.length} предм.
                      {real
                        ? ` · дроп ${pct(real.ev / c.price)} · окуп ${pct(real.profit)}`
                        : h
                          ? ` · дроп ${pct(h.rtp)}${c.kind !== 'paid' ? ' от 34 B' : ''} · окуп ${pct(h.profit)}`
                          : ''}
                      {c.mystery ? ' · мистери' : ''}
                      {c.kind === 'paid' && sectionName(c.sectionId) ? ` · ${sectionName(c.sectionId)}` : ''}
                    </span>
                  </span>
                  <span className="acat-row__right">
                    <span className="acat-row__price">{c.kind === 'free' ? 'Бесплатно' : c.kind === 'tickets' ? `${formatCoins(c.ticketPrice ?? 0)} тикетов` : c.kind === 'bonus' ? (c.bonus === 'nick' ? 'За ник' : 'Реферальный') : `${formatCoins(c.price)} B`}</span>
                    {h?.manual && <span className="pill pill--gold">ручные шансы</span>}
                    {h && !h.ok && !h.manual && <span className="pill pill--red">не сходится</span>}
                    {c.status !== 'active' && <span className="pill">Скрыт</span>}
                  </span>
                </button>
              </li>
            );
          })}
        </ul>
        <Sheet open={!!editing} onClose={() => setEditing(null)} title={editing === 'new' ? 'Новый кейс' : 'Кейс'}>
          {editing && <CaseForm key={editing === 'new' ? 'new' : editing.id} current={editing === 'new' ? null : editing} sections={sections.data ?? []} onDone={() => setEditing(null)} />}
        </Sheet>
      </Card>
    </>
  );
}

type SectionRow = Data<typeof AdminApi.adminSections>[number];

/** «Темы» of the home page: add, rename, reorder, delete (their cases move to the first theme). */
function Sections() {
  const list = useAdminQuery<SectionRow[]>(['sections'], '/sections');
  const [title, setTitle] = useState('');
  const create = useAdminAction((t: string) => adminApi('/sections', 'POST', { title: t }), { success: 'Тема добавлена', catalog: true });
  const update = useAdminAction(({ id, ...body }: { id: number; title?: string; move?: number }) => adminApi(`/sections/${id}`, 'PATCH', body), {
    success: 'Тема сохранена',
    catalog: true,
  });
  const remove = useAdminAction((id: number) => adminApi(`/sections/${id}`, 'DELETE'), { success: 'Тема удалена', catalog: true });
  const rows = list.data ?? [];
  return (
    <Card title={`Темы на главной · ${rows.length}`}>
      <p className="acard__text">Каждая тема — отдельный блок кейсов на главной. Кейс переносится в тему в его настройках.</p>
      <ul className="asections">
        {rows.map((s, i) => (
          <SectionRowEditor
            key={s.id}
            row={s}
            first={i === 0}
            last={i === rows.length - 1}
            busy={update.isPending || remove.isPending}
            onRename={(t) => update.mutate({ id: s.id, title: t })}
            onMove={(move) => update.mutate({ id: s.id, move })}
            onDelete={() => remove.mutate(s.id)}
          />
        ))}
      </ul>
      <form
        className="arow arow--form"
        onSubmit={(e) => {
          e.preventDefault();
          if (title.trim()) create.mutate(title.trim(), { onSuccess: () => setTitle('') });
        }}
      >
        <span className="ainput">
          <input value={title} maxLength={40} placeholder="Новая тема, например «Хэллоуин»" onChange={(e) => setTitle(e.target.value)} aria-label="Название новой темы" />
        </span>
        <button type="submit" className="btn btn--primary btn--sm" disabled={!title.trim() || create.isPending}>
          <Icon name="plus" size={16} /> Добавить
        </button>
      </form>
    </Card>
  );
}

function SectionRowEditor(props: {
  row: SectionRow;
  first: boolean;
  last: boolean;
  busy: boolean;
  onRename: (title: string) => void;
  onMove: (move: number) => void;
  onDelete: () => void;
}) {
  const { row, first, last, busy } = props;
  const [title, setTitle] = useState(row.title);
  return (
    <li className="asections__row">
      <span className="ainput asections__name">
        <input value={title} maxLength={40} onChange={(e) => setTitle(e.target.value)} aria-label="Название темы" />
      </span>
      <small className="asections__count">{row.cases} кейс.</small>
      {title.trim() && title !== row.title && (
        <button type="button" className="btn btn--primary btn--sm" disabled={busy} onClick={() => props.onRename(title.trim())}>
          Сохранить
        </button>
      )}
      <button type="button" className="icon-btn icon-btn--ghost" aria-label="Выше" disabled={busy || first} onClick={() => props.onMove(-1)}>
        <Icon name="chevronUp" size={16} />
      </button>
      <button type="button" className="icon-btn icon-btn--ghost" aria-label="Ниже" disabled={busy || last} onClick={() => props.onMove(1)}>
        <Icon name="chevronDown" size={16} />
      </button>
      <ConfirmButton className="icon-btn icon-btn--ghost" onConfirm={props.onDelete} confirmText={`Удалить «${row.title}»?`}>
        <Icon name="trash" size={16} />
      </ConfirmButton>
    </li>
  );
}

type EditItem = { brainrotId: string; weight: number; fixed?: number | null };
type ChanceMode = 'auto' | 'fixed' | 'never';
const modeOf = (f: number | null | undefined): ChanceMode => (f === null || f === undefined ? 'auto' : f === 0 ? 'never' : 'fixed');
/** «12,5» (percent) → 0.125; NaN when unreadable. */
const percentToChance = (s: string) => Number(s.replace(',', '.')) / 100;
const chanceToPercent = (f: number) => String(Math.round(f * 100 * 1e6) / 1e6).replace('.', ',');

/**
 * «Добавить из каталога» for a case: tap brainrots (or coin prizes) to put them in, tap again to take them out —
 * several at once, with the count on the button, then «Готово».
 */
function CaseItemsPicker({ inCase, onAdd, onRemove }: { inCase: string[]; onAdd: (id: string) => void; onRemove: (id: string) => void }) {
  const catalog = useCatalog();
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState('');
  const [kind, setKind] = useState<'brainrot' | 'coins'>('brainrot');
  const has = new Set(inCase);
  const list = catalog.brainrots
    .filter((b) => b.status !== 'deleted' && (b.kind ?? 'brainrot') === kind)
    .filter((b) => !q || b.name.toLowerCase().includes(q.toLowerCase()))
    .sort((a, b) => a.price - b.price);
  return (
    <>
      <button type="button" className="btn btn--ghost btn--block acase-add" onClick={() => setOpen(true)}>
        <Icon name="plus" size={18} /> Добавить из каталога
      </button>
      <Sheet open={open} onClose={() => setOpen(false)} title={`В кейсе: ${inCase.length}`}>
        <Segmented
          label="Что добавить"
          value={kind}
          onChange={setKind}
          options={[
            { value: 'brainrot', label: 'Брейнроты' },
            { value: 'coins', label: 'Монеты' },
          ]}
        />
        <span className="ainput ainput--icon">
          <Icon name="sparkle" size={16} />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Поиск по названию" aria-label="Поиск" />
        </span>
        <p className="acard__text">Нажимай на карточки — добавятся в кейс (с галочкой). Нажми ещё раз — уберётся.</p>
        {kind === 'coins' && !list.length && <Empty>Монетных призов нет — создай их в Каталог → «Монеты».</Empty>}
        <div className="apick-grid">
          {list.map((b) => {
            const on = has.has(b.id);
            return (
              <button
                key={b.id}
                type="button"
                aria-pressed={on}
                className={cx('apick-grid__item', on && 'is-on', b.status !== 'active' && 'is-dim')}
                onClick={() => (on ? onRemove(b.id) : onAdd(b.id))}
              >
                {on && (
                  <span className="apick-grid__check" aria-hidden="true">
                    <Icon name="check" size={12} />
                  </span>
                )}
                <BrainrotThumb brainrot={b} size={56} />
                <span className="apick-grid__name">{b.name}</span>
                <span className="apick-grid__price">{formatCoins(b.price)}</span>
              </button>
            );
          })}
        </div>
        <button type="button" className="btn btn--primary btn--lg btn--block apick-done" onClick={() => setOpen(false)}>
          Готово · в кейсе {inCase.length}
        </button>
      </Sheet>
    </>
  );
}

function CaseForm({ current, sections, onDone }: { current: AdminCase | null; sections: SectionRow[]; onDone: () => void }) {
  const catalog = useCatalog();
  const [name, setName] = useState(current?.name ?? '');
  const [price, setPrice] = useState(String(current?.price ?? ''));
  const [image, setImage] = useState<string | null>(current?.image ?? null);
  const [status, setStatus] = useState<'active' | 'hidden'>(current?.status ?? 'active');
  const [items, setItems] = useState<EditItem[]>(current?.items ?? []);
  // What the admin is typing in a «Свой %» field (kept as text so «0,000» can be typed).
  const [typed, setTyped] = useState<Record<string, string>>(() =>
    Object.fromEntries((current?.items ?? []).filter((i) => modeOf(i.fixed) === 'fixed').map((i) => [i.brainrotId, chanceToPercent(i.fixed!)])),
  );
  const [mystery, setMystery] = useState(current?.mystery ?? false);
  const [sectionId, setSectionId] = useState<number | null>(current?.sectionId ?? sections[0]?.id ?? null);
  // Ticket cases: no coin price, a price in tickets and a home theme instead.
  const tickets = current?.kind === 'tickets';
  const free = current?.kind === 'free' || current?.kind === 'bonus' || tickets;
  const [ticketPrice, setTicketPrice] = useState(String(current?.ticketPrice ?? ''));
  // «НОВЫЙ» / «РЕДИЗАЙН»: auto (the server decides), or the admin's pick.
  const [badge, setBadge] = useState<'auto' | 'none' | 'new' | 'redesign'>('auto');
  // A floating price: the prices the case moves between every 5–10 minutes (empty = a fixed price).
  const [floating, setFloating] = useState(!!current?.priceCycle);
  const [cycle, setCycle] = useState((current?.priceCycle ?? []).join(' / '));
  const cyclePrices = cycle
    .split(/[\s/;]+/)
    .map((x) => Number(x.replace(',', '.')))
    .filter((x) => Number.isFinite(x) && x > 0);
  const save = useAdminAction((body: object) => (current ? adminApi(`/cases/${current.id}`, 'PATCH', body) : adminApi('/cases', 'POST', body)), {
    success: (r) => `${current ? 'Кейс сохранён' : 'Кейс создан'}${healedText(r)}`,
    catalog: true,
  });
  const recompose = useAdminAction(() => adminApi<Data<typeof AdminApi.recomposeCase>>(`/cases/${current!.id}/recompose`, 'POST'), {
    success: (r) => `Состав пересобран: ${r.items} предм., средний дроп ${r.after}%`,
    catalog: true,
  });
  const remove = useAdminAction(() => adminApi(`/cases/${current!.id}`, 'DELETE'), { success: 'Кейс удалён', catalog: true });

  const p = Number(price.replace(',', '.')) || 0;
  // The fixed chance of each item as the admin has it now (a half-typed «Свой %» counts once it reads).
  const fixedOf = (it: EditItem): number | null => {
    const mode = modeOf(it.fixed);
    if (mode !== 'fixed') return mode === 'never' ? 0 : null;
    const v = percentToChance(typed[it.brainrotId] ?? '');
    return Number.isFinite(v) ? v : it.fixed!;
  };
  // Same rule the server uses: hand-set chances as set, the rest from current prices.
  const priced = items.map((i) => ({ ...i, price: catalog.byId.get(i.brainrotId)?.price ?? 0 })).sort((a, b) => b.price - a.price);
  const fixedNow = priced.map(fixedOf);
  const solved = solveCaseChances(
    priced.map((i) => i.price),
    fixedNow,
    free ? 0 : p,
  );
  const chances = solved.probs;
  // What the case really rolls now: «Окуп ×…» on top (a «Свой %» starts from the chance before it, as stored).
  const cut = useOkupCut();
  const real = solveCaseChances(
    priced.map((i) => i.price),
    fixedNow,
    free ? 0 : p,
    1,
    cut,
  );
  const fixedSum = fixedNow.reduce<number>((s, f) => s + (f ?? 0), 0);
  const badChance = priced.some((it, k) => {
    if (modeOf(it.fixed) !== 'fixed') return false;
    const v = percentToChance(typed[it.brainrotId] ?? '');
    return !Number.isFinite(v) || v < MIN_FIXED_CHANCE || v > 1 || fixedNow[k] === null;
  });
  // «Nothing can drop» is only possible with hand-set chances; an automatic case that doesn't fit its price yet is
  // completed by the server on save, so it must not block the button.
  const chanceError = badChance
    ? 'Свой шанс — от 0,0001% до 100%'
    : fixedSum > 1 + 1e-9
      ? 'Ручные шансы в сумме больше 100%'
      : solved.manual && !solved.ok && items.length
        ? 'Ни один предмет не может выпасть'
        : null;
  // What still keeps the button grey, said in words.
  const missing = [!image && 'картинку', !name.trim() && 'название', !free && !p && 'цену', !free && floating && cyclePrices.length < 2 && 'хотя бы 2 плавающие цены', tickets && !Number(ticketPrice) && 'цену в тикетах', items.length < 2 && `${items.length ? 'ещё 1 предмет' : 'минимум 2 предмета'}`].filter(Boolean);
  const [fresh, setFresh] = useState<string[]>([]);
  const suggested = current && p === current.price ? current.health?.suggestedPrice : null;

  function setMode(id: string, mode: ChanceMode) {
    setItems((list) =>
      list.map((x) => {
        if (x.brainrotId !== id) return x;
        if (mode === 'auto') return { ...x, fixed: null };
        if (mode === 'never') return { ...x, fixed: 0 };
        // Start from the chance it has now, so switching to «Свой %» changes nothing until edited.
        const k = priced.findIndex((it) => it.brainrotId === id);
        const start = Math.max(MIN_FIXED_CHANCE, chances[k] ?? MIN_FIXED_CHANCE);
        setTyped((t) => ({ ...t, [id]: chanceToPercent(start) }));
        return { ...x, fixed: start };
      }),
    );
  }

  function submit(e: FormEvent) {
    e.preventDefault();
    if (chanceError) return;
    const body: Record<string, unknown> = {
      name,
      image,
      items: priced.map((i, k) => ({ brainrotId: i.brainrotId, chance: fixedNow[k] })),
      status,
      mystery,
    };
    if (!free) {
      body.price = p;
      body.sectionId = sectionId;
      body.priceCycle = floating ? cyclePrices : null;
    }
    if (badge !== 'auto') body.badge = badge;
    if (tickets) {
      body.ticketPrice = Number(ticketPrice);
      body.sectionId = sectionId;
    }
    save.mutate(body, { onSuccess: onDone });
  }

  return (
    <form className="aform" onSubmit={submit}>
      <ImageInput value={image} onChange={setImage} label="Картинка кейса" />
      <Field label="Название">
        <span className="ainput">
          <input value={name} maxLength={40} onChange={(e) => setName(e.target.value)} />
        </span>
      </Field>
      {!free && (
        <Field label="Цена">
          <span className="ainput">
            <Coin size={18} />
            <input inputMode="decimal" value={price} onChange={(e) => setPrice(e.target.value.replace(/[^\d.,]/g, '').slice(0, 12))} />
          </span>
        </Field>
      )}
      {tickets && (
        <Field label="Цена в тикетах" hint="Тикеты дают за задания; монетами этот кейс не открыть">
          <span className="ainput">
            <Ticket size={18} />
            <input inputMode="numeric" value={ticketPrice} onChange={(e) => setTicketPrice(e.target.value.replace(/\D/g, '').slice(0, 6))} />
          </span>
        </Field>
      )}
      {(!free || tickets) && sections.length > 0 && (
        <Field label="Тема на главной">
          <span className="ainput">
            <select className="aselect" value={sectionId ?? ''} onChange={(e) => setSectionId(e.target.value ? Number(e.target.value) : null)} aria-label="Тема">
              {sections.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.title}
                </option>
              ))}
            </select>
          </span>
        </Field>
      )}
      {current && (
        <Segmented
          label="Статус"
          value={status}
          onChange={setStatus}
          options={[
            { value: 'active', label: 'Активен' },
            { value: 'hidden', label: 'Скрыт' },
          ]}
        />
      )}
      {!free && (
        <div className="arow">
          <div>
            <p className="arow__title">Плавающая цена</p>
            <p className="acard__text">
              Каждые 5–10 минут цена сама меняется на одну из списка (как «Биткоин»). Шансы считаются от текущей цены, сервер сам добавит предметы под
              каждую. В батлы такой кейс не ставится.
            </p>
          </div>
          <Switch on={floating} onChange={setFloating} label="Плавающая цена" />
        </div>
      )}
      {!free && floating && (
        <Field label="Цены через «/»" hint={cyclePrices.length < 2 ? 'Минимум 2 цены, например 10000 / 5000 / 799 / 99' : `${cyclePrices.length} цены: ${cyclePrices.map((x) => formatCoins(x)).join(' → ')}`}>
          <span className="ainput">
            <Coin size={18} />
            <input value={cycle} placeholder="10000 / 5000 / 799 / 99" onChange={(e) => setCycle(e.target.value.replace(/[^\d.,/ ]/g, '').slice(0, 60))} />
          </span>
        </Field>
      )}
      <Segmented
        label={current?.badge ? `Ленточка (сейчас «${current.badge === 'new' ? 'Новый' : 'Редизайн'}»)` : 'Ленточка на карточке'}
        value={badge}
        onChange={setBadge}
        options={[
          { value: 'auto', label: 'Авто' },
          { value: 'new', label: 'Новый' },
          { value: 'redesign', label: 'Редизайн' },
          { value: 'none', label: 'Нет' },
        ]}
      />
      <div className="arow">
        <div>
          <p className="arow__title">Мистери</p>
          <p className="acard__text">В прокрутке вместо брейнротов — светящиеся «?», выигрыш открывается при остановке.</p>
        </div>
        <Switch on={mystery} onChange={setMystery} label="Мистери-кейс" />
      </div>
      <div className="ametric">
        <span>
          Средний дроп: {formatCoins(Math.round(real.ev))} B{!free && p > 0 ? ` (${pct(real.rtp)} цены)` : ''}
        </span>
        {!free && p > 0 && <span className="pill pill--green">окуп {pct(real.profit)}</span>}
        {!free && p > 0 && cut < 1 && <span className="pill pill--gold">окуп {okupText(cut)} включён</span>}
        {solved.manual && <span className="pill pill--gold">ручные шансы</span>}
      </div>
      {chanceError && (
        <div className="anote anote--warn" role="alert">
          <p>{chanceError}</p>
        </div>
      )}
      {solved.manual && !free && p > 0 && real.rtp > 1 && (
        <div className="anote anote--warn" role="status">
          <p>С такими шансами кейс в минусе: в среднем выдаёт {pct(real.rtp)} своей цены. Кейс откроется как настроено — проверь, что так и задумано.</p>
        </div>
      )}
      {items.length >= 2 && (free || p > 0) && !solved.ok && !solved.manual && (
        <div className="anote anote--warn" role="status">
          {solved.rtp > 1 ? (
            <p>Кейс в минусе: почти всё в нём дороже самого кейса. После сохранения сервер сам добавит предметы подешевле.</p>
          ) : solved.rtp < MIN_RTP ? (
            <p>В каталоге нет брейнротов около этой цены — средний дроп всего {pct(solved.rtp)}. Добавь предметы чуть дешевле кейса или поменяй цену.</p>
          ) : (
            <p>Мало предметов около цены кейса — сохранить можно: сервер сам добавит недостающие из каталога. Или добавь их сам.</p>
          )}
          {suggested && (
            <button type="button" className="btn btn--ghost btn--sm" onClick={() => setPrice(String(suggested))}>
              Поставить цену {formatCoins(suggested)} B
            </button>
          )}
        </div>
      )}
      <div className="afield">
        <span className="afield__label">Предметы и шансы (игроки шансы не видят; «Невозможно» не показывается в кейсе)</span>
        <ul className="aitems">
          {priced.map((it, k) => {
            const b = catalog.byId.get(it.brainrotId);
            const mode = modeOf(it.fixed);
            return (
              <li key={it.brainrotId} className={cx('aitems__row aitems__row--chance', mode === 'never' && 'is-dim', fresh.includes(it.brainrotId) && 'is-new')}>
                {b && <BrainrotThumb brainrot={b} size={36} />}
                <span className="aitems__name">
                  {b?.name ?? it.brainrotId}
                  <small>
                    {formatCoins(it.price)} B · <b className={cx('achance__now', mode !== 'auto' && 'is-manual')}>{mode === 'never' ? 'невозможно' : formatAdminChance(real.probs[k]!)}</b>
                    {mode === 'fixed' && cut < 1 && it.price > p && p > 0 && <> · задан {formatAdminChance(chances[k]!)}</>}
                  </small>
                </span>
                <button type="button" className="icon-btn icon-btn--ghost" aria-label="Убрать" onClick={() => setItems((list) => list.filter((x) => x.brainrotId !== it.brainrotId))}>
                  <Icon name="close" size={16} />
                </button>
                <span className="achance" role="radiogroup" aria-label={`Шанс: ${b?.name ?? it.brainrotId}`}>
                  {(['auto', 'fixed', 'never'] as const).map((m) => (
                    <button key={m} type="button" role="radio" aria-checked={mode === m} className={cx('achance__mode', mode === m && 'is-on', m === 'never' && 'achance__mode--never')} onClick={() => setMode(it.brainrotId, m)}>
                      {m === 'auto' ? 'Авто' : m === 'fixed' ? 'Свой %' : 'Невозможно'}
                    </button>
                  ))}
                  {mode === 'fixed' && (
                    <span className="ainput achance__input">
                      <input
                        inputMode="decimal"
                        value={typed[it.brainrotId] ?? ''}
                        onChange={(e) => setTyped((t) => ({ ...t, [it.brainrotId]: e.target.value.replace(/[^\d.,]/g, '').slice(0, 12) }))}
                        aria-label="Шанс в процентах"
                      />
                      %
                    </span>
                  )}
                </span>
              </li>
            );
          })}
        </ul>
        <CaseItemsPicker
          inCase={items.map((i) => i.brainrotId)}
          onAdd={(id) => {
            setItems((list) => (list.some((i) => i.brainrotId === id) ? list : [...list, { brainrotId: id, weight: 1 }]));
            setFresh((list) => [...list, id]);
          }}
          onRemove={(id) => setItems((list) => list.filter((x) => x.brainrotId !== id))}
        />
      </div>
      <button type="submit" className="btn btn--primary btn--lg btn--block" disabled={save.isPending || missing.length > 0 || !!chanceError}>
        {current ? 'Сохранить кейс' : 'Создать кейс'}
      </button>
      {missing.length > 0 && <p className="acard__text acase-missing">Чтобы {current ? 'сохранить' : 'создать'} кейс, добавь: {missing.join(', ')}.</p>}
      {current && (
        <ConfirmButton
          className="btn btn--ghost btn--block"
          disabled={recompose.isPending}
          onConfirm={() => recompose.mutate(undefined, { onSuccess: onDone })}
          confirmText="Подобрать состав заново из каталога?"
        >
          <Icon name="reset" size={16} /> Пересобрать состав
        </ConfirmButton>
      )}
      {current && !free && (
        <ConfirmButton className="btn btn--danger btn--block" onConfirm={() => remove.mutate(undefined, { onSuccess: onDone })} confirmText="Удалить кейс?">
          Удалить кейс
        </ConfirmButton>
      )}
    </form>
  );
}

// ---------- Titles ----------

type TitleRow = Data<typeof AdminApi.titles>[number];
const COLORS = ['#ffc94d', '#ff5a6e', '#4d8dff', '#3ee08f', '#b26bff', '#ffffff', '#ff8a3d', '#2ee6e6'];

export function Titles() {
  const list = useAdminQuery<TitleRow[]>(['titles'], '/titles');
  const [editing, setEditing] = useState<TitleRow | 'new' | null>(null);
  return (
    <Card
      title={`Титулы · ${list.data?.length ?? 0}`}
      actions={
        <button type="button" className="btn btn--primary btn--sm" onClick={() => setEditing('new')}>
          <Icon name="plus" size={16} /> Создать
        </button>
      }
    >
      <p className="acard__text">Титул — светящаяся иконка рядом с ником. По нажатию игрок видит название, описание и когда получил.</p>
      {list.data?.length === 0 && <Empty>Титулов пока нет — создай первый.</Empty>}
      <ul className="alist">
        {(list.data ?? []).map((t) => (
          <li key={t.id}>
            <button type="button" className="alist__btn acat-row" onClick={() => setEditing(t)}>
              <TitleIcon title={t} size={44} />
              <span className="acat-row__text">
                <span className="acat-row__name">{t.name}</span>
                <span className="acat-row__meta">{t.description || 'Без описания'}</span>
              </span>
              <span className="pill">{t.holders} у игроков</span>
            </button>
          </li>
        ))}
      </ul>
      <Sheet open={!!editing} onClose={() => setEditing(null)} title={editing === 'new' ? 'Новый титул' : 'Титул'}>
        {editing && <TitleForm key={editing === 'new' ? 'new' : editing.id} current={editing === 'new' ? null : editing} onDone={() => setEditing(null)} />}
      </Sheet>
    </Card>
  );
}

function TitleForm({ current, onDone }: { current: TitleRow | null; onDone: () => void }) {
  const catalog = useCatalog();
  const [name, setName] = useState(current?.name ?? '');
  const [description, setDescription] = useState(current?.description ?? '');
  const [icon, setIcon] = useState<string | null>(current?.icon ?? null);
  const [color, setColor] = useState(current?.color ?? COLORS[0]!);
  const [user, setUser] = useState('');
  const [iconSource, setIconSource] = useState<'brainrot' | 'upload'>(current?.icon.startsWith('/api/img/') ? 'upload' : 'brainrot');
  const brainrotFromIcon = catalog.brainrots.find((b) => b.image === icon)?.id ?? null;
  const holders = useAdminQuery<Data<typeof AdminApi.titleHolders>>(['title-holders', current?.id], `/titles/${current?.id}/holders`, !!current);
  const save = useAdminAction((body: object) => (current ? adminApi(`/titles/${current.id}`, 'PATCH', body) : adminApi('/titles', 'POST', body)), {
    success: current ? 'Титул сохранён' : 'Титул создан',
  });
  const remove = useAdminAction(() => adminApi(`/titles/${current!.id}`, 'DELETE'), { success: 'Титул удалён у всех' });
  const grant = useAdminAction((body: object) => adminApi<Data<typeof AdminApi.grantTitle>>(`/titles/${current!.id}/grant`, 'POST', body), {
    success: (r) => `${r.user.display} получил титул — ${notifiedText(r.notified)}`,
  });
  const revoke = useAdminAction((userId: number) => adminApi(`/titles/${current!.id}/revoke`, 'POST', { userId }), { success: 'Титул отобран' });

  return (
    <div className="aform">
      <div className="title-preview" style={{ '--glow': color } as CSSProperties}>
        {icon ? <TitleIcon title={{ icon, color, name }} size={88} /> : <span className="title-preview__empty">Иконка</span>}
        <span className="title-preview__name">{name || 'Название'}</span>
      </div>
      <form
        className="aform"
        onSubmit={(e) => {
          e.preventDefault();
          save.mutate({ name, description, icon, color }, { onSuccess: () => !current && onDone() });
        }}
      >
        <Field label="Название">
          <span className="ainput">
            <input value={name} maxLength={40} onChange={(e) => setName(e.target.value)} placeholder="Например, Герой" />
          </span>
        </Field>
        <Field label="За что выдан">
          <span className="ainput">
            <input value={description} maxLength={240} onChange={(e) => setDescription(e.target.value)} placeholder="Описание, которое увидит игрок" />
          </span>
        </Field>
        <Segmented
          label="Иконка"
          value={iconSource}
          onChange={setIconSource}
          options={[
            { value: 'brainrot', label: 'Брейнрот' },
            { value: 'upload', label: 'Своя картинка' },
          ]}
        />
        {iconSource === 'brainrot' ? (
          <BrainrotPicker value={brainrotFromIcon} onChange={(id) => setIcon(catalog.byId.get(id)?.image ?? null)} label="Иконка из каталога" />
        ) : (
          <ImageInput value={icon} onChange={setIcon} label="Иконка" />
        )}
        <div className="afield">
          <span className="afield__label">Цвет свечения</span>
          <div className="acolors">
            {COLORS.map((c) => (
              <button key={c} type="button" className={cx('acolors__swatch', c === color && 'is-on')} style={{ background: c }} aria-label={c} aria-pressed={c === color} onClick={() => setColor(c)} />
            ))}
            <input type="color" value={color} onChange={(e) => setColor(e.target.value)} aria-label="Свой цвет" />
          </div>
        </div>
        <button type="submit" className="btn btn--primary btn--block" disabled={save.isPending || !name || !icon}>
          {current ? 'Сохранить' : 'Создать титул'}
        </button>
      </form>

      {current && (
        <>
          <form
            className="aform aform--boxed"
            onSubmit={(e) => {
              e.preventDefault();
              grant.mutate({ user });
              setUser('');
            }}
          >
            <UserField value={user} onChange={setUser} label="Выдать игроку" />
            <button type="submit" className="btn btn--primary btn--block" disabled={!user || grant.isPending}>
              Выдать титул
            </button>
          </form>
          <div className="afield">
            <span className="afield__label">У кого есть · {holders.data?.length ?? 0}</span>
            <ul className="alist alist--compact">
              {(holders.data ?? []).map((u) => (
                <li key={u.id} className="alist__row">
                  <UserLine user={u} />
                  <ConfirmButton className="btn btn--ghost btn--sm" onConfirm={() => revoke.mutate(u.id)}>
                    Отобрать
                  </ConfirmButton>
                </li>
              ))}
            </ul>
          </div>
          <ConfirmButton className="btn btn--danger btn--block" onConfirm={() => remove.mutate(undefined, { onSuccess: onDone })} confirmText="Удалить у всех?">
            Удалить титул
          </ConfirmButton>
        </>
      )}
    </div>
  );
}

// ---------- Promo codes ----------

type PromoData = Data<typeof AdminApi.promos>;

export function Promos() {
  const [made, setMade] = useState<string | null>(null);
  const now = useNow(1000);
  const catalog = useCatalog();
  const list = useAdminQuery<PromoData>(['promos'], '/promos');
  const [code, setCode] = useState('');
  const [maxUses, setMaxUses] = useState('100');
  const [rewardType, setRewardType] = useState<'coins' | 'brainrot'>('coins');
  const [amount, setAmount] = useState('100');
  const [brainrotId, setBrainrotId] = useState<string | null>(null);
  const create = useAdminAction((body: object) => adminApi('/promos', 'POST', body), { success: 'Промокод создан' });
  const remove = useAdminAction((id: number) => adminApi(`/promos/${id}`, 'DELETE'), { success: 'Промокод удалён' });
  const auto = list.data?.auto;

  function submit(e: FormEvent) {
    e.preventDefault();
    const reward = promoRewardText({ type: rewardType, amount: Number(amount), name: brainrotId ? catalog.byId.get(brainrotId)?.name : undefined });
    const text = promoAnnouncement(code.trim(), Number(maxUses), reward);
    create.mutate({ code, maxUses: Number(maxUses), rewardType, amount: Number(amount), brainrotId }, { onSuccess: () => (setCode(''), setMade(text)) });
  }

  return (
    <>
      {auto && (
        <Card title="Авто-промокод сейчас">
          <div className="aauto">
            <span className="aauto__code">{auto.code}</span>
            <span className="pill pill--green">+{auto.percent}% к депозиту</span>
            <span className="aauto__time">сменится через {formatCountdown(auto.endsAt - now)}</span>
          </div>
          <p className="acard__text">Каждые 2 часа появляется новый, старый перестаёт работать сам.</p>
        </Card>
      )}
      <Card title="Новый промокод">
        <form className="aform" onSubmit={submit}>
          <Field label="Название" hint="Можно по-русски и по-английски, с пробелами. Регистр не важен.">
            <span className="ainput">
              <input value={code} maxLength={40} onChange={(e) => setCode(e.target.value)} placeholder="Летний бонус" />
            </span>
          </Field>
          <div className="atwo">
            <Field label="Активаций">
              <span className="ainput">
                <input inputMode="numeric" value={maxUses} onChange={(e) => setMaxUses(e.target.value.replace(/\D/g, '').slice(0, 7))} />
              </span>
            </Field>
            <Field label={rewardType === 'coins' ? 'Монет' : 'Штук'}>
              <span className="ainput">
                <input inputMode="numeric" value={amount} onChange={(e) => setAmount(e.target.value.replace(/\D/g, '').slice(0, 9))} />
              </span>
            </Field>
          </div>
          <Segmented
            label="Награда"
            value={rewardType}
            onChange={(t) => {
              setRewardType(t);
              setAmount(t === 'coins' ? '100' : '1');
            }}
            options={[
              { value: 'coins', label: 'Монеты' },
              { value: 'brainrot', label: 'Брейнрот' },
            ]}
          />
          {rewardType === 'brainrot' && <BrainrotPicker value={brainrotId} onChange={setBrainrotId} />}
          <button type="submit" className="btn btn--primary btn--lg btn--block" disabled={create.isPending || code.trim().length < 2 || (rewardType === 'brainrot' && !brainrotId)}>
            Создать промокод
          </button>
        </form>
        {made && <PromoAnnounce text={made} onClose={() => setMade(null)} />}
      </Card>
      <Card title={`История промокодов · ${list.data?.codes.length ?? 0}`}>
        {list.data?.codes.length === 0 && <Empty>Промокодов пока нет.</Empty>}
        <ul className="alist">
          {(list.data?.codes ?? []).map((p) => {
            const b = p.brainrotId ? catalog.byId.get(p.brainrotId) : null;
            const done = p.uses >= p.maxUses;
            return (
              <li key={p.id} className="alist__row apromo">
                <div className="apromo__top">
                  <span className="apromo__code">{p.code}</span>
                  <span className={cx('pill', done ? '' : 'pill--green')}>{done ? 'закончился' : 'активен'}</span>
                </div>
                <p className="alist__meta">
                  {p.rewardType === 'coins' ? `${formatCoins(p.amount)} B` : `${b?.name ?? p.brainrotId}${p.amount > 1 ? ` ×${p.amount}` : ''}`} · создал {p.by ?? '—'} · {formatWhen(p.at)}
                </p>
                <div className="abar" aria-label={`Использовано ${p.uses} из ${p.maxUses}`}>
                  <span style={{ width: `${Math.min(100, (p.uses / p.maxUses) * 100)}%` }} />
                </div>
                <div className="apromo__foot">
                  <span>
                    {p.uses} / {p.maxUses} активаций
                  </span>
                  <ConfirmButton className="btn btn--ghost btn--sm" onConfirm={() => remove.mutate(p.id)}>
                    Удалить
                  </ConfirmButton>
                </div>
              </li>
            );
          })}
        </ul>
      </Card>
    </>
  );
}

function formatAdminChance(p: number): string {
  const pct = p * 100;
  if (pct <= 0) return '0%';
  if (pct >= 1) return `${pct.toFixed(2)}%`;
  if (pct >= 0.001) return `${pct.toFixed(3)}%`;
  return `${pct.toFixed(4)}%`;
}
