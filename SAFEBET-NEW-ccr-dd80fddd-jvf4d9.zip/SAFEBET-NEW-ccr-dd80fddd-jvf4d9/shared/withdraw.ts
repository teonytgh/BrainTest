/** Withdrawal rules shared by the server (enforces them) and the app (explains them before sending). */

export interface WithdrawRules {
  /** A request is fine with this much in total… */
  minValue: number;
  /** …or with at least this many brainrots. */
  minItems: number;
  /** Brainrots cheaper than this («хлам») never go out. */
  minItemPrice: number;
  /** «Отыгрыш» (iteration 36): deposits must be played through × this before a withdrawal (0 = off). */
  wagerDeposit: number;
  /** …and everything free (bonus cases, cashback, promo codes, prizes, admin gifts) × this. */
  wagerBonus: number;
}

/**
 * Defaults (the admin changes them in the panel): 100 B or 2 brainrots; cheaper than Garama And Madundung is junk;
 * deposits and bonuses played through ×2 (iteration 38, the owner's «отыгрыш до х2»; the SQL `wager_rate` has the same default).
 */
export const DEFAULT_WITHDRAW_RULES: WithdrawRules = { minValue: 100, minItems: 2, minItemPrice: 45, wagerDeposit: 2, wagerBonus: 2 };
export const MAX_WAGER_MULTIPLIER = 10;

/** The player's wagering: what is left to play and the whole of the current round. */
export interface Wager {
  left: number;
  total: number;
}

/** Why a withdrawal waits for the wagering, or null when it is played out. */
export function wagerProblem(w: Wager | null | undefined): string | null {
  if (!w || w.left <= 0) return null;
  return `Сначала отыграй ещё ${fmtMoney(w.left)} B — ставь в любых играх, каждая ставка засчитывается`;
}

/** Share of the current round already played (0…1). */
export const wagerProgress = (w: Wager) => (w.total > 0 ? Math.min(1, Math.max(0, (w.total - w.left) / w.total)) : 1);

const fmtMoney = (n: number) => n.toLocaleString('ru-RU', { minimumFractionDigits: 0, maximumFractionDigits: 2 });

export const MAX_WITHDRAW_ITEMS = 20;
/** Time the player has to send the trade once it is their turn. */
export const WITHDRAW_TRADE_MS = 5 * 60 * 1000;
/** Both sides get a heads-up this long before the scheduled time. */
export const WITHDRAW_REMIND_MS = 5 * 60 * 1000;

export type WithdrawStatus = 'pending' | 'scheduled' | 'trading' | 'expired' | 'done' | 'rejected' | 'cancelled';
export const OPEN_WITHDRAW_STATUSES: readonly WithdrawStatus[] = ['pending', 'scheduled', 'trading', 'expired'];
/** Before the first trade window the player may take the items back; after it only an admin closes the request. */
export const CANCELLABLE_WITHDRAW_STATUSES: readonly WithdrawStatus[] = ['pending', 'scheduled'];

export const WITHDRAW_STATUS_LABEL: Record<WithdrawStatus, string> = {
  pending: 'На подборе',
  scheduled: 'Назначен',
  trading: 'Трейд',
  expired: 'Время вышло',
  done: 'Выведено',
  rejected: 'Отклонён',
  cancelled: 'Отменён',
};

const fmt = (n: number) => n.toLocaleString('ru-RU', { maximumFractionDigits: 2 });

/** A demo brainrot (an admin's «для демо» gift or a demo game's win) never leaves the game. */
export const DEMO_BLOCK = 'Демо-брейнрот — выдан для демо, не выводится и не меняется';

/** Why this brainrot can't be withdrawn at all, or null. */
export function withdrawBlock(b: { price: number; withdrawable: boolean; status?: string; demo?: boolean }, rules: WithdrawRules): string | null {
  if (b.demo) return DEMO_BLOCK;
  if (b.status === 'deleted' || !b.withdrawable) return 'Этот брейнрот не выводится';
  if (b.price < rules.minItemPrice) return `Хлам дешевле ${fmt(rules.minItemPrice)} B не выводится`;
  return null;
}

/** Why this selection can't be sent, or null when it is fine. */
export function withdrawProblem(selected: readonly { name: string; price: number }[], rules: WithdrawRules): string | null {
  if (!selected.length) return 'Выбери брейнротов для вывода';
  if (selected.length > MAX_WITHDRAW_ITEMS) return `За один вывод — не больше ${MAX_WITHDRAW_ITEMS} брейнротов`;
  const total = selected.reduce((s, b) => s + b.price, 0);
  if (total >= rules.minValue || selected.length >= rules.minItems) return null;
  const example = selected.length === 1 ? ` (например, ${rules.minItems} × ${selected[0]!.name})` : '';
  return `Вывод — от ${rules.minItems} брейнротов${example} или на сумму от ${fmt(rules.minValue)} B`;
}

// ---------- Exchange («размен») into brainrots that are in stock ----------

/** In stock = the admins can hand it out: active, switched on for withdrawals and not junk. Dearest first. */
export function inStock<T extends { price: number; withdrawable: boolean; status?: string }>(catalog: readonly T[], rules: WithdrawRules): T[] {
  return catalog.filter((b) => (b.status ?? 'active') === 'active' && b.withdrawable && b.price >= rules.minItemPrice).sort((a, b) => b.price - a.price);
}

/** A brainrot that isn't in stock can be exchanged when it isn't junk. */
export const exchangeable = (b: { price: number; status?: string }, rules: WithdrawRules) => b.status !== 'deleted' && b.price >= rules.minItemPrice;

export interface ExchangeOffer {
  take: { brainrotId: string; count: number }[];
  total: number;
  change: number;
}

const cents = (x: number) => Math.round(x * 100) / 100;

function offer(value: number, take: Map<string, number>, priceOf: Map<string, number>): ExchangeOffer {
  const list = [...take].filter(([, n]) => n > 0).map(([brainrotId, count]) => ({ brainrotId, count }));
  const total = cents(list.reduce((s, t) => s + priceOf.get(t.brainrotId)! * t.count, 0));
  return { take: list, total, change: cents(value - total) };
}

/** Dearest first, as many as fit, within the piece limit. */
function greedy(value: number, stock: readonly { id: string; price: number }[], pieces: number, start = new Map<string, number>()) {
  const take = new Map(start);
  let left = value - [...take].reduce((s, [id, n]) => s + stock.find((b) => b.id === id)!.price * n, 0);
  let room = pieces - [...take.values()].reduce((a, b) => a + b, 0);
  for (const b of stock) {
    const n = Math.min(Math.floor((left + 1e-9) / b.price), room);
    if (n <= 0) continue;
    take.set(b.id, (take.get(b.id) ?? 0) + n);
    left -= n * b.price;
    room -= n;
  }
  return take;
}

/**
 * Ready-made exchange offers for brainrots worth `value`: the closest fit (least change) first, then one kind
 * each — e.g. 1000 B → «Dragon Cannelloni + 3 Garama, сдача 25», «Dragon Cannelloni, сдача 160», «20 Garama…».
 * `stock` is `inStock(...)`; the change goes to the balance.
 */
export function exchangeOffers(value: number, stock: readonly { id: string; price: number }[], pieces = MAX_WITHDRAW_ITEMS): ExchangeOffer[] {
  const fits = stock.filter((b) => b.price <= value + 1e-9);
  if (!fits.length) return [];
  const priceOf = new Map(stock.map((b) => [b.id, b.price]));
  const candidates: ExchangeOffer[] = [];
  // Closest fit: start from each kind, fill the rest greedily, keep the least change.
  for (const first of fits) candidates.push(offer(value, greedy(value, fits, pieces, new Map([[first.id, 1]])), priceOf));
  candidates.sort((a, b) => a.change - b.change || a.take.reduce((s, t) => s + t.count, 0) - b.take.reduce((s, t) => s + t.count, 0));
  const out: ExchangeOffer[] = [candidates[0]!];
  for (const b of fits) {
    const n = Math.min(Math.floor((value + 1e-9) / b.price), pieces);
    out.push(offer(value, new Map([[b.id, n]]), priceOf));
  }
  const seen = new Set<string>();
  return out.filter((o) => {
    const key = o.take.map((t) => `${t.brainrotId}×${t.count}`).join(',');
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

const MSK_OFFSET_MS = 3 * 60 * 60 * 1000;

/**
 * An admin's date in Moscow time: «19.10 18:30», «19.10.2026 18:30» or just «18:30» (today, or tomorrow if that
 * time has passed). Returns ms, or null when it can't be read or isn't within the next 30 days.
 */
export function parseMskDate(text: string, now = Date.now()): number | null {
  const m = /^\s*(?:(\d{1,2})[./](\d{1,2})(?:[./](\d{2,4}))?\s+)?(\d{1,2})[:.](\d{2})\s*$/.exec(text);
  if (!m) return null;
  const msk = new Date(now + MSK_OFFSET_MS);
  const hours = Number(m[4]);
  const minutes = Number(m[5]);
  if (hours > 23 || minutes > 59) return null;
  let year = msk.getUTCFullYear();
  let month = msk.getUTCMonth();
  let day = msk.getUTCDate();
  if (m[1]) {
    day = Number(m[1]);
    month = Number(m[2]) - 1;
    if (m[3]) year = Number(m[3].length === 2 ? `20${m[3]}` : m[3]);
    if (month < 0 || month > 11 || day < 1 || day > 31) return null;
  }
  let at = Date.UTC(year, month, day, hours, minutes) - MSK_OFFSET_MS;
  const check = new Date(at + MSK_OFFSET_MS);
  if (check.getUTCDate() !== day || check.getUTCMonth() !== month) return null;
  if (!m[1] && at < now - 60_000) at += 24 * 60 * 60 * 1000;
  // A date without a year that has already passed means next year.
  if (m[1] && !m[3] && at < now - 60_000) at = Date.UTC(year + 1, month, day, hours, minutes) - MSK_OFFSET_MS;
  if (at < now - 60_000 || at > now + 30 * 24 * 60 * 60 * 1000) return null;
  return at;
}

const mskFormat = new Intl.DateTimeFormat('ru-RU', { timeZone: 'Europe/Moscow', day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit' });

/** «19 октября, 18:30 МСК». */
export const formatMsk = (at: number) => `${mskFormat.format(at)} МСК`;
