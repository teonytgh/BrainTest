/** Brainrot deposits: one trade in Roblox, so at most this many pieces per request. */
export const MAX_DEPOSIT_ITEMS = 5;

/** Tabs of the deposit picker; admins move items between them (Админка → Пополнения → Список). */
export const DEPOSIT_SECTIONS = ['brainrots', 'gears'] as const;
export type DepositSection = (typeof DEPOSIT_SECTIONS)[number];
export const DEPOSIT_SECTION_LABEL: Record<DepositSection, string> = { brainrots: 'Брейнроты', gears: 'Гирсы' };
/** «Пополнение брейнротами / гирсами». */
export const DEPOSIT_SECTION_OF: Record<DepositSection, string> = { brainrots: 'брейнротами', gears: 'гирсами' };

/** Which tabs take new requests: admins open and close each one (Админка → Пополнения → «Приём»). */
export type DepositOpen = Record<DepositSection, boolean>;
export const DEFAULT_DEPOSIT_OPEN: DepositOpen = { brainrots: true, gears: true };
