-- Iteration 13: only brainrots the admins have in stock go out; the rest are exchanged into them.

-- The owner's in-stock list (the «Можно выводить» switch in the catalog changes it later).
UPDATE brainrots SET withdrawable = id IN ('garama-and-madundung', 'dragon-cannelloni', 'meowl', 'junk-pork', 'john-pork',
  'strawberry-elephant', 'skibidi-toilet');

-- Exchanges («размен»): what went in, what came out, the change paid to the balance.
CREATE TABLE item_exchanges (
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT NOT NULL REFERENCES users (id),
  given JSONB NOT NULL,
  taken JSONB NOT NULL,
  value NUMERIC(16, 2) NOT NULL,
  change NUMERIC(16, 2) NOT NULL CHECK (change >= 0),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX item_exchanges_user ON item_exchanges (user_id, created_at DESC);

ALTER TABLE item_exchanges ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'anon') THEN
    EXECUTE 'REVOKE ALL ON item_exchanges FROM anon, authenticated';
    EXECUTE 'REVOKE ALL ON SEQUENCE item_exchanges_id_seq FROM anon, authenticated';
  END IF;
END $$;
