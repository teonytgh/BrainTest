import { RankBadge } from '../../components/RankBadge';
import { RANKS } from '../../../shared/ranks';
import { useEffect, useState } from 'react';
import { BrainrotThumb } from '../../components/BrainrotCard';
import { Coin } from '../../components/Coin';
import { Icon } from '../../components/Icon';
import { Switch } from '../../components/Toggle';
import { EVENT_INFO, MAX_SNAP_MINUTES, SNAP_DEFAULT_EVENTS, type EventId } from '../../../shared/events';
import { useCatalog, useMe } from '../../api/queries';
import { SHOUT_COLORS, SHOUT_COLOR_LABEL, SHOUT_MAX, type ShoutColor } from '../../../shared/shout';
import { OKUP_CUTS } from '../../../shared/cases';
import { cx, formatCoins, formatCountdown } from '../../lib/format';
import { toast } from '../../store/toast';
import type * as StarsApi from '../../../server/stars';
import type * as WithdrawApi from '../../../server/withdrawals';
import type * as SkyApi from '../../../server/sky';
import type * as SquidApi from '../../../server/squid';
import type * as CryptoApi from '../../../server/crypto';
import { CRYPTO_RATE_MAX, CRYPTO_RATE_MIN, rubToCoins } from '../../../shared/crypto';
import { SKY_EGG_VALUE, SKY_MAX_CAP, SKY_MAX_MINUTES, SKY_MAX_POOL, SKY_MAX_REPEAT_HOURS } from '../../../shared/sky';
import { SQUID_LOBBY_MS, SQUID_MAX_PLACES, SQUID_STAGE, type SquidPhase, type SquidPrize, type SquidStage } from '../../../shared/squid';
import { OPEN_WITHDRAW_STATUSES, WITHDRAW_STATUS_LABEL, formatMsk } from '../../../shared/withdraw';
import { useNow } from '../../lib/useNow';
import { BrainrotPicker, Card, ConfirmButton, Empty, Field, Segmented, UserLine, adminApi, formatWhen, fromMskInput, toMskInput, useAdminAction, useAdminQuery, type AdminApi, type Data } from './ui';

// ---------- Maintenance ----------

type SettingsData = Data<typeof AdminApi.readSettings>;

export function Maintenance() {
  const settings = useAdminQuery<SettingsData>(['settings'], '/settings');
  const [enabled, setEnabled] = useState(false);
  const [message, setMessage] = useState('');
  const save = useAdminAction((body: object) => adminApi<SettingsData>('/settings', 'POST', body), { success: 'Настройки сохранены' });

  useEffect(() => {
    if (!settings.data) return;
    setEnabled(settings.data.maintenance.enabled);
    setMessage(settings.data.maintenance.message);
  }, [settings.data]);

  return (
    <>
      <Card title="Технические работы">
        <div className="arow">
          <div>
            <p className="arow__title">{enabled ? 'Включены — игроки видят заглушку' : 'Выключены'}</p>
            <p className="acard__text">Админы продолжают пользоваться приложением как обычно.</p>
          </div>
          <Switch on={enabled} onChange={setEnabled} label="Технические работы" />
        </div>
        <Field label="Текст для игроков">
          <textarea className="atextarea" rows={4} maxLength={500} value={message} placeholder="Мы на обновлении! Вернёмся через час с новыми кейсами." onChange={(e) => setMessage(e.target.value)} />
        </Field>
        <div className="amaint-preview" aria-label="Так увидят игроки">
          <Icon name="settings" size={28} />
          <strong>Мы на обновлении</strong>
          <span>{message || 'Проводим технические работы. Скоро вернёмся — с новыми фишками!'}</span>
        </div>
        <button type="button" className={enabled ? 'btn btn--danger btn--lg btn--block' : 'btn btn--primary btn--lg btn--block'} disabled={save.isPending} onClick={() => save.mutate({ maintenance: { enabled, message } })}>
          {enabled ? 'Сохранить и закрыть сайт' : 'Сохранить'}
        </button>
      </Card>
    </>
  );
}

// ---------- Telegram Stars ----------

type PaymentsData = Data<typeof StarsApi.adminPayments>;

export function Payments() {
  const settings = useAdminQuery<SettingsData>(['settings'], '/settings');
  const list = useAdminQuery<PaymentsData>(['payments'], '/payments');
  const [rate, setRate] = useState('');
  const save = useAdminAction((body: object) => adminApi<SettingsData>('/settings', 'POST', body), { success: 'Курс сохранён' });

  useEffect(() => {
    if (settings.data) setRate(String(settings.data.starRate).replace('.', ','));
  }, [settings.data]);

  const parsed = Number(rate.replace(',', '.'));
  const valid = rate !== '' && Number.isFinite(parsed) && parsed >= 0.01 && parsed <= 1000 && /^\d+([.,]\d{1,2})?$/.test(rate);
  const t = list.data?.totals;

  return (
    <>
      <Card title="Курс Telegram Stars">
        <p className="acard__text">Сколько монет B игрок получает за 1 ⭐. Бонус авто-промокода начисляется сверху.</p>
        <Field label="1 ⭐ =" hint={valid ? `100 ⭐ → ${formatCoins(Math.floor((100 * Math.round(parsed * 100)) / 100))} B` : 'Число от 0,01 до 1000, до двух знаков после запятой'}>
          <span className="ainput">
            <input inputMode="decimal" value={rate} onChange={(e) => setRate(e.target.value.replace(/[^\d.,]/g, '').slice(0, 7))} aria-label="Курс: монет за одну звезду" />
            <Coin size={18} />
          </span>
        </Field>
        <button type="button" className="btn btn--primary btn--lg btn--block" disabled={!valid || save.isPending} onClick={() => save.mutate({ starRate: parsed })}>
          Сохранить курс
        </button>
      </Card>
      <div className="atiles">
        <div className="atile">
          <span className="atile__value">{t ? formatCoins(t.stars) : '…'} ⭐</span>
          <span className="atile__label">Получено всего</span>
        </div>
        <div className="atile">
          <span className="atile__value">{t ? formatCoins(t.stars24) : '…'} ⭐</span>
          <span className="atile__label">За 24 часа</span>
        </div>
        <div className="atile">
          <span className="atile__value">{t ? formatCoins(t.count) : '…'}</span>
          <span className="atile__label">Оплат</span>
        </div>
        <div className="atile">
          <span className="atile__value">{t ? formatCoins(t.coins) : '…'}</span>
          <span className="atile__label">Монет начислено</span>
        </div>
      </div>
      <Card title="Последние оплаты">
        {list.isPending && <Empty>Загружаем…</Empty>}
        {list.data?.payments.length === 0 && <Empty>Оплат пока не было.</Empty>}
        <ul className="alog">
          {(list.data?.payments ?? []).map((p) => (
            <li key={p.chargeId}>
              <time>{formatWhen(p.at)}</time>
              <p>
                <strong>{p.user}</strong> · {formatCoins(p.stars)} ⭐ → {formatCoins(p.credited)} B{p.percent ? ` (бонус +${p.percent}%)` : ''}
              </p>
              <small>
                Счёт #{p.orderId} · ID {p.userId} · {p.chargeId.slice(0, 18)}…
              </small>
            </li>
          ))}
        </ul>
      </Card>
      <CryptoCard />
    </>
  );
}

type CryptoData = Data<typeof CryptoApi.adminCryptoPayments>;

/** Crypto deposits through @CryptoBot (iteration 38): status, the rate (owners), the webhook address, the payments. */
function CryptoCard() {
  const me = useMe();
  const settings = useAdminQuery<SettingsData>(['settings'], '/settings');
  const data = useAdminQuery<CryptoData>(['crypto'], '/crypto');
  const [rate, setRate] = useState('');
  const save = useAdminAction((body: object) => adminApi<SettingsData>('/settings', 'POST', body), { success: 'Курс крипты сохранён' });
  useEffect(() => {
    if (settings.data) setRate(String(settings.data.cryptoRate).replace('.', ','));
  }, [settings.data]);
  const parsed = Number(rate.replace(',', '.'));
  const valid = rate !== '' && Number.isFinite(parsed) && parsed >= CRYPTO_RATE_MIN && parsed <= CRYPTO_RATE_MAX && /^\d+([.,]\d{1,2})?$/.test(rate);
  const d = data.data;
  return (
    <>
      <Card title="Крипта · CryptoBot">
        <div className={cx('arow', d?.enabled && 'is-on')}>
          <div>
            <p className="arow__title">{d ? (d.enabled ? 'Подключена' : 'Не подключена') : '…'}</p>
            <p className="acard__text">
              {d?.enabled
                ? 'Игроки пополняют в рублях, платят USDT, TON, BTC и др. Монеты приходят сами: по вебхуку CryptoBot или проверкой раз в минуту.'
                : 'Нужен секрет CRYPTO_PAY_TOKEN у Worker (токен приложения из @CryptoBot → Crypto Pay → Create App).'}
            </p>
          </div>
        </div>
        {d && (
          <Field label="Вебхук для @CryptoBot (Crypto Pay → приложение → Webhooks)">
            <span className="ainput">
              <input readOnly value={d.webhook} aria-label="Адрес вебхука" onFocus={(e) => e.currentTarget.select()} />
            </span>
          </Field>
        )}
        {me.user.isOwner && (
          <>
            <Field label="1 ₽ =" hint={valid ? `100 ₽ → ${formatCoins(rubToCoins(100, parsed))} B` : `Число от ${CRYPTO_RATE_MIN} до ${CRYPTO_RATE_MAX}, до двух знаков`}>
              <span className="ainput">
                <input inputMode="decimal" value={rate} onChange={(e) => setRate(e.target.value.replace(/[^\d.,]/g, '').slice(0, 6))} aria-label="Курс: монет за рубль" />
                <Coin size={18} />
              </span>
            </Field>
            <button type="button" className="btn btn--primary btn--block" disabled={!valid || save.isPending} onClick={() => save.mutate({ cryptoRate: parsed })}>
              Сохранить курс
            </button>
          </>
        )}
      </Card>
      <div className="atiles">
        <div className="atile">
          <span className="atile__value">{d ? formatCoins(d.totals.rub) : '…'} ₽</span>
          <span className="atile__label">Криптой всего</span>
        </div>
        <div className="atile">
          <span className="atile__value">{d ? formatCoins(d.totals.rub24) : '…'} ₽</span>
          <span className="atile__label">За 24 часа</span>
        </div>
        <div className="atile">
          <span className="atile__value">{d ? formatCoins(d.totals.count) : '…'}</span>
          <span className="atile__label">Оплат</span>
        </div>
      </div>
      <Card title="Крипто-оплаты">
        {d?.payments.length === 0 && <Empty>Оплат криптой пока не было.</Empty>}
        <ul className="alog">
          {(d?.payments ?? []).map((p) => (
            <li key={p.id}>
              <time>{formatWhen(p.at)}</time>
              <p>
                <strong>{p.user}</strong> · {formatCoins(p.rub)} ₽ → {formatCoins(p.coins)} B
              </p>
              <small>
                {p.amount !== null && p.asset ? `${p.amount} ${p.asset} · ` : ''}заказ #{p.id} · ID {p.userId}
              </small>
            </li>
          ))}
        </ul>
      </Card>
    </>
  );
}

// ---------- Events: x2 luck and Halloween ----------

export function Luck() {
  const me = useMe();
  return (
    <>
      {me.user.isOwner && <OkupCutCard />}
      <ShoutCard />
      <TopDropCard />
      <ImmortalCard />
      <SquidCard />
      <SkyCard />
      <SnapCard />
      <LuckCard />
      <LookEventCard kind="fuse" />
      <LookEventCard kind="upgrade" />
      <TacosCard />
    </>
  );
}

/**
 * «Окуп в кейсах» (iteration 38, owners): for a while the drops dearer than a paid case come out ×0.75 / ×0.5 / ×0.25
 * as often — hand-set chances too; the freed chance goes to the cheaper drops.
 */
const okupLabel = (f: number) => (f >= 1 ? 'Обычный' : f === 0 ? 'Без окупа' : `×${String(f).replace('.', ',')}`);

function OkupCutCard() {
  const label = okupLabel;
  const settings = useAdminQuery<SettingsData>(['settings'], '/settings');
  const now = useNow(1000);
  const [hours, setHours] = useState('0');
  const save = useAdminAction((body: { factor: number; hours: number }) => adminApi<Data<typeof AdminApi.setOkupCut>>('/okup-cut', 'POST', body), {
    success: (r) => (r.okupCut.factor >= 1 ? 'Окуп снова обычный' : `Окуп ${label(r.okupCut.factor)} включён во всех платных кейсах`),
    catalog: true,
  });
  const cut = settings.data?.okupCut;
  if (!cut) return null;
  const on = cut.factor < 1;
  const h = Math.min(720, Math.floor(Number(hours) || 0));
  // One tap applies the choice at once: the highlighted option is always what the server runs now.
  return (
    <Card title="Окуп в кейсах">
      <div className={cx('arow', on && 'is-on')}>
        <div>
          <p className="arow__title">
            {on ? `Сейчас ${label(cut.factor)}${cut.until ? ` · ещё ${formatCountdown(Math.max(0, cut.until - now))}` : ' · пока не выключишь'}` : 'Сейчас обычный'}
          </p>
          <p className="acard__text">
            Нажми вариант — он сразу включится. Во всех платных кейсах и батлах дропы дороже кейса выпадают реже во столько раз — и с ручными шансами тоже;
            освободившийся шанс уходит дешёвым дропам. «Без окупа» — дороже кейса не выпадает ничего (такие дропы пропадают из кейса у игроков; удачу
            тогда включить нельзя). «Обычный» — выключить. Бесплатные, бонусные и тикетные кейсы не меняются.
          </p>
        </div>
      </div>
      <Field label="На сколько часов включать (0 — пока не выключишь)">
        <span className="ainput ainput--short">
          <input inputMode="numeric" aria-label="Часы" value={hours} onChange={(e) => setHours(e.target.value.replace(/\D/g, '').slice(0, 3))} />
        </span>
      </Field>
      <Segmented
        label="Множитель окупа"
        value={String(cut.factor)}
        onChange={(v) => {
          const factor = Number(v);
          if (!save.isPending) save.mutate({ factor, hours: factor < 1 ? h : 0 });
        }}
        options={OKUP_CUTS.map((f) => ({ value: String(f), label: label(f) }))}
      />
    </Card>
  );
}

/**
 * «Анонс в игре» (iteration 37, like Sammy in Steal a Brainrot): the line drops in on top of every open app with this
 * admin's photo and name and a sound. One every 20 seconds.
 */
function ShoutCard() {
  const [text, setText] = useState('');
  const [color, setColor] = useState<ShoutColor>('accent');
  const send = useAdminAction((body: object) => adminApi<unknown>('/shout', 'POST', body), { success: 'Анонс показан всем в игре', catalog: true });
  const t = text.trim();
  return (
    <Card title="Анонс в игре">
      <p className="acard__text">
        Как у Sammy в Steal a Brainrot: у всех, кто сейчас в приложении, сверху выезжает твоя аватарка, имя и текст со звуком (8 секунд). Кто зайдёт в течение 2 минут —
        тоже увидит. Не чаще раза в 20 секунд, всё пишется в журнал.
      </p>
      <Field label={`Текст · ${t.length}/${SHOUT_MAX}`}>
        <textarea className="atextarea" rows={3} maxLength={SHOUT_MAX} value={text} onChange={(e) => setText(e.target.value)} placeholder="Через 5 минут — Игра Кальмара! Заходите 🦑" />
      </Field>
      <Segmented label="Цвет" value={color} onChange={setColor} options={SHOUT_COLORS.map((c) => ({ value: c, label: SHOUT_COLOR_LABEL[c] }))} />
      <button
        type="button"
        className="btn btn--primary btn--block"
        disabled={!t || send.isPending}
        onClick={() => send.mutate({ text: t, color }, { onSuccess: () => setText('') })}
      >
        <Icon name="send" size={16} /> Показать всем
      </button>
    </Card>
  );
}

/** Immortality for trailers (iteration 37): this admin only; the next entry into Кальмар or «Небо» carries it. */
/** «Очистить топ дроп дня» (iteration 41): the home page's top drop starts over; the drops stay in the history. */
function TopDropCard() {
  const reset = useAdminAction(() => adminApi<{ ok: boolean }>('/top-drop/reset', 'POST'), { success: 'Топ дроп дня очищен', catalog: true });
  return (
    <Card title="Топ дроп дня">
      <p className="acard__text">Очищает «Топ дроп дня» на главной у всех: дальше считаются только новые дропы. История игроков не меняется.</p>
      <button
        type="button"
        className="btn btn--danger btn--block"
        disabled={reset.isPending}
        onClick={() => {
          if (confirm('Очистить «Топ дроп дня» для всех?')) reset.mutate(undefined);
        }}
      >
        <Icon name="trash" size={16} /> Очистить топ дроп дня
      </button>
    </Card>
  );
}

function ImmortalCard() {
  const me = useMe();
  const settings = useAdminQuery<SettingsData>(['settings'], '/settings');
  const toggle = useAdminAction((body: { on: boolean }) => adminApi<{ on: boolean }>('/immortal', 'POST', body), {
    success: (r) => (r.on ? 'Бессмертие включено — зайди в игру заново' : 'Бессмертие выключено'),
  });
  const on = !!settings.data?.immortal.includes(me.user.id);
  return (
    <Card title="Бессмертие для трейлеров">
      <div className={cx('arow', on && 'is-on')}>
        <div>
          <p className="arow__title">{on ? 'Ты бессмертен' : 'Выключено'}</p>
          <p className="acard__text">
            Только для тебя. В «Игре Кальмара» не выбываешь (красный свет, удары, соты, стекло), в боях «Неба Meowl» не получаешь урона. Мест и призов админам не положено. Включи
            перед входом в игру. Уйти или стоять без дела всё равно нельзя.
          </p>
        </div>
        <Switch on={on} onChange={(v) => toggle.mutate({ on: v })} label="Бессмертие" />
      </div>
    </Card>
  );
}

type SkyData = Data<typeof SkyApi.adminSky>;

const num = (v: string, min: number, max: number) => Math.max(min, Math.min(max, Math.floor(Number(v) || 0)));

/**
 * «Небо Meowl» (iteration 35): launch a flight for N minutes with a coin cap per player (deposits only by default),
 * optionally repeat it every K hours, stop it, and drop rare eggs next to everyone flying or N random players.
 */
function SkyCard() {
  const data = useAdminQuery<SkyData>(['sky'], '/sky');
  const now = useNow(1000);
  const [form, setForm] = useState<{ minutes: string; max: string; pool: string; repeatHours: string; needDeposit: boolean; notify: boolean } | null>(null);
  const [eggCount, setEggCount] = useState('3');
  const start = useAdminAction((body: object) => adminApi<unknown>('/sky/start', 'POST', body), { success: 'Небо Meowl запущено', catalog: true });
  const config = useAdminAction((body: object) => adminApi<unknown>('/sky/config', 'POST', body), { success: 'Настройки сохранены', catalog: true });
  const stop = useAdminAction(() => adminApi<unknown>('/sky/stop', 'POST'), { success: 'Полёт остановлен', catalog: true });
  const eggs = useAdminAction((body: object) => adminApi<{ spawned: number }>('/sky/eggs', 'POST', body), {
    success: (r) => `Яйца появились рядом с ${r.spawned} игрок${r.spawned === 1 ? 'ом' : 'ами'}`,
  });
  const d = data.data;
  if (!d) return null;
  const s = d.settings;
  const f = form ?? { minutes: String(s.minutes), max: String(s.max), pool: String(s.pool), repeatHours: String(s.repeatHours), needDeposit: s.needDeposit, notify: s.notify };
  const set = (patch: Partial<typeof f>) => setForm({ ...f, ...patch });
  const body = {
    minutes: num(f.minutes, 1, SKY_MAX_MINUTES),
    max: num(f.max, 1, SKY_MAX_CAP),
    pool: num(f.pool, 1, SKY_MAX_POOL),
    repeatHours: num(f.repeatHours, 0, SKY_MAX_REPEAT_HOURS),
    needDeposit: f.needDeposit,
    notify: f.notify,
  };
  const run = s.run;
  const running = !!run && run.endsAt > now;
  return (
    <Card title="Небо Meowl">
      <div className={cx('aluck', running && 'is-on')}>
        <img src="/sky/meowl-face.webp" alt="" />
        <div>
          <p className="arow__title">{running ? `Идёт · осталось ${formatCountdown(run.endsAt - now)}` : 'Не идёт'}</p>
          <p className="acard__text">
            Игроки летают на Meowl над бесконечной картой и собирают монеты по 0,5 B — по одной в разных местах, общие, кто первый. Монеты настоящие:
            полёт раздаст не больше фонда на всех, а один игрок — не больше лимита. Каждые 3 минуты — бой на мечах 30 секунд (для веселья, монеты не
            теряются). Яйцо — {SKY_EGG_VALUE} B: на карте его почти не найти, роняешь его ты.
          </p>
          {running && d.stats && (
            <p className="acard__text">
              Взлетели {d.stats.players} · сейчас в небе {d.stats.online ?? '—'} · выдано монетами {formatCoins(d.stats.coins)} B
              {d.stats.pool !== null ? ` из фонда ${formatCoins(d.stats.pool)} B` : ''}, яйцами {formatCoins(d.stats.eggs)} B
            </p>
          )}
        </div>
      </div>
      <div className="agrid2">
        <Field label="Длительность, мин">
          <span className="ainput">
            <input inputMode="numeric" value={f.minutes} onChange={(e) => set({ minutes: e.target.value.replace(/\D/g, '').slice(0, 3) })} />
          </span>
        </Field>
        <Field label="Лимит на игрока, B">
          <span className="ainput">
            <Coin size={18} />
            <input inputMode="numeric" value={f.max} onChange={(e) => set({ max: e.target.value.replace(/\D/g, '').slice(0, 3) })} />
          </span>
        </Field>
      </div>
      <Field label="Фонд на всех за полёт, B" hint="Сколько монет полёт раздаст всем игрокам вместе. Кончился — монеты больше не платят (яйца — сверху).">
        <span className="ainput">
          <Coin size={18} />
          <input inputMode="numeric" value={f.pool} onChange={(e) => set({ pool: e.target.value.replace(/\D/g, '').slice(0, 6) })} />
        </span>
      </Field>
      <Field label="Автоповтор: каждые N часов (0 — выключен)" hint={body.repeatHours ? `Новый полёт сам начнётся через ${body.repeatHours} ч после начала прошлого` : undefined}>
        <span className="ainput">
          <input inputMode="numeric" value={f.repeatHours} onChange={(e) => set({ repeatHours: e.target.value.replace(/\D/g, '').slice(0, 2) })} />
        </span>
      </Field>
      <div className="arow">
        <div>
          <p className="arow__title">Только с пополнением</p>
          <p className="acard__text">Мультиаккаунты без депозита не фармят монеты. Админы летают всегда (для проверки).</p>
        </div>
        <Switch on={f.needDeposit} onChange={(v) => set({ needDeposit: v })} label="Только с пополнением" />
      </div>
      <div className="arow">
        <div>
          <p className="arow__title">Сообщить всем в боте</p>
          <p className="acard__text">Рассылка «Небо Meowl открыто» с кнопкой «Взлететь» при запуске.</p>
        </div>
        <Switch on={f.notify} onChange={(v) => set({ notify: v })} label="Сообщить в боте" />
      </div>
      <div className="abuttons">
        <button type="button" className="btn btn--primary" disabled={start.isPending} onClick={() => start.mutate(body, { onSuccess: () => setForm(null) })}>
          {running ? 'Перезапустить' : 'Запустить'} на {body.minutes} мин
        </button>
        <button type="button" className="btn btn--ghost" disabled={config.isPending} onClick={() => config.mutate(body, { onSuccess: () => setForm(null) })}>
          Сохранить настройки
        </button>
        {running && (
          <ConfirmButton className="btn btn--danger" disabled={stop.isPending} onConfirm={() => stop.mutate(undefined)}>
            Остановить
          </ConfirmButton>
        )}
      </div>
      {running && (
        <div className="asky-eggs">
          <p className="arow__title">🥚 Заспавнить редкое яйцо</p>
          <p className="acard__text">Яйцо появится рядом с игроком, у всех в небе всплывёт «{'{'}твоё имя{'}'} заспавнил редкое яйцо — успей подобрать!» со звуком.</p>
          <div className="abuttons">
            <button type="button" className="btn btn--primary" disabled={eggs.isPending} onClick={() => eggs.mutate({ mode: 'all' })}>
              Всем в небе
            </button>
            <span className="ainput asky-eggs__count">
              <input inputMode="numeric" value={eggCount} onChange={(e) => setEggCount(e.target.value.replace(/\D/g, '').slice(0, 3))} aria-label="Сколько игроков" />
            </span>
            <button type="button" className="btn btn--ghost" disabled={eggs.isPending} onClick={() => eggs.mutate({ mode: 'random', count: num(eggCount, 1, 100) })}>
              {num(eggCount, 1, 100)} случайным
            </button>
          </div>
        </div>
      )}
    </Card>
  );
}

type SquidData = Data<typeof SquidApi.adminSquid>;
type PrizeDraft = { type: 'brainrot'; id: string | null } | { type: 'coins'; amount: string };

const SQUID_STATUS: Record<string, string> = { live: 'идёт', done: 'сыграна', cancelled: 'отменена', abandoned: 'брошена (все вышли)' };
const squidPhase = (phase: string) =>
  phase === 'lobby' ? 'вход открыт' : phase === 'break' ? 'перерыв' : phase === 'done' ? 'финиш, выдаём призы' : (SQUID_STAGE[phase as SquidStage]?.name ?? phase);

/**
 * «Игра Кальмара» (iteration 35): prizes for the first places (a brainrot or coins each), who may play, and the start —
 * every open app gets the invite at once, the bot tells everyone; 2 minutes to get in, then the four stages.
 */
function SquidCard() {
  const data = useAdminQuery<SquidData>(['squid'], '/squid');
  const catalog = useCatalog();
  const now = useNow(1000);
  const [prizes, setPrizes] = useState<PrizeDraft[]>([
    { type: 'brainrot', id: null },
    { type: 'coins', amount: '100' },
    { type: 'coins', amount: '50' },
  ]);
  const [needDeposit, setNeedDeposit] = useState(true);
  const [notify, setNotify] = useState(true);
  const start = useAdminAction((body: object) => adminApi<unknown>('/squid/start', 'POST', body), { success: 'Игра Кальмара запущена — всем ушло приглашение', catalog: true });
  const cancel = useAdminAction(() => adminApi<unknown>('/squid/cancel', 'POST'), { success: 'Игра отменена', catalog: true });
  // While a game runs, its phase is read again every few seconds.
  useEffect(() => {
    if (!data.data?.game) return;
    const t = setInterval(() => void data.refetch(), 5000);
    return () => clearInterval(t);
  }, [data]);
  const d = data.data;
  if (!d) return null;
  const game = d.game;
  const places = (n: number) =>
    setPrizes((list) => (n <= list.length ? list.slice(0, n) : [...list, ...Array.from({ length: n - list.length }, () => ({ type: 'coins' as const, amount: '25' }))]));
  const setPrize = (i: number, p: PrizeDraft) => setPrizes((list) => list.map((x, k) => (k === i ? p : x)));
  const body: SquidPrize[] = prizes.map((p) => (p.type === 'brainrot' ? { type: 'brainrot', brainrotId: p.id ?? '' } : { type: 'coins', amount: num(p.amount, 1, 1_000_000) }));
  const pool = body.reduce((sum, p) => sum + (p.type === 'coins' ? p.amount : (catalog.byId.get(p.brainrotId)?.price ?? 0)), 0);
  const problem = prizes.some((p) => p.type === 'brainrot' && !p.id) ? 'Выбери брейнрота-приз' : null;
  return (
    <Card title="Игра Кальмара">
      <div className={cx('aluck', game && 'is-on')}>
        <img src="/squid/watcher-red.webp" alt="" />
        <div>
          <p className="arow__title">
            {game
              ? game.lobbyUntil > now
                ? `Вход открыт · ещё ${formatCountdown(game.lobbyUntil - now)}`
                : `Идёт · ${d.room ? squidPhase(d.room.phase as SquidPhase) : '…'}`
              : 'Не идёт'}
          </p>
          <p className="acard__text">
            4 испытания на выбывание: «Тихо едешь», «Кровавая ночь», соты, стеклянный мост. Кто перешёл мост — занял место по порядку.
            Админы играют, но мест не занимают: приз уходит следующему игроку.
          </p>
          {game && d.room && (
            <p className="acard__text">
              Играют {d.room.players} · осталось в игре {d.room.alive}
            </p>
          )}
        </div>
      </div>
      {game ? (
        <>
          <ul className="asquid-prizes">
            {game.prizes.map((p, i) => {
              const b = p.type === 'brainrot' ? catalog.byId.get(p.brainrotId) : null;
              return (
                <li key={i}>
                  <span>{i + 1}</span>
                  {b ? <BrainrotThumb brainrot={b} size={26} /> : <Coin size={20} />}
                  <b>{b ? b.name : `${formatCoins(p.type === 'coins' ? p.amount : 0)} B`}</b>
                </li>
              );
            })}
          </ul>
          <ConfirmButton className="btn btn--danger" disabled={cancel.isPending} onConfirm={() => cancel.mutate(undefined)} confirmText="Отменить игру без призов?">
            Отменить игру
          </ConfirmButton>
        </>
      ) : (
        <>
          <Field label="Призовых мест">
            <span className="agw-places">
              {Array.from({ length: SQUID_MAX_PLACES }, (_, i) => i + 1).map((n) => (
                <button key={n} type="button" className={cx('chip chip--sm', prizes.length === n && 'is-active')} onClick={() => places(n)} aria-pressed={prizes.length === n}>
                  {n}
                </button>
              ))}
            </span>
          </Field>
          <div className="asquid-form">
            {prizes.map((p, i) => (
              <div key={i} className="asquid-row">
                <span className="asquid-row__place">{i + 1}</span>
                <Segmented
                  label={`Приз за ${i + 1} место`}
                  value={p.type}
                  onChange={(t) => setPrize(i, t === 'brainrot' ? { type: 'brainrot', id: null } : { type: 'coins', amount: '50' })}
                  options={[
                    { value: 'brainrot', label: 'Брейнрот' },
                    { value: 'coins', label: 'Монеты' },
                  ]}
                />
                {p.type === 'brainrot' ? (
                  <BrainrotPicker label={`${i + 1} место`} value={p.id} includeHidden={false} onChange={(id) => setPrize(i, { type: 'brainrot', id })} />
                ) : (
                  <span className="ainput">
                    <Coin size={18} />
                    <input
                      inputMode="numeric"
                      aria-label={`Монеты за ${i + 1} место`}
                      value={p.amount}
                      onChange={(e) => setPrize(i, { type: 'coins', amount: e.target.value.replace(/\D/g, '').slice(0, 7) })}
                    />
                  </span>
                )}
              </div>
            ))}
          </div>
          <p className="agw-pool">
            Призовой фонд{' '}
            <span className="agw-pool__sum">
              <Coin size={13} /> <b>{formatCoins(pool)}</b>
            </span>{' '}
            — призы уходят сами, как только игра закончится.
          </p>
          <div className="arow">
            <div>
              <p className="arow__title">Только с пополнением</p>
              <p className="acard__text">Играют игроки, у которых было хоть одно пополнение (мультиаккаунты не забирают призы). Смотреть могут все.</p>
            </div>
            <Switch on={needDeposit} onChange={setNeedDeposit} label="Только с пополнением" />
          </div>
          <div className="arow">
            <div>
              <p className="arow__title">Сообщить всем в боте</p>
              <p className="acard__text">Кроме приглашения в приложении — рассылка с кнопкой «Участвовать» (до 40 сообщений в минуту, пока открыт вход).</p>
            </div>
            <Switch on={notify} onChange={setNotify} label="Сообщить в боте" />
          </div>
          <button type="button" className="btn btn--primary btn--block" disabled={!!problem || start.isPending} onClick={() => start.mutate({ prizes: body, needDeposit, notify })}>
            {problem ?? `Запустить игру — вход ${SQUID_LOBBY_MS / 60_000} мин`}
          </button>
        </>
      )}
      {d.last.length > 0 && (
        <ul className="asquid-last">
          {d.last.map((g) => (
            <li key={g.id}>
              <span>#{g.id}</span>
              <span>{formatWhen(g.at)}</span>
              <span>{SQUID_STATUS[g.status] ?? g.status}</span>
              <span>
                {g.players} игр. · {g.places} прошли
              </span>
            </li>
          ))}
        </ul>
      )}
    </Card>
  );
}

/** Every event the snap can switch on; x4 / x8 luck only when picked (the default is x2, SNAP_DEFAULT_EVENTS). */
const SNAP_EVENTS: EventId[] = ['cases', 'luck4', 'luck8', 'fuse', 'upgrade', 'tacos'];

/** «Щелчок»: every chosen event at once for N minutes, with the cutscene in every open app. */
function SnapCard() {
  const settings = useAdminQuery<SettingsData>(['settings'], '/settings');
  const now = useNow(1000);
  const [minutes, setMinutes] = useState('5');
  const [events, setEvents] = useState<EventId[]>([...SNAP_DEFAULT_EVENTS]);
  const save = useAdminAction((body: { minutes: number; events: EventId[] }) => adminApi<SettingsData>('/settings', 'POST', { snap: body }), {
    success: 'Щелчок! У всех открытых приложений пошла катсцена',
    catalog: true,
  });
  const snap = settings.data?.snap ?? null;
  const left = snap ? Math.max(0, snap.endsAt - now) : 0;
  const n = Number(minutes) || 0;
  const toggle = (id: EventId) => setEvents((list) => (list.includes(id) ? list.filter((e) => e !== id) : [...list, id]));
  return (
    <Card title="Щелчок">
      <div className={cx('aluck asnap', left > 0 && 'is-on')}>
        <img src="/brainrots/sammyni-fatini.webp" alt="" />
        <div>
          <p className="arow__title">{left > 0 ? `Идёт · осталось ${formatCountdown(left)}` : 'Все ивенты одним щелчком'}</p>
          <p className="acard__text">
            У всех, у кого открыто приложение (и кто откроет его в ближайшие 10 минут), один раз проиграется 10-секундная катсцена: Sammyni Fatini с красной
            аурой идёт по красной дорожке и щёлкает пальцами — и выбранные ивенты включаются до одного времени. Ивент, который уже идёт дольше, не
            укорачивается.
          </p>
        </div>
      </div>
      <div className="asnap__events" role="group" aria-label="Какие ивенты включить">
        {SNAP_EVENTS.map((id) => (
          <button key={id} type="button" className={cx('asnap__event', events.includes(id) && 'is-on')} onClick={() => toggle(id)} aria-pressed={events.includes(id)}>
            <img src={EVENT_INFO[id].icon} alt="" />
            <span>{EVENT_INFO[id].name}</span>
            <Icon name={events.includes(id) ? 'check' : 'plus'} size={14} />
          </button>
        ))}
      </div>
      <Field label="На сколько минут">
        <span className="ainput ainput--short">
          <input inputMode="numeric" value={minutes} onChange={(e) => setMinutes(e.target.value.replace(/\D/g, '').slice(0, 3))} aria-label="Минут" />
        </span>
      </Field>
      <div className="achips">
        {[5, 15, 30, 60].map((m) => (
          <button key={m} type="button" className={cx('chip', n === m && 'is-active')} onClick={() => setMinutes(String(m))}>
            {m} мин
          </button>
        ))}
      </div>
      <ConfirmButton
        className="btn btn--primary btn--lg btn--block"
        confirmText="Щёлкнуть?"
        disabled={save.isPending || n < 1 || n > MAX_SNAP_MINUTES || !events.length}
        onConfirm={() => save.mutate({ minutes: n, events })}
      >
        ⚡ Щёлкнуть на {n || 0} мин
      </ConfirmButton>
    </Card>
  );
}

/** The FUSE / upgrader event: the page's party look only — chances stay what they are. */
function LookEventCard({ kind }: { kind: 'fuse' | 'upgrade' }) {
  const settings = useAdminQuery<SettingsData>(['settings'], '/settings');
  const now = useNow(1000);
  const [minutes, setMinutes] = useState('30');
  const field = kind === 'fuse' ? 'fuseEvent' : 'upgradeEvent';
  const save = useAdminAction((m: number) => adminApi<SettingsData>('/settings', 'POST', { [field]: { minutes: m } }), { success: 'Готово', catalog: true });
  const until = (kind === 'fuse' ? settings.data?.fuseEventUntil : settings.data?.upgradeEventUntil) ?? null;
  const left = until ? Math.max(0, until - now) : 0;
  const n = Number(minutes) || 0;
  const info = EVENT_INFO[kind];
  return (
    <Card title={info.name}>
      <div className={cx('aluck', left > 0 && 'is-on')}>
        <img src={info.icon} alt="" />
        <div>
          <p className="arow__title">{left > 0 ? `Идёт · осталось ${formatCountdown(left)}` : 'Выключен'}</p>
          <p className="acard__text">
            Праздничное оформление {kind === 'fuse' ? 'FUSE' : 'апгрейдера'}: баннер с иконкой и таймером, свечение, плашка на главной. Шансы не меняются —
            поэтому в текстах нет обещаний «x2».
          </p>
        </div>
      </div>
      <div className="achips">
        {[15, 30, 60, 180].map((m) => (
          <button key={m} type="button" className={cx('chip', n === m && 'is-active')} onClick={() => setMinutes(String(m))}>
            {m >= 60 ? `${m / 60} ч` : `${m} мин`}
          </button>
        ))}
      </div>
      <button type="button" className="btn btn--primary btn--block" disabled={save.isPending || n < 1} onClick={() => save.mutate(n)}>
        {left > 0 ? 'Перезапустить' : 'Включить'} на {n >= 60 ? `${n / 60} ч` : `${n} мин`}
      </button>
      {left > 0 && (
        <button type="button" className="btn btn--danger btn--block" disabled={save.isPending} onClick={() => save.mutate(0)}>
          Выключить сейчас
        </button>
      )}
    </Card>
  );
}

/** «YYYY-MM-DDTHH:mm» in Moscow time (the admins plan in MSK). */


function TacosCard() {
  const settings = useAdminQuery<SettingsData>(['settings'], '/settings');
  const now = useNow(1000);
  const ev = settings.data?.tacos;
  const [enabled, setEnabled] = useState<boolean | null>(null);
  const [ends, setEnds] = useState<string | null>(null);
  const save = useAdminAction((body: { enabled: boolean; endsAt: number }) => adminApi<SettingsData>('/settings', 'POST', { tacos: body }), { success: 'Ивент сохранён', catalog: true });
  if (!ev) return null;
  const on = enabled ?? ev.enabled;
  const endsText = ends ?? toMskInput(ev.endsAt || Date.now() + 2 * 3600_000);
  const endsAt = fromMskInput(endsText);
  const running = ev.enabled && ev.endsAt > now;
  return (
    <Card title="Raining Tacos">
      <div className={cx('aluck', running && 'is-on')}>
        <img src="/brainrots/rubiko-and-kubiko.webp" alt="" />
        <div>
          <p className="arow__title">{running ? `Идёт · до конца ${Math.floor((ev.endsAt - now) / 86_400_000)} д ${formatCountdown((ev.endsAt - now) % 86_400_000)}` : ev.enabled ? 'Закончился' : 'Выключен'}</p>
          <p className="acard__text">
            Пока ивент идёт, на всех страницах сайта падают тако и сама играет музыка Raining Tacos (игрок может выключить её на значке
            ивента внизу). Только для настроения — ни монет, ни шансов. Включается на время или вместе со «Щелчком».
          </p>
        </div>
      </div>
      <div className="arow">
        <div>
          <p className="arow__title">Ивент включён</p>
          <p className="acard__text">Выключи, чтобы остановить тако и музыку сразу.</p>
        </div>
        <Switch on={on} onChange={setEnabled} label="Ивент включён" />
      </div>
      <Field label="Конец ивента (МСК)">
        <span className="ainput">
          <input type="datetime-local" value={endsText} onChange={(e) => setEnds(e.target.value)} />
        </span>
      </Field>
      <button
        type="button"
        className="btn btn--primary btn--block"
        disabled={save.isPending || !Number.isFinite(endsAt)}
        onClick={() => save.mutate({ enabled: on, endsAt }, { onSuccess: () => (setEnabled(null), setEnds(null)) })}
      >
        Сохранить ивент
      </button>
    </Card>
  );
}

const LUCK_LEVELS = [
  { x: 2, key: 'luckUntil', icon: '/luck-clover.webp', text: 'удваивается' },
  { x: 4, key: 'luck4Until', icon: EVENT_INFO.luck4.icon, text: 'растёт в 4 раза' },
  { x: 8, key: 'luck8Until', icon: EVENT_INFO.luck8.icon, text: 'растёт в 8 раз' },
] as const;

/** x2 / x4 / x8 luck: each is its own event, the strongest running one counts. Real odds, the 88 % average stays. */
function LuckCard() {
  const settings = useAdminQuery<SettingsData>(['settings'], '/settings');
  const [x, setX] = useState<2 | 4 | 8>(2);
  const [amount, setAmount] = useState('30');
  const [unit, setUnit] = useState<'min' | 'hour'>('min');
  const [notify, setNotify] = useState(true);
  const level = LUCK_LEVELS.find((l) => l.x === x)!;
  const save = useAdminAction((minutes: number) => adminApi<SettingsData>('/settings', 'POST', { luck: { minutes, notify, x } }), {
    success: (r) => (r[level.key] && notify && !until ? 'Включено — рассылка в бот уже пошла' : 'Готово'),
    catalog: true,
  });
  const broadcasts = useAdminQuery<Data<typeof AdminApi.broadcasts>>(['broadcasts'], '/broadcasts');
  const last = broadcasts.data?.list[0];
  const now = useNow(1000);
  const until = settings.data?.[level.key] ?? null;
  const left = until ? Math.max(0, until - now) : 0;
  const minutes = (Number(amount) || 0) * (unit === 'hour' ? 60 : 1);

  return (
    <Card title="Удача в кейсах">
      <div className="aluck-levels" role="group" aria-label="Уровень удачи">
        {LUCK_LEVELS.map((l) => {
          const on = (settings.data?.[l.key] ?? 0) > now;
          return (
            <button key={l.x} type="button" className={cx('aluck-level', x === l.x && 'is-active', on && 'is-on')} aria-pressed={x === l.x} onClick={() => setX(l.x)}>
              <img src={l.icon} alt="" />
              <b>x{l.x}</b>
              <small>{on ? formatCountdown((settings.data?.[l.key] ?? now) - now) : 'выкл'}</small>
            </button>
          );
        })}
      </div>
      <div className={cx('aluck', left > 0 && 'is-on')}>
        <img src={level.icon} alt="" />
        <div>
          <p className="arow__title">
            x{x} — {left > 0 ? `идёт · осталось ${formatCountdown(left)}` : 'выключена'}
          </p>
          <p className="acard__text">
            Пока ивент идёт, шанс окупных дропов (дороже кейса) во всех кейсах и батлах {level.text}, а среднее остаётся 88 % — дешёвые дропы
            становятся дешевле. На главной висит баннер с таймером. Если идут несколько, действует самая сильная. При урезанном окупе удача умножает уже урезанный шанс.
          </p>
        </div>
      </div>
      <div className="aduration">
        <span className="ainput ainput--short">
          <input inputMode="numeric" aria-label="Длительность" value={amount} onChange={(e) => setAmount(e.target.value.replace(/\D/g, '').slice(0, 4))} />
        </span>
        <Segmented
          label="Единицы"
          value={unit}
          onChange={setUnit}
          options={[
            { value: 'min', label: 'минут' },
            { value: 'hour', label: 'часов' },
          ]}
        />
      </div>
      <div className="achips">
        {[15, 30, 60, 180].map((m) => (
          <button key={m} type="button" className="chip" onClick={() => (setAmount(String(m >= 60 ? m / 60 : m)), setUnit(m >= 60 ? 'hour' : 'min'))}>
            {m >= 60 ? `${m / 60} ч` : `${m} мин`}
          </button>
        ))}
      </div>
      {left === 0 && (
        <div className="arow">
          <div>
            <p className="arow__title">Уведомить всех в боте</p>
            <p className="acard__text">Сообщение с картинкой и кнопкой «Крутить» уйдёт всем игрокам, кто не заблокировал бота (~{broadcasts.data?.reachable ?? '…'}).</p>
          </div>
          <Switch on={notify} onChange={setNotify} label="Уведомить всех в боте" />
        </div>
      )}
      {last && (
        <p className="acard__text">
          Последняя рассылка ({formatWhen(last.at)}): доставлено {last.sent}
          {last.failed ? `, не дошло ${last.failed}` : ''} — {last.done ? 'готово' : 'идёт, до 40 сообщений в минуту'}
        </p>
      )}
      <button type="button" className="btn btn--primary btn--lg btn--block" disabled={save.isPending || minutes < 1 || minutes > 7 * 24 * 60} onClick={() => save.mutate(minutes)}>
        {left > 0 ? 'Перезапустить' : 'Включить'} x{x} на {amount} {unit === 'hour' ? 'ч' : 'мин'}
      </button>
      {left > 0 && (
        <button type="button" className="btn btn--danger btn--block" disabled={save.isPending} onClick={() => save.mutate(0)}>
          Выключить x{x} сейчас
        </button>
      )}
    </Card>
  );
}

// ---------- Withdrawals ----------

type WithdrawalRow = Data<typeof WithdrawApi.adminWithdrawals>[number];

const toLocalInput = (ms: number) => {
  const d = new Date(ms - new Date(ms).getTimezoneOffset() * 60_000);
  return d.toISOString().slice(0, 16);
};

export function Withdrawals() {
  const [tab, setTab] = useState<'open' | 'history'>('open');
  const list = useAdminQuery<WithdrawalRow[]>(['withdrawals', tab], `/withdrawals?status=${tab}`);
  const settings = useAdminQuery<SettingsData>(['settings'], '/settings');
  return (
    <>
      <Card title="Выводы">
        <p className="acard__text">
          Новые заявки приходят и в бот. Там же кнопки «📅 Указать дату», «✅ Выведено», «❌ Отклонено», «💬 Связаться». За 5 минут до времени бот напомнит игроку и
          админам, в назначенное время у игрока 5 минут на трейд.
        </p>
        <Segmented
          label="Заявки"
          value={tab}
          onChange={setTab}
          options={[
            { value: 'open', label: tab === 'open' && list.data ? `Открытые · ${list.data.length}` : 'Открытые' },
            { value: 'history', label: 'История' },
          ]}
        />
        {list.isPending && <Empty>Загружаем…</Empty>}
        {list.data?.length === 0 && <Empty>{tab === 'open' ? 'Открытых выводов нет 🎉' : 'Здесь пока пусто.'}</Empty>}
        <ul className="alist">
          {(list.data ?? []).map((w) => (
            <WithdrawalCard key={w.id} w={w} bots={settings.data?.tradeBots ?? []} />
          ))}
        </ul>
      </Card>
      {settings.data && <WithdrawRulesCard rules={settings.data.withdrawRules} />}
    </>
  );
}

function WithdrawalCard({ w, bots }: { w: WithdrawalRow; bots: string[] }) {
  const catalog = useCatalog();
  const open = OPEN_WITHDRAW_STATUSES.includes(w.status);
  const [at, setAt] = useState(() => toLocalInput(w.scheduledAt ?? Date.now() + 15 * 60_000));
  const [bot, setBot] = useState(w.botNick ?? bots[0] ?? '');
  const [note, setNote] = useState('');
  const act = useAdminAction((body: object) => adminApi(`/withdrawals/${w.id}`, 'POST', body), { success: 'Готово' });
  const atMs = new Date(at).getTime();
  return (
    <li className={cx('alist__row awd', `awd--${w.status}`)}>
      <UserLine
        user={w.user}
        extra={
          <>
            {w.user.rank > 0 && (
              <span className="pill pill--rank" title={`Ранг: ${RANKS[w.user.rank]!.name}`}>
                <RankBadge rank={RANKS[w.user.rank]!} size={16} /> {RANKS[w.user.rank]!.name}
              </span>
            )}
            <span className={cx('pill', w.status === 'done' && 'pill--green', (w.status === 'rejected' || w.status === 'expired') && 'pill--red', open && w.status !== 'expired' && 'pill--gold')}>
              #{w.id} · {WITHDRAW_STATUS_LABEL[w.status]}
            </span>
          </>
        }
      />
      <ul className="awd__items">
        {w.items.map((i) => {
          const b = catalog.byId.get(i.brainrotId);
          return (
            <li key={i.brainrotId}>
              {b && <BrainrotThumb brainrot={b} size={36} />}
              <span>
                {i.name}
                {i.count > 1 && <b> ×{i.count}</b>}
              </span>
              <small>
                {formatCoins(i.price * i.count)} <Coin size={10} />
              </small>
            </li>
          );
        })}
      </ul>
      <p className="alist__meta">
        Сумма <b>{formatCoins(w.value)} B</b> · создана {formatWhen(w.createdAt)}
        {w.scheduledAt ? ` · время ${formatMsk(w.scheduledAt)}` : ''}
        {w.botNick ? ` · бот ${w.botNick}` : ''}
        {w.note ? ` · ${w.note}` : ''}
      </p>
      <button
        type="button"
        className="awd__nick"
        onClick={() => {
          void navigator.clipboard?.writeText(w.robloxNick).then(() => toast('Ник скопирован', 'success'));
        }}
      >
        Roblox игрока: <strong>{w.robloxNick}</strong> <Icon name="copy" size={14} />
      </button>
      {open && (
        <>
          {w.status !== 'trading' && (
            <div className="awd__plan">
              <div className="awd__quick" role="group" aria-label="Быстро назначить">
                {[0, 15, 30, 60].map((m) => (
                  <button
                    key={m}
                    type="button"
                    className="chip chip--sm"
                    disabled={act.isPending || (!bot && !bots.length)}
                    onClick={() => act.mutate({ action: 'schedule', at: Date.now() + m * 60_000, botNick: bot || undefined })}
                  >
                    {m === 0 ? '⚡ Сейчас' : m < 60 ? `+${m} мин` : '+1 ч'}
                  </button>
                ))}
              </div>
              <Field label="Дата и время" hint={Number.isFinite(atMs) ? `= ${formatMsk(atMs)}` : undefined}>
                <span className="ainput">
                  <input type="datetime-local" value={at} onChange={(e) => setAt(e.target.value)} />
                </span>
              </Field>
              <Field label="Ник бота">
                <span className="ainput">
                  <input list={`bots-${w.id}`} value={bot} maxLength={20} placeholder="RobloxBot" onChange={(e) => setBot(e.target.value.trim())} />
                  <datalist id={`bots-${w.id}`}>
                    {bots.map((b) => (
                      <option key={b} value={b} />
                    ))}
                  </datalist>
                </span>
              </Field>
              <button type="button" className="btn btn--primary btn--sm btn--block" disabled={act.isPending || !Number.isFinite(atMs) || !bot} onClick={() => act.mutate({ action: 'schedule', at: atMs, botNick: bot })}>
                <Icon name="clock" size={16} /> Назначить вывод
              </button>
            </div>
          )}
          <span className="ainput">
            <input value={note} maxLength={200} placeholder="Причина отказа (необязательно)" onChange={(e) => setNote(e.target.value)} />
          </span>
          <div className="abuttons">
            <ConfirmButton className="btn btn--green btn--sm" disabled={act.isPending} onConfirm={() => act.mutate({ action: 'done' })} confirmText="Выведено? Предметы спишутся">
              ✅ Выведено
            </ConfirmButton>
            <ConfirmButton className="btn btn--ghost btn--sm" disabled={act.isPending} onConfirm={() => act.mutate({ action: 'reject', note })} confirmText="Вернуть брейнротов?">
              ❌ Отклонить
            </ConfirmButton>
          </div>
        </>
      )}
    </li>
  );
}

function WithdrawRulesCard({ rules }: { rules: SettingsData['withdrawRules'] }) {
  const [minValue, setMinValue] = useState(String(rules.minValue));
  const [minItems, setMinItems] = useState(String(rules.minItems));
  const [minItemPrice, setMinItemPrice] = useState(String(rules.minItemPrice));
  const [wagerDeposit, setWagerDeposit] = useState(String(rules.wagerDeposit));
  const [wagerBonus, setWagerBonus] = useState(String(rules.wagerBonus));
  const save = useAdminAction((body: object) => adminApi('/settings', 'POST', body), { success: 'Правила вывода сохранены' });
  return (
    <Card title="Правила вывода">
      <p className="acard__text">
        Заявка проходит, если сумма не меньше минимума <b>или</b> в ней не меньше N брейнротов. Выводятся только брейнроты «в наличии» (переключатель в «Каталоге»);
        остальных от порога хлама игрок разменивает на них со сдачей монетами. Хлам дешевле порога не выводится и не размениваются.
      </p>
      <div className="agrid3">
        <Field label="Сумма от, B">
          <span className="ainput">
            <input inputMode="decimal" value={minValue} onChange={(e) => setMinValue(e.target.value)} />
          </span>
        </Field>
        <Field label="Или брейнротов от">
          <span className="ainput">
            <input inputMode="numeric" value={minItems} onChange={(e) => setMinItems(e.target.value)} />
          </span>
        </Field>
        <Field label="Хлам дешевле, B">
          <span className="ainput">
            <input inputMode="decimal" value={minItemPrice} onChange={(e) => setMinItemPrice(e.target.value)} />
          </span>
        </Field>
      </div>
      <p className="acard__text">
        <b>Отыгрыш.</b> Перед выводом игрок ставит в играх пополнения × первый множитель и всё бесплатное (бонусные и подарочные кейсы, кэшбэк, промокоды,
        призы, реферальный баланс, выдача) × второй. Каждая ставка засчитывается целиком, выигрыши со своих ставок — нет. 0 — выключить.
      </p>
      <div className="agrid2">
        <Field label="Пополнения ×">
          <span className="ainput">
            <input inputMode="decimal" value={wagerDeposit} onChange={(e) => setWagerDeposit(e.target.value)} />
          </span>
        </Field>
        <Field label="Бонусы и призы ×">
          <span className="ainput">
            <input inputMode="decimal" value={wagerBonus} onChange={(e) => setWagerBonus(e.target.value)} />
          </span>
        </Field>
      </div>
      <button
        type="button"
        className="btn btn--primary btn--block"
        disabled={save.isPending}
        onClick={() =>
          save.mutate({
            withdrawRules: {
              minValue: minValue.replace(',', '.'),
              minItems: Number(minItems),
              minItemPrice: minItemPrice.replace(',', '.'),
              wagerDeposit: wagerDeposit.replace(',', '.'),
              wagerBonus: wagerBonus.replace(',', '.'),
            },
          })
        }
      >
        Сохранить правила
      </button>
    </Card>
  );
}

// ---------- Log ----------

const ACTION: Record<string, string> = {
  give_coins: 'выдал монеты',
  give_brainrot: 'выдал брейнрота',
  take: 'забрал',
  ban: 'забанил',
  freeze: 'заморозил',
  unban: 'разбанил',
  unfreeze: 'разморозил',
  promo_create: 'создал промокод',
  promo_delete: 'удалил промокод',
  media_grant: 'выдал Партнёра',
  media_revoke: 'снял Партнёра',
  maintenance_on: 'включил тех. работы',
  maintenance_off: 'выключил тех. работы',
  demo_deposits: 'переключил тест. пополнения',
  star_rate: 'изменил курс звёзд',
  crypto_rate: 'изменил курс крипты',
  give_case: 'выдал кейс',
  luck_on: 'включил x2 удачу',
  halloween_on: 'настроил Хэллоуин-ивент',
  halloween_off: 'выключил Хэллоуин-ивент',
  luck_off: 'выключил x2 удачу',
  trade_bots: 'обновил ники ботов',
  item_deposit_credit: 'зачислил пополнение брейнротами',
  brainrot_create: 'создал брейнрота',
  announce: 'запустил рассылку',
  announce_stop: 'остановил рассылку',
  danger_reset: 'обнулил игрока',
  danger_wipe: 'обнулил ВСЕХ игроков',
  danger_reset_eggs: 'обнулил всех, кто подобрал яйцо',
  danger_denied: 'ввёл неверный пароль опасной зоны',
  brainrot_update: 'изменил брейнрота',
  brainrot_delete: 'удалил брейнрота',
  title_create: 'создал титул',
  title_update: 'изменил титул',
  title_delete: 'удалил титул',
  title_grant: 'выдал титул',
  title_revoke: 'отобрал титул',
  case_create: 'создал кейс',
  case_update: 'изменил кейс',
  case_delete: 'удалил кейс',
  withdraw_done: 'выполнил вывод',
  withdraw_reject: 'отклонил вывод',
  withdraw_rules: 'изменил правила вывода',
  wager_clear: 'снял отыгрыш',
  okup_cut: 'изменил шанс окупа в кейсах',
  top_drop_reset: 'очистил топ дроп дня',
  admin_add: 'выдал админку',
  admin_remove: 'снял админку',
  section_create: 'создал тему',
  section_update: 'изменил тему',
  section_delete: 'удалил тему',
  case_heal: 'дополнил состав кейса',
  case_recompose: 'пересобрал состав кейса',
  deposit_item_add: 'добавил в список пополнений',
  deposit_item_price: 'изменил цену в списке пополнений',
  deposit_item_remove: 'убрал из списка пополнений',
  deposit_item_section: 'перенёс позицию пополнений',
  free_gate: 'изменил условия бесплатного кейса',
  withdraw_min: 'изменил минимум вывода',
  deposit_open: 'открыл/закрыл приём пополнений',
};

function summary(details: unknown): string {
  if (!details || typeof details !== 'object') return '';
  const d = details as Record<string, unknown>;
  const parts = ['amount', 'count', 'code', 'name', 'id', 'price', 'platform', 'reason', 'rate']
    .filter((k) => d[k] !== undefined && d[k] !== null && d[k] !== '')
    .map((k) => String(d[k]));
  return parts.join(' · ');
}

export function Logs() {
  const list = useAdminQuery<Data<typeof AdminApi.logs>>(['logs'], '/logs');
  return (
    <Card title="Журнал действий">
      {list.data?.length === 0 && <Empty>Пока пусто.</Empty>}
      <ul className="alog">
        {(list.data ?? []).map((l) => (
          <li key={l.id}>
            <time>{formatWhen(l.at)}</time>
            <p>
              <strong>{l.admin}</strong> {ACTION[l.action] ?? l.action}
              {l.target && (
                <>
                  {' '}
                  → <strong>{l.target}</strong>
                </>
              )}
            </p>
            {summary(l.details) && <small>{summary(l.details)}</small>}
          </li>
        ))}
      </ul>
    </Card>
  );
}
