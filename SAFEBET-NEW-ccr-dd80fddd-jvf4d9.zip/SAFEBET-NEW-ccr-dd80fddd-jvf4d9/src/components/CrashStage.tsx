import { useEffect, useRef } from 'react';
import { cx } from '../lib/format';

export type CrashPhase = 'idle' | 'flying' | 'crashed' | 'cashed';

const LABEL: Record<CrashPhase, string> = {
  idle: 'Готов к запуску',
  flying: 'В полёте',
  crashed: 'Взорвалась',
  cashed: 'Забрал',
};

export function CrashStage({ phase, multiplier }: { phase: CrashPhase; multiplier: number }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const speedRef = useRef(0.15);
  speedRef.current = phase === 'flying' ? 0.7 + Math.log(multiplier) * 1.8 : 0.15;

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;
    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    const stars = Array.from({ length: 90 }, () => ({ x: Math.random(), y: Math.random(), z: 0.25 + Math.random() * 0.75 }));
    let w = 0;
    let h = 0;

    const resize = () => {
      const rect = canvas.getBoundingClientRect();
      w = rect.width;
      h = rect.height;
      canvas.width = Math.round(w * dpr);
      canvas.height = Math.round(h * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    resize();
    const observer = new ResizeObserver(resize);
    observer.observe(canvas);

    let frame = 0;
    let last = performance.now();
    const draw = (t: number) => {
      const dt = Math.min(0.05, (t - last) / 1000);
      last = t;
      const speed = reduceMotion ? 0 : speedRef.current;
      ctx.clearRect(0, 0, w, h);
      ctx.lineCap = 'round';
      for (const s of stars) {
        s.x -= speed * s.z * dt * 0.45;
        s.y += speed * s.z * dt * 0.45;
        if (s.x < -0.05) s.x += 1.1;
        if (s.y > 1.05) s.y -= 1.1;
        const len = 1 + speed * s.z * 14;
        const x = s.x * w;
        const y = s.y * h;
        ctx.strokeStyle = `rgba(214, 226, 255, ${0.2 + s.z * 0.6})`;
        ctx.lineWidth = 0.6 + s.z * 1.4;
        ctx.beginPath();
        ctx.moveTo(x, y);
        ctx.lineTo(x + len * 0.7, y - len * 0.7);
        ctx.stroke();
      }
      frame = requestAnimationFrame(draw);
    };
    frame = requestAnimationFrame(draw);
    return () => {
      cancelAnimationFrame(frame);
      observer.disconnect();
    };
  }, []);

  return (
    <div className={cx('stage', `stage--${phase}`)}>
      <canvas ref={canvasRef} className="stage__stars" aria-hidden="true" />
      <div className="stage__rocket" aria-hidden="true">
        <Rocket />
      </div>
      {phase === 'crashed' && <Boom />}
      <div className="stage__readout">
        <span className="stage__label">{LABEL[phase]}</span>
        <span className="stage__mult">
          {multiplier.toFixed(2)}
          <small>x</small>
        </span>
      </div>
    </div>
  );
}

function Rocket() {
  return (
    <svg viewBox="0 0 120 130" width="100%" height="100%">
      <defs>
        <linearGradient id="rocket-body" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#c9d1e3" />
          <stop offset="0.45" stopColor="#ffffff" />
          <stop offset="1" stopColor="#9aa6bf" />
        </linearGradient>
        <linearGradient id="rocket-flame" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#fff6c2" />
          <stop offset="0.35" stopColor="#ffc531" />
          <stop offset="0.75" stopColor="#ff5a2b" />
          <stop offset="1" stopColor="#ff5a2b" stopOpacity="0" />
        </linearGradient>
      </defs>
      <g className="rocket__flame">
        <path d="M48 86c0 16 6 28 12 40 6-12 12-24 12-40z" fill="url(#rocket-flame)" />
        <path d="M54 86c0 9 3 16 6 22 3-6 6-13 6-22z" fill="#fffbe6" opacity="0.85" />
      </g>
      <path d="M40 62L22 88l6 6 14-10z" fill="#e2384d" />
      <path d="M80 62l18 26-6 6-14-10z" fill="#e2384d" />
      <path d="M60 6c18 16 24 40 20 72H40C36 46 42 22 60 6z" fill="url(#rocket-body)" />
      <path d="M60 6c10 9 16 20 18.6 32H41.4C44 26 50 15 60 6z" fill="#e2384d" />
      <rect x="41" y="66" width="38" height="5" fill="#3d6df2" />
      <circle cx="60" cy="52" r="10.5" fill="#16234a" stroke="#ffffff" strokeWidth="3.5" />
      <circle cx="56.5" cy="48.5" r="3" fill="#7fa3ff" opacity="0.8" />
      <rect x="47" y="78" width="26" height="8" rx="2.5" fill="#7b869e" />
      <path d="M58 60v22" stroke="#e2384d" strokeWidth="4" strokeLinecap="round" />
    </svg>
  );
}

function Boom() {
  const rays = Array.from({ length: 12 }, (_, i) => i);
  return (
    <svg className="stage__boom" viewBox="0 0 200 200" aria-hidden="true">
      <circle className="boom__wave" cx="100" cy="100" r="40" fill="none" stroke="#ffd36b" strokeWidth="6" />
      <g className="boom__rays">
        {rays.map((i) => (
          <path
            key={i}
            d="M100 100 L94 30 L100 14 L106 30 Z"
            fill={i % 2 ? '#ff5a2b' : '#ffc531'}
            transform={`rotate(${i * 30} 100 100)`}
          />
        ))}
      </g>
      <circle className="boom__core" cx="100" cy="100" r="30" fill="#fff3c4" />
    </svg>
  );
}
