import type { MediaPlatform } from '../../shared/types';
import { cx } from '../lib/format';

const LABEL: Record<MediaPlatform, string> = { tiktok: 'TikTok', youtube: 'YouTube', twitch: 'Twitch' };

export function PlatformLogo({ platform, size = 16 }: { platform: MediaPlatform; size?: number }) {
  if (platform === 'youtube') {
    return (
      <svg width={size} height={size} viewBox="0 0 24 24" aria-hidden="true">
        <rect x="1.5" y="5" width="21" height="14" rx="4.5" fill="#ff2a2a" />
        <path d="M10 8.8v6.4l5.6-3.2z" fill="#fff" />
      </svg>
    );
  }
  if (platform === 'twitch') {
    return (
      <svg width={size} height={size} viewBox="0 0 24 24" aria-hidden="true">
        <path d="M4.5 2.5L3 6.5v13h4.5V22h2.6l2.4-2.5h3.7l4.8-4.9V2.5z" fill="#9146ff" />
        <path d="M6.5 4.5h12v9.2l-2.8 2.8h-4.2l-2.4 2.4v-2.4H6.5z" fill="#fff" />
        <path d="M11 7.5h1.8v4.6H11zM15.3 7.5h1.8v4.6h-1.8z" fill="#9146ff" />
      </svg>
    );
  }
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" aria-hidden="true">
      <rect width="24" height="24" rx="6" fill="#0b0b0f" />
      <path d="M13.6 4h2.6c.2 1.9 1.5 3.3 3.3 3.5v2.6c-1.2 0-2.3-.4-3.3-1v5.6a4.8 4.8 0 1 1-4.8-4.8c.3 0 .5 0 .8.1v2.7a2.2 2.2 0 1 0 1.4 2V4z" fill="#25f4ee" transform="translate(-.6 -.4)" />
      <path d="M13.6 4h2.6c.2 1.9 1.5 3.3 3.3 3.5v2.6c-1.2 0-2.3-.4-3.3-1v5.6a4.8 4.8 0 1 1-4.8-4.8c.3 0 .5 0 .8.1v2.7a2.2 2.2 0 1 0 1.4 2V4z" fill="#fe2c55" transform="translate(.6 .4)" />
      <path d="M13.6 4h2.6c.2 1.9 1.5 3.3 3.3 3.5v2.6c-1.2 0-2.3-.4-3.3-1v5.6a4.8 4.8 0 1 1-4.8-4.8c.3 0 .5 0 .8.1v2.7a2.2 2.2 0 1 0 1.4 2V4z" fill="#fff" />
    </svg>
  );
}

export function MediaBadge({ platform, className }: { platform: string; className?: string }) {
  const p = platform as MediaPlatform;
  if (!LABEL[p]) return null;
  return (
    <span className={cx('media-badge', `media-badge--${p}`, className)} title={`Партнёр ${LABEL[p]}`}>
      <PlatformLogo platform={p} />
      Партнёр
    </span>
  );
}

export { LABEL as PLATFORM_LABEL };
