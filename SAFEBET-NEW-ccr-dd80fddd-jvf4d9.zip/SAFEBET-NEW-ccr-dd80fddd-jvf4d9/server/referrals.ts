import { randomInt } from 'node:crypto';
import { HOUSE_GAMES, REF_CODE_COOLDOWN_MS, REF_DEPOSIT_MIN, REF_MILESTONE_TURNOVER, REF_MILESTONES, nextMilestone, refLevel } from '../shared/bonuses';
import { floor2, round2 } from '../shared/money';
import { assertActive, type Viewer } from './auth';
import { db, ms, num, one, q, tx, type Queryable } from './db';
import { addWager, spendRealCoins } from './economy';
import { bad, notFound } from './errors';
import { touch } from './live';
import { botApi, escapeHtml } from './telegram';
import { displayName } from './users';
import { int, str, type Body } from './validate';

/**
 * Referral programme: personal codes and links, binding new players, the referrer's share of every friend's deposit
 * and players' own promo codes.
 */

export const BOT_LINK = 'https://t.me/braincrashbot';
export const refLink = (code: string) => `${BOT_LINK}?start=r-${code}`;
const CODE_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const REFERRAL_CASE = 'referral';

const newCode = (n: number) => Array.from({ length: n }, () => CODE_ALPHABET[randomInt(CODE_ALPHABET.length)]).join('');

/** Every player gets a code the first time they need one. */
export async function ensureRefCode(c: Queryable, userId: number): Promise<string> {
  const { rows } = await c.query<{ ref_code: string | null }>('SELECT ref_code FROM users WHERE id = $1', [userId]);
  if (rows[0]?.ref_code) return rows[0].ref_code;
  for (let attempt = 0; attempt < 6; attempt++) {
    const code = newCode(8);
    if (await codeTaken(c, code)) continue;
    try {
      const r = await c.query<{ ref_code: string }>('UPDATE users SET ref_code = COALESCE(ref_code, $2) WHERE id = $1 RETURNING ref_code', [userId, code]);
      if (r.rows[0]) return r.rows[0].ref_code;
    } catch (e) {
      if ((e as { code?: string }).code !== '23505') throw e;
    }
  }
  throw new Error('could not allocate a referral code');
}

/** Promo codes, partner codes and every partner code used before share one namespace. */
export async function codeTaken(c: Queryable, code: string, exceptUser?: number) {
  const { rows } = await c.query(
    `SELECT 1 FROM promo_codes WHERE code_key = $1
     UNION ALL SELECT 1 FROM users WHERE lower(ref_code) = $1 AND id IS DISTINCT FROM $2
     UNION ALL SELECT 1 FROM ref_code_history WHERE code_lc = $1 AND user_id IS DISTINCT FROM $2
     LIMIT 1`,
    [code.trim().toLowerCase(), exceptUser ?? null],
  );
  return rows.length > 0;
}

/** The owner of a partner code — a former code of theirs too, so links shared before a change keep working. */
export async function referrerByCode(c: Queryable, code: string): Promise<number | null> {
  const { rows } = await c.query<{ id: string }>(
    `SELECT id FROM users WHERE lower(ref_code) = $1
     UNION ALL SELECT user_id FROM ref_code_history WHERE code_lc = $1
     LIMIT 1`,
    [code.trim().toLowerCase()],
  );
  return rows[0] ? num(rows[0].id) : null;
}

/**
 * A visit by link counts only for the visitor's own referrer (or anyone while they have none yet): a player already
 * bound to someone else who follows another link counts for nobody — no click, no binding, no case.
 */
export async function recordClick(referrerId: number, visitorId: number) {
  if (referrerId === visitorId) return;
  await q(
    `INSERT INTO ref_clicks (referrer_id, visitor_id)
     SELECT $1, $2 WHERE NOT EXISTS (SELECT 1 FROM users WHERE id = $2 AND referred_by IS NOT NULL AND referred_by <> $1)
     ON CONFLICT DO NOTHING`,
    [referrerId, visitorId],
  );
}

async function giveReferralCase(c: Queryable, userId: number) {
  touch(userId, 'me', 'bonuses');
  await c.query(
    `INSERT INTO case_keys (user_id, case_id, count) SELECT $1, id, 1 FROM cases WHERE id = $2 AND status = 'active'
     ON CONFLICT (user_id, case_id) DO UPDATE SET count = case_keys.count + 1`,
    [userId, REFERRAL_CASE],
  );
}

export type BindResult = 'bound' | 'self' | 'already' | 'cycle' | 'missing';

/**
 * The referral case comes ONCE per account (the owner: «хоть миллион позовет — один раз»): at the account's first
 * referral link — when it is bound to someone, or when its first friend comes, whichever is first. An account that
 * is somebody's referral or already has a friend has had it.
 */
async function hadReferralCase(c: Queryable, userId: number, referredBy: string | null): Promise<boolean> {
  if (referredBy) return true;
  const { rows } = await c.query('SELECT 1 FROM users WHERE referred_by = $1 LIMIT 1', [userId]);
  return rows.length > 0;
}

/**
 * Makes `userId` a referral of `referrerId` if they aren't anyone's yet. Each of them gets a referral case opening
 * right away (the owner's call) unless their account has had one already (hadReferralCase). Runs inside the
 * caller's transaction; the referrer is told in the bot afterwards (see notifyBound).
 */
export async function bindReferral(c: Queryable, userId: number, referrerId: number): Promise<BindResult> {
  if (userId === referrerId) return 'self';
  // Both rows locked in id order: two players binding to each other at once can't deadlock or both succeed.
  const { rows } = await c.query<{ id: string; referred_by: string | null }>('SELECT id, referred_by FROM users WHERE id = ANY($1::bigint[]) ORDER BY id FOR UPDATE', [[userId, referrerId]]);
  const me = rows.find((r) => num(r.id) === userId);
  if (!rows.some((r) => num(r.id) === referrerId)) return 'missing';
  if (!me) return 'missing';
  if (me.referred_by) return 'already';
  // No loops: the new referral must not be somewhere up the referrer's own chain.
  const { rows: loop } = await c.query(
    `WITH RECURSIVE up (id, depth) AS (
       SELECT referred_by, 1 FROM users WHERE id = $1 AND referred_by IS NOT NULL
       UNION ALL
       SELECT u.referred_by, up.depth + 1 FROM users u JOIN up ON u.id = up.id WHERE u.referred_by IS NOT NULL AND up.depth < 64
     )
     SELECT 1 FROM up WHERE id = $2 LIMIT 1`,
    [referrerId, userId],
  );
  if (loop.length) return 'cycle';
  // Asked before the binding below (it would make the referrer look as if they had a friend already).
  const friendGets = !(await hadReferralCase(c, userId, me.referred_by));
  const referrerGets = !(await hadReferralCase(c, referrerId, rows.find((r) => num(r.id) === referrerId)!.referred_by));
  await c.query('UPDATE users SET referred_by = $2, referred_at = now() WHERE id = $1', [userId, referrerId]);
  if (friendGets) await giveReferralCase(c, userId);
  if (referrerGets) await giveReferralCase(c, referrerId);
  return 'bound';
}

export async function notifyBound(referrerId: number, userId: number) {
  const u = await one<{ id: string; username: string | null; first_name: string; last_name: string | null }>('SELECT id, username, first_name, last_name FROM users WHERE id = $1', [userId]);
  // The referrer's case came with this friend only if it is their first and nobody brought them (hadReferralCase).
  const r = await one<{ first: boolean }>(
    `SELECT (referred_by IS NULL AND (SELECT count(*) FROM users f WHERE f.referred_by = $1) = 1) AS first FROM users WHERE id = $1`,
    [referrerId],
  );
  await botApi('sendMessage', {
    chat_id: referrerId,
    parse_mode: 'HTML',
    text: `🎉 По твоей ссылке пришёл ${escapeHtml(u ? displayName(u) : 'новый друг')}!\n${
      r?.first ? 'Тебе и другу — по реферальному кейсу (он даётся один раз на аккаунт).' : 'Другу — реферальный кейс (тебе он уже доставался: один раз на аккаунт).'
    } С каждого его пополнения тебе — процент на реферальный баланс, сразу.`,
  });
}

/**
 * The friend's first real deposit of at least REF_DEPOSIT_MIN makes them active: they start counting towards the
 * referrer's level. Returns the referrer when this deposit did it.
 */
export async function markActiveReferral(c: Queryable, userId: number, amount: number): Promise<number | null> {
  if (amount < REF_DEPOSIT_MIN) return null;
  const { rows } = await c.query<{ referred_by: string }>(
    'UPDATE users SET ref_bonus_paid = true WHERE id = $1 AND referred_by IS NOT NULL AND NOT ref_bonus_paid RETURNING referred_by',
    [userId],
  );
  return rows[0] ? num(rows[0].referred_by) : null;
}

/**
 * The referrer's share of a friend's deposit, straight onto the referral balance: the level percent (REF_LEVELS, by
 * active friends, this deposit included) of what the friend paid for — a promo bonus on top doesn't count. The
 * owner's rule: referrers earn from deposits only, never from bets.
 */
export async function payDepositShare(c: Queryable, userId: number, paid: number): Promise<{ referrer: number; share: number; percent: number } | null> {
  if (!(paid > 0)) return null;
  const { rows } = await c.query<{ referrer: string | null; active: string; partner: string | null }>(
    `SELECT u.referred_by AS referrer, (SELECT count(*) FROM users f WHERE f.referred_by = u.referred_by AND f.ref_bonus_paid) AS active,
       (SELECT r.ref_percent FROM users r WHERE r.id = u.referred_by) AS partner
     FROM users u WHERE u.id = $1`,
    [userId],
  );
  if (!rows[0]?.referrer) return null;
  const referrer = num(rows[0].referrer);
  // A partner (a creator an owner signed up) gets their own percent from the first friend on.
  const percent = rows[0].partner !== null ? num(rows[0].partner) : refLevel(num(rows[0].active)).percent;
  const share = floor2((paid * percent) / 100);
  if (share <= 0) return null;
  await c.query('UPDATE users SET ref_balance = ref_balance + $2 WHERE id = $1', [referrer, share]);
  // `deposit_bonus`: the payout kind for anything earned on a friend's deposit.
  await c.query(`INSERT INTO ref_payouts (referrer_id, referral_id, kind, amount) VALUES ($1, $2, 'deposit_bonus', $3)`, [referrer, userId, share]);
  touch(referrer, 'me');
  return { referrer, share, percent };
}

/** The referrer hears about the share at once (and that the friend became active, on their first deposit). */
export async function notifyDepositShare(p: { referrer: number; share: number; percent: number }, firstDeposit: boolean) {
  await botApi('sendMessage', {
    chat_id: p.referrer,
    parse_mode: 'HTML',
    text: firstDeposit
      ? `💸 Твой друг сделал первое пополнение — он теперь активный. Тебе <b>+${round2(p.share).toLocaleString('ru-RU')} B</b> (${p.percent}%) на реферальный баланс.`
      : `💸 Друг пополнил баланс — тебе <b>+${round2(p.share).toLocaleString('ru-RU')} B</b> (${p.percent}%) на реферальный баланс.`,
  });
}

/** A friend's first deposit that pays nothing (too small for a share) still tells the referrer they are active now. */
export async function notifyActiveFriend(referrerId: number) {
  const r = await one<{ active: string }>('SELECT count(*) AS active FROM users WHERE referred_by = $1 AND ref_bonus_paid', [referrerId]);
  const level = refLevel(num(r?.active));
  await botApi('sendMessage', {
    chat_id: referrerId,
    parse_mode: 'HTML',
    text: `💸 Твой друг сделал первое пополнение — он теперь активный. Ты получаешь <b>${level.percent}%</b> с каждого пополнения друзей.`,
  });
}

/** A referred player's net deposits since binding: Stars + brainrot deposits − finished withdrawals. */
const FRIEND_NET = `
  (SELECT coalesce(sum(p.credited), 0) FROM star_payments p WHERE p.user_id = u.id AND p.created_at >= u.referred_at)
  + (SELECT coalesce(sum(d.credited), 0) FROM item_deposits d WHERE d.user_id = u.id AND d.status = 'credited' AND d.updated_at >= u.referred_at)
  - (SELECT coalesce(sum(w.value), 0) FROM withdrawals w WHERE w.user_id = u.id AND w.status = 'done' AND w.processed_at >= u.referred_at)`;

/** What a referred player has played since binding in cases and battles (the games that keep 12 %). */
const FRIEND_PLAYED = `
  (SELECT coalesce(sum(dr.stake_value), 0) FROM drops dr
    WHERE dr.user_id = u.id AND dr.game IN (${HOUSE_GAMES.map((g) => `'${g}'`).join(', ')}) AND dr.stake_value > 0 AND NOT dr.demo AND dr.created_at >= u.referred_at)`;

export interface MilestonePaid {
  referrer: number;
  friend: number;
  from: number;
  reward: number;
}

const STEPS = REF_MILESTONES.map((m) => `(${m.step}, ${m.from}, ${m.reward})`).join(', ');

/**
 * Pays every milestone the chosen friends (`where` on users u) have reached and not been paid for: net deposits past
 * the threshold and REF_MILESTONE_TURNOVER × it played. One statement; the primary key (friend, step) makes a second
 * payment impossible even when a deposit and the tick race.
 */
async function payDue(c: Queryable, where: string, params: unknown[]): Promise<MilestonePaid[]> {
  const { rows } = await c.query<{ referral_id: string; step: number; referrer_id: string; amount: string }>(
    `WITH cand AS (
       SELECT u.id, u.referred_by AS referrer, ${FRIEND_NET} AS net, ${FRIEND_PLAYED} AS played
       FROM users u WHERE u.referred_by IS NOT NULL AND u.referred_at IS NOT NULL AND ${where}
     ), ins AS (
       INSERT INTO ref_milestones (referral_id, step, referrer_id, amount)
       SELECT c.id, m.step, c.referrer, m.reward
       FROM cand c JOIN (VALUES ${STEPS}) AS m (step, from_value, reward)
         ON c.net >= m.from_value AND c.played >= m.from_value * ${REF_MILESTONE_TURNOVER}
       ON CONFLICT DO NOTHING
       RETURNING referral_id, step, referrer_id, amount
     ), credit AS (
       UPDATE users r SET ref_balance = r.ref_balance + s.total
       FROM (SELECT referrer_id, sum(amount) AS total FROM ins GROUP BY referrer_id) s
       WHERE r.id = s.referrer_id
     ), logged AS (
       INSERT INTO ref_payouts (referrer_id, referral_id, kind, amount) SELECT referrer_id, referral_id, 'milestone', amount FROM ins
     )
     SELECT referral_id, step, referrer_id, amount FROM ins ORDER BY referral_id, step`,
    params,
  );
  const paid = rows.map((r) => ({
    referrer: num(r.referrer_id),
    friend: num(r.referral_id),
    from: REF_MILESTONES.find((m) => m.step === Number(r.step))?.from ?? 0,
    reward: num(r.amount),
  }));
  for (const referrer of new Set(paid.map((p) => p.referrer))) touch(referrer, 'me');
  return paid;
}

/** After a friend's deposit (in its transaction). */
export function payMilestones(c: Queryable, userId: number): Promise<MilestonePaid[]> {
  return payDue(c, 'u.id = $1', [userId]);
}

/**
 * The minute tick: friends who played in the last 10 minutes may have reached the turnover. A missed tick is caught
 * up by their next game or deposit.
 */
export async function payPlayedMilestones(): Promise<number> {
  const paid = await tx((c) =>
    payDue(c, `EXISTS (SELECT 1 FROM drops d WHERE d.user_id = u.id AND NOT d.demo AND d.created_at > now() - interval '10 minutes')`, []),
  );
  if (paid.length) {
    for (const friend of new Set(paid.map((p) => p.friend))) await notifyMilestones(paid.filter((p) => p.friend === friend));
  }
  return paid.length;
}

export async function notifyMilestones(paid: MilestonePaid[]) {
  if (!paid.length) return;
  const u = await one<{ id: string; username: string | null; first_name: string; last_name: string | null }>('SELECT id, username, first_name, last_name FROM users WHERE id = $1', [paid[0]!.friend]);
  const name = escapeHtml(u ? displayName(u) : 'Твой друг');
  for (const p of paid) {
    await botApi('sendMessage', {
      chat_id: p.referrer,
      parse_mode: 'HTML',
      text: `🏆 <b>Крупное приглашение!</b> ${name} пополнил уже на ${p.from.toLocaleString('ru-RU')} B — тебе <b>+${p.reward.toLocaleString('ru-RU')} B</b> на реферальный баланс.`,
    });
  }
}

// ---------- Player API ----------

export async function referralSummary(v: Viewer) {
  const code = await ensureRefCode(db, v.id);
  const [invited, clicks, money, me] = await Promise.all([
    one<{ n: string; active: string }>('SELECT count(*) AS n, count(*) FILTER (WHERE ref_bonus_paid) AS active FROM users WHERE referred_by = $1', [v.id]),
    one<{ n: string }>('SELECT count(*) AS n FROM ref_clicks WHERE referrer_id = $1', [v.id]),
    one<{ deposits: string; withdrawals: string; bets: string; earned: string; milestones: string }>(
      `SELECT
         (SELECT coalesce(sum(p.credited), 0) FROM star_payments p JOIN users u ON u.id = p.user_id WHERE u.referred_by = $1)
           + (SELECT coalesce(sum(d.credited), 0) FROM item_deposits d JOIN users u ON u.id = d.user_id WHERE u.referred_by = $1 AND d.status = 'credited') AS deposits,
         (SELECT coalesce(sum(w.value), 0) FROM withdrawals w JOIN users u ON u.id = w.user_id WHERE u.referred_by = $1 AND w.status = 'done') AS withdrawals,
         (SELECT coalesce(sum(dr.stake_value), 0) FROM drops dr JOIN users u ON u.id = dr.user_id WHERE u.referred_by = $1 AND dr.stake_value > 0 AND NOT dr.demo) AS bets,
         (SELECT coalesce(sum(amount), 0) FROM ref_payouts WHERE referrer_id = $1) AS earned,
         (SELECT coalesce(sum(amount), 0) FROM ref_milestones WHERE referrer_id = $1) AS milestones`,
      [v.id],
    ),
    one<{ ref_balance: string; referred_by: string | null; ref_percent: string | null }>('SELECT ref_balance, referred_by, ref_percent FROM users WHERE id = $1', [v.id]),
  ]);
  const active = num(invited?.active);
  const level = refLevel(active);
  return {
    code,
    link: refLink(code),
    level: level.level,
    // A partner's own percent replaces the level's.
    percent: me?.ref_percent != null ? num(me.ref_percent) : level.percent,
    partner: me?.ref_percent != null,
    next: me?.ref_percent == null && level.next ? { level: level.next.level, percent: level.next.percent, from: level.next.from } : null,
    invited: num(invited?.n),
    active,
    clicks: num(clicks?.n),
    deposits: num(money?.deposits),
    withdrawals: num(money?.withdrawals),
    bets: num(money?.bets),
    earned: num(money?.earned),
    milestones: num(money?.milestones),
    balance: num(me?.ref_balance),
    hasReferrer: !!me?.referred_by,
  };
}

export async function referralFriends(v: Viewer) {
  const rows = await q<{
    id: string;
    username: string | null;
    first_name: string;
    last_name: string | null;
    photo_url: string | null;
    referred_at: string;
    deposits: string;
    bets: string;
    brought: string;
    net: string;
    played: string;
    paid_step: number | null;
  }>(
    `SELECT u.id, u.username, u.first_name, u.last_name, u.photo_url, u.referred_at, ${FRIEND_NET} AS net, ${FRIEND_PLAYED} AS played,
       (SELECT max(rm.step) FROM ref_milestones rm WHERE rm.referral_id = u.id) AS paid_step,
       (SELECT coalesce(sum(p.credited), 0) FROM star_payments p WHERE p.user_id = u.id)
         + (SELECT coalesce(sum(d.credited), 0) FROM item_deposits d WHERE d.user_id = u.id AND d.status = 'credited') AS deposits,
       (SELECT coalesce(sum(dr.stake_value), 0) FROM drops dr WHERE dr.user_id = u.id AND dr.stake_value > 0 AND NOT dr.demo) AS bets,
       (SELECT coalesce(sum(rp.amount), 0) FROM ref_payouts rp WHERE rp.referrer_id = $1 AND rp.referral_id = u.id) AS brought
     FROM users u WHERE u.referred_by = $1 ORDER BY u.referred_at DESC LIMIT 200`,
    [v.id],
  );
  // Friends see each other's names in Telegram anyway; no IDs or balances here.
  return rows.map((r) => ({
    name: displayName({ ...r, id: '' }) || 'Игрок',
    photo: r.photo_url,
    since: ms(r.referred_at),
    deposits: num(r.deposits),
    bets: num(r.bets),
    brought: num(r.brought),
    // «Крупные приглашения»: how far the friend is from the next threshold (both conditions).
    net: Math.max(0, num(r.net)),
    played: num(r.played),
    nextMilestone: nextMilestone(Number(r.paid_step ?? 0)),
  }));
}

export async function transferRefBalance(v: Viewer) {
  assertActive(v);
  return tx(async (c) => {
    const { rows } = await c.query<{ ref_balance: string }>('SELECT ref_balance FROM users WHERE id = $1 FOR UPDATE', [v.id]);
    const moved = num(rows[0]?.ref_balance);
    if (moved <= 0) throw bad('empty', 'На реферальном балансе пока пусто');
    await c.query('UPDATE users SET balance = balance + ref_balance, ref_balance = 0 WHERE id = $1', [v.id]);
    // Referral income is free value: played through like any bonus before a withdrawal.
    await addWager(c, v.id, moved, 'bonus');
    return { moved };
  });
}

const CODE_RE = /^[A-Za-z0-9_]{4,16}$/;

/** A personal code, once a day; the old one is kept in the history and still brings friends to you. */
export async function setRefCode(v: Viewer, body: Body) {
  assertActive(v);
  const code = str(body.code, 'код', 4, 16).trim();
  if (!CODE_RE.test(code)) throw bad('invalid', 'Код: 4–16 символов, латиница, цифры и _');
  await ensureRefCode(db, v.id);
  return tx(async (c) => {
    const { rows } = await c.query<{ ref_code: string; ref_code_changed_at: string | null }>('SELECT ref_code, ref_code_changed_at FROM users WHERE id = $1 FOR UPDATE', [v.id]);
    const old = rows[0]!.ref_code;
    if (old === code) return { code, link: refLink(code) };
    const changed = ms(rows[0]!.ref_code_changed_at);
    if (changed && Date.now() - changed < REF_CODE_COOLDOWN_MS) throw bad('cooldown', 'Код можно менять раз в сутки', { nextAt: changed + REF_CODE_COOLDOWN_MS });
    if (await codeTaken(c, code, v.id)) throw bad('taken', 'Такой код уже занят');
    try {
      await c.query('INSERT INTO ref_code_history (code_lc, user_id) VALUES ($1, $2) ON CONFLICT (code_lc) DO NOTHING', [old.toLowerCase(), v.id]);
      // Taking back one of your own old codes moves it out of the history.
      await c.query('DELETE FROM ref_code_history WHERE code_lc = $1 AND user_id = $2', [code.toLowerCase(), v.id]);
      await c.query('UPDATE users SET ref_code = $2, ref_code_changed_at = now() WHERE id = $1', [v.id, code]);
    } catch (e) {
      if ((e as { code?: string }).code === '23505') throw bad('taken', 'Такой код уже занят');
      throw e;
    }
    return { code, link: refLink(code) };
  });
}

// ---------- Players' own promo codes ----------

const MAX_USES = 500;

/** Coins from real deposits only: free coins (cases, cashback, gifts) can't be turned into promo codes for alts. */
async function hasDeposited(c: Queryable, userId: number) {
  const { rows } = await c.query(
    `SELECT 1 FROM star_payments WHERE user_id = $1
     UNION ALL SELECT 1 FROM item_deposits WHERE user_id = $1 AND status = 'credited'
     LIMIT 1`,
    [userId],
  );
  return rows.length > 0;
}

export async function createUserPromo(v: Viewer, body: Body) {
  assertActive(v);
  const type = body.type === 'case' ? 'case' : 'coins';
  const uses = int(body.uses, 'активаций', 1, MAX_USES);
  const custom = typeof body.code === 'string' && body.code.trim() ? body.code.trim() : null;
  if (custom && !/^[A-Za-z0-9_]{4,24}$/.test(custom)) throw bad('invalid', 'Код: 4–24 символа, латиница, цифры и _');
  return tx(async (c) => {
    if (!(await hasDeposited(c, v.id))) throw bad('need_deposit', 'Свои промокоды открываются после первого пополнения');
    let unit: number;
    let caseId: string | null = null;
    if (type === 'coins') {
      unit = int(body.amount, 'монет за активацию', 1, 10_000);
    } else {
      caseId = str(body.caseId, 'кейс', 1, 80);
      const { rows } = await c.query<{ price: string }>(`SELECT price FROM cases WHERE id = $1 AND kind = 'paid' AND status = 'active'`, [caseId]);
      if (!rows[0]) throw notFound('Кейс недоступен');
      unit = num(rows[0].price);
    }
    const cost = round2(unit * uses);
    let code = custom;
    for (let i = 0; !code && i < 6; i++) {
      const candidate = `GG${newCode(6)}`;
      if (!(await codeTaken(c, candidate))) code = candidate;
    }
    if (!code) throw new Error('could not allocate a promo code');
    if (await codeTaken(c, code)) throw bad('taken', 'Такой код уже занят');
    // Own coins only: demo coins never turn into codes other players can use.
    await spendRealCoins(c, v.id, cost);
    const { rows } = await c
      .query<{ id: string }>(
        `INSERT INTO promo_codes (code, code_key, max_uses, reward_type, reward_amount, reward_case_id, created_by, owner_id, unit_cost)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $7, $8) RETURNING id`,
        [code, code.toLowerCase(), uses, type, type === 'coins' ? unit : 1, caseId, v.id, unit],
      )
      .catch((e: { code?: string }) => {
        // Someone took the same code a moment earlier (the whole transaction, payment included, rolls back).
        if (e.code === '23505') throw bad('taken', 'Такой код уже занят');
        throw e;
      });
    return { id: num(rows[0]!.id), code, cost };
  });
}

export async function userPromos(v: Viewer) {
  const rows = await q<{ id: string; code: string; reward_type: string; reward_amount: string; reward_case_id: string | null; uses: number; max_uses: number; created_at: string }>(
    'SELECT * FROM promo_codes WHERE owner_id = $1 ORDER BY id DESC LIMIT 50',
    [v.id],
  );
  return rows.map((r) => ({
    id: num(r.id),
    code: r.code,
    type: r.reward_type as 'coins' | 'case',
    amount: num(r.reward_amount),
    caseId: r.reward_case_id,
    uses: r.uses,
    maxUses: r.max_uses,
    createdAt: ms(r.created_at),
  }));
}

/** Deleting returns what the unused activations cost. */
export async function deleteUserPromo(v: Viewer, idParam: string) {
  assertActive(v);
  const id = int(idParam, 'промокод');
  return tx(async (c) => {
    const { rows } = await c.query<{ uses: number; max_uses: number; unit_cost: string }>('DELETE FROM promo_codes WHERE id = $1 AND owner_id = $2 RETURNING uses, max_uses, unit_cost', [id, v.id]);
    const r = rows[0];
    if (!r) throw notFound('Промокод не найден');
    const refund = round2(Math.max(0, r.max_uses - r.uses) * num(r.unit_cost));
    if (refund > 0) await c.query('UPDATE users SET balance = balance + $2 WHERE id = $1', [v.id, refund]);
    return { refund };
  });
}

