/** The BC mark: a red B, a blue C and a gold crash arrow (public/logo-bc.webp, a bigger copy for the splash; scripts/blender/brand.py). */
export function BrandMark({ height = 22 }: { height?: number }) {
  return <img className="brand-mark" src={height > 48 ? '/logo-bc-256.webp' : '/logo-bc.webp'} height={height} alt="" aria-hidden="true" draggable={false} />;
}

export function Logo() {
  return (
    <span className="logo">
      <BrandMark height={22} />
      <span className="logo__name">
        BRAINROT<span className="logo__accent">CRASH</span>
      </span>
    </span>
  );
}
