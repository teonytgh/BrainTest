/**
 * «Игра Кальмара» (iteration 35): an admin-run elimination event. Everybody gets an invite, the lobby is open for two
 * minutes, then four stages; whoever crosses the glass bridge places, by crossing order, and the admin's prizes go to
 * the first places. Cartoonish: players «выбывают», nobody dies. The room (server/rooms/squid.ts, a Durable Object) is
 * the referee: lights, hits, the candy check and the bridge's glass are decided there, never in the app.
 *
 * Our own look: the watcher of the first stage is a giant Meowl statue (it turns round with red eyes on «red»), not a
 * copy of the show's doll.
 */

export const SQUID_LOBBY_MS = 120_000;
/** A pause between stages: who passed, then the next stage's rules. */
export const SQUID_BREAK_MS = 9_000;
export const SQUID_MAX_PLACES = 10;
export const SQUID_ROOM_LIMIT = 150;

export const SQUID_STAGES = ['light', 'night', 'cookie', 'bridge'] as const;
export type SquidStage = (typeof SQUID_STAGES)[number];
export type SquidPhase = 'lobby' | 'break' | SquidStage | 'done';

/**
 * `ms`: the stage's clock, or null — no clock: the stage ends when everyone still in has finished or is out (the owner:
 * «не заканчивался таймер — само закончилось, когда игрок пройдёт фулл»). Only the night keeps one: surviving till dawn
 * is what passing it means.
 */
export const SQUID_STAGE: Record<SquidStage, { name: string; ms: number | null; rules: string }> = {
  light: {
    name: 'Тише едешь',
    ms: null,
    rules: 'Беги, пока статуя Meowl смотрит в сторону (зелёный). Она обернулась (красный) — замри: кто двинулся, выбывает. Без таймера: этап кончится, когда все добегут. Стоишь на зелёном 20 секунд — уснул и выбыл.',
  },
  night: {
    name: 'Кровавая ночь',
    ms: 30_000,
    rules: 'Все против всех: у каждого 100 HP, удар мечом снимает 15–20. Кончились HP — выбыл. Продержись 30 секунд до рассвета.',
  },
  cookie: {
    name: 'Сахарные соты',
    ms: null,
    rules: 'Вырежи фигуру из сотов: веди пальцем точно по контуру и не спеши. Съехал с линии или слишком быстро — соты треснули. Без таймера, но 40 секунд без резьбы — соты засохли.',
  },
  bridge: {
    name: 'Стеклянный мост',
    ms: null,
    rules:
      'Сколько игроков дошло, столько и пролётов (до 18): в каждом одно стекло закалённое, другое ломается. Игроки идут по очереди, у каждого 7 секунд на шаг. Пройденные стёкла видят все. Мост кончается, когда все прошли свою очередь.',
  },
};

/** A player who lost the connection for this long during a stage without a clock is out («вышел»). */
export const SQUID_GONE_MS = 15_000;
/**
 * The hidden safety net of a stage without a clock: only an abandoned room ever reaches it (players finish in a
 * minute or two). Never shown as a countdown.
 */
export const SQUID_STAGE_CAP_MS = 10 * 60_000;

// ---------- Stage 1: red light, green light ----------

/** The field's length (units); a lane per player across it. */
export const LIGHT_FIELD = 1800;
export const LIGHT_SPEED = 130;
/** Movement this soon after «red» is forgiven (reaction and lag; 650 ms since iteration 37 — easier to win). */
export const LIGHT_GRACE_MS = 650;
/** Moves of less than this on red are noise, not running. */
export const LIGHT_TOLERANCE = 3;
export const LIGHT_GREEN_MS = [2600, 5600] as const;
export const LIGHT_RED_MS = [1600, 3000] as const;
/** Standing still for this much green light is out («уснул»): without a clock the stage would wait for them forever. */
export const LIGHT_IDLE_MS = 20_000;
/** Running this far (half a second) counts as running for the idle check. */
export const LIGHT_IDLE_GAIN = 60;

// ---------- Stage 2: the night fight ----------

export const NIGHT_RADIUS = 560;
export const NIGHT_SPEED = 170;
export const NIGHT_HP = 100;
export const NIGHT_DAMAGE = [15, 20] as const;
export const NIGHT_REACH = 74;
export const NIGHT_COOLDOWN_MS = 600;

// ---------- Stage 3: the honeycomb candy ----------

export type CookieShape = 'circle' | 'triangle' | 'star' | 'heart';
export const COOKIE_SHAPES: CookieShape[] = ['circle', 'triangle', 'star', 'heart'];
export const COOKIE_SHAPE_NAME: Record<CookieShape, string> = { circle: 'Круг', triangle: 'Треугольник', star: 'Звезда', heart: 'Сердце' };
/** How far from the line a point may be (shape units: the candy is −1…1). */
export const COOKIE_TOLERANCE = 0.075;
/** Faster than this along the line cracks the candy (units per second). */
export const COOKIE_MAX_SPEED = 1.15;
/** The share of the outline that must be traced. */
export const COOKIE_COVER = 0.95;
/** No new piece of the outline traced for this long — the candy dried out, the player is out. */
export const COOKIE_IDLE_MS = 40_000;

/** The shape's outline as a closed polyline in −1…1 (y down). */
export function cookieOutline(shape: CookieShape): [number, number][] {
  const pts: [number, number][] = [];
  if (shape === 'circle') {
    for (let i = 0; i < 48; i++) {
      const a = (i / 48) * Math.PI * 2;
      pts.push([Math.cos(a) * 0.55, Math.sin(a) * 0.55]);
    }
  } else if (shape === 'triangle') {
    const c: [number, number][] = [
      [0, -0.6],
      [0.58, 0.42],
      [-0.58, 0.42],
    ];
    for (let k = 0; k < 3; k++) {
      const [ax, ay] = c[k]!;
      const [bx, by] = c[(k + 1) % 3]!;
      for (let i = 0; i < 16; i++) pts.push([ax + ((bx - ax) * i) / 16, ay + ((by - ay) * i) / 16]);
    }
  } else if (shape === 'star') {
    const corners: [number, number][] = [];
    for (let i = 0; i < 10; i++) {
      const a = -Math.PI / 2 + (i / 10) * Math.PI * 2;
      const r = i % 2 ? 0.27 : 0.62;
      corners.push([Math.cos(a) * r, Math.sin(a) * r]);
    }
    for (let k = 0; k < 10; k++) {
      const [ax, ay] = corners[k]!;
      const [bx, by] = corners[(k + 1) % 10]!;
      for (let i = 0; i < 6; i++) pts.push([ax + ((bx - ax) * i) / 6, ay + ((by - ay) * i) / 6]);
    }
  } else {
    // A heart (the classic curve), point down.
    for (let i = 0; i < 64; i++) {
      const t = (i / 64) * Math.PI * 2;
      const x = 16 * Math.sin(t) ** 3;
      const y = 13 * Math.cos(t) - 5 * Math.cos(2 * t) - 2 * Math.cos(3 * t) - Math.cos(4 * t);
      pts.push([x * 0.036, -y * 0.036 - 0.04]);
    }
  }
  return pts;
}

/** Distance from a point to the outline (as a closed polyline). */
export function outlineDistance(outline: [number, number][], x: number, y: number): number {
  let best = Infinity;
  for (let i = 0; i < outline.length; i++) {
    const [ax, ay] = outline[i]!;
    const [bx, by] = outline[(i + 1) % outline.length]!;
    const dx = bx - ax;
    const dy = by - ay;
    const t = Math.max(0, Math.min(1, ((x - ax) * dx + (y - ay) * dy) / (dx * dx + dy * dy || 1)));
    best = Math.min(best, Math.hypot(x - (ax + t * dx), y - (ay + t * dy)));
  }
  return best;
}

/** The outline sampled evenly: what «covered» is measured on. */
export function outlineSamples(outline: [number, number][], n = 120): [number, number][] {
  const seg: number[] = [];
  let total = 0;
  for (let i = 0; i < outline.length; i++) {
    const [ax, ay] = outline[i]!;
    const [bx, by] = outline[(i + 1) % outline.length]!;
    const d = Math.hypot(bx - ax, by - ay);
    seg.push(d);
    total += d;
  }
  const out: [number, number][] = [];
  for (let k = 0; k < n; k++) {
    let at = (k / n) * total;
    let i = 0;
    while (at > seg[i]! && i < seg.length - 1) at -= seg[i++]!;
    const [ax, ay] = outline[i]!;
    const [bx, by] = outline[(i + 1) % outline.length]!;
    const t = seg[i]! ? at / seg[i]! : 0;
    out.push([ax + (bx - ax) * t, ay + (by - ay) * t]);
  }
  return out;
}

// ---------- Stage 4: the glass bridge ----------

/**
 * As many spans as players reach the bridge (2–18): every unknown span costs one guess, half of them wrong, so about
 * half the players cross — with a fixed 18 a handful of survivors would all fall and nobody would take a prize.
 */
export const BRIDGE_MAX_SPANS = 18;
export const bridgeSpans = (players: number) => Math.max(2, Math.min(BRIDGE_MAX_SPANS, Math.floor(players)));
export const BRIDGE_TURN_MS = 7_000;

export type BridgeSide = 'l' | 'r';

// ---------- Prizes ----------

export type SquidPrize = { type: 'brainrot'; brainrotId: string } | { type: 'coins'; amount: number };

export interface SquidGameView {
  gameId: number;
  lobbyUntil: number;
  needDeposit: boolean;
  prizes: SquidPrize[];
}
