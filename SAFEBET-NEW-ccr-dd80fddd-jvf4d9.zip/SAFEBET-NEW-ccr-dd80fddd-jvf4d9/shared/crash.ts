import { secureRandom, type Rng } from './random';

/** The rocket reaches x2 in 8 s, then keeps the same exponential pace: x5 ≈ 18.6 s, x10 ≈ 26.6 s. */
export const CRASH_GROWTH = Math.LN2 / 8;
// Capped so a server-side wait for one round always fits into a single function invocation.
export const CRASH_MAX = 100;
/** P(reach m) = HOUSE_FACTOR / m, so ~48 % of rockets make it to x2. */
export const HOUSE_FACTOR = 0.96;
export const AUTO_MIN = 1.01;

export function multiplierAt(elapsedMs: number): number {
  return Math.exp((CRASH_GROWTH * Math.max(0, elapsedMs)) / 1000);
}

export function msToReach(multiplier: number): number {
  return (Math.log(multiplier) / CRASH_GROWTH) * 1000;
}

export function floor2(value: number): number {
  return Math.floor(value * 100 + 1e-9) / 100;
}

export function generateCrashPoint(rng: Rng = secureRandom): number {
  const raw = HOUSE_FACTOR / (1 - rng());
  return Math.min(CRASH_MAX, Math.max(1, floor2(raw)));
}

export function parseAutoCashout(input: string): number | null {
  const value = Number.parseFloat(input.replace(',', '.'));
  if (!Number.isFinite(value) || value < AUTO_MIN || value > CRASH_MAX) return null;
  return floor2(value);
}
