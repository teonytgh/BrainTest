import { pickWeighted } from '../shared/cases';
import { assertActive, type Viewer } from './auth';
import { caseDropTable, publicName, rebalancing } from './catalog';
import { ms, num, one, q, tx, type Queryable } from './db';
import { addCoins, deliverDrop, recordDrop, spendRealCoins } from './economy';
import { siteUrl } from './env';
import { bad, notFound } from './errors';
import { botApi, escapeHtml } from './telegram';
import { getUser } from './users';
import { int, str, type Body } from './validate';

/** Nobody joined within this time → the creator's case opens by itself. */
/** A waiting battle on a case that can't be opened (priced into a loss) is refunded after this. */
const LOSING_REFUND_MS = 15 * 60 * 1000;
export const BATTLE_WAIT_MS = 5 * 60 * 1000;
/** Countdown the clients show between the join and the spin. */
export const BATTLE_COUNTDOWN_MS = 5000;
const MAX_WAITING_PER_USER = 3;

interface Round {
  creator: string;
  opponent?: string;
}

interface BattleRow {
  id: string;
  case_id: string;
  case_name: string;
  price: string;
  creator_id: string;
  opponent_id: string | null;
  status: 'waiting' | 'finished' | 'solo' | 'cancelled';
  rounds: Round[];
  winner_id: string | null;
  created_at: string;
  started_at: string | null;
  finished_at: string | null;
}

interface PlayerRow {
  id: string;
  public_id: string;
  username: string | null;
  first_name: string;
  last_name: string | null;
  photo_url: string | null;
}

const playUrl = () => `${siteUrl()}/`;

async function players(ids: (string | null)[]): Promise<Map<string, PlayerRow>> {
  const list = [...new Set(ids.filter((x): x is string => !!x))];
  if (!list.length) return new Map();
  const rows = await q<PlayerRow>('SELECT id, public_id, username, first_name, last_name, photo_url FROM users WHERE id = ANY($1::bigint[])', [list]);
  return new Map(rows.map((r) => [String(r.id), r]));
}

/** An opponent as other players see them: the Telegram name, never the @username. */
const brief = (p: PlayerRow | undefined) => (p ? { publicId: p.public_id, name: publicName(p), photoUrl: p.photo_url } : null);

/** What clients see: public ids only, the winner as a side. */
function view(b: BattleRow, people: Map<string, PlayerRow>, viewerId: number) {
  const winner = b.winner_id === null ? null : String(b.winner_id) === String(b.creator_id) ? 'creator' : 'opponent';
  return {
    id: num(b.id),
    caseId: b.case_id,
    caseName: b.case_name,
    price: num(b.price),
    status: b.status,
    creator: brief(people.get(String(b.creator_id)))!,
    opponent: brief(people.get(String(b.opponent_id))),
    you: num(b.creator_id) === viewerId ? ('creator' as const) : b.opponent_id !== null && num(b.opponent_id) === viewerId ? ('opponent' as const) : null,
    rounds: b.rounds,
    winner: winner as 'creator' | 'opponent' | null,
    createdAt: ms(b.created_at)!,
    expiresAt: ms(b.created_at)! + BATTLE_WAIT_MS,
    startedAt: ms(b.started_at),
    finishedAt: ms(b.finished_at),
  };
}

export type BattleView = ReturnType<typeof view>;

async function views(rows: BattleRow[], viewerId: number) {
  const people = await players(rows.flatMap((b) => [b.creator_id, b.opponent_id]));
  return rows.map((b) => view(b, people, viewerId));
}

function tell(userId: number, html: string) {
  return botApi('sendMessage', {
    chat_id: userId,
    text: html,
    parse_mode: 'HTML',
    reply_markup: { inline_keyboard: [[{ text: '⚔️ Открыть батлы', web_app: { url: `${playUrl()}?open=battle` } }]] },
  });
}

// ---------- Player API ----------

export async function createBattle(v: Viewer, body: Body) {
  assertActive(v);
  const caseId = str(body.caseId, 'кейс', 1, 80);
  const row = await tx(async (c) => {
    const table = await caseDropTable(c, caseId);
    if (!table || !table.items.length) throw notFound('Кейс недоступен');
    if (table.losing) throw rebalancing();
    if (table.kind === 'free' || table.price <= 0) throw bad('free_case', 'Бесплатный кейс нельзя поставить в батл');
    if (table.floating) throw bad('floating_price', 'Кейс с плавающей ценой нельзя поставить в батл: цена может смениться, пока ждёшь соперника');
    const { rows: open } = await c.query<{ n: string }>(`SELECT count(*) AS n FROM battles WHERE creator_id = $1 AND status = 'waiting'`, [v.id]);
    if (num(open[0]?.n) >= MAX_WAITING_PER_USER) throw bad('too_many', `Можно ждать не больше ${MAX_WAITING_PER_USER} батлов одновременно`);
    // Own coins only: a demo stake against another player's real one would turn gifts into real brainrots.
    await spendRealCoins(c, v.id, table.price);
    const { rows } = await c.query<BattleRow>('INSERT INTO battles (case_id, case_name, price, creator_id) VALUES ($1, $2, $3, $4) RETURNING *', [
      table.id,
      table.name,
      table.price,
      v.id,
    ]);
    return rows[0]!;
  });
  return (await views([row], v.id))[0]!;
}

export async function listBattles(v: Viewer) {
  await resolveStaleBattles();
  const [waiting, recent, mine] = await Promise.all([
    q<BattleRow>(`SELECT * FROM battles WHERE status = 'waiting' ORDER BY created_at DESC LIMIT 50`),
    q<BattleRow>(`SELECT * FROM battles WHERE status = 'finished' ORDER BY finished_at DESC LIMIT 15`),
    q<BattleRow>(`SELECT * FROM battles WHERE (creator_id = $1 OR opponent_id = $1) AND status <> 'waiting' ORDER BY id DESC LIMIT 10`, [v.id]),
  ]);
  const all = await views([...waiting, ...recent, ...mine], v.id);
  return {
    waiting: all.slice(0, waiting.length),
    recent: all.slice(waiting.length, waiting.length + recent.length),
    mine: all.slice(waiting.length + recent.length),
  };
}

export async function getBattle(v: Viewer, idParam: string) {
  const id = int(idParam, 'батл');
  await resolveStaleBattles(id);
  const row = await one<BattleRow>('SELECT * FROM battles WHERE id = $1', [id]);
  if (!row) throw notFound('Батл не найден');
  return (await views([row], v.id))[0]!;
}

/** Rolls both cases once the moment the opponent pays; the dearer drop takes both, equal prices are a draw. */
export async function joinBattle(v: Viewer, idParam: string) {
  assertActive(v);
  const id = int(idParam, 'батл');
  const result = await tx(async (c) => {
    const { rows } = await c.query<BattleRow>(`SELECT * FROM battles WHERE id = $1 FOR UPDATE`, [id]);
    const b = rows[0];
    if (!b) throw notFound('Батл не найден');
    if (b.status !== 'waiting') throw bad('taken', 'В этот батл уже зашли');
    if (num(b.creator_id) === v.id) throw bad('own_battle', 'Нельзя зайти в свой батл');
    if (Date.now() - ms(b.created_at)! > BATTLE_WAIT_MS) throw bad('expired', 'Время ожидания батла вышло');
    const table = await caseDropTable(c, b.case_id);
    if (table?.losing) throw rebalancing();
    // Gone, or re-priced since the battle was made (its chances follow the new price): the creator gets the
    // stake back. Returned, not thrown, so the refund is committed.
    if (!table || !table.items.length || table.price !== num(b.price)) {
      await refund(c, b);
      return { refunded: true as const, reason: table && table.items.length ? 'price' : 'gone' };
    }
    const price = num(b.price);
    await spendRealCoins(c, v.id, price);
    // One roll each. Rerolling ties would skew the battle towards unequal pairs and pay far more than the case
    // (with hand-set chances most rolls tie on the cheap item); a tie is a draw instead, so a battle pays exactly
    // what opening the case does.
    const last: Round = { creator: pickWeighted(table.items).brainrotId, opponent: pickWeighted(table.items).brainrotId };
    const rounds: Round[] = [last];
    const pa = table.priceOf.get(last.creator)!;
    const po = table.priceOf.get(last.opponent!)!;
    const creatorId = num(b.creator_id);
    const winner: number | null = pa === po ? null : pa > po ? creatorId : v.id;
    if (winner === null) {
      // A draw: everyone keeps their own drop.
      await deliverDrop(c, creatorId, last.creator, `battle:${b.id}`);
      await deliverDrop(c, v.id, last.opponent!, `battle:${b.id}`);
    } else {
      await deliverDrop(c, winner, last.creator, `battle:${b.id}`);
      await deliverDrop(c, winner, last.opponent!, `battle:${b.id}`);
    }
    const best = table.priceOf.get(last.creator)! >= table.priceOf.get(last.opponent!)! ? last.creator : last.opponent!;
    for (const uid of [creatorId, v.id]) {
      const won = winner === null || winner === uid;
      const own = uid === creatorId ? last.creator : last.opponent!;
      // The winner takes both drops; on a draw each keeps their own.
      const payoutValue = winner === null ? table.priceOf.get(own)! : won ? table.priceOf.get(last.creator)! + table.priceOf.get(last.opponent!)! : 0;
      await recordDrop(c, {
        userId: uid,
        game: 'battle',
        win: won,
        stakeValue: price,
        brainrotId: won ? (winner === null ? own : best) : null,
        payoutValue,
        meta: { battleId: num(b.id), caseId: b.case_id },
      });
      await c.query('UPDATE users SET cases_opened = cases_opened + 1 WHERE id = $1', [uid]);
    }
    const { rows: done } = await c.query<BattleRow>(
      `UPDATE battles SET opponent_id = $2, status = 'finished', rounds = $3::jsonb, winner_id = $4, started_at = now(), finished_at = now()
       WHERE id = $1 RETURNING *`,
      [b.id, v.id, JSON.stringify(rounds), winner],
    );
    return done[0]!;
  });
  if ('refunded' in result) {
    throw bad(
      'case_changed',
      result.reason === 'price' ? 'Цена кейса изменилась — батл отменён, ставка возвращена создателю' : 'Кейс этого батла больше недоступен — ставка возвращена создателю',
    );
  }
  const joiner = await getUser(v.id);
  await tell(
    num(result.creator_id),
    `⚔️ ${escapeHtml(joiner ? publicName(joiner) : 'Игрок')} зашёл в твой батл #${result.id} («${escapeHtml(result.case_name)}») — смотри, кто победил!`,
  );
  return (await views([result], v.id))[0]!;
}

export async function cancelBattle(v: Viewer, idParam: string) {
  const id = int(idParam, 'батл');
  const row = await tx(async (c) => {
    const { rows } = await c.query<BattleRow>(`SELECT * FROM battles WHERE id = $1 AND creator_id = $2 AND status = 'waiting' FOR UPDATE`, [id, v.id]);
    if (!rows[0]) throw bad('not_cancellable', 'Этот батл уже нельзя отменить');
    return refund(c, rows[0]);
  });
  return (await views([row], v.id))[0]!;
}

async function refund(c: Queryable, b: BattleRow) {
  await addCoins(c, num(b.creator_id), num(b.price));
  const { rows } = await c.query<BattleRow>(`UPDATE battles SET status = 'cancelled', finished_at = now() WHERE id = $1 RETURNING *`, [b.id]);
  return rows[0]!;
}

/** Battles nobody joined in time: open the creator's case for them (or refund if the case is gone). */
export async function resolveStaleBattles(onlyId?: number) {
  const stale = await q<{ id: string }>(
    `SELECT id FROM battles WHERE status = 'waiting' AND created_at < now() - interval '${BATTLE_WAIT_MS / 1000} seconds' ${onlyId ? 'AND id = $1' : ''}
     ORDER BY created_at LIMIT 50`,
    onlyId ? [onlyId] : [],
  );
  let resolved = 0;
  for (const { id } of stale) {
    const out = await tx(async (c) => {
      const { rows } = await c.query<BattleRow>(`SELECT * FROM battles WHERE id = $1 AND status = 'waiting' FOR UPDATE SKIP LOCKED`, [id]);
      const b = rows[0];
      if (!b) return null;
      const table = await caseDropTable(c, b.case_id);
      // Re-priced into a loss: wait for the healer; if the catalog can't fix it in 15 minutes, refund.
      if (table?.losing) return Date.now() - ms(b.created_at)! > LOSING_REFUND_MS ? { b: await refund(c, b), item: null } : null;
      if (!table || !table.items.length || table.price !== num(b.price)) return { b: await refund(c, b), item: null };
      const item = pickWeighted(table.items).brainrotId;
      const creatorId = num(b.creator_id);
      await deliverDrop(c, creatorId, item, `battle:${b.id}`);
      await recordDrop(c, { userId: creatorId, game: 'battle', win: true, stakeValue: num(b.price), brainrotId: item, meta: { battleId: num(b.id), solo: true } });
      await c.query('UPDATE users SET cases_opened = cases_opened + 1 WHERE id = $1', [creatorId]);
      const { rows: done } = await c.query<BattleRow>(
        `UPDATE battles SET status = 'solo', rounds = $2::jsonb, winner_id = creator_id, finished_at = now() WHERE id = $1 RETURNING *`,
        [b.id, JSON.stringify([{ creator: item }])],
      );
      const name = (await c.query<{ name: string }>('SELECT name FROM brainrots WHERE id = $1', [item])).rows[0]?.name ?? item;
      return { b: done[0]!, item: name };
    });
    if (!out) continue;
    resolved++;
    await tell(
      num(out.b.creator_id),
      out.item
        ? `⌛ В батл #${out.b.id} никто не зашёл за 5 минут — кейс «${escapeHtml(out.b.case_name)}» открыт автоматически: <b>${escapeHtml(out.item)}</b> уже в инвентаре.`
        : `⌛ Батл #${out.b.id} закрыт: кейс больше недоступен, ставка возвращена.`,
    );
  }
  return resolved;
}
