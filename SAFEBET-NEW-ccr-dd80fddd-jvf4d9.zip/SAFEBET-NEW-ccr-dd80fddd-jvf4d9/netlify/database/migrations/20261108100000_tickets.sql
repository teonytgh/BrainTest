-- Iteration 32: quest tickets, ticket-only cases «Затмение» and «Кенди», the first-visit tour with Meowl.
-- Applied by the Worker (server/autoMigrate.ts), so everything here is safe to run twice.

-- Tickets: a balance of their own, paid by quests, spent on ticket cases only.
ALTER TABLE users ADD COLUMN IF NOT EXISTS tickets INT NOT NULL DEFAULT 0;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'users_tickets_nonneg') THEN
    ALTER TABLE users ADD CONSTRAINT users_tickets_nonneg CHECK (tickets >= 0);
  END IF;
END $$;

-- The tour with Meowl: done or skipped. Players who have already played never see it.
ALTER TABLE users ADD COLUMN IF NOT EXISTS onboarded_at TIMESTAMPTZ;
UPDATE users u SET onboarded_at = now()
WHERE onboarded_at IS NULL AND EXISTS (SELECT 1 FROM drops d WHERE d.user_id = u.id);

-- Quest rewards were coins until now; from here on they are tickets.
ALTER TABLE quest_claims ADD COLUMN IF NOT EXISTS currency TEXT NOT NULL DEFAULT 'coins';
-- Each day's and week's quests, built once from the catalog and kept, so a catalog edit never changes them mid-period.
CREATE TABLE IF NOT EXISTS quest_sets (
  period TEXT PRIMARY KEY,
  quests JSONB NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Ticket cases: their own kind, a price in tickets.
ALTER TABLE cases ADD COLUMN IF NOT EXISTS ticket_price INT CHECK (ticket_price IS NULL OR ticket_price > 0);
ALTER TABLE cases DROP CONSTRAINT IF EXISTS cases_kind_check;
ALTER TABLE cases ADD CONSTRAINT cases_kind_check CHECK (kind IN ('paid', 'free', 'bonus', 'tickets'));

-- Coin prizes the ticket cases need (the catalog already has 1–8 B ones).
INSERT INTO brainrots (id, name, price, image, status, withdrawable, kind) VALUES
  ('coins-10', '10 B', 10, '/brainrots/coin-prize.webp', 'active', FALSE, 'coins'),
  ('coins-15', '15 B', 15, '/brainrots/coin-prize.webp', 'active', FALSE, 'coins')
ON CONFLICT (id) DO NOTHING;

-- The home page theme for them.
INSERT INTO case_sections (title, sort)
SELECT 'Бесплатные', coalesce((SELECT max(sort) FROM case_sections), 0) + 1
WHERE NOT EXISTS (SELECT 1 FROM case_sections WHERE title = 'Бесплатные');

INSERT INTO cases (id, name, price, image, kind, status, sort, mystery, bonus, section_id, ticket_price)
SELECT v.id, v.name, 0, v.image, 'tickets', 'active', v.sort, FALSE, NULL, s.id, v.tickets
FROM (VALUES ('eclipse', 'Затмение', '/cases/eclipse.webp', 950, 119), ('candy', 'Кенди', '/cases/candy.webp', 951, 240))
  AS v(id, name, image, sort, tickets)
CROSS JOIN (SELECT id FROM case_sections WHERE title = 'Бесплатные' ORDER BY id LIMIT 1) s
ON CONFLICT (id) DO NOTHING;

-- Compositions with hand-set chances (docs/SPEC.md, iteration 32): the brainrots are picked by price from whatever
-- the catalog holds right now, so production's own prices decide which ones. Plus the three most expensive brainrots
-- with chance 0 («Невозможно»): they never drop and, like every zero-chance item, players don't see them.
DO $$
DECLARE
  t RECORD;
  pick TEXT;
  used TEXT[];
BEGIN
  IF NOT EXISTS (SELECT 1 FROM case_items WHERE case_id = 'eclipse') THEN
    used := ARRAY['coins-10', 'coins-15'];
    INSERT INTO case_items (case_id, brainrot_id, weight, fixed_chance) VALUES
      ('eclipse', 'coins-10', 1, 0.68),
      ('eclipse', 'coins-15', 1, 0.17);
    FOR t IN SELECT * FROM (VALUES (30, 0.10), (40, 0.04), (50, 0.01)) AS v(target, chance) LOOP
      SELECT id INTO pick FROM brainrots
      WHERE status = 'active' AND kind = 'brainrot' AND NOT (id = ANY (used))
      ORDER BY abs(price - t.target), price, id LIMIT 1;
      IF pick IS NOT NULL THEN
        INSERT INTO case_items (case_id, brainrot_id, weight, fixed_chance) VALUES ('eclipse', pick, 1, t.chance);
        used := used || pick;
      END IF;
    END LOOP;
    INSERT INTO case_items (case_id, brainrot_id, weight, fixed_chance)
    SELECT 'eclipse', id, 1, 0 FROM brainrots
    WHERE status = 'active' AND kind = 'brainrot' AND NOT (id = ANY (used))
    ORDER BY price DESC, id LIMIT 3;
  END IF;

  IF NOT EXISTS (SELECT 1 FROM case_items WHERE case_id = 'candy') THEN
    used := ARRAY[]::TEXT[];
    FOR t IN SELECT * FROM (VALUES (18, 0.35), (25, 0.30), (35, 0.20), (45, 0.10), (60, 0.05)) AS v(target, chance) LOOP
      SELECT id INTO pick FROM brainrots
      WHERE status = 'active' AND kind = 'brainrot' AND NOT (id = ANY (used))
      ORDER BY abs(price - t.target), price, id LIMIT 1;
      IF pick IS NOT NULL THEN
        INSERT INTO case_items (case_id, brainrot_id, weight, fixed_chance) VALUES ('candy', pick, 1, t.chance);
        used := used || pick;
      END IF;
    END LOOP;
    INSERT INTO case_items (case_id, brainrot_id, weight, fixed_chance)
    SELECT 'candy', id, 1, 0 FROM brainrots
    WHERE status = 'active' AND kind = 'brainrot' AND NOT (id = ANY (used))
    ORDER BY price DESC, id LIMIT 3;
  END IF;
END $$;

-- Same as every table: no access through Supabase's public API, only through the Worker.
DO $$
BEGIN
  ALTER TABLE quest_sets ENABLE ROW LEVEL SECURITY;
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'anon') THEN
    REVOKE ALL ON quest_sets FROM anon, authenticated;
  END IF;
END $$;
